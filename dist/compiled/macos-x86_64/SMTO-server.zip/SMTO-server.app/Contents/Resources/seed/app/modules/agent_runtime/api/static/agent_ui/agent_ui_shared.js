(() => {
  "use strict";

  const apiBase = "/api/agent";
  const themeModeNames = Object.freeze(["manual", "auto_day_night"]);
  const defaultSettings = Object.freeze({ ui_theme: "light", ui_theme_mode: "manual" });
  const session = window.SMTOUiSession;
  let appearanceSettings = {}, autoThemeTimer = null;

  function canonicalAgentAppearance(settings = {}, override = session.get("theme")) {
    return ["light", "dark"].includes(override) ? override : effectiveThemeName(settings);
  }

  function applyAgentAppearance(settings = appearanceSettings) {
    appearanceSettings = settings;
    window.SMTOBranding?.apply(settings);
    const root = document.documentElement;
    root.dataset.theme = canonicalAgentAppearance(settings);
    root.dataset.themePreference = normalizeThemeName(settings.ui_theme);
    root.dataset.themeMode = normalizeThemeMode(settings.ui_theme_mode);
    window.SMTOAppearance?.apply(settings);
    root.dataset.waveletEnabled = String(settings.ui_wavelet_enabled === true);
    root.dataset.waveletTimelineEnabled = String(settings.ui_wavelet_timeline_enabled !== false);
    root.dataset.footerEnabled = String(settings.ui_footer_enabled === true);
    root.dataset.thinkingAnimation = settings.ui_thinking_animation || "rubiks-cube-monochrome";
    window.SMTOThinkingAnimations?.setPreference(settings.ui_thinking_animation);
    root.dataset.activityUpdateAnimation = settings.ui_activity_update_animation || "roll";
    window.SMTOActivityUpdates?.setPreference(settings.ui_activity_update_animation);
    clearTimeout(autoThemeTimer);
    if (root.dataset.themeMode === "auto_day_night" && !session.get("theme")) {
      autoThemeTimer = setTimeout(() => applyAgentAppearance(), autoThemeNextChangeDelayMs());
    }
    window.dispatchEvent(new Event("smto:appearance"));
  }

  function bindBrandCopy(node, value) {
    const source = String(value ?? "");
    if (window.SMTOBranding) {
      return window.SMTOBranding.bindText(node, source, () => window.SMTOBranding.text(source));
    }
    node.textContent = source;
    return node;
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = window.__BRANDING_UI__?.page;
    if (!["Scheduler", "Notifications", "Directory", "Parameter Store", "Console"].includes(page)) return;
    let version = 0;
    window.SMTOUiUpdates?.subscribe(["settings.changed"], async () => {
      const request = ++version;
      try {
        const response = await fetch("/api/agent/settings/preferences", {cache: "no-store"});
        if (!response.ok) return;
        const payload = await response.json();
        if (request === version) applyAgentAppearance(payload.settings);
      } catch (_) { /* Keep the last displayed identity while offline. */ }
    });
  });

  function setThemeOverride(theme) {
    session.set("theme", theme);
    applyAgentAppearance();
  }

  window.addEventListener("smto:appearance-saved", event => applyAgentAppearance(event.detail));

  window.addEventListener("pageshow", () => applyAgentAppearance());
  document.addEventListener("visibilitychange", () => { if (!document.hidden) applyAgentAppearance(); });

  function isPlainObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function compactText(value, fallback = "") {
    const text = String(value ?? "").replace(/\s+/g, " ").trim();
    return text || fallback;
  }

  function gatewayConnectionSecured(record) {
    return record?.enabled === true && record.status === "connected"
      && record.transport !== "outbound" && record.scheme === "https"
      && record.tls_trust_state === "pinned"
      && Boolean(record.tls_identity_spki_sha256 && record.tls_last_verified_at);
  }

  function gatewayLockIcon() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    for (const [key, value] of Object.entries({class: "gateway-secure-lock", viewBox: "0 0 24 24",
      width: "14", height: "14", fill: "none", stroke: "currentColor", "stroke-width": "1.5",
      "stroke-linecap": "round", "stroke-linejoin": "round", role: "img",
      "aria-label": "Secure Gateway connection"})) svg.setAttribute(key, value);
    const title = document.createElementNS(svg.namespaceURI, "title");
    title.textContent = "Secure connection · Gateway identity verified";
    const path = document.createElementNS(svg.namespaceURI, "path");
    path.setAttribute("d", "M7 10V7a5 5 0 0 1 10 0v3M5 10h14v11H5Z");
    svg.append(title, path);
    return svg;
  }

  function normalizeThemeName(value) {
    return value === "dark" ? "dark" : "light";
  }

  function normalizeThemeMode(value, fallback = defaultSettings.ui_theme_mode) {
    const candidate = compactText(value).toLowerCase();
    if (themeModeNames.includes(candidate)) {
      return candidate;
    }
    const safeFallback = compactText(fallback, defaultSettings.ui_theme_mode).toLowerCase();
    return themeModeNames.includes(safeFallback) ? safeFallback : defaultSettings.ui_theme_mode;
  }

  function isAutoThemeDay(date = new Date()) {
    const hour = date instanceof Date && !Number.isNaN(date.getTime()) ? date.getHours() : 12;
    return hour >= 6 && hour < 18;
  }

  function effectiveThemeName(settings = {}, date = new Date()) {
    const safe = { ui_theme: normalizeThemeName(settings.ui_theme), ui_theme_mode: normalizeThemeMode(settings.ui_theme_mode) };
    if (safe.ui_theme_mode === "auto_day_night") {
      return isAutoThemeDay(date) ? "light" : "dark";
    }
    return normalizeThemeName(safe.ui_theme);
  }

  function autoThemeNextChangeDelayMs(date = new Date()) {
    const now = date instanceof Date && !Number.isNaN(date.getTime()) ? date : new Date();
    const next = new Date(now.getTime());
    const hour = now.getHours();
    if (hour < 6) {
      next.setHours(6, 0, 0, 0);
    } else if (hour < 18) {
      next.setHours(18, 0, 0, 0);
    } else {
      next.setDate(next.getDate() + 1);
      next.setHours(6, 0, 0, 0);
    }
    return Math.max(1000, next.getTime() - now.getTime());
  }

  function fetchSettingsBackendPreferences() {
    return apiJson("/settings/preferences");
  }

  function writeSettingsBackendPreferences({ settings }) {
    return apiJson("/settings/preferences", { method: "PUT", body: { settings } });
  }

  function apiUrl(path, params = null) {
    const cleanPath = String(path || "").startsWith("/") ? String(path || "") : `/${path || ""}`;
    const url = new URL(`${apiBase}${cleanPath}`, window.location.origin);
    if (isPlainObject(params)) {
      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null && value !== "") {
          url.searchParams.set(key, String(value));
        }
      }
    }
    return `${url.pathname}${url.search}`;
  }

  function manualUrl(docId = "manual-home", port = "8013") {
    return window.SMTOManualLinks.manualUrl(docId, port);
  }

  function hydrateManualLinks(root = document) {
    const scope = root && typeof root.querySelectorAll === "function" ? root : document;
    for (const link of scope.querySelectorAll("[data-manual-link]")) {
      const docId = link.dataset.manualDoc || "manual-home";
      const port = link.dataset.manualPort || "8013";
      link.href = manualUrl(docId, port);
    }
  }

  async function errorMessageFromResponse(response) {
    let text = "";
    try {
      text = await response.text();
    } catch (_error) {
      return `HTTP ${response.status}`;
    }
    if (!text) {
      return `HTTP ${response.status}`;
    }
    try {
      const parsed = JSON.parse(text);
      if (parsed?.error_detail?.error_id) return `${parsed.error_detail.error_id} · ${parsed.error_detail.short_description}`;
      const detail = parsed && parsed.detail;
      if (Array.isArray(detail)) {
        return detail
          .map((item) => compactText(item?.msg || item?.message || item))
          .filter(Boolean)
          .join("; ") || text;
      }
      if (isPlainObject(detail)) {
        return compactText(detail.message || detail.error || JSON.stringify(detail), text);
      }
      return compactText(detail || parsed.message || parsed.error, text);
    } catch (_error) {
      return text;
    }
  }

  async function apiFetch(path, options = {}) {
    const headers = new Headers(options.headers || {});
    const init = { ...options, headers, cache: options.cache || "no-store" };
    delete init.params;
    if (init.body !== undefined && isPlainObject(init.body)) {
      headers.set("Content-Type", "application/json");
      init.body = JSON.stringify(init.body);
    }
    const response = await window.SMTOErrors.fetch(apiUrl(path, options.params), init);
    if (!response.ok) {
      if (response.status === 403) {
        const rejection = await response.clone().json().catch(() => ({}));
        if (rejection.detail?.error_kind === "eula_acceptance_required") {
          window.dispatchEvent(new Event("smto:eula-required"));
        }
      }
      throw await window.SMTOErrors.fromResponse(response);
    }
    return response;
  }

  async function apiJson(path, options = {}) {
    const response = await apiFetch(path, options);
    if (response.status === 204) {
      return {};
    }
    return window.SMTOErrors.readJson(response);
  }

  function ensureUiErrorToastStyles() {
    if (!document?.head || document.getElementById("smto-ui-error-toast-styles")) {
      return;
    }
    const style = document.createElement("style");
    style.id = "smto-ui-error-toast-styles";
    style.textContent = `
      .ui-error-toast-region {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 220;
        display: grid;
        gap: 10px;
        width: min(420px, calc(100vw - 36px));
        pointer-events: none;
      }
      .ui-error-toast {
        pointer-events: auto;
        border: 1px solid var(--border-strong, var(--line));
        border-radius: 12px;
        background: var(--bg);
        box-shadow: var(--shadow);
        color: var(--text);
        padding: 15px 17px;
        font: calc(12px * var(--ui-font-scale, 1))/1.55 var(--ui-font);
        animation: ui-error-toast-in 180ms ease-out;
      }
      .ui-error-toast strong {
        display: block;
        margin-bottom: 3px;
        color: var(--text);
        font-size: calc(13px * var(--ui-font-scale, 1));
        font-weight: 600;
      }
      .ui-error-toast span {
        display: block;
      }
      @keyframes ui-error-toast-in {
        from {
          opacity: 0;
          transform: translateY(10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .ui-error-toast { animation: none; }
      }
    `;
    document.head.append(style);
  }

  function ensureUiErrorToastRegion() {
    if (!document?.body) {
      return null;
    }
    let region = document.getElementById("ui-error-toast-region");
    if (region) {
      return region;
    }
    ensureUiErrorToastStyles();
    region = document.createElement("div");
    region.id = "ui-error-toast-region";
    region.className = "ui-error-toast-region";
    region.setAttribute("aria-live", "assertive");
    region.setAttribute("aria-atomic", "false");
    document.body.append(region);
    return region;
  }

  function resolveUiErrorField(field) {
    if (!field) {
      return null;
    }
    if (typeof field === "string") {
      return document.querySelector(field);
    }
    return typeof field.focus === "function" ? field : null;
  }

  function markUiErrorField(field) {
    const target = resolveUiErrorField(field);
    if (!target) {
      return;
    }
    target.setAttribute("aria-invalid", "true");
    const clearInvalid = () => target.removeAttribute("aria-invalid");
    target.addEventListener("input", clearInvalid, { once: true });
    target.addEventListener("change", clearInvalid, { once: true });
    target.focus({ preventScroll: false });
  }

  function notifyUiError(input = {}, options = {}) {
    const source = typeof input === "string" ? { message: input } : (isPlainObject(input) ? input : {});
    const title = compactText(source.title, "Action failed");
    const message = compactText(source.message || source.detail || source.error, "The action could not be completed.");
    const fix = compactText(source.fix);
    const region = ensureUiErrorToastRegion();
    markUiErrorField(source.field);
    if (!region) {
      return null;
    }
    const toast = document.createElement("div");
    toast.className = "ui-error-toast";
    toast.dataset.level = "error";
    toast.setAttribute("role", "alert");
    const titleNode = document.createElement("strong");
    titleNode.textContent = title;
    const messageNode = document.createElement("span");
    messageNode.textContent = fix ? `${message} Fix: ${fix}` : message;
    toast.append(titleNode, messageNode);
    if (source.error_detail || source.error_ref || source.error?.error_detail) {
      window.SMTOErrors?.present(toast, source.error || source, {profile: "toast"});
    }
    region.prepend(toast);
    const timeout = Number(options.persistMs ?? source.persistMs ?? 9000);
    if (timeout > 0) {
      window.setTimeout(() => toast.remove(), timeout);
    }
    return toast;
  }

  window.SMTOAgentUi = Object.freeze({
    bindBrandCopy,
    canonicalAgentAppearance,
    applyAgentAppearance,
    setThemeOverride,
    apiJson,
    compactText,
    gatewayConnectionSecured,
    gatewayLockIcon,
    hydrateManualLinks,
    manualUrl,
    fetchSettingsBackendPreferences,
    normalizeThemeMode,
    notifyUiError,
    autoThemeNextChangeDelayMs,
    effectiveThemeName,
    writeSettingsBackendPreferences,
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => hydrateManualLinks(), { once: true });
  } else {
    hydrateManualLinks();
  }
})();
