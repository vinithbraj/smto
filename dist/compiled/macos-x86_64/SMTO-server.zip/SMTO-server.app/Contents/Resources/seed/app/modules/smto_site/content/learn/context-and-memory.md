---
{"title": "What the assistant can remember", "status": "published"}
---
## The AI sees a limited amount at once

The information sent to the AI with a request is called its **context**. It may
include your instructions, earlier messages, and tool results. Each model has a
limit on how much it can take in at once.

SMTO can shorten earlier information while keeping saved results that can be read
again. Keeping a record does not mean the AI has read every part of it.

## Notes help with the current conversation

The assistant can write and read notes within one conversation. In technical
settings, this notebook is called Agent KV. Notes can survive a restart or a
shortened chat history, but they are not automatically included in every AI request.
The assistant needs to read the notes it wants to use.

## Memory can help in later conversations

The Memory feature can save useful information across conversations. Examples
include a command that has been checked, a correction, or a lasting preference.
The assistant can look up saved information when it is relevant to a later task.

If you tell the assistant not to remember something, that instruction takes
priority. Memory should not be used to store passwords, access keys, whole chat
histories, or unverified guesses. Information read from Memory may be sent to the AI.

## Saved information can become outdated

A command that worked last week may fail after a program changes. A saved note
about a computer does not prove that the computer is still online. The assistant
needs current results when checking what is true now.

Think of memory as helpful background information. For a result you depend on,
check the file, tool output, or service involved in the current task.

Read [how to check results](/learn/verifiable-agent-completion),
[how SMTO helps smaller models](/learn/small-model-task-orchestration), and
[how longer tasks are saved](/docs/concepts/jobs).
See [SMTO's features](/product) and [installation options](/download).
