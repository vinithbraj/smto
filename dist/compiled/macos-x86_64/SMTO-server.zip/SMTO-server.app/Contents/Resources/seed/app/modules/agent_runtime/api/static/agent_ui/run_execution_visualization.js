/* Pure text projection of authoritative execution facts; no runtime authority. */
(() => {
  "use strict";
  const SUMMARY_THRESHOLD = 100;
  const LEGEND = "#### Running   .... Waiting   ==== Background   [ ? ] Timing unavailable";
  const clean = (value, limit = 160) => Array.from(String(value ?? "").replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g, " ")).slice(0, limit).join("");
  const finite = value => typeof value === "number" && Number.isFinite(value);
  const duration = value => !finite(value) ? "timing unavailable" : value === 0 ? "0s" : value < 1 ? `${Math.round(value * 1000)}ms` : value < 60 ? `${Number(value.toFixed(1))}s` : `${Number((value / 60).toFixed(1))}m`;
  const short = (value, width) => { const chars = Array.from(clean(value)); return chars.length > width ? chars.slice(0, width - 1).join("") + "…" : chars.join(""); };
  const status = state => ({completed: "OK", answered: "OK", failed: "FAIL", cancelled: "CANCELLED", interrupted: "INTERRUPTED",
    unknown: "UNKNOWN", outcome_unknown: "UNKNOWN", lost: "UNKNOWN", not_admitted: "NOT ADMITTED", rejected_policy: "NOT ADMITTED",
    blocked_dependency: "BLOCKED", blocked_resource: "BLOCKED", blocked_conflict: "BLOCKED", running_background: "RUNNING",
    runnable_waiting_capacity: "WAITING", pending_dependency: "WAITING", queued_background: "WAITING",
    waiting_user: "WAITING", waiting_approval: "WAITING"})[state] || clean(state || "unknown", 24).replaceAll("_", " ").toUpperCase();
  function spans(activity, snapshot, field = "intervals") {
    const values = [];
    for (const span of activity[field] || []) {
      const end = finite(span.finished_at) ? span.finished_at : span.open && snapshot.live ? snapshot.observed_at : null;
      if (finite(span.started_at) && finite(end) && end > span.started_at) values.push([span.started_at, end]);
    }
    return values.sort((a, b) => a[0] - b[0]);
  }
  function analyze(snapshot) {
    const activities = snapshot.activities || [], intervals = [], points = [];
    activities.forEach((activity, index) => {
      // Merge an Activity's own spans so resumes cannot double-count it.
      const merged = [];
      for (const [start, end] of spans(activity, snapshot)) {
        if (merged.length && start <= merged.at(-1)[1]) merged.at(-1)[1] = Math.max(end, merged.at(-1)[1]);
        else merged.push([start, end]);
      }
      for (const [start, end] of merged) { intervals.push({start, end, index}); points.push([start, 1], [end, -1]); }
    });
    // Ends sort before starts: touching intervals do not overlap.
    points.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    let active = 0, peak = 0;
    for (const [, delta] of points) { active += delta; peak = Math.max(peak, active); }
    intervals.sort((a, b) => a.start - b.start || a.end - b.end || a.index - b.index);
    const phases = [];
    for (const interval of intervals) {
      const last = phases.at(-1);
      if (last && interval.start < last.end) { last.end = Math.max(last.end, interval.end); last.members.add(interval.index); }
      else phases.push({start: interval.start, end: interval.end, members: new Set([interval.index])});
    }
    const timestamps = activities.flatMap(a => [...spans(a, snapshot), ...spans(a, snapshot, "waits")].flat());
    const start = finite(snapshot.started_at) ? snapshot.started_at : timestamps.length ? Math.min(...timestamps) : null;
    const endpoint = snapshot.live ? snapshot.observed_at : snapshot.finished_at;
    const end = Math.max(...timestamps, finite(endpoint) ? endpoint : -Infinity);
    return {peak, phases, start, end: finite(end) ? end : null,
      duration: finite(start) && finite(endpoint) ? Math.max(0, endpoint - start) : null};
  }
  function groups(snapshot, analysis) {
    const activities = snapshot.activities, grouped = new Map();
    if (activities.some(a => a.batch_id)) {
      const batches = new Map();
      for (const a of activities) if (a.batch_id && !batches.has(a.batch_id)) batches.set(a.batch_id, batches.size + 1);
      activities.forEach((a, index) => {
        const key = a.batch_id ? `Batch ${batches.get(a.batch_id)}${Number.isInteger(a.wave_id) ? ` · wave ${a.wave_id + 1}` : ""}` : "Other recorded activities";
        if (!grouped.has(key)) grouped.set(key, []);
        grouped.get(key).push(index);
      });
    } else if (activities.some(a => a.depends_on?.length)) {
      const levels = new Map(), byId = new Map(activities.map(a => [a.activity_id, a]));
      for (let pass = 0; pass < activities.length; pass++) {
        let changed = false;
        for (const a of activities) {
          if (levels.has(a.activity_id)) continue;
          const deps = (a.depends_on || []).filter(id => byId.has(id));
          if (deps.every(id => levels.has(id))) { levels.set(a.activity_id, Math.max(0, ...deps.map(id => levels.get(id) + 1))); changed = true; }
        }
        if (!changed) break;
      }
      activities.forEach((a, index) => {
        const level = levels.get(a.activity_id), key = level === undefined ? "Unresolved dependency layer" : `Dependency layer ${level + 1}`;
        if (!grouped.has(key)) grouped.set(key, []);
        grouped.get(key).push(index);
      });
    } else {
      const seen = new Set();
      analysis.phases.forEach((phase, i) => {
        const members = [...phase.members].filter(index => !seen.has(index));
        members.forEach(index => seen.add(index));
        if (members.length) grouped.set(`Execution phase ${i + 1}`, members);
      });
      const unknown = activities.map((_, i) => i).filter(i => !seen.has(i));
      if (unknown.length) grouped.set("No measured execution", unknown);
    }
    const entries = [...grouped];
    // Even 500 singleton batches have bounded default output.
    if (entries.length > 20) return [...entries.slice(0, 19), [`${entries.length - 19} further groups`, entries.slice(19).flatMap(([, members]) => members)]];
    return entries;
  }
  function render(snapshot, columns = 100, {all = false} = {}) {
    columns = Math.min(120, Math.max(70, Math.floor(columns) || 100));
    const width = columns - 22, analysis = analyze(snapshot), activities = snapshot.activities || [];
    const summary = `${activities.length} ${activities.length === 1 ? "activity" : "activities"} · ${duration(analysis.duration)} · peak concurrency ${analysis.peak} · ${analysis.phases.length} execution ${analysis.phases.length === 1 ? "phase" : "phases"}`;
    const lines = [`Run execution${snapshot.live ? " · LIVE" : ""}`, summary, ""];
    const tasks = snapshot.top_level_tasks || [];
    if (tasks.some(task => task.dependencies?.length)) {
      lines.push("Top-level task dependencies (success required)");
      for (const task of tasks) {
        const label = `Task ${task.creation_sequence || task.task_id}`;
        const state = task.status === "queued" && task.dependency?.state !== "satisfied"
          ? task.dependency?.state : task.status;
        lines.push(short(`${label} [${status(state)}] ${task.task_id}`, columns));
        for (const edge of task.dependencies || []) {
          const target = tasks.find(item => item.task_id === edge.task_id);
          lines.push(short(`  Task ${target?.creation_sequence || edge.task_id} --success--> ${label}`, columns));
        }
      }
      lines.push("");
    }
    if (!activities.length) return [...lines, "No executable Activities were recorded for this run."].join("\n");
    if (activities.length > SUMMARY_THRESHOLD && !all) {
      for (const [label, members] of groups(snapshot, analysis)) {
        const measured = members.flatMap(i => spans(activities[i], snapshot));
        const time = measured.length ? duration(Math.max(...measured.map(s => s[1])) - Math.min(...measured.map(s => s[0]))) : "timing unavailable";
        const outcomes = [...new Set(members.map(i => status(activities[i].state)))].join(", ");
        lines.push(short(`${label} · ${members.length} activities · ${time} · ${outcomes}`, columns));
      }
      lines.push("", "Show all activities to expand the timeline.");
    } else {
      const start = analysis.start, total = Math.max(0.001, (analysis.end ?? start) - start);
      const column = at => Math.min(width - 1, Math.max(0, Math.floor((at - start) / total * width)));
      const axis = Array(width).fill(" "), ticks = Array(width).fill("-");
      for (let i = 0; i <= 4; i++) {
        const pos = Math.round(i / 4 * (width - 1)), label = duration(total * i / 4), from = Math.min(pos, width - label.length);
        [...label].forEach((c, n) => { axis[from + n] = c; }); ticks[pos] = "|";
      }
      const labelWidth = Math.max(4, `A${activities.length}`.length), indent = " ".repeat(labelWidth + 2);
      lines.push("Timeline");
      if (finite(start) && finite(analysis.end)) lines.push(`${"Time".padEnd(labelWidth)}  ${axis.join("")}`, `${indent}${ticks.join("")}`);
      const ids = new Map(activities.map((a, index) => [a.activity_id, `A${index + 1}`]));
      const batches = new Map();
      const details = [];
      for (const a of activities) if (a.batch_id && !batches.has(a.batch_id)) batches.set(a.batch_id, batches.size + 1);
      activities.forEach((a, index) => {
        const heading = `A${index + 1} ${a.display_label}${a.target ? ` · ${a.target}` : ""}`;
        details.push(short(heading, columns));
        if (a.target && Array.from(heading).length > columns) details.push(short(`     Target ${a.target}`, columns));
        const bar = Array(width).fill(" ");
        const paint = (values, glyph) => { for (const [begin, end] of values) {
          const left = column(begin), right = Math.min(width, Math.max(left + 1, Math.floor((end - start) / total * width)));
          for (let p = left; p < right; p++) bar[p] = glyph;
        }};
        const running = spans(a, snapshot), waits = spans(a, snapshot, "waits");
        paint(waits, ".");
        for (const interval of a.intervals || []) paint(spans({...a, intervals: [interval]}, snapshot), (interval.background ?? a.background) ? "=" : "#");
        const noRun = ["NOT ADMITTED", "BLOCKED"].includes(status(a.state));
        if (!running.length && !waits.length) bar.splice(0, 5, ...(!noRun ? "[ ? ]" : "     "));
        lines.push(`${`A${index + 1}`.padEnd(labelWidth)} |${bar.join("")}|  ${status(a.state)}`);
        const facts = [];
        if (a.background) facts.push("background");
        if (a.batch_id) facts.push(`batch ${batches.get(a.batch_id)}`);
        if (Number.isInteger(a.wave_id)) facts.push(`wave ${a.wave_id + 1}`);
        if (a.resource_class) facts.push(clean(a.resource_class).replaceAll("_", " "));
        if (running.length) facts.push(`run ${duration(running.reduce((sum, [s, e]) => sum + e - s, 0))}`);
        else if (!noRun) facts.push("timing unavailable");
        if (facts.length) details.push(short(`     ${facts.join(" · ")}`, columns));
        if (a.depends_on?.length) details.push(short(`     ${a.depends_on.map(id => ids.get(id) || `external:${clean(id, 32)}`).join(" + ")} ${status(a.state) === "BLOCKED" ? "-X->" : "--->"} A${index + 1} (depends on)`, columns));
        for (const wait of a.waits || []) {
          const end = finite(wait.finished_at) ? wait.finished_at : wait.open && snapshot.live ? snapshot.observed_at : null;
          details.push(short(`     wait ${clean(wait.kind)} · ${duration(finite(end) && finite(wait.started_at) ? Math.max(0, end - wait.started_at) : null)}${wait.reason ? ` · ${wait.reason}` : ""}`, columns));
        }
        if (a.wait_reason) details.push(short(`     ${a.wait_reason}`, columns));
        details.push("");
      });
      lines.push("", LEGEND, "", "Activity details", "-".repeat(columns), ...details);
      if (analysis.phases.length && analysis.phases.length <= 8) lines.push("Execution phases");
      if (analysis.phases.length <= 8) for (const [i, phase] of analysis.phases.entries()) {
        lines.push(short(`Phase ${i + 1} · ${duration(phase.start - start)}–${duration(phase.end - start)} · ${duration(phase.end - phase.start)} · ${phase.members.size > 1 ? "overlapping execution" : "one activity"}`, columns));
      }
    }
    for (const batch of snapshot.scheduler?.batches || []) if (batch.serialized_conflicts > 0) lines.push(`${batch.serialized_conflicts} scheduler conflict(s) serialized in a recorded batch.`);
    if (activities.length > SUMMARY_THRESHOLD && !all) lines.push("", LEGEND);
    return lines.join("\n");
  }

  const node = (tag, text, className) => { const el = document.createElement(tag); if (text) el.textContent = text; if (className) el.className = className; return el; };
  let sequence = 0;
  function attach(actionRow, requestId, apiJson) {
    const action = node("button", "Visualize run", "run-detail-action run-visualize-action"); action.type = "button";
    const panel = node("section", "", "run-execution-visualization"); panel.id = `run-execution-${++sequence}`; panel.hidden = true;
    panel.setAttribute("aria-label", "Run execution visualization");
    action.setAttribute("aria-controls", panel.id); action.setAttribute("aria-expanded", "false");
    actionRow.append(action); actionRow.after(panel);
    let expanded = false, snapshot = null, dirty = true, pending = false, timer = null, unsubscribe = null, observer = null;
    let all = false, generation = 0, diagram = "", renderKey = "", knownStatus = "";
    const cache = new Map();
    function stop() { clearTimeout(timer); timer = null; unsubscribe?.(); unsubscribe = null; observer?.disconnect(); observer = null; }
    function columns() {
      const measure = node("span", "0000000000", "run-execution-measure"); panel.append(measure);
      const char = measure.getBoundingClientRect().width / 10 || 7.8; measure.remove();
      return Math.max(70, Math.min(120, Math.floor((panel.clientWidth - 32) / char)));
    }
    function draw() {
      if (!expanded || !panel.isConnected || !snapshot) return;
      const width = columns(), key = `${snapshot.run_id}:${snapshot.revision}:${snapshot.live ? snapshot.observed_at : ""}:${width}:${all}`;
      if (key === renderKey) return;
      diagram = cache.get(key) || render(snapshot, width, {all});
      cache.set(key, diagram); if (cache.size > 6) cache.delete(cache.keys().next().value);
      renderKey = key;
      const pre = node("pre", diagram); pre.tabIndex = 0; pre.setAttribute("aria-label", "Execution timeline");
      const controls = node("div", "", "run-execution-controls");
      if (snapshot.activities.length > SUMMARY_THRESHOLD) {
        const show = node("button", all ? "Show summary" : "Show all activities", "run-detail-action"); show.type = "button";
        show.onclick = () => { all = !all; draw(); }; controls.append(show);
      }
      const copy = node("button", "Copy diagram", "run-detail-action"); copy.type = "button";
      const copied = window.SMTOCopyFeedback.bind(copy);
      const feedback = node("span", "", "run-execution-feedback"); feedback.setAttribute("role", "status");
      copy.onclick = async () => {
        try { await navigator.clipboard.writeText(diagram); copied(); feedback.textContent = "Copied"; }
        catch (_) { feedback.textContent = "Could not copy diagram. Select the text to copy."; }
      };
      controls.append(feedback, copy); panel.replaceChildren(pre, controls);
    }
    function fail() {
      renderKey = "";
      const error = node("p", "Could not visualize this run. "); error.setAttribute("role", "status");
      const retry = node("button", "Retry", "run-detail-action"); retry.type = "button";
      retry.onclick = () => { dirty = true; void load(); }; error.append(retry); panel.replaceChildren(error);
    }
    function subscriptions() {
      if (!expanded || (!snapshot?.live && !snapshot?.top_level_tasks?.length)) { unsubscribe?.(); unsubscribe = null; return; }
      if (!unsubscribe) unsubscribe = window.SMTOUiUpdates?.subscribe(["runs.changed", "tasks.changed"], payload => {
        if (payload.syncRequired || payload.events?.some(event => !event.ids?.request_id && !event.ids?.run_id || event.ids?.request_id === requestId || event.ids?.run_id === snapshot.run_id)) invalidate();
      });
    }
    async function load() {
      if (!expanded || pending || !panel.isConnected) return;
      pending = true; dirty = false; const version = generation;
      const loading = node("p", "Loading visualization…", "output-loading");
      loading.setAttribute("role", "status"); loading.setAttribute("aria-label", "Loading run visualization");
      if (!snapshot || !panel.querySelector("pre")) {
        renderKey = "";
        panel.replaceChildren(loading);
      } else panel.prepend(loading);
      panel.setAttribute("aria-busy", "true");
      try {
        const value = await apiJson(`/api/agent/native/${encodeURIComponent(requestId)}/execution-visualization`);
        if (version !== generation) dirty = true;
        if (!snapshot || snapshot.revision !== value.revision) snapshot = value;
        knownStatus = value.status;
        if (expanded && panel.isConnected) { draw(); subscriptions(); }
      } catch (_) { dirty = true; if (expanded && panel.isConnected) fail(); }
      finally {
        loading.remove();
        pending = false; panel.setAttribute("aria-busy", "false");
        if (expanded && version !== generation) schedule();
      }
    }
    function schedule() {
      if (!expanded || timer !== null) return;
      timer = setTimeout(() => { timer = null; if (!panel.isConnected) { stop(); return; } void load(); }, 350);
    }
    function invalidate() { dirty = true; generation++; schedule(); }
    function event(event) {
      if (!/^(activity\.|batch\.|scheduler\.|graph\.|invocation\.(started|completed)|request\.(running|completed|failed|cancelled|interrupted)|run\.(resumed|paused|stop\.))/.test(event.event_type || "")) return;
      // The caller owns trace deduplication; cursor IDs can restart on resume.
      invalidate();
    }
    action.onclick = () => {
      expanded = !expanded; panel.hidden = !expanded;
      action.textContent = expanded ? "Hide visualization" : "Visualize run"; action.setAttribute("aria-expanded", String(expanded));
      if (!expanded) { stop(); return; }
      if (window.ResizeObserver) { observer = new ResizeObserver(() => { try { draw(); } catch (_) { fail(); } }); observer.observe(panel); }
      if (dirty || !snapshot || snapshot.live) void load();
      else { try { draw(); subscriptions(); } catch (_) { fail(); } }
    };
    return {action, panel, event, invalidate,
      statusChanged(status) { if (status && status !== knownStatus) { knownStatus = status; invalidate(); } },
      dispose() { expanded = false; generation++; stop(); }};
  }
  window.SMTORunExecution = {render, analyze, attach, SUMMARY_THRESHOLD};
})();
