---
id: ui-pages-tour
title: UI Pages Tour
kind: manual
tags: [manual, ui]
order: 22
---
# UI Pages Tour

Choose **Plan** from the Mode picker in expanded composer Controls (mobile:
**Agent options**) to inspect and discuss changes before implementation. The picker
offers Agent, Plan, and Ask; Conversation is hidden from it and Settings. A completed
plan offers **Yes, implement this plan** in the same
chat, **Yes, clear context and implement** in a fresh chat, and **No, stay in Plan
mode** to request revisions. Both implementation choices switch to Agent mode.
Fresh implementation carries the approved plan and
preferences without the planning transcript. Task Contract remains a separate saved
preference: planning suppresses compilation and implementation restores it. Permission
grants do not permit writes while a task is in Plan.

`/agent-ui` is the conversational workspace. It exposes conversations, tasks, jobs, waits and attachments from persisted runtime state. Missing authentication values use ordinary `ask_user` and one normal reply. Literal values remain canonical task data; optional Redaction settings control consumer projections. OAuth authorization retains its protocol-specific interaction.

The header's Save to SQL button turns green when SQL confirms all data accepted before that click. Large saves can take several minutes; the button keeps checking and stays in its saving state. A temporary connection interruption while checking also keeps checking. Red indicates a rejected or unconfirmed save request, a reported write failure, or a server restart before confirmation; the tooltip explains which occurred. After a write failure, the button continues watching the server's automatic retry and also allows a manual retry. Later changes may need another save; green confirms the data covered by the completed click.

When stopping the server, keep its terminal open until it prints **SQL save complete. Safe to close this terminal.** Shutdown logs explain when background services are stopping and when SQL saving begins, with elapsed-time updates every five seconds. The final save waits for completion even when it exceeds the normal worker shutdown timeout. Avoid pressing Ctrl+C again or force-killing the server while it is saving. A failed or interrupted save prints a warning instead of claiming completion.

Expand an Agent activity row to inspect the input and output from that exact invocation, projected according to its redaction setting. Completed HTTP requests expose request headers/body, status, response headers/body and available timing/size metadata. Web Search exposes the returned sources; Web Read shows extracted content. Connection rows explain the target, Gateway and authentication state. Expanding a captured Shell row opens its retained and live output stream; collapsing it closes the viewer while the command continues. Running state, exit code and viewer connection state are shown separately. Copy output and Jump to latest operate locally and do not call the model. Python and job operations expose their available execution evidence.

For a Shell command running as a background job, the inspector reads the runtime's
retained job status. Output appears when the runtime retains the completed result;
the panel explains this while the job is running. Completion freezes elapsed time
at the recorded job duration and closes the observer. Missing or incomplete output
is labeled explicitly. Opening the inspector does not query the Gateway or restart
the job.

Inspection does not pause the Agent. Details become available as each invocation completes, before the task's final answer or Results document. Responses are rendered as data; retrieved HTML cannot execute. Credentials remain literal unless the owning Redaction source is enabled. Hidden reasoning, internal prompts and context-control contents are excluded from this inspector.

The inspector fetches details only when opened. Each section previews at most 64 KiB, with a 256 KiB content budget per invocation; truncation is marked explicitly. Binary content is represented by metadata. Existing HTTP artifact retention is preserved and its metadata remains inspectable. Normal reload/reconnect works while the backend retains the detail. Previews share the trace's in-memory lifetime, with at most 64 per request and 16 MiB across all requests. Evicted details or a server restart show “Execution details are no longer available.” Older Gateways can supply result evidence but cannot retroactively provide transmitted request details.

Use `/schedules` for the Scheduler Manager (also available from the Agent header calendar icon), `/directory` for available services, `/settings` for active configuration, `/parameter-editor` for Parameter Store profiles, protected values, and reusable agent guidance. Gmail's delivery/sync activity is provider diagnostics, separate from the model decision loop.

In Parameter Store, the template menu beside **New** offers **Blank**, **Server**,
**Proxmox Server**, **Credential**, **Git Repository**, Gmail profiles, and **HTTP Connection** auth starters. Choose a template and click
**New** to start an unsaved draft. Saving a profile does not enable a skill or connect
to its server. The [Proxmox guide](24-proxmox.md) covers enabling the optional skill
and using a saved server profile; [Parameter Store](16-parameter-store-context-sql.md)
explains typed credential privacy and ordinary parameter behavior.

Ordinary chat is sent to the model. Slash commands use the application control API, add no model-history turn, and remain available during execution according to each command’s state requirements. Type `/` to discover `/status`, `/new`, `/stop`, `/delete`, `/help`, `/pause`, `/resume`, `/compact`, `/history`, `/settings`, `/queue`, `/clearqueue`, `/trace`, and `/restart`. `/status` opens a closeable status panel or mobile sheet with exact or explicitly estimated context usage. `/delete` uses the normal safety confirmation and opens the nearest older surviving conversation, or New Chat. `/restart` restarts the backend and requests restarts for enabled gateways even while tasks are active; active work may be interrupted. Use the composer and run controls to submit work, attach context, and manage the current run. The task board displays model-authored high-level outcomes, while command cards show actual tool output. Normal chat does not open a browser terminal connection; backend Gateway PTYs remain available to explicit execution capabilities.

Conversation deletion uses one confirmation on desktop and mobile. It removes saved
turns, discards queued prompts, abandons conversation work and requests cancellation
of running operations. Work changing while the confirmation is open does not block
deletion. Already-started external operations may continue; their execution evidence
is retained, and independent schedules, monitors and tasks remain. Bulk deletion
requires another review if the set of selected conversations changes.
While the request is pending, the dialog shows **Deleting…**. **Close** dismisses
the desktop dialog without cancelling the submitted deletion.

Mission Control → **Model Configuration** offers Provider Defaults, smTO Recommended and Custom profiles. Each parameter exposes Provider Default or User Configured, with expandable behavior, recommendations and warnings. Search matches parameter names, canonical keys, provider tags and help. Open **Resolved settings** to see exactly which values will be configured or omitted. These generation choices affect normal agent execution; Task Contract generation and recovery keep their own configuration. See [Configuration and storage](09-configuration-storage.md) for persistence and resume behavior.

The [Model Configuration guide](25-model-configuration.md) explains profile changes,
provider compatibility and why saved runs keep earlier values. Endpoint and timeout
controls are now in the same section; they retain their existing transport scope.

Saved HTTP connections live in Parameter Store, with an HTTP Connection tab for
public configuration, credentials, selected-Gateway testing and session disconnect.
Settings no longer contains a separate HTTP Connections editor. Metadata, rename,
copy reference and delete use the normal Parameter controls; existing profiles
appear automatically. See the [HTTP guide](architecture/18-http.md).

## Workflows

After an eligible completed run, **Save as workflow** opens a review of verified
steps, parameters, account references, Gateway policy and risks. **More options →
Workflows** provides revision history, Run now, Schedule, and Archive. Scheduling
uses the existing Scheduler Manager. See [Workflow recorder](44-workflow-recorder.md)
for supported capture and recovery behavior.
