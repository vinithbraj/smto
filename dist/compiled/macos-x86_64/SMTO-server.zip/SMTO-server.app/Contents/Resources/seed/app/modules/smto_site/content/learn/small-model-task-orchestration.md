---
{"title": "How SMTO helps smaller AI models", "status": "published"}
---
## What the name SMTO means

SMTO stands for Small Model Task Orchestration. Here, orchestration means organizing
the steps of a task. The AI decides what to do, while SMTO runs tools and saves what
happened.

A smaller AI model often needs less powerful hardware, but it may have more trouble
with complex instructions. SMTO can help it keep track of work. It cannot give a
model knowledge or judgment that the model does not have.

## AI can only use so much information at once

A model has a limit on the information it can read in one request. That information
is called its context. A long chat, large file, and several tool results can take
up that space quickly.

SMTO keeps the full saved results separate from the shorter information it sends
to the model. The AI may need to ask for more detail. A saved file or result is not
proof that the AI has read all of it.

## Saved records help with several steps

Imagine a task where a file was read, a change needs approval, and another action
is still running. The assistant needs to know which of these things happened and
which still needs attention.

SMTO saves those details along with permissions and errors. The model has less to
reconstruct from earlier chat messages. Clear records can help, but the AI may
still misunderstand what the records mean.

## Give the AI tools relevant to the task

SMTO selects tools that fit the request instead of describing every installed tool
at once. The assistant can ask for another tool when needed. Access still depends
on permissions, account connections, and whether the tool is available.

For example, reading a text file needs file access. Searching the web needs the
web research tools. Installing either tool does not automatically allow every action.

## Test with work you understand

Try a small task whose result you can check. Look at what the tools returned and
what the AI wrote. If the AI misunderstood the file, saved progress may not fix
that. If a tool could not connect, changing the model may not fix the connection.

Read about [tools and permissions](/learn/agent-capabilities-and-permissions),
[notes and memory](/learn/context-and-memory), and
[AI model settings](/docs/configuration/models).
See [SMTO's features](/product) and [installation options](/download).
