/**
 * @file src/agent_runtime/api/static/agent_ui/run_activity.js
 * @brief Render existing invocation state and bounded Gateway transfer progress.
 * @details
 * Responsibilities: Reduce ordered trace events into foreground labels and retained operation rows.
 * Boundaries: Presentation cannot authorize, schedule or establish execution completion.
 * Lifecycle: Live and replayed events share a reducer; late progress cannot reopen terminal work.
 * State: Per-view maps retain invocation identity; no separate transfer cards or browser authority.
 * Security: Bounded labels use text content; progress contains metadata, never file bytes.
 * Collaborators: capability_presentation.py supplies target labels; native transfer checkpoints emit
 * progress; desktop and mobile consumers reuse this projection.
 * Public surface: SMTORunActivity exposes creation, reduction, resolution and rendering.
 * Compatibility: Existing one-Gateway labels and event ordering remain unchanged.
 * @see src/agent_runtime/observability/capability_presentation.py
 */
(() => {
  "use strict";
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted", "partial"]);
  const labels = {
    awaiting_confirmation: "Waiting for approval…",
    awaiting_resource_reconciliation: "Waiting for resource recovery decision…",
    awaiting_clarification: "Waiting for clarification…", waiting_user: "Waiting for user…",
    waiting_event: "Waiting for event…", waiting_job: "Waiting for job…", paused: "Paused",
    paused_budget: "Paused · budget reached", blocked: "Blocked…", partial: "Partial · resumable",
    completed: "Completed", answered: "Completed", failed: "Failed", cancelled: "Stopped", interrupted: "Interrupted",
  };
  const clean = (value, limit = 100) => typeof value === "string"
    ? value.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g, " ").slice(0, limit) : "";
  function taskContractRecoveryNotice(detail, limit) {
    let notice = "Retrying task contract automatically";
    if (Number.isSafeInteger(limit) && limit > 0) notice += ` with ${limit.toLocaleString("en-US")} tokens`;
    const index = detail.auto_retry_index, retries = detail.configured_auto_retries;
    if (Number.isSafeInteger(index) && index > 0 && Number.isSafeInteger(retries) && retries >= index) {
      notice += ` · retry ${index} of ${retries}`;
    }
    return notice;
  }
  const create = (streamActivity = window.SMTOStreamActivity.create()) => ({status: "pending", sequence: 0, operations: new Map(), activeId: "",
    streamActivity,
    operationOrder: 0, runtimeStep: null,
    taskContract: false,
    inference: false, modelCallId: "", streamAt: 0, answerStreaming: false,
    generationNotice: "", generationRecovery: false,
    fastPathUsed: false, fastPathActive: false, fastPathPerformance: null,
    stopping: false, pausing: false, resuming: false, waitSkill: ""});
  const streamFreshnessMs = 3000;
  const clearStream = state => {
    state.streamAt = 0; state.modelCallId = ""; state.answerStreaming = false;
  };
  // Consume the server projection. Legacy traces use this one fallback everywhere.
  const userStatus = (trace = {}, native = null) => native?.user_visible_status || native?.status
    || trace?.user_visible_status || trace?.outcome || trace?.native_profile?.final_status
    || trace?.response_metrics?.native_outcome || trace?.effective_status || trace?.status || "pending";
  function presentation(value = {}) {
    return {running_label: clean(value.running_label, 600) || "Running capability",
      completed_label: clean(value.completed_label, 600) || "Used capability",
      failed_label: clean(value.failed_label, 600) || "Capability failed",
      skill_label: clean(value.skill_label, 80), detail: clean(value.detail),
      capability_id: clean(value.capability_id, 100), icon_kind: clean(value.icon_kind, 24),
      compact_running_label: clean(value.compact_running_label, 240),
      compact_completed_label: clean(value.compact_completed_label, 240),
      compact_failed_label: clean(value.compact_failed_label, 240),
      compact_context: clean(value.compact_context, 160), context_detail: clean(value.context_detail, 240),
      trace_detail: clean(value.trace_detail || value.detail, 240), privileged: value.privileged === true};
  }
  // The invocation, native tool and command streams describe the same operation.
  // Preserve richer invocation metadata when a later lifecycle event is sparse.
  function operationPresentation(detail, previous, type) {
    const supplied = detail.presentation || {};
    const capability = clean(detail.capability_id || supplied.capability_id || previous?.capability_id
      || detail.tool_name, 100).replaceAll("__", ".");
    const python = ["python_action", "python_code"].includes(detail.kind);
    const shell = !capability && type.startsWith("execution.command.") && !python;
    return presentation({
      running_label: python ? "Running Python" : shell ? "Running Shell" : capability ? `Running ${capability}` : "Running action",
      completed_label: python ? "Ran Python" : shell ? "Ran Shell" : capability ? `Used ${capability}` : "Action completed",
      skill_label: python ? "Python" : shell ? "Shell" : "",
      icon_kind: python ? "code" : shell ? "shell" : "runtime",
      ...previous, ...supplied,
      capability_id: capability,
      privileged: detail.privileged === true || supplied.privileged === true || previous?.privileged === true,
    });
  }
  function activeOperations(state) {
    const active = [...state.operations.values()].filter(operation => operation.foreground
      && !operation.terminal && operation.status === "running" && !operation.detached);
    const parents = new Set(active.map(operation => operation.parentId).filter(Boolean));
    return active.filter(operation => !parents.has(operation.id)).sort((a, b) => b.order - a.order);
  }
  function clearForeground(state) {
    for (const operation of state.operations.values()) operation.foreground = false;
    state.runtimeStep = null;
  }
  function setStatus(state, status, {cancel_requested = false, pause_requested, oauth_authorization_request,
    authoritative = false, trace_event_id, stop, pending_wait, wait_timing, wait_control, timing} = {}) {
    if (!state || !status) return;
    if (stop !== undefined) state.stop = stop;
    if (authoritative && Number.isFinite(trace_event_id) && trace_event_id < state.sequence) return;
    if (oauth_authorization_request !== undefined) state.oauthAuthorization = oauth_authorization_request?.kind === "oauth";
    // Unversioned legacy signals cannot reopen a completed request or replace
    // an explicit wait. Fresh server projections can advance the same run.
    if (!authoritative && terminal.has(state.status) && !terminal.has(status)) return;
    state.stopping = terminal.has(status) ? false : state.stopping || Boolean(cancel_requested);
    if (terminal.has(status) || status === "paused" || state.stopping) state.pausing = false;
    else if (pause_requested !== undefined) state.pausing = Boolean(pause_requested);
    if (!authoritative && status === "running" && labels[state.status] && !terminal.has(state.status)) return;
    if (wait_timing !== undefined) state.waitTiming = wait_timing;
    else if (pending_wait !== undefined) state.waitTiming = pending_wait ? {
      kind: pending_wait.kind, started_at: pending_wait.created_at, due_at: pending_wait.wake_at,
      wake_requested: pending_wait.wake_requested,
    } : null;
    if (wait_control !== undefined) state.waitControl = wait_control;
    if (status !== "waiting_event") state.waitControl = null;
    if (!["waiting_event", "paused", "paused_budget"].includes(status)) state.waitTiming = null;
    const serverNow = Date.parse(timing?.server_now);
    if (Number.isFinite(serverNow)) window.SMTOStreamActivity.syncClock(state.streamActivity, serverNow);
    state.resuming = false;
    state.status = status;
    if (terminal.has(status)) { state.fastPathActive = false; clearForeground(state); }
    state.stopping = terminal.has(status) ? false : state.stopping || Boolean(cancel_requested);
    if (terminal.has(status) || labels[status]) { state.activeId = ""; state.inference = false; }
    if (!state.inference || state.stopping) clearStream(state);
  }
  function operationStatus(detail) {
    if (detail.controller_operation && ["success", "completed"].includes(detail.status)) return "completed";
    if (["waiting_user", "waiting_approval", "waiting_event", "awaiting_confirmation"].includes(detail.status)) return detail.status;
    if (detail.status === "waiting_job") return "waiting_job";
    if (["queued", "starting", "running"].includes(detail.job_state)) return detail.job_state;
    if (detail.status === "cancelled" || detail.process_state === "cancelled") return "cancelled";
    if (detail.effect_unknown || detail.error_kind === "unknown_effect" || ["outcome_unknown", "unknown"].includes(detail.status) || detail.process_state === "outcome_unknown") return "unknown";
    if (detail.error_kind === "gateway_job_control_unavailable") return "failed";
    if (detail.executed === false || ["confirmation_required", "skipped", "blocked", "not_executed"].includes(detail.status)) return "not_executed";
    if (detail.process_state === "timed_out" || detail.error_kind === "timeout") return "timed_out";
    if (["error", "failed"].includes(detail.status)) return "failed";
    return "completed";
  }
  function reduce(state, event) {
    if (!state) return false;
    event = window.SMTOActivityPresentation?.operationEvent(event) || event;
    const type = String(event.event_type || ""), detail = event.detail || {};
    const seq = Number(event.id || 0);
    const key = String(detail.operation_id || detail.action_id || detail.execution_id || "");
    const existing = state.operations.get(key);
    const stream = type.startsWith("execution.command.");
    // stdout is constant-time and inert except for the first proven elevation.
    if (stream && ["stdout", "stderr"].includes(type.split(".").at(-1))) {
      if (existing && !existing.terminal && detail.elevated === true && !existing.elevated) {
        existing.elevated = true; return true;
      }
      return false;
    }
    if (seq && seq <= state.sequence) return false;
    if (seq) state.sequence = seq;
    if (existing?.terminal && (["invocation.started", "tool.started", "execution.command.started"].includes(type)
      || (event.source_event_type || type).startsWith("tool."))) return false;
    const previousExecution = state.executionStatus;
    if (window.SMTOConversationSnapshot) state.executionStatus = window.SMTOConversationSnapshot.executionEvent(previousExecution, event);
    if (type.startsWith("activity.supervision.")) {
      state.executionStatus = {...(previousExecution || {}), detail: event.title,
        supervision: {...(previousExecution?.supervision || {}), health_state: detail.health_state,
          last_observed_at: detail.observed_at, last_progress_at: detail.last_progress_at}};
      return true;
    }
    if (type.startsWith("capability_")) {
      state.capabilityEvents ||= new Map();
      state.capabilityEvents.set(detail.capability_event_id || `${type}:${seq}`, {
        title: clean(event.title, 240),
        skills: (detail.requested_skill_ids || detail.selected_skill_ids || []).map(s => clean(s, 128)),
        reason: clean(detail.reason, 100),
      });
      if (!terminal.has(state.status) && !state.stopping && type !== "capability_manifest.available") {
        const label = clean(detail.label || event.title, 240) || ({
          "capability_selection.started": "Selecting capabilities…",
          "capability_selection.completed": "Capabilities selected",
          "capability_selection.failed": "Capability selection failed",
          "capability_selection.degraded": "Using permitted capabilities",
        }[type]) || type.replaceAll("_", " ").replaceAll(".", " · ");
        state.runtimeStep = {label, detail: "", kind: "runtime", iconKind: "user"};
      }
      return true;
    }
    if (type === "agent_check.observed") {
      state.checkObservations ||= new Map();
      state.checkObservations.set(detail.agent_check_observation_id || `${type}:${seq}`, {
        guard: clean(detail.guard_id, 100), label: clean(detail.guard_label, 160),
        manualDocId: clean(detail.manual_doc_id, 100),
      });
      return true;
    }
    // Historical receipts remain valid across phase/call boundaries. Status still
    // rejects stale calls below; receipt timestamps decide where graph data belongs.
    if (type === "llm.response.progress" && detail.receiving === true && detail.call_id) {
      window.SMTOStreamActivity.receive(state.streamActivity, detail.stream_activity,
        JSON.stringify([event.request_id || "", detail.call_id]));
    }
    if (type.startsWith("request.preflight_") || type.startsWith("llm.scheduler_wait.")) {
      if (terminal.has(state.status) || state.stopping) return false;
      state.preflight = state.preflight || new Set();
      if (type.endsWith("started")) state.runtimeStep = null;
      if (type === "request.preflight_model_started") state.preflight.add("model");
      if (type === "request.preflight_gateway_started") state.preflight.add("gateway");
      if (type === "request.preflight_model_completed") state.preflight.delete("model");
      if (type === "request.preflight_gateway_completed") state.preflight.delete("gateway");
      if (["request.preflight_completed", "request.preflight_failed"].includes(type)) state.preflight.clear();
      if (type === "llm.scheduler_wait.started") {
        state.schedulerWaiting = true;
        state.schedulerQueue = detail.queue === "agent_turn" ? "controller" : "model";
      }
      if (type === "llm.scheduler_wait.completed") state.schedulerWaiting = false;
      return true;
    }
    if (["request.running", "run.resumed", "model.started", "llm.request", "task_contract.started",
      "invocation.started", "tool.started", "execution.command.started"].includes(type)) state.runtimeStep = null;
    if (["llm.request", "tool.started"].includes(type)) {
      state.schedulerWaiting = false;
      state.preflight?.clear();
    }
    if (type === "run.stop.graceful_started") {
      state.stop = detail; state.stopping = true; state.inference = false; clearStream(state);
    } else if (type === "run.stop.completed") {
      state.stop = detail; setStatus(state, "cancelled");
    } else if (type === "runtime.fault_blocked") {
      state.runtimeFault = true;
      state.inference = false;
      state.generationNotice = "";
      state.generationRecovery = false;
      setStatus(state, "failed");
    } else if (["runtime.generation_changed", "runtime.recovery_changed"].includes(type)) {
      state.runtimeFault = false;
    } else if (type === "execution_cache.hit") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.fastPathUsed = true; state.fastPathActive = true; state.fastPathPerformance = null;
    } else if (type === "execution_cache.focus_released") {
      state.fastPathActive = false; state.fastPathPerformance = null;
    } else if (type === "execution_cache.performance") {
      state.fastPathPerformance = {comparable: detail.comparable === true,
        improved: detail.improved === true, speedup_percent: detail.speedup_percent};
    } else if (type === "request.running") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.status = "running"; state.inference = false; state.activeId = "";
      clearForeground(state);
      clearStream(state);
      state.waitSkill = "";
    } else if (type === "run.pause_requested") {
      if (!terminal.has(state.status) && !state.stopping) state.pausing = true;
    } else if (type === "run.paused") {
      setStatus(state, "paused");
    } else if (type === "run.resumed") {
      state.status = detail.resume_status || "running"; state.pausing = false; state.resuming = false;
      state.inference = false; state.activeId = "";
      clearForeground(state);
      clearStream(state);
    } else if (["request.completed", "request.suspended", "request.failed", "request.cancelled", "request.interrupted"].includes(type)) {
      const status = detail.outcome || event.parsed_output?.outcome || detail.status || type.split(".")[1];
      setStatus(state, status);
    } else if (type === "task_contract.started") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.taskContract = true; state.inference = false; state.activeId = "";
      state.generationIcon = "file";
      state.generationNotice = detail.auto_retry_index
        ? taskContractRecoveryNotice(detail, detail.effective_max_tokens)
        : "Generating task contract"; clearStream(state);
    } else if (type === "task_contract.recovery_started") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.taskContract = true;
      state.generationNotice = taskContractRecoveryNotice(detail, detail.next_max_tokens);
    } else if (["task_contract.completed", "task_contract.failed", "task_contract.clarification_required"].includes(type)) {
      state.taskContract = false;
      state.generationNotice = type === "task_contract.failed"
        ? (detail.auto_recovery && detail.auto_retry_index === detail.configured_auto_retries
          && detail.transport_started !== false
          && !["cancelled", "stale_source_revision", "interrupted_compilation", "recovery_deadline"].includes(detail.reason)
          ? "Task contract automatic recovery exhausted" : "Task contract generation failed")
        : type === "task_contract.clarification_required" ? "Task contract needs clarification" : "Task contract generated";
    } else if (type === "model.started") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.taskContract = false;
      state.generationIcon = "thinking";
      state.status = "running"; state.inference = true; state.activeId = ""; state.waitSkill = "";
      clearStream(state);
      if (!state.generationRecovery) state.generationNotice = "";
      if (["continuation", "restart"].includes(detail.recovery_mode)) {
        state.generationRecovery = true;
        state.generationNotice = detail.recovery_mode === "continuation"
          ? "Continuing the unfinished response…"
          : "Continuation unavailable; retrying the pending decision…";
      }
    } else if (type === "model.thinking_target_exceeded") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.generationNotice = "Thinking target exceeded; continuing the same response.";
    } else if (type === "model.budget_increased") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.generationRecovery = true;
      state.generationNotice = `Increased ${detail.budget === "thinking" ? `thinking to ${detail.effective_thinking_percent}%` : `output to ${Number(detail.effective_output_tokens).toLocaleString()} tokens`}; ${detail.increases_remaining} increases remaining.`;
      if (detail.recovery_mode === "live_extension") state.generationNotice += " Continuing the same response.";
    } else if (["model.generation_recovery", "model.continuation_unavailable"].includes(type)) {
      if (terminal.has(state.status) || state.stopping) return false;
      state.generationRecovery = true;
      state.generationNotice = detail.recovery_mode === "continuation"
        ? "Continuing the unfinished response…"
        : "Continuation unavailable; retrying the pending decision…";
    } else if (type === "model.budget_growth_exhausted") {
      state.generationNotice = "Automatic budget increase unavailable; using configured recovery.";
    } else if (type === "model.budget_growth_reset") {
      state.generationRecovery = false;
      state.generationNotice = `Response accepted; ${detail.increases_remaining} automatic increases available.`;
    } else if (type === "model.recovery_started") {
      if (terminal.has(state.status) || state.stopping) return false;
      state.generationRecovery = true;
      state.generationNotice = detail.prevent_brain_freeze || detail.recovery_mode === "thinking_off"
        ? "Recovery attempt 1 of 1 · thinking off…"
        : detail.retry_limit === 1 ? (detail.recovery_mode === "thinking_override"
          ? "Recovery attempt 1 of 1 · configured thinking override…" : "Recovery attempt 1 of 1 · normal model settings…")
        : `Recovery attempt ${detail.recovery_attempt || 1}…`;
    } else if (type === "model.brain_freeze_recovered") {
      state.generationRecovery = false;
      state.generationNotice = "Recovery succeeded · normal thinking restored";
    } else if (["model.recovery_exhausted", "model.brain_freeze_exhausted"].includes(type)) {
      state.generationNotice = type === "model.brain_freeze_exhausted"
        ? "Thinking-off retry failed · nothing executed" : "Agent response failed · nothing executed";
      state.generationRecovery = false;
      setStatus(state, "partial");
    } else if (type === "llm.request" && (detail.phase || event.stage) === "native_decision") {
      if (state.stopping || terminal.has(state.status) || labels[state.status]) return false;
      state.inference = true;
      if (!state.generationRecovery) state.generationNotice = "";
      state.modelCallId = detail.call_id || ""; state.streamAt = 0; state.answerStreaming = false;
    } else if (type === "llm.response.delta" && detail.user_facing_stream === true) {
      if (!state.inference || state.stopping || terminal.has(state.status)
          || (state.modelCallId && state.modelCallId !== detail.call_id)) return false;
      state.modelCallId = detail.call_id || state.modelCallId;
      state.answerStreaming = detail.invalidated !== true && Boolean(detail.user_facing_text);
    } else if (type === "llm.response.progress") {
      if (!state.inference || state.stopping || terminal.has(state.status)
          || detail.receiving !== true || !detail.call_id
          || (state.modelCallId && state.modelCallId !== detail.call_id)) return false;
      state.modelCallId = detail.call_id;
      // Replayed events retain their age; reconnect does not manufacture receipt.
      const receivedNow = window.SMTOStreamActivity.now(state.streamActivity);
      state.streamAt = Number.isFinite(detail.stream_activity?.last_receipt_ms)
        ? Math.min(receivedNow, detail.stream_activity.last_receipt_ms)
        : event.timestamp ? Math.min(receivedNow, Date.parse(event.timestamp) || 0) : receivedNow;
    } else if (["llm.response", "llm.error", "llm.cancelled"].includes(type)) {
      if (state.modelCallId && detail.call_id !== state.modelCallId) return false;
      if (detail.call_id !== state.modelCallId && event.stage !== "native_decision") return false;
      state.inference = false; clearStream(state);
    } else if (["model.usage", "model.rejected"].includes(type)) {
      state.inference = false; clearStream(state);
      state.generationRecovery = false;
      state.generationNotice = type === "model.rejected"
        ? detail.error_kind === "model_generation_repetitive"
          ? "Reasoning repetition detected · nothing from this response executed"
          : detail.error_kind === "model_generation_stalled_no_action" ? "Generation inactivity timeout · response stopped"
          : detail.error_kind === "model_generation_startup_timeout" ? "Generation startup timeout · no generation observed"
          : detail.error_kind === "model_recovery_deadline_exceeded" ? "Configured recovery deadline reached"
          : "Agent response rejected · nothing executed" : "";
    } else if (type === "tool.validation_rejected") {
      if (existing) { existing.foreground = false; existing.terminal = true; existing.status = "not_executed"; }
      state.generationIcon = window.SMTOActionIcons?.resolve(existing?.presentation || detail) || "runtime";
      state.inference = false; clearStream(state);
      state.generationRecovery = false;
      state.generationNotice = "Tool call rejected · nothing executed";
    } else if (window.SMTOProseActivity?.researchNotice(event)) {
      state.generationIcon = "globe";
      state.inference = false; clearStream(state);
      state.generationRecovery = false;
      state.generationNotice = window.SMTOProseActivity.researchNotice(event).title;
    } else if (window.SMTOProseActivity?.policyRejection(event)) {
      const rejection = window.SMTOProseActivity.policyRejection(event);
      if (existing) { existing.foreground = false; existing.terminal = true; existing.status = detail.executed === false ? "not_executed" : "failed"; }
      state.generationIcon = window.SMTOActionIcons?.resolve(existing?.presentation || detail) || "runtime";
      state.inference = false; clearStream(state);
      state.generationRecovery = false;
      state.generationNotice = rejection.title + (rejection.prevented ? " · not executed" : "");
    } else if (type === "invocation.queued") {
      if (!key || existing?.terminal || existing?.foreground) return false;
      const operation = existing || {id: key, terminal: false, foreground: false};
      operation.presentation = operationPresentation(detail, operation.presentation, type);
      operation.status = detail.status || "queued";
      operation.parentId = detail.parallel_parent_id || detail.parent_operation_id || operation.parentId;
      state.operations.set(key, operation);
    } else if (["invocation.started", "tool.started"].includes(type) || (stream && type.endsWith(".started"))) {
      if (!key || existing?.terminal || terminal.has(state.status)) return false;
      const p = operationPresentation(detail, existing?.presentation, type);
      state.operations.set(key, existing || {id: key, status: "running", terminal: false, elevated: false});
      const active = state.operations.get(key);
      active.presentation = p;
      if (!active.foreground) active.order = ++state.operationOrder;
      active.foreground = true;
      active.detached ||= detail.terminal_detached === true || detail.detached === true;
      active.parentId = detail.parent_operation_id || detail.parallel_parent_id || detail.sequence_operation_id || active.parentId;
      if (["queued", "starting"].includes(detail.job_state)) active.status = detail.job_state;
      else if (detail.job_state === "running" || type === "execution.command.started" || type === "invocation.started") active.status = "running";
      if (typeof detail.command === "string") active.command = clean(detail.command, 600);
      state.activeId = key; state.inference = false;
      state.generationNotice = "";
      clearStream(state);
    } else if (type === "activity.started") {
      // Durable scheduling intent precedes dispatch. Retain correlation only;
      // it must not claim that an unadmitted operation is executing.
      state.operationParents ||= new Map();
      if (key && detail.parallel_parent_id) state.operationParents.set(key, detail.parallel_parent_id);
      if (existing && detail.parallel_parent_id) existing.parentId = detail.parallel_parent_id;
    } else if (type === "sequence.step_started") {
      state.operationParents ||= new Map();
      if (key && detail.child_operation_id) state.operationParents.set(String(detail.child_operation_id), key);
    } else if (["context.working_set_pruned", "context.manual_compacted"].includes(type)) {
      if (!terminal.has(state.status) && !state.stopping) state.runtimeStep = {
        label: clean(event.title, 240) || "Context compacted", detail: "", kind: "runtime", iconKind: "context"};
    } else if (type === "transfer.progress") {
      if (!existing || existing.terminal || terminal.has(state.status)) return false;
      const percent = Number.isFinite(detail.percent) ? Math.max(0, Math.min(100, detail.percent)) : null;
      existing.transferProgress = [clean(detail.source_label, 240) + " → " + clean(detail.destination_label, 240),
        percent === null ? "" : `${percent}%`,
        detail.transfer_state === "committing" ? "Verifying" : ""].filter(Boolean).join(" · ");
    } else if (type === "observation.completed") {
      if (!existing || detail.executed !== true || detail.fresh_observation !== true) return false;
      existing.freshObservation = true;
      existing.observationUnchanged = detail.unchanged === true;
    } else if (type === "operation.redundant") {
      if (!key) return false;
      const operation = existing || {id: key, presentation: presentation(detail.presentation),
        status: "not_executed", terminal: true, executed: false};
      operation.duplicateMutation = detail.effect_class === "write";
      operation.duplicateOperation = true;
      operation.foreground = false; operation.terminal = true; operation.status = "not_executed";
      state.operations.set(key, operation);
    } else if (["invocation.completed", "tool.completed", "tool.failed", "tool.cancelled"].includes(type)
      || (stream && /\.(completed|cancelled|error)$/.test(type))) {
      if (!key) return false;
      const operation = existing || {id: key, elevated: false};
      operation.presentation = operationPresentation(detail, operation.presentation, type);
      // The final adapter receipt can refine command-stream truth; older starts cannot.
      const nextStatus = operationStatus({...detail,
        status: type.endsWith(".cancelled") ? "cancelled" : /\.(error|failed)$/.test(type) ? "error" : detail.status
          || (operation.status === "failed" ? "error" : undefined)});
      operation.status = event.source_event_type?.startsWith("activity.") && operation.status === "failed" && nextStatus === "completed" ? "failed"
        : ["cancelled", "timed_out"].includes(operation.status) && !["timed_out", "unknown"].includes(nextStatus)
        ? operation.status : nextStatus;
      operation.terminal = true; operation.elevated ||= detail.elevated === true;
      operation.foreground = false;
      if (typeof detail.executed === "boolean") operation.executed = detail.executed;
      if (detail.status) operation.resultStatus = detail.status;
      if (Number.isInteger(detail.exit_code)) operation.exitCode = detail.exit_code;
      operation.errorKind = clean(detail.error_kind, 80);
      operation.resourceBlockerLabel = clean(detail.resource_blocker_label, 100);
      operation.cancellationSource = detail.cancellation_source || operation.cancellationSource;
      operation.effectiveTimeout = detail.effective_timeout_seconds || operation.effectiveTimeout;
      state.operations.set(key, operation);
      if (state.activeId === key) state.activeId = "";
      if (detail.run_status) {
        setStatus(state, detail.run_status, {cancel_requested: state.stopping});
        state.waitSkill = operation.presentation.skill_label;
      }
    } else if (stream && /\.(long_running|continued)$/.test(type)) {
      if (existing && !existing.terminal) existing.longRunningDecision = detail.long_running_user_decision || "pending";
    } else if (stream && type.endsWith(".terminal_input_required")) {
      setStatus(state, "waiting_user", {cancel_requested: state.stopping});
    } else if (stream && type.endsWith(".resource_wait")) {
      if (existing && !existing.terminal) {
        existing.status = "waiting_resource";
        existing.resourceWait = "Your command has not executed yet.";
      }
    } else if (stream && type.endsWith(".resource_admitted")) {
      if (existing && !existing.terminal) { existing.status = "running"; existing.resourceWait = ""; }
    } else return previousExecution !== state.executionStatus;
    const targetOperation = state.operations.get(key);
    if (targetOperation && state.operationParents?.has(key)) targetOperation.parentId = state.operationParents.get(key);
    if (targetOperation && detail.execution_target) targetOperation.executionTarget = detail.execution_target;
    if (targetOperation && detail.transport_gateway) targetOperation.transportGateway = detail.transport_gateway;
    return true;
  }
  function resolveStatus(state, now) {
    if (!state) return {label: "Ready", detail: "", kind: "idle"};
    if (state.resuming && !state.stopping) return {label: "Resuming…", detail: "", kind: "resuming"};
    if (terminal.has(state.status)) return {label: labels[state.status], detail: "", kind: "terminal"};
    if (state.runtimeFault) return {label: "Runtime", detail: "Blocked · server restart required", kind: "terminal"};
    if (state.stopping) return state.stop?.mode === "graceful"
      ? {label: window.SMTOStopMessages?.graceful || "Stopping gracefully…",
        detail: (window.SMTOStopMessages?.graceful_detail || "Current operation has up to {seconds}s to stop.")
          .replace("{seconds}", state.stop.grace_timeout), kind: "stopping"}
      : {label: "Stopping…", detail: "", kind: "stopping"};
    const suffix = state.pausing ? " · Pause requested" : "";
    if (labels[state.status]) return {
      label: state.status === "waiting_user" && state.oauthAuthorization
        ? "Waiting for OAuth authorization…" + suffix : labels[state.status] + suffix,
      detail: state.status === "awaiting_confirmation" ? state.waitSkill
        : state.status === "waiting_job" ? supervisionDetail(state.executionStatus, now) : "", kind: "waiting",
      ...(state.status === "waiting_event" ? waitDetail(state.waitTiming, now) : {})};
    const execution = state.executionStatus;
    // Run waits and admission remain authoritative. A receipt for one parallel
    // operation must not hide its still-running siblings.
    if (execution && (["waiting", "terminal"].includes(execution.kind)
      || ["outcome_unknown", "admitted"].includes(execution.state))) return execution;
    const active = activeOperations(state);
    const operation = active[0] || state.operations.get(state.activeId);
    if (operation?.foreground && !operation.terminal && !operation.detached) {
      if (operation.status === "waiting_resource") return {
        label: "Waiting for another operation to release this resource…" + suffix,
        detail: operation.resourceWait, kind: "waiting"};
      if (operation.status === "running") {
        const p = operation.presentation, label = p.compact_running_label || p.running_label;
        const context = p.detail && !label.includes(p.detail) ? p.detail : "";
        const observation = execution?.operation_id === operation.id ? execution : null;
        const detail = [operation.transferProgress || context || operation.command || "",
          supervisionDetail(observation, now) || (observation?.progress_state === "possibly_stalled" ? "Possibly stalled" : "")].filter(Boolean).join(" · ");
        return {label: label.replace(/…$/, "") + "…" + suffix, detail,
          tooltip: p.context_detail || p.trace_detail || operation.command || label,
          iconKind: window.SMTOActionIcons?.resolve(p) || p.icon_kind || "runtime",
          actionId: operation.id, activeCount: active.length,
          privileged: p.privileged, elevated: operation.elevated, kind: "capability"};
      }
    }
    if (state.pausing) return {label: "Pausing after current action…", detail: "", kind: "pausing"};
    if (state.schedulerWaiting) return {label: state.schedulerQueue === "controller"
      ? "Waiting for controller capacity…" : "Waiting for model capacity…", detail: "", kind: "waiting"};
    if (state.preflight?.size) return {
      label: state.preflight.size > 1 ? "Preparing…" : state.preflight.has("model") ? "Preparing model…" : "Validating target…",
      detail: "", kind: "preparing"};
    if (state.runtimeStep) return state.runtimeStep;
    if (state.generationNotice) return {
      label: state.generationNotice, detail: "", kind: "model_recovery", iconKind: state.generationIcon || "runtime"};
    if (state.inference && state.answerStreaming) return {
      label: "Generating…", detail: "", kind: "generating", receiving: false};
    if (execution && !state.inference) {
      const finished = state.operations.get(execution.operation_id);
      if (execution.state === "operation_completed" && finished?.terminal) return {
        label: traceHeading(finished), detail: "", kind: "runtime", actionId: finished.id,
        iconKind: window.SMTOActionIcons?.resolve(finished.presentation) || "runtime",
        tooltip: finished.presentation.context_detail || finished.presentation.trace_detail,
      };
      return execution;
    }
    const receiving = state.inference && state.streamAt > 0 && now - state.streamAt < streamFreshnessMs;
    return {label: state.inference ? "Thinking…"
      : state.status === "pending" ? "Preparing…" : "Working…",
      detail: "", kind: state.inference ? "thinking" : "preparing", receiving};
  }
  function resolve(state, now = window.SMTOStreamActivity.now(state?.streamActivity)) {
    const value = resolveStatus(state, now);
    return {actionId: null, activeCount: 0, ...value,
      iconKind: value.iconKind || window.SMTOActionIcons?.resolve({kind: value.kind}) || "runtime"};
  }
  // One adornment renderer for the trace, mobile trace and wavelet. Keep the
  // thinking node mounted so changing actions never resets the chosen animation.
  function renderStatus(root, value, label) {
    root.dataset.kind = value.kind;
    root.dataset.thinking = String(value.kind === "thinking");
    const host = root.querySelector(".activity-primary") || root;
    let icon = host.querySelector(":scope > .activity-status-icon");
    if (!icon) {
      icon = window.SMTOActionIcons.create(value.iconKind);
      icon.classList.add("activity-status-icon");
      host.insertBefore(icon, host.querySelector(".task-activity-copy, .activity-label"));
    }
    window.SMTOActionIcons.update(icon, value.iconKind);
    icon.hidden = ["thinking", "idle", "terminal"].includes(value.kind);
    root.dataset.statusIcon = String(!icon.hidden);
    if (label.textContent !== value.label) label.textContent = value.label;
    label.title = value.tooltip || value.label;
    let count = label.parentElement.querySelector(":scope > .activity-action-count");
    if (!count) {
      count = document.createElement("span"); count.className = "activity-action-count";
      label.after(count);
    }
    const text = value.activeCount > 1 ? `+${value.activeCount - 1} more` : "";
    if (count.textContent !== text) count.textContent = text;
    count.hidden = !text;
    count.title = text ? `${value.activeCount} actions running` : "";
    window.SMTOActivityUpdates?.update(label.parentElement, value);
  }
  function renderDetail(detail, value, {animateNumbers = false} = {}) {
    const text = value.detail || "";
    if (animateNumbers) window.SMTONumberOdometer.render(detail, text);
    else if (detail.textContent !== text) detail.textContent = text;
    detail.title = text ? value.tooltip || text : "";
    const countdown = Number.isFinite(value.waitRemaining);
    detail.toggleAttribute("data-wait-countdown", countdown);
    if (countdown) detail.style.setProperty("--wait-remaining", String(value.waitRemaining));
    else detail.style.removeProperty("--wait-remaining");
  }
  /** Format a persisted deadline against server time; zero never claims execution. */
  function waitDetail(wait, now) {
    if (!wait) return {};
    if (wait.wake_requested) return {detail: "Wake requested · waiting to resume"};
    /** Reject missing or malformed timestamps instead of displaying a fabricated deadline. */
    const validTime = value => typeof value === "number" && Number.isFinite(value) && value > 0;
    /** Keep sub-hour waits compact while retaining hours for longer waits. */
    const duration = seconds => {
      const hours = Math.floor(seconds / 3600), minutes = Math.floor(seconds % 3600 / 60);
      return [hours || null, String(minutes).padStart(2, "0"),
        String(seconds % 60).padStart(2, "0")].filter(value => value !== null).join(":");
    };
    if (wait.triggered) return {detail: "Triggered · waiting to resume"};
    const schedule = {paused: "Schedule paused", cancelled: "Schedule cancelled", completed: "Schedule completed",
      unavailable: "Schedule unavailable"}[wait.schedule_status];
    if (schedule) return {detail: schedule};
    if (validTime(wait.due_at)) {
      const seconds = Math.max(0, Math.ceil(wait.due_at - now / 1000));
      // Use the same rounded seconds as the clock and the persisted full wait,
      // so refreshes and schedule edits cannot restart the circular countdown.
      const total = validTime(wait.started_at) && wait.due_at > wait.started_at
        ? Math.ceil(wait.due_at - wait.started_at) : null;
      return {detail: seconds ? `${wait.kind === "schedule" ? "Next trigger" : "Resumes"} in ${duration(seconds)}`
        : "Due now · waiting to resume", tooltip: `Scheduled for ${new Date(wait.due_at * 1000).toLocaleString()}`,
        // The deadline identifies this wait; ticking text is not a new status.
        ...(seconds ? {detailTransitionKey: ["wait", wait.kind, wait.started_at ?? null, wait.due_at]} : {}),
        waitRemaining: total ? Math.min(1, seconds / total) : null};
    }
    return validTime(wait.started_at)
      ? {detail: `Waiting for ${duration(Math.max(0, Math.floor(now / 1000 - wait.started_at)))}`,
        detailTransitionKey: ["wait", wait.kind, wait.started_at, null],
        tooltip: "The event trigger time is unknown."} : {};
  }
  function supervisionDetail(execution, now) {
    const supervision = execution?.supervision;
    if (!supervision) return "";
    const checked = supervision.last_observed_at;
    const age = checked ? Math.max(0, Math.floor(now / 1000 - checked)) : null;
    return [execution.detail, supervision.observation_in_flight ? "Inspecting…"
      : age === null ? "Awaiting first check" : `Last checked ${age}s ago`].filter(Boolean).join(" · ");
  }
  function restoreOperations(state, events) {
    // Lazy history needs operation rows even when its foreground state came
    // from a summary. Replaying older events must not rewind live execution.
    const restored = create(state.streamActivity);
    for (const event of events) reduce(restored, event);
    for (const [key, operation] of restored.operations) {
      if (!state.operations.has(key)) state.operations.set(key, {...operation, foreground: false});
    }
  }
  function notExecutedLabel(operation) {
    if (operation.status === "cancelled") return "cancelled";
    switch (operation.errorKind) {
      case "provider_unavailable": return "provider unavailable";
      case "gateway_identity_changed": return "TLS identity mismatch";
      case "gateway_tls_invalid": return "TLS verification failed";
      case "privilege_transport_insecure":
      case "gateway_unreachable": return "Gateway unreachable";
      case "http_tls_verification_failed": return "TLS verification failed";
      case "http_tls_handshake_failed": return "TLS handshake failed";
      case "http_auth_response_invalid": return "invalid login response";
      case "http_auth_transport_error": return "authentication transport failed";
      case "http_auth_timeout": return "authentication timeout";
      case "http_transport_error": return "network transport failed";
      case "http_auth_failed": return "authentication failed";
      case "http_auth_endpoint_not_found": return "authentication endpoint not found";
      case "http_auth_method_not_allowed": return "authentication method not allowed";
      case "http_auth_request_rejected": return "authentication request rejected";
      case "http_auth_server_error": return "authentication server error";
      case "http_auth_http_error": return "unexpected authentication HTTP status";
      case "http_session_mapping_required": return "session extraction required";
      case "http_timeout": return "network timeout";
      case "http_connection_refused": return "connection refused";
      case "http_dns_failed": return "DNS lookup failed";
      case "http_feature_unsupported": return "required feature unsupported";
      case "http_connect_required": return "connection setup required";
      case "http_credentials_missing": return "credentials required";
      case "http_credentials_rejected": return "credentials rejected";
      case "http_profile_not_found": return "connection not found";
      case "http_profile_ambiguous": return "connection ambiguous";
      case "http_connection_not_found": return "connection unavailable";
      case "http_connection_scope_mismatch": return "connection scope mismatch";
      case "http_connection_origin_mismatch": return "connection origin mismatch";
      case "http_unavailable": return "capability unavailable";
      case "http_gateway_unavailable": return "gateway unavailable";
      case "http_profile_unavailable": return "profile unavailable";
      case "privilege_unavailable": return "privilege unavailable";
      case "privileged_environment_unsupported": return "privileged environment unsupported";
      case "runtime_policy_denied": return "runtime policy denied";
      case "unsafe_authorization_required": return "unsafe confirmation required";
      case "unsafe_authorization_invalid": return "unsafe authorization expired";
      case "denied": case "blocked": case "permission_denied":
      case "privilege_not_permitted": return "permission denied";
      case "approval_required": return "approval required";
      case "job_conflict": return "background job conflict";
      case "job_conflict_unresolved":
      case "external_resource_blocker":
      case "resource_reconciliation_required": return operation.resourceBlockerLabel || "execution prevented";
      case "sequence_ineligible": return "sequence ineligible";
      case "gateway_job_runtime_unavailable": return "Gateway job runtime unavailable";
      case "gateway_job_control_unavailable": return "Gateway job control unavailable";
      case "job_launch_failed": return "job failed to start";
      case "invalid_working_directory": return "invalid working directory";
      case "credential_required": return "credential required";
      case "credential_rejected": return "credential rejected";
      case "cancelled": return "cancelled";
      default: return operation.executed === true ? "" : "execution prevented";
    }
  }
  function traceHeading(operation) {
    const p = operation.presentation;
    const target = operation.executionTarget;
    const location = target?.label ? clean(target.label, 253)
      + (target.kind === "ssh_remote" ? ` via ${clean(operation.transportGateway?.label || "Gateway", 253)}` : "") : "";
    const notExecuted = operation.status === "not_executed"
      || (operation.status === "cancelled" && operation.executed === false);
    let label = notExecuted ? (operation.duplicateMutation ? "Duplicate mutation prevented"
      : operation.duplicateOperation ? "Duplicate operation prevented" : "Not run") : {running: p.running_label,
      completed: operation.resultStatus === "completed" ? `${p.skill_label || "Process"} completed` : p.completed_label,
      failed: p.failed_label, timed_out: `${p.skill_label || "Shell"} timed out · process terminated`,
      waiting_job: "Waiting for job · Agent suspended",
      waiting_user: "Waiting for input", waiting_approval: "Waiting for approval",
      awaiting_confirmation: "Waiting for approval", waiting_event: "Waiting for event",
      waiting_resource: "Waiting for resource · Not started",
      queued: "Queued", starting: "Starting job",
      unknown: "Outcome unknown", cancelled: operation.cancellationSource === "user" ? "Shell terminated by user"
        : operation.cancellationSource === "run_cancelled" ? "Stopped · run cancelled" : "Stopped"}[operation.status] || p.failed_label;
    // New projections carry safe contextual sentences. Legacy and Shell headings stay intact.
    if (p.compact_running_label && !p.capability_id.startsWith("shell.")) {
      if (notExecuted) label = [label, p.compact_running_label].filter(Boolean).join(" · ");
      else label = {running: p.compact_running_label, completed: p.compact_completed_label,
        failed: p.compact_failed_label,
        timed_out: `${p.compact_running_label} · timed out · process terminated`,
        unknown: `${p.compact_running_label} · Outcome unknown`,
        cancelled: `${p.compact_running_label} · ${operation.cancellationSource === "run_cancelled" ? "Stopped · run cancelled" : "Stopped"}`,
      }[operation.status] || [label, p.compact_context].filter(Boolean).join(" · ");
    }
    const reason = notExecuted || operation.errorKind === "gateway_job_control_unavailable" || (p.skill_label === "HTTP" && operation.status === "failed" && operation.errorKind?.startsWith("http_")) ? notExecutedLabel(operation) : "";
    return [label, location && !label.includes(location) ? location : "", Number.isInteger(operation.exitCode) && operation.status !== "timed_out"
      && !(operation.status === "cancelled" && operation.cancellationSource) ? `exit ${operation.exitCode}` : "",
      operation.status === "running" && operation.longRunningDecision === "continue" ? "user chose to continue" : "",
      operation.freshObservation ? "Fresh observation" : "",
      operation.observationUnchanged ? "Result unchanged · No progress" : "",
      reason, operation.elevated ? "Elevated" : p.privileged ? "Privileged" : ""].filter(Boolean).join(" · ");
  }
  function render(root, live, state, {freshness = "current", connection = "connected", showReconciliation = true} = {}) {
    const activity = resolve(state);
    // Connection freshness shares the waveform's existing status line. Keep the
    // resolved execution state intact so task headings and controls retain it.
    const freshnessLabel = freshness === "reconciling" && showReconciliation ? "Reconciling task status…"
      : freshness === "stale" ? connection === "connected"
        ? "Task status may be stale" : "Reconnecting — task status may be stale" : "";
    const label = activity.label;
    // Status changes never unmount or collapse the page's rolling timeline.
    root.hidden = false;
    root.dataset.kind = activity.kind;
    root.dataset.freshness = freshness;
    root.dataset.receiving = String(!freshnessLabel && activity.receiving === true);
    renderStatus(root, activity, root.querySelector(".activity-label"));
    let transport = root.querySelector(".activity-connection");
    if (!transport) {
      transport = document.createElement("span"); transport.className = "activity-connection";
      transport.setAttribute("role", "status");
      (root.querySelector(".activity-primary") || root).append(transport);
    }
    transport.textContent = freshnessLabel; transport.hidden = !freshnessLabel;
    const detail = root.querySelector(".activity-detail");
    renderDetail(detail, activity);
    const fastPath = root.querySelector(".activity-fast-path");
    if (fastPath) fastPath.hidden = !state?.fastPathActive || terminal.has(state?.status);
    root.querySelector(".activity-lock").toggleAttribute("hidden", !activity.privileged && !activity.elevated);
    root.querySelector(".activity-elevation").textContent = activity.elevated ? "Elevated" : activity.privileged ? "Privileged" : "";
    root.title = [label, freshnessLabel ? `Last observed: ${activity.label}` : "",
      activity.elevated ? "Elevated" : activity.privileged ? "Privileged requested" : "",
      activity.tooltip || activity.detail].filter(Boolean).join(" · ");
    const announcement = label + (activity.activeCount > 1 ? ` +${activity.activeCount - 1} more` : "")
      + (activity.elevated ? " Elevated" : activity.privileged ? " Privileged requested" : "");
    if (live.textContent !== announcement) live.textContent = announcement;
    return activity;
  }
  window.SMTORunActivity = {create, reduce, setStatus, userStatus, resolve, presentation, traceHeading, restoreOperations, render, renderStatus, renderDetail, terminal, streamFreshnessMs};
})();
