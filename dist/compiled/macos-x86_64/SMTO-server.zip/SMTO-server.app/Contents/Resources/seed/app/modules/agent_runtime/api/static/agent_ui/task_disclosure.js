/* Browser-local task presentation shared by desktop and mobile. No execution authority. */
(() => {
  "use strict";
  if (window.SMTOTaskDisclosure) return;
  const prefix = "smto.agentUi.taskDisclosure.v1.";
  const cache = new Map(), controllers = new Set(), unavailable = new Set();
  let sequence = 0;
  const empty = () => ({version: 1, collapsed: false, activeOnly: false, overrides: Object.create(null)});
  function read(cid) {
    let value = cache.get(cid) || empty();
    if (!cid || unavailable.has(cid)) return value;
    try {
      const raw = cid && localStorage.getItem(prefix + cid);
      const saved = raw ? JSON.parse(raw) : null;
      value = empty();
      if (saved?.version === 1 && typeof saved.collapsed === "boolean"
          && saved.overrides && typeof saved.overrides === "object" && !Array.isArray(saved.overrides)) {
        value.collapsed = saved.collapsed;
        value.activeOnly = saved.activeOnly === true;
        for (const [key, collapsed] of Object.entries(saved.overrides))
          if (/^(task|request|submission):.+/.test(key) && typeof collapsed === "boolean") value.overrides[key] = collapsed;
      }
    } catch (_) { /* Keep this page's choices when browser storage is unavailable. */ }
    cache.set(cid, value);
    return value;
  }
  function save(cid, value) {
    cache.set(cid, value);
    if (cid) try { localStorage.setItem(prefix + cid, JSON.stringify(value)); unavailable.delete(cid); }
    catch (_) { unavailable.add(cid); }
  }
  function forget(cid, keys) {
    if (!cid) return;
    if (keys) {
      const value = read(cid);
      if (!keys.some(key => Object.hasOwn(value.overrides, key))) return;
      for (const key of keys) delete value.overrides[key];
      save(cid, value);
    } else {
      cache.delete(cid);
      try { localStorage.removeItem(prefix + cid); } catch (_) {}
    }
    for (const controller of controllers) controller.reload(cid);
  }
  const paths = {
    toggle: '<path d="m9 5 7 7-7 7"/>',
    collapse: '<path d="m6 3 6 6 6-6M6 21l6-6 6 6"/>',
    expand: '<path d="m6 9 6-6 6 6m-12 6 6 6 6-6"/>',
  };
  function button(kind, label) {
    const root = document.createElement("button"); root.type = "button";
    root.className = "task-disclosure-button";
    root.title = label; root.setAttribute("aria-label", label);
    root.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${paths[kind]}</svg>`;
    return root;
  }
  const labels = {pending: "Starting", queued: "Queued", running: "Running", resuming: "Resuming", completed: "Completed", answered: "Completed",
    failed: "Failed", cancelled: "Stopped", interrupted: "Interrupted", paused: "Paused", paused_budget: "Paused · budget reached",
    waiting_user: "Needs input", awaiting_clarification: "Needs input", awaiting_confirmation: "Needs approval",
    waiting_user_confirmation: "Needs approval", awaiting_resource_reconciliation: "Needs recovery decision",
    waiting_job: "Waiting for job", waiting_event: "Waiting for event", blocked: "Blocked", partial: "Partial · resumable"};
  function queryLabel(prompt, attachments = []) {
    if (prompt?.trim()) return prompt.trim();
    if (!Array.isArray(attachments)) attachments = [];
    if (attachments.length > 1) return `Files · ${attachments.length} attachments`;
    if (attachments.length === 1) {
      const file = attachments[0], name = file.filename || file.name || "";
      const image = /^image\//.test(file.mime_type || file.content_type || file.type || "")
        || /\.(png|jpe?g|gif|webp|heic|avif|svg)$/i.test(name);
      return `${image ? "Image" : "File"}${name ? ` · ${name}` : ""}`;
    }
    return "User prompt";
  }
  function anchorFor(root) {
    const group = root?.closest(".activity-group");
    return group?.dataset.taskCollapsed === "true"
      ? document.getElementById(group.dataset.disclosureAnchor) || group : root;
  }
  const isFiltered = root => Boolean(root?.closest('[data-run-filtered="true"]'));
  function create({content, viewport, toolbar, conversationId, getTurn, getTask = () => null,
    beforeToggle = () => {}, changed = () => {}, toggleNavigator = null}) {
    const groups = new WeakMap(), newSubmissions = new WeakSet(), previews = new Set();
    let cid, preferences = empty(), pending = false, rendering = false;
    function scope() {
      const next = conversationId() || "";
      if (cid !== next) { cid = next; preferences = read(cid); }
    }
    const collapsed = key => preferences.overrides[key] ?? preferences.collapsed;
    const collapseAll = button("collapse", "Collapse all tasks"), expandAll = button("expand", "Expand all tasks");
    const filter = document.createElement("label"); filter.className = "task-active-filter";
    const activeOnly = document.createElement("input"); activeOnly.type = "checkbox";
    activeOnly.className = "mission-switch"; activeOnly.setAttribute("role", "switch");
    filter.append(activeOnly, document.createTextNode("Show only active runs"));
    const displayToggles = document.createElement("div"); displayToggles.className = "task-display-toggles";
    displayToggles.append(filter);
    const navigatorToggle = document.createElement("input"); navigatorToggle.type = "checkbox";
    navigatorToggle.className = "mission-switch"; navigatorToggle.setAttribute("role", "switch");
    if (toggleNavigator) {
      const label = document.createElement("label"); label.className = "task-navigator-toggle";
      label.append(navigatorToggle, document.createTextNode("Navigator")); displayToggles.append(label);
      navigatorToggle.onchange = async () => {
        const pending = toggleNavigator(navigatorToggle);
        if (!pending?.then) return;
        // Only lazy loading needs a disabled control; synchronous close restores focus here.
        navigatorToggle.disabled = true;
        try { await pending; }
        finally { navigatorToggle.disabled = false; }
      };
    }
    const emptyState = document.createElement("div"); emptyState.className = "task-active-empty"; emptyState.hidden = true;
    const emptyLabel = document.createElement("p"); emptyLabel.textContent = "No active runs";
    emptyLabel.setAttribute("role", "status");
    emptyState.append(emptyLabel);
    toolbar.classList.add("task-disclosure-toolbar"); toolbar.setAttribute("role", "group");
    toolbar.setAttribute("aria-label", "Task display"); toolbar.append(collapseAll, expandAll, displayToggles);
    const resize = new ResizeObserver(entries => {
      for (const {target} of entries) measure(target);
    });
    function measure(preview) {
      const overflow = preview.clientHeight > 0 && preview.scrollHeight > preview.clientHeight + 1;
      preview.classList.toggle("task-query-overflow", overflow);
    }
    function mount(group) {
      const header = document.createElement("div"); header.className = "task-disclosure-header";
      header.id = `task-disclosure-${++sequence}`;
      const toggle = button("toggle", "Collapse task"); toggle.classList.add("task-disclosure-toggle");
      const mode = document.createElement("div"); mode.className = "task-mode-banner task-disclosure-mode";
      const modeLabel = document.createElement("span"); modeLabel.className = "task-disclosure-mode-label"; modeLabel.hidden = true;
      const separator = document.createElement("span"); separator.className = "task-disclosure-separator";
      separator.textContent = "|"; separator.setAttribute("aria-hidden", "true"); separator.hidden = true;
      const preview = document.createElement("span"); preview.className = "task-disclosure-query";
      const status = document.createElement("span"); status.className = "task-disclosure-status";
      status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
      const timing = document.createElement("div"); timing.className = "task-disclosure-timing"; timing.hidden = true;
      const clock = window.SMTOMessageTimestamps?.create(null);
      const timeSeparator = document.createElement("span"); timeSeparator.textContent = "·";
      timeSeparator.setAttribute("aria-hidden", "true");
      const duration = document.createElement("span"); duration.className = "task-disclosure-duration";
      if (clock) timing.append(clock.root);
      timing.append(timeSeparator, duration); group.append(timing);
      mode.append(modeLabel, separator, status);
      header.append(toggle, mode, preview); group.prepend(header); resize.observe(preview);
      previews.add(preview);
      const record = {header, toggle, mode, modeLabel, separator, preview, status, timing, clock, timeSeparator, duration,
        key: "", cid, collapsed: false};
      toggle.addEventListener("click", () => change(() => {
        preferences.overrides[record.key] = !collapsed(record.key);
      }, header));
      groups.set(group, record);
      return record;
    }
    function sync() {
      if (rendering) return;
      rendering = true;
      scope();
      // Capture surviving runs before filtering changes their geometry, including
      // live completion and resume updates that do not go through change().
      const filtering = preferences.activeOnly || content.dataset.activeRunsOnly === "true";
      const top = viewport.getBoundingClientRect().top;
      const anchors = filtering ? [...new Set([...content.querySelectorAll(".turn")].filter(root => !isFiltered(root)).map(anchorFor))]
        .filter(node => node?.getClientRects().length && node.getBoundingClientRect().bottom > top)
        .map(node => ({node, top: node.getBoundingClientRect().top})) : [];
      let visibilityChanged = (content.dataset.activeRunsOnly === "true") !== preferences.activeOnly;
      content.dataset.activeRunsOnly = String(preferences.activeOnly);
      activeOnly.checked = preferences.activeOnly;
      if (!content.contains(emptyState)) content.append(emptyState);
      for (const preview of previews) if (!content.contains(preview)) { resize.unobserve(preview); previews.delete(preview); }
      const all = [], tasks = new Map();
      let dirty = false;
      for (const group of content.querySelectorAll(".activity-group")) {
        const articles = [...group.querySelectorAll(":scope > .turn")];
        if (!articles.length) continue;
        const records = articles.map(root => ({...getTurn(root), root}));
        const first = records[0], taskId = group.dataset.taskId || first.taskId;
        const record = groups.get(group) || mount(group);
        const key = taskId ? `task:${taskId}` : first.root.dataset.requestId ? `request:${first.root.dataset.requestId}`
          : `submission:${first.root.dataset.submissionId || record.header.id}`;
        // Binding a provisional request or a durable task must retain the user's choice.
        if (record.key && (record.key !== key || record.cid !== cid)
            && (record.cid === cid || !record.cid) && !Object.hasOwn(preferences.overrides, key)) {
          preferences.overrides[key] = record.collapsed; dirty = true;
          delete preferences.overrides[record.key];
        }
        if (newSubmissions.has(articles[0])) {
          preferences.overrides[key] = false; newSubmissions.delete(articles[0]); dirty = true;
        }
        Object.assign(record, {key, cid, collapsed: collapsed(key)});
        const item = {group, articles, records, record, taskId}; all.push(item);
        if (!tasks.has(key)) tasks.set(key, []);
        tasks.get(key).push(item);
      }
      if (dirty) save(cid, preferences);
      toolbar.hidden = !all.length && !preferences.activeOnly;
      let previousKey = null, leader;
      let visibleRuns = 0;
      for (const item of all) {
        const {group, articles, record, taskId} = item, members = tasks.get(record.key);
        const records = members.flatMap(member => member.records);
        const task = getTask(taskId);
        const headId = task?.current_request_id || task?.latest_request_id;
        const head = headId ? records.find(turn => turn.root.dataset.requestId === headId) : records.at(-1);
        const status = task?.status === "queued" ? "queued" : head?.status || task?.user_visible_status || task?.status;
        // A task can contain completed attempts and a running continuation.
        // Filter each request independently; task status must not revive old runs.
        for (const turn of item.records) {
          const filtered = preferences.activeOnly && turn.status !== "running";
          if ((turn.root.dataset.runFiltered === "true") !== filtered) visibilityChanged = true;
          if (filtered && turn.root.contains(document.activeElement)) activeOnly.focus({preventScroll: true});
          turn.root.dataset.runFiltered = String(filtered);
          if (!filtered) visibleRuns++;
        }
        const filtered = articles.every(article => article.dataset.runFiltered === "true");
        if ((group.dataset.runFiltered === "true") !== filtered) visibilityChanged = true;
        if (filtered && group.contains(document.activeElement)) activeOnly.focus({preventScroll: true});
        group.dataset.runFiltered = String(filtered);
        group.inert = filtered;
        const displayed = preferences.activeOnly ? records.filter(turn => turn.status === "running") : records;
        const original = displayed.find(turn => turn.userAuthored !== false && turn.prompt) || displayed[0] || records[0];
        const mode = original.root.querySelector(":scope > .task-mode-banner");
        record.modeLabel.hidden = record.separator.hidden = !mode;
        if (record.modeLabel.textContent !== (mode?.textContent || "")) record.modeLabel.textContent = mode?.textContent || "";
        record.mode.dataset.mode = mode?.dataset.mode || "";
        const prompt = preferences.activeOnly ? original.prompt || task?.prompt : task?.prompt || original.prompt;
        const preview = queryLabel(prompt, original.attachments);
        if (record.collapsed && record.previewSource !== preview) {
          // Reuse the shared plain-text renderer and cache by source; live status
          // updates should not parse the same prompt again or change its stored text.
          const plain = prompt?.trim() && window.SMTOMarkdown
            ? window.SMTOMarkdown.toText(preview, {limit: Infinity}) : preview;
          record.preview.textContent = plain.replace(/\s+/g, " ").trim();
          record.previewSource = preview;
        }
        const displayStatus = preferences.activeOnly && !filtered ? "running" : status;
        const label = labels[displayStatus] || "Status unavailable";
        if (record.status.textContent !== label) record.status.textContent = label;
        record.status.dataset.status = displayStatus || "unknown";
        const duplicate = !filtered && previousKey === record.key;
        if (!filtered && !duplicate) leader = record.header;
        record.header.hidden = duplicate;
        group.dataset.disclosureAnchor = filtered ? record.header.id : leader.id;
        group.dataset.taskCollapsed = String(record.collapsed);
        group.classList.toggle("task-disclosure-fragment", duplicate && record.collapsed);
        record.preview.hidden = !record.collapsed;
        record.clock?.update(task?.created_at || original.sentAt);
        const durations = records.map(turn => turn.durationMs)
          .filter(value => typeof value === "number" && Number.isFinite(value) && value >= 0);
        const requestIds = new Set(records.map(turn => turn.root.dataset.requestId).filter(Boolean));
        const partial = durations.length !== records.length || (headId && !requestIds.has(headId))
          || records.some(turn => turn.root.dataset.parentRequestId && !requestIds.has(turn.root.dataset.parentRequestId));
        const seconds = Math.floor(durations.reduce((total, value) => total + value, 0) / 1000);
        const elapsed = seconds >= 60 ? `${Math.floor(seconds / 60)}m ${seconds % 60}s` : `${seconds}s`;
        const durationLabel = durations.length ? `${elapsed}${partial ? " · partial" : ""}` : "Duration unavailable";
        if (record.duration.textContent !== durationLabel) record.duration.textContent = durationLabel;
        record.duration.title = "Time spent on this task's responses. Time between responses is excluded."
          + (partial ? " Some response times are unavailable." : "");
        const hasClock = record.clock && !record.clock.root.hidden;
        record.timeSeparator.hidden = !hasClock;
        record.timing.hidden = !record.collapsed || duplicate || (!hasClock && !durations.length);
        record.toggle.setAttribute("aria-expanded", String(!record.collapsed));
        record.toggle.title = record.collapsed ? "Expand task" : "Collapse task";
        record.toggle.setAttribute("aria-label", record.toggle.title);
        const bodies = members.flatMap(member => member.articles);
        for (const article of bodies) article.id ||= `task-body-${++sequence}`;
        record.toggle.setAttribute("aria-controls", bodies.map(article => article.id).join(" "));
        for (const article of articles) {
          if (!filtered && record.collapsed && article.contains(document.activeElement)) leader.querySelector("button").focus({preventScroll: true});
          article.inert = record.collapsed || article.dataset.runFiltered === "true";
        }
        measure(record.preview);
        if (!filtered) previousKey = record.key;
      }
      const showEmpty = preferences.activeOnly && visibleRuns === 0;
      emptyState.hidden = !showEmpty;
      if (visibilityChanged) {
        const saved = anchors.find(({node}) => node.isConnected && !isFiltered(node) && node.getClientRects().length);
        if (saved) viewport.scrollBy({top: saved.node.getBoundingClientRect().top - saved.top, behavior: "instant"});
        viewport.dispatchEvent(new Event("task-disclosure-change"));
        // Defer until create() has returned; clients may still be initializing.
        queueMicrotask(changed);
      }
      rendering = false;
    }
    function refresh() {
      if (pending) return;
      pending = true;
      queueMicrotask(() => { pending = false; sync(); });
    }
    function change(update, preferredAnchor, persist = true) {
      scope(); preferences = read(cid);
      beforeToggle();
      const top = viewport.getBoundingClientRect().top;
      const visible = [...content.querySelectorAll(".activity-group")]
        .find(node => node.getBoundingClientRect().bottom > top);
      const anchor = preferredAnchor || document.getElementById(visible?.dataset.disclosureAnchor);
      const y = anchor ? Math.max(top, anchor.getBoundingClientRect().top) : 0;
      const wasFiltered = content.dataset.activeRunsOnly === "true";
      update(); if (persist) save(cid, preferences); sync();
      if (wasFiltered === preferences.activeOnly && anchor?.isConnected && !isFiltered(anchor) && anchor.getClientRects().length)
        viewport.scrollBy({top: anchor.getBoundingClientRect().top - y, behavior: "instant"});
      viewport.dispatchEvent(new Event("task-disclosure-change"));
      changed();
    }
    collapseAll.onclick = () => change(() => { preferences.collapsed = true; preferences.overrides = Object.create(null); });
    expandAll.onclick = () => change(() => { preferences.collapsed = false; preferences.overrides = Object.create(null); });
    activeOnly.onchange = () => change(() => { preferences.activeOnly = activeOnly.checked; });
    const controller = {refresh, sync,
      setNavigatorOpen(open) { navigatorToggle.checked = open; },
      submitted(root) { newSubmissions.add(root); sync(); },
      reveal(root) {
        sync(); const record = groups.get(root?.closest(".activity-group"));
        if (record && (record.collapsed || isFiltered(root))) change(() => {
          if (isFiltered(root)) preferences.activeOnly = false;
          preferences.overrides[record.key] = false;
        }, record.header);
      },
      reload(changedCid) {
        scope();
        if (changedCid !== undefined && changedCid !== cid) return;
        change(() => {}, null, false);
      },
    };
    controllers.add(controller); sync();
    return controller;
  }
  window.addEventListener("storage", event => {
    if (event.key === null || event.key.startsWith(prefix)) {
      if (event.key) { cache.delete(event.key.slice(prefix.length)); unavailable.delete(event.key.slice(prefix.length)); }
      else { cache.clear(); unavailable.clear(); }
      for (const controller of controllers) controller.reload(event.key?.slice(prefix.length));
    }
  });
  window.addEventListener("pageshow", event => { if (event.persisted) for (const controller of controllers) controller.reload(); });
  window.SMTOTaskDisclosure = {create, anchorFor, isFiltered, forget};
})();
