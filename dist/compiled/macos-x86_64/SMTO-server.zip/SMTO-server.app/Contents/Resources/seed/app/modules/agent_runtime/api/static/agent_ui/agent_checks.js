/**
 * @file src/agent_runtime/api/static/agent_ui/agent_checks.js
 * @brief Render policy diagnostics and Activity controls from server snapshots.
 * @details
 * Responsibilities: Display Activity state and scoped policy fields with an explicit native field skin.
 * Boundaries: The conversation owns the selected ordinary answer form; diagnostics own no run truth,
 *   scheduler semantics, persistence authority or credential storage.
 * Lifecycle: Catalog/run snapshots render controls; user events call existing APIs and refresh.
 *   Promoted user waits point back to the conversation without a duplicate Activity answer field.
 * State: Page-local draft maps, controls and disclosures project server-owned policy/Activity state.
 * Security: Dedicated credential/approval controls remain separate and server validated.
 * Collaborators: native routes project waiting_activity_id; desktop/mobile conversations submit replies;
 *   agent_checks.css owns ordinary field presentation and mission_switch.css owns switches.
 * Public surface: SMTOAgentChecks exposes scoped policy renderers, draft accessors and Activity
 *   diagnostics without model calls. Presentation helpers preserve native elements and event targets.
 * @see src/agent_runtime/api/agent_ui_support/route_groups/background_activities.py
 * @see src/agent_runtime/api/static/agent_ui/agent_checks.css
 * @see src/agent_runtime/api/static/agent_ui/completion_handling.js
 */
(() => {
  "use strict";
  const displayCopy = value => window.SMTOBranding?.text(value) ?? value;
  // Mobile may load this through both the shared script and a lazy module.
  if (window.SMTOAgentChecks) return;
  /** Create presentation nodes with textContent, keeping catalog text out of executable HTML. */
  const node = (tag, text = "", cls = "") => {
    const el = document.createElement(tag); el.textContent = text;
    if (cls) el.className = cls;
    return el;
  };
  /** Create an ordinary native field with the shared skin; switches use switchControl. */
  const fieldControl = tag => node(tag, "", "chat-field-control");
  /** Wrap a real select for a CSS-only chevron; handlers retain the original select. */
  function selectShell(select) {
    const shell = node("span", "", "chat-select-shell");
    shell.append(select);
    return shell;
  }
  const terminal = new Set(["answered", "completed", "failed", "cancelled", "interrupted"]);
  /** Encode the run identity for native API routes; callers supply the owning request ID. */
  const path = rid => `/api/agent/native/${encodeURIComponent(rid)}`;
  /** Serialize existing API payloads with their JSON content type; never persist field values here. */
  const json = body => ({headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
  /** Read Agent Checks snapshots from current traces or their supported metrics/profile envelopes. */
  const stateOf = trace => trace?.agent_checks || trace?.response_metrics?.agent_checks || trace?.native_profile?.agent_checks;
  const strikeDisclosureState = new WeakMap();
  const strikeAttempts = new WeakMap();
  const strikeCurrentState = new WeakMap();
  let panelSequence = 0;
  // One conversation-scoped owner for desktop and mobile prompt overrides.
  const integrityDrafts = new Map();
  /** Return the temporary conversation-keyed integrity override, or undefined for inheritance. */
  const integrityForRequest = cid => integrityDrafts.get(cid || "new");
  /** Set or clear a boolean prompt override and notify composer projections without an API write. */
  const setIntegrityDraft = (cid, value) => {
    if (typeof value === "boolean") integrityDrafts.set(cid || "new", value);
    else integrityDrafts.delete(cid || "new");
    window.dispatchEvent(new Event("task-contract-integrity-changed"));
  };
  /** Resolve the prompt override against conversation settings, retaining disabled compilation state. */
  const integrityView = (cid, settings = {}) => {
    const override = integrityForRequest(cid);
    return {enabled: override ?? settings.task_contract_integrity_guard_enabled ?? true,
      source: override === undefined ? "Conversation default" : "Overridden for this prompt",
      disabled: settings.task_contract_compilation_enabled !== true,
      help: "Applies only when Task Contract Compilation is enabled. Checks scope paths and @parameter references without additional model calls."};
  };
  /** Render the prompt-only integrity switch/reset; mutations remain in the conversation draft map. */
  function integrityControls(root, {conversationId, settings, onDraftChanged}) {
    const box = node("div"), label = node("label"), toggle = switchControl("Task Contract Integrity Guard", true);
    const source = node("small"), help = node("p");
    label.append(toggle, node("span", "Task Contract Integrity Guard"));
    const reset = node("button", "Use conversation default", "action-button"); reset.type = "button";
    /** Reproject the prompt integrity draft and inherited setting into the switch, help and reset state. */
    const refresh = () => {
      const view = integrityView(conversationId, settings());
      toggle.checked = view.enabled; toggle.disabled = view.disabled;
      source.textContent = view.source; help.textContent = view.help;
      reset.disabled = integrityForRequest(conversationId) === undefined;
    };
    toggle.onchange = () => { setIntegrityDraft(conversationId, toggle.checked); onDraftChanged?.(); refresh(); };
    reset.onclick = () => { setIntegrityDraft(conversationId, null); onDraftChanged?.(); refresh(); };
    box.append(label, source, help, reset); root.append(box); refresh();
    return refresh;
  }
  const contextDrafts = new Map();
  const backgroundDrafts = new Map();
  /** Return the pending background policy for request capture without resolving server defaults. */
  const backgroundPolicyForRequest = cid => backgroundDrafts.get(cid || "new");
  /** Set or clear the background prompt override and notify the current composer. */
  const setBackgroundDraft = (cid, policy) => {
    if (policy) backgroundDrafts.set(cid || "new", policy); else backgroundDrafts.delete(cid || "new");
    window.dispatchEvent(new Event("background-policy-changed"));
  };
  const dependencyDrafts = new Map();
  /** Expose the pending dependency policy for this conversation at request admission. */
  const dependencyPolicyForRequest = cid => dependencyDrafts.get(cid || "new");
  /** Update only the in-memory dependency override and dispatch its projection event. */
  const setDependencyDraft = (cid, policy) => {
    if (policy) dependencyDrafts.set(cid || "new", policy); else dependencyDrafts.delete(cid || "new");
    window.dispatchEvent(new Event("dependency-policy-changed"));
  };
  const schedulingDrafts = new Map();
  const schedulingPreferenceForRequest = cid => schedulingDrafts.get(cid || "new");
  function schedulingControls(root, cid, changed) {
    const value = schedulingPreferenceForRequest(cid) || {preset: "automatic", mode: "automatic", priority: "automatic"};
    const box = node("article", "", "agent-check-row scheduling-preference");
    box.append(node("h4", "Scheduling preference"));
    const fields = {};
    for (const [key, title, options] of [
      ["preset", "Scheduling", [["automatic", "Automatic"], ["read_only_inspection", "Read-only inspection"], ["network_download", "Network download"], ["network_upload", "Network upload"], ["cpu_intensive", "CPU intensive"], ["gpu_intensive", "GPU intensive"], ["disk_read", "Disk read"], ["disk_write", "Disk write"], ["lightweight", "Lightweight"], ["exclusive", "Exclusive"]]],
      ["mode", "Mode", [["automatic", "Automatic"], ["foreground", "Foreground"], ["background", "Background"]]],
      ["priority", "Priority", [["automatic", "Automatic"], ["interactive", "Interactive"], ["normal", "Normal"], ["background", "Background"]]]]) {
      const input = fieldControl("select"); input.setAttribute("aria-label", title);
      for (const [id, text] of options) { const option = node("option", text); option.value = id; input.append(option); }
      input.value = value[key]; fields[key] = input;
      const label = node("label", "", "agent-check-toggle-row"); label.append(node("span", title), selectShell(input)); box.append(label);
      input.addEventListener("change", () => {
        schedulingDrafts.set(cid || "new", Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, v.value])));
        changed?.();
      });
    }
    box.append(node("p", "Preferences help schedule work. Detected effects, resource limits and execution permissions still apply."));
    root.append(box);
  }
  const resourceDrafts = new Map();
  /** Read the resource prompt override; absence delegates inheritance to the policy owner. */
  const resourcePolicyForRequest = cid => resourceDrafts.get(cid || "new");
  /** Replace or clear a resource prompt draft and signal the composer without saving globally. */
  const setResourceDraft = (cid, policy) => {
    if (policy) resourceDrafts.set(cid || "new", policy); else resourceDrafts.delete(cid || "new");
    window.dispatchEvent(new Event("resource-policy-changed"));
  };
  const parallelDrafts = new Map();
  /** Read the conversation-keyed parallel policy captured with the next prompt. */
  const parallelPolicyForRequest = cid => parallelDrafts.get(cid || "new");
  /** Replace or clear parallel prompt intent and notify views without changing scheduler state. */
  const setParallelDraft = (cid, policy) => {
    if (policy) parallelDrafts.set(cid || "new", policy); else parallelDrafts.delete(cid || "new");
    window.dispatchEvent(new Event("parallel-policy-changed"));
  };
  /** Return the temporary attached-context read policy for the selected conversation. */
  const contextPolicyForRequest = cid => contextDrafts.get(cid || "new");
  /** Describe full, bounded-character or legacy context reads using the supplied policy snapshot. */
  const contextPolicyLabel = policy => !policy ? "Legacy byte reads" : policy.read_full_attached_context
    ? "Full file" : `Up to ${Number(policy.max_characters_per_read).toLocaleString()} characters per read`;
  const stopDrafts = new Map();
  /** Expose the pending stop policy for capture with the next admitted request. */
  const stopPolicyForRequest = cid => stopDrafts.get(cid || "new");
  /** Consume all prompt policy drafts for a conversation and notify dependent composer views. */
  const clearStopDraft = cid => {
    stopDrafts.delete(cid || "new"); contextDrafts.delete(cid || "new");
    setIntegrityDraft(cid, null);
    setParallelDraft(cid, null); setBackgroundDraft(cid, null); setDependencyDraft(cid, null); setResourceDraft(cid, null);
    window.dispatchEvent(new Event("context-policy-changed"));
  };
  /** Append a searchable Settings capacity group while leaving its field events to policy renderers. */
  function capacityGroup(root, title, description) {
    const box = node("article", "", "agent-check-row scheduler-capacity-group");
    box.dataset.settingSearch = `${title} ${description}`.toLowerCase();
    box.append(node("h4", title), node("p", description));
    root.append(box);
    return box;
  }

  /** Render scoped conflict/concurrency controls; prompt edits draft locally and other scopes use the policy API. */
  function parallelControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged, showGroupTitle = true, capacityRoot}) {
    if (!catalog) return;
    if (showGroupTitle) {
      const group = node("section", "", "asynchronous-task-execution");
      group.setAttribute("aria-label", "Asynchronous task execution");
      group.append(node("h3", "Asynchronous task execution"));
      root.append(group); root = group;
    }
    const explicit = scope === "run" ? run.parallel_execution_policy : scope === "prompt" ? parallelPolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = explicit || catalog.parallel_execution_policy;
    const box = node("article", "", "agent-check-row parallel-settings");
    box.dataset.settingSearch = "parallel execution conflict serialize reject concurrent activities";
    box.append(node("h4", "Parallel execution"));
    const toggle = switchControl("Parallel execution", policy.enabled);
    const label = node("label", "", "agent-check-toggle-row"); label.append(node("span", "Parallel execution"), toggle);
    const conflict = fieldControl("select"); conflict.setAttribute("aria-label", "When parallel operations conflict");
    for (const [value, title] of [["serialize", "Serialize safely"], ["reject", "Reject parallel request"]]) {
      const option = node("option", title); option.value = value; conflict.append(option);
    }
    conflict.value = policy.conflict_behavior;
    const conflictLabel = node("label", "When parallel operations conflict"); conflictLabel.append(selectShell(conflict));
    const limit = fieldControl("select"); limit.setAttribute("aria-label", "Max concurrent activities per run");
    for (let i = 1; i <= 16; i++) { const option = node("option", String(i)); option.value = String(i); limit.append(option); }
    limit.value = String(policy.max_concurrent_activities);
    const limitLabel = node("label", "Max concurrent activities per run"); limitLabel.append(selectShell(limit));
    const source = scope === "run" ? run.parallel_execution_source : explicit && scope !== "global" ? scope
      : scope === "global" ? catalog.global_source : catalog.parallel_execution_source;
    const sourceText = source === "global" ? "Inherited from Global" : source === "product_default" ? "Product default"
      : source === "legacy" ? "Historical sequential setting" : `Overridden for this ${source}`;
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
    const feedback = node("p"); feedback.setAttribute("role", "status");
    const historical = scope === "run" && terminal.has(run.status);
    /** Combine pending save, historical run and the parallel toggle into dependent field disabled states. */
    const disabled = busy => {
      toggle.disabled = reset.disabled = Boolean(busy || historical);
      conflict.disabled = limit.disabled = Boolean(busy || historical || !toggle.checked);
    };
    /** Save parallel intent to its prompt draft or revision-aware API; refresh and restore controls after feedback. */
    async function save(value) {
      disabled(true);
      try {
        if (scope === "prompt") { setParallelDraft(conversationId, value); onDraftChanged?.(); }
        else await apiJson("/api/agent/parallel-execution", {method: "PUT", ...json({scope,
          conversation_id: conversationId || null, request_id: requestId || null, policy: value,
          policy_revision: scope === "run" ? run.parallel_execution_revision || 0 : null})});
        window.dispatchEvent(new Event("parallel-policy-changed"));
        await refresh();
      } catch (error) { window.SMTOErrors.present(feedback, error); notify?.(error); }
      finally { disabled(false); }
    }
    /** Build the existing parallel policy payload from native checked/value properties and save it once. */
    const changed = () => void save({enabled: toggle.checked, conflict_behavior: conflict.value,
      max_concurrent_activities: Number(limit.value)});
    toggle.onchange = conflict.onchange = limit.onchange = changed; reset.onclick = () => void save(null);
    box.append(label, node("p", "Run independent compatible operations at the same time. This limit covers foreground, background and dependency activities together. When off, one activity executes at a time and foreground calls keep their original order."),
      conflictLabel, node("p", "Serialize safely runs conflicting or uncertain operations in order. Reject checks the entire group before any operation starts."),
      limitLabel, node("small", sourceText), feedback, reset);
    if (capacityRoot) {
      const capacity = capacityGroup(capacityRoot, "Parallel activity limit", "The shared ceiling for foreground, background and dependency activities. Parallel execution Off still permits only one activity at a time.");
      capacity.append(limitLabel);
    }
    disabled(false); root.append(box);
  }

  /** Render promotion and background limits with native numeric validation and historical-run disabling. */
  function backgroundControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged, capacityRoot}) {
    if (!catalog) return;
    const explicit = scope === "run" ? run.background_activity_policy : scope === "prompt" ? backgroundPolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = explicit || (scope === "run" ? {...catalog.product_default, enabled: false} : catalog.background_activity_policy);
    const box = node("article", "", "agent-check-row background-settings");
    box.dataset.settingSearch = "background activities auto promote promotion delay asynchronous required wait";
    box.append(node("h4", "Background activities"));
    const capacity = capacityRoot ? capacityGroup(capacityRoot, "Background activity limit", "Background work also shares the parallel and resource limits.") : null;
    const fields = {};
    for (const [key, title, type, min, max] of [
      ["enabled", "Background activities", "boolean"],
      ["auto_promote", "Auto-promote long foreground operations", "boolean"],
      ["promotion_delay_seconds", "Background promotion delay (seconds)", "number", 1, 300],
      ["max_background_activities", "Max background activities per run", "number", 1, 16],
      ["wait_for_required", "Wait for required activities before finish", "boolean"]]) {
      const input = type === "boolean" ? switchControl(title, policy[key]) : fieldControl("input");
      if (type === "number") { input.type = "number"; input.min = min; input.max = max; input.step = 1; input.required = true; input.value = policy[key]; input.setAttribute("aria-label", title); }
      const label = node("label", "", "agent-check-toggle-row"); label.append(node("span", title), input);
      (capacity && key.startsWith("max_") ? capacity : box).append(label);
      fields[key] = input;
    }
    const source = scope === "run" ? run.background_activity_source || "legacy" : explicit && scope !== "global" ? scope
      : scope === "global" ? catalog.global_source : catalog.background_activity_source;
    box.append(node("p", "Keep managed work running while the agent handles independent steps. Background work shares the activity limit. Remaining jobs stop when the task closes."),
      node("small", source === "global" ? "Inherited from Global" : source === "product_default" ? "Product default" : source === "legacy" ? "Historical setting: Off" : `Overridden for this ${source}`));
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
    const feedback = node("p"); feedback.setAttribute("role", "status");
    /** Keep background fields unavailable during saves, historical runs or disabled background execution. */
    const disabled = busy => {
      const historical = scope === "run" && terminal.has(run.status);
      for (const [key, input] of Object.entries(fields)) input.disabled = Boolean(busy || historical || (key !== "enabled" && !fields.enabled.checked));
      reset.disabled = Boolean(busy || historical);
    };
    /** Persist scoped background policy or inheritance, reporting API failure before re-enabling editable controls. */
    async function save(value) {
      disabled(true);
      try {
        if (scope === "prompt") { setBackgroundDraft(conversationId, value); onDraftChanged?.(); }
        else await apiJson("/api/agent/background-activities", {method: "PUT", ...json({scope, conversation_id: conversationId || null,
          request_id: requestId || null, policy: value, policy_revision: scope === "run" ? run.background_activity_revision || 0 : null})});
        window.dispatchEvent(new Event("background-policy-changed")); await refresh?.();
      } catch (error) { window.SMTOErrors.present(feedback, error); notify?.(error); }
      finally { disabled(false); }
    }
    /** Validate background numeric controls before collecting their unchanged boolean/number payload. */
    const changed = () => {
      const value = {};
      for (const [key, input] of Object.entries(fields)) {
        if (input.type === "number" && !input.checkValidity()) { input.reportValidity(); return; }
        value[key] = input.type === "number" ? Number(input.value) : input.checked;
      }
      void save(value);
    };
    for (const input of Object.values(fields)) input.onchange = changed;
    reset.onclick = () => void save(null); box.append(feedback, reset); disabled(false); root.append(box);
  }

  /** Render dependency limits and toggles; preserve branch rules, scopes and revision-aware saves. */
  function dependencyControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged, capacityRoot}) {
    if (!catalog) return;
    const explicit = scope === "run" ? run.dependency_scheduling_policy : scope === "prompt" ? dependencyPolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = explicit || (scope === "run" ? {...catalog.product_default, enabled: false} : catalog.dependency_scheduling_policy);
    const box = node("article", "", "agent-check-row dependency-settings");
    box.dataset.settingSearch = "dependency DAG branch local unknown effects disjoint mutations graph scheduler";
    box.append(node("h4", "Dependency-aware scheduling"));
    const capacity = capacityRoot ? capacityGroup(capacityRoot, "Dependency activity limits", "Bound graph size and ready dependency work. Shared parallel and resource ceilings still apply.") : null;
    const fields = {};
    for (const [key, title, type, min, max] of [
      ["enabled", "Dependency-aware scheduling", "boolean"],
      ["parallel_disjoint_mutations", "Parallel disjoint mutations", "boolean"],
      ["branch_local_unknown_effects", "Block only conflicting branches on unknown effects", "boolean"],
      ["require_successful_dependencies", "Require successful dependencies", "boolean"],
      ["max_graph_activities", "Max activities per dependency graph", "number", 1, 256],
      ["max_run_activities", "Max activities per run", "number", 1, 1024],
      ["max_concurrent_activities", "Max concurrent dependency activities per run", "number", 1, 16],
      ["max_concurrent_per_gateway", "Max concurrent dependency activities per Gateway", "number", 1, 16]]) {
      const input = type === "boolean" ? switchControl(title, policy[key] ?? (key === "require_successful_dependencies")) : fieldControl("input");
      if (type === "number") { input.type = "number"; input.min = min; input.max = max; input.step = 1; input.required = true; input.value = policy[key]; input.setAttribute("aria-label", title); }
      const label = node("label", "", "agent-check-toggle-row"); label.append(node("span", title), input);
      (capacity && key.startsWith("max_") ? capacity : box).append(label);
      fields[key] = input;
    }
    const source = scope === "run" ? run.dependency_scheduling_source || "legacy" : explicit && scope !== "global" ? scope
      : scope === "global" ? catalog.global_source : catalog.dependency_scheduling_source;
    box.append(node("p", "Parallel execution controls overlap across foreground, background and dependency activities. When it is off, one activity executes at a time; dependency ordering still applies. Disjoint mutations require proven independent resources. Turning off Require successful dependencies permits continuation after confirmed failures; cancellation, unknown outcomes and policy rejections still block dependents. Accepted nodes keep their target and use current run Agent Checks."),
      node("small", source === "global" ? "Inherited from Global" : source === "product_default" ? "Product default" : source === "legacy" ? "Historical setting: Off" : `Overridden for this ${source}`));
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
    const feedback = node("p"); feedback.setAttribute("role", "status");
    /** Project dependency save/history/feature state onto fields while preserving the enabling switch. */
    const disabled = busy => {
      const historical = scope === "run" && terminal.has(run.status);
      for (const [key, input] of Object.entries(fields)) input.disabled = Boolean(busy || historical || (key !== "enabled" && !fields.enabled.checked));
      reset.disabled = Boolean(busy || historical);
    };
    /** Persist dependency policy for the selected scope, then refresh the catalog-backed field projection. */
    async function save(value) {
      disabled(true);
      try {
        if (scope === "prompt") { setDependencyDraft(conversationId, value); onDraftChanged?.(); }
        else await apiJson("/api/agent/dependency-scheduling", {method: "PUT", ...json({scope, conversation_id: conversationId || null,
          request_id: requestId || null, policy: value, policy_revision: scope === "run" ? run.dependency_scheduling_revision || 0 : null})});
        window.dispatchEvent(new Event("dependency-policy-changed")); await refresh?.();
      } catch (error) { window.SMTOErrors.present(feedback, error); notify?.(error); }
      finally { disabled(false); }
    }
    /** Validate dependency numeric controls before saving their typed values and toggle states. */
    const changed = () => {
      const value = {};
      for (const [key, input] of Object.entries(fields)) {
        if (input.type === "number" && !input.checkValidity()) { input.reportValidity(); return; }
        value[key] = input.type === "number" ? Number(input.value) : input.checked;
      }
      void save(value);
    };
    for (const input of Object.values(fields)) input.onchange = changed;
    reset.onclick = () => void save(null); box.append(feedback, reset); disabled(false); root.append(box);
  }

  /** Render resource/Gateway limits and global slots; Auto disables custom limits without discarding them. */
  function resourceControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged, toggleRoot, expanded = false}) {
    if (!catalog) return;
    if (scope === "prompt") schedulingControls(root, conversationId, onDraftChanged);
    const explicit = scope === "run" ? run.resource_scheduling_policy : scope === "prompt" ? resourcePolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = {observation: 4, ...catalog.product_default, ...(explicit || (scope === "run" ? {enabled: false} : catalog.resource_scheduling_policy))};
    const box = node("article", "", "agent-check-row resource-settings");
    box.dataset.settingSearch = "resource scheduler adaptive concurrency cpu disk gpu network capacity fairness";
    box.append(node("h4", toggleRoot ? "Resource and Gateway defaults" : "Scheduler capacity"));
    const toggleBox = toggleRoot ? capacityGroup(toggleRoot, "Resource budgets", "General activity limits remain active. Optional resource checks are controlled in Resource locking.") : box;
    const fields = {};
    const legacyEnabled = document.createElement("input"); legacyEnabled.type = "checkbox"; legacyEnabled.checked = true; fields.enabled = legacyEnabled;
    const lockingLink = node("a", "Configure Resource locking in Settings"); lockingLink.href = "/settings#settings-section-resource-locking"; toggleBox.append(lockingLink);
    const advanced = node("details"); advanced.open = expanded; advanced.append(node("summary", "Advanced resource limits"));
    for (const [key, title, type, min, max] of [
      ["max_concurrent_activities", "Max scheduled activities per run", "number", 1, 16],
      ["max_concurrent_per_gateway", "Default max activities per Gateway", "number", 1, 64],
      ["cpu_heavy", "CPU-heavy per Gateway", "number", 1, 64],
      ["disk_read_heavy", "Disk read-heavy per Gateway", "number", 1, 64],
      ["disk_heavy", "Disk-heavy per Gateway", "number", 1, 64],
      ["network_heavy", "Network-heavy per Gateway", "number", 1, 64],
      ["gpu_heavy", "GPU-heavy per Gateway", "number", 1, 64],
      ["lightweight", "Lightweight per Gateway", "number", 1, 64],
      ["unknown", "Unknown per Gateway", "number", 1, 64],
      ["observation", "Observation capacity", "number", 1, 16]]) {
      const input = type === "boolean" ? switchControl(title, policy[key]) : fieldControl("input");
      if (type === "number") { input.type = "number"; input.min = min; input.max = max; input.step = 1; input.required = true; input.value = policy[key] ?? (key === "unknown" ? 1 : undefined); input.setAttribute("aria-label", title); }
      const label = node("label", "", "agent-check-toggle-row"); label.append(node("span", title), input); (key === "enabled" ? toggleBox : key.endsWith("_heavy") || ["lightweight", "unknown"].includes(key) ? advanced : box).append(label);
      fields[key] = input;
    }
    for (const [key, title, options] of [
      ["resource_limits", "Resource-aware limits", [["auto", "Auto"], ["custom", "Custom"]]],
      ["fairness", "Scheduler fairness", [["balanced", "Balanced"], ["interactive", "Interactive first"]]]]) {
      const input = fieldControl("select"); input.setAttribute("aria-label", title);
      for (const [value, title] of options) { const option = node("option", title); option.value = value; input.append(option); }
      input.value = policy[key]; fields[key] = input;
      const label = node("label", title); label.append(selectShell(input)); box.append(label);
    }
    box.append(advanced);
    const source = scope === "run" ? run.resource_scheduling_source || "legacy" : explicit && scope !== "global" ? scope
      : scope === "global" ? catalog.global_source : catalog.resource_scheduling_source;
    box.append(node("p", "Resource budgets apply only to families enabled in Settings → Resource locking. Disabled families neither consume nor wait for these budgets. General activity limits remain active. Auto permits two proven disk reads per Gateway and one disk-heavy or unknown activity. Select Custom to edit each resource limit. Explicit Gateway overrides take precedence; shared total limits still apply."),
      node("small", source === "global" ? "Inherited from Global" : source === "product_default" ? "Product default" : source === "legacy" ? "Historical setting: Off" : `Overridden for this ${source}`));
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
    const feedback = node("p"); feedback.setAttribute("role", "status");
    /** Combine resource save/history state with Auto/Custom mode to gate custom numeric limits. */
    const disabled = busy => {
      const historical = scope === "run" && terminal.has(run.status);
      for (const [key, input] of Object.entries(fields)) input.disabled = Boolean(busy || historical || (key !== "enabled" && !fields.enabled.checked) || ((key.endsWith("_heavy") || ["lightweight", "unknown"].includes(key)) && fields.resource_limits.value !== "custom"));
      reset.disabled = Boolean(busy || historical);
    };
    /** Save scoped resource policy without changing admission logic; API errors remain visible in the group. */
    async function save(value) {
      if (scope === "prompt") {
        // Draft edits are synchronous. Disabling fields on blur steals focus
        // from the next numeric control before its keyboard input arrives.
        setResourceDraft(conversationId, value); disabled(false); onDraftChanged?.(); return;
      }
      disabled(true);
      try {
        await apiJson("/api/agent/resource-scheduling", {method: "PUT", ...json({scope, conversation_id: conversationId || null,
          request_id: requestId || null, policy: value, policy_revision: scope === "run" ? run.resource_scheduling_revision || 0 : null})});
        window.dispatchEvent(new Event("resource-policy-changed")); await refresh?.();
      } catch (error) { window.SMTOErrors.present(feedback, error); notify?.(error); }
      finally { disabled(false); }
    }
    /** Collect native select, numeric and switch values only after every resource number passes validity. */
    const changed = () => {
      const value = {};
      for (const [key, input] of Object.entries(fields)) {
        if (input.type === "number" && !input.checkValidity()) { input.reportValidity(); return; }
        value[key] = input.tagName.toLowerCase() === "select" ? input.value : input.type === "number" ? Number(input.value) : input.checked;
      }
      void save(value);
    };
    for (const input of Object.values(fields)) input.onchange = changed;
    reset.onclick = () => void save(null); box.append(feedback, reset); disabled(false); root.append(box);
    if (scope === "global") {
      const globalInput = fieldControl("input"); globalInput.type = "number"; globalInput.min = 1; globalInput.max = 128; globalInput.step = 1; globalInput.required = true;
      globalInput.setAttribute("aria-label", "Global activity slots"); globalInput.disabled = true;
      const label = node("label", "Global activity slots"); label.append(globalInput);
      const globalBox = expanded ? capacityGroup(root, "Global activity limit", "Shared across tasks and Gateways. Changes apply to new admissions; running work continues.") : advanced;
      globalBox.append(label);
      void apiJson("/api/agent/resource-scheduling/capacity").then(value => {globalInput.value = value.capacity; globalInput.disabled = false;}).catch(error => {window.SMTOErrors.present(feedback, error);});
      globalInput.onchange = async () => {
        if (!globalInput.checkValidity()) {globalInput.reportValidity(); return;}
        globalInput.disabled = true;
        try {await apiJson("/api/agent/resource-scheduling/capacity", {method:"PUT", ...json({global_slots:Number(globalInput.value)})});}
        catch (error) {window.SMTOErrors.present(feedback, error);}
        finally {globalInput.disabled = false;}
      };
    }
  }

  const activityClocks = new Set();
  const activitySectionActions = new WeakMap();
  let activityClock = null;
  /** Share one elapsed-time timer across active Activity projections and release it when all detach. */
  function trackActivityClock(element, activity) {
    if (!["running", "running_background"].includes(activity.state) || activity.finished_at || !activity.started_at || typeof window.setInterval !== "function") return;
    activityClocks.add({element, activity});
    if (activityClock !== null) return;
    activityClock = window.setInterval(() => {
      for (const entry of activityClocks) {
        if (!entry.element.isConnected) { activityClocks.delete(entry); continue; }
        const a = entry.activity, elapsed = Math.max(0, Date.now()/1000-a.started_at).toFixed(1);
        window.SMTONumberOdometer.render(entry.element, `${a.state.replaceAll("_", " ")} · ${a.effect_descriptor.target_id} ${elapsed}s`);
      }
      if (!activityClocks.size) { window.clearInterval(activityClock); activityClock = null; }
    }, 1000);
  }

  /** Project Activity snapshots and conflict recovery; promoted user waits link to their conversation-owned reply. */
  function activities(root, state, {requestId, apiJson, refresh, notify, stop, actionContainer}) {
    const sameRun = root.dataset.activityRequest === requestId;
    const expanded = sameRun ? [...root.querySelectorAll("details[open]")] : [];
    const open = new Set(expanded.map(el => el.dataset.batchId).filter(Boolean));
    const openSections = new Set(expanded.map(el => el.dataset.runSection).filter(Boolean));
    const previousRows = new Map((sameRun ? [...root.querySelectorAll("[data-activity-id]")] : []).map(el => [el.dataset.activityId, el]));
    root.dataset.activityRequest = requestId;
    root.replaceChildren();
    /** Create a native disclosure using the saved expansion state for this run section. */
    const section = (label, className) => {
      const detail = node("details", "", className);
      detail.dataset.runSection = className;
      detail.open = openSections.has(className);
      detail.append(node("summary", label));
      return detail;
    };
    const batches = state.activity_batches || [];
    if (state.resource_metrics) {
      const m = state.resource_metrics;
      const metrics = node("p", `Peak ${m.peak_concurrency || 0} · Parallelism ${Number(m.parallelism_factor || 0).toFixed(1)}× · Resource wait ${Number(m.resource_wait_seconds || 0).toFixed(1)}s`, "activity-concurrency-metrics");
      if (!actionContainer) root.append(metrics);
      if (m.scheduler_events || actionContainer) {
        const detail = section("Scheduler diagnostics", "activity-scheduler-diagnostics");
        if (actionContainer) detail.append(metrics);
        const e = m.scheduler_events;
        if (e) detail.append(node("p", `Capacity waits ${e.capacity_limited || 0} · Fairness waits ${e.fairness_wait || 0} · Aged admissions ${e.aged_admission || 0}`));
        root.append(detail);
      }
    }
    const activitySection = section("Activities", "run-activities");
    for (const batch of batches) {
      // Foreground results already appear in the timeline; managed jobs keep their receipt inspector.
      const single = batch.activities.length === 1 ? batch.activities[0] : null;
      if (single && !single.resource_class && !single.dependency_node && (single.state === "completed" && single.observation_id && !single.job_id
        || single.state === "rejected_policy" && (state.guard_strikes || []).some(strike =>
          strike.blocked_operation_id && strike.blocked_operation_id === single.operation_id))) continue;
      const box = node("details", "", "foreground-activities"); box.dataset.batchId = batch.batch_id;
      box.open = open.has(batch.batch_id);
      const running = batch.activities.filter(a => ["running", "running_background", "runnable", "pending"].includes(a.state)).length;
      const waiting = batch.activities.filter(a => ["queued_background", "runnable_waiting_capacity", "pending_dependency", "waiting_user", "waiting_approval"].includes(a.state)).length;
      box.append(node("summary", batch.activities.some(a => a.resource_class) ? `${batch.activities.length} ${single ? "activity" : "activities"} · Running ${running} · Waiting ${waiting}` : `${running ? "Running " : ""}${batch.activities.length} ${single ? "activity" : "activities"}`));
      const rows = node("ul");
      for (const activity of batch.activities) {
        const signature = JSON.stringify(activity);
        const previous = previousRows.get(activity.activity_id);
        if (activity.finished_at && previous?.dataset.signature === signature) {
          rows.append(previous); continue; // Preserve opened receipt inspectors across snapshots.
        }
        const row = node("li"); row.dataset.activityId = activity.activity_id; row.dataset.state = activity.state;
        row.dataset.signature = signature;
        const symbol = {runnable_waiting_capacity: "…", pending_dependency: "◌", blocked_dependency: "⊘", blocked_resource: "⊘", completed: "✓", running: "◉", running_background: "◉", queued_background: "◌", waiting_approval: "◌", waiting_user: "◌", unknown: "?", failed: "!", cancelled: "−", rejected_policy: "!", blocked_conflict: "!"}[activity.state] || "○";
        const duration = activity.started_at ? Math.max(0, (activity.finished_at || Date.now() / 1000) - activity.started_at).toFixed(1) + "s" : "";
        const elapsed = node("small", `${activity.state.replaceAll("_", " ")} · ${activity.effect_descriptor.target_id} ${duration}`);
        if (activity.resource_class) row.append(node("small", ({lightweight:"Light",cpu_heavy:"CPU",disk_read_heavy:"Disk read",disk_heavy:"Disk",network_heavy:"Network",gpu_heavy:"GPU",mixed:"Mixed",unknown:"Unknown"})[activity.resource_class], "activity-resource"));
        if (activity.state === "runnable_waiting_capacity") elapsed.textContent = activity.capacity_wait_reason || "Waiting for slot";
        trackActivityClock(elapsed, activity);
        const mark = node("span", symbol);
        if (symbol === "✓") mark.dataset.uiSymbol = "check";
        row.append(mark, node("span", activity.label || activity.child_id || activity.tool_name.replaceAll("__", ".")), elapsed);
        const supervision = state.supervision?.find(item => item.job_id === activity.job_id || item.activity_id === activity.activity_id);
        if (supervision) {
          const checked = supervision.last_observed_at
            ? new Date(supervision.last_observed_at * 1000).toLocaleTimeString() : "pending";
          const health = node("small", `${supervision.label} · Last checked ${checked}`);
          health.dataset.supervision = supervision.health_state;
          row.append(health);
        }
        row.id = `activity-${activity.activity_id}`;
        if (activity.resource_class) {
          const details = node("details", "", "activity-resource-details"); details.append(node("summary", "Activity details"));
          for (const [title, value] of [["Target", activity.resource_target_label || activity.effect_descriptor.target_id],
            ["Resource class", activity.resource_class.replaceAll("_", " ")], ["Duration", duration],
            ["Mode", activity.scheduling?.execution_mode], ["Priority", activity.scheduling?.priority],
            ["Reads", activity.scheduling?.access?.reads?.join(", ")],
            ["Writes", activity.scheduling?.access?.writes?.join(", ")],
            ["Footprint source", activity.scheduling?.confidence?.footprint],
            ["Profile sources", activity.scheduling?.provenance?.join(", ")],
            ["Unknown scope", activity.scheduling?.unknown?.scope],
            ["Classification reason", activity.scheduling?.unknown?.reason],
            ["Agent slot", ["running", "running_background", "queued_background", "runnable_waiting_capacity"].includes(activity.state) ? "Released during physical work" : null],
            ["Receipt", activity.receipt_id], ["Wait reason", activity.capacity_wait_reason],
            ["Resource claims", Object.entries(activity.resource_claims || {}).map(([key, value]) => `${key}=${value}`).join(", ")],
            ["Resource claim", activity.resource_claim_state], ["Process liveness", activity.liveness_state],
            ["Classified effect", activity.classified_effect], ["Classifier revision", activity.classified_effect_revision],
            ["Resource descriptor revision", activity.resource_descriptor_revision],
            ["Effect reconciled by", activity.effect_reconciled_by],
            ["Outcome", activity.outcome_state], ["Blocker revision", activity.blocker_revision],
            ["Agent revision", activity.agent_runtime_revision], ["Gateway revision", activity.gateway_runtime_revision],
            ["Gateway version", activity.gateway_version], ["Execution protocol", activity.execution_protocol_revision]]) {
            if (value) details.append(node("p", `${title}: ${value}`));
          }
          const admission = activity.resource_admission;
          if (admission) {
            const diagnostic = node("details"); diagnostic.append(node("summary", "Resource admission"));
            const values = [["P1 foreground ceiling", admission.p1_limit],
              ["Policy source", admission.policy_source], ["Resource limits", admission.resource_limits],
              ["Limiting factor", admission.limiting_dimension || "None"]];
            if (admission.resource_locking) {
              const locking = admission.resource_locking;
              values.push(["Resource locking", locking.enabled ? "Enabled" : "Disabled"],
                ["Locking family", locking.family], ["Locking policy revision", locking.revision]);
            }
            for (const key of ["global", "run", "gateway"]) {
              const usage = admission[key];
              if (usage) values.push([`${key} usage / ceiling`, `${usage.usage} / ${usage.limit}`]);
            }
            for (const [key, usage] of Object.entries(admission.resources || {}))
              values.push([`${key} usage / capacity (demand)`, `${usage.usage} / ${usage.limit} (${usage.demand})`]);
            const overrides = Object.entries(admission.gateway_override || {}).filter(([, value]) => value != null);
            if (overrides.length) values.push(["Gateway overrides", overrides.map(([key, value]) => `${key}=${value}`).join(", ")]);
            for (const [title, value] of values) if (value != null) diagnostic.append(node("p", `${title}: ${value}`));
            details.append(diagnostic);
          }
          row.append(details);
        }
        if (activity.depends_on?.length) {
          row.className = "dependency-activity";
          const details = node("details", "", "activity-dependencies"); details.append(node("summary", "Depends on"));
          for (const dependency of activity.dependency_details || []) {
            const link = node("a", `${dependency.label} · ${dependency.state.replaceAll("_", " ")}`);
            link.href = `#activity-${dependency.activity_id}`; details.append(link);
          }
          row.append(details);
        }
        if (activity.state === "pending_dependency") row.append(node("p", "Waiting for dependencies", "activity-dependency-status"));
        if (activity.blocked_reason) row.append(node("p", activity.blocked_reason, "activity-dependency-status"));
        if (activity.state === "blocked_resource") {
          const strike = (state.guard_strikes || []).findLast(item => item.blocked_operation_id === activity.operation_id);
          if (strike) strikeCard(row, strike, state, {requestId, status: state.status, apiJson, reload: refresh, notify});
        }
        if (["runnable_waiting_capacity", "running", "starting", "running_background", "queued_background", "pending", "pending_dependency", "blocked_resource", "runnable", "waiting_approval", "waiting_user", "unknown"].includes(activity.state)) {
          const button = node("button", activity.stop_requested ? "Stopping…" : "Stop", "action-button"); button.type = "button";
          button.setAttribute("aria-label", "Stop activity"); button.disabled = Boolean(activity.stop_requested);
          button.onclick = async () => {
            button.disabled = true;
            try { await apiJson(`${path(requestId)}/activities/${encodeURIComponent(activity.activity_id)}/stop`, {method: "POST"}); await refresh(); }
            catch (error) { button.disabled = false; notify?.(error); }
          };
          row.append(button);
        }
        if (activity.state === "waiting_user" && state.waiting_activity_id === activity.activity_id) {
          row.append(node("p", "Waiting for your reply in the conversation"));
        } else if (["waiting_approval", "waiting_user"].includes(activity.state)) {
          const provide = node("details", "", "activity-input"); provide.append(node("summary", activity.state === "waiting_approval" ? "Review approval" : "Provide input"));
          provide.append(node("p", activity.wait_message || "This activity needs input. Other work can continue."));
          if (activity.approval_preview) provide.append(node("pre", JSON.stringify(activity.approval_preview, null, 2)));
          const request = activity.input_request;
          const form = node("form"), input = fieldControl("input");
          if (request?.kind === "oauth") {
            const url = request.authorization_url || request.verification_uri;
            try { if (["https:", "http:"].includes(new URL(url).protocol)) { const link = node("a", "Authorize in browser"); link.href = url; link.target = "_blank"; link.rel = "noopener noreferrer"; provide.append(link); } } catch (_) {}
            if (request.user_code) provide.append(node("p", request.user_code));
          } input.type = "text";
          input.autocomplete = "off"; input.setAttribute("aria-label", "Answer");
          if (activity.state !== "waiting_approval" && request?.kind !== "oauth") form.append(input);
          const send = node("button", activity.state === "waiting_approval" ? "Approve this activity" : "Provide", "action-button"); send.type = "submit"; form.append(send);
          form.onsubmit = async event => {
            event.preventDefault(); send.disabled = true;
            try { await apiJson(`${path(requestId)}/activities/${encodeURIComponent(activity.activity_id)}/input`, {method: "POST", ...json({
              action: {waiting_approval: "approve", waiting_user: "answer"}[activity.state], value: input.value || null, operation_id: activity.operation_id,
              ...(activity.authority_request ? {authority_request_id: activity.authority_request.authority_request_id} : {}),
            })});
              input.value = ""; await refresh();
            } catch (error) { notify?.(error); send.disabled = false; }
          };
          if (request?.kind !== "oauth") provide.append(form); row.append(provide);
        }
        if (activity.observation_id && window.SMTOToolActivity) {
          window.SMTOToolActivity.attach({copy: row, title: node("span", "View result"), summary: node("small")},
            requestId, {detail_available: true, operation_id: activity.observation_id || activity.operation_id, detail_version: "completed"});
        }
        rows.append(row);
      }
      box.append(rows);
      if (batch.activities.some(a => a.state === "running_background")) box.append(node("p", "Background work continues while the agent handles independent steps."));
      if ((running || batch.activities.some(a => ["pending_dependency", "blocked_resource", "waiting_user", "waiting_approval"].includes(a.state))) && stop) { const button = node("button", "Stop task", "action-button"); button.type = "button"; button.onclick = stop; box.append(button); }
      activitySection.append(box);
    }
    if (activitySection.children.length > 1) root.append(activitySection);
    if (state.jobs?.length) {
      const history = section("Operation history", "run-operation-history");
      const rows = node("ul", "", "run-operation-list");
      for (const job of state.jobs) {
        const row = node("li");
        row.append(node("span", job.capability_id || "Operation", "run-operation-name"),
          node("span", (job.state || "unknown").replaceAll("_", " "), "run-operation-state"),
          node("code", job.job_id, "run-operation-id"));
        rows.append(row);
      }
      history.append(rows); root.append(history);
    }
    if (state.parallel_conflict) {
      const strike = node("details", "", "agent-check-strike"); strike.open = true;
      strike.append(node("summary", "Action Rejected · Parallel conflict"), node("p", state.parallel_conflict.problem));
      const select = fieldControl("select"); select.setAttribute("aria-label", "Parallel conflict handling for this run");
      for (const [value, title] of [["reject", "Keep rejecting"], ["serialize", "Serialize safely and continue"]]) {
        const option = node("option", title); option.value = value; select.append(option);
      }
      select.onchange = async () => {
        if (select.value !== "serialize") return;
        select.disabled = true;
        try {
          const result = await apiJson("/api/agent/parallel-execution", {method: "PUT", ...json({scope: "run", request_id: requestId,
            policy: {...state.parallel_execution_policy, conflict_behavior: "serialize"},
            policy_revision: state.parallel_execution_revision || 0, batch_id: state.parallel_conflict.batch_id})});
          if (result?.resume_required) await apiJson(`${path(requestId)}/control`, {method: "POST", ...json({action: "resume"})});
          await refresh();
        } catch (error) { notify?.(error); select.disabled = false; }
      };
      strike.append(selectShell(select)); root.append(strike);
    }
    if (actionContainer) {
      let buttons = activitySectionActions.get(root);
      if (!buttons || !sameRun) {
        for (const button of buttons?.values() || []) button.remove();
        buttons = new Map(); activitySectionActions.set(root, buttons);
      }
      const panels = [...root.children].filter(panel => panel.dataset.runSection);
      const keys = new Set(panels.map(panel => panel.dataset.runSection));
      for (const [key, button] of buttons) if (!keys.has(key)) { button.remove(); buttons.delete(key); }
      panels.forEach((panel, index) => {
        const key = panel.dataset.runSection, label = panel.querySelector("summary").textContent;
        panel.classList.add("run-section-with-action");
        panel.id = `${key}-${requestId}`;
        panel.setAttribute("aria-label", label);
        let button = buttons.get(key);
        if (!button) { button = node("button", label, "run-detail-action"); button.type = "button"; buttons.set(key, button); }
        button.setAttribute("aria-controls", panel.id);
        /** Project a section disclosure onto its existing action button aria-expanded state. */
        const sync = () => button.setAttribute("aria-expanded", String(panel.open));
        sync();
        button.onclick = () => { panel.open = !panel.open; sync(); };
        panel.addEventListener("toggle", () => { if (panel.isConnected) sync(); });
        const current = actionContainer.querySelectorAll(".run-detail-action")[index];
        if (current !== button) actionContainer.insertBefore(button, current || null);
      });
    }
  }
  /** Render full/bounded context reads with associated validation text and unchanged scope persistence. */
  function contextControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged}) {
    if (!catalog) return;
    const explicit = scope === "run" ? run.context_read_policy : scope === "prompt" ? contextPolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = explicit || (scope === "global" ? catalog.product_default : catalog.context_read_policy);
    const box = node("article", "", "agent-check-row context-read-settings");
    box.dataset.settingSearch = "context attachments full read characters maximum limit";
    box.append(node("h4", "Context & Attachments"));
    const help = node("p", displayCopy("Return the complete attached Context when the agent requests it, if it fits the model’s available context window. smTO reports when a full source cannot fit; it does not silently truncate it."));
    help.id = `context-read-help-${++panelSequence}`;
    const toggle = switchControl("Read full attached context", policy.read_full_attached_context, help.id);
    const toggleLabel = node("label", "", "agent-check-toggle-row");
    toggleLabel.append(node("span", "Read full attached context"), toggle);
    const amount = fieldControl("input"); amount.type = "number"; amount.min = "1"; amount.step = "1"; amount.required = true;
    amount.value = policy.max_characters_per_read;
    amount.setAttribute("aria-label", "Maximum characters per Context read");
    const amountLabel = node("label", "Maximum characters per Context read"); amountLabel.append(amount);
    const boundedHelp = node("p", "Used when Full is off. Counts Unicode characters; larger model requests are clamped to this value.");
    const feedback = node("p"); feedback.id = `context-read-error-${panelSequence}`;
    feedback.setAttribute("role", "status"); feedback.setAttribute("aria-live", "polite");
    amount.setAttribute("aria-describedby", feedback.id);
    const historical = scope === "run" && terminal.has(run.status);
    toggle.disabled = Boolean(historical); amount.disabled = Boolean(historical || toggle.checked);
    const source = scope === "run" ? run.context_read_policy_source || "legacy"
      : scope === "global" ? catalog.global_source || "product_default" : explicit ? scope : catalog.context_read_policy_source;
    const sourceText = scope === "run" && !explicit ? "Historical run · legacy byte reads"
      : source === "global" ? (scope === "global" ? "Global setting" : "Inherited from Global") : source === "product_default" ? "Product default"
      : `Overridden for this ${source === "prompt" ? "prompt" : source}`;
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button"; reset.disabled = Boolean(historical);
    /** Save validated context intent and refresh; historical and full-read conditions still control editability. */
    async function save(value) {
      toggle.disabled = amount.disabled = reset.disabled = true;
      try {
        if (scope === "prompt") {
          if (value) contextDrafts.set(conversationId || "new", value); else contextDrafts.delete(conversationId || "new");
          onDraftChanged?.();
        } else await apiJson("/api/agent/context-read-policy", {method: "PUT", ...json({scope,
          conversation_id: conversationId || null, request_id: requestId || null, policy: value,
          policy_revision: scope === "run" ? run.context_read_policy_revision || 0 : null})});
        window.dispatchEvent(new Event("context-policy-changed"));
        await refresh();
      } catch (error) { window.SMTOErrors.present(feedback, error); notify(error); }
      finally { toggle.disabled = reset.disabled = Boolean(historical); amount.disabled = Boolean(historical || toggle.checked); }
    }
    /** Validate a positive whole context limit, associate any error, and save the existing policy schema. */
    const changed = () => {
      const value = Number(amount.value);
      if (!amount.value.trim() || !Number.isInteger(value) || value <= 0 || !Number.isFinite(value)) {
        feedback.textContent = "Enter a positive whole number of characters.";
        amount.setAttribute("aria-invalid", "true"); return;
      }
      amount.removeAttribute("aria-invalid"); feedback.textContent = "";
      void save({schema_version: 1, read_full_attached_context: toggle.checked, max_characters_per_read: value});
    };
    toggle.onchange = amount.onchange = changed; reset.onclick = () => void save(null);
    box.append(toggleLabel, help, amountLabel, boundedHelp, node("small", sourceText), feedback, reset);
    root.append(box);
  }

  /** Render stop mode and its conditional grace field; retain existing draft clearing and historical locks. */
  function lifecycleControls(root, catalog, {scope, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged}) {
    if (!catalog) return;
    const copy = catalog.messages;
    window.SMTOStopMessages = copy;
    const selected = scope === "run" ? run.stop_policy : scope === "prompt" ? stopPolicyForRequest(conversationId)
      : scope === "global" ? catalog.global : catalog.conversation_override;
    const policy = selected || (scope === "global" ? catalog.product_default : catalog.stop_policy);
    const box = node("article", "", "agent-check-row");
    box.dataset.settingSearch = "execution lifecycle stop behavior instant graceful timeout";
    box.append(node("h4", "Execution & Lifecycle"));
    const mode = fieldControl("select"); mode.setAttribute("aria-label", copy.behavior);
    for (const [value, label] of [["instant", copy.instant], ["graceful", copy.graceful_mode]]) {
      const option = node("option", label); option.value = value; mode.append(option);
    }
    mode.value = policy.mode;
    const label = node("label", copy.behavior); label.append(selectShell(mode));
    const timeout = fieldControl("input"); timeout.type = "number"; timeout.min = "0.1"; timeout.max = "300"; timeout.step = "0.1";
    timeout.value = policy.graceful_timeout_seconds; timeout.setAttribute("aria-label", copy.timeout);
    const grace = node("label", copy.timeout); grace.append(timeout); grace.hidden = mode.value !== "graceful";
    const help = node("p", mode.value === "instant" ? copy.instant_help : copy.graceful_help);
    const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
    const historical = scope === "run" && (terminal.has(run.status) || run.stop);
    mode.disabled = timeout.disabled = reset.disabled = Boolean(historical);
    /** Write stop intent to the selected scope, or retain it as a temporary prompt draft, then refresh. */
    async function save(policy) {
      try {
        if (scope === "prompt") {
          if (policy) stopDrafts.set(conversationId || "new", policy); else clearStopDraft(conversationId);
          onDraftChanged?.();
        } else await apiJson("/api/agent/stop-policy", {method: "PUT", ...json({scope, request_id: requestId,
          conversation_id: conversationId, policy})});
        await refresh();
      } catch (error) { notify(error); }
    }
    mode.onchange = timeout.onchange = () => {
      if (!timeout.checkValidity()) { timeout.reportValidity(); return; }
      void save({mode: mode.value, graceful_timeout_seconds: Number(timeout.value)});
    };
    reset.onclick = () => void save(null);
    box.append(label, grace, help, reset); root.append(box);
  }

  /** Mount or remove one inline policy panel while keeping its trigger relationship and expansion state. */
  function bindPanelToggle(control, root, options) {
    const id = `agent-check-panel-${++panelSequence}`;
    let mounted = null;
    control.setAttribute("aria-controls", id);
    control.setAttribute("aria-expanded", "false");
    control.onclick = () => {
      if (mounted?.element.isConnected) {
        mounted.element.remove(); mounted = null;
        control.setAttribute("aria-expanded", "false");
        return;
      }
      mounted = panel(root, options);
      mounted.element.id = id;
      mounted.element.classList.add("agent-check-inline-panel");
      control.setAttribute("aria-expanded", "true");
    };
  }

  /** Create an explicitly styled native checkbox switch with its accessible name and optional risk description. */
  function switchControl(name, checked, riskId) {
    const input = node("input", "", "mission-switch");
    input.type = "checkbox"; input.checked = checked;
    input.setAttribute("role", "switch"); input.setAttribute("aria-label", name);
    if (riskId) input.setAttribute("aria-describedby", riskId);
    return input;
  }

  /** Describe receipt execution truth, preserving unknown outcomes rather than implying a safe retry. */
  const strikeExecution = strike => strike.candidate_outcome === "unknown"
    ? "Execution outcome is unknown. This operation will not be automatically repeated."
    : strike.executed === false ? "The proposed operation was not executed." : "The operation executed. Its receipt is unchanged.";

  /** Reconcile current enforcement with earlier strike history and bind revision-aware per-run overrides. */
  function strikeCard(root, strike, policy, {requestId, status, apiJson, reload, notify = () => {}, conversationId}) {
    if (!strike?.guard_id) return; // External failures have no policy switch.
    const previous = [...root.children].find(child => child.dataset.guardId === strike.guard_id
      && child.dataset.requestId === requestId);
    const attempts = new Map(strikeAttempts.get(previous));
    attempts.set(strike.strike_id || JSON.stringify(strike), strike);
    // Replayed events update their attempt without replacing the latest rejection.
    strike = [...attempts.values()].at(-1);
    const card = node("details", "", "action-card agent-check-strike");
    card.dataset.strikeId = strike.strike_id;
    card.dataset.guardId = strike.guard_id; card.dataset.requestId = requestId;
    strikeAttempts.set(card, attempts);
    let disclosureState = strikeDisclosureState.get(root);
    if (!disclosureState) { disclosureState = new Map(); strikeDisclosureState.set(root, disclosureState); }
    const disclosureKey = JSON.stringify([requestId, strike.guard_id]);
    const lastCard = previous || disclosureState.get(disclosureKey);
    const known = strikeCurrentState.get(lastCard);
    const override = policy?.runtime_guard_overrides?.[strike.guard_id];
    const effective = override ?? policy?.runtime_guard_policy?.[strike.guard_id];
    const revision = (typeof effective === "boolean" ? policy.runtime_guard_revision : strike.policy_revision) ?? 0;
    // Replayed rejection events describe the old policy, not the current run.
    const keepKnown = known && (known.revision > revision || (effective == null && known.revision === revision));
    const current = {
      enabled: keepKnown ? known.enabled : effective ?? strike.enabled,
      source: keepKnown ? known.source : typeof override === "boolean" ? "run"
        : policy?.runtime_guard_sources?.[strike.guard_id] || strike.policy_source,
      revision: keepKnown ? known.revision : revision,
      status: terminal.has(known?.status) ? known.status : status || known?.status,
    };
    strikeCurrentState.set(card, current);
    // Checks start collapsed; later refreshes keep the user's choice.
    // Read the disclosure itself: queued toggle events from replaced cards can be stale.
    card.open = current.enabled === false && known?.enabled !== false
      ? false : lastCard?.open ?? false;
    disclosureState.set(disclosureKey, card);
    const risk = node("p", `Risk if disabled · ${strike.risk_level}: ${strike.risk_warning}`);
    risk.id = `guard-risk-${strike.strike_id}`;
    const title = node("summary"), titleText = node("span", "", "agent-check-summary-text"), problem = node("p");
    const summaryToggle = switchControl(`Enforce ${strike.guard_id} for this run`, current.enabled, risk.id);
    // The switch changes enforcement without activating the disclosure.
    summaryToggle.onclick = event => event.stopPropagation();
    summaryToggle.onkeydown = event => event.stopPropagation();
    title.append(titleText, summaryToggle);
    const instructionLabel = node("strong", displayCopy("What smTO asked the model to do"));
    const instruction = node("p", strike.model_instruction), execution = node("p", strikeExecution(strike));
    card.append(title, problem, instructionLabel, instruction, execution, risk);
    const row = node("label", "", "agent-check-toggle-row");
    const toggle = switchControl(`Enforce ${strike.guard_id} for this run`, current.enabled, risk.id);
    const value = node("span");
    row.append(node("span", "Enforce this check for this run"), toggle, value);
    const policyText = node("p");
    const feedback = node("p"); feedback.setAttribute("role", "status"); feedback.setAttribute("aria-live", "polite");
    const history = node("details", "", "agent-check-attempts");
    history.open = lastCard?.querySelector(".agent-check-attempts")?.open ?? true;
    /** Refresh enforcement copy, historical read-only state and prior attempts from the current strike projection. */
    function updatePresentation() {
      const historical = terminal.has(current.status), earlier = historical || current.enabled === false;
      const label = strike.label || strike.title?.replace(/^Action Rejected · /, "") || strike.guard_id;
      titleText.textContent = historical ? `Task ${current.status} · ${label}`
        : earlier ? `Check disabled · ${label}` : strike.title;
      problem.textContent = earlier
        ? `Enforcement is ${current.enabled ? "ON" : "OFF"} for this run. Earlier rejections are recorded below.`
        : strike.problem;
      instructionLabel.hidden = instruction.hidden = execution.hidden = earlier;
      toggle.checked = summaryToggle.checked = current.enabled;
      toggle.disabled = summaryToggle.disabled = historical;
      value.textContent = current.enabled ? "ON" : "OFF";
      policyText.textContent = current.source === "run" ? "Run override · broader settings are unchanged"
        : `Current policy: ${value.textContent} · inherited from ${current.source}`;
      if (historical) feedback.textContent = "Historical run · read-only";
      const tableWrap = node("div", "", "agent-check-attempt-table-wrap");
      tableWrap.tabIndex = 0;
      tableWrap.setAttribute("role", "region");
      tableWrap.setAttribute("aria-label", "Rejected attempts; scroll to view all columns");
      const table = node("table", "", "agent-check-attempt-table");
      table.setAttribute("aria-label", `Rejected attempts · ${label}`);
      const head = node("thead"), headings = node("tr"), entries = node("tbody");
      for (const text of ["Action / attempt", "Rejection reason", "Model instruction", "Execution / policy"]) {
        const heading = node("th", text); heading.setAttribute("scope", "col"); headings.append(heading);
      }
      head.append(headings);
      let index = 0;
      for (const attempt of attempts.values()) {
        const entry = node("tr"), action = node("th");
        action.setAttribute("scope", "row");
        action.append(node("strong", `Attempt ${++index}`));
        action.append(node("small", attempt.blocked_operation_id ? `Operation: ${attempt.blocked_operation_id}`
          : attempt.decision_id ? `Decision: ${attempt.decision_id}` : "Action not recorded"));
        const reason = node("td", attempt.problem || "Reason not recorded");
        const instruction = node("td", attempt.model_instruction || "No instruction recorded");
        const outcome = node("td");
        outcome.append(node("p", strikeExecution(attempt)));
        if (typeof attempt.enabled === "boolean") outcome.append(node("small", `Enforcement at rejection: ${attempt.enabled ? "ON" : "OFF"}.`));
        entry.append(action, reason, instruction, outcome);
        entries.append(entry);
      }
      table.append(head, entries); tableWrap.append(table);
      history.replaceChildren(node("summary", earlier
        ? `${attempts.size} earlier rejected ${attempts.size === 1 ? "attempt" : "attempts"}`
        : `${attempts.size} rejected ${attempts.size === 1 ? "attempt" : "attempts"}`),
        node("p", earlier ? "These attempts were rejected under the policy in effect at the time."
          : "All rejected attempts are listed in recorded order."), tableWrap);
    }
    updatePresentation();
    let busy = false;
    /** Persist the requested guard setting and refresh its inline enforcement controls. */
    async function changeEnforcement(enabled) {
      if (busy || terminal.has(current.status)) return;
      busy = true; toggle.disabled = summaryToggle.disabled = true;
      try {
        const run = await apiJson(path(requestId));
        const updated = await apiJson(`${path(requestId)}/agent-checks/${encodeURIComponent(strike.guard_id)}`, {
          method: "PATCH", ...json({enabled, strike_id: strike.strike_id,
            ...(run.authority_request?.kind === "agent_check_override" && run.authority_request.safe_summary?.strike_id === strike.strike_id
              ? {authority_request_id: run.authority_request.authority_request_id} : {}),
            policy_revision: run.runtime_guard_revision || 0, origin: "inline_guard_strike"}),
        });
        Object.assign(current, {enabled: updated.effective_value, source: "run",
          revision: updated.policy_revision ?? updated.runtime_guard_revision ?? (run.runtime_guard_revision || 0) + 1,
          status: updated.status || current.status});
        if (current.enabled === false) card.open = false;
        feedback.textContent = updated.resume_action === "next_operation_boundary"
          ? "Saved. Applies at the next operation boundary."
          : displayCopy("Run policy updated. smTO re-evaluated continuation under the current checks.");
        updatePresentation();
        toggle.disabled = summaryToggle.disabled = true;
        await reload?.(requestId);
      } catch (error) {
        toggle.checked = summaryToggle.checked = current.enabled;
        window.SMTOErrors.present(feedback, error); notify(error);
        if (error.status === 409) await reload?.(requestId);
      } finally { busy = false; toggle.disabled = summaryToggle.disabled = terminal.has(current.status); }
    }
    toggle.onchange = () => changeEnforcement(toggle.checked);
    summaryToggle.onchange = () => changeEnforcement(summaryToggle.checked);
    const manage = node("button", "Policy settings", "action-button"); manage.type = "button";
    bindPanelToggle(manage, card, {apiJson, requestId, conversationId, initialScope: "run", guardId: strike.guard_id,
      focus: strike.guard_id, notify, reload});
    card.append(row, policyText, manage, feedback, history);
    if (previous) previous.replaceWith(card); else root.append(card);
    return card;
  }

  /** Attach relaxed-check actions and strike disclosures from a trace without issuing model requests. */
  function render(root, trace, hooks) {
    const actionRoot = hooks.actionRoot || root, panelRoot = hooks.panelRoot || root;
    if (actionRoot !== root) actionRoot.querySelector(".agent-check-relaxed")?.remove();
    if (panelRoot !== root) panelRoot.replaceChildren();
    const policy = stateOf(trace);
    if (!policy) return false;
    window.SMTOResourceReconciliation?.render(root, policy, hooks);
    const status = trace.outcome || trace.final_status || trace.status;
    if (policy.guards_relaxed) {
      const link = node("button", `Agent Checks relaxed · ${policy.guards_relaxed}`, "agent-check-relaxed");
      link.type = "button";
      bindPanelToggle(link, panelRoot, {...hooks, initialScope: "run"});
      const fork = actionRoot.querySelector(".task-fork-action");
      if (fork) actionRoot.insertBefore(link, fork); else actionRoot.append(link);
      actionRoot.hidden = false;
    }
    for (const strike of policy.guard_strikes || []) strikeCard(root, strike, policy, {...hooks, status});
    return true;
  }

  /** Mount scoped policy controls; async refresh generations prevent stale catalogs replacing newer selections. */
  function panel(root, {apiJson, requestId, conversationId, initialScope = "prompt", focus, guardId,
    notify = () => {}, reload, draft = {}, allowPrompt = false, showLifecycle = true, showContext = true, showParallel = true, composerSettings = null, onDraftChanged = () => {}, onRendered = () => {}}) {
    const box = node("section", "", "agent-check-panel");
    box.append(node("h3", guardId ? "Policy settings" : "Agent Checks"));
    const scope = fieldControl("select"); scope.setAttribute("aria-label", "Agent Checks scope");
    for (const [value, label] of [["run", "This run"], ["prompt", "This prompt"], ["conversation", "This conversation"], ["global", "Global"]]) {
      if (value === "run" && !requestId || value === "prompt" && (requestId && !allowPrompt || initialScope === "global") || value === "conversation" && !conversationId) continue;
      const option = node("option", label); option.value = value; scope.append(option);
    }
    scope.value = initialScope;
    const copy = node("p"), rows = node("div");
    box.append(selectShell(scope), copy, rows); root.append(box);
    let generation = 0;
    /** Fetch the current scope snapshot and rebuild fields only if this panel and refresh generation remain current. */
    async function refresh() {
      await window.SMTOReadPriority?.ready;
      const version = ++generation, selected = scope.value;
      try {
        const catalog = await apiJson(`/api/agent/runtime-guards${conversationId ? `?conversation_id=${encodeURIComponent(conversationId)}` : ""}`);
        const run = selected === "run" ? await apiJson(path(requestId)) : null;
        if (version !== generation || !box.isConnected) return;
        copy.textContent = selected === "run" ? "Changes apply only to this run."
          : selected === "prompt" ? "Captured when this prompt is accepted."
          : selected === "conversation" ? "Applies to future tasks in this conversation."
          : "Applies globally to future tasks.";
        rows.replaceChildren();
        if (selected === "prompt" && composerSettings && !guardId) {
          integrityControls(rows, {conversationId, settings: composerSettings, onDraftChanged});
        }
        if (showParallel && !guardId) {
          parallelControls(rows, catalog.parallel_execution, {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
          backgroundControls(rows.querySelector(".asynchronous-task-execution") || rows, catalog.background_activities,
            {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
          dependencyControls(rows.querySelector(".asynchronous-task-execution") || rows, catalog.dependency_scheduling,
            {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
          resourceControls(rows.querySelector(".asynchronous-task-execution") || rows, catalog.resource_scheduling,
            {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
        }
        if (showLifecycle && !guardId) lifecycleControls(rows, catalog.lifecycle, {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
        if (showContext && !guardId) contextControls(rows, catalog.attached_context, {scope: selected, requestId, conversationId, run, apiJson, refresh, notify, onDraftChanged});
        let category = "";
        for (const guard of catalog.checks) {
          if (guardId && guard.id !== guardId) continue;
          if (["mutation.reconciliation", "mutation.job_conflict"].includes(guard.id)) {
            const row = node("article", "", "agent-check-row");
            row.dataset.settingSearch = `${guard.label} resource locking`;
            const link = node("a", "Managed globally in Resource locking");
            link.href = "/settings#settings-section-resource-locking";
            row.append(node("h4", guard.label), link); rows.append(row); continue;
          }
          if (guard.category !== category) { category = guard.category; rows.append(node("h4", category)); }
          const row = node("article", "", "agent-check-row"); row.dataset.guardId = guard.id;
          const searchText = [guard.id, guard.label, guard.category, guard.description,
            guard.risk_level, guard.risk_warning, guard.problem, guard.model_instruction,
            guard.bypass_semantics].filter(Boolean).join(" ").toLowerCase().replace(/\s+/g, " ");
          // Retain exact IDs and also match natural-language spellings of them.
          row.dataset.settingSearch = `${searchText} ${searchText.replace(/[._-]+/g, " ")}`;
          const explicit = selected === "prompt" ? draft[guard.id]
            : selected === "run" ? run.runtime_guard_overrides?.[guard.id]
            : catalog.scope_overrides?.[selected]?.[guard.id];
          const enabled = typeof explicit === "boolean" ? explicit : selected === "run" ? run.runtime_guard_policy[guard.id]
            : selected === "global" ? catalog.scope_overrides?.global?.[guard.id] ?? guard.product_default
            : catalog.runtime_guard_policy[guard.id];
          const risk = node("p", `Risk if disabled · ${guard.risk_level}: ${guard.risk_warning}`);
          risk.id = `panel-risk-${selected}-${guard.id.replaceAll(".", "-")}`;
          const toggle = switchControl(guard.label, enabled, risk.id);
          const label = node("label", "", "agent-check-toggle-row");
          const value = node("span", enabled ? "ON" : "OFF");
          label.append(node("span", guard.label), toggle, value);
          const reset = node("button", "Use inherited setting", "action-button"); reset.type = "button";
          const historical = selected === "run" && terminal.has(run.status);
          toggle.disabled = reset.disabled = historical;
          const source = selected === "run" ? run.runtime_guard_sources?.[guard.id]
            : typeof explicit === "boolean" ? selected : selected === "global" ? "product_default" : guard.source;
          row.append(label, node("p", window.SMTOBranding?.text(guard.description) ?? guard.description), risk, node("small", `Policy source: ${source}`), reset);
          rows.append(row);
          /** Save/reset one guard in the selected scope; per-run writes retain the observed revision and origin. */
          async function save(enabled) {
            toggle.disabled = reset.disabled = true;
            try {
              if (selected === "prompt") {
                if (enabled === null) delete draft[guard.id]; else draft[guard.id] = enabled;
                onDraftChanged();
              } else if (selected === "run") {
                await apiJson(`${path(requestId)}/agent-checks/${encodeURIComponent(guard.id)}`, {method: "PATCH",
                  ...json({enabled, policy_revision: run.runtime_guard_revision || 0, origin: "agent_checks_panel"})});
                await reload?.(requestId);
              } else await apiJson("/api/agent/runtime-guards", {method: "PUT",
                ...json({guard_id: guard.id, scope: selected, conversation_id: conversationId || null, enabled})});
              await refresh();
            } catch (error) { notify(error); toggle.checked = !toggle.checked; }
            finally { toggle.disabled = reset.disabled = historical; }
          }
          toggle.onchange = () => save(toggle.checked); reset.onclick = () => save(null);
          if (focus === guard.id) { row.tabIndex = -1; row.focus(); }
        }
        onRendered();
      } catch (error) { window.SMTOErrors.present(copy, error); }
    }
    scope.onchange = refresh; void refresh();
    return {refresh, element: box};
  }
  function observationGroup(actionContainer, current, after = actionContainer) {
    if (current) return current;
    const disclosure = node("details", "", "execution-inspection agent-check-observations");
    const summary = node("summary");
    summary.append(node("span", "Checks triggered during this run", "execution-inspection-title"));
    const items = node("div", "", "execution-inspection-group");
    disclosure.append(summary, items);
    after.after(disclosure);
    const shortcut = window.SMTOConversationSnapshot.disclosureAction({
      actionContainer, panel: disclosure, label: "Checks triggered"});
    shortcut.action.classList.add("run-checks-action");
    return {root: disclosure, items, seen: new Set(),
      dispose() { shortcut.dispose(); disclosure.remove(); }};
  }
  function observationCard(root, detail) {
    const card = document.createElement("div");
    card.className = "model-step agent-check-observation"; card.dataset.level = "info";
    const title = document.createElement("strong");
    title.textContent = detail.guard_label ? `The “${detail.guard_label}” check` : "An agent check";
    const copy = document.createElement("span");
    copy.textContent = " was triggered; the agent continued because it is ";
    const status = document.createElement("span");
    status.className = "agent-check-observation-status";
    status.textContent = "disabled. ";
    const link = document.createElement("a"); link.textContent = "Learn more ↗";
    const doc = String(detail.manual_doc_id || "checks-authority");
    link.href = window.SMTOManualLinks.manualUrl(/^[a-z0-9-]+$/.test(doc) ? doc : "checks-authority");
    link.target = "_blank"; link.rel = "noopener";
    status.append(link);
    card.append(title, copy, status); root?.append(card); return card;
  }
  window.SMTOAgentChecks = {observationGroup,observationCard,integrityForRequest, setIntegrityDraft, integrityView, integrityControls, render, panel, strikeCard, stateOf, stopPolicyForRequest, clearStopDraft, lifecycleControls, contextControls, contextPolicyForRequest, contextPolicyLabel,
    parallelControls, parallelPolicyForRequest, setParallelDraft, backgroundControls, backgroundPolicyForRequest, setBackgroundDraft, dependencyControls, dependencyPolicyForRequest, setDependencyDraft, resourceControls, resourcePolicyForRequest, setResourceDraft, schedulingPreferenceForRequest, schedulingControls, activities};
})();
