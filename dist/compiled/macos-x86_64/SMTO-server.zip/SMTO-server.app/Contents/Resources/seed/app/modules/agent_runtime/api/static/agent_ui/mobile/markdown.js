// HTML is never interpreted. This bounded renderer constructs all markup as DOM nodes.
import { node, button, safeUrl, notice } from "./api.js";

const sources = new WeakMap();
export function trackArtifactSources(root) {
  for (const element of root.querySelectorAll(".markdown")) {
    const source = sources.get(element);
    if (source !== undefined) window.SMTOMarkdown?.track(element, source, markdown);
  }
}
export function copyButton(value, {icon = false} = {}) {
  const copy = button("Copy", async () => {
    try {
      await navigator.clipboard.writeText(
        typeof value === "function" ? await value() : value,
      );
      copied();
    } catch {
      notice(
        "Could not copy the full content. Try again.",
      );
    }
  });
  if (icon) copy.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
  const copied = window.SMTOCopyFeedback.bind(copy);
  return copy;
}
function inline(parent, text, depth = 0) {
  if (depth > 6) {
    parent.append(document.createTextNode(text));
    return;
  }
  const pattern =
    /(!?\[([^\]\n]*)\]\(<?([^\s)>]+)>?(?:\s+"[^"\n]*")?\)|`([^`\n]+)`|\*\*([^*\n]+)\*\*|__([^_\n]+)__|\*([^*\n]+)\*|_([^_\n]+)_)/g;
  let offset = 0;
  for (const match of text.matchAll(pattern)) {
    parent.append(document.createTextNode(text.slice(offset, match.index)));
    let element;
    if (match[2] !== undefined) {
      const image = match[0].startsWith("!"),
        filesystem = /^(?:\/(?!api\/agent\/file)|[a-z]:[\\/]|file:)/i.test(match[3]),
        url = filesystem ? null : safeUrl(match[3], { image });
      if (match[3].startsWith("artifact:")) {
        element = node("span");
        const id = /^artifact:\/\/(art_[a-f0-9]{32})$/.exec(match[3])?.[1];
        element.textContent = `Artifact unavailable · ${match[2]}`;
        if (id) {
          element.className = "artifact-reference"; element.dataset.artifactId = id;
          element.dataset.artifactLabel = match[2]; element.dataset.artifactImage = String(image);
        }
      } else if (url && !image) {
        element = node("a");
        element.href = url;
        element.rel = "noopener noreferrer";
        element.target = "_blank";
        inline(element, match[2], depth + 1);
      } else element = node("span", match[2]);
    } else if (match[4]) element = node("code", match[4]);
    else {
      element = node(match[5] || match[6] ? "strong" : "em");
      inline(element, match[5] || match[6] || match[7] || match[8], depth + 1);
    }
    parent.append(element);
    offset = match.index + match[0].length;
  }
  parent.append(document.createTextNode(text.slice(offset)));
}
export function markdown(root, source) {
  sources.set(root, source);
  window.SMTOMarkdown?.track(root, source, markdown);
  const restore = window.SMTOArtifacts?.capture(root);
  const lines = String(source || "")
    .replace(/\r\n?/g, "\n")
    .split("\n");
  const fragment = document.createDocumentFragment();
  const cells = (line) =>
    line
      .trim()
      .replace(/^\||\|$/g, "")
      .split("|")
      .map((v) => v.trim());
  for (let i = 0; i < lines.length; ) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    const fence = line.match(/^\s*(`{3,}|~{3,})(.*)$/);
    if (fence) {
      const content = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith(fence[1]))
        content.push(lines[i++]);
      if (i < lines.length) i++;
      const block = node("div", null, "code-block"),
        bar = node("div", null, "code-bar");
      bar.append(node("span", fence[2].trim()), copyButton(content.join("\n")));
      const pre = node("pre");
      pre.append(node("code", content.join("\n")));
      block.append(bar, pre);
      fragment.append(block);
      continue;
    }
    if (
      i + 1 < lines.length &&
      line.includes("|") &&
      /^\s*\|?\s*:?-{3,}/.test(lines[i + 1])
    ) {
      const wrap = node("div", null, "table-wrap"),
        table = node("table"),
        head = node("tr");
      cells(line).forEach((value) => {
        const cell = node("th");
        inline(cell, value);
        head.append(cell);
      });
      const thead = node("thead");
      thead.append(head);
      table.append(thead);
      i += 2;
      const body = node("tbody");
      while (i < lines.length && lines[i].includes("|") && lines[i].trim()) {
        const row = node("tr");
        cells(lines[i++]).forEach((value) => {
          const cell = node("td");
          inline(cell, value);
          row.append(cell);
        });
        body.append(row);
      }
      table.append(body);
      wrap.append(table);
      fragment.append(wrap);
      continue;
    }
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) {
      const h = node(`h${heading[1].length}`);
      inline(h, heading[2]);
      fragment.append(h);
      i++;
      continue;
    }
    if (/^\s*(?:---+|\*\*\*+|___+)\s*$/.test(line)) {
      fragment.append(node("hr"));
      i++;
      continue;
    }
    if (/^\s*>/.test(line)) {
      const block = node("blockquote"),
        content = [];
      while (i < lines.length && /^\s*>/.test(lines[i]))
        content.push(lines[i++].replace(/^\s*>\s?/, ""));
      markdown(block, content.join("\n"));
      fragment.append(block);
      continue;
    }
    const item = line.match(/^\s*(?:([-+*])|(\d+)[.)])\s+(.+)$/);
    if (item) {
      const list = node(item[2] ? "ol" : "ul");
      if (item[2]) list.start = Number(item[2]);
      while (i < lines.length) {
        const match = lines[i].match(/^\s*(?:([-+*])|(\d+)[.)])\s+(.+)$/);
        if (!match || Boolean(match[2]) !== Boolean(item[2])) break;
        const li = node("li");
        inline(li, match[3]);
        list.append(li);
        i++;
      }
      fragment.append(list);
      continue;
    }
    const paragraph = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() &&
      !/^\s*(?:#{1,6}\s|>|[-+*]\s|\d+[.)]\s|`{3}|~{3})/.test(lines[i]) &&
      !(lines[i].includes("|") && /^\s*\|?\s*:?-{3,}/.test(lines[i + 1] || ""))
    )
      paragraph.push(lines[i++]);
    const p = node("p");
    inline(p, paragraph.join("\n"));
    fragment.append(p);
  }
  root.replaceChildren(fragment);
  root.classList.add("markdown");
  restore?.();
  window.SMTOArtifacts?.hydrate(root);
  if (root.querySelector(".artifact-reference")) root.dispatchEvent(new Event("mobile-artifact-reference", {bubbles: true}));
}
