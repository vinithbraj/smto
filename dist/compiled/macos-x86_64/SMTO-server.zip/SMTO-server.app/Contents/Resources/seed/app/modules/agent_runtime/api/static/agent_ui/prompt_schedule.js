/* Lazy presentation cache; all identity matching and creation are server-authoritative. */
(() => {
  "use strict";
  const icon = status => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3v4m8-4v4M4 10h16M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1Z"/><path data-ui-symbol="${status === "active" ? "check" : ""}" d="${status === "active" ? "m8 15 3 3 5-5" : status === "paused" ? "M10 13v5m4-5v5" : "M12 12v6m-3-3h6"}"/></svg>`;
  const normal = prompt => String(prompt || "").normalize("NFC").replace(/\r\n?/g, "\n").trim();
  const eligible = prompt => Boolean(normal(prompt)) && !normal(prompt).startsWith("/");
  function create({notify = () => {}, executionSnapshot = () => null} = {}) {
    const editor = window.SMTOScheduleEditor.create();
    const cache = new Map(), pending = new Map(), buttons = new Set();
    let generation = 0, opening = false;
    function paint(button, event) {
      const status = event?.status;
      button.dataset.scheduleStatus = status || "none";
      button.innerHTML = icon(status);
      button.title = status === "paused" ? "View paused schedule" : status === "active" ? "View scheduled prompt" : "Schedule prompt";
      button.setAttribute("aria-label", status ? button.title : "Schedule this prompt");
    }
    function apply(prompt, event) {
      const key = normal(prompt); cache.set(key, event);
      for (const item of buttons) {
        if (!item.button.isConnected) { buttons.delete(item); continue; }
        if (item.key === key) paint(item.button, event);
      }
    }
    async function resolve(prompt, force = false) {
      const key = normal(prompt);
      if (!force && cache.has(key)) return {event: cache.get(key)};
      if (pending.has(key)) return pending.get(key);
      const version = generation;
      const work = window.SMTOScheduleEditor.api("/prompt-schedule/resolve", "POST", {prompt}).then(result => {
        if (version !== generation) { pending.delete(key); return resolve(prompt, true); }
        apply(prompt, result.event);
        return result;
      }).finally(() => { if (pending.get(key) === work) pending.delete(key); });
      pending.set(key, work); return work;
    }
    async function open(prompt, requestId = "", options = {}) {
      if (opening || !eligible(prompt)) return;
      opening = true;
      try {
        const execution = executionSnapshot();
        const result = await resolve(prompt, true);
        editor.open(result.event, {prompt, requestId, title: result.suggested_title, ...options, execution});
      } catch (error) { notify(error.message); }
      finally { opening = false; }
    }
    function attach(row, prompt, requestId) {
      if (!eligible(prompt)) return;
      const button = document.createElement("button"); button.type = "button"; button.className = "prompt-schedule-action";
      button.setAttribute("aria-haspopup", "dialog");
      paint(button, cache.get(normal(prompt)));
      buttons.add({button, key: normal(prompt), prompt}); row.append(button);
      const preload = () => { void resolve(prompt).catch(() => {}); };
      button.addEventListener("pointerenter", preload); button.addEventListener("focus", preload);
      button.addEventListener("click", () => { void open(prompt, requestId); });
    }
    window.addEventListener("smto:schedule-saved", e => { if (e.detail.prompt) apply(e.detail.prompt, e.detail.event); });
    function invalidate() {
      generation += 1; cache.clear();
      const observed = new Map();
      for (const item of buttons) {
        if (!item.button.isConnected) { buttons.delete(item); continue; }
        if (item.button.dataset.scheduleStatus !== "none") observed.set(item.key, item.prompt);
        paint(item.button, null);
      }
      for (const prompt of observed.values()) void resolve(prompt, true).catch(() => {});
    }
    window.SMTOUiUpdates?.subscribe(["events.changed"], invalidate);
    return {attach, open, eligible, openWorkflow: source => editor.open(null, source)};
  }
  window.SMTOPromptSchedule = {create, icon};
})();
