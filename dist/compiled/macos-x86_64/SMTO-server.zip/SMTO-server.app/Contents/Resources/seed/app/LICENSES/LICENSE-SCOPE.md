# SMTO release license scope

Release: dev.4c9a113b9126.20261022.20261022T033612346297Z

Source revision: 4c9a113b91264fd4c3f82ad6bb3a30b9e4184041

Target: macos-x86_64; component: server

Review decision: HOLD

This inventory does not designate any material as newly proprietary. Earlier grants and component-specific rights remain effective. Dates and file paths alone do not establish ownership.

See LICENSE-SCOPE.json for material boundaries, evidence and unresolved reviews. See third-party/manifest.json and bom.json for component-specific notices. The first-party metadata does not license the entire mixed payload.
