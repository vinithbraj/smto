/* A task fork is application data manipulation, never a submitted Agent prompt. */
(() => {
  "use strict";
  const terminal = new Set(["completed", "answered", "partial", "failed", "blocked", "cancelled", "interrupted"]);
  function create({apiJson, currentId, openConversation, conversationUrl, focusComposer, notify}) {
    const requests = new Map();
    function attach(turn) {
      const conversationId = currentId();
      if (!conversationId || !turn.requestId) return;
      const key = `${conversationId}:${turn.requestId}`;
      const request = requests.get(key) || {id: null, busy: false};
      requests.set(key, request);
      const action = turn.forkAction || document.createElement("button");
      if (!turn.forkAction) {
        turn.forkAction = action;
        action.type = "button";
        action.className = "task-fork-action";
        action.setAttribute("aria-label", "Continue task in new conversation");
        action.addEventListener("click", async () => {
          if (request.busy || !terminal.has(turn.activity.status)) return;
          request.id ||= `fork_${globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)}`;
          request.busy = true;
          draw();
          const sourceId = currentId();
          try {
            const result = await apiJson(
              `/api/agent/chats/${encodeURIComponent(conversationId)}/tasks/${encodeURIComponent(turn.requestId)}/fork`,
              {method: "POST", headers: {"Content-Type": "application/json"},
                body: JSON.stringify({client_submission_id: request.id})},
            );
            request.id = null;
            if (sourceId === currentId() && turn.article.isConnected) {
              await openConversation(result.conversation_id);
              if (currentId() === result.conversation_id) focusComposer();
            }
          } catch (error) {
            // Keep the request identity: an uncertain response must be safe to retry.
            notify(error.message || "Could not create the conversation. Try again.");
          } finally {
            request.busy = false;
            draw();
          }
        });
      }
      function draw() {
        const ended = terminal.has(turn.activity.status);
        action.disabled = request.busy || !ended;
        action.textContent = request.busy ? "Creating conversation…" : "↗ Continue in new conversation";
        action.title = ended ? "Branch this conversation at this task" : "Available when this task has ended";
        action.setAttribute("aria-busy", String(request.busy));
      }
      draw();
      if (turn.runActions) {
        if (turn.runActions.firstChild !== action) turn.runActions.prepend(action);
      } else if (action.parentNode !== turn.meta) turn.meta.append(action);
    }
    function source(container, chat) {
      const handoff = chat.conversation_handoff?.schema_version === 2 ? chat.conversation_handoff : null;
      const snapshot = handoff ? {...handoff.selected_task, ...handoff.branch} : chat.source_task_context;
      if (!snapshot) return;
      const card = document.createElement("aside");
      card.className = "task-source-context";
      const label = handoff ? "Continued from previous conversation" : "Context from previous task";
      card.setAttribute("aria-label", label);
      const heading = document.createElement("strong");
      heading.textContent = `↗ ${label}`;
      const request = document.createElement("p");
      request.textContent = snapshot.original_request;
      const status = document.createElement("span");
      status.textContent = (snapshot.status || "").replaceAll("_", " ");
      status.className = "task-source-status";
      const link = document.createElement("a");
      const url = new URL(conversationUrl(snapshot.source_conversation_id), location.href);
      url.searchParams.set("task", snapshot.source_request_id);
      link.href = url.href;
      link.textContent = "View source";
      function unavailable() {
        link.removeAttribute("href");
        link.textContent = "Source unavailable";
        link.setAttribute("aria-disabled", "true");
      }
      if (chat.source_available === false) unavailable();
      link.addEventListener("click", async event => {
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        if (!link.hasAttribute("href")) return;
        try {
          await apiJson(`/api/agent/chats/${encodeURIComponent(snapshot.source_conversation_id)}`, {method: "HEAD"});
          if (card.isConnected) await openConversation(snapshot.source_conversation_id, {sourceRequestId: snapshot.source_request_id});
        } catch (_) { unavailable(); }
      });
      card.append(heading, request, status, link);
      if (handoff) {
        const details = document.createElement("p");
        details.className = "muted";
        const resources = Object.keys(handoff.seed.conversation_working_context.resources || {}).length;
        details.textContent = `Inherited context: ${handoff.history_archive.turn_count} prior turns · ${resources} working resources · ${handoff.seed.context_assets.length} context files`;
        card.append(details);
      }
      const omitted = handoff?.seed.omitted_context_assets ?? snapshot.omitted_attachments;
      if (omitted) {
        const note = document.createElement("p");
        note.className = "muted";
        note.textContent = `${omitted} source attachment(s) could not be carried forward.`;
        card.append(note);
      }
      container.append(card);
    }
    return {attach, source};
  }
  window.SMTOTaskFork = {create};
})();
