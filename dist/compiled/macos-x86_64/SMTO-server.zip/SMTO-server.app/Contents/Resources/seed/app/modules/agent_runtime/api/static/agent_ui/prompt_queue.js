/**
 * @file src/agent_runtime/api/static/agent_ui/prompt_queue.js
 * @brief Project the server-owned conversation lane and edit queued user intent.
 * @details
 * Responsibilities: Render queued prompts, edit/reorder actions, steering.
 * Boundaries: The server owns execution order, admission and task outcomes; the browser does not schedule work.
 * Lifecycle: Lane snapshots render rows; explicit actions call queue APIs and reconcile their results.
 * State: Controller generations isolate conversation changes; durable lane data comes from the server.
 * Security: Prompt validation retains length/command boundaries; the queue does not collect credential fields.
 * Collaborators: app.js supplies conversation/API hooks; prompt_queue.css owns layout;
 *   agent_checks.css styles the native queued-prompt textarea through chat-field-control.
 * Public surface: SMTOPromptQueue exposes queue binding and current submission validation.
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/api/static/agent_ui/prompt_queue.css
 */
(() => {
  "use strict";
  const LIMIT = 32;
  const SUCCESS = new Set(["completed", "answered"]);
  const FAILED = new Set(["failed", "cancelled"]);
  const HARD_BLOCK = new Set(["interrupted"]);
  const STEERABLE = new Set(["running", "waiting_job", "waiting_event", "paused", "paused_budget"]);
  const INTERACTION = new Set(["waiting_user", "awaiting_confirmation", "awaiting_clarification"]);
  const clone = value => JSON.parse(JSON.stringify(value));
  const policyKeys = ["preferred_skill_ids", "excluded_skill_ids", "preferred_tool_ids", "excluded_tool_ids",
    "preferred_shell_executables", "excluded_shell_executables"];
  const permissionIntent = policy => policy === null ? null : window.SMTOPermissionPolicy.canonical(policy || {});
  const sameEnvelope = (a, b) => a && b && a.gateway_id && ["gateway_id", "agent_mode", "llm_model", "conversation_id"].every(k => (a[k] || null) === (b[k] || null))
    && JSON.stringify(a.gateway_selection || {schema_version: 1, gateway_ids: [a.gateway_id], primary_gateway_id: a.gateway_id})
      === JSON.stringify(b.gateway_selection || {schema_version: 1, gateway_ids: [b.gateway_id], primary_gateway_id: b.gateway_id})
    && (a.collaboration_mode || a.composer_values?.collaboration_mode || "default") === (b.collaboration_mode || b.composer_values?.collaboration_mode || "default")
    && (a.behavior_effort || "medium") === (b.behavior_effort || "medium")
    && (a.context_carry_forward?.mode || "all") === (b.context_carry_forward?.mode || "all")
    && (a.context_carry_forward?.mode !== "rolling" || a.context_carry_forward.window_size === b.context_carry_forward?.window_size)
    && (!a.task_contract_compilation_enabled || (a.task_contract_integrity_guard_enabled ?? false) === (b.task_contract_integrity_guard_enabled ?? false))
    && JSON.stringify(a.stop_policy || null) === JSON.stringify(b.stop_policy || null)
    && JSON.stringify(a.parallel_execution_policy || null) === JSON.stringify(b.parallel_execution_policy || null)
    && JSON.stringify(a.background_activity_policy || null) === JSON.stringify(b.background_activity_policy || null)
    && JSON.stringify(a.dependency_scheduling_policy || null) === JSON.stringify(b.dependency_scheduling_policy || null)
    && JSON.stringify(a.scheduling_preference || null) === JSON.stringify(b.scheduling_preference || null)
    && JSON.stringify(a.resource_scheduling_policy || null) === JSON.stringify(b.resource_scheduling_policy || null)
    && JSON.stringify(a.context_read_policy || null) === JSON.stringify(b.context_read_policy || null)
    && JSON.stringify(a.runtime_guard_policy || {}) === JSON.stringify(b.runtime_guard_policy || {})
    && JSON.stringify(a.capability_selection || null) === JSON.stringify(b.capability_selection || null)
    && JSON.stringify(a.native_behavior_policy || null) === JSON.stringify(b.native_behavior_policy || null)
    && JSON.stringify([...a.context_refs].sort()) === JSON.stringify([...b.context_refs].sort())
    && JSON.stringify(permissionIntent(a.permission_policy)) === JSON.stringify(permissionIntent(b.permission_policy))
    && policyKeys.every(k => JSON.stringify([...(a.capability_policy[k] || [])].sort()) === JSON.stringify([...(b.capability_policy[k] || [])].sort()));
  const submissionFailure = "Previous request could not be started. Queue paused.";
  const waitingPredecessor = "The preceding task is still active or waiting. Resume or cancel it before running next.";
  const interruptedPredecessor = "Previous task was interrupted and the runtime could not confirm every external effect. Queue paused. Use Continue task to reconcile it.";
  function checkText(text) {
    if (typeof text !== "string" || !text.trim() || text.length > 24000) throw window.SMTOErrors.error("ui_prompt_invalid");
    if (text.trim().startsWith("/")) throw window.SMTOErrors.error("ui_command_not_queueable");
  }
  window.SMTOPromptQueue = {create(hooks) {
    const root = hooks.root;
    let lane = null, ready = false, editing = "", busy = false, refreshPromise = null, refreshAgain = false;
    let enqueueChain = Promise.resolve(), generation = 0, lastError = "", lastFailure = null;
    let expanded = window.SMTOUiSession?.get("prompt_queue_expanded", false) ?? false;
    const recovered = new Set();
    const pending = new Map();
    const base = cid => `/api/agent/conversations/${encodeURIComponent(cid)}/task-lane`;
    const taskUrl = task => `/api/agent/tasks/${encodeURIComponent(task.task_id)}`;
    const waitReason = task => {
      const dependency = window.SMTOTaskDependencies?.describe(task, lane?.tasks || []) || "";
      return task.queue_block?.kind === "dependency_unsatisfied"
        ? dependency || task.queue_block.reason
        : task.queue_block?.reason || dependency;
    };
    const snapshotOf = task => task.context ? ({client_submission_id: task.client_submission_id, task_id: task.task_id, prompt: task.prompt, agent_mode: task.agent_mode,
      conversation_id: task.conversation_id, collaboration_mode: task.context.collaboration_mode || "default", gateway_id: task.gateway_id,
      gateway_selection: clone(task.context.gateway_selection || {schema_version: 1, gateway_ids: [task.gateway_id], primary_gateway_id: task.gateway_id}),
      gateway_label: task.context.gateway_label || task.gateway_id,
      gateway_locality: task.context.gateway_locality || "unknown", llm_model: task.context.llm_model,
      context_refs: task.context.context_refs || [], capability_policy: task.context.native_capability_policy || {},
      capability_selection: task.context.capability_selection_config || {mode: "manual"},
      behavior_effort: task.context.behavior_effort || "medium",
      context_carry_forward: task.context.context_carry_forward || {mode: "all"},
      runtime_guard_policy: task.context.runtime_guard_policy || {},
      stop_policy: task.context.stop_policy,
      context_read_policy: task.context.context_read_policy,
      task_contract_compilation_enabled: task.context.task_contract_compilation_enabled === true,
      task_contract_integrity_guard_enabled: task.context.task_contract_integrity_guard_enabled ?? false,
      parallel_execution_policy: task.context.parallel_execution_policy,
      background_activity_policy: task.context.background_activity_policy,
      dependency_scheduling_policy: task.context.dependency_scheduling_policy,
      resource_scheduling_policy: task.context.resource_scheduling_policy,
      scheduling_preference: task.context.scheduling_preference,
      native_behavior_policy: task.context.native_behavior_policy || null,
      permission_policy: task.context.native_permission_policy === null ? null : task.context.native_permission_policy || {}}) : null;
    const json = (method, body) => ({method, headers: {"Content-Type": "application/json"},
      ...(body === undefined ? {} : {body: JSON.stringify(body)})});
    function changed() { render(); hooks.changed?.(); }
    function button(label, action, disabled = false, title = "") {
      const b = document.createElement("button"); b.type = "button"; b.textContent = label;
      b.disabled = disabled; b.title = title; b.onclick = action; return b;
    }
    async function action(url, method, body) {
      if (busy) return;
      busy = true; changed();
      try { await hooks.apiJson(url, json(method, body)); editing = ""; }
      catch (error) { hooks.notify(error.message); }
      finally { busy = false; await reconcile(); changed(); }
    }
    function render() {
      window.SMTOTaskDependencies?.composer(lane, hooks.conversationId());
      if (editing && root.querySelector("textarea")) return;
      const refocusToggle = root.querySelector(".prompt-queue-toggle") === document.activeElement;
      root.replaceChildren();
      const items = lane?.queued_tasks || [];
      root.hidden = !items.length && (!lane || lane.block.kind === "none");
      if (root.hidden) return;
      const header = document.createElement("div"); header.className = "prompt-queue-header";
      const title = document.createElement("strong"); title.textContent = `Queued · ${items.length}`;
      const content = document.createElement("div"); content.className = "prompt-queue-content";
      content.id = `${root.id || "prompt-queue"}-content`;
      const waiting = items.find(task => ["waiting", "blocked"].includes(task.dependency?.state));
      const summary = document.createElement("p"); summary.className = "prompt-queue-status";
      summary.dataset.dependencyState = waiting?.dependency?.state || "";
      summary.setAttribute("role", "status");
      summary.textContent = items.length ? waitReason(items[0]) : waiting ? waitReason(waiting) : "";
      const chevron = document.createElement("span"); chevron.setAttribute("aria-hidden", "true");
      const toggle = button("", () => {
        expanded = !expanded;
        syncExpanded();
        window.SMTOUiSession?.set("prompt_queue_expanded", expanded);
      });
      toggle.className = "prompt-queue-toggle";
      toggle.setAttribute("aria-controls", content.id);
      toggle.append(chevron, title);
      function syncExpanded() {
        content.hidden = !expanded;
        summary.hidden = expanded || !summary.textContent;
        toggle.setAttribute("aria-expanded", String(expanded));
        toggle.title = expanded ? "Collapse queued tasks" : "Expand queued tasks";
        chevron.textContent = expanded ? "▾" : "▸";
      }
      syncExpanded();
      header.append(toggle);
      if (lane.block.kind !== "none") {
        const paused = document.createElement("span"); paused.className = "prompt-queue-paused";
        paused.textContent = "Paused"; paused.title = lane.block.reason || "Queue paused";
        paused.setAttribute("role", "status"); header.append(paused);
      }
      header.append(button("Clear queue", () => clear(lane.conversation_id), busy));
      root.append(header, summary);
      const note = document.createElement("p"); note.className = "prompt-queue-status"; note.setAttribute("role", "status");
      note.textContent = lane.block.kind !== "none" ? `Queue paused. ${lane.block.reason || ""}`.trim()
        : lane.active_task ? `Current task: ${window.SMTORunActivity.resolve({
          ...window.SMTORunActivity.create(), status: window.SMTORunActivity.userStatus(lane.active_task)
        }).label} · ${items.length} queued ${items.length === 1 ? "task" : "tasks"} waiting.`
        : "Queued tasks continue even if this browser is closed.";
      content.append(note);
      if (items.length && lane.run_next_available === true) {
        const observed = {version: lane.version}, url = `${base(lane.conversation_id)}/run-next`;
        content.append(button("Run next", () => action(url, "POST", observed), busy,
          "The previous task did not succeed. Proceed to the next queued request anyway."));
      }
      const list = document.createElement("ol");
      items.forEach((task, index) => {
        const item = snapshotOf(task);
        const row = document.createElement("li"); row.dataset.queueId = task.client_submission_id; row.dataset.taskId = task.task_id;
        window.SMTOTaskMode.render(row, task);
        const preview = document.createElement("p"); preview.className = "prompt-queue-preview"; preview.textContent = task.prompt; preview.title = task.prompt;
        const meta = document.createElement("p"); meta.className = "prompt-queue-meta";
        const rules = policyKeys.flatMap(k => (item?.capability_policy[k] || []).map(v => `${k.startsWith("preferred") ? "+" : "−"}${v}`));
        meta.textContent = item ? [item.collaboration_mode === "plan" ? "Plan" : {agent: "Agent", conversation: "Conversation", advisory: "Ask"}[item.agent_mode],
          item.llm_model === "auto" ? "Auto" : item.llm_model,
          `Permissions: ${item.permission_policy === null ? "Inherited" : window.SMTOPermissionPolicy.names[item.permission_policy?.mode || "manual"]}`,
          window.SMTOBehaviorEffort.labels[item.behavior_effort],
          item.gateway_selection.gateway_ids.length > 1 ? `Multiple gateways · ${item.gateway_selection.gateway_ids.length}` : `Target: ${item.gateway_label || item.gateway_id}`, item.context_refs.length ? `${item.context_refs.length} attachment(s)` : "", ...rules.slice(0,4)].filter(Boolean).join(" · ")
          : [task.collaboration_mode === "plan" ? "Plan" : {agent: "Agent", conversation: "Conversation", advisory: "Ask"}[task.agent_mode], task.model_label,
            task.gateway_id ? `Target: ${task.gateway_id}` : ""].filter(Boolean).join(" · ");
        const actions = document.createElement("div"); actions.className = "prompt-queue-actions";
        if (task.dependency?.state === "blocked") {
          const observed = {version: lane.version};
          actions.append(button("Start task", () => action(`${taskUrl(task)}/start-blocked`, "POST", observed), busy,
            "Start this task without waiting for its dependencies. Execution slots still apply."));
        }
        // Compact rows contain no permission/context envelope. The explicit
        // steer action validates those settings against the current run on the
        // server, as on mobile; never invent defaults from omitted fields.
        const compatible = !task.dependencies?.length && lane.active_task
          && (!item || sameEnvelope(item, snapshotOf(lane.active_task))) && STEERABLE.has(hooks.current().status);
        actions.append(button("Steer current", () => action(`${taskUrl(task)}/steer-current`, "POST"), busy || !compatible,
          compatible ? "" : "Different or unverified target, model, capability, permission, behavior, or context settings."),
          button("Steer without interrupting", () => action(`${taskUrl(task)}/steer-current`, "POST", {steering_mode: "after_response"}), busy || !compatible,
            "Let the current response finish, then apply your update before the next action."),
          button("Edit", () => edit(task, row), busy),
          button("↑", () => move(index, -1), busy || index === 0, "Move up"),
          button("↓", () => move(index, 1), busy || index === items.length - 1, "Move down"),
          button("Remove", () => action(taskUrl(task), "DELETE"), busy));
        const dependency = document.createElement("p"); dependency.className = "prompt-queue-meta task-dependency-status";
        dependency.dataset.dependencyState = task.dependency?.state || "";
        dependency.textContent = waitReason(task);
        dependency.dataset.queueBlock = task.queue_block?.kind || "";
        dependency.setAttribute("role", "status");
        row.append(preview, meta, dependency, actions); list.append(row);
      }); content.append(list); root.append(content);
      if (refocusToggle) toggle.focus({preventScroll: true});
    }
    async function edit(task, row) {
      editing = task.task_id;
      try {
        const detail = await hooks.apiJson(task.detail_url || `/api/agent/tasks/${encodeURIComponent(task.task_id)}`);
        if (!row.isConnected || editing !== task.task_id) return;
        task = detail.task;
      } catch (error) { editing = ""; hooks.notify(error.message); return; }
      const input = document.createElement("textarea"); input.className = "chat-field-control"; input.value = task.prompt; input.maxLength = 24000; input.setAttribute("aria-label", "Edit queued prompt");
      row.replaceChildren(input, button("Save", () => {
        try { checkText(input.value); void action(taskUrl(task), "PATCH", {prompt: input.value}); }
        catch (error) { hooks.notify(error.message); }
      }), button("Cancel edit", () => { editing = ""; changed(); })); input.focus();
    }
    function move(index, delta) {
      const ids = lane.queued_tasks.map(t => t.task_id);
      [ids[index], ids[index + delta]] = [ids[index + delta], ids[index]];
      void action(`${base(lane.conversation_id)}/reorder`, "POST", {task_ids: ids, version: lane.version});
    }
    async function reconcileLane() {
      const cid = hooks.conversationId(), version = generation;
      if (!cid) { lane = null; changed(); return true; }
        try {
          const result = await hooks.apiJson(base(cid) + window.SMTOTaskDependencies.query());
          if (version !== generation || hooks.conversationId() !== cid) return false;
          if (lane && result.version < lane.version) return false;
          let recoveredOk = true;
          const previousRequests = lane && new Set(lane.tasks.map(task => task.current_request_id || task.latest_request_id));
          lane = result; hooks.reconciled?.(lane); changed();
          const active = lane.active_tasks || lane.tasks.filter(task =>
            ["running", "awaiting_confirmation", "awaiting_clarification"].includes(task.status));
          const candidates = active.length ? [...active] : [lane.active_task || lane.blocked_task || lane.tasks.at(-1)];
          // A short task can finish between invalidations while a sibling is still running.
          if (previousRequests) candidates.push(...lane.tasks.filter(task =>
            !previousRequests.has(task.current_request_id || task.latest_request_id)));
          for (const task of candidates) {
            if (version !== generation || hooks.conversationId() !== cid) break;
            const rid = task?.current_request_id || task?.latest_request_id;
            const attached = hooks.attachedRequestId ? hooks.attachedRequestId() : hooks.current().request_id;
            if (!rid || recovered.has(rid)) continue;
            recovered.add(rid);
            if (attached === rid) continue;
            // Every concurrent task owns an observation stream; attaching never starts work.
            try { await hooks.recoverAccepted(snapshotOf(task), {request_id: rid, conversation_id: cid, status: task.status}); }
            catch (_) { recovered.delete(rid); recoveredOk = false; }
          }
          if (version === generation && hooks.conversationId() === cid) {
            hooks.selectActive?.(active.map(task => task.current_request_id || task.latest_request_id));
          }
          return recoveredOk && version === generation && hooks.conversationId() === cid;
        } catch (error) {
          if (error.status !== 404) hooks.notify("Could not refresh the server task queue.");
          return false;
        }
    }
    async function reconcile() {
      if (window.SMTOSelectedConversation?.selected()) return window.SMTOSelectedConversation.refresh();
      if (!ready) return false;
      if (refreshPromise) { refreshAgain = true; return refreshPromise; }
      refreshPromise = (async () => {
        let current;
        do {
          refreshAgain = false;
          current = await reconcileLane();
        } while (refreshAgain);
        return current;
      })().finally(() => { refreshPromise = null; });
      return refreshPromise;
    }

    function enqueue(snapshot, {onAccepted, onFailure} = {}) {
      const captured = clone(snapshot), version = generation;
      checkText(captured.prompt);
      const key = JSON.stringify(captured);
      if (!pending.has(key)) pending.set(key, {
        id: `q_${globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)}`,
      });
      const submission = pending.get(key);
      // Visible local acknowledgement is synchronous, before even the enqueue chain.
      submission.view = hooks.submitting?.(captured, submission.id, submission.view);
      let restoreDependency = window.SMTOTaskDependencies?.reset();
      const work = async () => {
        let response;
        try {
          if (!submission.body) {
            if (!captured.conversation_id && version === generation && hooks.conversationId()) {
              captured.conversation_id = hooks.conversationId();
              delete captured.conversation_policy_defaults;
            }
            submission.body = {...captured, client_submission_id: submission.id};
          }
          hooks.submissionTiming?.(submission.id, "post_started");
          response = await hooks.apiJson("/api/agent/conversation-tasks", json("POST", submission.body));
        } catch (error) {
          const definite = error.status >= 400 && error.status < 500;
          if (definite) pending.delete(key);
          if (version === generation) {
            restoreDependency?.();
            hooks.submissionFailed?.(submission.view, error, definite);
          }
          lastFailure = {error, definite};
          lastError = definite ? error.message : "Couldn’t confirm submission · Retry with the same prompt.";
          onFailure?.(definite, error);
          hooks.notify(lastError);
          return false;
        }
        // Once acknowledged, presentation failures cannot turn acceptance into failure.
        pending.delete(key); lastFailure = null; restoreDependency = null;
        hooks.submissionTiming?.(submission.id, "ack_received");
        try {
          onAccepted?.(response);
          if (version === generation) {
            hooks.submissionAccepted?.(submission.view, response, captured);
            Promise.resolve(hooks.accepted?.(response, captured)).catch(() => hooks.notify("Task accepted. Some controls could not refresh."));
          }
        } catch (_) { hooks.notify("Task accepted. Some controls could not refresh."); }
        void reconcile();
        return response;
      };
      const result = enqueueChain.then(work, work);
      enqueueChain = result.catch(() => {});
      return result;
    }
    async function clear(cid = hooks.conversationId()) {
      if (!cid || cid !== hooks.conversationId()) return;
      await action(`${base(cid)}/queue`, "DELETE");
    }
    async function open() {
      await reconcile(); expanded = true; render();
      if (root.hidden) { hooks.notify("The queue is already empty."); return; }
      root.scrollIntoView({block: "nearest"}); root.querySelector("button")?.focus();
    }
    const api = {enqueue, reconcile, open, clear,
      applyLane(value) { lane = value; hooks.reconciled?.(lane); changed(); },
      failureMessage: () => lastError, failure: () => lastFailure, hasItems: () => Boolean(lane?.queued_tasks.length),
      // A detached projection of an exact task; observers never select the latest task.
      task: id => clone(lane?.tasks.find(task => task.task_id === id) || null),
      prepared() {}, submissionFailed() { void reconcile(); }, requestAccepted() { void reconcile(); },
      continued() { void reconcile(); }, cancel() { void reconcile(); },
      navigation() {
        generation++; recovered.clear(); hooks.navigation?.(); lane = null; editing = ""; changed();
        if (ready) window.SMTOUiUpdates.reconcile();
      },
      async start() {
        if (!ready) {
          ready = true;
          // Register only once boot has established the conversation scope. The
          // shared client then includes this ready owner in its freshness check.
          if (!window.SMTOSelectedConversation)
            window.SMTOUiUpdates.subscribe(["runs.changed", "tasks.changed"], reconcile, {critical: true});
        }
        await reconcile();
      }};
    render(); return api;
  }, isOperational: status => Boolean(status) && !SUCCESS.has(status) && !FAILED.has(status) && !HARD_BLOCK.has(status),
  isInteraction: status => INTERACTION.has(status), isSteerable: status => STEERABLE.has(status)};
})();
