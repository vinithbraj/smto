import { api, state, node, button, encode } from "../api.js";
import { openSheet } from "../overlays.js";
import "../../task_mode.js?v=20261015-smto";

export async function open(hooks) {
  const cid = state.conversationId;
  if (!cid) return;
  let laneChanged;
  const generation = state.generation,
    body = openSheet("Queued messages", {onClose: () => {
      if (hooks.laneChanged === laneChanged) delete hooks.laneChanged;
    }});
  const base = `conversations/${encode(cid)}/task-lane`,
    lane = state.lane || window.SMTOConversationSnapshot.laneView(
      await api(base + (window.SMTOTaskDependencies.query() || "?") + "&view=compact"));
  if (generation !== state.generation || !body.isConnected) return;
  state.lane = lane;
  hooks.renderComposer();
  const action = async (path, method, body) => {
    await api(path, { method, body });
    await hooks.refresh();
    if (generation === state.generation) await open(hooks);
  };
  if (lane.active_task)
    body.append(
      node(
        "p",
        `Current task: ${lane.active_task.user_visible_status || lane.active_task.status}`,
      ),
    );
  if (lane.block?.kind && lane.block.kind !== "none")
    body.append(node("p", lane.block.reason || "Queue paused.", "error"));
  if (lane.run_next_available === true)
    body.append(
      button("Run next", () =>
        action(`${base}/run-next`, "POST", { version: lane.version }),
      ),
    );
  const queued = lane.queued_tasks || [];
  function updateStart(row, task, snapshot) {
    let start = row.querySelector(".queue-start-blocked");
    if (task.status !== "queued" || task.dependency?.state !== "blocked") {
      start?.remove();
      return;
    }
    if (!start) {
      start = button("Start task", () => action(`tasks/${encode(task.task_id)}/start-blocked`, "POST",
        {version: Number(start.dataset.version)}), "queue-start-blocked");
      start.title = "Start this task without waiting for its dependencies. Execution slots still apply.";
      row.append(start);
    }
    start.dataset.version = snapshot.version;
  }
  if (!queued.length) body.append(node("p", "No queued messages.", "muted"));
  queued.forEach((task, index) => {
    const row = node("section", null, "action-card");
    row.dataset.taskId = task.task_id;
    window.SMTOTaskMode.render(row, task);
    row.append(
      node("p", task.prompt),
      node(
        "p",
        `${task.user_visible_status || task.status} · ${task.model_label || task.context?.llm_model || ""}`,
        "muted",
      ),
    );
    const dependency = node("p", window.SMTOTaskDependencies?.describe(task, lane.tasks) || "",
      "muted task-dependency-status");
    dependency.setAttribute("role", "status");
    row.append(dependency);
    updateStart(row, task, lane);
    row.append(
      button("Edit", async () => {
        const detail = await api(`tasks/${encode(task.task_id)}`);
        if (!row.isConnected) return;
        const input = node("textarea");
        input.value = detail.task.prompt;
        input.maxLength = 24000;
        input.setAttribute("aria-label", "Edit queued message");
        row.replaceChildren(
          input,
          button("Save", () => {
            return action(`tasks/${encode(task.task_id)}`, "PATCH", {
              prompt: input.value,
            });
          }),
        );
      }),
    );
    row.append(
      button("Remove", () => action(`tasks/${encode(task.task_id)}`, "DELETE")),
    );
    if (lane.active_task && !task.dependencies?.length)
      row.append(
        button("Steer current", () =>
          action(`tasks/${encode(task.task_id)}/steer-current`, "POST"),
        ),
        Object.assign(button("Steer without interrupting", () =>
          action(`tasks/${encode(task.task_id)}/steer-current`, "POST", {steering_mode: "after_response"}),
        ), {title: "Let the current response finish, then apply your update before the next action."}),
      );
    if (index > 0)
      row.append(
        button("Move up", () => {
          const ids = queued.map((t) => t.task_id);
          [ids[index - 1], ids[index]] = [ids[index], ids[index - 1]];
          return action(`${base}/reorder`, "POST", {
            version: lane.version,
            task_ids: ids,
          });
        }),
      );
    body.append(row);
  });
  // Reuse the mobile client's existing invalidation stream. Keep edited inputs
  // and keyboard focus intact while dependency reasons change in the open sheet.
  laneChanged = next => {
    if (generation !== state.generation || next.conversation_id !== cid || !body.isConnected) return;
    for (const task of next.tasks || []) {
      const row = body.querySelector(`[data-task-id="${CSS.escape(task.task_id)}"]`);
      const status = row?.querySelector(".task-dependency-status");
      if (status) status.textContent = window.SMTOTaskDependencies?.describe(task, next.tasks) || "";
      if (row && !row.querySelector("textarea")) updateStart(row, task, next);
    }
  };
  hooks.laneChanged = laneChanged;
  if (queued.length)
    body.append(
      button("Clear queued messages", () => clear(hooks, cid)),
    );
}

export async function clear(hooks, cid = state.conversationId) {
  if (!cid || cid !== state.conversationId) return;
  await api(`conversations/${encode(cid)}/task-lane/queue`, {method: "DELETE"});
  await hooks.refresh();
  if (cid === state.conversationId) await open(hooks);
}
