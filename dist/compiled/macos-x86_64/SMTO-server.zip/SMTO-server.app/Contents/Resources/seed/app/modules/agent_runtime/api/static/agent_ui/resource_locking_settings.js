/* Live global policy; controls never infer effects or own execution admission. */
(() => {
  "use strict";
  function mount(sections, nav, {setStatus, onChange = () => {}}) {
    const node = (tag, text, className) => {
      const el = document.createElement(tag);
      if (text) el.textContent = text;
      if (className) el.className = className;
      return el;
    };
    const section = node("details", "", "mission-settings-section");
    section.id = "settings-section-resource-locking";
    section.dataset.sectionSearch = "resource locking shell files memory kv python docker gpu local ai network web conflicts serialization";
    const summary = node("summary", "", "mission-settings-section-summary");
    summary.append(node("h2", "Resource locking")); section.append(summary);
    const body = node("div", "", "mission-section-body"); section.append(body); sections.append(section);
    const link = node("a", "Resource locking"); link.href = "#" + section.id; nav.append(link);
    const api = (options) => window.SMTOAgentUi.apiJson("/resource-locking", options);
    let catalog, generation = 0, saving = false, refreshPending = false, additionalOpen = false;
    const feedback = node("p"); feedback.setAttribute("role", "status");
    async function save(policy) {
      const focusLabel = document.activeElement?.getAttribute("aria-label");
      saving = true; ++generation;
      body.querySelectorAll("input").forEach(input => { input.disabled = true; });
      try {
        catalog = await api({method: "PUT", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({policy, expected_revision: catalog.policy.revision})});
        feedback.textContent = "Resource locking settings saved.";
        setStatus(feedback.textContent, "saved");
      } catch (error) {
        feedback.textContent = error.message;
        setStatus(error.message, "error");
        try { catalog = await api(); } catch (_) { /* Retain last acknowledged policy. */ }
      } finally {
        saving = false; render();
        if (focusLabel) body.querySelector(`[aria-label="${CSS.escape(focusLabel)}"]`)?.focus();
      }
    }
    function render() {
      body.replaceChildren();
      body.append(node("p", "Off allows operations to access shared resources concurrently. Enable selected families to check for conflicts and apply resource budgets. Changes affect running and queued tasks.", "mission-section-copy"));
      const policy = catalog.policy;
      function toggle(root, label, checked, change) {
        const row = node("label", "", "agent-check-toggle-row resource-locking-row");
        row.dataset.settingSearch = label.toLowerCase();
        row.append(node("span", label));
        const input = node("input", "", "mission-switch"); input.type = "checkbox";
        input.setAttribute("role", "switch"); input.setAttribute("aria-label", label); input.checked = checked;
        input.onchange = () => change(input.checked); row.append(input); root.append(row);
      }
      toggle(body, "Enable resource locking", policy.enabled, enabled => void save({...policy, enabled}));
      body.append(node("p", policy.enabled ? "Only selected families participate. Disabled families remain unrestricted." :
        "Resource locking is off for every family. Your selections below are saved for when it is enabled."));
      const additional = node("details", "", "resource-locking-additional"); additional.append(node("summary", "Additional tool families"));
      additional.open = additionalOpen;
      additional.ontoggle = () => { if (additional.isConnected) additionalOpen = additional.open; };
      for (const family of catalog.families) {
        toggle(family.primary ? body : additional, family.label, Boolean(policy.families[family.id]),
          enabled => void save({...policy, families: {...policy.families, [family.id]: enabled}}));
      }
      body.append(additional);
      const pending = (catalog.gateways || []).filter(g => g.state !== "applied");
      if (pending.length) {
        const status = node("p"); status.setAttribute("role", "status");
        status.textContent = pending.map(g => `${g.label}: ${g.state === "upgrade_required" ? "Gateway upgrade required" : "waiting to synchronize"}`).join("; ");
        body.append(status);
      }
      body.append(feedback); onChange();
    }
    async function refresh() {
      if (saving || body.contains(document.activeElement)) { refreshPending = true; return; }
      refreshPending = false;
      const revision = ++generation;
      try {
        const value = await api();
        if (revision !== generation || saving) return;
        catalog = value; render();
      } catch (error) { feedback.textContent = error.message; body.append(feedback); }
    }
    window.SMTOUiUpdates?.subscribe(["settings.changed"], () => void refresh());
    body.addEventListener("focusout", () => setTimeout(() => { if (refreshPending) void refresh(); }, 0));
    window.addEventListener("focus", () => void refresh());
    void refresh();
  }
  window.SMTOResourceLockingSettings = {mount};
})();
