/* Optional text transitions for the shared single-line activity status.
 * Update existing nodes immediately; motion never delays or queues status truth. */
(() => {
  "use strict";
  const enter = transform => [{opacity: 0, transform}, {opacity: 1, transform: "none"}];
  const styles = new Map([
    ["roll", null],
    ["swipe-down", enter("translateY(-12px)")],
    ["swipe-up", enter("translateY(12px)")],
    ["slide-left", enter("translateX(14px)")],
    ["slide-right", enter("translateX(-14px)")],
    ["fade", [{opacity: 0}, {opacity: 1}]],
    ["zoom-in", enter("scale(.94)")],
    ["zoom-out", enter("scale(1.06)")],
    ["flip", enter("perspective(240px) rotateX(-45deg)")],
    ["blur", [{opacity: 0, filter: "blur(3px)"}, {opacity: 1, filter: "blur(0)"}]],
    ["bounce", [
      {opacity: 0, transform: "translateY(-12px)", offset: 0},
      {opacity: 1, transform: "translateY(2px)", offset: .7},
      {opacity: 1, transform: "none", offset: 1},
    ]],
  ]);
  const views = new WeakMap(), active = new Set();
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  let preference = "roll";

  function stop(view) {
    if (!view) return;
    for (const animation of view.animations) {
      animation.onfinish = animation.oncancel = null;
      animation.cancel();
    }
    view.animations = [];
    view.outgoing?.remove();
    view.outgoing = null;
    active.delete(view);
  }

  function cancelActive() {
    for (const view of active) stop(view);
  }

  function snapshot(copy, value) {
    const old = copy.cloneNode(true);
    // A clock tick can refresh this snapshot while the preceding transition is
    // still running. Its outgoing row must not become part of the next one.
    old.querySelectorAll(".activity-update-outgoing").forEach(child => child.remove());
    old.classList.add("activity-update-outgoing");
    old.setAttribute("aria-hidden", "true");
    old.inert = true;
    old.removeAttribute("id");
    old.querySelectorAll("[id]").forEach(child => child.removeAttribute("id"));
    // Callers render detail text just after update; retain the new value now
    // so the next transition includes the complete preceding sentence.
    const detail = old.querySelector(".task-activity-detail");
    if (detail) detail.textContent = value.detail || "";
    return old;
  }

  function animate(view, child, frames, duration) {
    const animation = child.animate(frames, {
      duration, easing: "cubic-bezier(.2,.7,.2,1)", fill: "both",
    });
    animation.id = `activity-update-${preference}`;
    active.add(view);
    view.animations.push(animation);
    animation.onfinish = () => {
      if (view.animations.every(item => item.playState === "finished")) stop(view);
    };
    animation.oncancel = () => stop(view);
  }

  function setPreference(value) {
    const next = value === "none" || styles.has(value) ? value : "roll";
    if (next !== preference) cancelActive();
    preference = next;
    document.documentElement.dataset.activityUpdateAnimation = next;
  }

  function update(copy, value) {
    if (!copy?.matches(".task-activity-copy")) return;
    const detail = value.detail || "";
    const key = JSON.stringify([value.label, value.detailTransitionKey ?? detail,
      value.activeCount > 1 ? value.activeCount : 0, value.actionId || ""]);
    const previous = views.get(copy);
    if (previous?.key === key) {
      // Clock text is live data within the same wait. Keep it current without
      // starting (or restarting) a whole-status transition.
      if (previous.detail !== detail) {
        previous.detail = detail;
        previous.snapshot = snapshot(copy, value);
      }
      return;
    }
    stop(previous);
    const view = {key, detail, animations: [], snapshot: snapshot(copy, value)};
    views.set(copy, view);
    // Initial rendering and hidden/finished statuses don't need entrance motion.
    if (!previous || !value.label || ["idle", "terminal"].includes(value.kind)
        || preference === "none" || reducedMotion.matches || document.hidden
        || !copy.isConnected || !copy.getClientRects().length) return;
    // The existing overflow-hidden flex row clips moving text without changing
    // its dimensions, icons, focus, accessible content or surrounding scroll.
    const children = [...copy.children];
    const rolling = preference === "roll";
    const distance = rolling ? copy.getBoundingClientRect().height : 0;
    const duration = rolling || preference === "bounce" ? 320 : 240;
    if (rolling && copy.animate) {
      view.outgoing = previous.snapshot;
      copy.append(view.outgoing);
      animate(view, view.outgoing, [
        {transform: "translateY(0)"}, {transform: `translateY(${distance}px)`},
      ], duration);
    }
    for (const child of children) {
      if (child.hidden || !child.animate) continue;
      animate(view, child, rolling ? [
        {transform: `translateY(-${distance}px)`}, {transform: "translateY(0)"},
      ] : styles.get(preference), duration);
    }
  }

  reducedMotion.addEventListener("change", () => {
    if (reducedMotion.matches) cancelActive();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) cancelActive();
  });
  setPreference(document.documentElement.dataset.activityUpdateAnimation
    || window.__SMTO_MOBILE_BOOT__?.ui_activity_update_animation);
  window.SMTOActivityUpdates = {setPreference, update};
})();
