---
id: web-research
title: Web Research
kind: architecture
tags: [architecture, web, browser, research, skills]
order: 43
---
# Web Research

**Web Research** researches public information while preserving the requested source,
exact identifiers and filters. Enable it in Capabilities or accept its normal capability
grant. It is optional and starts disabled; installing it does not widen saved policies.
Explicit capability policy, selector and editor lists support up to 64 Skills so the
expanded catalog can be selected and saved. Policy schema version 1 and defaults remain unchanged.

| Skill | Purpose |
| --- | --- |
| Web Research | Runtime evidence ledger, typed filters, citation validation and bounded recovery |
| Web | Anonymous public search and static page reading |
| Browser | Rendered/session-dependent reading and website interaction on the selected Gateway |
| PDF | Selected-Gateway inspection, page text, rendering and explicit OCR |
| HTTP | Explicit REST/API requests and configured connections |

Web Research owns no executable tools or provider configuration. It reuses `web.search`
and `web.read`. Search configuration remains in **Settings → Skills → Web**. A supplied
public URL can be read even without a Search provider. Search snippets locate sources;
primary-source reads support current claims. The native runtime owns research state;
the model chooses acquisitions and selects supported results for its answer.

## What verified means

A verified fact is an explicitly observed field or attributed source quotation, bound
to an executed, complete native receipt and an exact retained span. It does not certify
that the publisher is truthful or that the observation is still current outside this
run. Search results are discovery records. Blocked pages describe access, and do not
prove product facts. Missing values are `UNKNOWN`; conflicting observations are
`CONTRADICTED`. Neither passes a required filter.

Seller country, item location and shipping origin are separate fields. A country in
one field cannot fill another. “Located in” means item location, not seller country.
`US $` establishes USD; bare `$` does not. GPU-memory/VRAM labels establish product memory;
unqualified memory/system RAM does not. Explicit sold, ended and out-of-stock states are
historical/unavailable observations and cannot pass a current-availability requirement.
Price intervals retain both upper and lower bounds.
Literal model tokens preserve identifiers such as T100
and T1000 as different products. Dollar symbols remain `$` unless the source explicitly
establishes a currency code. Price plus shipping is derived only when both verified
inputs use the same unit; taxes, exchange rates and undisclosed charges are not inferred.
An explicit currency in a price span also verifies the currency field. GPU capacity is
separate from system RAM. Incidental identifiers in source URL paths are not product names.

## Evidence and final answers

The version-2 `web_research_state` lives in the native run checkpoint. It contains a
frozen intent revision, source records, exact evidence spans, typed facts, filter
evaluations, acquisition reservations and the repair counter. RunStore remains the
canonical receipt owner. Page-authored identifiers cannot become evidence IDs.

Supported literal constraints are projected from user input and accepted Task Contract
descriptions without another compiler call. Additive price/country follow-ups create a
new revision and re-filter already scoped receipts. Old fact IDs are invalid in the new
revision. A request to refresh starts fresh evidence acquisition. The ordinary history
policy still excludes transient Browser receipts from a new conversation turn; grant
continuations preserve their existing receipt scope.

The model receives bounded result rows and exact excerpts, with a suggested completion
when evidence is available. Packets and compact receipts include `expandable_result_ids`.
`read_research_evidence(result_id=...)` expands a retained result without another fetch or
model call. `subject_id` remains a compatible argument. A source reference resolves only
when exactly one result belongs to it; ambiguous sources return bounded candidate IDs.
Unknown and wrong-kind references are typed input failures and consume no expansion
allowance. Source IDs remain provenance references, not interchangeable result IDs.
Raw Web/Browser bodies remain in canonical storage and the exact journal. Model-facing
tool messages preserve operation correlations and bounded Browser element references.

**Settings → Agent Checks → Research proof validation**
(`completion.research_proof`) defaults **OFF**. Research and analysis can finish in
ordinary prose using generated conclusions, Git/local observations and available
sources. Missing proof, a missing claim map or a reference outside the Web ledger
does not suppress the answer or trigger a correction. An unavailable check is not
enforced. The output records validation as `not_checked`, never as verified success.
The model should distinguish observations, inferences and uncertainty.

With this check off, research runs also bypass the generic completion citation,
receipt, complete-observation and strict final-response structure requirements.
Other execution controls keep their configured behavior. Disabled-check monitoring
may add diagnostics without changing output or requesting another model decision.
Disabling proof on a paused completion reuses its retained answer without rerunning
research. Existing runs with no saved value inherit OFF.

When research proof validation is explicitly enabled, `finish_task` accepts same-decision
`__smto_research_claims`. The message uses `[[claim_id]]` placeholders, and the
runtime renders the selected facts and source links. `OBSERVED_FACT` selects verified
facts from eligible results; `UNCERTAIN` explicitly labels excluded candidates or
unknown fields. Deterministic derivations cite their verified input facts. Arbitrary
paraphrases and unregistered semantic conclusions cannot be certified by this gate.
This stricter output protocol also applies to direct, implicit and retained final
responses. Generated answers remain retained and visible if validation fails, with
partial status and verification feedback.
The model-facing schema requires the claim map and marker-only message format. Browser
target constraints use an equivalent schema layout that preserves structural properties
in local grammar compilers; canonical argument validation remains unchanged.

Every published claim rechecks receipt scope, execution, completeness, source digest,
span contents and hard-filter support. Citations are generated from observed source
URLs. A pasted URL or plausible-looking quotation is insufficient. Truncated content
cannot support an exhaustive result claim. No claim verifier model is used.

Missing evidence or an unmet explicit Browser request can return to acquisition once
within the current allowances and authority when proof validation is enabled. A terminal
correction permits at most one additional model decision per intent revision. If it
fails, the runtime publishes the retained generated answer as partial with verification
feedback. Only when no generated answer exists does it use a deterministic fallback.
Prose accompanying a valid repair control remains in the durable journal.
Text-only, multiple calls, another tool, malformed arguments and unsupported claims still
fail. Ordinary native protocol remains strict; the original rejection survives fallback.

## Runtime bounds

Trusted execution context can lower initial values through `web_research_limits`.
Evidence storage and packet sizes are hard bounds. Acquisition counts are soft allowances:
reaching one returns a typed limit result while leaving the tool visible. The model chooses
whether to request an extension or finish using retained evidence.

| Bound per intent revision | Default / maximum |
| --- | ---: |
| Sources / result subjects | 128 / 128 |
| Evidence spans / spans per source | 2,048 / 768 |
| Retained span text bytes / facts | 262,144 / 4,096 |
| Claims per answer | 32 |
| Results / facts per result in a packet | 8 / 16 |
| Excerpts / characters per excerpt | 6 / 480 |
| Research packet characters | 16,000; configurable minimum 4,096 |
| Searches / Web or HTTP reads | 6 / 32 |
| Browser starts and navigations / reads, snapshots, finds and waits | 8 / 12 |
| Browser clicks, text entry, selection, checks and scrolling | 20 |
| Operation reservation records (hard, fail closed) | 512 |
| Stored-evidence expansions per decision | 2 |
| Same transport transient retry | 1 |
| Terminal model repair | 1 |

`request_research_budget` supplies exact positive increments for soft allowance categories.
The existing authority card records one durable Allow/Don't allow decision. Approval
atomically adds the increments once, preserving run ID, evidence, used counts, intent and
Browser session references. Denial suppresses cosmetic requests for the same categories.
The next model packet includes the accepted decision and denied categories, so the model
can continue within remaining allowances without asking the same question through another
control. Declining page reads does not mark an independently available Browser method blocked.
Pause, Stop, stale identities and duplicate replies cannot apply increments. This cannot
grant capabilities or extend model, tool-call, wall-clock, storage or context limits.

Overflow is recorded and omitted records are not silently promoted to verified facts.
Approval continuation reuses the existing operation reservation. Repeated blocked-origin
reads cannot try cosmetic variants; another URL supplied by the user or actually found
by search may be read. All calls still pass normal execution policy. Each reservation and receipt is joined by
operation ID, so out-of-order completion cannot lend a retry to another operation. Access
history retains separate URL/transport outcomes. Tracking-only URL changes do not create a
new target; known distinct supplied/discovered URLs remain usable. A 429 records a bounded
cooldown (including Retry-After when present), independently of 403 block history. There
is no automatic Browser bypass or retry. Browser page revisions and conservative mutation
epochs make subsequent observations fresh after interaction.

Packets describe tool availability, remaining allowances, recent outcomes, progress deltas
and unresolved fields. They never select the next URL or prescribe a universal “enough”
threshold from the presence of one eligible result.
Recent retry state includes remaining cooldown seconds and whether the one exact transient
retry remains available; waiting does not replenish an exhausted retry allowance.
An explicit numeric request such as “find at least 3 listings” freezes a minimum result
count. An answer below that count must remain partial and disclose the unmet requirement.

## Source-aware recovery

An explicit instruction to use Browser is a frozen method requirement, independent of
whether static reads work. A completed meaningful Browser read/snapshot/find at a real
page URL satisfies it; status and start alone do not. The packet reports pending,
satisfied or blocked with observed blockers. Unavailable/denied Browser permits a truthful
partial answer, never a claim that Browser verification occurred. Conditional requests
such as “Browser if needed” do not create this obligation.

Without an explicit method requirement, a normal static page needs no browser startup. If anonymous Web receives a block, challenge,
JavaScript requirement or empty application shell, the Agent considers whether Browser
would help. When the user names a site, that source is part of the task. For example,
“check ebay.com for NVIDIA T100 32 GB, US sellers only” preserves both the literal
model identifier and the marketplace. A related model is a separate ambiguity to explain.
Item location alone does not establish seller country.

When a source is only a means to a fact, another credible primary source may suffice.
When a required source cannot be checked, the answer states that limitation and identifies
any alternate evidence separately. A completed blocked-page observation is not a successful
retrieval of the requested facts. Truncated reads cannot establish whole-page absence.

Already selected Browser exposes its authorized research surface immediately: session/tab
inspection and management, navigation, page observations, screenshots/download inspection,
and ordinary click/fill/type/press/select/check interaction. It is not gated on a blocked
Web origin. Uploads and other capabilities keep their own authority.
Browser can also be acquired with `discover_tools(skill_ids=["browser"])`. Within the
accepted ceiling this activates deterministically. Otherwise, the central authority
controller immediately opens a durable approval card for a grantable request, with no
intervening model call or `ask_user` operation. Approval creates a
continuation preserving the task under a new frozen ceiling. Denial suppresses repeated
grant prompts for that semantic task. Hard restrictions remain authoritative.

Enabling Web Research **does not enable Browser or HTTP**, grant credentials, change
saved Permission Policy. For an active research run, the exact research Browser allowlist
waives default confirmation friction; explicit tool/Skill Ask/Deny, deny mode, capability
restrictions, unsafe actions and secret protections remain enforced. These operations
retain their real write effects for scheduling and replay. Unknown-effect mutations must
be reconciled, never blindly replayed. Existing capability Activity events record the
request, activation or grant, and continuation; there is no second research event store.

## Anonymous Web result contract

### Public PDF acquisition

`web.read` accepts a public `application/pdf` response, or an octet-stream with a PDF
signature, as an untrusted document observation. A `.pdf` URL alone proves nothing.
The reader streams bounded bytes into the immutable current-run ArtifactStore, then
uses the existing atomic transfer protocol to materialize a create-only file in the
selected Gateway's run workspace. The limit is the smaller of PDF's 64 MiB ceiling
and the artifact policy limits; compressed and decoded bytes are each bounded.
DNS pinning, public-address validation on each redirect, timeout and cancellation
checks remain active. Credentials in anonymous Web URLs are rejected.

The receipt reports `resource_kind=document`, `document_type=pdf`, SHA-256, requested
and final URLs, artifact reference and locality. `materialized=true` includes a usable
`artifact_path`; a failed Gateway handoff leaves the immutable acquisition available
with a locality limitation. Web does not extract text or run OCR. Repeating the URL
within the same run can reuse the verified artifact and rematerialize it without
another HTTP request; `acquisition_reused` and `network_executed=false` identify this
as retained evidence. An explicit research refresh bypasses reuse.

The model discovers the separate PDF capability through normal grants and selects
`info`, `pages`, `text`, `render` or explicit `ocr`. The runtime exposes installed and
authorized operations only when a document is relevant. It chooses no recovery ladder.
PDF text and OCR facts bind the original public URL, acquisition receipt, document
hash, Gateway path/revision, extraction operation and exact page offsets. Final
validation reopens both receipts and checks the quote stays within its recorded page.
Citations use the public URL and page number, never an internal artifact path.
Compacted extraction receipts retain `extracted_text_chars` and `ocr_performed`, so an
empty native text layer remains visible. Generated page markers are not document facts.
The capability packet includes the existing `pdf.ocr` discovery section; the model
still decides whether OCR or another observation is appropriate.

Rendering produces an image artifact; it does not imply that the model can see it.
Only explicit active serving metadata `capabilities.image_input=true` enables input
to the same primary model. Names and training configuration are not evidence of
serving support. At most two verified current-run page images, totaling 4 MiB, enter
an ephemeral request projection. PDF bytes and image base64 never enter research
state. Text-only models retain a visual limitation and need textual corroboration;
OCR labels alone do not establish diagram placement. When research proof validation
is enabled, strict fact publication requires registered evidence. With it disabled,
the model may explain its conclusions while preserving this visual limitation.

### Exact identity and clarification

Each literal entity has `EXACT_OBSERVED`, `UNRESOLVED`, `ALTERNATIVES_ONLY` or
`USER_RESOLVED` state. Alternatives reference observed facts; T100 never becomes T1000,
and Tesla N100 never inherits V100 specifications. Brand/family prefixes and explicit
version literals are retained. No fuzzy matching or helper inference is used.

When represented fit, dimensions, power, connector, compatibility or dosage requirements
depend on unresolved identity and research proof validation is enabled, an answered/completed declaration returns
`research_entity_clarification_required`. Its single bounded correction permits
`ask_user` or a validated partial limitation. Other completion corrections retain their
existing tool restrictions. Existence/verification questions may finish with a scoped
unverified result without asking an unnecessary question.
An initial citation or envelope failure cannot hide an independently established
material identity blocker: the same single correction can ask for identity, while
the original validation failure remains recorded separately.

Identity questions carry `research_entity_id`; candidates must occur in user input or
retained evidence. An open question is valid. The existing durable ask_user checkpoint
consumes a single explicit literal or quoted reply once, creates a new intent revision,
retains the old contract audit, and rechecks retained receipts against the new identity.
Ambiguous multi-identifier replies never select a replacement automatically. Old runs
default missing indexes conservatively and acquire no fabricated PDF lineage.

Thinking-limit recovery remains a separate one-step control. A discovered PDF read or
an identity question can be that step; the next decision restores normal reasoning.

### Access and recovery state

Access outcomes, operation retry allowances, cooldowns, Browser availability and
authorized alternatives remain distinct. A blocked static source does not select
Browser automatically. A 429 cooldown also covers query variations on the same
origin/path and transport; a genuinely different source remains a model choice.
Soft budgets, per-operation error identities and explicit capability denials remain
enforced through the existing controls.

`web.read` adds a compact `access_state`, `browser_recovery` and `same_transport_retry`.
The `transport_profile` reports `mode=anonymous_http`, with JavaScript, cookies, session
state, credentials and automatic retries all false. Web accepts no arbitrary request
headers and never copies browser state. Recovery metadata precedes page text in ordinary
result previews and passes through existing sanitization and Activity paths.

| Observation | Access state | Browser recovery | Same transport retry |
| --- | --- | --- | --- |
| Useful static 2xx | `readable` | `not_recommended` | false |
| Acquired public PDF | `document_acquired` | `not_recommended` | retained artifact reuse |
| PDF type/size/acquisition failure | `document_error` | `not_recommended` | false |
| 401 | `authentication_required` | `recommended` | false |
| 403 | `forbidden`, or `challenge` with a fixed signature | `recommended` | false |
| 404 / 410 | `not_found` | `not_recommended` | false; discover a correct URL |
| 429 | `rate_limited` | `not_recommended` | false; wait or permitted alternative |
| 451 | `restricted` | `not_recommended` | false |
| Other non-2xx response | `http_error` | `not_recommended` | false |
| Ordinary 5xx | `server_error` | `possible` | at most once if transient |
| Explicit JS requirement with missing static content | `javascript_required` | `recommended` | false |
| Short browser-verification interstitial | `challenge` | `recommended` | false |
| Scripted application root with empty/loading text | `client_rendered_shell` | `recommended` | false |
| Unsupported document type | `unsupported_content` | `not_recommended` | false |
| Timeout/DNS/connect/incomplete response | `transport_error` | `possible` | at most once if transient |
| Invalid/private target or redirect-limit rejection | `transport_error` | `not_recommended` | false |

Status takes precedence over content: challenge wording in a 429 never recommends rate-limit
bypass. An unsupported 403 body remains an observed forbidden response. Security rejections
never suggest routing around Web's public-address checks. A retry-eligible result includes
`retry_policy=at_most_once_if_transient`; no retry executes automatically.

`complete=true` describes a completed bounded observation. `ok` and `content_complete`
are false when content is blocked or missing because rendering is required, including
HTTP 200 application shells. The tool receipt can still be successful because it observed
a real HTTP response. Existing error kinds and transport-failure completion semantics stay
intact. Classification uses fixed local signatures, at most 64 KiB of HTML structure,
bounded extracted text and no model calls. It adds no raw page dump.

These conservative hints cannot guarantee a site's content is complete or detect every
login/challenge page. They describe access evidence, never authority or browser readiness.
Do not retry blocks through cosmetic headers or guessed RSS/mobile/JSON endpoints.
Short explanatory CAPTCHA/JavaScript articles retain their useful text. A phrase inside
an article is insufficient to declare an access interstitial; strong standalone or
structural evidence is required.

## Browser sessions and limits

Inspect Browser status and conversation-owned sessions first; reuse an appropriate
session using returned IDs. Explicit operator-configured CDP attachment and managed
SMTO Chromium remain separate modes. Managed profiles do not inherit the user's
personal Chrome login. No ports are scanned, debugging enabled silently, or personal
profiles copied. See [Browser automation](39-browser.md) for configuration and discovery.

Browser is installed and enabled by the standard Gateway setup. Missing runtime, browser binary, attach
configuration or headed display is reported through existing Browser availability/errors;
there is no controller-local fallback. Human login or challenge completion happens directly
in an available headed browser; `ask_user` requests continuation, never passwords in chat.

Web and Browser page content remain untrusted evidence. Page instructions cannot grant
capabilities, reveal secrets or authorize unrelated actions. Web Research is not a stealth
scraper, CAPTCHA solver, cookie extractor or provider-specific API framework. Legal,
geographic and site access controls remain restrictions. No helper model, browser planner
or DOM-summary model is added. The existing selector/Task Contract call budget is unchanged.

## Compatibility and limits

The Skill IDs, primitive Web/Browser argument contracts, provider configuration,
permission schema and capability defaults remain unchanged. Browser snapshot/find
responses include their existing public page URL and tab ID so evidence can bind to
the observed page. Old conversations without research state load normally; state is
initialized lazily when Web Research participates. There is no database migration or
automatic certification of old free-form answers.

Typed extraction supports known JSON fields, existing Browser tables, labeled text
and exact quotations. It is not a general semantic entailment engine or a provider
scraper. Unsupported semantic constraints remain unresolved in the contract; the gate's
matching summary concerns its represented filters. Complex substitutions, provider
pagination completeness and natural-language fact normalization require additional
adapters or stronger accepted intent records. An unavailable authenticated source or
missing seller country remains unverified.

Run `scripts/benchmarks/web_research_reliability.py --runs 5` with the configured model
for the release benchmark. It uses isolated state, controlled HTTP fixtures and a
disposable Chromium profile, and records fixture accuracy, useful outcomes, token/call
counts and latency. See the engineering hardening report for the measured release
verdict; unit tests alone are not a model reliability claim.
