---
id: gmail-integration
title: Gmail Integration
kind: manual
tags: [manual, gmail, multi-account]
order: 25
---
# Gmail Integration

smTO is not an email client. Gmail is the source of truth. smTO does not maintain a mailbox copy, inbox index, message/thread cache, draft mirror, label cache, or background synchronization database. Searches and reads query Gmail when requested.

## Connect with a Gmail app password

In **Parameter Store → New parameter template**, select **Gmail — App Password (Gmail + SMTP)**.
Save the following JSON as `personal_gmail`, replacing the email and password:

```json
{
  "profile_type": "gmail_app_password_account",
  "profile_version": 1,
  "email": "you@gmail.com",
  "app_password": "YOUR_GOOGLE_APP_PASSWORD",
  "display_name": "",
  "timeout_seconds": 30
}
```

Use a Google app password, not your normal Google password. Google requires 2-Step
Verification; account or administrator policies can make app passwords unavailable.
Follow [Google's app-password setup](https://support.google.com/accounts/answer/185833).
Spaces in pasted app passwords are removed when saving. Google-hosted custom-domain
addresses work with this profile too. No OAuth application, consent screen, or callback
is needed. Saved accounts are **configured**; saving performs no network request.

The selected paired Gateway needs this release's `gmail_imap` v1 and `email_smtp`
support. Connections use verified TLS to `imap.gmail.com:993` and verified STARTTLS
to `smtp.gmail.com:587`. The profile does not accept custom hosts or insecure TLS.
Update older Gateways if the private Gmail operation route is unavailable.

Example prompts:

- “Test Gmail IMAP and SMTP with @personal_gmail.”
- “Use Gmail with @personal_gmail to summarize unread messages from today.”
- “Use Email / SMTP with @personal_gmail to send this message to alice@example.com.”

`gmail.test_connection(account_ref="@personal_gmail")` tests both connections independently
without changing mail or sending anything. `email.test_connection(profile_key="@personal_gmail")`
tests SMTP only. Both skills use this one saved record. Enable each skill separately in
Capability Policy; enabling Gmail does not require enabling Email / SMTP for Gmail sends.
Setup does not enable either skill automatically.

App-password Gmail supports search, messages, threads, attachments, drafts, send/reply/forward,
read/star state, archive, trash/untrash, and custom labels. Filters and label visibility
settings require an OAuth account. System folders are protected. Reads use `BODY.PEEK`
and preserve unread state. Gmail remains the mailbox authority; there is no background sync.

The socket timeout defaults to 30 seconds and can be changed in this profile (1–120 seconds).
Each network operation has a total deadline of `min(300, timeout_seconds × 4)` seconds.
These settings do not control model generation or thinking.

Draft replacement returns a new draft reference after creating and verifying the replacement.
If retiring the original fails, the result reports partial completion and both references.
Removal moves the exact draft to Trash. SMTP acceptance remains confirmed if subsequent
draft cleanup fails; cleanup never resends. A lost write acknowledgment is an unknown effect
and blocks automatic replay. An exact Sent-folder match can reconcile an uncertain send;
an inconclusive search never authorizes another send. Gmail already saves SMTP-sent messages,
so the integration never appends a second Sent copy.

Continuation tokens and bulk previews expire after ten minutes and on restart. Account edits
or mailbox UIDVALIDITY changes invalidate them; request a fresh search/preview. Approved bulk
operations use exactly the previewed IDs and report confirmed, failed and unattempted items.

## Connect with OAuth

Enable the Gmail skill in Capability Policy. In **Parameter Store → New → Gmail OAuth App**, enter your existing Google OAuth application's client ID and client secret. Save it as `gmail_auth_app`. smTO does not supply or register a Google OAuth application.

```json
{
  "profile_type": "gmail_oauth_app",
  "profile_version": 1,
  "service": "gmail",
  "client_type": "desktop",
  "client_id": "YOUR_CLIENT_ID",
  "client_secret": "YOUR_CLIENT_SECRET",
  "authorization_uri": "https://accounts.google.com/o/oauth2/v2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "scopes": [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.labels"
  ]
}
```

The template fills in Google's endpoints. Desktop clients use a temporary loopback callback and the system browser. Web clients require `client_type: "web"` and a `redirect_uri` registered with Google, pointing to your controller's `/api/agent/gmail/oauth/callback`. On a remote controller, use a web application callback reachable from your browser; the desktop callback runs on the controller machine.

Ask:

> Connect Gmail using @gmail_auth_app and save the account as work_gmail.

`gmail.connect` opens Google consent or returns an authorization link. After consent, the callback creates a **Gmail Account** Parameter Store record named `work_gmail`. OAuth handshake state expires after ten minutes and is lost on restart; restart the connection if necessary. No mailbox synchronization runs after connection.

The account record contains email, the linked OAuth app reference, tokens, expiry, and granted scopes. The model receives account identity, never raw secrets. Token refresh is automatic and updates that same Parameter Store entry. A revoked refresh token returns `reauthorization_required`; reconnect to the same key using the same OAuth app and Google account. A different account cannot silently replace it.

## Use Gmail

- “Use @work_gmail and summarize unread mail from today.”
- “Find the latest message from alice@example.com using @work_gmail.”
- “Draft a reply in @work_gmail.”
- “Send the reviewed Gmail draft.”
- “Forward Susan's PDF from @work_gmail to John.”
- “Trash promotions older than one year in @personal_gmail.”

The main agent chooses searches, reads relevant messages or threads, and writes summaries or replies. Gmail tools contain no separate planning or summarization model. Email bodies, headers and attachment filenames remain untrusted external data.

Search supports Gmail query syntax and concrete structured filters, returns metadata first, and exposes continuation tokens. Bodies are bounded and truncation is explicit. Attachment presence is unknown in metadata-only results; read the selected message for attachment details. Counts report a lower bound when their explicit maximum is reached.

Drafts, labels, filters, and sends operate directly in Gmail. Compose and reply support text, HTML, CC/BCC, and attachments. For outgoing attachments, pass an existing `artifact://` reference, a granted uploaded `ctx_...` / `context://` reference, an `artifact-workspace://` path, or a file supported by the normal task temporary-file publication mechanism. Explicit downloads become normal run artifacts; Gmail has no attachment cache. Forwarding can include the original message and attachments.

Filter operations need `https://www.googleapis.com/auth/gmail.settings.basic`. Add that scope to the OAuth app and reconnect explicitly. Tools report missing scope without widening authorization automatically.

## Accounts, confirmation, and reliability

Multiple accounts are separately named parameters: `@work_gmail`, `@personal_gmail`, or any chosen key. Rename an account through the normal Parameter Store editor and use the new `@name` immediately. Explicit tool references win; otherwise a single accepted Gmail reference or a single available account can supply the account. Multiple candidates require selection. Account operations resolve current Parameter Store authorization, so deletion or rename takes effect immediately. If renaming an OAuth app, update the accounts' `oauth_app_ref` as well.

Mutations use the existing permission and confirmation policy. `gmail.preview_modify` resolves a bounded exact selection and returns a ten-minute, one-use selection token. `gmail.batch_modify` executes those IDs after approval, without rerunning the query. A restart or expiry requires a new preview. Label/state changes use native batches of at most 1,000 messages. Trash is reversible; permanent deletion is not exposed.

A lost write response may mean Gmail applied the operation. smTO reports an unknown effect and the runtime prevents automatic replay. Sends use RFC822 Message-ID reconciliation against Sent where possible; an inconclusive lookup never triggers another send.

## Existing installations

Existing `gmail_oauth_app` and `gmail_account` Parameter Store records remain supported
without migration. Startup does not import, rewrite, rename or remove old credential
files. Reconnect explicitly if credentials are not already available in Parameter Store.

For a shared Google Workspace identity, use `auth.google_connect` with a
`google_oauth_app` and the Gmail features needed. Existing `gmail.*` tools also accept
the resulting `google_account`. They validate operation-specific granted scopes and
return `google.scope_upgrade_required` on the selected account when access is missing.
Use that same account key when adding Calendar or Drive features. See
[Shared Google Workspace identity](27-google-workspace.md).

OAuth configuration and authorization live in Parameter Store. There is no extra Gmail settings page, credential database, or primary-account database. Legacy sync, cache removal, broker callback, and OAuth configuration routes return HTTP 410. Parameter Store encryption and vault integration are separate future work.
