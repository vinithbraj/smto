---
id: artifacts-output
title: Artifacts and output publication
kind: architecture
tags: [architecture, current, artifacts-output]
order: 25
---
# Artifacts and output publication

`agent_runtime/artifacts` is production implementation, despite sharing a name with the
repository's generated top-level output directory. The artifact store owns generated
file identity, immutable versions, provenance and lifecycle. Collection registers actual
files; previews, exports, download access and retention are separate responsibilities.

The output pipeline shapes actual results into display documents and exports. Publication
does not manufacture execution evidence. A rendered table, chart or download card is a
projection of an underlying result/version; completion still follows receipt and task
contract validation.

Artifact API access is conversation-scoped. `ArtifactAccess` accepts the configured API
credential or a valid expiring session. Local bootstrap checks loopback client and host,
origin and cross-site rules; forwarded headers do not establish trust. Configuring
`AOR_ARTIFACT_API_TOKEN` disables unauthenticated local bootstrap. Session hashes persist
in the artifact store so ordinary restarts need not discard valid sessions.

Previews are sanitized/bounded and browser viewers preserve their sandbox boundary.
Retention and cleanup can make old files unavailable; a prior download link is not an
unlimited storage guarantee. Literal credentials may appear in generated content. FILES optionally masks consumer previews without changing raw artifacts. Source owners include `artifacts/api.py`, `store.py`, `preview.py`, `export.py`,
`maintenance.py` and `output_pipeline/`.

Updated Gateways expose `OF_RUN_TEMP_DIR` under their own system temporary root,
with `OF_ACTIVITY_TEMP_DIR` for activity/receipt isolation. Finalized regular
files there are published automatically, regardless of type. `TMPDIR` on POSIX,
or `TEMP`/`TMP` on Windows, points to the activity temp directory (otherwise run
temp). Explicit command assignments can override these defaults. Explicit CWD,
terminal CWD, Gateway default CWD and configured workspaces keep their semantics.
`OF_RUN_ARTIFACT_DIR` remains the preferred output directory;
`OF_RUN_SCRATCH_DIR` outside its `published` child remains private scratch.

Concrete system-temp paths in current tool output or the final assistant answer
can be staged on the original Gateway, then transferred through the bounded
artifact reader. The server never opens a remote path locally. Global temp is
never crawled; parent traversal, symlinks/reparse points and special files cannot
be promoted. Older Gateways keep workspace collection and receive no unsupported
temp actions.

Executed terminal `python.run` attempts also retain their exact submitted UTF-8
source at `source/python/<operation hash>.py`, excluding wrappers and injected
inputs. Shell command strings are not automatically stored as scripts. Files
remain downloadable through the existing artifact surface after Gateway cleanup
or disconnection. Images render inline from authorized server artifact endpoints;
other files use the existing preview/download cards. Display enrichment happens
after completion validation and adds zero model calls. Stored source bindings
support deterministic retries and history rendering without resolving old paths
against a newly selected Gateway.

Gateway artifact caches are cleared on startup and checked every 24 hours.
The daily pass removes caches idle for at least 24 hours, including staged
workspace files and publishable task temp. Active requests and tracked running
or uncertain jobs protect their files. Private scratch, unrelated shared temp
files and saved server artifacts are preserved. Output that has not reached
the server can be lost at startup or expiry; server downloads continue to use
their separate conversation retention policy. Cleanup is shared by all Gateway
platforms and both connection modes, in `gateway_core/artifact_maintenance.py`.
