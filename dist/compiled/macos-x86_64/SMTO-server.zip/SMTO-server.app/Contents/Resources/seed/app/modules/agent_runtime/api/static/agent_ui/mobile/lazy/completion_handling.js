import "./advanced.js";
/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/lazy/completion_handling.js
 * @brief Adapt shared Agent Checks policies to the mobile options sheet.
 * @details
 * Responsibilities: Mount scoped native policy fields and expose temporary prompt guard drafts.
 * Boundaries: Shared renderers own field events; APIs own policy validation and durable persistence.
 * Lifecycle: options mounts the panel; refreshOptions reconciles it; requestAccepted consumes drafts.
 * State: Drafts are keyed by conversation in memory; mounted holds only the current sheet projection.
 * Security: Policy classes carry no authorization and this adapter stores no credentials.
 * Collaborators: composer_profile.js supplies conversation settings; api.js supplies requests/state;
 *   agent_checks.js shares field rendering with desktop.
 * Public surface: options, refreshOptions, policyForRequest and requestAccepted support the composer.
 * @see src/agent_runtime/api/static/agent_ui/agent_checks.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/composer_profile.js
 */
import {composerProfile} from "../composer_profile.js";
import "../../agent_checks.js?v=20261015-smto";
import { api, state } from "../api.js";
export function decision() {} // Historical compatibility; registry strikes own rendering.
let mounted;
const drafts = new Map();
state.runtimeGuardDraft = policyForRequest;
state.consumePolicyDraft = requestAccepted;
state.refreshPolicyOptions = refreshOptions;
function draft() {
  const cid = state.conversationId || "new";
  if (!drafts.has(cid)) drafts.set(cid, {});
  return drafts.get(cid);
}
export function policyForRequest() { return {...draft()}; }
export function requestAccepted(cid) { drafts.delete(cid || "new"); window.SMTOAgentChecks.clearStopDraft(cid); }
export async function refreshOptions() { await mounted?.refresh(); }
export function options(body, hooks) {
  mounted = window.SMTOAgentChecks.panel(body, {initialScope: "prompt", allowPrompt: true, draft: draft(),
    requestId: state.requestId, conversationId: state.conversationId, composerSettings: () => composerProfile.current(),
    apiJson: (url, options = {}) => api(url.replace("/api/agent/", ""), {
      ...options, ...(options.body ? {body: JSON.parse(options.body)} : {})}),
    reload: () => hooks.refresh()});
}
