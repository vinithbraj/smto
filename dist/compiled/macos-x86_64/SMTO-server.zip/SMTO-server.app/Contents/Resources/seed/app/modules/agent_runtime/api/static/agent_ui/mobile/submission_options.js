import {state} from "./api.js";
import {composerProfile} from "./composer_profile.js";
import {targets} from "./targets.js";
export function submissionOptions() {
  // Navigation already loaded the composer catalog and target registry. Capture
  // that intent synchronously; admission and preflight validate live authority.
  if (!composerProfile.ready() || state.composerProblem) throw window.SMTOErrors.error("ui_composer_not_ready");
  const captured = targets().draftSnapshot();
  const config = state.config,
    selected = state.choices;
  const reason = targets().unavailable(captured);
  if (reason) throw window.SMTOErrors.error("ui_composer_not_ready");
  const target = targets().recordsSnapshot().find(t => t.gateway_id === captured.gateway_selection.primary_gateway_id);
  if (!config?.models.some((model) => model.value === selected.llm_model))
    throw window.SMTOErrors.error("ui_model_required");
  return {
    ...composerProfile.submission(),
    runtime_guard_policy: state.runtimeGuardDraft?.() || {},
    stop_policy: window.SMTOAgentChecks?.stopPolicyForRequest?.(state.conversationId),
    context_read_policy: window.SMTOAgentChecks?.contextPolicyForRequest?.(state.conversationId),
    task_contract_integrity_guard_enabled: window.SMTOAgentChecks?.integrityForRequest?.(state.conversationId),
    parallel_execution_policy: window.SMTOAgentChecks?.parallelPolicyForRequest?.(state.conversationId),
    background_activity_policy: window.SMTOAgentChecks?.backgroundPolicyForRequest?.(state.conversationId),
    dependency_scheduling_policy: window.SMTOAgentChecks?.dependencyPolicyForRequest?.(state.conversationId),
    scheduling_preference: window.SMTOAgentChecks?.schedulingPreferenceForRequest?.(state.conversationId),
    resource_scheduling_policy: window.SMTOAgentChecks?.resourcePolicyForRequest?.(state.conversationId),
    agent_mode: selected.agent_mode,
    llm_model: selected.llm_model,
    behavior_effort: selected.behavior_effort,
    gateway_id: target.gateway_id,
    gateway_label: target.label,
    gateway_locality: target.locality || "unknown",
    gateway_selection: captured.gateway_selection,
    permission_policy: selected.permission_policy || null,
    capability_policy: selected.capability_policy || null,
    capability_selection: selected.capability_selection || null,
  };
}
