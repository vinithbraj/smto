/* Installation-owned Skill configuration. No browser persistence or model calls. */
(() => {
  "use strict";
  const api = async (path, options = {}) => {
    const response = await window.SMTOErrors.fetch(path, {headers: {"Content-Type": "application/json"}, ...options});
    const data = await window.SMTOErrors.readJson(response);
    if (!response.ok) throw window.SMTOErrors.fromPayload(data, response.status);
    return data;
  };
  const element = (tag, text, className) => {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    if (className) node.className = className;
    return node;
  };
  const button = (text, action) => {
    const node = element("button", text); node.type = "button";
    node.addEventListener("click", action); return node;
  };
  const get = (object, path) => path.split(".").reduce((value, key) => value?.[key], object);
  const set = (object, path, value) => {
    const parts = path.split("."); const key = parts.pop();
    for (const part of parts) object = object[part] ??= {};
    object[key] = value;
  };
  const dialog = (title) => {
    const node = element("dialog", "", "skill-configuration-dialog");
    node.setAttribute("aria-label", title);
    const head = element("header"); head.append(element("h2", title), button("Close", () => node.close()));
    node.append(head); document.body.append(node);
    node.addEventListener("close", () => node.remove(), {once: true});
    node.showModal(); return node;
  };
  let catalogDialog = null, editor = null;

  async function refreshList() {
    if (!catalogDialog?.open) return;
    const host = catalogDialog.querySelector("[data-skill-list]");
    try {
      const catalog = await api("/api/agent/capabilities/catalog");
      if (!host.isConnected) return;
      host.replaceChildren();
      for (const skill of catalog.skills) {
        const row = element("section", "", "skill-configuration-card");
        row.dataset.skillId = skill.skill_id;
        row.append(element("h3", skill.display_name), element("p", skill.description));
        for (const tool of skill.tools) row.append(element("p", `${tool.tool_id}: ${tool.available ? "Ready" : tool.reason}`));
        if (skill.configurable) {
          row.append(element("p", skill.configuration_status === "ready" ? "Ready" : "Partially configured"));
          row.append(button("Configure", () => open(skill.skill_id, skill.display_name)));
        }
        host.append(row);
      }
    } catch (error) { window.SMTOErrors.present(host, error); }
  }

  function showSkills() {
    if (catalogDialog?.open) return;
    catalogDialog = dialog("Skills");
    const host = element("div"); host.dataset.skillList = ""; catalogDialog.append(host);
    void refreshList();
  }

  async function open(skillId, name = skillId) {
    if (editor?.node.open) return;
    const node = dialog(`${name} configuration`);
    const status = element("p", "Loading configuration…", "skill-configuration-status");
    status.setAttribute("role", "status"); node.append(status);
    const state = {node, skillId, dirty: false, busy: false, version: 0, remote: false};
    editor = state;
    const path = `/api/agent/skills/${encodeURIComponent(skillId)}/configuration`;
    const body = element("div"); node.append(body);
    const save = button("Save", async () => {
      if (!state.form.reportValidity()) return;
      state.busy = true; save.disabled = true;
      const version = state.version;
      try {
        const result = await api(path, {method: "PUT", body: JSON.stringify(state.draft)});
        if (state.version === version) {
          state.dirty = false; state.remote = false; state.data = result;
          status.textContent = "Saved. Future calls use this configuration.";
        } else status.textContent = "Saved. Newer edits still need Save.";
        void refreshList();
      } catch (error) { window.SMTOErrors.present(status, error); }
      finally {
        state.busy = false; save.disabled = false;
        if (state.pendingSync) { state.pendingSync = false; void state.sync(); }
      }
    });
    const reload = button("Reload saved configuration", () => void load());
    const footer = element("footer"); footer.append(reload, save); node.append(footer);
    node.addEventListener("cancel", event => {
      if (state.busy) event.preventDefault();
    });
    const dynamicOptions = [];
    const testStatuses = [];
    const changed = () => {
      state.dirty = true; state.version++; status.textContent = "Unsaved changes";
      for (const refresh of dynamicOptions) refresh();
      for (const tested of testStatuses) {
        if (tested.textContent) tested.textContent = "Configuration changed; test again.";
      }
    };

    function renderField(field, object, target) {
      if (field.kind === "entries") {
        const section = element("section", "", "skill-configuration-entries");
        section.append(element("h3", field.label));
        const values = get(object, field.key) || [];
        for (const entry of values) {
          const card = element("fieldset", "", "skill-configuration-card");
          card.append(element("legend", entry.name || "New entry"));
          card.dataset.entryId = entry[field.identity_key];
          for (const child of field.fields) renderField(child, entry, card);
          const testStatus = element("span"); testStatus.setAttribute("role", "status");
          testStatuses.push(testStatus);
          const actions = element("div", "", "skill-configuration-actions");
          if (state.data.definition.testable) actions.append(button("Test connection", async event => {
            if (!state.form.reportValidity()) return;
            const control = event.currentTarget; control.disabled = true;
            testStatus.textContent = "Testing…";
            const version = state.version;
            try {
              const result = await api(path + "/test", {method: "POST", body: JSON.stringify({
                configuration: state.draft, provider_id: entry[field.identity_key],
              })});
              testStatus.textContent = (state.version !== version ? "Earlier candidate: " : "") + result.message;
              testStatus.dataset.ok = String(result.ok);
            } catch (error) { window.SMTOErrors.present(testStatus, error); }
            finally { control.disabled = false; }
          }));
          actions.append(button("Remove", () => {
            set(object, field.key, values.filter(value => value !== entry));
            // Removing a referenced default explicitly leaves it unconfigured.
            for (const option of state.data.definition.fields.filter(f => f.options_from === field.key)) {
              if (get(state.draft, option.key) === entry[field.identity_key]) set(state.draft, option.key, null);
            }
            changed(); render();
          }), testStatus);
          card.append(actions); section.append(card);
        }
        const add = button(field.add_label, () => {
          const entry = structuredClone(field.default || {});
          // Like the queue UI, support installations opened over plain LAN HTTP.
          const id = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
          entry[field.identity_key] = "entry_" + id.replaceAll("-", "");
          set(object, field.key, [...values, entry]); changed(); render();
          body.querySelector(`[data-entry-id="${entry[field.identity_key]}"] input`)?.focus();
        });
        add.disabled = values.length >= field.maximum; section.append(add); target.append(section); return;
      }
      const label = element("label", "", "skill-configuration-field");
      label.append(element("span", field.label));
      if (field.kind === "secret_reference") {
        const reference = get(object, field.key) || {parameter_key: "", pointer: ""};
        for (const [key, title] of [["parameter_key", "Parameter Store key"], ["pointer", "Credential field pointer"]]) {
          const input = element("input"); input.value = reference[key]; input.maxLength = key === "pointer" ? 512 : 160;
          input.setAttribute("aria-label", title);
          input.addEventListener("input", () => { reference[key] = input.value; set(object, field.key, reference); changed(); });
          label.append(input);
        }
      } else {
        const input = element(field.kind === "select" ? "select" : "input");
        input.setAttribute("aria-label", field.label);
        if (field.kind === "select") {
          const source = state.data.definition.fields.find(f => f.key === field.options_from);
          const options = field.options_from ? [{value: "", label: "Not configured"},
            ...(get(state.draft, field.options_from) || []).filter(e => e.enabled).map(e => ({value: e[source.identity_key], label: e.name}))] : field.options;
          for (const option of options) {
            const opt = element("option", option.label); opt.value = option.value; input.append(opt);
          }
          if (field.options_from) dynamicOptions.push(() => {
            input.replaceChildren();
            for (const option of [{value: "", label: "Not configured"},
              ...(get(state.draft, field.options_from) || []).filter(e => e.enabled).map(e => ({value: e[source.identity_key], label: e.name}))]) {
              const opt = element("option", option.label); opt.value = option.value; input.append(opt);
            }
            input.value = get(object, field.key) || "";
          });
        } else {
          input.type = ({url: "url", number: "number", boolean: "checkbox"})[field.kind] || "text";
          if (field.minimum !== null) input.min = field.minimum;
          if (field.maximum !== null) input.max = field.maximum;
          if (field.max_length !== null) input.maxLength = field.max_length;
        }
        const value = get(object, field.key);
        if (field.kind === "boolean") {
          input.classList.add("mission-switch");
          input.setAttribute("role", "switch");
        }
        if (field.kind === "boolean") input.checked = Boolean(value); else input.value = value ?? "";
        input.required = ["url", "number"].includes(field.kind);
        input.addEventListener("input", () => {
          set(object, field.key, field.kind === "boolean" ? input.checked : field.kind === "number" ?
            (input.value === "" ? null : input.valueAsNumber) : field.options_from ? (input.value || null) : input.value);
          if (field.key === "enabled" && !input.checked) {
            for (const option of state.data.definition.fields.filter(f => f.options_from)) {
              const source = state.data.definition.fields.find(f => f.key === option.options_from);
              if (get(state.draft, option.key) === object[source.identity_key]) set(state.draft, option.key, null);
            }
          }
          changed();
          if (field.key === "enabled") render();
        });
        label.append(input);
      }
      if (field.description) label.append(element("small", field.description));
      target.append(label);
    }

    function render() {
      dynamicOptions.length = 0;
      testStatuses.length = 0;
      body.replaceChildren(element("p", state.data.definition.description));
      state.form = element("form"); state.form.addEventListener("submit", event => event.preventDefault());
      for (const field of state.data.definition.fields) renderField(field, state.draft, state.form);
      body.append(state.form);
    }
    async function load() {
      try {
        state.data = await api(path);
        state.draft = structuredClone(state.data.configuration); state.dirty = false; state.remote = false;
        status.textContent = state.data.warning || "Installation-level configuration. Changes take effect after Save.";
        render();
      } catch (error) { window.SMTOErrors.present(status, error); save.disabled = true; }
    }
    state.reload = load;
    state.sync = async () => {
      if (state.busy) { state.pendingSync = true; return; }
      const next = await api(path);
      if (state.busy) { state.pendingSync = true; return; }
      if (!node.open || next.updated_at === state.data?.updated_at) return;
      if (state.dirty) {
        state.remote = true;
        status.textContent = "Saved configuration changed elsewhere. Your edits are retained; reload to use the saved version.";
      } else {
        state.data = next; state.draft = structuredClone(next.configuration);
        status.textContent = "Synced saved configuration."; render();
      }
    };
    await load();
  }

  window.SMTOSkillConfiguration = {open, showSkills};
  document.querySelector("#settings-skills-button")?.addEventListener("click", showSkills);
  window.SMTOUiUpdates?.subscribe("skill-configuration.changed", async () => {
    void refreshList();
    if (editor?.node.open) {
      await editor.sync();
    }
  });
})();
