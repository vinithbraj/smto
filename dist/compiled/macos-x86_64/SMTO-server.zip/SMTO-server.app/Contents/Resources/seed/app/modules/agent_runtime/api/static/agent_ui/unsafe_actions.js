/**
 * @file src/agent_runtime/api/static/agent_ui/unsafe_actions.js
 * @brief Bind exact-operation owner confirmation to the existing unsafe-action API.
 * @details
 * Responsibilities: Present operation and target details for explicit approval.
 * Boundaries: The server validates authorization, operation identity, and expiry.
 * Lifecycle: mount creates a dialog; render binds a pending request; explicit submit posts confirmation.
 * State: Current request, generation and expiry timer are volatile; cancel revokes approval.
 * Security: The server binds approval to the exact operation and current authority.
 * Collaborators: app.js supplies refresh/stop hooks; agent_checks.css provides the explicit field skin.
 * Public surface: SMTOUnsafeActions.mount returns the dialog controller for pending requests.
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/api/static/agent_ui/agent_checks.css
 */
(() => {
  "use strict";
  function mount({onAccepted, onStop, onRefresh}) {
    const dialog = document.createElement("dialog");
    dialog.className = "action-confirmation unsafe-action-dialog";
    dialog.setAttribute("aria-labelledby", "unsafe-action-title");
    dialog.setAttribute("aria-describedby", "unsafe-action-effect");
    dialog.innerHTML = `<form autocomplete="off">
      <h2 id="unsafe-action-title">Unsafe action requires confirmation</h2>
      <p>I need your approval to perform an operation that may cause data loss, service interruption, or system unavailability.</p>
      <strong>Target</strong><p class="unsafe-target"></p>
      <strong>Exact operation</strong><pre class="unsafe-command"></pre>
      <p id="unsafe-action-effect"></p>
      <p class="unsafe-status" role="status" aria-live="polite"></p>
      <div class="action-confirmation-actions"><button type="button" class="unsafe-cancel" autofocus>Cancel</button>
        <button type="submit" class="unsafe-confirm">Proceed</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const submit = dialog.querySelector(".unsafe-confirm"), cancel = dialog.querySelector(".unsafe-cancel");
    const status = dialog.querySelector(".unsafe-status");
    let current = null, busy = false, generation = 0, expiryTimer = null;
    const labels = {shutdown: "Shut down", restart: "Restart", poweroff: "Power off", delete: "Delete", proceed: "Proceed"};
    async function stop() {
      if (!current || busy) return;
      busy = true; submit.disabled = cancel.disabled = true;
      try { await onStop(current.request_id); dialog.close(); }
      finally { busy = false; await onRefresh(); }
    }
    cancel.addEventListener("click", stop);
    dialog.addEventListener("cancel", event => { event.preventDefault(); void stop(); });
    dialog.addEventListener("keydown", event => {
      if (event.key !== "Tab") return;
      const items = [...dialog.querySelectorAll("button:not(:disabled), input:not(:disabled)")]
        .filter(element => element.getClientRects().length);
      const index = items.indexOf(document.activeElement);
      if (!items.length) { event.preventDefault(); return; }
      if (event.shiftKey && index <= 0) { event.preventDefault(); items.at(-1).focus(); }
      else if (!event.shiftKey && (index === items.length - 1 || index < 0)) {
        event.preventDefault(); items[0].focus();
      }
    });
    form.addEventListener("submit", async event => {
      event.preventDefault();
      if (!current?.valid || busy || current.accepted) return;
      busy = true; submit.disabled = cancel.disabled = true;
      const revision = generation, request = current;
      let body = JSON.stringify({action: "confirm", challenge_id: request.challenge_id,
        ...(request.authority_request_id ? {authority_request_id: request.authority_request_id} : {}),
      });
      status.textContent = "Authorizing this exact action…";
      try {
        const response = await window.SMTOErrors.fetch(`/api/agent/native/${encodeURIComponent(request.request_id)}/unsafe-action`, {
          method: "POST", headers: {"Content-Type": "application/json"}, body,
        });
        body = "";
        if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
        const result = await window.SMTOErrors.readJson(response);
        if (revision === generation) dialog.close();
        onAccepted({...result, resumed: true});
      } catch (error) {
        if (revision === generation) window.SMTOErrors.present(status, error);
      } finally {
        body = ""; busy = false;
        submit.disabled = !current?.valid || Boolean(current?.accepted); cancel.disabled = false;
        await onRefresh();
      }
    });
    function update(request, cancelled = false) {
      if (expiryTimer) { clearTimeout(expiryTimer); expiryTimer = null; }
      if (!request || cancelled || request.policy_changed) { current = null; generation++; dialog.close(); return; }
      const changed = request.challenge_id !== current?.challenge_id;
      if (changed) { generation++; status.textContent = ""; }
      current = request;
      if (Number.isFinite(request.expires_at) && request.valid) {
        expiryTimer = setTimeout(() => {
          if (current?.challenge_id !== request.challenge_id) return;
          current = {...current, valid: false}; submit.disabled = true;
          status.textContent = "This authorization expired. Cancel and request the action again.";
        }, Math.max(0, request.expires_at * 1000 - Date.now()));
      }
      dialog.querySelector(".unsafe-target").textContent = request.target;
      // Render all arguments, including cwd, inputs and the complete sequence.
      dialog.querySelector(".unsafe-command").textContent = JSON.stringify(
        request.invocations || request.arguments, null, 2);
      const label = labels[request.action] || "Proceed";
      dialog.querySelector("h2").textContent = request.effect_class === "host_control"
        ? `${label} ${request.target.split(" · ")[0]}` : "Unsafe action requires confirmation";
      dialog.querySelector("#unsafe-action-effect").textContent = request.effect_class === "host_control"
        ? `This will ${request.action === "restart" ? "restart" : "shut down"} the machine and may disconnect its Gateway.`
        : "This action may permanently change or delete data or interrupt services.";
      submit.textContent = label;
      submit.disabled = busy || !request.valid || request.accepted;
      cancel.disabled = busy;
      if (!request.valid) status.textContent = "This authorization expired or was revoked. Cancel and request the action again.";
      if (request.accepted) status.textContent = "Authorization accepted. Resuming this action…";
      if (!dialog.open) dialog.showModal();
    }
    return {update};
  }
  window.SMTOUnsafeActions = {mount};
})();
