import { button, node } from "../api.js";
import { openSheet, closeSheet, mountControls } from "../overlays.js";

export function open(turn, returnFocus) {
  if (turn.disposed || !turn.root.isConnected) return;
  const wasOpen = turn.controls.open;
  const body = openSheet("Message details", {returnFocus, onClose: () => { turn.controls.open = wasOpen; }});
  mountControls(body, ...turn.root.querySelectorAll(":scope > .message-time-heading"),
    turn.tokenUsage, turn.detailActions, turn.executionInspector?.root, turn.controls);
  const mode = turn.root.querySelector(":scope > .task-mode-banner");
  if (mode) body.prepend(node("p", `Mode · ${mode.textContent}`, "muted"));
  turn.controls.open = true;
  const remove = turn.activityGroup?.querySelector(":scope > .task-delete-button");
  if (remove) body.append(button("Delete task", async () => {
    await closeSheet();
    if (remove.isConnected && !remove.disabled) remove.click();
  }, "choice"));
  body.append(button("View activity", async () => {
    await closeSheet();
    if (turn.disposed || !turn.root.isConnected) return;
    turn.activity.open = true;
    for (const group of turn.activity.querySelectorAll(".prose-activity")) group.open = true;
    turn.activity.scrollIntoView({block: "nearest"});
  }, "choice"));
}
