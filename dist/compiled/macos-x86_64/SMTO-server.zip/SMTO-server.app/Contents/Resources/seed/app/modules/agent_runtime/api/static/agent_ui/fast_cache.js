/* Deterministic user retention controls. Only durable request identities are submitted. */
(() => {
  "use strict";
  const base = "/api/agent/fast-cache";
  const el = (tag, className, text) => {
    const node = document.createElement(tag);
    node.className = className || "";
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const button = (text, label, action) => {
    const node = el("button", "", text);
    node.type = "button";
    node.title = label; node.setAttribute("aria-label", label);
    node.addEventListener("click", action);
    return node;
  };
  const channel = typeof BroadcastChannel === "function" ? new BroadcastChannel("smto-fast-cache") : null;
  const changed = () => {
    window.dispatchEvent(new Event("fast-cache-changed"));
    channel?.postMessage("changed");
  };
  if (channel) channel.onmessage = () => window.dispatchEvent(new Event("fast-cache-changed"));
  async function api(path, body, method = "GET") {
    const response = await window.SMTOErrors.fetch(base + path, {
      method, cache: "no-store", headers: {"Accept": "application/json", "Content-Type": "application/json"},
      ...(body ? {body: JSON.stringify(body)} : {}),
    });
    if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
    return window.SMTOErrors.readJson(response);
  }
  const post = (path, body) => api(path, body, "POST");
  function describe(item) {
    const copy = el("div", "fast-cache-copy");
    const title = item.prompt || (item.unassigned ? "Recipe · No prompt assigned" : `Exact prompt · ${item.prompt_hash?.slice(0, 12) || "Unavailable"}`);
    copy.append(el("strong", "", title));
    const tools = (item.tools || [item.tool_id]).filter(Boolean).map(id => id.split(".")[0]).join(", ");
    copy.append(el("span", "fast-cache-context", `${item.step_count || 0} read${item.step_count === 1 ? "" : "s"} · ${tools}`));
    copy.append(el("span", "fast-cache-context", [item.cwd, item.gateway].filter(Boolean).join(" · ")));
    if (item.plan?.length) {
      const details = el("details", "fast-cache-plan");
      details.append(el("summary", "", "Verified read plan"));
      const steps = el("ol");
      for (const step of item.plan) {
        const row = el("li"); row.append(el("code", "fast-cache-command", step.command)); steps.append(row);
      }
      details.append(steps); copy.append(details);
    }
    return copy;
  }
  function attachPrompt(turn, row) {
    if (!turn.requestId || turn.refreshFastCache) return;
    let control, generation = 0, timer;
    async function refresh(attempt = 0) {
      await window.SMTOReadPriority?.ready;
      clearTimeout(timer);
      const current = ++generation;
      if (!row.isConnected) return;
      try {
        const item = await api(`/prompts/${encodeURIComponent(turn.requestId)}`);
        if (current !== generation || !row.isConnected) return;
        if (!item.eligible) {
          control?.remove(); control = null;
          // Terminal trace delivery may precede the final cache capture commit.
          if (attempt < 3) timer = setTimeout(() => refresh(attempt + 1), 400 * (attempt + 1));
          return;
        }
        if (!control) {
          control = button("+", "Pin prompt to Fast Cache", async event => {
            event.stopPropagation(); event.preventDefault();
            if (control.dataset.pinned === "true") return;
            control.disabled = true;
            try {
              await post("/prompts/pin", {request_id: turn.requestId});
              changed();
            } catch (error) {
              control.title = error.message;
              control.setAttribute("aria-label", error.message);
            } finally { if (control) control.disabled = false; }
          });
          control.className = "icon-button fast-cache-prompt-pin";
          row.append(control);
        }
        control.dataset.pinned = String(item.pinned);
        control.textContent = item.pinned ? "✓" : "+";
        control.dataset.uiSymbol = item.pinned ? "check" : "";
        control.title = item.pinned ? "Pinned to Fast Cache" : "Pin prompt to Fast Cache";
        control.setAttribute("aria-label", item.pinned ? "Pinned to Fast Cache" : "Pin this prompt and its verified read plan to Fast Cache");
        control.setAttribute("aria-disabled", String(item.pinned));
      } catch (_) {
        // An unavailable authority cannot leave an old eligibility control visible.
        if (current === generation) { control?.remove(); control = null; }
      }
    }
    const onChange = () => {
      if (row.isConnected) void refresh();
      else { clearTimeout(timer); window.removeEventListener("fast-cache-changed", onChange); }
    };
    window.addEventListener("fast-cache-changed", onChange);
    turn.disposeFastCache = () => { generation++; clearTimeout(timer); window.removeEventListener("fast-cache-changed", onChange); };
    turn.refreshFastCache = refresh;
    if (turn.historical) void refresh();
  }
  function mountSettings(sections, nav) {
    const section = el("details", "mission-settings-section"); section.id = "settings-section-fast-cache";
    section.dataset.sectionSearch = "fast cache pinned prompts learned verified read plans";
    const summary = el("summary", "mission-settings-section-summary"); summary.append(el("h2", "", "Fast Cache"));
    const body = el("div", "mission-section-body");
    const intro = el("div", "mission-setting-row");
    intro.append(el("p", "mission-section-copy", "Keep exact prompts and their verified read plans. Every use reads current information again. Pinned prompts remain until removed here, even if their conversation is deleted."));
    const counts = el("p", "fast-cache-status"); counts.setAttribute("role", "status");
    const entries = el("div", "fast-cache-entries");
    const filter = el("select"); filter.setAttribute("aria-label", "Fast Cache entries");
    for (const name of ["Pinned prompts", "Learned", "All"]) {
      const option = el("option", "", name); option.value = name.split(" ")[0].toLowerCase(); filter.append(option);
    }
    const refresh = button("Refresh", "Refresh Fast Cache", load);
    const clear = button("Clear learned", "Clear learned Fast Cache recipes", async () => {
      clear.disabled = true;
      try { await api("/learned", null, "DELETE"); changed(); }
      catch (error) { window.SMTOErrors.present(counts, error); clear.disabled = false; }
    });
    const tools = el("div", "fast-cache-actions"); tools.append(clear, refresh, filter);
    body.append(intro, el("h3", "", "Pinned prompts"), counts, tools, entries); section.append(summary, body); sections.append(section);
    const link = el("a", "", "Fast Cache"); link.href = "#" + section.id; nav.append(link);
    let data = [];
    function render() {
      entries.replaceChildren();
      const visible = data.filter(item => filter.value === "all" || item.pinned === (filter.value === "pinned"));
      for (const item of visible) {
        const row = el("div", "mission-setting-row fast-cache-entry");
        row.dataset.settingSearch = [item.prompt, item.command, item.cwd, item.gateway].join(" ").toLowerCase();
        const copy = describe(item);
        const used = item.last_used_at ? new Date(item.last_used_at * 1000).toLocaleString() : "Never";
        copy.append(el("span", "fast-cache-context", `${item.pinned ? "Pinned" : "Learned"} · Hits: ${item.hit_count} · Last used: ${used}`));
        if (!item.available) copy.append(el("span", "fast-cache-context", `Unavailable · ${String(item.reason || "invalid recipe").replaceAll("_", " ")}`));
        const remove = button("Remove", "Remove prompt from Fast Cache", async () => {
          remove.disabled = true;
          try { await api(item.prompt_key ? `/prompts/${encodeURIComponent(item.prompt_key)}` : `/${encodeURIComponent(item.recipe_id)}`, null, "DELETE"); changed(); }
          catch (error) { window.SMTOErrors.present(counts, error); remove.disabled = false; }
        });
        row.append(copy, remove); entries.append(row);
      }
      if (!visible.length) entries.append(el("p", "mission-setting-row", "No prompts here yet."));
    }
    async function load() {
      refresh.disabled = true;
      try {
        const result = await api("/prompts"); data = result.entries;
        clear.disabled = result.learned_count === 0;
        counts.textContent = `Pinned: ${result.pinned_count} · Learned: ${result.learned_count}`;
        render();
      } catch (error) { window.SMTOErrors.present(counts, error); }
      finally { refresh.disabled = false; }
    }
    filter.addEventListener("change", render);
    const onChange = () => {
      if (section.isConnected) void load();
      else window.removeEventListener("fast-cache-changed", onChange);
    };
    window.addEventListener("fast-cache-changed", onChange);
    void load();
  }
  window.SMTOFastCache = {attachPrompt, mountSettings};
})();
