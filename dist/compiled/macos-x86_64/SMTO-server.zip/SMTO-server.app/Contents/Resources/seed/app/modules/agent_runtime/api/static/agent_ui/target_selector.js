/**
 * @file src/agent_runtime/api/static/agent_ui/target_selector.js
 * @brief Capture ordered Gateway intent and render the desktop multi-select control.
 * @details
 * Responsibilities: Validate bounded ID-only selections, primary changes and presentation.
 * Boundaries: The server registry resolves authority; this module never chooses transport.
 * Lifecycle: Registry updates refresh labels; submission copies validated intent.
 * State: Conversation profiles persist ID-only intent; accepted run scope is a separate copy.
 * Security: Storage accepts only IDs and bounded labels/locality, never URLs or grants.
 * Collaborators: Composer profile adapters restore intent; mobile uses the same state owner.
 * Public surface: create renders desktop controls; createState supplies shared selection APIs.
 * Compatibility: safeSnapshot and setGateway retain their single-Gateway contracts.
 * @see src/agent_runtime/api/static/agent_ui/conversation_composer_profile.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/lazy/agent_options.js
 */
(() => {
  "use strict";
  const KEY = "smto.agentUi.target.v1";
  const MAX = 16;
  const fields = ["gateway_id", "gateway_label", "gateway_locality"];
  /** Translate registry locality into the existing user-facing location label. */
  const localityName = value => ({local: "Local", remote: "Remote", unknown: "Unknown location"})[value] || "Unknown location";
  /** Bound public metadata and remove control characters before DOM presentation. */
  const text = (value, limit) => typeof value === "string" ? value.replace(/[\x00-\x1f\x7f]/g, "").slice(0, limit) : "";
  /** Accept the bounded word-leading registry ID syntax used by selection requests. */
  const idValid = value => typeof value === "string" && /^[\w][\w.-]{0,159}$/.test(value);
  /** Represent an explicitly empty composer; this value is never a valid submission. */
  const empty = () => ({schema_version: 1, gateway_ids: [], primary_gateway_id: ""});
  /** Detach nested presentation and intent objects from their state owner. */
  const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
  /** Accept only legacy public presentation fields, including saved unavailable targets. */
  function safeSnapshot(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)
      || Object.keys(value).some(key => !fields.includes(key)) || !idValid(value.gateway_id)
      || typeof value.gateway_label !== "string" || value.gateway_label.length > 240
      || /[\x00-\x1f\x7f]/.test(value.gateway_label)
      || !["local", "remote", "unknown"].includes(value.gateway_locality)) return null;
    return Object.fromEntries(fields.map(key => [key, value[key]]));
  }
  /** Empty scope is a draft state only; the server contract requires 1..16 IDs. */
  function safeSelection(value, allowEmpty = false) {
    if (!value || value.schema_version !== 1 || Array.isArray(value)
      || Object.keys(value).some(key => !["schema_version", "gateway_ids", "primary_gateway_id"].includes(key))
      || !Array.isArray(value.gateway_ids) || value.gateway_ids.length > MAX
      || !value.gateway_ids.every(idValid) || new Set(value.gateway_ids).size !== value.gateway_ids.length
      || (value.gateway_ids.length ? !value.gateway_ids.includes(value.primary_gateway_id)
        : !allowEmpty || value.primary_gateway_id !== "")) return null;
    return {schema_version: 1, gateway_ids: [...value.gateway_ids], primary_gateway_id: value.primary_gateway_id};
  }
  /** Validate the complete persisted draft projection, rejecting unknown authority fields. */
  function safeDraft(value) {
    if (!value || value.schema_version !== 2 || Array.isArray(value)
      || Object.keys(value).some(key => !["schema_version", "gateway_selection", "gateways"].includes(key))) return null;
    const scope = safeSelection(value.gateway_selection, true);
    if (!scope || !Array.isArray(value.gateways) || value.gateways.length !== scope.gateway_ids.length) return null;
    const gateways = value.gateways.map(safeSnapshot);
    if (gateways.some((item, index) => !item || item.gateway_id !== scope.gateway_ids[index])) return null;
    return {schema_version: 2, gateway_selection: scope, gateways};
  }
  /** Project immutable native scope without retaining target transports or credentials. */
  function fromNative(state) {
    const authority = state?.authority;
    if (!authority) return null;
    const node = text(authority.gateway_node || authority.node || authority.gateway_defaults?.node, 160);
    const id = text(authority.gateway_id, 160);
    if (!id && !node) return null;
    const scope = safeSelection(authority.gateway_selection || state.gateway_selection);
    return {gateway_id: id, gateway_label: node || "Execution Gateway", gateway_locality: "unknown",
      ...(scope ? {gateway_selection: scope} : {})};
  }
  /** Shared desktop/mobile intent owner. All mutations copy scope and obey steering locks. */
  function createState({onChanged = () => {}, announce = () => {}, isSteering = () => false} = {}) {
    let scope = null, presentations = [], records = [], loaded = false, failed = false, defaultId = "";
    /** Find a selected identity in the most recently verified registry projection. */
    const find = id => records.find(item => item.gateway_id === id);
    /** Refresh a selected label while retaining saved presentation for deleted identities. */
    const display = id => {
      const record = find(id);
      return record ? {gateway_id: id, gateway_label: record.label, gateway_locality: record.locality}
        : presentations.find(item => item.gateway_id === id)
          || {gateway_id: id, gateway_label: "Unavailable Gateway", gateway_locality: "unknown"};
    };
    /** Return an independent ordered ID scope, including an empty draft when unset. */
    const gatewaySelection = () => copy(scope || empty());
    /** Expose primary presentation for existing single-Gateway callers. */
    const selection = () => scope?.primary_gateway_id ? {...display(scope.primary_gateway_id)} : null;
    /** Persist only ordered IDs and safe selected labels with a versioned envelope. */
    const draftSnapshot = () => ({schema_version: 2, gateway_selection: gatewaySelection(),
      gateways: (scope?.gateway_ids || []).map(id => ({...display(id)}))});
    /** Refresh saved labels before notifying the draft owner and accessible status region. */
    function changed(message = "", edited = true) {
      presentations = draftSnapshot().gateways;
      onChanged(edited);
      if (message) announce(message);
    }
    /** Validate every captured target without filtering offline or unavailable members. */
    function unavailable(snapshot = null) {
      const captured = snapshot ? (snapshot.gateway_selection || (snapshot.gateway_id
        ? {schema_version: 1, gateway_ids: [snapshot.gateway_id], primary_gateway_id: snapshot.gateway_id} : empty())) : gatewaySelection();
      if (!captured.gateway_ids?.length) return "Choose at least one execution Gateway.";
      if (!safeSelection(captured) || (snapshot?.gateway_id && snapshot.gateway_id !== captured.primary_gateway_id)) return "Invalid execution Gateway selection. Choose your Gateways again.";
      if (!loaded || failed) return "Execution targets could not be verified. Refresh targets before sending.";
      for (const id of captured.gateway_ids) {
        const record = find(id);
        if (!record) return `Target unavailable: ${display(id).gateway_label}. Choose an existing Gateway.`;
        if (record.status === "disabled") return `Target disabled: ${record.label}. Choose an enabled Gateway.`;
      }
      return "";
    }
    /** Replace future intent only with enabled known IDs and one selected primary. */
    function setGatewaySelection(value) {
      const next = safeSelection(value, true);
      if (isSteering() || !next || next.gateway_ids.some(id => !find(id) || find(id).status === "disabled")) return false;
      scope = next; changed(); return true;
    }
    /** Append one enabled Gateway, retaining order and the first selected primary. */
    function addGateway(id) {
      if (isSteering() || !find(id) || find(id).status === "disabled") return false;
      if (scope?.gateway_ids.includes(id)) { announce(`${find(id).label} is already selected.`); return true; }
      if (scope?.gateway_ids.length >= MAX) { announce("Select at most 16 Gateways."); return false; }
      scope = {schema_version: 1, gateway_ids: [...(scope?.gateway_ids || []), id], primary_gateway_id: scope?.primary_gateway_id || id};
      changed(`Added ${find(id).label}, ${localityName(find(id).locality).toLowerCase()}.${scope.gateway_ids.length === 1 ? " Primary Gateway." : ""}`);
      return true;
    }
    /** Remove intent and deterministically promote the first remaining primary. */
    function removeGateway(id) {
      if (isSteering() || !scope?.gateway_ids.includes(id)) return false;
      const name = display(id).gateway_label, primary = scope.primary_gateway_id === id;
      const ids = scope.gateway_ids.filter(value => value !== id);
      scope = {schema_version: 1, gateway_ids: ids, primary_gateway_id: primary ? ids[0] || "" : scope.primary_gateway_id};
      changed(`Removed ${name}.${primary && ids.length ? ` ${display(ids[0]).gateway_label} is now primary.` : ""}${!ids.length ? " Choose at least one execution Gateway." : ""}`);
      return true;
    }
    /** Change only the selected primary, preserving target order and membership. */
    function setPrimaryGateway(id) {
      if (isSteering() || !scope?.gateway_ids.includes(id) || !find(id) || find(id).status === "disabled") return false;
      scope = {...scope, primary_gateway_id: id}; changed(`${display(id).gateway_label} is now primary.`); return true;
    }
    /** Restoring saved intent preserves missing/disabled IDs; only user actions validate membership. */
    function restoreDraftState(value) {
      const saved = value == null ? null : safeDraft(value);
      scope = saved ? saved.gateway_selection : value == null ? null : empty();
      presentations = saved?.gateways || [];
      if (!scope && loaded) scope = find(defaultId)?.status !== "disabled" && find(defaultId)
        ? {schema_version: 1, gateway_ids: [defaultId], primary_gateway_id: defaultId} : empty();
      changed("", false);
    }
    /** Refresh labels and health in place; a changed default never replaces explicit intent. */
    function updateRecords(payload) {
      if (!Array.isArray(payload.gateways)) throw window.SMTOErrors.error("ui_response_invalid");
      const Core = window.SMTOAgentUi;
      records = payload.gateways.filter(raw => raw.presentation).map(raw => ({...raw.presentation,
        secure: Core?.gatewayConnectionSecured?.(raw) === true}))
        .filter(item => safeSnapshot({gateway_id: item.gateway_id, gateway_label: item.label, gateway_locality: item.locality}))
        .map(item => ({gateway_id: item.gateway_id, label: item.label, locality: item.locality,
          status: ["connected", "offline", "degraded", "disabled"].includes(item.status) ? item.status : "unknown",
          node: text(item.node, 160), platform_label: text(item.platform_label, 80), is_default: item.is_default === true, secure: item.secure}));
      loaded = true; failed = false; defaultId = payload.default_gateway_id;
      if (!scope) restoreDraftState(null);
      else changed("", false);
    }
    return {gatewayId: () => scope?.primary_gateway_id || "", gatewayIds: () => [...(scope?.gateway_ids || [])],
      gatewaySelection, selection, draftSnapshot, unavailable, setGatewaySelection, addGateway, removeGateway, setPrimaryGateway,
      setGateway: id => setGatewaySelection({schema_version: 1, gateway_ids: [id], primary_gateway_id: id}),
      submissionSnapshot() { const reason = unavailable(); if (reason) throw window.SMTOErrors.error("ui_composer_not_ready"); return {...selection(), gateway_selection: gatewaySelection()}; },
      restoreDraftState, updateRecords, recordsSnapshot: () => copy(records),
      markFailed() { failed = true; changed("", false); }, isLoaded: () => loaded, isFailed: () => failed,
      isInitialized: () => scope !== null};
  }
  /** Bind shared intent to the existing Target menu, chips and accepted-run badge. */
  function create({apiJson, root, summary, runBadge, currentRun, isSteering, onChanged = () => {}, notify = () => {}}) {
    let open = false, loading = null, reload = false, runTarget = null, runId = "", renderedOptions = "";
    const renderedGateways = new WeakMap();
    root.innerHTML = `<button id="target-button" type="button" class="target-button" aria-haspopup="listbox" aria-expanded="false" aria-controls="target-options"><span></span><span aria-hidden="true">▾</span></button>
      <div id="target-menu" class="target-menu" hidden><p id="target-heading">Execution target</p><div id="target-options" role="listbox" aria-multiselectable="true" aria-labelledby="target-heading"></div><div id="target-primary-actions" aria-label="Primary Gateway"></div><p class="target-help">Select up to 16 Gateways. Local means a loopback connection from the runtime.</p><button id="target-refresh" type="button">Refresh targets</button></div>
      <span class="sr-only" id="target-announcement" role="status" aria-live="polite"></span>`;
    const button = root.querySelector("#target-button"), menu = root.querySelector("#target-menu");
    const options = root.querySelector("#target-options"), primaryActions = root.querySelector("#target-primary-actions");
    const announcement = root.querySelector("#target-announcement");
    const model = createState({isSteering, announce: message => { announcement.textContent = message; },
      onChanged: edited => { render(); onChanged(edited); }});
    /** Show the gateways tied to a conversation's task, including completed tasks. */
    function renderGateways(container, snapshot) {
      const target = fromNative(snapshot), records = model.recordsSnapshot();
      const ids = target?.gateway_selection?.gateway_ids || (target ? [target.gateway_id] : []);
      const primary = target?.gateway_selection?.primary_gateway_id || target?.gateway_id;
      const gateways = ids.map(id => {
        const record = records.find(item => item.gateway_id === id);
        return {id, label: record?.label || (id === target.gateway_id ? target.gateway_label : id),
          primary: id === primary,
          status: !model.isLoaded() || model.isFailed() ? "unknown" : record?.status || "unavailable"};
      });
      const signature = JSON.stringify(gateways);
      if (signature === renderedGateways.get(container)) return;
      renderedGateways.set(container, signature);
      container.hidden = !gateways.length;
      container.replaceChildren();
      if (!gateways.length) return;
      const heading = document.createElement("span"); heading.className = "conversation-gateways-label";
      heading.textContent = gateways.length === 1 ? "Gateway" : "Gateways"; container.append(heading);
      for (const gateway of gateways) {
        const chip = document.createElement("span"); chip.className = "target-chip";
        chip.dataset.runGatewayId = gateway.id;
        const label = document.createElement("span"); label.textContent = gateway.label;
        const detail = [gateway.primary ? "Primary Gateway" : "Gateway", gateway.id].filter(Boolean).join(" · ");
        chip.title = detail;
        const status = document.createElement("span"); status.className = "target-chip-status";
        status.dataset.status = gateway.status; status.setAttribute("role", "img");
        status.title = ({connected: "Online", offline: "Offline", disabled: "Disabled", unavailable: "Unavailable",
          degraded: "Degraded connection", unknown: "Connection status unknown"})[gateway.status];
        status.setAttribute("aria-label", status.title);
        if (gateway.status === "connected") { status.textContent = "✓"; status.dataset.uiSymbol = "check"; }
        else if (["offline", "disabled", "unavailable"].includes(gateway.status)) { status.textContent = "×"; status.dataset.uiSymbol = "cross"; }
        else status.textContent = gateway.status === "degraded" ? "!" : "?";
        chip.append(label, status); container.append(chip);
      }
    }
    /** Position the existing menu within the viewport and move focus on explicit navigation. */
    function setOpen(value, focus = false) {
      open = Boolean(value && !isSteering()); menu.hidden = !open; button.setAttribute("aria-expanded", String(open));
      if (open) {
        const bounds = button.getBoundingClientRect();
        const above = bounds.top - 16, below = document.documentElement.clientHeight - bounds.bottom - 16;
        menu.dataset.placement = above >= below ? "above" : "below";
        menu.style.maxHeight = `${Math.max(0, above, below)}px`;
      }
      if (focus) (open ? options.querySelector('[aria-selected="true"]') || options.querySelector('[role="option"]') || root.querySelector("#target-refresh") : button).focus();
    }
    /** Refresh controls and chips without confusing future intent with captured run authority. */
    function render() {
      const active = window.SMTOPromptQueue?.isOperational(currentRun().status), locked = Boolean(isSteering());
      const target = locked ? (runId === currentRun().request_id ? runTarget : null) : model.selection();
      const ids = locked ? target?.gateway_selection?.gateway_ids || (target?.gateway_id ? [target.gateway_id] : []) : model.gatewayIds();
      const records = model.recordsSnapshot(), record = records.find(item => item.gateway_id === target?.gateway_id);
      const prefix = locked ? "Run target" : active ? "Next target" : "Target";
      let label = target ? `${localityName(target.gateway_locality)} · ${target.gateway_label}` : model.isLoaded() ? "No execution target" : "Loading…";
      if (locked) label = target?.gateway_label || "Unverified";
      else if (target && model.isLoaded() && !record) label = `Target unavailable · ${target.gateway_label}`;
      else if (model.isFailed()) label += " · Unverified";
      else if (record && record.status !== "connected") label += ` · ${record.status[0].toUpperCase()}${record.status.slice(1)}`;
      const caption = ids.length > 1 ? `${locked ? "Run targets" : "Multiple gateways"} · ${ids.length}` : `${prefix}: ${label}`;
      button.firstElementChild.textContent = caption;
      button.querySelector(".gateway-secure-lock")?.remove();
      const secure = ids.length === 1 && !model.isFailed() && record?.secure;
      if (secure) button.insertBefore(window.SMTOAgentUi.gatewayLockIcon(), button.lastElementChild);
      button.setAttribute("aria-label", `${caption}${record && ids.length === 1 ? ` · ${record.status}` : ""}${secure ? " · Secure connection" : ""}${locked ? " · Locked while steering" : ""}`);
      button.title = locked ? "Steering preserves the run's execution Gateways." : model.unavailable() || caption;
      button.disabled = locked; root.dataset.unavailable = String(!locked && Boolean(model.unavailable()));
      if (locked) setOpen(false);
      const executionTarget = active && runId === currentRun().request_id ? runTarget : null;
      const runCount = executionTarget?.gateway_selection?.gateway_ids.length || 1;
      runBadge.hidden = !executionTarget;
      runBadge.textContent = executionTarget ? runCount > 1 ? `Multiple gateways · ${runCount}` : `Via ${executionTarget.gateway_label}` : "";
      if (executionTarget && runCount === 1 && !model.isFailed() && records.find(item => item.gateway_id === executionTarget.gateway_id)?.secure) runBadge.append(window.SMTOAgentUi.gatewayLockIcon());
      runBadge.title = executionTarget ? "Captured run scope; future selections do not change it." : "";
      const signature = JSON.stringify([records, model.draftSnapshot(), locked, model.isLoaded(), model.isFailed()]);
      if (signature === renderedOptions) return;
      renderedOptions = signature;
      const focused = root.contains(document.activeElement) || summary.contains(document.activeElement) ? document.activeElement.dataset.focusKey : null;
      options.replaceChildren(); primaryActions.replaceChildren(); summary.replaceChildren();
      const selected = model.gatewayIds(), primary = model.gatewayId();
      const savedGateways = model.draftSnapshot().gateways;
      // Saved targets that disappeared must still be removable through Controls.
      const choices = [...records, ...savedGateways.filter(item => !records.some(record => record.gateway_id === item.gateway_id))
        .map(item => ({gateway_id: item.gateway_id, label: item.gateway_label, locality: item.gateway_locality, status: "unavailable"}))];
      for (const item of choices) {
        const option = document.createElement("button"); option.type = "button";
        const checked = selected.includes(item.gateway_id);
        option.setAttribute("role", "option"); option.setAttribute("aria-selected", String(checked));
        option.setAttribute("aria-disabled", String(item.status === "disabled" && !checked));
        option.dataset.gatewayId = item.gateway_id; option.dataset.focusKey = `option:${item.gateway_id}`; option.tabIndex = -1;
        const title = document.createElement("span"), detail = document.createElement("small"); title.className = "target-option-label";
        const name = document.createElement("span");
        const mark = document.createElement("span"); mark.textContent = checked ? "☑" : "☐";
        if (checked) mark.dataset.uiSymbol = "check";
        name.append(mark, document.createTextNode(` ${localityName(item.locality)} · ${item.label}${primary === item.gateway_id ? " · Primary" : ""}`));
        title.append(name);
        if (item.secure && !model.isFailed()) title.append(window.SMTOAgentUi.gatewayLockIcon());
        detail.textContent = [item.status[0].toUpperCase() + item.status.slice(1), item.platform_label, item.is_default ? "Default" : ""].filter(Boolean).join(" · ");
        option.append(title, detail);
        option.onclick = () => { if (checked) model.removeGateway(item.gateway_id); else if (item.status !== "disabled") model.addGateway(item.gateway_id); };
        options.append(option);
      }
      if (!choices.length) { const p = document.createElement("p"); p.textContent = "No execution target configured."; options.append(p); }
      for (const item of savedGateways) {
        const record = records.find(value => value.gateway_id === item.gateway_id), isPrimary = item.gateway_id === primary;
        const status = !model.isLoaded() || model.isFailed() ? "unknown" : record?.status || "unavailable";
        const chip = document.createElement("span"); chip.className = "target-chip";
        const label = document.createElement("span");
        label.textContent = `${item.gateway_label}${isPrimary ? " ★" : ""}${status === "connected" ? "" : ` · ${status === "unavailable" ? "Unavailable" : status}`}`;
        label.title = isPrimary ? "Primary Gateway" : "Selected Gateway";
        const indicator = document.createElement("span"); indicator.className = "target-chip-status";
        indicator.dataset.status = status;
        indicator.setAttribute("role", "img");
        indicator.title = ({connected: "Online", offline: "Offline", disabled: "Disabled", unavailable: "Unavailable",
          degraded: "Degraded connection", unknown: "Connection status unknown"})[status];
        indicator.setAttribute("aria-label", indicator.title);
        if (status === "connected") { indicator.textContent = "✓"; indicator.dataset.uiSymbol = "check"; }
        else if (["offline", "disabled", "unavailable"].includes(status)) { indicator.textContent = "×"; indicator.dataset.uiSymbol = "cross"; }
        else indicator.textContent = status === "degraded" ? "!" : "?";
        chip.append(label, indicator); summary.append(chip);
        if (!isPrimary && !locked) {
          const make = document.createElement("button"); make.type = "button"; make.textContent = `Make primary: ${item.gateway_label}`;
          make.dataset.focusKey = `primary:${item.gateway_id}`; make.disabled = !record || record.status === "disabled";
          make.onclick = () => { model.setPrimaryGateway(item.gateway_id); options.querySelector('[aria-selected="true"]')?.focus(); };
          primaryActions.append(make);
        }
      }
      summary.hidden = locked || !selected.length;
      if (focused) ([...root.querySelectorAll('[data-focus-key]'), ...summary.querySelectorAll('[data-focus-key]')].find(item => item.dataset.focusKey === focused) || button).focus();
    }
    /** Coalesce registry refreshes and mark verification failures without dropping intent. */
    function load() {
      reload = true;
      if (!loading) loading = (async () => {
        do {
          reload = false;
          try { model.updateRecords(await apiJson("/api/agent/gateways")); }
          catch (_) { model.markFailed(); }
        } while (reload);
      })().finally(() => { loading = null; });
      return loading;
    }
    button.addEventListener("click", () => setOpen(!open, true));
    button.addEventListener("keydown", event => { if (["ArrowDown", "ArrowUp"].includes(event.key)) { event.preventDefault(); setOpen(true, true); } });
    menu.addEventListener("keydown", event => {
      if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); setOpen(false, true); }
      if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
        const choices = [...options.querySelectorAll('[role="option"]')]; if (!choices.length) return;
        event.preventDefault(); const index = choices.indexOf(document.activeElement);
        choices[event.key === "Home" ? 0 : event.key === "End" ? choices.length - 1 : (index + (event.key === "ArrowUp" ? -1 : 1) + choices.length) % choices.length].focus();
      }
    });
    root.addEventListener("focusout", event => { if (event.relatedTarget && !root.contains(event.relatedTarget)) setOpen(false); });
    document.addEventListener("click", event => { if (!event.composedPath().includes(root)) setOpen(false); });
    root.querySelector("#target-refresh").onclick = () => void load();
    window.SMTOUiUpdates.subscribe(["gateways.changed", "gateway.health.changed"], load);
    // Do not call app callbacks during construction, before its policy owners exist.
    // Ambiguous old tab choices never become an existing conversation's intent.
    try { sessionStorage.removeItem(KEY); } catch (_) {}
    queueMicrotask(render);
    return {...model, load, render, renderGateways, setRunTarget(snapshot, id) { runTarget = copy(snapshot); runId = id; render(); }};
  }
  window.SMTOTargetSelector = {create, createState, safeSnapshot, safeSelection, safeDraft, fromNative};
})();
