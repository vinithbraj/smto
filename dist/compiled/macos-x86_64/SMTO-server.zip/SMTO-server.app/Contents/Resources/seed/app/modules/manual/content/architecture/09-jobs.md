---
id: jobs-waits
title: Jobs, waits and resume
kind: architecture
tags: [architecture, tools]
order: 9
---
# Jobs, waits and resume

A **job** is an action that takes time, such as a long command running in the
background. SMTO keeps a record of the job so the assistant can follow it later.
You do not need to keep the browser open, but the computer running the work and
SMTO's main service must stay available for progress to continue.

A task can also **wait** for your answer, a tool result, a set time, or another
event. SMTO saves what it is waiting for and continues the task when that condition
is met. While waiting, it does not repeatedly ask the AI to make another decision.

Starting a job is not the same as finishing it. Check the completed result before
relying on the answer. After an interruption, SMTO checks the saved job and the
running program to find out whether work is still running, finished, or lost.
If an action may have changed something but no result was received, it needs to
be checked before being repeated. A cancellation stays tied to the job and task
that were allowed to run.

### Tool names for developers

These are the technical controls used by the assistant and integrations. You do
not need to type them to follow a task in the activity history.

- `background=true` starts a long command as a background job. Keep its job ID,
  which identifies that particular action.
- `inspect_execution` reads saved progress and status without contacting the computer
  doing the work.
- `manage_job` can check the computer for a fresh status, read a limited amount of
  output, cancel a job, check an unclear result, or wait for it.
- `wait_for_event` saves a wait for a time, monitor, schedule, or trusted service event.

The implementation is in `native/jobs.py` and `native/continuation.py`. Saved results
show what actually happened; a message saying a job started is not final output.

## Detached managed jobs

Any command can use `shell.command(background=true, detached=true)` to run independently
of task completion. An existing managed job can use `manage_job(action="detach", job_id=...)`.
This is explicit: ordinary background jobs still block completion, and requests to wait
for results or monitor work retain the existing wait and monitor behavior.

Detachment keeps the captured Gateway owner, job ID, logs, resource claims and
`job_lifetime_seconds` limit (zero means no lifetime cap). Normal task cleanup leaves
detached processes running. They stop on their own exit, their lifetime deadline, or
explicit cancellation. An explicit task Stop continues to cancel its owned jobs,
including detached jobs. Detachment does not release resources or satisfy dependencies
that require the command's result.

The agent can inspect or read logs, proceed with independent work, or finish. A confirmed
running process supplies a separate launch reference proving only process start, never
successful command completion. Queued or unknown execution supplies no such proof.
`manage_job(action="wait")` also works on detached jobs when waiting is requested later.
Detachment is durable across recovery; later observations cannot silently restore task
ownership. Inspect, logs, wait and cancel continue to use the original scoped job handle.

## Controller operation settlement

`current_run/operation_settlement.py` owns the shared deterministic release decision
for synchronous operations, managed jobs and composite transfers. `execution/lifecycle.py`
owns the producer contracts. The RAM and SQLite compatibility stores publish exact
receipt/job evidence through this decision, in the same transaction as queue, lock,
settlement event and affected activity updates. Existing lock hooks mirror queue
transitions. Notifications occur after commit. A publication failure rolls everything
back; duplicate evidence cannot reopen a released operation or replace an immutable
receipt with conflicting evidence.

The live controller uses indexed RAM records and the existing hub commit. It does
not connect to SQLite, scan disk, wait for a checkpoint, or scan retained ownership
on every admission. Exact artifacts are inspected through immutable mappings;
activity updates share unrelated output and history. Bootstrap checks retained
ownership once before readiness. Owner reconciliation can also check a specific
operation before making an authenticated Gateway inspection. SQLite remains an
existing compatibility backend using the same release rules, not the RAM path.

The owned job record supersedes an earlier launch acknowledgement. Cross-run
artifacts, inherited artifact links, model result projections, timestamps and local
worker/PID exit cannot establish release. Derived receipts must explicitly
supersede the original operation. Foreground inspection is bound by the existing
owner to the retained target. Historical outcome uncertainty survives physical
release, and late evidence preserves Stop and run ownership rather than resuming
a cancelled task.

Namespace V2 changes which resources are owned, not what proves physical end.
An uncertain job retains its captured target/shared domains while unrelated pinned
Gateways can proceed. Historical V1 global reservations remain global until exact
evidence or an authorized, revision-fenced reconciliation resolves them. Stopping
the Controller or changing a display name never releases or relabels those claims.
Retained input continuations require positive no-start evidence before reopening;
the current run-owner lease consumes a single continuation generation while preserving
the accepted profile. OAuth's `_auth` receipt is bound to that generation explicitly.
completed physical work stays fenced. The old no-start receipt cannot settle a
later continuation. Its new completion must arrive through correlated source evidence.

Execution paths supply release proof at their own source boundary:

| Path | Release evidence | Evidence that retains ownership |
| --- | --- | --- |
| Synchronous tools, including filesystem and inspection tools | The adapter's declared synchronous return | An exception with possible execution or contradictory live-process facts |
| Shell/Python managed execution and background promotion | The same operation's accepted job or foreground completion receipt | Launch acknowledgement, live child, stale observation, or unknown process state |
| Independent completion, health and cancellation observers | Correlated physical-end evidence settles job and closed sequence-parent claims in the observation transaction | Missing supervisor, cancellation request, or unknown liveness; no run owner is required to publish valid release proof |
| Ordered `shell.sequence` | Dispatcher closure plus exact same-run receipts/jobs for every claimed child | Any missing, running, unbound or uncertain child; a still-open dispatcher |
| Activity/engine/child preflight rejection | Source-owned proof that dispatch never started | A replay or error returned after dispatch may have begun |
| Parallel batches and dependency graphs | Each admitted child's own evidence | Parent batch labels do not release child claims |
| Local controls | The owning synchronous control return, when no external executor exists | A business operation without execution evidence |
| Gateway transfer | Explicit transfer completion and reconciliation evidence | Lost commit acknowledgement or another unresolved transfer phase |
| Stop, failure and restart | Confirmed execution inactivity, even if historical effects remain uncertain | Task cancellation, worker exit or elapsed time alone |

Shell sequence closure is committed with the invocation result and parent lock transition.
The server verifies child operation identities, indexes and accepted commands; it does not
use bounded child previews or a `success` label as execution proof. A failed or interrupted
sequence can release once all attempted commands have ended. A child missing from a short
error aggregate still counts if its invocation was claimed. Later child receipts and job
observations settle a closed parent and wake waiting work in the same publication path.
Approved retries validate reused prefix receipts without repeating commands. Bootstrap can
repair older completed sequences from their retained invocation and child evidence.

The sequence-parent and preflight reservation fixes are server-side. Gateways still own
physical command execution and its receipts. An opaque operation may legitimately reserve
the shared `external:*` resource across Gateways; fixing release does not weaken that fence.

Gateway selection is separate from physical resource identity. Merely selecting two
Gateways in one conversation does not combine their resource scopes. Each ordinary
operation uses its captured target; a transfer claims both endpoints. The Controller's
`physical-targets.json` bootstrap enrollment binds verified physical machines and shared
storage to pinned Gateway identities. Without that mapping, even a proven host-local
operation is widened to `external:*`, which overlaps every target. With distinct enrolled
machines and complete storage evidence, proven host-local operations can overlap across
machines. Opaque executable effects remain global even with enrolled targets. A Gateway
restart cannot change this Controller namespace policy.

A server restart invalidates its local progression and observation owners, then rebuilds
resource ownership from retained execution evidence. It does not kill detached Gateway
processes. Proven inactive jobs release during recovery or later observation; unknown
jobs retain their reservations. In particular, `supervisor_missing`, `executed=false`
and `resource_claim_state=none` do not establish inactivity when the Gateway still
reports `liveness_state=unknown`. Restarting either service cannot manufacture a
missing physical completion receipt. Completion observations settle physical claims
without waiting for the old conversation to resume; semantic result delivery still
uses the fenced completion mailbox.

A terminal outcome label does not retire observation while physical ownership remains
unresolved. Recovery re-enables older prematurely retired observers. Cancellation and
unknown jobs receive process inspection at bounded intervals even when optional health
supervision is disabled; cached status alone cannot establish process death. Background
recovery never changes an already released reservation back to active, including an
explicit operator reset. Duplicate terminal publication preserves the accepted outcome
and any newer physical release evidence on both storage backends.

The Gateway can establish that a detached worker never dispatched when its scoped IPC
ticket identifies a dead worker, the durable dispatch fence is absent, and the job has
no command identity or start evidence. The parent reaper also covers worker failure before
PID binding. This closes the failed launch without replay. A legacy worker without a
ticket, a live worker, a dispatch fence, or contradictory execution evidence remains
unresolved. This launch recovery change requires the updated Gateway process as well as
updated Controller observation code.

For a pre-lifecycle `gateway.copy` receipt, automatic compatibility repair requires
an exact successful receipt plus its same-operation checkpoint: matching transfer
identity, both Gateway/path pairs, verified phase, byte counts, SHA-256 verification
and completed cleanup. A lost commit acknowledgement retains the claim until
provider reconciliation proves its outcome. Successful destination publication
can release while cleanup of isolated handles/staging remains pending; cleanup
cannot subsequently publish the destination. Recovery never retransfers bytes.

Scheduling-profile observations expose a read-only `settlement` diagnostic,
including `release_pending` when release proof exists but publication was lost.
Status GETs never repair ownership. Lifecycle projection deduplicates foreground,
batch history, dependency and background activities by execution identity, then
uses current job/queue ownership. A lock wait remains distinct from capacity
waiting and cannot be reported as all required work settled.

`tests/test_operation_settlement.py` exercises backend parity, rollback, unknown
commit retention, supersession, stale observations, stopped runs, read-only
diagnostics, no-SQL RAM admission and checkpoint recovery. Run
`python -m tests.benchmark_operation_settlement` to measure RAM admission and
receipt/settlement publication with retained history; it reports latency without
using machine-load-sensitive correctness assertions. Settlement and projection
make zero helper model calls.

`tests/test_sequence_settlement.py` adds closed-parent, late-child, malformed evidence,
approved-prefix and checkpoint recovery cases. `tests/test_resource_lock_execution_paths.py`
exercises complete dispatch and following-command admission on both backends, all three
result delivery modes, preflight rejection, dispatcher exceptions and real subprocesses.

Gateway history intentionally coordinates physical resources across conversations. Effect
classification and resource descriptors carry revisions and upgrade lazily without deleting
jobs. Admission repairs stale classifications, recovers authoritative receipts, observes
supported literal filesystem effects once per material revision, and checks structured
resource overlap before rejecting new work. Opaque commands retain conservative ownership.

Abandoned claims are repaired automatically before admission or during correlated
recovery inspection. If a job still owns the resource, the conversation offers
waiting or forceful termination. The Gateway binds recovery to the rejected
source operation and current blocker revision and keeps original receipts intact.
Older saved baseline decisions remain readable for compatibility.

The runtime saves the exact never-executed candidate and continues it under one linked
successor identity before another model decision. Existing permissions and Stop remain
authoritative. A claimed successor with a missing receipt is inspected, never blindly replayed.
Restart reconstructs the pending decision or accepted continuation from the same run store.

## Foreground supervision and resource waits

The Gateway server PID identifies the controller hosting a foreground stream. It is
not the lifetime of that command. Protocol 3 records `supervision_kind`,
`supervision_state`, and the scope's start/end reason separately. Every completion
receipt closes foreground supervision, including `outcome_unknown`. Stream loss
closes supervision while retaining the actual command PID, creation time, group
and session. A living child or descendant still holds ownership; a dead foreground
tree releases physical ownership even while the Gateway server stays alive.
Unobservable identity remains a reconciliation prerequisite. A known completion
receipt is distinct from a successful outcome.

Older JSON job rows upgrade lazily during inspection/admission. A foreground row
with a finish timestamp is interpreted as ended supervision. If its process tree
is dead and both execution and possible effects are false, its stale claim releases
and the original waiting candidate proceeds automatically. Unknown effects remain
unknown in the audit when an abandoned claim is repaired. No job history is deleted.
`lost` is an execution-control outcome, not proof of process-tree death; a surviving
or unobservable tree still protects its resource.

Short resource waits emit an activity explaining that the command has not started.
Admission saves correlated, allowlisted blocker facts and a progress timestamp.
After 15 seconds without a material blocker change, a never-executed candidate
enters the existing native resource decision. Unobservable ownership escalates after
bounded reconciliation immediately. This interval requests attention; it never
proves process death or expires an active claim.

Recovery appears inline in the conversation using the same disclosure and controls
as Agent checks. It offers only **Wait until the job state changes** and
**Resolve forcefully by terminating job**. Waiting persists across restarts until
the claim resolves or the task is stopped/paused; it does not expire after 15 seconds
and does not poll the model.

The Gateway automatically repairs abandoned claims with no recorded child identity
or a verified dead process. Active supervision, unexpired launch leases, live
process trees and inaccessible recorded identities prevent automatic repair. A
small conversation notice records the repair. The old command outcome remains
unknown; clearing ownership never fabricates success or replays the old command.

Forceful resolution records durable intent, kills the recorded process tree after
checking its identity, verifies termination, and restores the saved claims. With
no recorded child, an abandoned claim can be restored directly. Unknown effects
and unverified termination remain in the audit. New process identities invalidate
old resets; all decisions are correlated with the blocked operation and current
claim revision. Repeated delivery and restart cannot duplicate a reset.

Reset remains available after Stop, which preserves the task's cancelled state.
Active tasks continue the exact saved, never-executed invocation once through
ordinary capability and permission checks. An unreceipted successor is inspected
rather than relaunched. Browser presence has no execution authority.

## Observation without execution

`current_run/execution_observation.py` is the shared controller-local read owner for the
Agent's `inspect_execution` control and `GET /api/agent/executions/{identity}/observation`.
It resolves retained request, run, task, Activity, operation and job identities. A
conversation-only lookup requires an unambiguous current execution. Combined identities
must correlate; tombstoned and foreign-conversation state is not observable. Arbitrary
PID, path, hostname and command inputs are not execution observation identities.

The service reads selected native/job fields and `Scheduler.observe` diagnostics in
query-only transactions. It never reaps, reconciles, repairs a claim, touches a target,
creates an admission row or calls a model. The model control goes directly to this same
service before target preflight and admission. Inspecting a held operation therefore
does not queue behind that operation's resource slot. UI inspection can follow an owned
blocking operation to its retained job facts without running a new Shell check.

Admission, process liveness, progress and outcome are separate facts. Pending admission
means “Not started”; an acquired slot alone does not prove a process is alive. Only a
recent correlated lifecycle-owner observation establishes liveness. Progress requires
retained changes to output or capability metrics, with timestamps preserved by the job
writer. A heartbeat is neither liveness nor progress. Missing channels produce “Progress
unknown.” With Activity supervision, “Possibly stalled” requires a reliable progress
channel, a known live process, at least three observations and the accepted inactivity
threshold (90 seconds by default); it never fails or cancels the job. Receipt-defined
terminal outcome overrides stale admission evidence.

Run terminal/checkpoint controls take precedence in the conversation. Below those,
explicit dependency, effect and capacity waits take precedence over model narration.
“Let me check” is an intention, never proof that a check started. Connection freshness
is displayed separately and elapsed time comes from server timestamps. Existing recovery
interactions and unknown-effect protections retain their execution authority.

## Activity supervision

Managed inspectable jobs share one application-owned observation worker and a pool of
four observers. Foreground Shell/Python operations with negotiated job support use the
same operation identity; promotion does not start another watcher. Explicit external
waits are excluded. Persistent services and opaque processes remain observable but
silence alone never makes them stalled.

Completion detection and health supervision have separate clocks. Auto-managed Shell
commands first remain attached to their original tool call. The runtime reads compact
Gateway `status` every 250 ms, including a final fresh read at the promotion deadline.
Short commands settle in that same Agent turn without promotion or supervision trace
rows. Promotion transfers observation of the same job, PID, receipt lineage and claims;
it never launches a replacement process. Python currently uses synchronous foreground
execution and retains its direct receipt as completion authority.

After explicit background launch or promotion, the shared worker reads completion
status every 500 ms for ten seconds, every second through sixty seconds, then every
two seconds. Launch and cancellation confirmation use 250 ms. Status reads persisted
lifecycle facts without process telemetry, log fetching, or PID-based outcome inference.
Identical active status does not rewrite the native job. Completion probes produce no
trace history or model calls. They remain active when health supervision is disabled.

The accepted `activity_supervision_policy` defaults to enabled. Background health is
first inspected after 15 seconds, then every 25 seconds while healthy (30 seconds after
30 minutes). Unconfirmed starting states get a one-second health recheck independently
of their faster completion clock. Quiet jobs are checked every 10 seconds. At least
three observations and 90 seconds without reliable progress are needed for “Possibly
stalled”; attention starts at 180 seconds. The health inspection interval controls deeper
supervision of already-running long work. It does not slow completion detection for
normal commands. Timeout, cancellation and resource-claim owners retain their authority.

Output-byte growth, explicit completed-item/step/transfer counters and identity-checked
CPU or I/O growth can establish progress. Heartbeats, RSS, child count and changing
status text cannot. Missing counters remain unknown. Gateway inspection samples outside
its SQLite writer transaction and compares process identity again before publishing.
A PID reuse or inaccessible sample cannot establish progress or process death.

Observation failures use a separate ten-second retry cadence and become attention-worthy
after 90 seconds. They do not fail the job or release claims. Stop, newer progress and
terminal truth suppress stale attention. Supervision never automatically kills work.
Disabling supervision prevents health attention; ordinary completion probing remains active.
The 30-second fallback only repairs legacy jobs missing a current observation record.

The indexed `native_activity_watchdogs` table retains one bounded latest record per
Activity, with runtime-owned `launch_pending`, `attached_completion`, `background_health`,
`cancel_confirmation` and `terminal` phases. Independent completion and health deadlines
feed an indexed `next_due_at`. Claims make fresh manual and scheduled observations
single-flight. Attached completion has reserved observation capacity. Restart repairs
missing records, moves dead attached owners to background observation without relaunch,
retains pending attention and spreads overdue checks across 250 ms. The worker holds neither an Agent-turn slot nor parent progression
ownership during Gateway I/O. `inspect_execution` and UI reads remain query-only.
