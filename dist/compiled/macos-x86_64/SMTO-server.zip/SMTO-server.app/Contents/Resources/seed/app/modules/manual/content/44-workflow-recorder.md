---
id: workflow-recorder
title: Workflow recorder and Agent Recipes
kind: manual
tags: [workflows, recipes, schedules, automation]
order: 44
---
# Workflow recorder and Agent Recipes

After a successful task, **Save to workflow** below the response offers supported, verified steps for
review. Open **More options → Workflows** to find saved workflows. Existing saved
intents remain available and continue to use fresh Agent reasoning.

The action also appears on restored completed chats. If a chat has no reusable
steps, opening it explains why; text-only responses may not produce a workflow.
The Workflows and Offer after success settings control whether the action appears.

Review the name, description, ordered tools, arguments, parameter suggestions,
account references, Gateway policy, and effects before saving. Suggestions do not
change anything until selected. Repeated values can share one parameter. The
advanced JSON fields let you edit parameter names, types, defaults, required flags,
reference-only account slots, and exact arguments. Strings are data; there is no
Python, JavaScript, or `${...}` expression evaluation.

**Fixed Gateway** retains an exact Gateway identity. **Choose Gateway at each run**
uses the selected Gateway for the invocation. The application never substitutes a
different Gateway when a fixed target is missing. Account slots use symbolic
references such as `@work_google`; configure credentials in the existing account
or Parameter Store UI, never in workflow arguments or defaults.

Steps keep their dependencies. You cannot move a step before its producer or remove
a required producer. The server recomputes capabilities, effects, hashes and revision
numbers. An execution-affecting edit creates a new revision; a running task continues
with the revision it accepted. Archive hides the workflow and preserves history.

## Running and scheduling

**Run now** validates parameter values and current capability, tool-contract and
account availability, then starts a normal Agent request. The main Agent performs
fresh tool calls. Structured outputs from this invocation supply subsequent inputs.
A browser/UI session or element reference from the original run is never reusable.
Ambiguous structured selectors stop instead of choosing the first match. Live
provider and Gateway authorization still apply at each normal tool execution.

**Schedule** opens the existing schedule editor. Once, interval and calendar
schedules use the normal Scheduler Manager and durable task lifecycle. Schedules
pin the reviewed revision and parameters. Editing the workflow causes an old
schedule to report a revision mismatch; review and recreate that schedule. A
schedule grants no extra approval. Mandatory human checkpoints cannot run unattended.

History shows the pinned revision and per-step status. The default failure policy
is stop on failure. A failed or interrupted external write may have taken effect:
subsequent mutations and new occurrences of that workflow are blocked while that
uncertainty remains. Resume the original task and inspect its current state. If an
adapter provides verified reconciliation evidence, the task can continue using the
fresh result. Otherwise use Ask User or end the run with an actionable failure.
A read alone, a timeout, or a human assertion does not automatically authorize a
second write. There is no generic rollback.

## Availability and privacy

Capture is deterministic and makes **zero helper model calls**. It uses the bounded
receipt store, not conversation summaries. Only accepted evidence and its proven
dependencies become steps. Failed exploratory reads are excluded. Unsupported
background jobs, missing/ambiguous dependencies, unaccounted writes, and uncertain
effects make capture unavailable; the application does not save a prompt and call
it a recorded workflow.

Credential-bearing capture is refused. Symbolic account references are supported;
plaintext passwords, tokens, private headers and known sensitive parameter values
are not stored in recorded workflows. Runtime display-redaction settings do not
weaken this retention rule. Tool output bodies are not copied into recipes.

**Record workflow** reports unavailable on Linux, Windows and macOS. The current
Desktop, UI, Browser and Clipboard adapters execute semantic actions but do not
expose a scoped user-action subscription. There is no keyboard listener, clipboard
monitor, pointer recorder, screenshot stream or background demonstration recorder.
Run capture is the supported recording mode.

Direct execution without the main Agent, arbitrary cleanup/compensation, workflow
import/export, and automatic capture of background/parallel jobs are not provided.
Workflows with unsupported output schemas need a better tool contract or a new,
reviewed run. A literal credential cannot be turned into a safe account reference
by guessing its provenance.
