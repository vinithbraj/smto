/* Mobile command presentation. Shares only the small, DOM-free command contract. */
import "../../command_protocol.js";
import { $, api, state, node, button, notice, saveDraft } from "../api.js";
import { openSheet } from "../overlays.js";

export function create(hooks) {
  const protocol = window.SMTOCommandProtocol, input = $("#message");
  const panel = node("div", null, "mobile-command-palette");
  panel.id = "mobile-command-palette"; panel.hidden = true;
  panel.setAttribute("role", "listbox"); panel.setAttribute("aria-label", "Application commands");
  $("#compose").prepend(panel);
  let commands = [], matches = [], selected = 0, dismissed = false, busy = false;
  let statusBody, statusData, timer, pending, refreshing = false, dirty = false, statusGeneration;
  const view = () => ({conversation_id: state.conversationId, request_id: state.requestId,
    run_id: state.run?.run_id, status: state.run?.status, snapshot: state.run || {},
    queued_count: state.lane?.queued_tasks?.length, navigation: state.generation});
  const context = () => protocol.context(view(), "mobile");
  const ready = api("commands").then(payload => { commands = payload.commands || []; update(); })
    .catch(() => notice("Command list unavailable. Try again."));
  function close() {
    panel.hidden = true; input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant");
  }
  function complete(command = matches[selected]) {
    if (!command || protocol.availability(command, view())) return false;
    input.value = command.command; saveDraft(input.value); hooks.renderComposer(); update(); return true;
  }
  function update() {
    if (!input.value.trimStart().startsWith("/") || dismissed || busy) { close(); return; }
    const prefix = input.value.trimStart().slice(1).split(/\s/)[0].toLowerCase();
    matches = commands.filter(c => [c.name, ...(c.aliases || [])].some(n => n.startsWith(prefix)));
    selected = Math.min(selected, Math.max(0, matches.length - 1)); panel.replaceChildren();
    for (const [index, command] of matches.entries()) {
      const reason = protocol.availability(command, view());
      const option = button(command.command, async () => {
        if (reason) { notice(reason); return; }
        selected = index; complete(command); await execute(command.command);
      }, "mobile-command-option");
      option.id = `mobile-command-${index}`;
      option.dataset.command = command.name;
      option.setAttribute("role", "option"); option.setAttribute("aria-selected", String(index === selected));
      option.setAttribute("aria-disabled", String(Boolean(reason)));
      option.append(node("small", command.description));
      if (reason) option.append(node("small", reason, "muted"));
      panel.append(option);
    }
    if (!matches.length) panel.append(node("p", "No matching commands"));
    panel.hidden = false; input.setAttribute("aria-controls", panel.id); input.setAttribute("aria-autocomplete", "list");
    input.setAttribute("aria-expanded", "true");
    if (matches.length) input.setAttribute("aria-activedescendant", `mobile-command-${selected}`);
  }
  function keydown(event) {
    if (event.isComposing || event.shiftKey || event.altKey || panel.hidden) return false;
    if (!["ArrowUp", "ArrowDown", "Tab", "Enter", "Escape"].includes(event.key)) return false;
    event.preventDefault();
    if (event.key === "Escape") { dismissed = true; close(); }
    else if (event.key === "Tab") complete();
    else if (event.key === "Enter") {
      if (matches[selected] && !/\s/.test(input.value.trim()) && !complete()) {
        notice(protocol.availability(matches[selected], view())); return true;
      }
      void execute(input.value);
    } else if (matches.length) {
      selected = (selected + (event.key === "ArrowDown" ? 1 : -1) + matches.length) % matches.length;
      update(); panel.querySelector('[aria-selected="true"]')?.scrollIntoView({block: "nearest"});
    }
    return true;
  }
  function disposeStatus() {
    clearInterval(timer); clearTimeout(pending); statusBody = null; statusData = null; dirty = false;
  }
  function renderStatus() {
    if (!statusBody?.isConnected) return;
    const text = protocol.statusText(statusData);
    window.SMTONumberOdometer.render(statusBody.querySelector("strong"), text.summary);
    const details = statusBody.querySelector("dl");
    const rows = [[text.timingLabel, text.elapsed], ["Phase", text.phase],
      ["Context remaining", text.remaining], ["Context used", text.used],
      ["Measurement", text.measurement], ...text.tokenRows, ...text.memoryRows,
      ["Queued prompts", statusData.queue?.queued_count ?? 0]];
    rows.forEach(([key, value], index) => {
      let term = details.children[index * 2], description = details.children[index * 2 + 1];
      if (!term) { term = node("dt"); description = node("dd"); details.append(term, description); }
      const sameLabel = term.textContent === key;
      if (!sameLabel) term.textContent = key;
      window.SMTONumberOdometer.render(description, value, {live: sameLabel});
    });
    while (details.children.length > rows.length * 2) details.lastElementChild.remove();
  }
  function showStatus(data) {
    statusData = data;
    if (!statusBody?.isConnected) {
      disposeStatus(); statusData = data; statusGeneration = state.generation;
      statusBody = openSheet("Runtime status", {onClose: disposeStatus});
      statusBody.id = "mobile-runtime-status";
      const summary = node("strong"), details = node("dl");
      const collapse = button("Collapse", () => {
        details.hidden = !details.hidden; collapse.textContent = details.hidden ? "Expand" : "Collapse";
        collapse.setAttribute("aria-expanded", String(!details.hidden));
        collapse.setAttribute("aria-label", `${details.hidden ? "Expand" : "Collapse"} runtime status`);
      });
      collapse.setAttribute("aria-label", "Collapse runtime status"); collapse.setAttribute("aria-expanded", "true");
      statusBody.append(summary, collapse, details);
      timer = setInterval(() => { if (statusData?.timing?.ticking) renderStatus(); }, 1000);
    }
    renderStatus();
  }
  async function refreshStatus() {
    if (!statusBody?.isConnected || statusGeneration !== state.generation) return;
    if (refreshing) { dirty = true; return; }
    refreshing = true; const generation = state.generation;
    try {
      const result = await api("commands/execute", {method: "POST", body: {command: "/status", context: context()}});
      if (generation !== state.generation || !statusBody?.isConnected) return;
      if (result.status === "error") throw window.SMTOErrors.fromPayload(result);
      statusData = result.client_action.status; renderStatus();
    } catch { if (statusBody?.isConnected) notice("Status unavailable. Try /status again."); }
    finally { refreshing = false; if (dirty) { dirty = false; changed(); } }
  }
  function changed() {
    update();
    if (statusBody?.isConnected) { clearTimeout(pending); pending = setTimeout(refreshStatus, 150); }
  }
  hooks.commandStateChanged = changed;
  hooks.commandNavigation = () => { close(); disposeStatus(); };
  const target = action => ({command_context: protocol.context(action, "mobile")});
  const actions = {
    show_runtime_status: action => showStatus(action.status),
    new_conversation: () => hooks.newChat(),
    stop_current_run: action => hooks.control("cancel", target(action), action.request_id),
    pause_current_run: action => hooks.control("pause", target(action), action.request_id),
    resume_current_run: action => hooks.control("resume", target(action), action.request_id),
    compact_current_run: action => hooks.control("compact", target(action), action.request_id),
    open_history: () => hooks.openHistory(),
    open_settings: () => hooks.openSettings(),
    open_queue: () => hooks.openQueue(),
    clear_queue: async action => (await import("./queue.js")).clear(hooks, action.conversation_id),
    request_conversation_delete: async action => (await import("./history.js")).deletion({conversation_id: action.conversation_id}, hooks),
    open_trace: action => hooks.openTrace(action.request_id),
    show_help: action => {
      const body = openSheet("Application commands");
      for (const command of action.commands || commands) {
        const row = node("p"); row.append(node("strong", command.command),
          node("span", ` ${command.aliases.map(a => "/" + a).join(", ")} · ${command.description}`));
        const reason = protocol.availability(command, view());
        if (reason) row.append(node("small", reason, "muted")); body.append(row);
      }
    },
    await_backend_restart: async action => {
      window.SMTOLifecycle.begin(action);
    },
  };
  async function execute(raw) {
    if (busy) return;
    await ready;
    if (busy) return;
    const name = raw.trimStart().slice(1).split(/\s/)[0].toLowerCase();
    const definition = commands.find(c => c.name === name || c.aliases.includes(name));
    const reason = definition && protocol.availability(definition, view());
    if (reason) { notice(reason); return; }
    const captured = view(); busy = true; close(); input.value = ""; saveDraft(""); hooks.renderComposer();
    const restarting = /^\/restart\s*$/i.test(raw.trim());
    if (restarting) window.SMTOLifecycle?.begin();
    try {
      const result = await api("commands/execute", {method: "POST", body: {
        command: raw, context: protocol.context(captured, "mobile"),
      }});
      if (!protocol.sameView(captured, view())) return;
      if (result.status === "error") {
        if (restarting) window.SMTOLifecycle?.cancel();
        if (!input.value) { input.value = raw; saveDraft(raw); }
        notice(result.message); return;
      }
      if (result.message) notice(result.message);
      const action = result.client_action;
      if (!action) return;
      if (action.conversation_id && action.conversation_id !== captured.conversation_id
        || action.request_id && action.request_id !== captured.request_id) throw window.SMTOErrors.error("ui_state_stale");
      if (!Object.hasOwn(actions, action.type)) throw window.SMTOErrors.error("ui_command_unavailable");
      await actions[action.type](action);
    } catch {
      if (restarting) window.SMTOLifecycle?.uncertain();
      if (protocol.sameView(captured, view()) && !input.value) { input.value = raw; saveDraft(raw); }
      notice("Command request failed. Refresh and try again.");
    } finally { busy = false; hooks.renderComposer(); }
  }
  input.addEventListener("input", () => { dismissed = false; selected = 0; update(); });
  window.addEventListener("pagehide", disposeStatus);
  return {update, keydown, execute, isBusy: () => busy};
}
