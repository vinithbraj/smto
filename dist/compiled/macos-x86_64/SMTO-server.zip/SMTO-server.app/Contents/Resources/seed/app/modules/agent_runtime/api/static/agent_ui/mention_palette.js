/* Transient resource discovery. Structured state stays with the existing owners. */
(() => {
  "use strict";
  let categories = [], queryPattern = null, literalPattern = null, registryPromise = null;
  function configure(registry) {
    categories = registry.namespaces;
    queryPattern = new RegExp(registry.query_pattern, "i");
    literalPattern = new RegExp(registry.literal_pattern, "g");
  }
  function loadRegistry() {
    if (!registryPromise) registryPromise = Promise.resolve(window.SMTOReadPriority?.ready)
      .then(() => window.SMTOErrors.fetch("/api/agent/mentions", {cache: "no-store"}))
      .then(async response => { if (!response.ok) throw await window.SMTOErrors.fromResponse(response); return window.SMTOErrors.readJson(response); })
      .then(configure).catch(error => { registryPromise = null; throw error; });
    return registryPromise;
  }
  function parse(text, caret = text.length, end = caret) {
    if (!queryPattern || caret !== end || !caret || text.trimStart().startsWith("/")) return null;
    const start = text.lastIndexOf("@", caret - 1);
    if (start < 0 || (start > 0 && !/\s/.test(text[start - 1]))) return null;
    const masked = text.replace(literalPattern, value => " ".repeat(value.length));
    if (masked[start] !== "@") return null;
    const match = queryPattern.exec(text.slice(start, caret));
    if (!match) return null;
    const prefix = match[1].toLowerCase();
    const category = categories.find(item => item.id === prefix || item.aliases?.includes(prefix))?.id || "";
    if (!category && match[2] !== undefined) return null;
    return {start, end: caret, prefix, category, query: match[2] || ""};
  }
  function consume(text, token) {
    let left = text.slice(0, token.start), right = text.slice(token.end);
    // Only normalize horizontal whitespace touching the consumed token.
    if (/[ \t]$/.test(left) && /^[ \t]/.test(right)) right = right.replace(/^[ \t]+/, "");
    if (!left) right = right.replace(/^[ \t]+/, "");
    if (!right) left = left.replace(/[ \t]+$/, "");
    return {text: left + right, caret: left.length};
  }
  // A display name preserves sentence grammar; only gateway_selection grants addressability.
  function displayGateway(text, token, label) {
    const right = text.slice(token.end);
    const inserted = label + (!right || /^[\w]/.test(right) ? " " : "");
    return {text: text.slice(0, token.start) + inserted + right, caret: token.start + inserted.length};
  }
  function create({input, composer, targetSelector, nativeControls, conversationId, isSteering,
    notify, onDraftChanged, onVisibilityChanged = () => {}, onBusyChanged = () => {}}) {
    let token = null, rows = [], selected = 0, generation = 0, timer = null, controller = null;
    let searchKey = "", dismissedPrefix = null, busy = false, composing = false, rendered = "";
    let selectionGeneration = 0, busyConversation = null;
    let parameterCache = null, parameterCacheAt = 0;
    const panel = document.createElement("div");
    panel.id = "mention-palette"; panel.className = "mention-palette"; panel.hidden = true;
    panel.setAttribute("role", "listbox"); panel.setAttribute("aria-label", "Request resources");
    composer.prepend(panel);
    const current = () => parse(input.value, input.selectionStart, input.selectionEnd);
    const locked = () => isSteering() || composer.hidden || input.disabled;
    const isBusy = () => busy && busyConversation === conversationId();
    const sameToken = value => value && token && value.start === token.start && value.end === token.end
      && value.category === token.category && value.query === token.query && value.prefix === token.prefix;
    function cancelSearch() { generation++; clearTimeout(timer); controller?.abort(); controller = null; searchKey = ""; }
    function close(dismiss = false) {
      if (dismiss && token) dismissedPrefix = input.value.slice(0, token.end);
      const visible = !panel.hidden;
      panel.hidden = true; token = null; cancelSearch();
      if (input.getAttribute("aria-controls") === panel.id) {
        input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant");
      }
      if (visible) onVisibilityChanged();
    }
    function highlight() {
      [...panel.querySelectorAll('[role="option"]')].forEach((row, index) => {
        row.setAttribute("aria-selected", String(index === selected && !rows[index].disabled));
      });
      const row = panel.querySelector(`#mention-option-${selected}`);
      if (row && !rows[selected]?.disabled) {
        input.setAttribute("aria-activedescendant", row.id); row.scrollIntoView({block: "nearest"});
      } else input.removeAttribute("aria-activedescendant");
    }
    function render(items, message = "") {
      const signature = JSON.stringify([token?.category, items, message]);
      if (!panel.hidden && signature === rendered) return;
      rendered = signature;
      rows = items; selected = Math.max(0, rows.findIndex(row => !row.disabled));
      panel.replaceChildren();
      const heading = document.createElement("p");
      heading.className = "mention-heading";
      heading.textContent = categories.find(item => item.id === token?.category)?.title || "Add to this request";
      panel.append(heading);
      if (token?.category) {
        const back = document.createElement("button"); back.type = "button"; back.tabIndex = -1;
        back.textContent = "←"; back.setAttribute("aria-label", "Back to request resources");
        back.addEventListener("mousedown", event => event.preventDefault());
        back.addEventListener("click", goBack); heading.append(back);
      }
      if (message) { const status = document.createElement("p"); status.setAttribute("role", "status"); status.textContent = message; panel.append(status); }
      rows.forEach((item, index) => {
        const option = document.createElement("button"); option.type = "button"; option.tabIndex = -1;
        option.id = `mention-option-${index}`; option.setAttribute("role", "option");
        option.setAttribute("aria-disabled", String(Boolean(item.disabled)));
        option.setAttribute("aria-label", `${item.kind || "Resource"} — ${item.title}. ${item.detail || ""}`);
        const title = document.createElement("strong"), detail = document.createElement("span");
        title.textContent = item.title; detail.textContent = item.detail || ""; option.append(title, detail);
        option.addEventListener("mousedown", event => event.preventDefault());
        option.addEventListener("click", () => { selected = index; void select(); }); panel.append(option);
      });
      panel.hidden = false;
      input.setAttribute("aria-controls", panel.id); input.setAttribute("aria-autocomplete", "list");
      input.setAttribute("aria-expanded", "true"); highlight(); onVisibilityChanged();
    }
    function gateways() {
      const query = token.query.toLowerCase();
      const items = targetSelector.recordsSnapshot().filter(item =>
        [item.label, item.node, item.platform_label, item.locality].some(text => text.toLowerCase().includes(query))
      ).slice(0, 50).map(item => ({kind: "Gateway", title: item.label,
        detail: [item.locality, item.platform_label, item.status, item.is_default ? "Default" : ""].filter(Boolean).join(" · "),
        disabled: item.status === "disabled", value: item}));
      render(items, items.length ? "" : "No matching Gateways");
    }
    function rootRows() {
      const slots = nativeControls.remainingAttachmentSlots();
      return categories.filter(item => item.id.startsWith(token.prefix)).map(item => ({...item,
        kind: "Resource", category: item.id,
        disabled: ["context", "file", "artifact"].includes(item.id) && slots === 0,
        detail: ["context", "file", "artifact"].includes(item.id) && slots === 0
          ? "At most 16 context sources per request." : item.detail}));
    }
    function parameters(roots = []) {
      const query = (token.category ? token.query : token.prefix).toLowerCase();
      const key = JSON.stringify(["parameter", token.category, query]);
      if (searchKey === key) return;
      cancelSearch(); searchKey = key;
      const request = generation;
      const show = entries => {
        if (request !== generation || locked() || !sameToken(current())) return;
        const found = entries.filter(value => [value.key, value.normalized_key, value.description,
          ...(value.aliases || []), ...(value.tags || [])].some(text => text.toLowerCase().includes(query)))
          .slice(0, 50).map(value => ({kind: "Parameter Store", title: value.key,
            detail: value.mention_error || value.fields.join(" · "),
            disabled: value.mention_conflict, parameter: true, value}));
        render([...roots, ...found], roots.length || found.length ? "" : "No matching parameters");
      };
      if (parameterCache && Date.now() - parameterCacheAt < 30000) { show(parameterCache); return; }
      render(roots, "Loading parameters…");
      timer = setTimeout(async () => {
        controller = new AbortController();
        try {
          const response = await window.SMTOErrors.fetch("/api/agent/mentions/parameters?limit=1000",
            {cache: "no-store", signal: controller.signal});
          if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
          const data = await window.SMTOErrors.readJson(response);
          parameterCache = data.entries || []; parameterCacheAt = Date.now(); show(parameterCache);
        } catch (error) {
          if (request === generation && error.name !== "AbortError") render(roots, error.message);
        }
      }, 180);
    }
    function goBack() {
      if (!token?.category) return;
      const caret = token.start + 1;
      input.value = input.value.slice(0, token.start) + "@" + input.value.slice(token.end);
      input.focus(); input.setSelectionRange(caret, caret); onDraftChanged(); update(true);
    }
    function update(trigger = false) {
      const next = current();
      if (!next || (dismissedPrefix && !input.value.startsWith(dismissedPrefix))) dismissedPrefix = null;
      if (locked() || composing || !next || dismissedPrefix || (!trigger && panel.hidden)) { close(); return; }
      if (isBusy()) return;
      token = next;
      const slots = nativeControls.remainingAttachmentSlots();
      if (!token.category) {
        const roots = rootRows();
        if (token.prefix) parameters(roots);
        else { cancelSearch(); render(roots); }
        return;
      }
      if (token.category === "parameter") { parameters(); return; }
      if (token.category === "gateway") { cancelSearch(); gateways(); return; }
      if (!slots) { cancelSearch(); render([], "At most 16 context sources per request."); return; }
      if (token.category === "file") {
        cancelSearch(); render([{kind: "File", title: "Upload file…", detail: "Choose files from this device"}]); return;
      }
      const conversation = conversationId();
      if (!conversation) { cancelSearch(); render([], "Saved context becomes available after this conversation has been created."); return; }
      const key = JSON.stringify([conversation, token.category, token.query]);
      if (key === searchKey) return;
      cancelSearch(); searchKey = key;
      const request = generation, category = token.category, query = token.query;
      render([], "Loading…");
      timer = setTimeout(async () => {
        controller = new AbortController();
        try {
          const params = new URLSearchParams({conversation_id: conversation, query, limit: "20"});
          const response = await window.SMTOErrors.fetch(`/api/agent/context/${category === "context" ? "sources" : "artifacts"}?${params}`,
            {cache: "no-store", signal: controller.signal});
          if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
          const data = await window.SMTOErrors.readJson(response);
          if (request !== generation || locked() || conversation !== conversationId() || !sameToken(current())) return;
          const items = (data[category === "context" ? "sources" : "artifacts"] || []).slice(0, 20).map(value => category === "context"
            ? {kind: "Context", title: value.name || value.context_id,
              detail: `${value.media_type} · ${value.bytes < 1024 ? value.bytes + " bytes" : (value.bytes / 1024).toFixed(1) + " KB"}`, value}
            : {kind: "Artifact", title: value.reference,
              detail: `${value.capability_id || "Agent result"} · ${value.status}${value.complete ? " · completed" : ""} · fields: ${value.fields.join(", ")}`, value});
          render(items, items.length ? "" : category === "context" ? "No matching saved context" : "No matching artifacts");
        } catch (error) { if (request === generation && error.name !== "AbortError") render([], error.message); }
      }, 180);
    }
    function clean(value, active, label = null) {
      const result = label === null ? consume(value, active) : displayGateway(value, active, label); close(); input.value = result.text;
      input.focus(); input.setSelectionRange(result.caret, result.caret); onDraftChanged();
    }
    async function select() {
      const item = rows[selected], active = token, value = input.value, conversation = conversationId();
      if (isBusy() || locked() || !item || item.disabled || !sameToken(current())) return;
      if (item.category) {
        input.value = value.slice(0, active.start) + `@${item.category} ` + value.slice(active.end);
        const caret = active.start + item.category.length + 2;
        input.focus(); input.setSelectionRange(caret, caret); onDraftChanged(); update(true); return;
      }
      if (item.parameter) {
        const inserted = `@${item.value.mention_key} `;
        input.value = value.slice(0, active.start) + inserted + value.slice(active.end);
        const caret = active.start + inserted.length;
        close(); input.focus(); input.setSelectionRange(caret, caret); onDraftChanged(); return;
      }
      busy = true;
      busyConversation = conversation;
      const selection = ++selectionGeneration;
      onBusyChanged();
      try {
        if (active.category === "gateway") {
          if (!targetSelector.addGateway(item.value.gateway_id)) throw window.SMTOErrors.error("ui_gateway_selection_invalid");
          clean(value, active, item.value.label);
        } else if (active.category === "file") {
          // Selecting the action consumes @file, including when the chooser is cancelled.
          nativeControls.openFilePicker(); clean(value, active);
        } else {
          const attached = await (active.category === "context" ? nativeControls.attachContext(item.value) : nativeControls.attachArtifact(item.value));
          if (attached && conversation === conversationId() && !locked()
            && input.value.startsWith(value.slice(0, active.end))) clean(input.value, active);
        }
      } catch (error) {
        if (selection === selectionGeneration && conversation === conversationId()) {
          notify([403, 404].includes(error.status) ? "That resource is no longer available." : error.message);
          cancelSearch();
        }
      } finally {
        if (selection === selectionGeneration) { busy = false; onBusyChanged(); if (!panel.hidden) update(); }
      }
    }
    function keydown(event) {
      if (panel.hidden || event.isComposing || composing || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;
      if (locked()) { close(); return false; }
      if (event.key === "ArrowLeft" && !token?.category) return false;
      // Leave Home and End cursor/selection behavior to the composer.
      if (!["ArrowUp", "ArrowDown", "Enter", "Tab", "Escape", "ArrowLeft"].includes(event.key)) return false;
      event.preventDefault();
      if (event.key === "ArrowLeft") goBack();
      else if (event.key === "Escape") close(true);
      else if (["Enter", "Tab"].includes(event.key)) void select();
      else {
        const choices = rows.map((item, index) => item.disabled ? -1 : index).filter(index => index >= 0);
        if (choices.length) {
          const index = choices.indexOf(selected);
          selected = choices[(index + (event.key === "ArrowUp" ? -1 : 1) + choices.length) % choices.length];
          highlight();
        }
      }
      return true;
    }
    const ready = () => loadRegistry().then(() => {
      if (document.activeElement === input) update(true);
    }).catch(error => notify(error.message));
    void ready();
    input.addEventListener("input", () => { if (!queryPattern) void ready(); else update(true); });
    input.addEventListener("beforeinput", () => {
      if (input.selectionStart !== input.selectionEnd) dismissedPrefix = null;
    });
    input.addEventListener("compositionstart", () => { composing = true; close(); });
    input.addEventListener("compositionend", () => { composing = false; update(true); });
    input.addEventListener("blur", () => close(true));
    document.addEventListener("selectionchange", () => { if (!panel.hidden && !sameToken(current())) update(); });
    return {keydown, update: () => update(), close, isOpen: () => !panel.hidden, isBusy};
  }
  window.SMTOMentionPalette = {create, parse, consume, displayGateway, configure};
})();
