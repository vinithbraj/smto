/* Timed-wait controls shared by desktop and mobile. Countdown ticks keep this DOM mounted. */
(() => {
  "use strict";
  function create({requestId, submit, refresh, notify}) {
    const root = document.createElement("span");
    root.className = "wait-controls"; root.hidden = true;
    root.setAttribute("role", "group"); root.setAttribute("aria-label", "Adjust timed wait");
    const button = (text, label) => {
      const item = document.createElement("button"); item.type = "button";
      item.textContent = text; item.title = label; item.setAttribute("aria-label", label);
      return item;
    };
    const minus = button("−", "Subtract time"), plus = button("+", "Add time");
    const wake = button("Wake now", "Wake now");
    const amount = document.createElement("input");
    amount.type = "number"; amount.min = "1"; amount.step = "1"; amount.value = "1";
    amount.required = true; amount.inputMode = "numeric"; amount.setAttribute("aria-label", "Time adjustment amount");
    const unit = document.createElement("select"); unit.setAttribute("aria-label", "Time adjustment unit");
    for (const [value, label] of [[1, "seconds"], [60, "minutes"], [3600, "hours"]]) {
      const option = document.createElement("option"); option.value = value; option.textContent = label;
      unit.append(option);
    }
    unit.value = "60";
    const retry = button("Refresh wait", "Refresh wait before trying again"); retry.hidden = true;
    const message = document.createElement("span"); message.className = "wait-control-message";
    message.setAttribute("role", "status"); message.hidden = true;
    root.append(minus, amount, unit, plus, wake, retry, message);
    let state = null, busy = false, blocked = false;
    const eligible = () => state?.status === "waiting_event" && state.waitTiming?.kind === "time" && state.waitControl?.token
      && !state.stopping && !state.pausing && !state.resuming;
    function render() {
      root.hidden = !eligible();
      for (const item of [minus, plus, wake, amount, unit]) item.disabled = busy || blocked;
      root.setAttribute("aria-busy", String(busy));
      retry.hidden = !blocked; retry.disabled = busy;
    }
    async function reconcile() {
      const current = await refresh().catch(() => false);
      blocked = current === false;
      message.textContent = blocked ? "Could not refresh this wait. Refresh before trying again." : "";
      message.hidden = !blocked;
      return !blocked;
    }
    async function send(action, sign = 0) {
      if (busy || blocked || !eligible()) return;
      let delta;
      if (action === "adjust") {
        delta = amount.valueAsNumber * Number(unit.value);
        amount.setCustomValidity(Number.isSafeInteger(amount.valueAsNumber) && amount.valueAsNumber > 0
          && Number.isSafeInteger(delta) ? "" : "Enter a positive whole number.");
        if (!amount.reportValidity()) return;
      }
      const payload = {action, expected_wait_token: state.waitControl.token,
        ...(action === "adjust" ? {delta_seconds: sign * delta} : {})};
      busy = true; render();
      try {
        await submit(requestId, payload);
      } catch (error) {
        notify(error);
      } finally {
        // A failed POST may have committed. Never replay an adjustment blindly.
        await reconcile();
        busy = false; render();
      }
    }
    amount.addEventListener("input", () => amount.setCustomValidity(""));
    minus.addEventListener("click", () => void send("adjust", -1));
    plus.addEventListener("click", () => void send("adjust", 1));
    wake.addEventListener("click", () => void send("wake"));
    retry.addEventListener("click", async () => {
      busy = true; render();
      await reconcile(); busy = false; render();
    });
    return {root, update(value) { state = value; render(); }};
  }
  window.SMTOWaitControls = {create};
})();
