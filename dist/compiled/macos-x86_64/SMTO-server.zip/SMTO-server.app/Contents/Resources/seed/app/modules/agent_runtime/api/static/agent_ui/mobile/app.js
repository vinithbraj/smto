/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/app.js
 * @brief Compose dedicated mobile conversation navigation, submission and stream reconciliation.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities:
 * - Coordinate mobile composer/conversation modules, settings refresh, request controls and
 *   server trace/event streams.
 * Boundaries:
 * - This entry point does not instantiate the desktop controller or own scheduler/authorization
 *   decisions. Server APIs remain authoritative for accepted run state.
 * Lifecycle:
 * - Open a conversation with a new navigation generation, abort stale navigation, attach
 *   streams, then reconcile actions and composer state.
 * - Historical interaction summaries fetch the full trace before a bound reply is offered.
 * State:
 * - Page-local timers, refresh coalescing and pending-submission maps coordinate requests.
 *   api.js owns shared mobile state/storage; generation checks protect navigation from stale
 *   responses.
 * Security:
 * - OAuth follows its protocol interaction path; browser draft/storage choices must not
 *   promote protected values into ordinary persisted text.
 * Collaborators:
 * - composer.js owns input behavior; conversation.js owns turns/navigation/rendering;
 *   streaming.js owns stream lifecycle; overlays.js owns panel dismissal.
 * Public surface:
 * - openConversation, refresh and control hooks connect the mobile page to its composed
 *   controllers; API/run status remains server-owned.
 *
 * @see src/agent_runtime/api/static/agent_ui/mobile/api.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/conversation.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/streaming.js
 */
import "../activity_presentation.js?v=20261015-smto";
import {composerProfile, loadComposer} from "./composer_profile.js";
import {submissionOptions} from "./submission_options.js";
import {
  $,
  api,
  state,
  storage,
  node,
  notice,
  connection,
  encode,
  terminal,
  runStatus,
  saveDraft,
  restoreCapabilityDraft,
  consumeDraft,
  applyAppearance,
} from "./api.js";
import { initComposer, renderComposer, restoreDraft } from "./composer.js?v=20261015-smto";
let turns = new Map(), turnFor, setTurnActivityLineage, showSubmission, acceptSubmission, failSubmission,
  applyEvent, applyTrace, resetCursor, renderActions, summaryFor, showPlanTask, renderApprovedPlan, releaseTurn, removeDeletedSubmissions, navigateToConversationTurn;
let clearConversation = () => {}, follow = () => {}, refreshNavigator = () => {};
let conversationLoading;
async function ensureConversation() {
  if (!conversationLoading) conversationLoading = import("./conversation.js?v=20261015-smto").then(module => {
    ({turns, turnFor, setTurnActivityLineage, showSubmission, acceptSubmission, failSubmission, clearConversation,
      applyEvent, applyTrace, resetCursor, renderActions, summaryFor, follow, refreshNavigator, showPlanTask, renderApprovedPlan, releaseTurn, removeDeletedSubmissions, navigateToConversationTurn} = module);
    module.initConversation(actionState, retryContract);
  }).catch(error => { conversationLoading = null; throw error; });
  await conversationLoading;
}
import { createStreams } from "./streaming.js?v=20261015-smto";
import { closeSheet } from "./overlays.js";

const observing = (status) =>
  ["running", "pending", "queued", "waiting_job", "waiting_event"].includes(
    status,
  );
let refreshing = null,
  refreshAgain = false,
  refreshTimer = null;
let settingsVersion = 0;
const pendingSubmissions = new Map();
const taskDeletion = window.SMTOTaskDeletionController = window.SMTOTaskDeletion.create({
  conversationId: () => state.conversationId,
  apiJson: (url, options) => api(url.replace(/^\/api\/agent\//, ""), {
    ...options, ...(options.body ? {body: JSON.parse(options.body)} : {}),
  }), notify: notice,
  changed: (cid, deleted) => {
    if (cid !== state.conversationId) return;
    const viewport = $("#thread");
    const anchor = [...turns.values()].find(turn => !deleted(turn) && turn.root.getBoundingClientRect().bottom > viewport.getBoundingClientRect().top)?.root;
    const top = anchor?.getBoundingClientRect().top;
    for (const turn of [...turns.values()]) if (deleted(turn)) { streams.stopTrace(turn); releaseTurn(turn); }
    removeDeletedSubmissions?.(deleted);
    if (anchor?.isConnected) viewport.scrollTop += anchor.getBoundingClientRect().top - top;
    if (state.chat?.turns) state.chat.turns = state.chat.turns.filter(turn => !deleted(turn));
    if (deleted({request_id: state.requestId})) { state.requestId = null; state.run = null; }
    if (!turns.size) $("#welcome").hidden = false;
    refreshNavigator(); renderComposer(); scheduleRefresh();
  },
});
const hooks = {
  openConversation,
  newChat: () => openConversation(null),
  submit,
  openHistory: () => lazy("history"),
  openQueue: () => lazy("queue"),
  openSettings: () => { saveDraft($("#message").value); location.assign("/settings"); },
  openTrace: rid => {
    const turn = turns.get(rid);
    if (!turn) { notice("No current run trace is available."); return; }
    turn.activity.hidden = false; turn.activity.open = true;
    turn.activity.scrollIntoView({block: "nearest"}); turn.activity.querySelector("summary")?.focus();
  },
  refresh,
  control,
  steer: ({requestId, amendment, submissionId, steeringMode = "interrupt"}) => api(`native/${encode(requestId)}/control`, {
    method: "POST", body: {action: "steer", amendment, submission_id: submissionId, steering_mode: steeringMode},
  }),
  cancelSteer: ({requestId, submissionId}) => api(`native/${encode(requestId)}/control`, {
    method: "POST", body: {action: "cancel_steer", submission_id: submissionId},
  }),
  followup: async ({requestId, amendment, submissionId}) => {
    const generation = state.generation;
    const result = await api(`native/${encode(requestId)}/follow-up`, {
      method: "POST", body: {amendment, submission_id: submissionId},
    });
    if (generation !== state.generation) return result;
    const turn = turnFor(result.request_id, result.followup_prompt || amendment, {
      taskId: result.task_id, parentRequestId: result.parent_request_id || result.continuation?.parent_request_id || requestId,
    });
    turn.run = result; turn.status = runStatus(result);
    actionState(turn, turn.trace || {});
    if (observing(turn.status)) streams.attach(turn);
    if (state.requestId === requestId) state.requestId = result.request_id;
    void refresh().catch(() => {});
    return result;
  },
  resumeResponse,
  renderComposer,
  notify: notice,
};
const streams = createStreams({
  event: (turn, event) => {
    applyEvent(turn, event);
    if (state.replyPendingRequestId === turn.id && !turn.replyResume?.pending)
      actionState(turn, turn.trace || {});
    if (
      [
        "run.paused",
        "user.input.required",
        "confirmation.required",
      ].includes(event.event_type)
    )
      scheduleRefresh();
  },
  snapshot: (turn, trace) => applyTrace(turn, trace),
  cursor: (...args) => resetCursor?.(...args),
  refresh,
  current: (id) => observing(turns.get(id)?.status) || turns.get(id)?.awaitingFinalTrace
    || turns.get(id)?.replyResume?.pending || window.SMTOTaskLifecycle?.replyHandoff(turns.get(id)?.trace),
});

const selectedConversation = window.SMTOConversationSnapshot.create({
  apiJson: (path, options) => api(path, options),
  freshness: (freshness, previous) => {
    $("#messages").dataset.freshness = freshness;
    if (freshness === "current" && Number.isFinite(previous?.observed_at))
      for (const turn of turns.values())
        window.SMTOStreamActivity.syncClock(turn.liveActivity.streamActivity, previous.observed_at * 1000);
    if (freshness === "stale") connection(navigator.onLine ? "Live state is stale. Reconnecting…" : "Offline · showing last known state");
    else if (freshness === "current") connection();
  },
  apply: async (snapshot, lane) => {
    await ensureConversation();
    if (snapshot.conversation.conversation_id !== state.conversationId) return;
    taskDeletion.observe(snapshot);
    lane.tasks = lane.tasks.filter(task => !taskDeletion.deleted(task));
    state.snapshot = snapshot; state.lane = lane;
    state.requestId = taskDeletion.deleted({request_id: snapshot.current_request_id}) ? null : snapshot.current_request_id;
    state.run = snapshot.executions_by_request_id[state.requestId] || null;
    hooks.laneChanged?.(lane);
    for (const task of lane.tasks) {
      if (task.has_approved_plan && !task.current_request_id && !task.latest_request_id) showPlanTask(task);
    }
    for (const [rid, run] of Object.entries(snapshot.executions_by_request_id)) {
      if (taskDeletion.deleted({request_id: rid, task_id: run.task_id})) continue;
      const task = lane.tasks.find(task => (task.current_request_id || task.latest_request_id) === rid);
      const continuation = Boolean(run.continuation) && !run.followup_prompt;
      const turn = turns.get(rid) || turnFor(rid, run.followup_prompt || (continuation ? "" : task?.prompt || "Current request"), {
        taskId: run.task_id || task?.task_id, parentRequestId: run.parent_request_id,
      });
      const first = !turn.liveAttached;
      const previousStatus = turn.status;
      if ((run.state_revision || 0) < (turn.run?.state_revision || 0)) continue;
      if (!first && run.stream.generation === turn.createdAt && run.stream.after_id < turn.cursor
        && (run.state_revision || 0) <= (turn.run?.state_revision || 0)) continue;
      turn.replyResume ||= window.SMTOTaskLifecycle.restoreReply(run);
      if (window.SMTOTaskLifecycle.observeReply(turn.replyResume, run)) {
        summaryFor(turn); actionState(turn, turn.trace || {});
        if (turn.replyResume.pending) streams.attach(turn);
        continue;
      }
      const wasAwaitingFinalTrace = turn.awaitingFinalTrace;
      // Native completion can precede the trace's final message, including on reload.
      turn.awaitingFinalTrace = ["answered", "completed"].includes(runStatus(run))
        && ["running", "pending"].includes(run.trace?.status);
      setTurnActivityLineage(turn, run);
      turn.run = run;
      window.SMTORunActivity.setStatus(turn.liveActivity, runStatus(run), {...run, authoritative: true,
        ...(run.state_revision > (turn.nativeRevision || 0) ? {trace_event_id: undefined} : {})});
      turn.nativeRevision = Math.max(turn.nativeRevision || 0, run.state_revision || 0);
      if (!turn.executionStatus || !run.execution_status?.trace_event_id
        || run.execution_status.trace_event_id >= (turn.executionStatus.trace_event_id || 0)) turn.executionStatus = run.execution_status;
      turn.executionInspector ||= window.SMTOConversationSnapshot.inspectControl({actionContainer: turn.detailActions, requestId: rid, apiJson: api});
      turn.executionInspector.update(run.observation);
      applyTrace(turn, {...turn.trace, ...run.trace,
        ...(run.proposed_plan ? {proposed_plan: run.proposed_plan} : {}),
        ...(run.continuation ? {prompt: run.followup_prompt || ""} : {}),
        status: run.status, user_visible_status: run.user_visible_status,
        request_runtime_timing: run.timing, runtime_timing: run.timing});
      renderApprovedPlan(turn, task);
      if (first) turn.cursor = run.stream.after_id;
      turn.createdAt = run.stream.generation; turn.status = runStatus(run);
      summaryFor(turn); actionState(turn, turn.trace || {});
      if (observing(turn.status) || turn.awaitingFinalTrace || window.SMTOTaskLifecycle.replyHandoff(run)) {
        streams.attach(turn); turn.liveAttached = true;
        if (!turn.replyResume && window.SMTOTaskLifecycle.replyHandoff(run))
          void restoreFinal(turn, run);
      }
      else {
        streams.stopTrace(turn);
        const planNeedsAnswer = run.proposed_plan && turn.trace?.response_metrics?.proposed_plan?.digest !== run.proposed_plan.digest;
        if (terminal(turn.status) && (wasAwaitingFinalTrace || planNeedsAnswer || previousStatus !== turn.status && !first))
          void window.SMTOReadPriority.ready.then(() => restoreFinal(turn, run));
      }
    }
    state.loading = false;
    renderComposer(); hooks.commandStateChanged?.();
  },
});
window.SMTOSelectedConversation = selectedConversation;

function restoreFinal(turn, run) {
  if (turn.finalRead) return turn.finalRead;
  const generation = state.generation;
  turn.finalRead = api(`trace/${encode(turn.id)}/summary`).then(trace => {
    if (generation !== state.generation || !turn.root.isConnected) return;
    turn.replyResume ||= window.SMTOTaskLifecycle.restoreReply({...run, trace});
    // Native completion can precede the final trace frame. Retain its terminal
    // state while applying the available answer and checkpoint payload.
    applyTrace(turn, {...trace, status: run.status, user_visible_status: run.user_visible_status});
  }).catch(error => { if (generation === state.generation) notice(error); })
    .finally(() => { turn.finalRead = null; });
  return turn.finalRead;
}

function actionState(turn, trace) {
  const run = state.requestId === turn.id ? state.run : turn.run;
  if (window.SMTOTaskLifecycle.answeredQuestion(turn.replyResume, trace))
    trace = {...trace, clarification_required: false, clarification_request: null};
  if (state.requestId === turn.id) state.replyPendingRequestId = turn.replyResume?.pending ? turn.id : null;
  if (turn.replyResume?.pending) {
    if (state.requestId === turn.id) state.interaction = false;
    turn.actions.replaceChildren();
    renderComposer();
    return;
  }
  if (run) window.SMTOInlineSteer.observe(turn.id, run);
  if (state.requestId === turn.id)
    state.interaction = Boolean(
      trace.clarification_required ||
        trace.confirmation_required ||
        run?.unsafe_action_request || run?.resource_reconciliation_request,
    );
  void renderActions(turn, trace, run, hooks).catch((error) =>
    notice(error),
  );
  renderComposer();
}
function savePointer() {
  window.SMTOThinkingAnimations?.activate(state.conversationId);
  storage.set("conversation", state.conversationId);
  const url = new URL(location.href);
  if (state.conversationId)
    url.searchParams.set("conversation", state.conversationId);
  else url.searchParams.delete("conversation");
  url.searchParams.delete("task");
  history.replaceState(history.state, "", url);
}
window.addEventListener("mobile-conversation-missing", async () => {
  const id = state.conversationId;
  const feedback = await import("../deletion_progress.js?v=20261015-smto");
  await feedback.conversations.refresh();
  if (id === state.conversationId) void openConversation(null);
});
window.addEventListener("smto:conversation-deletion", renderComposer);
window.addEventListener("smto:conversation-deletion", () => {
  if (window.SMTOConversationDeletion?.autoPurged(state.conversationId)) {
    void openConversation(null).then(() => notice("Conversation automatically deleted after inactivity."));
  }
});
// Observe server-initiated deletion even when the history sheet has never opened.
void import("../deletion_progress.js?v=20261015-smto");
async function openConversation(id, { initial = false, fallbackOnMissing = false, sourceRequestId = "" } = {}) {
  if (window.SMTOConversationDeletion?.blocked(id)) {
    notice("This conversation is being deleted. Open another conversation or start a new chat."); return;
  }
  hooks.commandNavigation?.();
  if (!initial) {
    saveDraft($("#message").value);
    // Safari taps on navigation buttons can leave the editor focused.
    $("#message").blur();
  }
  if (!id && !initial) { storage.set("draft.new", null); storage.set("capability-draft.new", null); }
  const generation = ++state.generation;
  state.pendingSteer?.cancel(); state.pendingSteer = null;
  state.navigation?.abort();
  state.navigation = new AbortController();
  streams.stopTrace();
  clearTimeout(refreshTimer);
  state.conversationId = id;
  selectedConversation.select(id);
  state.requestId = null;
  state.run = null;
  state.lane = null;
  state.chat = null;
  state.steering = false;
  state.interaction = false;
  state.submitting = false;
  state.loading = Boolean(id);
  state.refs = [];
  state.choices.permission_policy = null;
  state.choices.capability_policy = null;
  state.choices.capability_selection = null;
  restoreCapabilityDraft(id);
  clearConversation();
  notice();
  restoreDraft({preserve: initial && state.draftEdited});
  await closeSheet();
  if (generation !== state.generation) return;
  savePointer();
  if (!id) {
    window.SMTOReadPriority.release();
    await loadComposer(id).catch(error => notice(error));
    if (generation !== state.generation) return;
    renderComposer();
    return;
  }
  try {
    void ensureConversation();
    state.currentSnapshotReady = selectedConversation.refresh();
    const target = sourceRequestId ? `&around_request_id=${encode(sourceRequestId)}` : "";
    const payload = await api(`chats/${encode(id)}/turns?limit=12${target}`, {
      signal: state.navigation.signal,
    });
    if (generation !== state.generation) return;
    await ensureConversation();
    if (generation !== state.generation) return;
    taskDeletion.observe(payload, id);
    state.chat = {...payload.conversation, turns: (payload.turns || []).filter(turn => !taskDeletion.deleted(turn))};
    // Historical snapshots contain public trace projections; invocation payloads remain lazy.
    for (const saved of state.chat.turns || [])
      if (saved.request_id)
        applyTrace(turnFor(saved.request_id, saved.prompt, {
          taskId: saved.task_id, parentRequestId: saved.parent_request_id,
        }), {...saved, ...(state.snapshot?.executions_by_request_id[saved.request_id]?.trace || {}),
          user_visible_status: state.snapshot?.executions_by_request_id[saved.request_id]?.user_visible_status || saved.status}, {
          historical: true,
        });
    state.loading = false;
    renderComposer();
    follow();
    performance.mark("mobile-conversation-rendered");
    if (payload.older_cursor) mountOlderTurns(id, payload.older_cursor, generation);
    if (payload.newer_cursor) mountOlderTurns(id, payload.newer_cursor, generation, "newer");
    await state.currentSnapshotReady;
    if (generation !== state.generation) return;
    await loadComposer(id);
    if (generation !== state.generation) return;
    if (sourceRequestId) {
      // Initial placement must finish before appearance/layout restoration can
      // interrupt a smooth scroll, especially when revealing filtered history.
      navigateToConversationTurn(sourceRequestId, {instant: true});
      const url = new URL(location.href); url.searchParams.set("task", sourceRequestId);
      history.replaceState(history.state, "", url);
    }
    void refreshSettings();
  } catch (error) {
    if (generation !== state.generation || error.name === "AbortError") return;
    if (fallbackOnMissing && error.status === 404) { await openConversation(null); return; }
    notice(error.message || "Couldn’t load this conversation.");
    const retry = node("button", "Retry loading conversation");
    retry.onclick = () => void openConversation(id, {sourceRequestId});
    $("#messages").append(retry);
    $("#welcome").hidden = true;
  } finally {
    if (generation === state.generation) {
      state.loading = false;
      renderComposer();
    }
  }
}
function scheduleRefresh() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => void refresh(), 120);
}
async function refreshSettings() {
  await window.SMTOReadPriority.ready;
  const version = ++settingsVersion;
  try {
    const payload = await api("settings/preferences");
    if (version === settingsVersion) {
      state.settings = payload.settings || state.settings;
      applyAppearance();
      window.SMTOActivityPresentation.applySettings(state.settings);
      window.SMTOThinkingAnimations?.setPreference(state.settings.ui_thinking_animation);
      window.SMTOActivityUpdates?.setPreference(state.settings.ui_activity_update_animation);
      refreshNavigator(); renderAgentName();
    }
  } catch { /* Existing invalidation retries refresh state. */ }
}
async function refresh(update) {
  if (!update || update.topics?.some(topic => ["chats.changed", "sync.required"].includes(topic))) {
    const feedback = await import("../deletion_progress.js?v=20261015-smto");
    await feedback.conversations.refresh();
  }
  const current = await (update ? selectedConversation.invalidate({...update,
    syncRequired: update.syncRequired ?? update.topics?.includes("sync.required")}) : selectedConversation.refresh());
  if (update?.topics?.some(topic => ["settings.changed", "sync.required"].includes(topic))) {
    void refreshSettings(); void composerProfile.refresh(); void state.refreshPolicyOptions?.();
  }
  if (update?.topics?.some(topic => ["chats.changed", "tasks.changed", "sync.required"].includes(topic)))
    void hooks.historyRefresh?.();
  return current;
}
function mountOlderTurns(cid, cursor, generation, direction = "older") {
  const older = direction === "older";
  const control = node("button", `Load ${direction} messages`, "history-older");
  const place = root => $("#messages")[older ? "prepend" : "append"](root);
  place(control);
  control.onclick = async () => {
    control.disabled = true;
    try {
      const page = await api(`chats/${encode(cid)}/turns?limit=12&${older ? "before" : "after"}=${encode(cursor)}`, {signal: state.navigation?.signal});
      if (generation !== state.generation) return;
      taskDeletion.observe(page, cid);
      for (const saved of older ? [...page.turns].reverse() : page.turns) {
        if (taskDeletion.deleted(saved)) continue;
        const turn = turnFor(saved.request_id, saved.prompt, {taskId: saved.task_id, parentRequestId: saved.parent_request_id});
        applyTrace(turn, saved, {historical: true});
        place(turn.activityGroup || turn.root);
      }
      cursor = older ? page.older_cursor : page.newer_cursor;
      if (cursor) place(control); else control.remove();
    } catch (error) { if (error.name !== "AbortError") notice(error); }
    finally { control.disabled = false; }
  };
}
async function resumeResponse(payload, previousId, answered = null) {
  const generation = state.generation;
  const rid = payload.request_id || previousId;
  if (rid) {
    if (!state.requestId || state.requestId === previousId) state.requestId = rid;
    const previous = turns.get(previousId);
    const turn = turnFor(rid, "", {taskId: payload.task_id || previous?.taskId,
      parentRequestId: rid !== previousId ? previousId : ""});
    if (answered && rid === previousId) {
      turn.replyResume = window.SMTOTaskLifecycle.replyAccepted(payload, answered.question, answered);
      turn.replyStreamUrl = payload.stream_url;
      if (turn.cursor > turn.replyResume.cursor) window.SMTOTaskLifecycle.observeReply(turn.replyResume, {
        request_id: rid, status: turn.status, last_event_id: turn.cursor,
        clarification_request: turn.trace?.clarification_request,
      });
      if (!turn.retained && (turn.text === answered.question.question || turn.transientNotice)) {
        turn.text = "";
        applyTrace(turn, {...turn.trace, final_response: ""});
        turn.answer.replaceChildren();
      }
      if (turn.replyResume.pending) streams.stopTrace(turn);
      if (turn.replyResume.pending || observing(turn.status)) streams.attach(turn);
      summaryFor(turn);
    }
    if (previous && previous !== turn) {
      previous.actionKey = null;
      previous.actions.replaceChildren();
      const trace = await api(`trace/${encode(previousId)}/summary`);
      if (generation !== state.generation) return;
      if (!previous.disposed) applyTrace(previous, trace);
    }
    for (const event of payload.conversation_events || []) applyEvent(turn, event);
    turn.actionKey = null;
    turn.actions.replaceChildren();
    // Acceptance schedules a worker; it does not assert that execution has resumed.
    notice("Response accepted. Waiting for the task to continue…");
    actionState(turn, turn.trace || {});
  }
  await refresh();
  const turn = turns.get(rid);
  if (turn && generation === state.generation) {
    const trace = await api(`trace/${encode(rid)}/summary`);
    if (generation === state.generation && !turn.disposed
      && Number(trace.last_event_id || 0) >= turn.cursor) applyTrace(turn, trace);
  }
  scheduleRefresh();
}
async function control(action, extra = {}, rid = state.requestId) {
  if (action === "force_stop") { action = "cancel"; extra = {...extra, mode: "instant"}; }
  const run = turns.get(rid)?.run || (rid === state.requestId ? state.run : null);
  const stop = run?.stop;
  if (action === "retry_task_contract") {
    if (!run?.task_contract_retry_attempt_id) return;
    extra = {...extra, retry_task_contract: true, contract_attempt_id: run.task_contract_retry_attempt_id};
    action = "resume";
  }
  if (["continue_next", "stop_next"].includes(action)) {
    if (!run?.continue_next) return;
    extra = {next_task_id: run.continue_next.next_task_id, version: run.continue_next.version,
      action: action === "stop_next" ? "stop" : "skip"};
  }
  if (action === "cancel" && stop?.mode === "graceful" && !stop.terminalized_at) extra = {...extra, mode: "instant"};
  const generation = state.generation;
  if (!rid || state.controlBusy) return;
  state.controlBusy = true;
  const turn = turns.get(rid);
  if (turn) { turn.lifecyclePending = action; actionState(turn, turn.trace || {}); }
  try {
    if (
      ["resume", "continue", "restart", "continue_next", "stop_next"].includes(action) &&
      !(await (await import("./lazy/legal.js?v=20261016-product-name")).ensureAgreement())
    )
      return;
    const newAttempt = ["continue", "restart"].includes(action);
    const advance = ["continue_next", "stop_next"].includes(action);
    const endpoint = advance ? "continue-next" : newAttempt ? action : "control";
    const result = await api(`native/${encode(rid)}/${endpoint}`, {
      method: "POST",
      ...(newAttempt ? {} : {body: advance ? extra : {action, ...extra}}),
    });
    if (generation !== state.generation) return;
    if (newAttempt && state.requestId === rid) state.requestId = result.request_id;
    if (action === "cancel" && state.requestId === rid) {
      state.run = { ...state.run, ...result, cancel_requested: result.status !== "cancelled" };
      renderComposer();
    }
    if (action === "pause" && state.requestId === rid) {
      state.run = { ...state.run, pause_requested: true };
      renderComposer();
    }
    await refresh();
    scheduleRefresh();
  } catch (error) {
    if (generation === state.generation) notice(error);
  } finally {
    state.controlBusy = false;
    if (turn && !turn.disposed) { turn.lifecyclePending = ""; actionState(turn, turn.trace || {}); }
  }
}
async function submit() {
  if (window.SMTOConversationDeletion?.blocked(state.conversationId)) return;
  const draft = $("#message").value,
    prompt = draft,
    steeringId = state.steering ? state.requestId : null,
    generation = state.generation,
    cid = state.conversationId,
    dependencyId = window.SMTOTaskDependencies.selectedTaskId(),
    dependencyVersion = window.SMTOTaskDependencies.revision();
  let restoreDependency = null, submissionId = null, submissionKey = null, durablyAccepted = false, postStarted = false;
  if (
    !prompt.trim() ||
    state.submitting ||
    state.loading ||
    state.interaction ||
    (runStatus(state.run) === "waiting_user" && state.run?.oauth_authorization_request?.kind === "oauth")
  )
    return;
  state.submitting = true;
  const steeringMode = state.steeringMode || "interrupt";
  const steerKey = JSON.stringify({action: "steer", requestId: steeringId, amendment: prompt, steeringMode});
  if (steeringId && !pendingSubmissions.has(steerKey)) pendingSubmissions.set(steerKey,
    `mobile_steer_${crypto.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)}`);
  const steerSubmissionId = pendingSubmissions.get(steerKey);
  const steeringTracker = steeringId ? window.SMTOInlineSteer.track(steeringId,
    message => { $("#steering-status span").textContent = message; renderComposer(); },
    {steeringMode, cancel: () => hooks.cancelSteer({requestId: steeringId, submissionId: steerSubmissionId})}) : null;
  if (steeringTracker) {
    state.pendingSteer = steeringTracker;
    $("#steering-status").innerHTML = window.SMTOInlineSteer.progressMarkup;
    if (steeringMode === "after_response") $("#steering-status span").textContent = window.SMTOInlineSteer.gentleWaiting;
  }
  notice();
  renderComposer();
  try {
    let options, body;
    if (!steeringId) {
      options = submissionOptions();
      body = {prompt, depends_on_task_id: dependencyId, conversation_id: cid,
        context_refs: state.refs.map(ref => ref.context_id), ...options};
      submissionKey = JSON.stringify(body);
      if (!pendingSubmissions.has(submissionKey)) pendingSubmissions.set(submissionKey,
        `mobile_${crypto.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)}`);
      submissionId = pendingSubmissions.get(submissionKey);
      body.client_submission_id = submissionId;
    }
    await ensureConversation();
    if (generation !== state.generation) return;
    if (submissionId) showSubmission(prompt, submissionId, body);
    const { ensureAgreement } = await import("./lazy/legal.js?v=20261016-product-name");
    if (!(await ensureAgreement()) || generation !== state.generation) {
      if (submissionId) { failSubmission(submissionId, true); pendingSubmissions.delete(submissionKey); }
      return;
    }
    if (steeringId) {
      const result = await api(`native/${encode(steeringId)}/control`, {
        method: "POST",
        body: { action: "steer", amendment: prompt, submission_id: steerSubmissionId, steering_mode: steeringMode },
      });
      if (generation !== state.generation) return;
      void refresh();
      const outcome = await steeringTracker.accepted(result);
      if (["applied", "withdrawn"].includes(outcome)) pendingSubmissions.delete(steerKey);
      if (outcome === "withdrawn" && generation === state.generation) notice("Steer cancelled. Your text is retained.");
      if (!window.SMTOInlineSteer.requireApplied(outcome)) return;
      if (generation !== state.generation) return;
      state.steering = false;
      if ($("#message").value === draft) $("#message").value = "";
      saveDraft($("#message").value);
      await refresh();
      if (generation === state.generation) follow(true);
      return;
    }
    if (window.SMTOTaskDependencies.revision() === dependencyVersion)
      restoreDependency = window.SMTOTaskDependencies.reset();
    postStarted = true;
    const accepted = await api("conversation-tasks", { method: "POST", body });
    durablyAccepted = true;
    pendingSubmissions.delete(submissionKey);
    restoreDependency = null;
    state.consumePolicyDraft?.(cid);
    consumeDraft(draft, cid);
    if (generation !== state.generation) return;
    acceptSubmission(submissionId, accepted);
    follow(true);
    for (const key of ["permission_policy", "capability_policy", "capability_selection"])
      if (state.choices[key] === options[key]) state.choices[key] = null;
    state.conversationId = accepted.conversation_id;
    selectedConversation.select(state.conversationId);
    composerProfile.accepted(accepted, body);
    savePointer();
    state.refs = state.refs.filter(
      (ref) => !body.context_refs.includes(ref.context_id),
    );
    if ($("#message").value === draft) $("#message").value = "";
    saveDraft($("#message").value);
    const rid =
      accepted.current_request_id || accepted.task?.current_request_id;
    if (rid) {
      state.requestId = rid;
    }
    void refresh();
    // The server may still be assigning a request to the accepted durable task.
    scheduleRefresh();
  } catch (error) {
    if (durablyAccepted) {
      notice("Task accepted. Some controls could not refresh.");
      return;
    }
    const definite = !postStarted || (error.status >= 400 && error.status < 500);
    if (definite && submissionKey) pendingSubmissions.delete(submissionKey);
    if (generation === state.generation && submissionId) failSubmission(submissionId, definite);
    if (generation === state.generation && error.detail?.code === "composer_state_changed") void refresh();
    if (generation === state.generation) restoreDependency?.();
    if (generation === state.generation)
      notice(
        error.message ||
          "Couldn’t confirm submission. Retry to reconcile the same task.",
      );
  } finally {
    steeringTracker?.cancel();
    if (state.pendingSteer === steeringTracker) state.pendingSteer = null;
    if (generation === state.generation) {
      state.submitting = false;
      renderComposer();
    }
  }
}
async function lazy(name, method = "open") {
  try {
    const modules = {
      history: () => import("./lazy/history.js?v=20261015-smto"),
      options: () => import("./lazy/conversation_options.js"),
      prompt: () => import("./lazy/agent_options.js?v=20261015-smto"),
      context: () => import("./lazy/context.js"),
      queue: () => import("./lazy/queue.js?v=20261015-smto"),
    };
    const generation = state.generation,
      module = await modules[name]();
    if (generation === state.generation) await module[method](hooks);
  } catch (error) {
    notice(error);
  }
}
function renderAgentName() {
  window.SMTOBranding.apply(state.settings);
}
applyAppearance();
window.addEventListener("smto:appearance-saved", event => {
  ++settingsVersion;
  state.settings = event.detail;
  applyAppearance();
});
renderAgentName();
async function retryContract(rid, attemptId) {
  if (!(await (await import("./lazy/legal.js?v=20261016-product-name")).ensureAgreement())) return false;
  const result = await api(`native/${encode(rid)}/control`, {method: "POST", body: {
    action: "resume", retry_task_contract: true, contract_attempt_id: attemptId,
  }});
  await resumeResponse(result, rid);
  return true;
}
initComposer(hooks);
$("#history").onclick = () => void lazy("history");
$("#options").onclick = () => void lazy("options");
$("#new-chat").onclick = () => void openConversation(null);
$("#add").onclick = () => void lazy("prompt");
$("#queue").onclick = () => void lazy("queue");
window.addEventListener("pagehide", () => saveDraft($("#message").value));
async function boot() {
  const linked = new URL(location.href).searchParams.get("conversation"),
    saved = storage.get("conversation");
  if (linked || saved)
    await openConversation(linked || saved, { initial: true,
      sourceRequestId: linked ? new URL(location.href).searchParams.get("task") || "" : "" });
  else {
    const generation = state.generation;
    try {
      const payload = await api("current-run");
      if (
        generation === state.generation &&
        payload.reconnectable &&
        payload.current_run?.conversation_id
      )
        await openConversation(payload.current_run.conversation_id, {
          initial: true,
        });
      else if (generation === state.generation)
        await openConversation(null, { initial: true });
    } catch {
      connection("Backend unavailable. Retry when connected.");
    }
  }
  streams.updates();
  performance.mark("mobile-ready");
}
void boot();
