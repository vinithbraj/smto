---
{"title": "How tasks pause, continue, and run later", "status": "published"}
---
## Closing the browser does not stop accepted work

Once SMTO accepts a task, it saves progress on the computer running its main
service. You can close the browser while that service continues working. This is
sometimes called durable execution: the task is saved beyond one browser connection.

Shutting down the computer is different. SMTO, the AI service, and the tools needed
for the next step must be available for work to continue. Saved progress alone
does not keep a powered-off computer working.

## SMTO keeps a record of each step

The saved task includes what you asked for, which computer was selected, the
settings, and the results of actions already taken. These details help SMTO tell
one attempt from another when work resumes.

A record that an action started is not proof it finished. A task may still be
waiting for a command to end, a file to be returned, or your answer to a question.

## A broken connection can leave an unclear result

Suppose a tool saves a file, but the connection breaks before its reply arrives.
The file may already exist. Trying again immediately could repeat a change that
was already made.

SMTO checks the available records before repeating an interrupted action. If it
cannot find out what happened, the result remains unclear. Further checking may
be needed. Saving progress cannot guarantee that every action happens only once.

## A task can wait for your answer

If SMTO needs permission or more information, it saves the task and waits. It does
not repeatedly ask the AI to check for your reply. Your answer belongs to that
particular question; it does not approve unrelated actions.

A **job** is an action that takes time and can be followed separately. A **schedule**
is an instruction to start work later. A **wait** pauses a task until an answer,
result, or set time arrives. A saved schedule does not mean its task has already run.

## Try a simple task first

Use a task that only reads information and has a result you can check. Close the
browser, return, and look at the activity history. For scheduled work, check that
the needed computers and services will be available when it is due.

Read the [guide to longer tasks](/docs/concepts/jobs),
[how a task runs](/learn/agent-execution-loop), and
[how to check results](/learn/verifiable-agent-completion).
See [SMTO's features](/product) and [installation options](/download).
