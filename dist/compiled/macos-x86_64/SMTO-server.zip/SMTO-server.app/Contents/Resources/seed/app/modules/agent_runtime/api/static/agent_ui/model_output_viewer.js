/* Read-only provider output. Text never becomes HTML, a tool, or conversation history. */
export const PREVIEW_LIMIT = 256 * 1024;
import "./number_odometer.js?v=20261015-smto";
const viewers = new Set();
const element = (tag, text, className = "") => {
  const node = document.createElement(tag); node.textContent = text; node.className = className; return node;
};
const refresh = () => { for (const viewer of viewers) viewer.reconcile(); };
document.addEventListener("visibilitychange", refresh);
document.addEventListener("toggle", refresh, true);
window.addEventListener("pagehide", () => { for (const viewer of viewers) viewer.suspend(); });
window.addEventListener("pageshow", refresh);
new MutationObserver(records => {
  if (records.some(record => record.removedNodes.length))
    for (const viewer of viewers) if (!viewer.disclosure.isConnected) viewer.dispose();
}).observe(document.documentElement, {childList: true, subtree: true});

export function mountModelOutput({disclosure, panel, requestId, callId}) {
  if (panel.modelViewer) return panel.modelViewer;
  panel.classList.add("shell-live-panel", "model-output-panel"); panel.setAttribute("aria-live", "off");
  const status = element("p", "Connecting…", "shell-live-status");
  const metadata = element("p", "", "shell-live-metadata");
  const explanation = element("p", "Provider output for debugging. Reasoning and partial tool calls are not verified answers or executed operations.", "shell-live-notice");
  const notice = element("p", "", "shell-live-notice");
  const selectShell = element("span", "", "chat-select-shell");
  const select = element("select", "", "chat-field-control"); select.setAttribute("aria-label", "Model output channel");
  for (const [value, label] of [["all", "All output"], ["reasoning", "Reasoning"], ["answer", "Answer"], ["tool", "Tool calls"]]) {
    const option = element("option", label); option.value = value; select.append(option);
  }
  selectShell.append(select);
  const pre = element("pre", "", "shell-live-transcript"); pre.tabIndex = 0;
  pre.setAttribute("aria-label", "Model output transcript");
  const empty = element("p", "Waiting for provider output…", "shell-live-empty");
  const actions = element("div", "", "shell-live-actions");
  const copy = element("button", "Copy output"), jump = element("button", "Jump to latest");
  const copied = window.SMTOCopyFeedback.bind(copy);
  const retry = element("button", "Reconnect"), download = element("a", "Download full capture");
  for (const button of [copy, jump, retry]) button.type = "button";
  const base = `/api/agent/trace/${encodeURIComponent(requestId)}/models/${encodeURIComponent(callId)}`;
  download.href = `${base}/download`; download.download = "model-output.txt";
  actions.append(selectShell, copy, jump, retry, download);
  panel.append(status, metadata, explanation, notice, actions, empty, pre);
  let source = null, reconnect = 0, clock = 0, frame = 0, attempt = 0;
  let cursor = 0, chunks = [], size = 0, omitted = false, following = true, disposed = false, ended = false;
  let info = {}, transport = "connecting", unavailable = false;
  const wanted = () => {
    if (disposed || document.hidden || !disclosure.isConnected) return false;
    for (let node = disclosure; node; node = node.parentElement)
      if (node.hidden || (node.tagName === "DETAILS" && !node.open)) return false;
    return true;
  };
  function preview() {
    const selected = chunks.filter(chunk => select.value === "all" || chunk.channel === select.value
      || (select.value === "tool" && chunk.channel.startsWith("tool_")));
    let channel = "", text = "";
    for (const chunk of selected) {
      if (select.value === "all" && channel !== chunk.channel) {
        channel = chunk.channel; text += `${text ? "\n\n" : ""}[${channel}]\n`;
      }
      text += chunk.text;
    }
    return text;
  }
  function renderStatus() {
    const counts = info.characters || {}, reasoning = counts.reasoning || 0;
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const elapsed = info.started_at ? Math.max(0, Math.floor(((info.ended_at ? Date.parse(info.ended_at) : Date.now()) - Date.parse(info.started_at)) / 1000)) : 0;
    const label = {generating: "Generating", completed: "Completed", failed: "Failed", cancelled: "Stopped", interrupted: "Interrupted"}[info.status] || "Loading";
    window.SMTONumberOdometer.render(status,
      `${label} · ${transport}${info.started_at ? ` · ${Math.floor(elapsed / 60)}m ${elapsed % 60}s` : ""}`);
    const parameters = info.parameters || {}, cap = parameters.max_completion_tokens ?? parameters.max_tokens;
    window.SMTONumberOdometer.render(metadata, [info.model, `${reasoning.toLocaleString()} reasoning characters`,
      `${total.toLocaleString()} total characters`,
      Number.isFinite(info.usage?.completion_tokens) ? `${info.usage.completion_tokens.toLocaleString()} generated tokens` : "",
      cap != null ? `Output cap: ${cap.toLocaleString()}` : "", info.finish_reason ? `Finish: ${info.finish_reason}` : "",
      info.error_kind].filter(Boolean).join(" · "));
    retry.hidden = ended || unavailable || !transport.includes("lost");
    download.hidden = unavailable; jump.hidden = following;
  }
  function render() {
    frame = 0; const text = preview(); pre.textContent = text; pre.hidden = !text; empty.hidden = Boolean(text);
    empty.textContent = unavailable ? "This call has no retained model output. Calls made before capture was added cannot be recovered."
      : ended ? "No text was captured for this channel. The provider may not expose reasoning."
        : "Waiting for provider output…";
    notice.hidden = !omitted;
    notice.textContent = "Earlier output is omitted from this preview. Download full capture to read everything retained.";
    if (following) pre.scrollTop = pre.scrollHeight;
    renderStatus();
  }
  const schedule = () => { if (!frame) frame = requestAnimationFrame(render); };
  function stop(message) {
    source?.close(); source = null; clearTimeout(reconnect); reconnect = 0;
    clearInterval(clock); clock = 0; transport = message; renderStatus();
  }
  async function failed() {
    stop("connection lost");
    if (!wanted() || ended) return;
    // EventSource hides HTTP status; a bounded status check distinguishes old uncaptured calls.
    if (!cursor) {
      try {
        const result = await fetch(base, {cache: "no-store"});
        await result.body?.cancel();
        if (result.status === 404) { unavailable = ended = true; stop("not captured"); render(); return; }
      } catch (_) { /* Reconnect remains available for transport failures. */ }
    }
    if (wanted() && !ended && attempt < 5)
      reconnect = setTimeout(() => { reconnect = 0; connect(); }, Math.min(1000 * 2 ** attempt++, 15000));
  }
  function connect() {
    if (!wanted() || source || reconnect || ended) return;
    const current = new EventSource(`${base}/stream?after=${cursor}`); source = current;
    transport = "connecting"; clock = setInterval(renderStatus, 1000); renderStatus();
    current.addEventListener("open", () => { if (source === current) { transport = "live"; renderStatus(); } });
    current.addEventListener("error", () => { if (source === current) void failed(); });
    current.addEventListener("model.output", event => {
      if (source !== current || !wanted()) return;
      try {
        const data = JSON.parse(event.data);
        if (data.request_id !== requestId || data.call_id !== callId) throw window.SMTOErrors.error("ui_state_stale");
        if (data.reset) { cursor = 0; chunks = []; size = 0; omitted = false; }
        for (const chunk of data.chunks || []) {
          if (!Number.isSafeInteger(chunk.seq) || typeof chunk.text !== "string" || typeof chunk.channel !== "string") throw window.SMTOErrors.error("ui_response_invalid");
          if (chunk.seq <= cursor) continue;
          cursor = chunk.seq; chunks.push(chunk); size += chunk.text.length;
        }
        while (size > PREVIEW_LIMIT && chunks.length) {
          const first = chunks[0], excess = size - PREVIEW_LIMIT;
          if (first.text.length <= excess) { size -= first.text.length; chunks.shift(); }
          else { first.text = first.text.slice(excess); size -= excess; }
          omitted = true;
        }
        info = data; attempt = 0; schedule();
      } catch (_) { void failed(); }
    });
    current.addEventListener("model.end", () => {
      if (source !== current) return;
      ended = true; stop("capture ended"); schedule();
    });
  }
  select.addEventListener("change", render);
  pre.addEventListener("scroll", () => { following = pre.scrollHeight - pre.scrollTop - pre.clientHeight < 32; jump.hidden = following; });
  jump.addEventListener("click", () => { following = true; render(); });
  copy.addEventListener("click", async () => {
    try {
      const response = await fetch(`${base}/copy?channel=${encodeURIComponent(select.value)}`, {cache: "no-store"});
      if (!response.ok) throw new Error("Output unavailable");
      await navigator.clipboard.writeText(await response.text()); copied();
    }
    catch (_) { copy.textContent = "Could not copy"; }
  });
  retry.addEventListener("click", () => { attempt = 0; clearTimeout(reconnect); reconnect = 0; connect(); });
  const viewer = {disclosure,
    reconcile() { if (!disclosure.isConnected) viewer.dispose(); else if (wanted()) connect(); else stop("suspended"); },
    suspend() { stop("suspended"); },
    dispose() { disposed = true; stop("closed"); cancelAnimationFrame(frame); viewers.delete(viewer); },
  };
  panel.modelViewer = viewer; viewers.add(viewer); render(); viewer.reconcile(); return viewer;
}
