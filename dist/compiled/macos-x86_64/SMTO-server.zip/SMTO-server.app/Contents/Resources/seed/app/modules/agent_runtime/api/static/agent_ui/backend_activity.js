/* Task execution is independent of HTTP traffic, connection health and CPU load. */
(() => {
  "use strict";
  const indicator = document.getElementById("connection-indicator");
  if (!indicator) return;
  let timer, staleTimer, request, inFlight, stopped = false;
  function duration(seconds) {
    seconds = Math.max(0, Math.floor(Number(seconds) || 0));
    return seconds >= 60 ? `${Math.floor(seconds / 60)}m ${seconds % 60}s` : `${seconds}s`;
  }
  function describeMaintenance(maintenance) {
    if (maintenance?.phase === 'saving') return `Saving · ${duration(maintenance.elapsed_seconds)}`;
    if (maintenance?.phase === 'cleanup') return `Cleaning up · ${duration(maintenance.elapsed_seconds)}`;
    if (maintenance?.phase === 'waiting') return maintenance.next_save_in_seconds > 0
      ? `Waiting to save · ${duration(maintenance.next_save_in_seconds)} before next automatic save`
      : 'Waiting for background maintenance';
    return '';
  }
  function show(state, maintenance = null, unresolvedJobs = 0) {
    indicator.dataset.execution = state;
    indicator.dataset.maintenance = maintenance?.active === true ? "running"
      : maintenance?.active === false ? "idle" : "unknown";
    indicator.dataset.unresolvedJobs = String(Number.isSafeInteger(unresolvedJobs) && unresolvedJobs > 0 ? unresolvedJobs : 0);
    indicator.dataset.maintenanceMessage = describeMaintenance(maintenance);
    window.dispatchEvent(new CustomEvent("smto:backend-activity", {detail: {state, maintenance}}));
  }
  async function refresh() {
    if (stopped || document.hidden) return;
    if (inFlight) return inFlight;
    clearTimeout(timer);
    const controller = new AbortController();
    request = controller;
    const timeout = setTimeout(() => controller.abort(), 3000);
    inFlight = (async () => {
      try {
        const response = await fetch("/api/agent/backend-activity", {
          cache: "no-store", signal: controller.signal,
        });
        if (!response.ok) throw new Error("Backend activity unavailable");
        const data = await response.json();
        if (stopped || controller.signal.aborted) return;
        clearTimeout(staleTimer);
        show(["idle", "active"].includes(data.state) ? data.state : "unknown", data.maintenance, data.unresolved_jobs);
        staleTimer = setTimeout(() => show("unknown"), 5000);
      } catch (_) {
        if (!stopped) show("unknown");
      } finally {
        clearTimeout(timeout);
        request = null; inFlight = null;
        if (!stopped && !document.hidden) timer = setTimeout(refresh, 2000);
      }
    })();
    return inFlight;
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { clearTimeout(timer); request?.abort(); }
    else void refresh();
  });
  window.addEventListener("pagehide", () => {
    stopped = true; clearTimeout(timer); clearTimeout(staleTimer); request?.abort(); show("unknown");
  });
  window.addEventListener("pageshow", () => { stopped = false; void refresh(); });
  window.SMTOBackendActivity = {refresh, describeMaintenance};
  show("unknown");
  void refresh();
})();
