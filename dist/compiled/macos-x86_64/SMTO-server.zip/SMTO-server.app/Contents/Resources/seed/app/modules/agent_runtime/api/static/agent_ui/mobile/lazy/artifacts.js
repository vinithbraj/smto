import "./advanced.js";
import "../../smto_markdown.js";
import "../../artifacts.js";
import {trackArtifactSources} from "../markdown.js";
import {api, state} from "../api.js";
export function attach(turn) {
  if (turn.disposed) return;
  trackArtifactSources(turn.root);
  if (!turn.artifacts) turn.artifacts = window.SMTOArtifacts.attach(turn.root, turn.id,
    turn.conversationId || state.conversationId, (url, options = {}) => api(url, options));
  window.SMTOArtifacts.hydrate(turn.root);
  turn.artifacts.update(turn.run?.artifact_summary);
  return turn.artifacts;
}
