/**
 * @file src/agent_runtime/api/static/agent_ui/app.js
 * @brief Compose the desktop Agent workspace around server-owned conversations, runs and policies.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities:
 * - Bind composer, navigation, model/settings controls, target selection, activity inspection
 *   and stream/timing projections into the desktop page.
 * Boundaries:
 * - The browser does not own scheduler admission, tool execution authority or completion
 *   evidence. Policy controls submit choices to server APIs.
 * Lifecycle:
 * - Bootstrap identity/settings, restore the selected conversation, submit or steer user input,
 *   and reconcile each running task's trace/events into its visible turn.
 * - Ordinary replies carry the displayed operation/Activity identity to the same request endpoint.
 * State:
 * - Page state tracks active request/conversation, navigation generation, timers, seen event IDs
 *   and pending submissions. Each turn owns its stream and duration timer.
 *   Shared session/draft modules own permitted browser persistence.
 * Security:
 * - OAuth and approval interactions use their protocol controls. UI gating and display
 *   metadata are not substitutes for server checks or redaction.
 * Collaborators:
 * - SMTOAgentUi and SMTOUiSession provide shared behavior; target, activity, stream,
 *   timing, queue and navigation modules attach controllers to stable DOM surfaces.
 * Public surface:
 * - The page IIFE owns event wiring and workspace state; retain SMTO globals and existing
 *   storage keys as compatibility interfaces.
 *
 * @see src/agent_runtime/api/static/agent_ui/index.html
 * @see src/agent_runtime/api/static/agent_ui/app.css
 * @see src/manual/content/architecture/26-ui-surfaces.md
 */
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const elements = {
    viewport: $("#conversation-viewport"),
    conversation: $("#conversation"),
    empty: $("#empty-state"),
    anchor: $("#scroll-anchor"),
    composer: $("#composer"),
    input: $("#prompt-input"),
    submit: $("#submit-button"),
    mode: $("#mode-select"),
    model: $("#model-select"),
    newChat: $("#new-chat-button"),
    drawerNewChat: $("#drawer-new-chat"),
    historyToggle: $("#history-toggle"),
    historyClose: $("#history-close"),
    historyDrawer: $("#history-drawer"),
    historyList: $("#history-list"),
    scrim: $("#drawer-scrim"),
    connection: $("#connection-indicator"),
    themeToggle: $("#theme-toggle"),
    moreToggle: $("#more-toggle"),
    moreMenu: $("#more-menu"),
    composerOptions: $("#composer-options-dropdown"),
    toast: $("#toast"),
    contextMeter: $("#context-meter"),
    generateProse: $("#generate-prose"),
    taskContract: $("#task-contract-compilation"),
  };

  const STORAGE = {
    conversation: "smto.agentUi.conversationId",
  };
  const session = window.SMTOUiSession;
  const Core = window.SMTOAgentUi;
  const confirmationSubmissions = new Set();
  const clarificationSubmissions = new Set();
  const TERMINAL_STATUSES = new Set([
    "completed", "failed", "cancelled", "interrupted",
    "awaiting_confirmation", "awaiting_clarification", "awaiting_resource_reconciliation",
  ]);
  const state = {
    conversationId: null,
    requestId: null,
    running: false,
    currentTurn: null,
    turns: new Map(),
    seenEventIds: new Set(),
    promptHistory: [],
    promptHistoryLimit: 100,
    promptHistoryNavigation: null,
    settings: {},
    settingsLoaded: false,
    settingsVersion: 0,
    generateProseSaving: false,
    taskContractSaving: false,
    waveletTimelineSaving: false,
    activeModelName: "",
    modelsLoading: false,
    toastTimer: null,
    submitting: false,
    composerBusy: false,
    steerRequestId: null,
    pendingSteer: null,
    activeEnvelope: null,
    traceStatus: "",
    navigationVersion: 0,
    preparingDirect: false,
    booting: true,
    executionReady: false,
    identityReady: false,
    historyLoad: null,
  };

  const promptSchedules = window.SMTOPromptSchedule.create({notify: showToast,
    executionSnapshot: () => targetSelector.submissionSnapshot()});
  $("#schedule-draft").innerHTML = window.SMTOPromptSchedule.icon();
  $("#schedule-draft").addEventListener("click", () => { if (!currentInteraction() && !state.steerRequestId) void promptSchedules.open(elements.input.value, "", {task_contract_integrity_guard_enabled: window.SMTOAgentChecks.integrityForRequest(state.conversationId)}); });

  let composerProfile = null, commandPalette = null;
  let restoredComposerTarget = null;
  let modelOptions = [];
  let draftCache = null, promptRecall = null, mentionPalette = null, composerBrowsing = null, promptNavigator = null;
  const targetSelector = window.SMTOTargetSelector.create({
    apiJson, root: $("#target-selector"), summary: $("#target-summary"), runBadge: $("#active-run-target"), currentRun,
    isSteering: () => Boolean(state.steerRequestId) || !composerProfile?.ready(), notify: showToast,
    onChanged: edited => {
      if (edited && composerProfile?.ready()) {
        const scope = targetSelector.gatewaySelection();
        void composerProfile.patch({gateway_id: scope.primary_gateway_id || null,
          gateway_selection: scope.gateway_ids.length ? scope : null});
      }
      void capabilityPolicy.targetChanged().catch(error => showToast(error.message || "Could not refresh target capabilities"));
      updateSubmitState();
      window.SMTONative?.renderTaskActions();
    },
  });
  const activity = window.SMTORunActivity;
  const activityPresentation = window.SMTOActivityPresentation;
  const actionIcons = window.SMTOActionIcons;
  const thinkingAnimations = window.SMTOThinkingAnimations;
  const streamActivityHistory = window.SMTOStreamActivity.create();
  const streamActivityGraph = window.SMTOStreamActivity.createRenderer(
    $("#llm-stream-activity"), streamActivityHistory);
  const timing = window.SMTOPerformanceTiming;
  const conversationTiming = window.SMTOConversationTiming.create({
    root: $("#conversation-timing"), apiJson,
    now: () => window.SMTOStreamActivity.now(streamActivityHistory),
    changed: () => taskDisclosure.refresh(),
  });
  const timingView = window.SMTOTimingView.create($("#llm-stream-activity"),
    () => window.SMTOStreamActivity.now(streamActivityHistory));
  let streamFreshnessTimer, activityClockRequest;
  let connectionTitle = elements.connection.title;
  const runActivityRoot = $("#run-activity");
  runActivityRoot.querySelector(".activity-primary").prepend(thinkingAnimations.create());
  let observedTaskStatus = null;
  const taskStatusObserver = typeof IntersectionObserver === "function"
    ? new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (entry.target === observedTaskStatus) {
          runActivityRoot.dataset.traceStatusVisible = String(entry.isIntersecting);
        }
      }
    }, {root: elements.viewport}) : null;

  function observeTaskActivityStatus() {
    const status = state.currentTurn?.work.status;
    const target = status && !status.hidden ? status : null;
    if (target === observedTaskStatus) return;
    taskStatusObserver?.disconnect();
    observedTaskStatus = target;
    runActivityRoot.dataset.traceStatusVisible = "false";
    if (target) taskStatusObserver?.observe(target);
  }

  function synchronizeActivityClock() {
    if (activityClockRequest) return activityClockRequest;
    // Reuse the existing server timestamp; CPU/GPU measurements never enter the
    // receipt graph. Resolve before trace replay, even when viewing remotely.
    activityClockRequest = apiJson("/api/agent/server-activity", {signal: AbortSignal.timeout(3000)})
      .then(snapshot => window.SMTOStreamActivity.syncClock(
        streamActivityHistory, snapshot.generated_at_ms))
      .catch(() => {})
      .finally(() => { activityClockRequest = null; });
    return activityClockRequest;
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) void synchronizeActivityClock();
  });
  window.addEventListener("pageshow", event => {
    if (event.persisted) void synchronizeActivityClock();
  });
  function syncTraceCursor(turn, createdAt) {
    if (!turn || !createdAt) return;
    if (turn.traceCreatedAt !== createdAt) {
      if (turn.traceCreatedAt) {
        turn.historyLoader?.reset();
        window.SMTOProseActivity.resetAnswers(turn.work.items);
        turn.archivedAnswers = null;
        turn.agentChecksSnapshot = null;
        turn.actionRenderKey = null;
      }
      // A restored transport can restart its cursor while retaining the same run.
      turn.lastEventId = 0;
      turn.activity.sequence = 0;
      turn.previewEventId = 0;
    }
    turn.traceCreatedAt = createdAt;
  }
  function renderActivity() {
    clearTimeout(streamFreshnessTimer);
    const freshness = window.SMTOUiUpdates.freshness();
    const turn = state.currentTurn;
    if (turn?.replyResume?.pending) turn.activity.resuming = true;
    syncAnswerState(turn);
    if (turn) turn.work.root.dataset.running = String(["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status));
    window.SMTOProgressNarration.refresh(turn);
    timingView.select(turn?.timing || null);
    const resolved = activity.render(runActivityRoot, $("#run-activity-announcement"),
      turn?.historical && activity.terminal.has(turn.activity.status) ? null : turn?.activity,
      {freshness, connection: window.SMTOUiUpdates.state(),
        showReconciliation: false});
    streamActivityGraph.update(Boolean(turn?.activity.inference && !turn.activity.stopping));
    if (resolved.receiving) {
      streamFreshnessTimer = setTimeout(renderActivity,
        Math.max(1, Math.min(activity.streamFreshnessMs,
          turn.activity.streamAt + activity.streamFreshnessMs - window.SMTOStreamActivity.now(streamActivityHistory))));
    }
    if (turn) renderTaskActivityStatus(turn, resolved.kind === "idle" ? activity.resolve(turn.activity) : resolved);
    observeTaskActivityStatus();
    window.SMTONative.renderStop(currentRun());
  }

  function renderTaskActivityStatus(turn, resolved = activity.resolve(turn.activity)) {
    taskDisclosure.refresh();
    turn.historyLoader?.update(turn.activity.status);
    void turn.refreshWorkflow?.();
    const live = resolved.kind !== "terminal" && resolved.kind !== "idle";
    turn.work.status.hidden = !live;
    turn.work.statusDetail.setAttribute("aria-live", "off");
    const text = live ? resolved.label : "", heading = live ? "Activity" : resolved.label;
    activity.renderStatus(turn.work.status, {...resolved, label: text}, turn.work.statusLabel);
    activity.renderDetail(turn.work.statusDetail, live ? resolved : {});
    if (!turn.waitControls && turn.requestId) {
      turn.waitControls = window.SMTOWaitControls.create({requestId: turn.requestId,
        submit: (id, payload) => apiJson(`/api/agent/native/${encodeURIComponent(id)}/wait/control`, {
          method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)}),
        refresh: () => window.SMTOSelectedConversation.invalidate(), notify: showToast});
      turn.work.status.append(turn.waitControls.root);
    }
    turn.waitControls?.update(turn.activity);
    if (turn.work.label.textContent !== heading) turn.work.label.textContent = heading;
  }
  const capabilityPolicy = window.SMTOCapabilityPolicy.create({
    apiJson, mode: () => elements.mode.value, gatewayId: () => targetSelector.gatewayId(),
    button: $("#capability-button"), chips: $("#capability-chips"), notify: showToast,
    quickButton: $("#capability-quick-button"), scopeSelect: $("#capability-scope"),
    onDraftChanged: (edited = true) => edited ? draftCache?.touch(true) : draftCache?.flush(),
  });

  const runtimeGuards = window.SMTOCompletionHandling.conversation({
    composerSettings: () => composerProfile?.current() || {},
    apiJson, conversationId: () => state.conversationId, requestId: () => state.requestId, notify: showToast,
    onDraftChanged: () => draftCache?.touch(true),
    currentRetained: () => {
      const turn = state.currentTurn, saved = turn?.completionDecision;
      return saved?.feedback?.check_id === "completion.strict_final_response_structure"
        && saved.feedback.enabled === true ? {requestId: turn.requestId, decisionId: saved.decision_id, turn} : null;
    },
    reconcile: reloadRetainedFinal,
  });
  const permissionPolicy = window.SMTOPermissionPolicy.create({
    apiJson, mode: () => elements.mode.value,
    button: $("#permission-button"), chips: $("#permission-chips"), notify: showToast,
    presetSelect: $("#permission-preset"), scopeSelect: $("#permission-scope"),
    onDraftChanged: (edited = true) => edited ? draftCache?.touch(true) : draftCache?.flush(),
    pendingApproval: () => currentRun().status === "awaiting_confirmation" ? currentRun().request_id : null,
    approvePolicy: async (requestId, scope, policy, expected_revision) => {
      const card = state.turns.get(requestId)?.actionArea.querySelector(".action-card") || document.createElement("section");
      if (!await submitConfirmation(requestId, policy.mode === "deny" ? "deny" : "approve", card, {scope, policy, expected_revision})) {
        throw window.SMTOErrors.error("ui_permission_save_failed");
      }
    },
  });

  const behaviorEffort = window.SMTOBehaviorEffort.create({
    select: $("#behavior-effort"), apiJson, changed: () => { void composerProfile.patch({behavior_effort: behaviorEffort.value()}); },
  });
  const carryForwardControl = window.SMTOContextCarryForward.create({
    onChange: value => void composerProfile.patch({context_carry_forward: value}),
  });
  $("#context-carry-forward-control").append(carryForwardControl);
  const thinkingToggle = window.SMTOComposerThinking.create({
    button: $("#thinking-toggle"), reset: $("#thinking-reset"),
    quickButton: $("#thinking-quick-toggle"),
    budget: $("#thinking-budget"), budgetValue: $("#thinking-budget-value"),
    budgetHelp: $("#thinking-budget-help"),
    thinkingTokens: $("#thinking-budget-tokens"), outputBudget: $("#output-budget"),
    outputTokens: $("#output-budget-tokens"), outputReset: $("#output-budget-reset"),
    outputHelp: $("#output-budget-help"),
    profile: () => composerProfile?.current() || {}, ready: () => composerProfile?.ready(),
    patch: changes => composerProfile.patch(changes), disabled: () => Boolean(state.steerRequestId),
  });
  let parallelCatalog = null, parallelVersion = 0;
  const parallelToggle = document.querySelector("#parallel-execution");
  async function renderParallel() {
    const version = ++parallelVersion, cid = state.conversationId;
    parallelToggle.disabled = true;
    try {
      const catalog = await apiJson(`/api/agent/parallel-execution${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`);
      if (version !== parallelVersion || cid !== state.conversationId) return;
      parallelCatalog = catalog;
      const draft = window.SMTOAgentChecks.parallelPolicyForRequest(cid);
      parallelToggle.checked = (draft || composerProfile?.policy("parallel_execution_policy") || catalog.parallel_execution_policy).enabled;
      const source = draft ? "prompt" : !cid && composerProfile?.policy("parallel_execution_policy") ? "conversation" : catalog.parallel_execution_source;
      document.querySelector("#parallel-execution-source").textContent = source === "global" ? "Inherited from Global"
        : source === "product_default" ? "Product default" : `Overridden for this ${source}`;
      parallelToggle.disabled = !composerProfile?.ready();
    } catch (error) { showToast(error); }
  }
  parallelToggle.addEventListener("change", () => {
    if (!parallelCatalog) return;
    const policy = composerProfile.policy("parallel_execution_policy") || parallelCatalog.parallel_execution_policy;
    void composerProfile.setPolicy("parallel_execution_policy", {...policy, enabled: parallelToggle.checked}).then(renderParallel).catch(error => showToast(error));
  });
  elements.composerOptions.addEventListener("toggle", () => { if (elements.composerOptions.open) void renderParallel(); });
  window.addEventListener("parallel-policy-changed", () => void renderParallel());
  let backgroundCatalog = null, backgroundVersion = 0;
  const backgroundToggle = document.querySelector("#background-activities");
  async function renderBackground() {
    const version = ++backgroundVersion, cid = state.conversationId;
    backgroundToggle.disabled = true;
    try {
      const catalog = await apiJson(`/api/agent/background-activities${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`);
      if (version !== backgroundVersion || cid !== state.conversationId) return;
      backgroundCatalog = catalog;
      const draft = window.SMTOAgentChecks.backgroundPolicyForRequest(cid);
      backgroundToggle.checked = (draft || composerProfile?.policy("background_activity_policy") || catalog.background_activity_policy).enabled;
      const source = draft ? "prompt" : !cid && composerProfile?.policy("background_activity_policy") ? "conversation" : catalog.background_activity_source;
      document.querySelector("#background-activities-source").textContent = source === "global" ? "Inherited from Global"
        : source === "product_default" ? "Product default" : `Overridden for this ${source}`;
      backgroundToggle.disabled = !composerProfile?.ready();
    } catch (error) { showToast(error); }
  }
  backgroundToggle.addEventListener("change", () => {
    if (!backgroundCatalog) return;
    const policy = composerProfile.policy("background_activity_policy") || backgroundCatalog.background_activity_policy;
    void composerProfile.setPolicy("background_activity_policy", {...policy, enabled: backgroundToggle.checked}).then(renderBackground).catch(error => showToast(error));
  });
  elements.composerOptions.addEventListener("toggle", () => { if (elements.composerOptions.open) void renderBackground(); });
  window.addEventListener("background-policy-changed", () => void renderBackground());
  let dependencyCatalog = null, dependencyVersion = 0;
  const dependencyToggle = document.querySelector("#dependency-scheduling");
  async function renderDependency() {
    const version = ++dependencyVersion, cid = state.conversationId;
    dependencyToggle.disabled = true;
    try {
      const catalog = await apiJson(`/api/agent/dependency-scheduling${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`);
      if (version !== dependencyVersion || cid !== state.conversationId) return;
      dependencyCatalog = catalog;
      const draft = window.SMTOAgentChecks.dependencyPolicyForRequest(cid);
      dependencyToggle.checked = (draft || composerProfile?.policy("dependency_scheduling_policy") || catalog.dependency_scheduling_policy).enabled;
      const source = draft ? "prompt" : !cid && composerProfile?.policy("dependency_scheduling_policy") ? "conversation" : catalog.dependency_scheduling_source;
      document.querySelector("#dependency-scheduling-source").textContent = source === "global" ? "Inherited from Global"
        : source === "product_default" ? "Product default" : `Overridden for this ${source}`;
      dependencyToggle.disabled = !composerProfile?.ready();
    } catch (error) { showToast(error); }
  }
  dependencyToggle.addEventListener("change", () => {
    if (!dependencyCatalog) return;
    const policy = composerProfile.policy("dependency_scheduling_policy") || dependencyCatalog.dependency_scheduling_policy;
    void composerProfile.setPolicy("dependency_scheduling_policy", {...policy, enabled: dependencyToggle.checked}).then(renderDependency).catch(error => showToast(error));
  });
  elements.composerOptions.addEventListener("toggle", () => { if (elements.composerOptions.open) void renderDependency(); });
  window.addEventListener("dependency-policy-changed", () => void renderDependency());
  elements.generateProse.addEventListener("change", () => {
    void composerProfile.patch({generate_prose: elements.generateProse.checked});
  });
  function renderIntegrityGuard() {
    const view = window.SMTOAgentChecks.integrityView(state.conversationId, composerProfile?.current() || {});
    const toggle = $("#task-contract-integrity-guard");
    toggle.checked = view.enabled; toggle.disabled = !composerProfile?.ready() || view.disabled;
    $("#task-contract-integrity-guard-source").textContent = window.SMTOAgentChecks.integrityForRequest(state.conversationId) === undefined ? "Saved for this conversation" : view.source;
    $("#task-contract-integrity-guard-help").textContent = view.help;
    $("#task-contract-integrity-guard-reset").disabled = window.SMTOAgentChecks.integrityForRequest(state.conversationId) === undefined;
  }
  $("#task-contract-integrity-guard").addEventListener("change", event => {
    void composerProfile.patch({task_contract_integrity_guard_enabled: event.target.checked});
    draftCache?.touch(true);
  });
  $("#task-contract-integrity-guard-reset").addEventListener("click", () => {
    window.SMTOAgentChecks.setIntegrityDraft(state.conversationId, null); draftCache?.touch(true);
  });
  window.addEventListener("task-contract-integrity-changed", renderIntegrityGuard);
  elements.composerOptions.addEventListener("toggle", () => { if (elements.composerOptions.open) renderIntegrityGuard(); });
  elements.taskContract.addEventListener("change", () => {
    void composerProfile.patch({task_contract_compilation_enabled: elements.taskContract.checked});
  });
  $("#activity-details-toggle").addEventListener("click", () => {
    const prose = window.SMTOProseActivity;
    prose.setExpanded(state.conversationId, !prose.preference(state.conversationId));
    prose.renderToggle($("#activity-details-toggle"), state.conversationId);
  });
  const profileStatus = document.createElement("div");
  profileStatus.setAttribute("role", "status"); profileStatus.setAttribute("aria-live", "polite");
  profileStatus.id = "composer-profile-status"; elements.composer.prepend(profileStatus);
  function renderProfileModel() {
    const profile = composerProfile?.current();
    if (!profile || profile.loading) return;
    const saved = profile.llm_model || "";
    const options = modelOptions.map(option => new Option(option.label || option.value, option.value));
    if (!modelOptions.some(option => option.value === saved)) options.unshift(new Option(`Model unavailable · ${saved || "Choose a model"}`, saved));
    const current = Array.from(elements.model.options);
    if (current.length !== options.length || options.some((option, index) =>
      option.value !== current[index].value || option.textContent !== current[index].textContent)) elements.model.replaceChildren(...options);
    elements.model.value = saved; state.activeModelName = saved;
  }
  function composerProblem() {
    if (!composerProfile?.ready()) return composerProfile?.current().error || "Loading conversation settings…";
    if (composerProfile.current().policyPending) return "Saving conversation policy…";
    if (composerProfile.current().error && !composerProfile.current().unsynced) return composerProfile.current().error;
    if (!modelOptions.some(option => option.value === composerProfile.current().llm_model)) return "Saved model is unavailable. Select an available model.";
    return targetSelector.unavailable();
  }
  composerProfile = window.SMTOComposerProfile.create({apiJson, notify: showToast, onMissing: () => void reconcileMissingConversation(), changed: profile => {
    elements.composer.toggleAttribute("data-profile-loading", profile.loading);
    elements.composer.setAttribute("aria-busy", String(Boolean(profile.loading)));
    profileStatus.replaceChildren();
    if (profile.loading) {
      profileStatus.innerHTML = `<svg class="composer-submission-progress" viewBox="0 0 24 12" aria-hidden="true" focusable="false">
        <path d="M-12 6q3-6 6 0t6 0t6 0t6 0t6 0t6 0t6 0t6 0" />
      </svg><span class="sr-only">Loading conversation settings…</span>`;
    } else {
      profileStatus.append(document.createTextNode(profile.error || (profile.unsynced ? "Saving conversation settings…" : "")));
    }
    if (profile.error) {
      const retry = document.createElement("button"); retry.type = "button"; retry.textContent = "Retry settings";
      retry.onclick = () => void composerProfile.retry().catch(error => showToast(error)); profileStatus.append(retry);
    }
    if (profile.loading || !profile.agent_mode) {
      elements.model.replaceChildren(new Option("Model", ""));
      if (restoredComposerTarget !== "") {
        restoredComposerTarget = ""; targetSelector.restoreDraftState({});
      }
    } else {
      elements.mode.value = window.SMTOComposerProfile.modeValue(profile); behaviorEffort.restore(profile.behavior_effort);
      carryForwardControl.setValue(profile.context_carry_forward, profile.context_carry_forward_default); renderProfileModel();
      // Persisted target intent fails closed; registry refresh cannot redirect it.
      const scope = profile.gateway_selection || {schema_version: 1, gateway_ids: profile.gateway_id ? [profile.gateway_id] : [], primary_gateway_id: profile.gateway_id || ""};
      const targetKey = JSON.stringify([scope, profile.gateway_label_hint]);
      if (targetKey !== restoredComposerTarget) {
        restoredComposerTarget = targetKey;
        targetSelector.restoreDraftState({schema_version: 2, gateway_selection: scope, gateways: scope.gateway_ids.map(id =>
          ({gateway_id: id, gateway_label: id === profile.gateway_id ? profile.gateway_label_hint || id : id, gateway_locality: "unknown"}))});
      }
      capabilityPolicy.modeChanged(); permissionPolicy.modeChanged();
    }
    renderGenerateProse(); renderTaskContract(); updateSubmitState();
  }});


  /** Mount implementation choices only for the active server-recognized Plan artifact. */

  function renderPlanAction(turn, trace) {
    return window.SMTOPlanMode.mount(turn.actionArea, trace, {
      conversationId: turn.conversationId || state.conversationId, requestId: turn.requestId, apiJson,
      active: () => turn.article.isConnected && (turn.conversationId || state.conversationId) === state.conversationId,
      notify: showToast, stay: async () => {
        await composerProfile.selectMode("plan");
        if (composerProfile.current().error) throw new Error(composerProfile.current().error);
        elements.input.focus();
      },
      accepted: async result => {
        await openConversation(result.conversation_id);
        if (state.conversationId === result.conversation_id) showPlanTask(result.task, {fresh: true});
        elements.input.focus();
      },
    });
  }

  function renderApprovedPlan(turn, source) {
    if (turn.prompt !== "Implement the plan.") return;
    window.SMTOPlanMode.quote(turn.user, source, {
      apiJson, renderMarkdown: (root, text) => window.SMTOMarkdown.render(root, text),
      active: () => turn.user.isConnected && turn.conversationId === state.conversationId,
    });
  }

  function showPlanTask(task, {fresh = false} = {}) {
    if (!task || task.conversation_id !== state.conversationId) return;
    let turn = [...state.turns.values()].find(item => item.taskId === task.task_id && !item.parentRequestId)
      || provisionalTurns.get(task.client_submission_id);
    if (!turn?.article.isConnected) {
      turn = createTurn(task.prompt, "", {taskId: task.task_id});
      turn.article.dataset.submissionId = task.client_submission_id;
      provisionalTurns.set(task.client_submission_id, turn);
    }
    if (!turn.requestId) turn.work.label.textContent = ({queued: "Queued…", cancelled: "Cancelled", failed: "Failed"})[task.status] || "Starting…";
    turn.messageTimes?.user(task.created_at);
    window.SMTOTaskMode.render(turn.article, task);
    renderApprovedPlan(turn, task);
    if (fresh) taskDisclosure.submitted(turn.article);
  }

  function commandView() {
    const run = currentRun();
    return {...run, request_id: state.requestId || null,
      snapshot: run.request_id === state.requestId ? run.snapshot || {} : {},
      conversation_id: state.conversationId, navigation: state.navigationVersion,
      submitting: state.submitting || state.composerBusy,
      running: state.running || state.submitting};
  }
  const commandStatus = window.SMTOCommandStatus.create({
    input: elements.input, host: elements.composer.parentElement, getView: commandView, notify: showToast,
  });
  const commandContext = action => window.SMTOCommandProtocol.context(action, "desktop");
  const commandActions = window.SMTOCommandActions.create({
    conversation: elements.conversation, input: elements.input, statusPanel: commandStatus,
    getView: commandView, showToast, setConnection,
    onResult: () => { showConversation(); scrollToBottom(); },
    beforeRestart: () => { draftCache?.flush(); closeTraces(); },
    operations: {
      new_conversation: () => clearConversation(),
      stop_current_run: action => window.SMTONative.cancelCurrent(action.request_id, {commandContext: commandContext(action)}),
      pause_current_run: action => window.SMTONative.pauseCurrent(action.request_id, commandContext(action)),
      resume_current_run: action => window.SMTONative.resumeCurrent(action.request_id, commandContext(action)),
      compact_current_run: action => window.SMTONative.compactCurrent(action.request_id, commandContext(action)),
      request_conversation_delete: action => historyManagement.deleteCurrent(action.conversation_id, elements.input),
      open_history: () => openHistory(),
      open_settings: () => { draftCache.flush(); location.assign("/settings"); },
      open_queue: () => promptQueue.open(),
      clear_queue: action => promptQueue.clear(action.conversation_id),
      open_trace: action => {
        const turn = state.turns.get(action.request_id);
        if (!turn) { showToast("No current run trace is available."); return; }
        turn.work.root.hidden = false; turn.work.root.open = true;
        turn.work.root.scrollIntoView({block: "nearest"}); turn.work.root.querySelector("summary")?.focus();
      },
    },
  });
  const slashCommands = window.SMTOSlashCommands.create({
    input: elements.input, composer: elements.composer, getView: commandView,
    present: (...args) => commandPalette ? commandPalette.present(...args, commandActions.present) : commandActions.present(...args), showToast,
    onInput: (edited = true) => { resizeInput(); updateSubmitState(); if (edited) draftCache?.touch(); },
    onStart: () => { commandPalette?.submitting(); return draftCache?.beginSubmission(); },
    onRejected: pending => draftCache?.recover(pending),
  });

  const provisionalTurns = new Map();
  const startupTimings = new Map();
  // Browser-only monotonic segments; never compare these with server clocks.
  window.SMTOStartupTimings = () => Array.from(startupTimings.values(), item => ({...item}));
  function submissionTiming(id, phase) {
    if (!startupTimings.has(id)) {
      if (startupTimings.size >= 64) startupTimings.delete(startupTimings.keys().next().value);
      startupTimings.set(id, {client_submission_id: id});
    }
    startupTimings.get(id)[phase] = performance.now();
    const value = startupTimings.get(id);
    if (value.ack_received) value.submit_to_ack_ms = value.ack_received - value.submit_entered;
    if (value.stream_attached) value.submit_to_stream_attached_ms = value.stream_attached - value.submit_entered;
  }
  const promptQueue = window.SMTOPromptQueue.create({
    navigation: () => provisionalTurns.clear(),
    reconciled: lane => {
      for (const [id, turn] of provisionalTurns) {
        if (!turn.article.isConnected) { provisionalTurns.delete(id); continue; }
        const task = lane.tasks.find(task => task.client_submission_id === id);
        // A queue response started before acknowledgement can omit this task.
        // Only an explicit terminal task state removes an accepted placeholder.
        if (task && !turn.requestId) {
          window.SMTOTaskMode.render(turn.article, task);
          turn.user.textContent = task.prompt;
          renderApprovedPlan(turn, task);
          turn.messageTimes?.user(task.created_at);
          if (task.status === "removed" || task.status === "cancelled" && !task.has_approved_plan) {
            const group = turn.activityGroup; turn.article.remove(); cleanupActivityGroup(group); provisionalTurns.delete(id); scheduleActivityBoundaries();
          }
        }
      }
    },
    submissionTiming,
    submitting: (snapshot, id, prior) => {
      commandPalette?.submitting();
      submissionTiming(id, "submit_entered");
      const turn = prior?.article.isConnected ? prior : createTurn(snapshot.prompt);
      window.SMTOTaskMode.render(turn.article, snapshot);
      turn.submissionId = id; turn.article.dataset.submissionId = id;
      turn.work.label.textContent = "Submitting…";
      provisionalTurns.set(id, turn);
      if (!prior) taskDisclosure.submitted(turn.article);
      submissionTiming(id, "optimistic_rendered");
      requestAnimationFrame(() => {
        if (!turn.article.isConnected) return;
        composerBrowsing?.scrollToBottom("instant", true);
        // Composer geometry can leave a short first turn above the viewport's
        // top edge after scrolling to the bottom. Keep the submitted text visible.
        turn.user.scrollIntoView({block: "nearest", behavior: "instant"});
      });
      return turn;
    },
    submissionAccepted: (turn, response) => {
      if (!turn?.article.isConnected) return;
      turn.messageTimes?.user(response.task?.created_at);
      turn.conversationId = response.conversation_id || turn.conversationId;
      turn.work.root.dataset.activityConversation = turn.conversationId || "";
      turn.work.root.open = window.SMTOProseActivity.preference(turn.conversationId, turn.work.root.open);
      setTurnActivityLineage(turn, {...response.task, task_id: response.task_id});
      turn.work.label.textContent = response.status === "queued" ? "Queued…" : "Starting…";
      if (response.current_request_id) turn.bindRequest(response.current_request_id);
    },
    submissionFailed: (turn, error, definite) => {
      commandPalette?.failed(error);
      if (definite) {
        if (turn) { const group = turn.activityGroup; turn.article.remove(); cleanupActivityGroup(group); }
        scheduleActivityBoundaries();
        if (turn) provisionalTurns.delete(turn.submissionId);
        const conflict = error.payload?.detail || error.payload;
        if (conflict?.code === "composer_state_changed") {
          void window.SMTONative.refreshTaskSnapshot(conflict.interaction.request_id).then(() => {
            const interaction = currentInteraction();
            if (interaction) void focusInteraction(interaction);
          });
        }
      } else if (turn) {
        turn.work.label.textContent = "Couldn’t confirm submission · Retry with the same prompt.";
      }
    },
    root: $("#prompt-queue"), notify: showToast, apiJson,
    current: currentRun, conversationId: () => state.openingConversation ? null : state.conversationId,
    attachedRequestId: () => state.requestId,
    targetUnavailable: snapshot => targetSelector.unavailable(snapshot),
    envelope: id => state.activeEnvelope?.request_id === id ? state.activeEnvelope.snapshot : null,
    changed: updateSubmitState, openConversation,
    selectActive: requestIds => {
      const turns = requestIds.map(id => state.turns.get(id)).filter(turn => turn?.article.isConnected);
      // Boot can restore the newest run before the lane supplies its older siblings.
      for (let index = 1; index < turns.length; index++) {
        const previous = turns[index - 1].activityGroup || turns[index - 1].article;
        const next = turns[index].activityGroup || turns[index].article;
        if (previous !== next && previous.parentElement === next.parentElement
          && previous.compareDocumentPosition(next) & Node.DOCUMENT_POSITION_PRECEDING) previous.after(next);
      }
      if (!state.currentTurn || !activity.terminal.has(state.currentTurn.activity.status)) return;
      const turn = turns.find(turn => !activity.terminal.has(turn.activity.status));
      if (!turn) return;
      state.currentTurn = turn;
      state.requestId = turn.requestId;
      state.activeEnvelope = turn.envelope || null;
      state.traceStatus = turn.activity.status;
      setRunning(["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status));
      void window.SMTONative?.refresh();
    },
    accepted: async (response, snapshot) => {
      // A successfully admitted composer prompt is immediately part of recall history.
      // Do not wait for the queued task to start or its final trace to settle: durable
      // conversation tasks may remain queued for an arbitrary amount of time.
      rememberPrompt(snapshot.prompt);
      promptRecall?.update();
      composerProfile.accepted(response, snapshot);
      window.SMTOAgentChecks.setIntegrityDraft(snapshot.conversation_id, null);
      window.SMTOConversationWidth.accepted(response.conversation_id);
      state.conversationId = response.conversation_id;
      selectedConversation.select(state.conversationId);
      contextMeter.activate(state.conversationId);
      conversationTiming.activate(state.conversationId);
      syncConversationUrl();
      writeStorage(STORAGE.conversation, state.conversationId || "");
      draftCache.rebind(draftScope());
      showConversation();
      commandPalette?.accepted(response);
      void runtimeGuards.requestAccepted(snapshot).catch(() => showToast("Task accepted. Agent Checks could not refresh."));
    },
    recoverAccepted: async (snapshot, response, trace) => {
      if (response.conversation_id && response.conversation_id !== state.conversationId) {
        await openConversation(response.conversation_id, {excludeRequestId: response.request_id, internal: true, keepCapabilityPolicy: true});
      }
      const navigationVersion = state.navigationVersion;
      let native = null;
      if (activity.terminal.has(response.status)) {
        // Terminal lane entries already belong to the saved history window.
        // Let that window mount them instead of creating a duplicate live turn.
        await state.historyLoad;
        if (navigationVersion !== state.navigationVersion) return;
        const saved = state.turns.get(response.request_id);
        if (saved?.historical && activity.terminal.has(saved.activity.status)) return;
      }
      const provisional = provisionalTurns.get(snapshot.client_submission_id);
      let attached = state.turns.get(response.request_id);
      if (!attached && provisional?.article.isConnected) {
        provisional.bindRequest(response.request_id); attached = provisional;
        provisionalTurns.delete(snapshot.client_submission_id);
      }
      if (attached === provisional) provisionalTurns.delete(snapshot.client_submission_id);
      if (!attached) {
        attached = createTurn(snapshot.prompt, response.request_id);
        attached.historical = true;
        lazyActivity(attached);
      }
      window.SMTOTaskMode.render(attached.article, response.task, snapshot);
      if (attached.historical) {
        state.currentTurn = attached; state.requestId = response.request_id;
        const restored = await loadFinalTrace(response.request_id, attached);
        if (navigationVersion !== state.navigationVersion || !attached.article.isConnected) return;
        if (!restored || activity.terminal.has(activity.userStatus(restored))) return;
      }
      attached.work.label.textContent = "Starting…";
      if (!attached.source) connectTrace(response.request_id, `/api/agent/stream/${response.request_id}`, attached, attached.lastEventId || 0);
      if (attached.submissionId) submissionTiming(attached.submissionId, "stream_attached");
      try { native = await apiJson(`/api/agent/native/${encodeURIComponent(response.request_id)}`); }
      catch (error) { if (error.status !== 404) showToast("Task started. Controls could not refresh."); }
      if (response.conversation_id !== state.conversationId || navigationVersion !== state.navigationVersion) return;
      const previousTurn = state.currentTurn;
      if (previousTurn?.requestId && previousTurn.requestId !== response.request_id && !previousTurn.source) {
        // Detached predecessors still need their final summary; live siblings keep observing.
        void loadFinalTrace(previousTurn.requestId, previousTurn);
      }
      const continuation = Boolean(native?.continuation) && !native?.followup_prompt;
      const turn = state.turns.get(response.request_id) || createTurn(native?.followup_prompt || (continuation ? "" : snapshot.prompt), response.request_id, {continuation});
      if (native) { setTurnActivityLineage(turn, native); setTurnAttemptPrompt(turn, native); }
      if (native && window.SMTOPromptQueue.isOperational(native.status)) turn.historical = false;
      state.currentTurn = turn;
      state.requestId = response.request_id;
      state.activeEnvelope = turn.envelope = {request_id: response.request_id, snapshot: JSON.parse(JSON.stringify(snapshot))};
      if (native?.user_permission_policy) state.activeEnvelope.snapshot.permission_policy = native.user_permission_policy;
      if (native?.behavior_effort) state.activeEnvelope.snapshot.behavior_effort = native.behavior_effort;
      if (native) state.activeEnvelope.snapshot.context_carry_forward = native.context_carry_forward || {mode: "all"};
      if (native) activity.setStatus(turn.activity, activity.userStatus(native), {...native, authoritative: true});
      setRunning(true);
      if (!turn.source) connectTrace(response.request_id, `/api/agent/stream/${response.request_id}`, turn, turn.lastEventId || 0);
      if (previousTurn && previousTurn !== turn) renderTurnActivity(previousTurn);
      void loadFinalTrace(response.request_id, turn).then(retained => {
        if (state.currentTurn === turn) void window.SMTONative?.refresh();
        if (retained && !continuation) rememberPrompt(snapshot.prompt);
      });
    },
  });

  const draftScope = () => window.SMTODraftCache.scopeFor(elements.mode.value, state.conversationId);
  mentionPalette = window.SMTOMentionPalette.create({
    input: elements.input, composer: elements.composer, targetSelector, nativeControls: window.SMTONative,
    conversationId: () => state.openingConversation ? null : state.conversationId,
    isSteering: () => Boolean(state.steerRequestId), notify: showToast,
    onDraftChanged: () => { resizeInput(); updateSubmitState(); draftCache?.touch(true); },
    onVisibilityChanged: () => promptRecall?.update(),
    onBusyChanged: updateSubmitState,
  });
  draftCache = window.SMTODraftCache.create({
    input: elements.input, native: window.SMTONative, capabilityPolicy, permissionPolicy, runtimeGuards,
    // Interaction answers belong to the run, never to a reusable task draft.
    interactionWaiting: () => Boolean(currentInteraction()),
    isSteering: () => Boolean(state.steerRequestId), notify: showToast,
    changed: () => { mentionPalette.close(); state.promptHistoryNavigation = null; resizeInput(); updateSubmitState(); slashCommands.update(); },
  });

  promptRecall = window.SMTOPromptRecall.create({
    input: elements.input, button: $("#recall-button"), ghost: $("#prompt-ghost"), hint: $("#prompt-suggestion-hint"),
    getHistory: () => state.promptHistory,
    interactionWaiting: () => Boolean(currentInteraction()),
    isSteering: () => Boolean(state.steerRequestId),
    resourcesOpen: () => mentionPalette.isOpen(),
    setPrompt: text => {
      mentionPalette.close();
      elements.input.value = text;
      state.promptHistoryNavigation = null;
      elements.input.focus(); elements.input.setSelectionRange(text.length, text.length);
      resizeInput(); updateSubmitState(); slashCommands.update(); draftCache.touch();
    },
  });

  const oauthPrompt = window.SMTOOAuthPrompt.mount({
    container: $("#oauth-authorization-container"),
    onStop: id => window.SMTONative.cancelCurrent(id),
    onRefresh: () => window.SMTONative.refresh(),
    onAccepted: resumeApprovedRun,
  });
  const unsafePrompt = window.SMTOUnsafeActions.mount({
    onAccepted: resumeApprovedRun,
    onStop: id => window.SMTONative.cancelCurrent(id),
    onRefresh: () => window.SMTONative.refresh(),
  });
  composerBrowsing = window.SMTOComposerBrowsing.create({
    composer: elements.composer, input: elements.input, viewport: elements.viewport, anchor: elements.anchor,
    onScroll: () => promptNavigator?.refreshActive(),
    onResize: resizeInput,
    protectedWork: () => Boolean(state.steerRequestId || state.composerBusy || currentInteraction()
      || slashCommands.isBusy() || mentionPalette.isBusy()
      || window.SMTONative.attachmentSnapshot().length || !elements.toast.hidden),
  });
  function navigateToConversationTurn(messageId) {
    taskDisclosure.reveal(state.turns.get(messageId)?.article);
    return composerBrowsing.navigateToTurn(state.turns.get(messageId)?.article);
  }
  promptNavigator = window.SMTOConversationPromptNavigator.create({
    viewport: elements.viewport, content: elements.conversation, navigateToConversationTurn,
    onOpenChange: open => taskDisclosure.setNavigatorOpen(open),
    // History mounts newest first, so Map insertion order is no longer the
    // chronological display order. Sort only the bounded mounted window.
    getRecords: () => Array.from(state.turns.values()).filter(turn => turn.article.isConnected)
      .sort((a, b) => a === b ? 0 : a.article.compareDocumentPosition(b.article) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1)
      .map(turn => ({
      messageId: turn.requestId, role: "user", prompt: turn.prompt,
      hidden: !turn.userAuthored || window.SMTOTaskDisclosure.isFiltered(turn.article),
      attachments: turn.attachments, anchor: window.SMTOTaskDisclosure.anchorFor(turn.article),
    })),
  });
  window.addEventListener("pagehide", () => promptNavigator?.reset());
  window.addEventListener("pageshow", event => { if (event.persisted) promptNavigator?.refresh(); });
  function syncInteractionPrompts(snapshot, requestId) {
    const turn = state.turns.get(requestId);
    if (turn && snapshot) {
      turn.resourceRecoveryState = snapshot;
      window.SMTOResourceReconciliation.render(turn.actionArea, snapshot, {
        requestId, apiJson, onAccepted: resumeApprovedRun,
        reload: rid => reloadResourceRecovery(rid, turn),
      });
    }
    unsafePrompt.update(snapshot?.unsafe_action_request, snapshot?.cancel_requested);
    const waiting = snapshot?.status === "waiting_user" && snapshot?.oauth_authorization_request?.kind === "oauth";
    const wasWaiting = elements.composer.hidden;
    if (waiting && !wasWaiting) state.promptHistoryNavigation = null;
    elements.composer.hidden = Boolean(waiting);
    elements.composer.inert = Boolean(waiting);
    elements.composer.closest("footer").classList.toggle("oauth-mode", Boolean(waiting));
    oauthPrompt.update(snapshot?.oauth_authorization_request || {request_id: requestId},
      {waiting, cancelRequested: snapshot?.cancel_requested, target: snapshot?.target});
    promptRecall.update();
    if (!waiting && wasWaiting) { resizeInput(); if (!document.hidden) elements.input.focus(); }
  }

  function resumeApprovedRun(result) {
    const requestId = result.request_id, current = window.SMTONative.current();
    if (!result.resumed || current.request_id !== requestId || activity.terminal.has(current.status)) return;
    const turn = state.turns.get(requestId);
    if (!turn) return;
    turn.traceGeneration = (turn.traceGeneration || 0) + 1;
    turn.awaitingResume = true;
    renderActivity();
    turn.messageTimes?.clear();
    turn.answerText = "";
    turn.answer.replaceChildren();
    turn.meta.replaceChildren();
    turn.meta.hidden = true;
    setRunning(true);
    turn.work.root.hidden = false;
    turn.work.root.dataset.running = "true";
    connectTrace(requestId, `/api/agent/stream/${encodeURIComponent(requestId)}`, turn, turn.lastEventId || 0, true);
  }

  function currentRun() {
    if (state.preparingDirect) return {request_id: "", status: "pending"};
    if (state.submitting && !state.currentTurn?.requestId) return {request_id: "", status: "pending"};
    const native = window.SMTONative?.current();
    if (native?.request_id && native.status && (!state.requestId || state.requestId === native.request_id)) return native;
    return {request_id: state.requestId || state.currentTurn?.requestId || "", status: state.running || state.submitting ? "running" : state.traceStatus};
  }

  function isOperational() { return state.submitting || state.currentTurn?.replyResume?.pending
    || window.SMTOPromptQueue.isOperational(currentRun().status); }

  function currentInteraction() {
    const run = currentRun();
    if (!run.request_id) return null;
    if (state.turns.get(run.request_id)?.replyResume?.pending) return null;
    if (run.status === "awaiting_confirmation") return {kind: "approval", requestId: run.request_id};
    if (!["waiting_user", "awaiting_clarification"].includes(run.status)) return null;
    const request = state.turns.get(run.request_id)?.clarificationRequest || {};
    return {kind: request.allow_freeform === false && request.options?.length ? "choice" : "reply", requestId: run.request_id};
  }

  async function focusInteraction(interaction) {
    const turn = state.turns.get(interaction.requestId);
    if (turn) {
      await loadFinalTrace(interaction.requestId, turn);
      const card = turn.actionArea.querySelector(".action-card");
      card?.scrollIntoView({block: "nearest"});
      card?.querySelector("button, input")?.focus();
    }
    showToast(interaction.kind === "approval" ? "Use the approval controls to approve or deny this action." : "Choose an option in the current question to continue.");
  }

  function promptSnapshot(prompt) {
    if (composerProblem()) throw window.SMTOErrors.error("ui_composer_not_ready");
    if (!elements.model.value) throw window.SMTOErrors.error("ui_model_required");
    const mode = composerProfile.current().agent_mode || "agent";
    return {...composerProfile.submission(), prompt, depends_on_task_id: window.SMTOTaskDependencies.selectedTaskId(), agent_mode: mode, llm_model: elements.model.value, behavior_effort: behaviorEffort.value(),
      runtime_guard_policy: runtimeGuards.policyForRequest(),
      stop_policy: window.SMTOAgentChecks.stopPolicyForRequest(state.conversationId),
      context_read_policy: window.SMTOAgentChecks.contextPolicyForRequest(state.conversationId),
      task_contract_integrity_guard_enabled: window.SMTOAgentChecks.integrityForRequest(state.conversationId),
      parallel_execution_policy: window.SMTOAgentChecks.parallelPolicyForRequest(state.conversationId),
      background_activity_policy: window.SMTOAgentChecks.backgroundPolicyForRequest(state.conversationId),
      dependency_scheduling_policy: window.SMTOAgentChecks.dependencyPolicyForRequest(state.conversationId),
      scheduling_preference: window.SMTOAgentChecks?.schedulingPreferenceForRequest?.(state.conversationId),
      resource_scheduling_policy: window.SMTOAgentChecks.resourcePolicyForRequest(state.conversationId),
      ...targetSelector.submissionSnapshot(),
      conversation_id: state.conversationId,
      context_refs: window.SMTONative?.refs() || [], capability_policy: capabilityPolicy.policyForRequest(),
      conversation_capability_policy: capabilityPolicy.pendingConversationPolicy(),
      capability_selection: capabilityPolicy.selectionForRequest(),
      conversation_capability_selection: capabilityPolicy.pendingConversationSelection(),
      permission_policy: permissionPolicy.policyForRequest(),
      conversation_permission_policy: permissionPolicy.pendingConversationPolicy()};
  }

  const steerSubmissions = new Map();
  async function cancelOrExitSteer() {
    if (state.pendingSteer?.navigation === state.navigationVersion) {
      try { await state.pendingSteer.tracker.requestCancel(); }
      catch (error) { showToast(error.message || "Couldn’t cancel this steer. Try again."); }
      updateSubmitState(); return;
    }
    exitSteer();
  }
  function exitSteer() {
    if (state.pendingSteer?.navigation === state.navigationVersion) return;
    state.steerRequestId = null;
    $("#steer-indicator").hidden = true;
    updateSubmitState();
  }

  function startSteer(requestId, steeringMode = "interrupt") {
    if (state.pendingSteer) return;
    if (!window.SMTOPromptQueue.isSteerable(currentRun().status)) return;
    state.steerRequestId = requestId;
    state.steeringMode = steeringMode;
    $("#steer-indicator span").textContent = steeringMode === "after_response"
      ? "Steer without interrupting. Let the current response finish, then apply your update before the next action."
      : "Steering current task. Steering changes instructions on the existing run. Model, capabilities, attachments, and target remain unchanged.";
    $("#steer-indicator").hidden = false;
    elements.input.focus(); updateSubmitState();
  }

  const contextMeter = window.SMTOContextMeter.create(elements.contextMeter,
    (remaining, {reset, observedAt}) => {
      if (reset || remaining === null) window.SMTOStreamActivity.resetContext(streamActivityHistory);
      window.SMTOStreamActivity.receiveContext(streamActivityHistory, remaining, observedAt);
    });
  function updateContextMeter(usage, observedAt) { contextMeter.update(usage, observedAt); }

  function conversationUrl(id) {
    const url = new URL(window.location.href);
    url.searchParams.delete("task");
    if (id) url.searchParams.set("conversation", id);
    else url.searchParams.delete("conversation");
    return url.href;
  }
  function syncConversationUrl() {
    thinkingAnimations.activate(state.conversationId);
    window.history.replaceState(null, "", conversationUrl(state.conversationId));
  }

  function readStorage(key, fallback = "") {
    try {
      return localStorage.getItem(key) || fallback;
    } catch (_error) {
      return fallback;
    }
  }

  function writeStorage(key, value) {
    try {
      if (value) localStorage.setItem(key, value);
      else localStorage.removeItem(key);
    } catch (_error) {}
  }

  function applyTheme(theme, { persist = false } = {}) {
    if (!["light", "dark"].includes(theme)) return;
    document.documentElement.dataset.theme = theme;
    const label = theme === "dark" ? "Switch to light theme" : "Switch to dark theme";
    elements.themeToggle.setAttribute("aria-label", label);
    elements.themeToggle.title = label;
    if (persist) Core.setThemeOverride(theme);
  }

  function apiJson(path, options = {}) {
    return (!options.method || options.method === "GET") && !options.signal && !options.headers
      ? window.SMTOConversationSnapshot.coalesceRead(`desktop:${path}`, () => readJson(path, options)) : readJson(path, options);
  }
  async function readJson(path, options = {}) {
    const response = await window.SMTOErrors.fetch(path, { cache: "no-store", ...options });
    const text = await response.text();
    let payload = {};
    try {
      payload = text ? JSON.parse(text) : {};
    } catch (_error) {
      throw window.SMTOErrors.error("ui_response_invalid");
    }
    if (!response.ok) {
      const detail = payload?.detail;
      if (detail?.error_kind === "eula_acceptance_required") window.dispatchEvent(new Event("smto:eula-required"));
      const error = window.SMTOErrors.fromPayload(payload, response.status);
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  }

  function showToast(message) {
    if (message instanceof Error) commandPalette?.failed(message);
    clearTimeout(state.toastTimer);
    if (message?.error_detail || message?.error_ref) window.SMTOErrors.present(elements.toast, message, {profile: "toast"});
    else elements.toast.textContent = String(message?.message || message || "");
    elements.toast.hidden = false;
    state.toastTimer = setTimeout(() => { elements.toast.hidden = true; }, message?.error_detail ? 9000 : 2800);
  }
  window.addEventListener("smto:background-notice", ({detail}) => {
    // Use the normal message timeout, without replacing a foreground message or error.
    if (elements.toast.hidden && detail?.message) showToast(detail.message);
  });

  function setConnection(stateName, title = "") {
    elements.connection.dataset.state = stateName;
    connectionTitle = title || (stateName === "connected" ? "Connected" : "Disconnected");
    renderConnectionIndicator();
  }

  function renderConnectionIndicator() {
    const reconciling = elements.connection.dataset.state === "connected"
      && window.SMTOUiUpdates.state() === "connected"
      && window.SMTOUiUpdates.freshness() === "reconciling";
    elements.connection.dataset.reconciling = String(reconciling);
    const execution = elements.connection.dataset.execution;
    const connected = elements.connection.dataset.state === "connected";
    const maintenance = elements.connection.dataset.maintenance === "running";
    const maintenanceMessage = elements.connection.dataset.maintenanceMessage;
    const unresolvedJobs = Number(elements.connection.dataset.unresolvedJobs) || 0;
    const activityTitle = maintenanceMessage && ['active', 'idle'].includes(execution)
      ? `Connected · ${execution === 'active' ? 'Task active' : 'Idle'} · ${maintenanceMessage}`
      : execution === "active"
      ? "Connected · Task active · Background maintenance " + (maintenance ? "running" : "paused")
      : execution === "idle" ? "Connected · Idle · Background maintenance " + (maintenance ? "running" : "allowed")
      : "Connected · Checking backend activity";
    elements.connection.title = connected
      ? activityTitle + (unresolvedJobs ? ` · ${unresolvedJobs} previous operation${unresolvedJobs === 1 ? "" : "s"} awaiting status` : "")
        + (reconciling ? " · Reconciling task status" : "") : connectionTitle;
    elements.connection.setAttribute("aria-label", elements.connection.title);
  }
  window.addEventListener("smto:backend-activity", renderConnectionIndicator);

  function resizeInput() {
    elements.input.style.height = "auto";
    elements.input.style.height = `${Math.min(elements.input.scrollHeight, 180)}px`;
  }

  function rememberPrompt(prompt) {
    state.promptHistory = [...state.promptHistory.filter((item) => item !== prompt), prompt]
      .slice(-state.promptHistoryLimit);
  }

  async function loadPromptHistory() {
    try {
      const payload = await apiJson("/api/agent/prompt-history");
      if (Number.isInteger(payload.max_items) && payload.max_items > 0) {
        state.promptHistoryLimit = payload.max_items;
      }
      const recent = state.promptHistory;
      state.promptHistory = [];
      for (const item of [...(Array.isArray(payload.items) ? payload.items : []), ...recent]) {
        if (typeof item === "string" && item.trim()) rememberPrompt(item);
      }
      promptRecall?.update();
    } catch (_error) { /* Prompts sent in this tab remain available offline. */ }
  }

  function navigatePromptHistory(direction) {
    const input = elements.input;
    if (input.selectionStart !== input.selectionEnd) return false;
    const surroundingText = direction < 0
      ? input.value.slice(0, input.selectionStart)
      : input.value.slice(input.selectionEnd);
    if (surroundingText.includes("\n")) return false;

    let navigation = state.promptHistoryNavigation;
    if (!navigation) {
      if (direction > 0 || !state.promptHistory.length) return false;
      navigation = {
        items: [...state.promptHistory],
        index: state.promptHistory.length,
        draft: input.value,
        selectionStart: input.selectionStart,
        selectionEnd: input.selectionEnd,
      };
      state.promptHistoryNavigation = navigation;
    }
    if (navigation.index < navigation.items.length) {
      navigation.items[navigation.index] = input.value;
    }
    navigation.index = Math.max(0, navigation.index + direction);
    if (navigation.index === navigation.items.length) {
      input.value = navigation.draft;
      input.setSelectionRange(navigation.selectionStart, navigation.selectionEnd);
      state.promptHistoryNavigation = null;
    } else {
      input.value = navigation.items[navigation.index];
      const caret = direction < 0 && input.value.includes("\n") ? 0 : input.value.length;
      input.setSelectionRange(caret, caret);
    }
    resizeInput();
    updateSubmitState();
    draftCache.touch();
    return true;
  }

  function updateSubmitState() {
    thinkingToggle.render();
    if (state.pendingSteer && state.pendingSteer.navigation !== state.navigationVersion) {
      state.pendingSteer.tracker.cancel(); state.pendingSteer = null; state.composerBusy = false;
    }
    $("#exit-steer").disabled = Boolean(state.pendingSteer && !state.pendingSteer.tracker.canCancel);
    $("#exit-steer").setAttribute("aria-label", state.pendingSteer ? "Cancel steer" : "Exit steering");
    $("#exit-steer").title = state.pendingSteer ? "Cancel steer" : "Exit steering";
    elements.composer.toggleAttribute("data-pending-steer", Boolean(state.pendingSteer));
    elements.submit.hidden = Boolean(state.pendingSteer);
    window.SMTOProseActivity.renderToggle($("#activity-details-toggle"), state.conversationId);
    composerBrowsing?.setContext(state.navigationVersion);
    window.SMTONative.renderStop(currentRun());
    window.SMTONative.syncResourceLock();
    targetSelector.render();
    behaviorEffort.render(state.steerRequestId
      ? currentRun().behavior_effort || state.activeEnvelope?.snapshot.behavior_effort || "medium" : null);
    mentionPalette?.update();
    promptRecall?.update();
    const interaction = currentInteraction();
    $("#schedule-draft").hidden = Boolean(interaction || state.steerRequestId);
    $("#schedule-draft").disabled = !state.executionReady || !state.identityReady || !window.SMTOLegal.canExecute() || Boolean(interaction || state.steerRequestId || state.composerBusy || !promptSchedules.eligible(elements.input.value));
    elements.input.placeholder = interaction?.kind === "reply" ? "Reply to me…" : interaction?.kind === "choice" ? "Choose an option above…" : interaction?.kind === "approval" ? "Use the approval controls above…" : window.__BRANDING__.composer_placeholder;
    const preparing = !state.executionReady || !state.identityReady;
    const profileLoading = !composerProfile?.ready();
    elements.mode.disabled = profileLoading || Boolean(state.steerRequestId);
    elements.model.disabled = profileLoading || Boolean(state.steerRequestId);
    $("#behavior-effort").disabled ||= profileLoading;
    carryForwardControl.setDisabled(Boolean(profileLoading || state.steerRequestId));
    for (const control of [parallelToggle, backgroundToggle, dependencyToggle]) control.disabled ||= profileLoading;

    if (!preparing) window.SMTOConversationHistory.mark("boot_to_execution_ready_ms");
    const label = preparing ? "Preparing…" : interaction ? {reply: "Reply to me", choice: "Choose an option", approval: "Review approval"}[interaction.kind]
      : state.steerRequestId ? (state.steeringMode === "after_response" ? "Steer without interrupting" : "Steer current") : (isOperational() || promptQueue.hasItems()) ? "Queue message" : "Send message";
    const interactionPending = interaction && (clarificationSubmissions.has(interaction.requestId)
      || confirmationSubmissions.has(interaction.requestId));
    elements.submit.disabled = (!interaction && !state.steerRequestId && !slashCommands.isCommand(elements.input.value) && Boolean(composerProblem())) || preparing || (!window.SMTOLegal.canExecute() && !slashCommands.isCommand(elements.input.value)) || slashCommands.isBusy() || mentionPalette?.isBusy() || state.composerBusy || interactionPending || state.generateProseSaving || state.taskContractSaving || !elements.input.value.trim();
    elements.submit.dataset.running = String(isOperational());
    elements.submit.setAttribute("aria-label", label);
    elements.submit.title = composerProblem() || label;
    if (window.SMTOConversationDeletion?.blocked(state.conversationId) && !slashCommands.isCommand(elements.input.value)) {
      elements.submit.disabled = true;
      elements.submit.setAttribute("aria-label", "Deleting conversation");
      elements.submit.title = "Deleting conversation. Open another conversation or start a new chat.";
    }
    if (composerProfile?.ready() && !composerProfile.current().unsynced && !composerProfile.current().error && profileStatus.firstChild) profileStatus.firstChild.textContent = composerProblem();
    composerBrowsing?.refresh();
    commandPalette?.update();
  }

  function setRunning(running) {
    state.running = Boolean(running);
    slashCommands.update();
    updateSubmitState();
    renderActivity();
    if (running) {
      startDurationClock(state.currentTurn);
    } else {
      clearInterval(state.currentTurn?.durationTimer);
    }
  }

  function showConversation() {
    elements.empty.hidden = Boolean(elements.conversation.querySelector(".turn, .history-skeleton, .history-retry"));
  }

  function scrollToBottom(behavior = "smooth", force = false) {
    if (document.hidden) return;
    const navigation = state.navigationVersion;
    requestAnimationFrame(() => {
      if (navigation === state.navigationVersion) composerBrowsing?.scrollToBottom(behavior, force);
    });
  }

  function formatDuration(milliseconds) {
    return timing.format(milliseconds);
  }

  function durationFromTrace(trace) {
    const timing = trace?.runtime_timing || trace?.timing || {};
    if (Number.isFinite(Number(timing.duration_ms))) return Number(timing.duration_ms);
    const start = Date.parse(timing.started_at || trace?.created_at || "");
    const end = Date.parse(timing.completed_at || trace?.updated_at || "");
    return Number.isFinite(start) && Number.isFinite(end) ? Math.max(0, end - start) : 0;
  }

  function renderResponseTiming(turn, trace) {
    turn.messageTimes?.restore(trace);
    turn.contextUsage = trace.native_profile?.llm_context_usage || trace.response_metrics?.llm_context_usage || turn.contextUsage;
    turn.tokenUsage = window.SMTOResponseTokens.latest(turn.tokenUsage, trace.response_metrics?.token_usage);
    const status = activity.userStatus(trace);
    const snapshot = trace.visualization_snapshot || trace;
    // A continuation's chain duration includes earlier responses. Show only this request.
    const recorded = snapshot.request_runtime_timing || snapshot.timing || snapshot.runtime_timing || {};
    const finite = value => typeof value === "number" && Number.isFinite(value) && value >= 0;
    let duration = recorded.duration_ms;
    if (!finite(duration)) {
      const start = Date.parse(recorded.started_at || snapshot.created_at || trace.created_at || "");
      const end = Date.parse(recorded.completed_at || snapshot.updated_at || trace.updated_at || "");
      if (Number.isFinite(start) && Number.isFinite(end)) duration = Math.max(0, end - start);
      else duration = snapshot.summary?.duration_ms ?? trace.response_metrics?.duration_ms
        ?? (finite(trace.response_metrics?.duration_seconds) ? trace.response_metrics.duration_seconds * 1000 : null)
        ?? timing.duration(turn.timing.run);
    }
    turn.responseTiming.hidden = !activity.terminal.has(status) || !finite(duration);
    if (turn.responseTiming.hidden) {
      turn.responseTiming.querySelector(".response-time-summary")?.remove();
      renderResponseTokens(turn, trace.response_metrics || turn.responseMetrics || {});
      return;
    }
    const label = {completed: "Completed in", answered: "Completed in", failed: "Failed after",
      cancelled: "Stopped after", interrupted: "Interrupted after", partial: "Worked for"}[status];
    const times = turn.responseTiming.querySelector(".response-time-summary") || document.createElement("div");
    times.className = "response-time-summary";
    times.textContent = `${label} ${formatDuration(duration)} · `;
    if (times.parentNode !== turn.responseTiming) turn.responseTiming.prepend(times);
    const metrics = trace.response_metrics || turn.responseMetrics || {};
    const breakdown = document.createElement("span");
    let summary = timing.responseBreakdown(recorded);
    if (summary.text === "Timing breakdown unavailable" && turn.completedTiming?.duration === duration
        && turn.completedTiming.requestId === turn.requestId) summary = turn.completedTiming.summary;
    turn.completedTiming = {duration, requestId: turn.requestId, summary};
    breakdown.className = "response-time-breakdown";
    breakdown.textContent = summary.text;
    breakdown.title = summary.title;
    times.append(breakdown, "\n");
    renderResponseTokens(turn, metrics, trace.native_profile?.usage);
  }

  function renderResponseTokens(turn, metrics = {}, usage) {
    const tokens = turn.responseTiming.querySelector(".response-token-usage") || document.createElement("div");
    const available = window.SMTOResponseTokens.render(tokens,
      {...metrics, llm_context_usage: turn.contextUsage || metrics.llm_context_usage,
        ...(turn.tokenUsage ? {token_usage: turn.tokenUsage} : {})}, metrics.usage || usage || {});
    if (available || !turn.responseTiming.hidden) {
      if (tokens.parentNode !== turn.responseTiming) turn.responseTiming.append(tokens);
      turn.responseTiming.hidden = false;
    }
  }

  function copyButton(textProvider, {label = "Copy response", successMessage = "Copied", failureMessage = "Could not copy the response"} = {}) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "copy-button";
    button.setAttribute("aria-label", label);
    button.title = label;
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
    const copied = window.SMTOCopyFeedback.bind(button);
    button.addEventListener("click", async event => {
      event.preventDefault(); event.stopPropagation();
      try {
        const text = String((await textProvider()) ?? "");
        try {
          if (!navigator.clipboard?.writeText) throw window.SMTOErrors.error("ui_clipboard_unavailable");
          await navigator.clipboard.writeText(text);
        } catch (_) {
          const active = document.activeElement, input = document.createElement("textarea");
          input.value = text; input.style.position = "fixed"; input.style.opacity = "0";
          document.body.append(input); input.select();
          try { if (!document.execCommand("copy")) throw window.SMTOErrors.error("ui_clipboard_unavailable"); }
          finally { input.remove(); active?.focus({preventScroll: true}); }
        }
        copied();
        showToast(successMessage);
      } catch (_error) {
        showToast(failureMessage);
      }
    });
    return button;
  }

  function decorateCodeBlocks(root) {
    const commands = new Set(["bash", "sh", "shell", "zsh", "powershell", "pwsh", "cmd", "console"]);
    for (const pre of root.querySelectorAll("pre")) {
      const code = pre.querySelector(":scope > code");
      if (!code || pre.querySelector(":scope > .copy-button")) continue;
      const language = (pre.dataset.language || "").toLowerCase();
      const kind = commands.has(language) ? "command" : language ? "code" : "";
      pre.append(copyButton(() => code.textContent, {
        label: kind ? `Copy ${kind}` : "Copy",
        successMessage: kind ? `${kind === "command" ? "Command" : "Code"} copied` : "Copied",
        failureMessage: kind ? `Could not copy ${kind}` : "Could not copy",
      }));
    }
  }

  function terminalIcon() {
    const icon = document.createElement("span");
    icon.className = "terminal-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = '<svg viewBox="0 0 16 16"><rect x="1.5" y="1.5" width="13" height="13" rx="3"/><path d="m5 5 2.5 2.5L5 10m4 0h2.5"/></svg>';
    return icon;
  }

  function updateCommandGroup(turn) {
    const commandsOnly = turn.timing.models.size === 0 && turn.actionItems.size > 0
      && Array.from(turn.actionItems.values()).every((row) => row.commandPreview);
    turn.work.root.classList.toggle("commands-only", commandsOnly);
    if (commandsOnly && turn.work.root.dataset.running !== "true" && ["Completed", "Worked", "Ran commands"].includes(turn.work.label.textContent)) {
      turn.work.label.textContent = "Ran commands";
    }
    return commandsOnly;
  }

  function createWorkDisclosure(running = true) {
    const details = document.createElement("details");
    details.className = "work-disclosure";
    details.dataset.running = String(running);
    details.dataset.activityConversation = state.conversationId || "";
    details.open = window.SMTOProseActivity.preference(state.conversationId,
      session.get("agent_responses_expanded", false));
    const summary = document.createElement("summary");
    // Individual activity disclosures are temporary; the composer owns persistence.
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    spinner.setAttribute("aria-hidden", "true");
    const label = document.createElement("span");
    label.className = "work-label";
    label.textContent = running ? "Working…" : "Completed";
    const duration = document.createElement("span");
    duration.className = "work-duration";
    summary.append(spinner, terminalIcon(), label, duration);
    const items = document.createElement("div");
    items.className = "work-items";
    details.append(summary, items);
    const status = document.createElement("p");
    status.className = "task-activity-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-atomic", "true");
    status.hidden = true;
    const statusCopy = document.createElement("span");
    statusCopy.className = "task-activity-copy";
    const statusLabel = document.createElement("span");
    const statusDetail = document.createElement("span");
    statusDetail.className = "task-activity-detail";
    statusCopy.append(statusLabel, document.createTextNode(" "), statusDetail);
    status.append(thinkingAnimations.create(state.conversationId), statusCopy);
    return { root: details, label, duration, items, status, statusLabel, statusDetail };
  }

  let conversationHistory = null;
  let activityBoundariesPending = false;
  const taskDisclosure = window.SMTOTaskDisclosure.create({
    content: elements.conversation, viewport: elements.viewport, toolbar: $("#task-disclosure-toolbar"),
    conversationId: () => state.conversationId,
    getTask: id => state.conversationSnapshot?.conversation?.conversation_id === state.conversationId
      ? state.conversationSnapshot.lane.tasks_by_id?.[id] : null,
    getTurn: root => {
      const turn = state.turns.get(root.dataset.requestId) || provisionalTurns.get(root.dataset.submissionId);
      return {prompt: turn?.prompt || root.querySelector(".user-message")?.textContent, attachments: turn?.attachments,
        taskId: root.dataset.taskId, userAuthored: turn?.userAuthored,
        sentAt: turn?.messageTimes?.sentAt(),
        durationMs: turn?.completedTiming?.duration ?? conversationTiming.duration(turn?.requestId),
        status: turn?.replyResume?.pending ? "resuming" : turn?.requestId ? turn.activity.status : root.dataset.taskId ? null : "pending"};
    },
    beforeToggle: () => composerBrowsing?.holdPosition(), changed: () => promptNavigator?.refresh(),
    toggleNavigator: trigger => promptNavigator?.toggle(trigger),
  });
  const taskDeletion = window.SMTOTaskDeletion.create({
    conversationId: () => state.conversationId, apiJson, notify: showToast,
    changed: (cid, deleted) => {
      if (cid !== state.conversationId) return;
      conversationHistory?.remove(deleted);
      for (const turn of [...state.turns.values()]) if (deleted(turn)) releaseHistoricalTurn(turn);
      for (const [id, turn] of provisionalTurns) if (deleted(turn)) {
        if (turn.article.isConnected) releaseHistoricalTurn(turn);
        provisionalTurns.delete(id);
      }
      if (deleted({request_id: state.requestId})) { state.requestId = null; state.currentTurn = null; }
      promptNavigator?.refresh();
      if (!state.turns.size && !provisionalTurns.size) elements.empty.hidden = false;
      scheduleActivityBoundaries();
      queueMicrotask(() => { void window.SMTOSelectedConversation?.refresh(); });
    },
  });

  function createActivityGroup() {
    const group = document.createElement("section");
    group.className = "activity-group";
    group.setAttribute("role", "group");
    group.setAttribute("aria-label", "Conversation activity");
    return group;
  }

  function setActivityGroupIdentity(group, taskId = "") {
    if (!group) return;
    if (taskId) {
      group.dataset.taskId = taskId;
      group.dataset.activityId = `task:${taskId}`;
    } else {
      delete group.dataset.taskId;
      delete group.dataset.activityId;
    }
  }

  function cleanupActivityGroup(group) {
    if (group?.classList?.contains("activity-group") && !group.querySelector(":scope > .turn")) group.remove();
  }

  function moveActivityGroupInto(parentTurn, turn) {
    if (!parentTurn?.article?.isConnected || !turn?.article?.isConnected || !turn.taskId
        || parentTurn.taskId !== turn.taskId) return false;
    parentTurn.continuedBy = turn.requestId;
    parentTurn.inlineSteer?.update({status: parentTurn.activity.status, continued_by: {request_id: turn.requestId}});
    const target = parentTurn.activityGroup || parentTurn.article.closest(".activity-group");
    const source = turn.activityGroup || turn.article.closest(".activity-group");
    if (!target || !source) return false;
    const targetPage = target.closest(".history-page"), sourcePage = source.closest(".history-page");
    // Virtual history pages own their historical turns independently. Keep a
    // cross-page continuation as a visual fragment so eviction/remount remains
    // correct; live continuations may be adopted into the mounted parent page.
    if (parentTurn.historical && turn.historical && targetPage && sourcePage && targetPage !== sourcePage) return false;
    setActivityGroupIdentity(target, turn.taskId);
    if (target === source) return true;

    const moved = [...source.querySelectorAll(":scope > .turn")];
    const movedTurns = [];
    for (const article of moved) {
      target.append(article);
      const member = article === turn.article ? turn : state.turns.get(article.dataset.requestId);
      if (member) { member.activityGroup = target; movedTurns.push(member); }
    }
    cleanupActivityGroup(source);
    conversationHistory?.adopt?.(parentTurn, movedTurns);
    return true;
  }

  function reconcileTurnActivityGroup(turn) {
    if (!turn?.article?.isConnected) return;
    const group = turn.activityGroup || turn.article.closest(".activity-group");
    if (group) {
      turn.activityGroup = group;
      if (turn.taskId) setActivityGroupIdentity(group, turn.taskId);
    }
    if (!turn.parentRequestId || !turn.taskId) return;
    const parentTurn = state.turns.get(turn.parentRequestId);
    if (!parentTurn) return;
    moveActivityGroupInto(parentTurn, turn);
  }

  function reconcileActivityChildren(parentTurn) {
    if (!parentTurn?.requestId || !parentTurn.taskId) return;
    for (const candidate of state.turns.values()) {
      if (candidate !== parentTurn && candidate.parentRequestId === parentTurn.requestId
          && candidate.taskId === parentTurn.taskId) moveActivityGroupInto(parentTurn, candidate);
    }
  }

  function scheduleActivityBoundaries() {
    if (activityBoundariesPending) return;
    activityBoundariesPending = true;
    queueMicrotask(() => {
      activityBoundariesPending = false;
      let previous = null;
      for (const group of elements.conversation.querySelectorAll(".activity-group")) {
        group.classList.remove("activity-continuation-fragment");
        group.querySelectorAll(":scope > .turn").forEach((article, index) => {
          if (article.closest("[hidden]")) return;
          const current = article.dataset;
          const continuation = Boolean(previous && current.taskId
            && current.taskId === previous.taskId && current.parentRequestId === previous.requestId);
          article.classList.toggle("activity-continuation", continuation);
          if (continuation && index === 0) group.classList.add("activity-continuation-fragment");
          previous = current;
        });
      }
      taskDeletion.decorate(elements.conversation);
      taskDisclosure.sync();
      promptNavigator?.refresh();
    });
  }

  function setTurnActivityLineage(turn, payload = {}) {
    if (!turn) return;
    const taskId = payload.task_id, parentRequestId = payload.parent_request_id || payload.continuation?.parent_request_id;
    let changed = false;
    if (taskId && turn.taskId !== taskId) {
      turn.taskId = turn.article.dataset.taskId = taskId; changed = true;
    }
    if (parentRequestId && turn.parentRequestId !== parentRequestId) {
      turn.parentRequestId = turn.article.dataset.parentRequestId = parentRequestId; changed = true;
    }
    window.SMTOTaskMode.render(turn.article, payload,
      state.conversationSnapshot?.lane.tasks_by_id?.[turn.taskId]);
    if (changed) { reconcileTurnActivityGroup(turn); reconcileActivityChildren(turn); }
    scheduleActivityBoundaries();
  }

  function setTurnAttemptPrompt(turn, payload = {}) {
    // Lane recovery may mount this request using the durable task's original
    // prompt before the child snapshot/POST arrives. Keep the actual amendment.
    const prompt = payload.followup_prompt || "";
    const continuation = Boolean(payload.continuation) && !prompt;
    if (!turn || (!prompt && !continuation) || (turn.prompt === prompt && turn.userAuthored === !continuation)) return;
    turn.prompt = turn.user.textContent = prompt;
    turn.userAuthored = !continuation;
    if (turn.userAuthored) turn.article.dataset.conversationTurnId = turn.requestId;
    else delete turn.article.dataset.conversationTurnId;
    const row = turn.user.parentElement;
    row.hidden = continuation;
    row.querySelector(".prompt-schedule-action")?.remove();
    if (!continuation) promptSchedules.attach(row, turn.prompt, turn.requestId);
    promptNavigator?.refresh();
  }

  function createTurn(prompt, requestId = "", { historical = false, compact = false, continuation = false, taskId = "", parentRequestId = "", attachments, container = elements.conversation } = {}) {
    const article = document.createElement("article");
    article.className = "turn";
    article.dataset.requestId = requestId;
    if (requestId && !compact && !continuation) article.dataset.conversationTurnId = requestId;
    const userRow = document.createElement("div");
    userRow.className = "user-message-row";
    userRow.hidden = continuation;
    const user = document.createElement("div");
    user.className = "user-message";
    user.textContent = prompt;
    if (compact) user.dataset.compact = "true";
    userRow.append(user);
    const userCopy = copyButton(() => window.SMTOPlanMode.message(user), {
      label: "Copy message",
      successMessage: "Message copied",
      failureMessage: "Could not copy the message",
    });
    userCopy.classList.add("prompt-copy-action");
    userRow.append(userCopy);
    if (!compact && !continuation) promptSchedules.attach(userRow, prompt, requestId);
    const assistant = document.createElement("div");
    assistant.className = "assistant-turn";
    const work = createWorkDisclosure(!historical);
    if (historical) work.root.hidden = true;
    const answer = document.createElement("div");
    answer.className = "assistant-answer markdown";
    const finalizing = document.createElement("div");
    finalizing.className = "answer-finalizing";
    finalizing.textContent = "Finalizing…";
    finalizing.setAttribute("role", "status");
    finalizing.hidden = true;
    const actionArea = document.createElement("div");
    actionArea.className = "action-area";
    const meta = document.createElement("div");
    meta.className = "assistant-meta";
    meta.hidden = true;
    const runActions = document.createElement("div");
    runActions.className = "assistant-meta run-actions";
    runActions.setAttribute("role", "group");
    runActions.setAttribute("aria-label", "Run actions");
    const agentChecksArea = document.createElement("div");
    agentChecksArea.className = "agent-check-details";
    const responseTiming = document.createElement("div");
    responseTiming.className = "response-timing";
    responseTiming.setAttribute("aria-live", "off");
    responseTiming.hidden = true;
    assistant.append(work.root, work.status, answer, finalizing, actionArea, meta, runActions, agentChecksArea, responseTiming);
    let inlineSteer = null;
    article.append(userRow, assistant);
    const activityGroup = createActivityGroup();
    activityGroup.append(article);
    if (historical) container.prepend(activityGroup);
    else container.append(activityGroup);
    showConversation();
    const turn = {
      article, user, assistant, work, answer, finalizing, actionArea, meta, runActions, agentChecksArea, responseTiming,
      requestId, conversationId: state.conversationId, inlineSteer, historical, prompt, attachments, userAuthored: !compact && !continuation, answerText: "", eventCount: 0,
      actionItems: new Map(),
      timing: timing.create(),
      activity: activity.create(streamActivityHistory),
      taskId: "", parentRequestId: "", activityGroup,
    };
    turn.messageTimes = window.SMTOMessageTimestamps.bind({user, answer, userAuthored: () => turn.userAuthored});
    setTurnActivityLineage(turn, {task_id: taskId, parent_request_id: parentRequestId});
    scheduleActivityBoundaries();
    const extras = () => {
      if (!article.isConnected) return;
      if (!compact && !continuation && !turn.promptExtrasAttached) {
        window.SMTOWorkflows?.attach(turn, runActions);
        window.SMTOFastCache?.attachPrompt(turn, userRow); turn.promptExtrasAttached = true;
      }
      if (requestId && !turn.artifacts) {
        turn.artifacts = window.SMTOArtifacts?.attach(assistant, requestId, state.conversationId, apiJson, {actionContainer: runActions});
        if (turn.artifacts?.action) {
          if (turn.forkAction) turn.forkAction.after(turn.artifacts.action);
          else runActions.prepend(turn.artifacts.action);
        }
      }
    };
    if (historical && window.IntersectionObserver) {
      const observer = new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) { observer.disconnect(); extras(); }
      }, {root: elements.viewport});
      observer.observe(article); turn.extrasObserver = observer;
    } else extras();
    turn.bindRequest = id => {
      turn.conversationId ||= state.conversationId;
      work.root.dataset.activityConversation = turn.conversationId || "";
      if (turn.boundRequestId) return;
      requestId = id; turn.requestId = id; turn.boundRequestId = id;
      window.SMTOSavedTaskContext?.bind(turn, {apiJson, conversationId: turn.conversationId});
      article.dataset.requestId = id;
      if (!compact && !continuation) article.dataset.conversationTurnId = id;
      inlineSteer = window.SMTOInlineSteer.create({requestId: id,
        submit: ({requestId: rid, amendment, submissionId, steeringMode}) => window.SMTONative.steer(amendment, rid, submissionId, steeringMode),
        cancel: payload => window.SMTONative.cancelSteer(payload),
        followup: payload => window.SMTONative.followup(payload),
        reconcile: rid => window.SMTONative.refreshTaskSnapshot(rid), notify: showToast,
        onAccepted: () => scrollToBottom("instant", true),
      });
      turn.inlineSteer = inlineSteer;
      if (inlineSteer) meta.after(inlineSteer.root);
      extras();
      state.turns.set(requestId, turn);
      reconcileTurnActivityGroup(turn);
      reconcileActivityChildren(turn);
      scheduleActivityBoundaries();
      promptNavigator?.refresh();
      const actions = window.SMTONative.createTaskActions(requestId, () => {
        const head = state.conversationSnapshot?.lane.tasks_by_id?.[turn.taskId]?.latest_request_id;
        return {
          status: turn.activity.status,
          continuedBy: turn.continuedBy || (head && head !== turn.requestId ? head : null),
          historical: turn.historical,
          current: turn === state.currentTurn,
          interaction: Boolean(turn.inlineInteraction),
          settled: activity.resolve(turn.activity).kind === "terminal",
        };
      }, {actionContainer: runActions, inlineSteer});
      runActions.after(actions);
      turn.visualization = window.SMTORunExecution?.attach(runActions, requestId, apiJson);
      turn.historyLoader = window.SMTOConversationSnapshot.loadHistoryControl({actionContainer: runActions,
        disclosure: work.root, host: work.items, requestId, apiJson, conversationId: turn.conversationId,
        ready: () => state.historyLoad, onAnswerArchived: answer => archiveTurnAnswer(turn, answer)});
    };
    if (requestId) turn.bindRequest(requestId);
    return turn;
  }

  function eventDetail(event) {
    const detail = event?.detail && typeof event.detail === "object" ? event.detail : {};
    return detail;
  }

  function eventShouldDisplay(event) {
    event = activityPresentation.operationEvent(event);
    const type = String(event?.event_type || "");
    return isCompactionEvent(event) || isTaskContractEvent(event) || ["run.resumed", "run.steer_queued", "run.steer_cancelled"].includes(type) || type.startsWith("execution.command.") || type.startsWith("invocation.");
  }

  function isTaskContractEvent(event) {
    return ["task_contract.started", "task_contract.progress", "task_contract.attempt_failed", "task_contract.failed", "task_contract.completed", "task_contract.clarification_required"].includes(event?.event_type)
      && Boolean(eventDetail(event).detail_available);
  }

  function renderTaskContractEvent(turn, event) {
    const detail = eventDetail(event);
    const key = detail.operation_id || `task-contract:${event.event_id || event.id}`;
    let row = turn.actionItems.get(key);
    if (!row) {
      row = createWorkItem(turn, key, {kind: "task-contract", title: detail.label || "Task contract"});
      turn.actionItems.set(key, row);
      row.item.classList.add("contextual-operation");
      actionIcons.update(row.typeIcon, "file");
      row.icon.setAttribute("aria-hidden", "true");
      row.contextPosition = {start: Date.parse(event.timestamp), order: Number(event.id || event.index || 0)};
    }
    if (row.item.dataset.status !== "completed" && row.item.dataset.status !== "failed")
      row.item.dataset.status = ["task_contract.started", "task_contract.progress"].includes(event.event_type) ? "running"
        : ["task_contract.failed", "task_contract.attempt_failed"].includes(event.event_type) ? "failed" : "completed";
    window.SMTOToolActivity?.attach(row, event.request_id || turn.requestId, detail, copyButton);
  }

  function isCompactionEvent(event) {
    return ["context.working_set_pruned", "context.manual_compacted"].includes(event?.event_type);
  }

  function renderCompactionEvent(turn, event) {
    const key = `context:${event.event_id || event.id}`;
    if (turn.actionItems.has(key)) return;
    const d = eventDetail(event);
    const mode = d.mode || (event.event_type === "context.manual_compacted" ? "manual" : "");
    const title = mode === "manual" ? "Context compacted manually" : "Context compacted";
    const valid = value => Number.isFinite(value) && value >= 0;
    const compact = value => value < 1000 ? String(value) : `${Number((value / 1000).toFixed(1))}k`;
    const exact = value => value.toLocaleString("en-US");
    const counts = valid(d.tokens_before) && valid(d.tokens_after)
      ? `${compact(d.tokens_before)} → ${compact(d.tokens_after)}` : "";
    const row = createWorkItem(turn, key, {iconText: "✓", kind: "context", title});
    row.icon.dataset.uiSymbol = "check";
    turn.actionItems.set(key, row);
    row.contextPosition = {start: Date.parse(event.timestamp), order: Number(event.id || event.index || 0)};
    row.item.dataset.level = "info";
    row.icon.setAttribute("aria-hidden", "true");
    const details = document.createElement("details"); details.className = "context-compaction";
    const summary = document.createElement("summary");
    summary.textContent = title + (counts ? ` · ${counts}` : "");
    const trigger = {automatic: "Automatic", manual: "Manual", overflow_recovery: "Context-limit recovery"}[mode];
    summary.setAttribute("aria-label", [title, trigger, counts ? `${exact(d.tokens_before)} to ${exact(d.tokens_after)} tokens` : ""].filter(Boolean).join(" · "));
    summary.setAttribute("aria-expanded", "false");
    details.addEventListener("toggle", () => summary.setAttribute("aria-expanded", String(details.open)));
    const facts = document.createElement("dl"); facts.className = "context-compaction-facts";
    const fact = (label, value) => {
      const term = document.createElement("dt"), description = document.createElement("dd");
      term.textContent = label; description.textContent = value; facts.append(term, description);
    };
    if (trigger) fact("Trigger", trigger);
    for (const [label, value, estimated] of [
      ["Before", d.tokens_before, d.tokens_before_estimated],
      ["After", d.tokens_after, d.tokens_after_estimated], ["Target", d.target_tokens],
    ]) if (valid(value)) fact(label, `${exact(value)} tokens${estimated === true ? " (estimated)" : ""}`);
    if (valid(d.history_turns_omitted)) fact("Older turns", `${exact(d.history_turns_omitted)} omitted from active context`);
    else if (valid(d.older_turns_omitted)) fact("Older turns", `${exact(d.older_turns_omitted)} omitted in total`);
    if (valid(d.tool_groups_pruned_now)) fact("Tool groups", `${exact(d.tool_groups_pruned_now)} pruned from active context`);
    else if (valid(d.tool_groups_pruned)) fact("Tool groups", `${exact(d.tool_groups_pruned)} pruned in total`);
    details.append(summary, facts);
    if (d.exact_history_retained === true) {
      const history = document.createElement("p");
      history.textContent = "Exact conversation and execution history was retained. Older details remain available if needed.";
      details.append(history);
    }
    row.copy.replaceChildren(details);
  }

  function createWorkItem(turn, key, { iconText = "", title = "", summary = "", kind = "execution" } = {}) {
    const row = activityPresentation.createRow({kind, title, summary, iconText});
    const {item} = row;
    if (!turn.work.activeItems || !turn.work.items.contains(turn.work.activeItems)) {
      turn.work.activeItems = window.SMTOProseActivity.working(turn.work.items,
        {conversationId: turn.conversationId, itemsClass: "work-items"}).items;
      turn.work.root.classList.add("progress-timeline");
      turn.work.root.open = true;
    }
    turn.work.activeItems.append(item);
    turn.eventCount += 1;
    return {key, ...row};
  }

  function executionKey(event, detail) {
    return String(
      detail.action_id
      || detail.operation_id
      || event?.action_id
      || event?.operation_id
      || `execution-${event?.event_id || event?.id || "unknown"}`,
    );
  }

  function executionOutput(event, detail) {
    const type = String(event?.event_type || "");
    if (type === "execution.command.started") {
      const command = detail.command || detail.shell_command;
      if (command) return { channel: "command", text: String(command) };
      return detail.code ? { channel: "code", text: String(detail.code) } : null;
    }
    const value = detail.text
      ?? detail.stdout
      ?? detail.stderr
      ?? detail.output
      ?? event?.tool_output
      ?? event?.error;
    if (value === undefined || value === null || value === "") return null;
    const text = typeof value === "string" ? value : JSON.stringify(value, null, 2);
    const declaredChannel = String(detail.channel || "").trim().toLowerCase();
    if (declaredChannel === "completed") return null;
    if (type.endsWith(".stderr") || type.endsWith(".error") || declaredChannel === "stderr" || detail.stderr) {
      return { channel: "stderr", text };
    }
    if (type.endsWith(".stdout") || declaredChannel === "stdout" || detail.stdout || event?.tool_output) {
      return { channel: "stdout", text };
    }
    return { channel: "output", text };
  }

  function mergeExecutionChunk(current, incoming) {
    if (!incoming) return current;
    if (!current || incoming.startsWith(current)) return incoming;
    if (incoming === current) return current;
    return `${current}${incoming}`;
  }

  function executionOutputText(row) {
    const streams = row.outputStreams || {};
    const sections = [];
    if (streams.command) sections.push(`$ ${streams.command}`);
    if (streams.code) sections.push(`Python\n${streams.code}`);
    if (String(streams.stdout || "").trim()) sections.push(`stdout\n${String(streams.stdout).trimEnd()}`);
    if (String(streams.stderr || "").trim()) sections.push(`stderr\n${String(streams.stderr).trimEnd()}`);
    if (String(streams.output || "").trim()) sections.push(String(streams.output).trimEnd());
    return sections.join("\n\n");
  }

  function appendExecutionOutput(row, chunk) {
    if (row.inspector) return;
    if (!chunk?.text || !chunk?.channel) return;
    row.outputStreams ||= { command: "", stdout: "", stderr: "", output: "" };
    if (["command", "code"].includes(chunk.channel)) {
      row.outputStreams[chunk.channel] = chunk.text;
    } else {
      row.outputStreams[chunk.channel] = mergeExecutionChunk(
        String(row.outputStreams[chunk.channel] || ""),
        String(chunk.text),
      ).slice(-12000);
    }
    const rendered = executionOutputText(row);
    if (!rendered) return;
    if (!row.output) {
      const disclosure = document.createElement("details");
      disclosure.className = "event-output";
      const summary = document.createElement("summary");
      summary.textContent = "Show output";
      const pre = document.createElement("pre");
      disclosure.append(summary, pre);
      row.copy.append(disclosure);
      row.output = pre;
      row.outputSummary = summary;
    }
    row.output.textContent = rendered;
    if ((row.outputStreams.command || row.outputStreams.code) && !row.commandCopy) {
      const kind = row.outputStreams.command ? "command" : "code";
      row.commandCopy = copyButton(() => row.outputStreams.command || row.outputStreams.code || "", {
        label: `Copy ${kind}`, successMessage: kind === "command" ? "Command copied" : "Code copied",
        failureMessage: `Could not copy ${kind}`,
      });
      row.outputSummary.append(row.commandCopy);
    }
  }

  function attachLiveShell(row, turn, event) {
    if (!row.liveShell) {
      const disclosure = document.createElement("details");
      disclosure.className = "event-output shell-live";
      const summary = document.createElement("summary"), panel = document.createElement("div");
      row.commandCopy = copyButton(() => row.outputStreams?.command || "", {label: "Copy command"});
      summary.append(row.title, row.commandCopy); disclosure.append(summary, panel); row.copy.append(disclosure);
      row.output = panel; row.outputSummary = summary;
      const live = {disclosure, panel, initialEvent: event, latestEvent: event, disposed: false};
      row.liveShell = live;
      disclosure.addEventListener("toggle", async () => {
        if (!disclosure.open || live.disposed || live.loading || live.viewer) return;
        live.loading = true;
        const loading = document.createElement("p");
        loading.className = "output-loading";
        loading.setAttribute("role", "status");
        loading.textContent = "Loading output…";
        panel.replaceChildren(loading);
        try {
          const {mountShellInspector} = await import("./shell_live_stream.js?v=20261015-smto");
          if (!disclosure.open || !disclosure.isConnected || live.disposed) return;
          panel.replaceChildren();
          live.viewer = mountShellInspector({disclosure, panel, requestId: turn.requestId,
            operationId: executionKey(event, eventDetail(event)), initialEvent: live.initialEvent});
          live.viewer.update(live.latestEvent);
        } catch (_) { panel.textContent = "Could not load live output. Close and reopen to retry."; }
        finally { live.loading = false; }
      });
    }
    row.liveShell.latestEvent = event;
    row.liveShell.viewer?.update(event);
  }

  function executionTitle(event, detail, status, row) {
    const target = detail.execution_target || row?.executionTarget;
    const via = detail.transport_gateway || row?.transportGateway;
    const privilege = detail.privilege || row?.privilege;
    const location = target?.label ? ` · ${target.label}${target.kind === "ssh_remote" ? ` via ${via?.label || "Gateway"}` : ""}${privilege?.elevated ? " · Elevated" : ""}` : "";
    const command = row?.outputStreams?.command;
    const code = row?.outputStreams?.code;
    if (command || code) {
      const preview = command || `Python ${code}`;
      const prefix = status === "unknown" ? "Outcome unknown:"
        : status === "not_executed" ? "Not run:"
        : status === "timed_out" ? "Shell timed out · process terminated:"
        : status === "cancelled" ? detail.cancellation_source === "user" ? "Shell terminated by user:" : "Stopped:"
        : status === "failed" ? "Failed:" : status === "completed"
          ? detail.status === "completed" ? "Completed" : "Ran" : "Running";
      const exit = status === "completed" && row?.exitCode !== undefined ? ` · exit ${row.exitCode}` : "";
      return `${prefix} ${preview.replace(/\s+/g, " ").trim()}${exit}${location}`;
    }
    const kind = String(detail.kind || "").toLowerCase();
    const generated = kind === "llm_text" || String(event?.title || "").toLowerCase().includes("text generation");
    if (status === "cancelled") return "Command cancelled";
    if (status === "failed") return generated ? "Text generation failed" : "Command failed";
    if (status === "completed") return generated ? "Generated text" : "Ran command";
    return generated ? "Generating text" : "Running command";
  }

  function executionExitCode(value) {
    if (value === null || value === undefined || value === "") return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function renderCommandOutcome(row, status = row.item.dataset.status, exitCode = row.exitCode) {
    if (!row.commandPreview && !row.item.classList.contains("shell-operation")) return;
    const state = String(status || "").toLowerCase().replaceAll(" ", "_");
    const failed = ["failed", "error", "timed_out", "failed_to_start"].includes(state)
      || row.commandProcessState === "failed_to_start";
    const completed = ["completed", "succeeded"].includes(state);
    if (!failed && !completed) {
      row.icon.replaceChildren();
      return;
    }
    const success = !failed && (exitCode == null || exitCode === 0);
    renderOutcome(row, success ? "success" : "failure", success ? "Command succeeded" : "Command failed");
  }

  function renderOutcome(row, outcome, label) {
    const mark = document.createElement("span");
    mark.className = "command-outcome";
    mark.dataset.outcome = outcome;
    mark.dataset.uiSymbol = {success: "check", failure: "cross", warning: "warning"}[outcome];
    mark.textContent = {success: "✓", failure: "×", warning: "!"}[outcome];
    mark.setAttribute("role", "img");
    mark.setAttribute("aria-label", label);
    mark.title = label;
    row.icon.replaceChildren(mark);
  }

  function renderExecutionEvent(turn, event) {
    const detail = eventDetail(event);
    const key = executionKey(event, detail);
    const type = String(event?.event_type || "");
    const failed = type.endsWith(".failed") || type.endsWith(".error") || ["error", "failed"].includes(detail.status) || String(event?.level || "") === "error";
    const completed = type.endsWith(".completed");
    const status = failed ? "failed" : completed ? "completed" : "running";
    let row = turn.actionItems.get(key);
    if (!row) {
      row = createWorkItem(turn, key, {
        title: executionTitle(event, detail, status),
        summary: String(detail.label || event?.summary || "").trim(),
        kind: "execution",
      });
      turn.actionItems.set(key, row);
    }
    actionIcons.update(row.typeIcon, actionIcons.resolve(detail, row.typeIcon.dataset.actionType === "runtime"
      ? "shell" : row.typeIcon.dataset.actionType));
    const exitCode = executionExitCode(detail.exit_code);
    const effectiveStatus = detail.process_state === "timed_out" || detail.error_kind === "timeout" ? "timed_out"
      : type.endsWith(".cancelled") || detail.process_state === "cancelled" || detail.status === "cancelled" || row.item.dataset.status === "cancelled" ? "cancelled" : completed && (detail.error_kind === "unknown_effect" || detail.status === "outcome_unknown" || detail.process_state === "outcome_unknown")
      ? "unknown" : completed && detail.executed === false ? "not_executed"
      : failed || row.item.dataset.status === "failed"
      ? "failed" : row.item.dataset.status === "completed" && status === "running" ? "completed" : status;
    row.item.dataset.level = effectiveStatus === "failed" ? "error" : "info";
    row.item.dataset.status = effectiveStatus;
    if (detail.process_state) row.commandProcessState = detail.process_state;
    if (detail.execution_target) row.executionTarget = detail.execution_target;
    if (detail.transport_gateway) row.transportGateway = detail.transport_gateway;
    if (detail.privilege) row.privilege = detail.privilege;
    const label = String(detail.label || "").trim();
    if (label) {
      row.summary.textContent = label;
      row.summary.hidden = false;
    }
    if (row.liveShell || (type === "execution.command.started" && detail.kind === "shell_command")) {
      row.outputStreams ||= {};
      if (detail.command) row.outputStreams.command = String(detail.command);
      attachLiveShell(row, turn, event);
    } else appendExecutionOutput(row, executionOutput(event, detail));
    if (exitCode !== null) row.exitCode = exitCode;
    activityPresentation.richLabel(row.title).textContent = executionTitle(event, detail, effectiveStatus, row);
    row.timingBase = activityPresentation.richLabel(row.title).textContent;
    row.commandPreview = row.outputStreams?.command || row.outputStreams?.code || "";
    if (row.commandPreview) {
      row.item.classList.add("command-row");
      row.icon.replaceChildren();
      row.summary.hidden = true;
      // The command itself is the disclosure, so completed rows stay one line.
      if (row.outputSummary && row.title.parentElement !== row.outputSummary) {
        row.outputSummary.replaceChildren(row.title, ...(row.commandCopy ? [row.commandCopy] : []));
      }
      row.outputSummary.title = `${row.commandPreview}${row.exitCode !== undefined ? `\nExit ${row.exitCode}` : ""}`;
    } else if (row.outputSummary && exitCode !== null) {
      row.outputSummary.textContent = `Show output · exit ${exitCode}`;
    }
    if (effectiveStatus === "failed" && row.output && !row.liveShell) row.output.closest("details").open = true;
    decorateOperationRow(turn, key);
    renderCommandOutcome(row);
    activityPresentation.decorateLabel(row.title, event, activityPresentation.outcome(event));
  }

  function decorateOperationRow(turn, key) {
    const row = turn.actionItems.get(key), operation = turn.activity.operations.get(key);
    if (!row || !operation) return;
    if (row.hasPresentation) {
      actionIcons.update(row.typeIcon, actionIcons.resolve(operation.presentation));
      activityPresentation.richLabel(row.title).textContent = activity.traceHeading(operation);
      row.summary.textContent = operation.presentation.trace_detail;
      const shell = operation.presentation.capability_id.startsWith("shell.")
        || operation.presentation.skill_label.startsWith("Shell");
      row.summary.hidden = !row.summary.textContent;
      row.item.dataset.status = operation.status;
      row.item.dataset.level = operation.status === "failed" ? "error" : "info";
      if (shell) {
        row.item.classList.add("shell-operation");
        renderCommandOutcome(row, operation.status, operation.exitCode ?? row.exitCode);
        if (!row.cue) {
          row.cue = document.createElement("span"); row.cue.className = "capability-cue";
          row.copy.prepend(row.cue);
        }
        row.cue.textContent = operation.presentation.skill_label;
      } else {
        row.item.classList.add("contextual-operation");
        row.icon.replaceChildren();
        if (operation.status === "completed") {
          const succeeded = !Number.isInteger(operation.exitCode) || operation.exitCode === 0;
          renderOutcome(row, succeeded ? "success" : "failure", succeeded ? "Action succeeded" : "Action failed");
        } else if (["failed", "timed_out"].includes(operation.status)) renderOutcome(row, "failure", "Action failed");
        row.title.title = [activityPresentation.richLabel(row.title).textContent, operation.presentation.context_detail].filter(Boolean).join(" · ");
        row.title.setAttribute("aria-label", `${operation.presentation.skill_label}: ${activityPresentation.richLabel(row.title).textContent}`);
        // The inspector retains its summary; the collapsed sentence already names the target.
        row.summary.hidden = Boolean(operation.presentation.compact_running_label) || !row.summary.textContent;
      }
      if (row.outputSummary) {
        row.outputSummary.title = operation.presentation.trace_detail;
        row.copy.insertBefore(row.outputSummary.parentElement, row.summary);
      }
    } else if (operation.elevated && !activityPresentation.richLabel(row.title).textContent.endsWith(" · Elevated")) {
      activityPresentation.richLabel(row.title).textContent += " · Elevated";
    }
  }

  function renderCapabilityEvent(turn, event) {
    const detail = eventDetail(event), key = executionKey(event, detail);
    const operation = turn.activity.operations.get(key);
    if (!operation) return;
    let row = turn.actionItems.get(key);
    if (!row) {
      row = createWorkItem(turn, key, {title: activity.traceHeading(operation)});
      turn.actionItems.set(key, row);
    }
    row.hasPresentation = true;
    activityPresentation.decorateLabel(row.title, {...event, detail: {...detail, presentation: operation.presentation}},
      activityPresentation.outcome(event));
    if (detail.process_state) row.commandProcessState = detail.process_state;
    decorateOperationRow(turn, key);
    // Shell keeps its existing streaming command/stdout/stderr disclosure.
    if (!row.output && (detail.capability_id !== "shell.command" || event.event_type === "invocation.completed")) {
      window.SMTOToolActivity?.attach(row, event.request_id || turn.requestId, detail, copyButton);
    }
  }

  function appendWorkEvent(turn, event) {
    if (event?.event_type === "task_context.context_submitted" || event?.event_type === "run.failed") void turn?.savedTaskContext?.refresh();
    if (event?.event_type === "task_context.source_available") {
      turn?.savedTaskContext?.source(event.detail || {});
      return;
    }
    event = activityPresentation.operationEvent(event);
    if (turn) window.SMTOProseActivity.observeMonitoring(turn.work.items, event);
    if (turn && event?.event_type === "conversation.message") {
      const row = window.SMTOProseActivity.message(turn.work.items, event,
        (body, text) => window.SMTOMarkdown.render(body, text));
      if (row) {
        turn.eventCount += 1;
        turn.work.activeItems = null;
        turn.work.root.hidden = false;
        turn.work.root.classList.add("progress-timeline");
        turn.work.root.open = true;
        if (event.detail.role === "assistant") {
          (turn.conversationQuestions ||= new Set()).add(event.detail.content.trim());
          for (const question of turn.actionArea.querySelectorAll(".clarification-question")) {
            question.hidden = turn.conversationQuestions.has(question.dataset.questionSource.trim());
          }
          if (turn.conversationQuestions.has(turn.answerText.trim())) {
            turn.answerText = ""; turn.answer.replaceChildren(); turn.meta.hidden = true;
          }
        }
      }
      return;
    }
    if (turn && event?.event_type === "agent_check.observed") {
      const detail = eventDetail(event), key = detail.agent_check_observation_id || `observation-${event.id}`;
      if (turn.checkObservations?.seen.has(key)) return;
      turn.checkObservations = window.SMTOAgentChecks.observationGroup(turn.runActions, turn.checkObservations,
        turn.assistant.querySelector(".result-document") || turn.executionInspector?.root || turn.runActions);
      window.SMTOAgentChecks.observationCard(turn.checkObservations.items, detail);
      turn.checkObservations.seen.add(key);
      return;
    }
    if (turn && String(event?.event_type || "").startsWith("capability_")
        && !String(event.event_type).startsWith("capability_selection.")) {
      const detail = eventDetail(event);
      const key = detail.capability_event_id || `capability-${event.id}`;
      if (turn.actionItems.has(key)) return;
      turn.work.root.hidden = false;
      const row = createWorkItem(turn, key, {kind: "control"});
      activityPresentation.richLabel(row.title).textContent = event.title || "Capability update";
      row.summary.textContent = [detail.requested_skill_ids?.join(" · "), detail.reason?.replaceAll("_", " "),
        detail.child_run_id ? "Continuing the same task" : ""].filter(Boolean).join(". ");
      row.summary.hidden = !row.summary.textContent;
      row.item.dataset.status = "completed";
      row.item.dataset.running = "false";
      turn.actionItems.set(key, row);
      renderOutcome(row, /blocked|denied|conflict|ambiguous|unavailable/.test(event.event_type) ? "warning" : "success", activityPresentation.richLabel(row.title).textContent);
      activityPresentation.decorateLabel(row.title, event, activityPresentation.outcome(event));
      window.SMTOProgressNarration.refresh(turn);
      return;
    }
    if (turn && String(event?.event_type || "").startsWith("capability_selection.")) {
      const detail = eventDetail(event);
      const started = event.event_type === "capability_selection.started";
      const changed = event.event_type === "capability_selection.changed";
      const degraded = event.event_type === "capability_selection.degraded";
      // Durable capability events retain their separate chronological identities.
      // Legacy events without IDs describe one start/result lifecycle.
      const key = detail.capability_event_id || (!started && !changed && turn.capabilitySelectionPendingKey)
        || `capability-selection-${event.id}`;
      if (started && !detail.capability_event_id) turn.capabilitySelectionPendingKey = key;
      else if (!changed) turn.capabilitySelectionPendingKey = null;
      const title = detail.label || event.title || (started ? "Selecting capabilities" : "Capabilities updated");
      const selected = detail.selected_skill_ids || [];
      const summary = [title.endsWith(` · ${selected.join(", ")}`) ? "" : selected.join(" · "),
        detail.dependency_tool_ids?.length ? `Required tools: ${detail.dependency_tool_ids.join(", ")}` : "",
        detail.unavailable_skill_ids?.length ? `Unavailable: ${detail.unavailable_skill_ids.join(", ")}` : "",
        detail.added_skill_ids?.length ? `Added: ${detail.added_skill_ids.join(", ")}` : "",
        detail.removed_skill_ids?.length ? `Removed: ${detail.removed_skill_ids.join(", ")}` : ""].filter(Boolean).join(". ");
      turn.work.root.hidden = false;
      const row = turn.actionItems.get(key) || createWorkItem(turn, key, {kind: "control"});
      row.key = key;
      turn.actionItems.set(key, row);
      activityPresentation.richLabel(row.title).textContent = title;
      row.summary.textContent = summary;
      row.summary.hidden = !summary;
      row.item.dataset.status = started && !detail.capability_event_id ? "running" : degraded ? "degraded" : "completed";
      row.item.dataset.running = String(started && !detail.capability_event_id);
      row.item.dataset.level = degraded ? "warning" : "info";
      if (started) row.icon.replaceChildren();
      else renderOutcome(row, degraded ? "warning" : "success",
        degraded ? "Capability selection used a fallback" : "Capabilities updated");
      activityPresentation.decorateLabel(row.title, event, activityPresentation.outcome(event));
      window.SMTOProgressNarration.refresh(turn);
      return;
    }
    if (turn && event?.event_type === "guard.strike") {
      window.SMTOAgentChecks.strikeCard(turn.actionArea, event.detail, null, {
        requestId: turn.requestId, conversationId: state.conversationId, status: "running", apiJson, notify: showToast,
        reload: rid => reloadResourceRecovery(rid, turn),
      });
    }
    const researchNotice = window.SMTOProseActivity.researchNotice(event);
    if (turn && researchNotice) {
      const key = `research-notice-${researchNotice.key}`;
      if (turn.actionItems.has(key)) return;
      const row = createWorkItem(turn, key, {title: researchNotice.title, kind: "control"});
      turn.actionItems.set(key, row);
      row.contextPosition = {start: Date.parse(event.timestamp), order: Number(event.id || event.index || 0)};
      row.item.dataset.researchNotice = "true";
      row.item.dataset.status = researchNotice.warning ? "blocked" : "completed";
      row.item.dataset.running = "false";
      renderOutcome(row, researchNotice.warning ? "warning" : "success", researchNotice.title);
      turn.work.root.hidden = false;
      renderTimingSpans(turn, new Set());
      window.SMTOProgressNarration.refresh(turn);
      return;
    }
    const rejection = window.SMTOProseActivity.policyRejection(event);
    if (turn && rejection) {
      const key = `policy-rejection-${rejection.key}`;
      const row = turn.actionItems.get(key)
        || createWorkItem(turn, key, {...rejection, kind: "control"});
      turn.actionItems.set(key, row);
      activityPresentation.richLabel(row.title).textContent = rejection.title;
      row.summary.textContent = rejection.summary;
      row.summary.hidden = false;
      row.item.dataset.policyRejection = "true";
      row.item.dataset.status = "rejected";
      row.item.dataset.running = "false";
      renderOutcome(row, "warning", "Action rejected");
      turn.work.root.hidden = false;
      window.SMTOProgressNarration.refresh(turn);
      return;
    }
    if (event?.event_type === "agent.final_response.retained") return;
    if (!turn) return;
    if (event.event_type === "user.steered") {
      if (window.SMTOProseActivity.steering(turn.work.items, event)) {
        turn.work.activeItems = null;
        turn.work.root.hidden = false;
        turn.eventCount += 1;
        if (turn === state.currentTurn) scrollToBottom();
      }
      return;
    }
    if (event.event_type?.startsWith("activity.supervision.")) {
      const group = window.SMTOProseActivity.monitoring(turn.work.items, event);
      if (group) {
        turn.work.activeItems = group.items;
        turn.eventCount += 1;
        turn.work.root.classList.add("progress-timeline");
        turn.work.root.open = true;
        turn.work.root.hidden = false;
      }
      return;
    }
    if (window.SMTOProgressNarration.render(turn, event)) {
      if (turn === state.currentTurn) scrollToBottom();
      return;
    }
    const changed = timing.reduce(turn.timing, event);
    if (!turn.historical) conversationTiming.event(turn.requestId, event);
    const display = eventShouldDisplay(event);
    if (!display && !changed.size) return;
    turn.work.root.hidden = false;
    if (["run.resumed", "run.steer_queued", "run.steer_cancelled"].includes(event.event_type)) {
      const steering = event.event_type === "run.steer_queued";
      const cancelled = event.event_type === "run.steer_cancelled";
      const key = `${event.event_type}-${event.id}`;
      if (!turn.actionItems.has(key)) turn.actionItems.set(key, createWorkItem(turn, key, {
        title: cancelled ? "Steer cancelled" : steering ? "Steering requested" : "Resumed task",
        summary: cancelled ? "Instruction withdrawn before processing." : steering ? "Instruction saved for the next safe decision." : "Continuing with preserved progress.", kind: "control",
      }));
      // Receipt of the instruction succeeded; application gets its own milestone.
      if (steering || cancelled) turn.actionItems.get(key).item.dataset.status = "completed";
    } else if (isCompactionEvent(event)) renderCompactionEvent(turn, event);
    else if (isTaskContractEvent(event)) renderTaskContractEvent(turn, event);
    else if (String(event.event_type).startsWith("invocation.")) renderCapabilityEvent(turn, event);
    else if (display) renderExecutionEvent(turn, event);
    const operationSpan = turn.timing.tools.get(executionKey(event, eventDetail(event)));
    if (display && operationSpan) changed.add(operationSpan);
    renderTimingSpans(turn, changed);
    if (turn === state.currentTurn) {
      timingView.select(turn.timing);
      timingView.refresh(changed);
    }
    updateCommandGroup(turn);
    if (!turn.historical && (display || ["llm.request", "llm.request.started", "sequence.started", "parallel.started"].includes(event.event_type))) scrollToBottom();
  }

  function renderTimingSpans(turn, changed) {
    for (const span of changed) {
      // Each model decision has an on-demand output inspector, including successful calls.
      const key = span.kind === "model" ? `model:${span.id}` : span.id;
      const group = ["sequence", "parallel", "batch"].includes(span.kind);
      let row = turn.actionItems.get(key);
      if (span.kind === "model") {
        if (!row) {
          row = createWorkItem(turn, key, {kind: "model"});
          turn.actionItems.set(key, row);
          row.modelActivity = document.createElement("details");
          row.modelActivity.className = "model-activity-detail";
          const summary = document.createElement("summary");
          summary.className = "model-activity-summary";
          summary.append(row.title);
          row.modelActivity.append(summary);
          row.copy.prepend(row.modelActivity);
          row.modelDisclosure = window.SMTOModelOutput.attach(row.modelActivity, turn.requestId, span.id);
        }
        row.item.dataset.status = span.status.toLowerCase();
        row.item.dataset.level = span.status === "Rejected" ? "warning" : "info";
        row.summary.textContent = span.reason_long || "";
        row.summary.hidden = !span.reason_long;
      }
      if (!row && group) {
        row = createWorkItem(turn, span.id, {kind: span.kind, title: span.label});
        turn.actionItems.set(span.id, row);
        if (span.kind === "sequence") {
          const cue = document.createElement("span"); cue.className = "capability-cue";
          cue.textContent = span.label; row.copy.prepend(cue);
        }
      }
      // Invocation events can create the row before the sequence starts.
      if (row && group && !row.children) {
        row.item.classList.add(`${span.kind}-item`);
        const disclosure = document.createElement("details");
        row.groupDisclosure = disclosure;
        disclosure.open = true;
        const summary = document.createElement("summary"); summary.textContent = "Show operations";
        disclosure.addEventListener("click", () => { row.groupDisclosureChosen = true; });
        row.children = document.createElement("div"); row.children.className = `${span.kind}-children`;
        disclosure.append(summary, row.children); row.copy.append(disclosure);
        // Replayed parent events may arrive after their command rows.
        for (const child of turn.actionItems.values()) {
          if (child.span?.parent === span.id) row.children.append(child.item);
        }
      }
      if (!row) continue;
      if (group) actionIcons.update(row.typeIcon, span.kind);
      row.span = span; row.item.tabIndex = -1;
      if (span.kind === "model") activityPresentation.decorateLabel(row.title, {
        event_type: span.terminal ? "llm.response" : "llm.request",
        detail: {call_id: span.id, phase: span.phase},
      }, span.status === "Rejected" ? "failure" : span.status === "Stopped" ? "cancelled" : span.terminal ? "success" : "running");
      renderCommandOutcome(row, span.background ? span.status : row.item.dataset.status, span.exitCode ?? row.exitCode);
      if (span.kind === "parallel" || span.kind === "batch") {
        row.item.dataset.status = span.status.toLowerCase().replaceAll(" ", "_");
        row.item.dataset.level = span.status === "Failed" ? "error" : "info";
        row.icon.replaceChildren();
        if (span.groupSummary !== undefined) {
          row.summary.textContent = span.groupSummary;
          row.summary.hidden = !span.groupSummary;
          const cue = row.copy.querySelector(".capability-cue");
          if (cue) cue.textContent = span.label;
          if (!row.groupDisclosureChosen && row.groupDisclosure) {
            row.groupDisclosure.open = !span.terminal || span.status !== "Completed";
          }
        }
      }
      row.title.setAttribute("aria-live", "off");
      // The conversation has aria-live=polite; elapsed text explicitly opts out.
      if (!row.timingDetail) {
        const disclosure = document.createElement("details"); disclosure.className = "timing-detail";
        const summary = document.createElement("summary"); summary.textContent = "Timing";
        row.timingDetail = document.createElement("div"); row.timingDetail.className = "timing-facts";
        row.timingDetail.setAttribute("aria-live", "off");
        disclosure.append(summary, row.timingDetail); row.copy.append(disclosure);
      }
      const outputDisclosure = row.groupDisclosure || row.modelDisclosure;
      if (outputDisclosure && !row.disclosures) {
        row.disclosures = document.createElement("div");
        row.disclosures.className = "activity-disclosures";
        row.disclosures.append(outputDisclosure, row.timingDetail.parentElement);
        (row.modelActivity || row.copy).append(row.disclosures);
      }
      const existingDetail = row.inspector?.disclosure || row.output?.closest("details");
      if (span.kind === "tool" && existingDetail && row.timingDetail.parentElement !== existingDetail) {
        const separate = row.timingDetail.closest(".timing-detail");
        existingDetail.append(row.timingDetail); separate?.remove();
      }
      if (span.kind === "tool") row.timingBase = row.hasPresentation
        ? activity.traceHeading(turn.activity.operations.get(span.id)) : row.timingBase || activityPresentation.richLabel(row.title).textContent;
      timingView.bind(span, row.item, now => {
        const ms = timing.duration(span, now);
        const base = span.kind === "tool" ? span.background
          ? `${span.label} · ${span.status}` : row.timingBase
          : span.kind === "model" ? `${timing.activityLabel(span)} · ${timing.format(ms)}`
            : timing.heading(span, now);
        const parts = base.split(" · ");
        if (span.kind === "sequence" && row.hasPresentation) {
          parts[0] = activity.traceHeading(turn.activity.operations.get(span.id));
        }
        const contextual = row.item.classList.contains("contextual-operation");
        if (contextual) {
          activityPresentation.richLabel(row.title).textContent = base;
          if (!row.compactTiming) {
            row.compactTiming = document.createElement("span");
            row.compactTiming.className = "activity-compact-timing";
            row.compactTiming.setAttribute("aria-live", "off");
            row.title.after(row.compactTiming);
          }
          window.SMTOTimingView.renderTimer(row.compactTiming,
            span.notRun || ms === null ? "" : timing.format(ms), {live: !span.terminal});
          row.compactTiming.hidden = Boolean(row.stats?.textContent && span.terminal);
          const detail = timing.detail(span, now);
          const inlineDetail = detail.replaceAll("\n", "  |  ");
          if (row.timingDetail.textContent !== inlineDetail) row.timingDetail.textContent = inlineDetail;
          row.title.title = [base, turn.activity.operations.get(span.id)?.presentation.context_detail,
            detail].filter(Boolean).join("\n");
          return;
        }
        if (span.kind === "tool" && ms !== null) parts.splice(1, 0, timing.format(ms));
        const timerIndex = span.notRun || (span.kind === "tool" && ms === null) ? -1 : 1;
        window.SMTOTimingView.renderTimer(activityPresentation.richLabel(row.title), timerIndex < 0 ? "" : parts[timerIndex], {
          live: !span.terminal,
          prefix: timerIndex < 0 ? parts.join(" · ") : `${parts[0]} · `,
          suffix: timerIndex < 0 || parts.length < 3 ? "" : ` · ${parts.slice(2).join(" · ")}`,
        });
        const detail = timing.detail(span, now);
        const inlineDetail = detail.replaceAll("\n", "  |  ");
        if (row.timingDetail.textContent !== inlineDetail) row.timingDetail.textContent = inlineDetail;
        row.title.title = detail;
      });
      if (span.parent) {
        const parent = turn.actionItems.get(span.parent);
        if (parent?.children && row.item.parentElement !== parent.children) parent.children.append(row.item);
      }
    }
    // Starts arriving after their terminal event are placed by persisted timestamp.
    const position = row => row.contextPosition || row.span;
    const rows = [...turn.actionItems.values()].filter(row => position(row) && !row.span?.parent);
    rows.sort((a, b) => Number.isFinite(position(a).start) && Number.isFinite(position(b).start)
      ? position(a).start - position(b).start || position(a).order - position(b).order
      : position(a).order - position(b).order);
    for (let index = 1; index < rows.length; index++) {
      const previous = rows[index - 1].item, current = rows[index].item;
      if (previous.parentElement === current.parentElement
          && previous.compareDocumentPosition(current) & Node.DOCUMENT_POSITION_PRECEDING) previous.after(current);
    }
    for (const row of turn.actionItems.values()) {
      const status = row.item.dataset.status, span = row.span;
      // Background launch receipts finish before their processes do.
      row.item.dataset.running = String(span
        ? !span.terminal && !span.notRun && (span.kind === "model" && ["Thinking", "Responding"].includes(span.status)
          || ["Running", "Starting"].includes(span.status)
            && (span.background || !status || status === "running"))
        : status === "running");
    }
    // Recompute every ancestor, even when only a nested child received an event.
    for (const [id, result] of timing.groupOutcomes(turn.timing)) {
      const row = turn.actionItems.get(id);
      if (!row) continue;
      row.item.dataset.running = String(result.running && !result.outcome);
      row.item.dataset.level = result.outcome === "failure" ? "error"
        : result.outcome === "warning" ? "warning" : "info";
      if (!result.outcome) { row.icon.replaceChildren(); continue; }
      const label = result.outcome === "success" ? "All steps succeeded"
        : result.outcome === "failure" ? "All steps failed"
          : result.failed ? `${result.failed} of ${result.total} steps failed` : "Some steps did not complete";
      renderOutcome(row, result.outcome, label);
    }
    window.SMTOProgressNarration.refresh(turn);
  }

  function startDurationClock(turn) {
    if (!turn) return;
    turn.completedTiming = null;
    turn.responseTiming.hidden = true;
    turn.responseTiming.querySelector(".response-time-summary")?.remove();
    renderResponseTokens(turn, turn.responseMetrics || {});
    clearInterval(turn.durationTimer);
    const now = () => window.SMTOStreamActivity.now(streamActivityHistory);
    const update = () => {
      const elapsed = timing.duration(turn.timing.run, now());
      window.SMTOTimingView.renderTimer(turn.work.duration,
        elapsed == null ? "" : formatDuration(elapsed), {live: elapsed != null && !turn.timing.run.terminal});
      turn.work.duration.title = elapsed == null ? "Start time unavailable" : "Elapsed from server start time";
      if (!document.hidden && turn.article.isConnected && turn.activity.status === "waiting_event") {
        // Countdown ticks use retained server timing and do not fetch or refresh workflow state.
        const resolved = turn === state.currentTurn
          ? activity.render(runActivityRoot, $("#run-activity-announcement"), turn.activity,
            {freshness: window.SMTOUiUpdates.freshness(), connection: window.SMTOUiUpdates.state(),
              showReconciliation: false}) : activity.resolve(turn.activity);
        activity.renderDetail(turn.work.statusDetail, resolved);
      }
    };
    update();
    turn.durationTimer = setInterval(update, 1000);
  }

  function completeWork(turn, trace) {
    if (!turn) return;
    clearInterval(turn.durationTimer);
    void turn.refreshFastCache?.();
    renderTimingSpans(turn, timing.restore(turn.timing, trace));
    conversationTiming.restore(turn.requestId, trace);
    conversationTiming.refresh();
    renderResponseTiming(turn, trace);
    if (turn === state.currentTurn) { timingView.select(turn.timing); timingView.refresh(); }
    const duration = durationFromTrace(trace);
    turn.work.root.dataset.running = "false";
    window.SMTOTimingView.renderTimer(turn.work.duration, duration ? formatDuration(duration) : "");
    const status = activity.userStatus(trace);
    window.SMTOProgressNarration.refresh(turn, status);
    renderTaskActivityStatus(turn, activity.resolve({...turn.activity, status}));
    updateCommandGroup(turn);
    if (!turn.eventCount && !turn.lazyActivity) turn.work.root.hidden = ["completed", "answered"].includes(status);
  }

  function cleanExecutionText(value) {
    return String(value || "")
      .replace(/\u001b\[[0-?]*[ -/]*[@-~]/g, "")
      .replace(/\r\n/g, "\n")
      .trim();
  }

  function genericCompletionResponse(markdown) {
    const text = String(markdown || "").trim();
    return /^Done\.\s+The requested work completed successfully\./i.test(text)
      || /^The requested work completed successfully\b/i.test(text);
  }

  function usefulBackendResponse(markdown) {
    const text = String(markdown || "").replace(/\r\n/g, "\n").trim();
    if (!text) return "";
    const agentHeading = /^##\s+Agent Response\s*$/im.exec(text);
    if (agentHeading) {
      return text
        .slice(agentHeading.index + agentHeading[0].length)
        .replace(/^\s*Evidence refs?:.*$/gim, "")
        .trim();
    }
    const streamingHeading = /^##\s+Streaming Complete\s*$/im.exec(text);
    const leading = streamingHeading ? text.slice(0, streamingHeading.index).trim() : text;
    return genericCompletionResponse(leading) ? "" : leading;
  }

  function markdownCodeBlock(value) {
    const text = cleanExecutionText(value);
    if (!text) return "";
    const fence = text.includes("```") ? "````" : "```";
    return `${fence}text\n${text}\n${fence}`;
  }

  function executionFacts(turn) {
    return Array.from(turn?.actionItems?.values?.() || []).map((row) => ({
      command: String(row?.outputStreams?.command || "").trim(),
      stdout: cleanExecutionText(row?.outputStreams?.stdout),
      stderr: cleanExecutionText(row?.outputStreams?.stderr),
      exitCode: executionExitCode(row?.exitCode),
      status: String(row?.item?.dataset?.status || ""),
      label: String(row?.summary?.textContent || "").trim(),
    }));
  }

  function gitStatusCompletionSummary(facts) {
    const fact = facts.find((item) => /^git\s+(?:-[A-Za-z]\s+\S+\s+)*status\b/i.test(item.command));
    if (!fact || fact.exitCode !== 0) return "";
    const output = fact.stdout;
    const clean = /nothing to commit, working tree clean/i.test(output)
      || (!output && /(?:--short\b|--porcelain\b)/i.test(fact.command));
    if (clean) {
      const branch = /^On branch\s+(.+)$/im.exec(output)?.[1]?.trim();
      const upstream = /^Your branch is up to date with ['`](.+?)['`]\.?$/im.exec(output)?.[1]?.trim();
      const branchNote = branch && upstream
        ? ` The current branch \`${branch.replaceAll("`", "\\`")}\` is up to date with \`${upstream.replaceAll("`", "\\`")}\`.`
        : upstream ? ` The branch is up to date with \`${upstream.replaceAll("`", "\\`")}\`.` : "";
      return `The repository is clean—there are no uncommitted changes.${branchNote}`;
    }
    if (output) {
      return `The repository has uncommitted changes.\n\n${markdownCodeBlock(output)}`;
    }
    return "The repository status check completed successfully, but it produced no output.";
  }

  function groundedCompletionSummary(turn) {
    const facts = executionFacts(turn);
    const gitStatusSummary = gitStatusCompletionSummary(facts);
    if (gitStatusSummary) return `## Summary\n\n${gitStatusSummary}`;

    const successfulGitAdd = facts.find((item) => /(?:^|\s)git\s+add\b/i.test(item.command) && item.exitCode === 0);
    if (successfulGitAdd) {
      return "## Summary\n\nThe requested repository changes were staged successfully.";
    }

    const usefulFacts = facts.filter((item) => item.stdout || item.stderr);
    if (usefulFacts.length) {
      const output = usefulFacts
        .slice(0, 3)
        .map((item) => item.stdout || item.stderr)
        .filter(Boolean)
        .join("\n\n");
      return `## Observed output\n\n${markdownCodeBlock(output)}`;
    }
    const successfulCommand = facts.find((item) => item.exitCode === 0 && item.status === "completed");
    if (successfulCommand?.command) {
      return `## Summary\n\nThe command \`${successfulCommand.command.replaceAll("`", "\\`")}\` completed successfully with no output.`;
    }
    const completedCommand = facts.find((item) => item.status === "completed" && item.exitCode !== null);
    if (completedCommand) return `The process completed with exit code ${completedCommand.exitCode} and no output.`;
    return "The run ended without a final answer. Review its tool results before treating the task as complete.";
  }

  function completionAnswerMarkdown(turn, trace, markdown) {
    if (trace?.response_metrics?.task_summary?.silent === true) return "";
    const useful = usefulBackendResponse(markdown);
    if (useful) return useful;
    const outcome = activity.userStatus(trace);
    if (window.SMTOTaskLifecycle.incomplete.has(outcome)) {
      const text = String(markdown || "").trim();
      if (text) return text;
      const notice = `Run ${outcome}; completion was not established.`;
      turn.generatedNotice = {text: notice, status: outcome};
      return notice;
    }
    if (["completed", "answered"].includes(outcome)) return groundedCompletionSummary(turn);
    return String(markdown || "").trim();
  }

  function appendFastPathMeta(meta, summary) {
    if (summary?.used !== true) return;
    const refreshed = summary.refreshed === true;
    const speed = Number.isInteger(summary.speedup_percent) && summary.speedup_percent >= 10
      && summary.speedup_percent <= 100 && !refreshed ? summary.speedup_percent : null;
    const chip = document.createElement("span");
    chip.className = "assistant-fast-path fast-path-cue";
    chip.tabIndex = 0;
    const label = refreshed ? "Fast path refreshed" : `Fast path${speed !== null ? ` · ${speed}% faster` : ""}`;
    const detail = refreshed ? "A repaired verified execution path was saved. Fresh tools were executed."
      : "Verified execution path reused for this exact task. Fresh tools were executed."
        + (speed !== null ? ` Measured Agent model/tool work was ${speed}% lower than the successful run that created this path. User wait time is excluded.` : "");
    chip.title = detail;
    chip.setAttribute("aria-label", `${label}. ${detail}`);
    chip.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m13 2-9 12h7l-1 8 10-12h-7l1-8Z"/></svg>';
    chip.append(document.createTextNode(label));
    meta.append(chip);
  }

  const taskFork = window.SMTOTaskFork.create({
    apiJson, currentId: () => state.conversationId, openConversation, conversationUrl,
    focusComposer: () => {
      if (!document.hidden && !document.activeElement?.closest(".final-response-feedback")) {
        elements.input.focus();
      }
    }, notify: showToast,
  });

  function archiveTurnAnswer(turn, answer) {
    (turn.archivedAnswers ||= new Map()).set(answer.id, answer.text.trim());
    const currentId = turn.retainedFinal?.id || turn.responseMetrics?.final_response?.decision_id;
    if (currentId === answer.id && turn.answerText.trim() === answer.text.trim()) {
      turn.messageTimes?.clear();
      turn.retainedFinal = null; turn.answerText = ""; turn.answer.replaceChildren();
      turn.meta.replaceChildren(); turn.meta.hidden = true;
    }
  }

  function renderAnswer(turn, markdown, { error = false, metrics = null } = {}) {
    if (!turn) return;
    renderApprovedPlan(turn, {response_metrics: metrics});
    if (metrics?.final_response) error = false;
    const canonicalText = String(markdown || "").trim();
    if (turn.generatedNotice?.text !== canonicalText || metrics?.final_response) turn.generatedNotice = null;
    if (turn.archivedAnswers?.get(metrics?.final_response?.decision_id) === canonicalText) return;
    if (turn.conversationQuestions?.has(canonicalText) && !activity.terminal.has(turn.activity.status)) {
      turn.answerText = ""; turn.answer.replaceChildren(); turn.meta.hidden = true;
      return;
    }
    // History includes running continuations before they have an answer. An
    // empty snapshot is not a completion, and must not close a live preview.
    if (!canonicalText && !error && !activity.terminal.has(turn.activity.status)) return;
    const outcome = metrics?.native_outcome || turn.activity.status;
    const retained = metrics?.final_response || turn.retainedFinal?.text === canonicalText;
    if (!retained && ["partial", "blocked", "failed", "paused_budget"].includes(outcome)) {
      turn.transientNotice = canonicalText;
    } else if (retained || turn.transientNotice !== canonicalText) turn.transientNotice = null;
    const promote = !error && turn.answer.dataset.provisional === "true"
      && turn.answerText === canonicalText;
    clearTimeout(turn.previewTimer);
    turn.previewTimer = null;
    turn.previewClosed = true;
    delete turn.answer.dataset.provisional;
    turn.answer.removeAttribute("aria-busy");
    turn.finalizing.hidden = true;
    turn.previewCorrection = false;
    turn.answerText = canonicalText;
    commandPalette?.update();
    turn.responseMetrics = metrics;
    if (metrics?.message_timestamps) turn.messageTimes?.restore({response_metrics: metrics});
    turn.answer.classList.toggle("is-error", error);
    const silent = metrics?.task_summary?.silent === true && !metrics?.final_response;
    turn.answer.hidden = silent;
    if (silent) {
      turn.answerText = "";
      turn.answer.replaceChildren();
    } else if (!promote) {
      window.SMTOMarkdown.render(turn.answer, turn.answerText || (error ? "The run failed without an error message." : "Done."));
    }
    turn.meta.replaceChildren();
    if (!promote) decorateCodeBlocks(turn.answer);
    if (silent) {
      const completed = document.createElement("span");
      completed.className = "task-completed";
      completed.innerHTML = '<span data-ui-symbol="check">✓</span> Completed';
      turn.meta.append(completed);
    } else {
      turn.meta.append(copyButton(() => turn.answerText));
    }
    if (!error) appendFastPathMeta(turn.meta, metrics?.execution_cache);
    if (!error && metrics?.direct_completion?.used === true) {
      const direct = document.createElement("span");
      direct.className = "direct-result-meta"; direct.textContent = "Direct result";
      turn.meta.append(direct);
    }
    turn.meta.hidden = false;
    window.SMTOTaskSummary?.attach(turn, metrics?.task_summary, {
      apiJson, conversationId: state.conversationId,
    });
    taskFork.attach(turn);
    syncAnswerState(turn);
  }

  function syncAnswerState(turn) {
    if (!turn) return;
    turn.answer.dataset.status = turn.activity.status;
    const active = ["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status);
    const resumedPause = turn.activity.status !== "paused"
      && turn.answerText === "Paused after the current action. Progress and results are preserved.";
    const expiredWait = !turn.responseMetrics?.final_response
      && window.SMTOTaskLifecycle.obsoleteWaitNotice(turn.answerText, turn.activity.status);
    const expiredNotice = turn.generatedNotice?.text === turn.answerText
      && (turn.generatedNotice.status !== turn.activity.status || turn.replyResume?.pending);
    // Runtime failure summaries expire on recovery; retained answers and tool history do not.
    if (!expiredNotice && !expiredWait && !resumedPause && !(active && turn.transientNotice && turn.answerText === turn.transientNotice)) return;
    if (turn.retainedFinal?.text === turn.answerText) return;
    turn.messageTimes?.clear();
    turn.answerText = "";
    turn.generatedNotice = null;
    turn.answer.replaceChildren();
    turn.answer.classList.remove("is-error");
    turn.responseMetrics = null;
    turn.meta.replaceChildren();
    turn.meta.hidden = true;
  }

  function clearAnswerPreview(turn) {
    clearTimeout(turn.previewTimer);
    turn.previewTimer = null;
    turn.previewText = "";
    turn.previewCorrection = false;
    turn.finalizing.hidden = true;
    turn.answer.removeAttribute("aria-busy");
    if (turn.answer.dataset.provisional === "true") {
      turn.messageTimes?.clear();
      turn.answer.replaceChildren();
      turn.answerText = "";
      delete turn.answer.dataset.provisional;
    }
  }

  function renderUserFacingDelta(turn, event) {
    if (!turn) return;
    const previousAnswer = turn.retainedFinal || (turn.responseMetrics?.final_response
      ? {id: turn.responseMetrics.final_response.decision_id, text: turn.answerText, startedAt: turn.messageTimes?.startedAt()} : null);
    if (window.SMTOProseActivity.answerBoundary(turn.work.items, event,
      (body, text) => window.SMTOMarkdown.render(body, text), previousAnswer,
      answer => archiveTurnAnswer(turn, answer))) {
      clearAnswerPreview(turn);
      turn.messageTimes?.clear();
      turn.retainedFinal = null; turn.finalCorrectionOnly = false;
      turn.answerText = ""; turn.answer.replaceChildren(); turn.answer.classList.remove("is-error");
      turn.responseMetrics = null; turn.transientNotice = null;
      turn.meta.replaceChildren(); turn.meta.hidden = true;
      turn.work.activeItems = null;
      turn.work.root.classList.add("progress-timeline"); turn.work.root.open = true; turn.work.root.hidden = false;
    }
    if (window.SMTOFinalResponse.retain(turn, event)) return;
    const sequence = Number(event?.id || 0);
    if (sequence && sequence <= (turn.previewEventId || 0)) return;
    if (sequence) turn.previewEventId = sequence;
    const detail = event?.detail && typeof event.detail === "object" ? event.detail : {};
    const type = event?.event_type;
    if (type === "llm.error" && detail.final_content_preserved === true) {
      turn.previewClosed = true;
      return;
    }
    const rejected = ["completion.rejected", "provider.response_rejected"].includes(type);
    if (rejected && detail.correction_only === true) {
      if (detail.call_id && turn.previewCallId && detail.call_id !== turn.previewCallId) return;
      clearTimeout(turn.previewTimer);
      turn.previewTimer = null;
      turn.previewCorrection = turn.answer.dataset.provisional === "true";
      turn.previewClosed = true;
      return;
    }
    if (["model.started", "request.running", "run.resumed"].includes(type)
        || (type === "llm.request" && event.stage === "native_decision")) {
      if (type === "model.started") turn.finalCorrectionOnly = !!turn.retainedFinal && detail.completion_only === true;
      const keep = turn.previewCorrection && (type === "llm.request"
        || (type === "model.started" && detail.completion_only === true));
      if (!keep) clearAnswerPreview(turn);
      // Bind the replacement stream to its own cumulative text/call ID while
      // leaving the last rendered candidate visible until the first new delta.
      turn.previewText = "";
      turn.previewCallId = detail.call_id || "";
      turn.previewClosed = turn.finalCorrectionOnly === true;
      return;
    }
    if (type === "request.completed" && ["answered", "completed"].includes(detail.outcome)) {
      clearTimeout(turn.previewTimer);
      turn.previewTimer = null;
      turn.previewClosed = true;
      // Only the authoritative final trace may promote this candidate.
      return;
    }
    if (["llm.error", "model.rejected", "provider.response_rejected", "completion.rejected",
      "model.response_discarded_for_pause", "run.paused", "request.completed", "request.suspended", "request.failed",
      "request.cancelled", "request.interrupted", "user.steered",
      "model.response_discarded_for_steering", "invocation.started"].includes(type)) {
      if (detail.call_id && turn.previewCallId && detail.call_id !== turn.previewCallId) return;
      clearAnswerPreview(turn);
      turn.previewClosed = true;
      return;
    }
    if (type === "llm.response.delta" && detail.user_facing_stream === true
        && detail.invalidated === true
        && (!turn.previewCallId || detail.call_id === turn.previewCallId)) {
      clearAnswerPreview(turn);
      turn.previewClosed = true;
      return;
    }
    if (type !== "llm.response.delta" || detail.user_facing_stream !== true
        || turn.previewClosed || turn.awaitingResume
        || !["pending", "running"].includes(turn.activity?.status)
        || (turn.previewCallId && detail.call_id !== turn.previewCallId)) return;
    turn.previewCallId = detail.call_id || turn.previewCallId;
    const streamed = String(detail.user_facing_text || "");
    if (!streamed || streamed === turn.previewText) return;
    turn.previewText = streamed;
    if (streamed.trim()) turn.messageTimes?.preview(event);
    const render = () => {
      turn.previewTimer = null;
      if (turn.previewClosed || !turn.article.isConnected) return;
      const viewport = elements.conversation.closest(".conversation-viewport");
      const nearBottom = viewport && viewport.scrollTop + viewport.clientHeight >= viewport.scrollHeight - 160;
      turn.answerText = turn.previewText;
      turn.answer.dataset.provisional = "true";
      turn.answer.setAttribute("aria-busy", "true");
      turn.finalizing.hidden = false;
      window.SMTOMarkdown.render(turn.answer, turn.previewText);
      decorateCodeBlocks(turn.answer);
      if (nearBottom && !document.hidden && composerBrowsing?.isFollowing()) viewport.scrollTo({top: viewport.scrollHeight, behavior: "instant"});
    };
    if (turn.answer.dataset.provisional !== "true") render();
    else if (!turn.previewTimer) turn.previewTimer = setTimeout(render, 80);
  }

  function renderDisplayDocument(turn, documentPayload) {
    if (!turn) return;
    let wrapper = turn.assistant.querySelector(".result-document");
    const sections = Array.isArray(documentPayload?.sections) ? documentPayload.sections : [];
    const outputs = sections.filter((section) => {
      if (Array.isArray(section?.rows) && section.rows.length) return true;
      const content = section?.content ?? section?.text ?? section?.preview;
      if (content === undefined || content === null || String(content).trim() === "") return false;
      const text = typeof content === "string" ? content.trim() : null;
      const isAnswer = !section.source_operation_id && !section.data_ref
        && [turn.answerText, documentPayload?.summary].some((answer) => answer?.trim() === text);
      return !isAnswer;
    });
    if (!outputs.length) {
      turn.resultsDisclosure?.dispose(); turn.resultsDisclosure = null; wrapper?.remove(); return;
    }
    if (!wrapper) {
      wrapper = document.createElement("details");
      wrapper.className = "result-document";
      const summary = document.createElement("summary");
      summary.textContent = "Results";
      wrapper.append(summary);
      turn.resultsDisclosure = window.SMTOConversationSnapshot.disclosureAction({
        actionContainer: turn.runActions, panel: wrapper, label: "Results"});
      turn.resultsDisclosure.action.classList.add("run-results-action");
      turn.runActions.querySelector(".run-checks-action")?.before(turn.resultsDisclosure.action);
      (turn.executionInspector?.root || turn.runActions).after(wrapper);
    }
    wrapper.querySelectorAll(".result-section").forEach(section => section.remove());
    outputs.forEach((section, index) => {
      const output = document.createElement("div");
      output.className = "result-section";
      const title = document.createElement("h3");
      const action = turn.actionItems.get(section.source_operation_id || section.data_ref);
      title.textContent = String(section.title || action?.commandPreview || `Output ${index + 1}`);
      output.append(title);
      const rows = Array.isArray(section?.rows) ? section.rows : [];
      if (rows.length) {
        const tableWrap = document.createElement("div");
        tableWrap.className = "result-table-wrap";
        const table = document.createElement("table");
        const columns = Array.isArray(section.columns) && section.columns.length
          ? section.columns
          : Object.keys(rows[0] || {});
        const head = document.createElement("thead");
        const headRow = document.createElement("tr");
        columns.forEach((column) => {
          const th = document.createElement("th");
          th.textContent = String(column);
          headRow.append(th);
        });
        head.append(headRow);
        const body = document.createElement("tbody");
        rows.slice(0, 100).forEach((row) => {
          const tr = document.createElement("tr");
          columns.forEach((column) => {
            const td = document.createElement("td");
            const value = row?.[column];
            td.textContent = typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
            tr.append(td);
          });
          body.append(tr);
        });
        table.append(head, body);
        tableWrap.append(table);
        output.append(tableWrap);
      } else {
        const content = section?.content ?? section?.text ?? section?.preview;
        if (content !== undefined && content !== null) {
          const pre = document.createElement("pre");
          pre.textContent = typeof content === "string" ? content : JSON.stringify(content, null, 2);
          output.append(pre);
        }
      }
      wrapper.append(output);
    });
  }

  function actionPreview(actions) {
    return actions.map((action) => {
      const capability = action?.capability_id || action?.kind || "Unknown operation";
      const display = action?.display;
      const identity = capability + (display?.privileged === true ? " · Privileged" : "");
      const title = typeof display?.title === "string" ? display.title : "";
      const summary = typeof display?.summary === "string"
        ? display.summary : "Operation requires approval";
      return [identity, title !== capability && title !== summary ? title : "", summary]
        .filter(Boolean).join("\n");
    }).join("\n\n");
  }

  function renderConfirmation(turn, trace) {
    const actions = Array.isArray(trace?.confirmation_actions) ? trace.confirmation_actions : [];
    const card = document.createElement("section");
    card.className = "action-card approval-card";
    card.dataset.authorityRequestId = actions[0]?.authority_request_id || "";
    card.innerHTML = '<header class="approval-heading"><h3>Approval needed</h3><p>I need your approval before continuing.</p></header>';
    if (actions.length) {
      const preview = document.createElement("pre");
      preview.className = "action-preview";
      preview.textContent = actionPreview(actions);
      card.append(preview);
    }
    const buttons = document.createElement("div");
    buttons.className = "action-buttons";
    const approve = document.createElement("button");
    approve.type = "button";
    approve.className = "action-button primary";
    approve.textContent = "Approve once";
    const deny = document.createElement("button");
    deny.type = "button";
    deny.className = "action-button";
    deny.textContent = "Deny / stop task";
    const decisionScope = document.createElement("select"); decisionScope.setAttribute("aria-label", "Apply decision to");
    const scopeLabels = {action: "This action", prompt: "This prompt", conversation: "This conversation", global: "Global"};
    for (const value of ["action", ...new Set(actions.flatMap(action => action.permission_scopes || []))]) {
      const option = document.createElement("option"); option.value = value; option.textContent = scopeLabels[value]; decisionScope.append(option);
    }
    decisionScope.onchange = () => { approve.textContent = decisionScope.value === "action" ? "Approve once" : "Allow"; };
    const decide = action => {
      const scope = decisionScope.value;
      void submitConfirmation(trace.request_id, action, card, scope === "action" ? null
        : {scope, policy: {mode: action === "approve" ? "full_access" : "deny"},
          expected_revision: actions[0]?.permission_scope_revisions?.[scope]});
    };
    approve.addEventListener("click", () => decide("approve"));
    deny.addEventListener("click", () => decide("deny"));
    const scopeLabel = document.createElement("label");
    scopeLabel.className = "approval-scope";
    const scopeText = document.createElement("span");
    scopeText.className = "approval-scope-label";
    scopeText.textContent = "Apply decision to";
    const scopeControl = document.createElement("span");
    scopeControl.className = "select-control permission-control";
    const scopeArrow = document.createElement("span");
    scopeArrow.className = "select-arrow";
    scopeArrow.setAttribute("aria-hidden", "true");
    scopeArrow.textContent = "▾";
    scopeControl.append(decisionScope, scopeArrow);
    scopeLabel.append(scopeText, scopeControl);
    card.append(scopeLabel);
    buttons.append(approve);
    const grants = actions.flatMap(action => action.permission_grants || []);
    if (grants.length) {
      const menu = document.createElement("details"); menu.className = "permission-grants";
      const label = document.createElement("summary"); label.textContent = "Allow…"; menu.append(label);
      for (const grant of grants) {
        const option = document.createElement("button"); option.type = "button"; option.className = "action-button"; option.textContent = grant.label;
        option.onclick = () => submitConfirmation(trace.request_id, "approve", card, {
          scope: grant.scope, rule: grant.rule, expected_revision: grant.expected_revision,
        });
        menu.append(option);
      }
      buttons.append(menu);
    }
    const edit = document.createElement("button"); edit.type = "button"; edit.className = "action-button"; edit.textContent = "Open Permissions";
    edit.onclick = () => permissionPolicy.open({requestId: trace.request_id});
    buttons.append(deny, edit);
    card.append(buttons);
    turn.actionArea.append(card);
  }

  function clarificationOptionLabel(option) {
    return String(option?.label || option?.title || option?.value || option?.option_id || "Use this option");
  }

  function renderClarification(turn, trace) {
    const request = trace?.clarification_request && typeof trace.clarification_request === "object"
      ? trace.clarification_request
      : {};
    turn.clarificationRequest = request;
    const card = document.createElement("section");
    card.className = "action-card";
    const heading = document.createElement("h3");
    heading.textContent = "I need your input";
    const question = document.createElement("div");
    question.className = "clarification-question markdown";
    // Match duplicate conversation messages against the source, before Markdown changes the text.
    question.dataset.questionSource = String(request.question || request.missing_information || "What should I use to continue?");
    window.SMTOMarkdown.render(question, question.dataset.questionSource);
    question.hidden = turn.conversationQuestions?.has(question.dataset.questionSource.trim()) || false;
    card.append(heading, question);
    const options = Array.isArray(request.options) ? request.options : [];
    if (options.length) {
      const optionArea = document.createElement("div");
      optionArea.className = "clarification-options";
      options.forEach((option, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "option-button";
        button.textContent = clarificationOptionLabel(option) + (request.recommended_id === option.option_id ? " (Recommended)" : "");
        if (option.description) { const description = document.createElement("span"); description.className = "choice-description"; description.textContent = option.description; button.append(description); }
        button.addEventListener("click", () => submitClarification(trace.request_id, {
          answer: String(option.value || option.label || option.title || option.option_id || "Selected option"),
          selected_option_id: String(option.option_id || index),
        }, card));
        optionArea.append(button);
      });
      card.append(optionArea);
    }
    if (request.allow_freeform !== false || !options.length) {
      const form = document.createElement("form");
      form.className = "clarification-form";
      const input = document.createElement("textarea");
      input.rows = 2;
      input.className = "clarification-input chat-field-control";
      input.placeholder = options.length ? "Other — type your answer" : "Type your answer";
      input.setAttribute("aria-label", options.length ? "Other answer" : "Your answer");
      input.required = true;
      const send = document.createElement("button");
      send.className = "clarification-submit";
      send.type = "submit";
      send.textContent = "Continue";
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        if (input.value.trim()) submitClarification(trace.request_id, { answer: input.value }, card);
      });
      input.addEventListener("keydown", event => {
        if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
          event.preventDefault(); form.requestSubmit();
        }
      });
      form.append(input, send);
      card.append(form);
    }
    turn.actionArea.append(card);
  }

  function renderNeededAction(turn, trace) {
    // Snapshot updates must not replace controls that own an in-flight reply.
    if (turn.actionArea.getAttribute("aria-busy") === "true") return;
    if (observeReply(turn, trace)) return;
    if (window.SMTOTaskLifecycle.answeredQuestion(turn.replyResume, trace))
      trace = {...trace, clarification_required: false, clarification_request: null};
    turn.inlineInteraction = Boolean(trace?.confirmation_required || trace?.clarification_required);
    if (turn.inlineInteraction) turn.inlineSteer?.update(null);
    const interactionKey = JSON.stringify([trace?.confirmation_required, trace?.confirmation_actions,
      trace?.clarification_required, trace?.clarification_request]);
    if (turn.inlineInteraction && turn.interactionKey === interactionKey
        && turn.actionArea.querySelector(".action-card")) {
      updateSubmitState();
      return;
    }
    turn.interactionKey = interactionKey;
    const completion = trace?.response_metrics?.final_response || trace?.native_profile?.final_response;
    if (!window.SMTOAgentChecks.stateOf(trace)?.guard_strikes?.length && completion?.feedback && !trace?.confirmation_required && !trace?.clarification_required
        && completion.decision_id === turn.completionDecision?.decision_id
        && ["check_id", "enabled", "title", "explanation", "recovery", "reason"].every(
          key => completion.feedback[key] === turn.completionDecision?.feedback?.[key])
        && turn.actionArea.querySelector(".final-response-feedback")) {
      // Repeated terminal projections must preserve focus, checkbox intent, and
      // the in-flight submission guard on the existing decision controls.
      updateSubmitState();
      return;
    }
    turn.completionDecision = completion;
    if (renderPlanAction(turn, trace)) return;
    const checks = window.SMTOAgentChecks.stateOf(trace);
    const recovery = turn.resourceRecoveryState || checks;
    if (recovery) trace = {...trace, agent_checks: {
      ...checks,
      resource_reconciliation_request: recovery.resource_reconciliation_request || null,
      resource_recovery_notices: recovery.resource_recovery_notices || [],
    }};
    turn.agentChecksSnapshot = window.SMTOAgentChecks.stateOf(trace);
    // Timing and other executions can change the conversation snapshot without
    // changing these controls. Keep their DOM, focus and open policy panels.
    const actionKey = JSON.stringify([trace?.outcome || trace?.final_status || trace?.status,
      Boolean(trace?.confirmation_required), trace?.confirmation_actions || [],
      Boolean(trace?.clarification_required), trace?.clarification_request || null,
      trace?.error_detail || null, completion || null, turn.agentChecksSnapshot || null]);
    const actionRoot = turn.runActions || turn.meta;
    if (turn.actionRenderKey === actionKey
        && turn.actionRenderNodes?.length === turn.actionArea.children.length
        && turn.actionRenderNodes.every((node, index) => turn.actionArea.children[index] === node)
        && turn.agentChecksLink === actionRoot.querySelector(".agent-check-relaxed")) {
      updateSubmitState();
      return;
    }
    turn.actionArea.replaceChildren();
    turn.clarificationRequest = null;
    if (trace?.confirmation_required) renderConfirmation(turn, trace);
    if (trace?.clarification_required) renderClarification(turn, trace);
    window.SMTOErrors?.mount(turn.actionArea, trace?.error_detail);
    window.SMTOCompletionHandling.feedback(turn, trace, {
      apiJson, conversationId: state.conversationId, reload: reloadResourceRecovery, notify: showToast,
      onAccepted: resumeApprovedRun,
      refreshSettings: runtimeGuards.refresh,
      retry: (requestId, decisionId) => window.SMTONative.retryCompletion(requestId, decisionId),
    });
    turn.actionRenderKey = actionKey;
    turn.actionRenderNodes = [...turn.actionArea.children];
    turn.agentChecksLink = actionRoot.querySelector(".agent-check-relaxed");
    updateSubmitState();
  }

  function traceErrorText(trace) {
    const detail = trace?.error_detail;
    if (typeof detail === "string") return detail;
    if (detail && typeof detail === "object") {
      return String(detail.message_markdown || detail.message || detail.technical_detail || "");
    }
    return String(trace?.error || "");
  }

  async function reloadResourceRecovery(requestId, turn) {
    const snapshot = await apiJson(`/api/agent/native/${encodeURIComponent(requestId)}`);
    if (!turn.article.isConnected) return;
    turn.resourceRecoveryState = snapshot;
    window.SMTOResourceReconciliation.render(turn.actionArea, snapshot, {
      requestId, apiJson, onAccepted: resumeApprovedRun,
      reload: rid => reloadResourceRecovery(rid, turn),
    });
    await reloadRetainedFinal(requestId, turn);
    if (turn === state.currentTurn) await window.SMTONative.refresh();
  }

  async function reloadRetainedFinal(requestId, turn) {
    if (turn === state.currentTurn) return loadFinalTrace(requestId, turn);
    const trace = await apiJson(`/api/agent/trace/${encodeURIComponent(requestId)}/summary`);
    if (!turn.article.isConnected) return;
    renderAnswer(turn, trace.final_response, {metrics: trace.response_metrics});
    renderResponseTiming(turn, trace);
    renderNeededAction(turn, trace);
  }

  const finalReads = new Map();
  function loadFinalTrace(requestId, turn = state.turns.get(requestId)) {
    const key = `${requestId}:${turn?.traceGeneration || 0}`;
    if (finalReads.has(key)) return finalReads.get(key);
    const read = restoreFinalTrace(requestId, turn).finally(() => { if (finalReads.get(key) === read) finalReads.delete(key); });
    finalReads.set(key, read); return read;
  }
  async function restoreFinalTrace(requestId, turn) {
    if (turn?.awaitingResume) return null;
    const generation = turn?.traceGeneration || 0;
    const stillCurrent = () => turn
      ? turn.article.isConnected
        && (turn.traceGeneration || 0) === generation
      : state.requestId === requestId;
    try {
      const trace = await apiJson(`/api/agent/trace/${encodeURIComponent(requestId)}/summary`);
      // A password follow-up or a chat change can overtake this completion fetch.
      if (!stillCurrent()) return null;
      if (!trace.status && !trace.user_visible_status) return null;
      syncTraceCursor(turn, trace.created_at);
      const traceCursor = Number(trace.last_event_id || 0);
      if (turn && traceCursor && traceCursor < (turn.lastEventId || 0)) return null;
      if (observeReply(turn, trace)) {
        renderTurnActivity(turn);
        if (turn.replyResume.pending && !turn.source)
          connectTrace(requestId, turn.replyResume.streamUrl, turn, turn.lastEventId || 0, false, false);
        return trace;
      }
      const userStatus = activity.userStatus(trace);
      // Native completion can precede publication of the final trace message.
      // Keep listening until the trace writer settles instead of rendering an empty answer.
      const awaitingFinalTrace = ["answered", "completed"].includes(userStatus)
        && ["running", "pending"].includes(trace.status);
      const isStillRunning = awaitingFinalTrace
        || window.SMTOTaskLifecycle.replyHandoff(trace)
        || ["running", "pending", "waiting_job", "waiting_event"].includes(userStatus);
      if (turn) {
        turn.awaitingFinalTrace = awaitingFinalTrace;
        activity.setStatus(turn.activity, userStatus, {authoritative: true});
        renderTurnActivity(turn);
        if (isStillRunning) {
          renderResponseTiming(turn, trace);
          if (turn.historical && !turn.source) {
            // Restore the current cursor from a compact summary; old activity
            // stays behind its disclosure instead of replaying on refresh.
            turn.lastEventId = traceCursor;
            turn.historical = false;
            if (turn === state.currentTurn) {
              state.requestId = requestId; state.traceStatus = userStatus; setRunning(true);
            }
          }
          startDurationClock(turn);
          // Replaying a previous wait's request.completed can close the stream
          // after this same run has already resumed. Reattach from the fetched
          // cursor so subsequent operations and model activity still arrive.
          if (!turn.source) {
            connectTrace(requestId, `/api/agent/stream/${requestId}`, turn, turn.lastEventId || 0, false, false);
          }
          return trace;
        }
        closeTrace(turn);
        if (turn === state.currentTurn) updateContextMeter(trace.native_profile?.llm_context_usage || trace.response_metrics?.llm_context_usage);
        completeWork(turn, trace);
        const failed = userStatus === "failed";
        const cancelled = trace.status === "cancelled" || trace.status === "interrupted";
        const response = String(trace.final_response || "").trim();
        const errorText = traceErrorText(trace);
        if (response || errorText || (!trace.confirmation_required && !trace.clarification_required)) {
          const answerMarkdown = response
            ? completionAnswerMarkdown(turn, trace, response)
            : errorText || (cancelled ? "Run stopped." : completionAnswerMarkdown(turn, trace, ""));
          renderAnswer(turn, answerMarkdown, {
            error: failed,
            metrics: trace.response_metrics,
          });
        }
        renderDisplayDocument(turn, trace.display_document);
        renderNeededAction(turn, trace);
      }
      if (!turn || turn === state.currentTurn) {
        state.traceStatus = userStatus;
        if (!isStillRunning) setRunning(false);
        state.requestId = isStillRunning ? requestId : null;
        if (!window.SMTOSelectedConversation) await window.SMTONative?.refresh();
      } else window.SMTONative.renderTaskActions();
      if (window.SMTOSelectedConversation) void selectedConversation.refresh();
      else void promptQueue.reconcile();
      historyManagement.scheduleRefresh();
      scrollToBottom();
      return trace;
    } catch (error) {
      if (!stillCurrent()) return null;
      if (turn?.replyResume && (turn.replyResume.pending
          || ["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status))) {
        showToast("Response accepted. Could not refresh its progress; reconnecting…");
        setConnection("disconnected", "Reconnecting…");
        return null;
      }
      if (!turn || turn === state.currentTurn) setRunning(false);
      if (turn && !turn.retainedFinal) renderAnswer(turn, error.message || "Could not load the final response.", { error: true });
      else showToast(error.message || "Could not refresh completion status.");
      setConnection("disconnected", "Backend unavailable");
      return null;
    }
  }

  function handleTraceEvent(event, turn = state.currentTurn, { terminal = true } = {}) {
    if (!turn || (event.request_id && turn.requestId && event.request_id !== turn.requestId)) return;
    if (turn) turn.lastEventId = Math.max(turn.lastEventId || 0, Number(event?.id || 0));
    const id = String(event?.event_id || `${event?.request_id || ""}:${event?.id || ""}`);
    if (id && state.seenEventIds.has(id)) return;
    if (id) state.seenEventIds.add(id);
    const answeredWait = observeReply(turn, event);
    turn.messageTimes?.event(event);
    turn.historyLoader?.event(event);
    turn.visualization?.event(event);
    const activityChanged = !answeredWait && (!turn.awaitingResume || event.event_type === "request.running")
      && activity.reduce(turn.activity, event);
    const usage = event?.detail?.llm_context_usage || event?.detail?.runtime_profile?.llm_context_usage;
    if (usage) turn.contextUsage = usage;
    if (usage && turn === state.currentTurn && turn.article.isConnected) {
      const observedAt = Date.parse(event.timestamp);
      updateContextMeter(usage, Number.isFinite(observedAt) ? observedAt : undefined);
    }
    renderUserFacingDelta(turn, event);
    appendWorkEvent(turn, event);
    window.SMTOConversationSnapshot.boundActivity(turn.work.items, [turn.actionItems]);
    if (turn.work.activeItems && !turn.work.items.contains(turn.work.activeItems)) turn.work.activeItems = null;
    if (activityChanged) renderTurnActivity(turn);
    if (event.detail?.token_usage || usage) {
      turn.tokenUsage = window.SMTOResponseTokens.latest(turn.tokenUsage, event.detail.token_usage);
      renderResponseTokens(turn, turn.responseMetrics || {});
    }
    const type = String(event?.event_type || "");
    if (terminal && ["request.completed", "request.suspended", "request.failed", "request.cancelled", "request.interrupted"].includes(type)) {
      if (!answeredWait) closeTrace(turn);
      void loadFinalTrace(event.request_id, turn);
    }
  }

  function closeTrace(turn) {
    if (!turn) return;
    turn.source?.close();
    turn.source = null;
    clearTimeout(turn.reconnectTimer);
    turn.reconnectTimer = null;
  }

  function closeTraces() {
    for (const turn of state.turns.values()) closeTrace(turn);
  }

  function renderTurnActivity(turn) {
    if (turn.replyResume?.pending) {
      turn.activity.resuming = true;
      turn.inlineInteraction = false;
      turn.actionArea.replaceChildren();
    }
    commandPalette?.update();
    if (!["pending", "running", "waiting_job", "waiting_event", "paused", "paused_budget"].includes(turn.activity.status)) {
      turn.inlineSteer?.updateStatus(turn.activity.status);
    }
    syncAnswerState(turn);
    turn.work.root.dataset.running = String(["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status));
    window.SMTOProgressNarration.refresh(turn);
    if (turn === state.currentTurn) renderActivity();
    else renderTaskActivityStatus(turn);
  }

  function connectTrace(requestId, streamUrl, turn, afterId = 0, awaitingResume = false, select = true) {
    closeTrace(turn);
    if (select) {
      state.requestId = requestId;
      state.currentTurn = turn;
      void window.SMTONative?.refresh();
    }
    const url = new URL(streamUrl, window.location.href);
    if (afterId) url.searchParams.set("after_id", Math.max(afterId, Number(url.searchParams.get("after_id")) || 0));
    if (turn.traceCreatedAt) url.searchParams.set("trace_created_at", turn.traceCreatedAt);
    const source = new EventSource(url.href);
    window.SMTOReadPriority?.stream(source);
    turn.source = source;
    renderTurnActivity(turn);
    if (["pending", "running", "waiting_job", "waiting_event"].includes(turn.activity.status)) startDurationClock(turn);
    const live = () => turn.source === source && turn.article.isConnected;
    source.addEventListener("trace.cursor", message => {
      if (!live()) return;
      try { syncTraceCursor(turn, JSON.parse(message.data).created_at); } catch (_) {}
    });
    source.addEventListener("trace", (message) => {
      if (!live()) return;
      try {
        const event = JSON.parse(message.data);
        if (["request.running", "run.resumed"].includes(event.event_type)) {
          awaitingResume = false;
          turn.awaitingResume = false;
        }
        // A replayed terminal event from the previous attempt cannot close a resumed stream.
        handleTraceEvent(event, turn, { terminal: !awaitingResume });
      } catch (_error) {}
    });
    source.addEventListener("heartbeat", () => { if (live()) setConnection("connected"); });
    source.addEventListener("error", () => {
      if (!live()) return;
      closeTrace(turn);
      if (awaitingResume) {
        turn.reconnectTimer = setTimeout(() => {
          if (turn.article.isConnected && !turn.source && turn.awaitingResume) {
            connectTrace(requestId, streamUrl, turn, turn.lastEventId || afterId, true, false);
          }
        }, 1000);
        return;
      }
      void loadFinalTrace(requestId, turn).then((trace) => {
        if (turn.replyResume?.pending && !turn.source && turn.article.isConnected) {
          turn.reconnectTimer = setTimeout(() => {
            if (turn.replyResume?.pending && !turn.source && turn.article.isConnected)
              connectTrace(requestId, turn.replyResume.streamUrl, turn, turn.lastEventId || afterId, false, false);
          }, 1000);
          return;
        }
        if (!turn.source && trace && ["running", "pending"].includes(String(trace.status || ""))) {
          setConnection("disconnected", "Live stream disconnected");
          showToast("Live updates disconnected. Refresh to reconnect.");
        }
      });
    });
  }

  async function prepareAndSubmit(prompt, queuedSnapshot = null, lifecycle = {}) {
    const snapshot = JSON.parse(JSON.stringify(queuedSnapshot || lifecycle.snapshot || promptSnapshot(prompt)));
    const response = await promptQueue.enqueue(snapshot, {onAccepted: lifecycle.onAccepted});
    state.submitting = false; state.preparingDirect = false; updateSubmitState();
    if (response) {
      if (lifecycle.policySnapshot) void capabilityPolicy.requestAccepted(response.conversation_id, lifecycle.policySnapshot);
      if (lifecycle.permissionSnapshot) void permissionPolicy.requestAccepted(response.conversation_id, lifecycle.permissionSnapshot);
    } else { lifecycle.onFailure?.(promptQueue.failure()?.definite === true); showToast(promptQueue.failureMessage()); }
    return response;
  }

  /** Resolve the current interaction trace before submitting its continuation. */

  function observeReply(turn, source) {
    if (!turn) return false;
    turn.replyResume ||= window.SMTOTaskLifecycle.restoreReply(source);
    if (!turn.replyResume) return false;
    const pending = turn.replyResume.pending;
    const hold = window.SMTOTaskLifecycle.observeReply(turn.replyResume, source);
    if (pending) turn.activity.resuming = turn.replyResume.pending;
    return hold;
  }

  async function resumeInteractionTrace(payload, parentRequestId, answered = null) {
    const previous = state.turns.get(parentRequestId);
    const continued = payload.request_id !== parentRequestId;
    const lineage = continued ? {...payload, task_id: payload.task_id || previous?.taskId,
      continuation: payload.continuation || {parent_request_id: parentRequestId}} : payload;
    // A snapshot can mount (or even complete) this attempt before the POST returns.
    // The request identity owns its DOM, stream cursor and retained answer.
    const turn = state.turns.get(payload.request_id) || createTurn("", payload.request_id, {
      continuation: true, taskId: lineage.task_id,
      parentRequestId: continued ? parentRequestId : "",
    });
    setTurnActivityLineage(turn, lineage);
    setTurnAttemptPrompt(turn, lineage);
    if (answered && !continued) {
      turn.replyResume = window.SMTOTaskLifecycle.replyAccepted(payload, answered.question, answered);
      turn.replyResume.streamUrl = payload.stream_url || `/api/agent/stream/${payload.request_id}`;
      // Current evidence may already include a second question or a final answer.
      if ((turn.lastEventId || 0) > turn.replyResume.cursor) observeReply(turn, {
        request_id: turn.requestId, status: turn.activity.status, last_event_id: turn.lastEventId,
        clarification_request: turn.clarificationRequest,
      });
    }
    if (!turn.replyResume || turn.replyResume.pending) turn.clarificationRequest = null;
    turn.traceGeneration = (turn.traceGeneration || 0) + 1;
    turn.awaitingResume = false;
    if (!continued && !turn.retainedFinal && (!answered || turn.transientNotice
        || turn.generatedNotice || turn.answerText === answered.question.question)) {
      turn.answerText = ""; turn.answer.replaceChildren(); turn.meta.replaceChildren(); turn.meta.hidden = true;
    }
    if (!answered || continued || turn.replyResume?.pending) closeTrace(turn);
    state.currentTurn = turn;
    state.requestId = payload.request_id;
    if (turn.replyResume?.pending) {
      turn.inlineInteraction = false;
      setRunning(true);
      connectTrace(payload.request_id, turn.replyResume.streamUrl, turn, turn.lastEventId || 0, false, false);
    }
    if (continued && previous) void loadFinalTrace(parentRequestId, previous);
    // Read current truth: the acknowledgement may predate a completed child.
    await loadFinalTrace(payload.request_id, turn);
    if (turn.article.isConnected) void window.SMTONative.refresh();
  }

  async function submitConfirmation(parentRequestId, action, card, grant = null) {
    if (confirmationSubmissions.has(parentRequestId)) return false;
    confirmationSubmissions.add(parentRequestId);
    const navigation = state.navigationVersion;
    const area = card.closest(".action-area") || card;
    const controls = [...card.querySelectorAll("button, input, textarea, select")]
      .filter(control => !control.disabled);
    controls.forEach(control => { control.disabled = true; });
    area.setAttribute("aria-busy", "true");
    updateSubmitState();
    let accepted = false;
    try {
      if (grant?.scope === "global" && grant.policy?.mode === "full_access" && action === "approve") {
        const saved = await apiJson("/api/agent/permissions/global");
        if (saved.policy?.mode !== "full_access" && !window.confirm("Allow permission-gated operations across conversations without asking each time?\n\nNarrower conversation or prompt overrides still apply.")) return false;
      }
      if (action === "deny" && !grant) {
        await window.SMTONative.cancelCurrent(parentRequestId, {confirmation: true});
        accepted = true;
        area.removeAttribute("aria-busy");
        card.remove();
        await loadFinalTrace(parentRequestId, state.currentTurn);
        return true;
      }
      const payload = await apiJson(`/api/agent/confirmation/${encodeURIComponent(parentRequestId)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, context: {}, ...(grant ? {grant} : {}),
          ...(card?.dataset.authorityRequestId ? {authority_request_id: card.dataset.authorityRequestId} : {}),
        }),
      });
      accepted = true;
      if (navigation !== state.navigationVersion) return true;
      area.removeAttribute("aria-busy");
      card.remove();
      void permissionPolicy.refreshConversation();
      if (payload.status === "denied") { await loadFinalTrace(parentRequestId, state.currentTurn); return true; }
      if (payload.permission_policy && state.activeEnvelope?.request_id === parentRequestId) {
        state.activeEnvelope.snapshot.permission_policy = payload.permission_policy;
      }
      if (!payload.request_id) {
        showToast("Approval recorded");
        historyManagement.scheduleRefresh();
        return;
      }
      await resumeInteractionTrace(payload, parentRequestId);
      return true;
    } catch (error) {
      showToast(error.message || "Could not submit approval");
      return false;
    } finally {
      confirmationSubmissions.delete(parentRequestId);
      area.removeAttribute("aria-busy");
      if (!accepted) controls.forEach(control => { control.disabled = false; });
      updateSubmitState();
    }
  }

  async function submitClarification(parentRequestId, answerPayload, card = null) {
    if (clarificationSubmissions.has(parentRequestId) || state.turns.get(parentRequestId)?.replyResume?.pending) return false;
    clarificationSubmissions.add(parentRequestId);
    const navigation = state.navigationVersion;
    const currentTurn = state.turns.get(parentRequestId);
    const interaction = currentTurn?.clarificationRequest || {};
    const answered = {question: interaction, cursor: currentTurn?.lastEventId || 0,
      generation: currentTurn?.traceCreatedAt};
    const area = currentTurn?.actionArea || card;
    const controls = [...(area?.querySelectorAll("button, input, textarea, select") || [])]
      .filter(control => !control.disabled);
    controls.forEach(control => { control.disabled = true; });
    area?.setAttribute("aria-busy", "true");
    updateSubmitState();
    let accepted = false;
    try {
      const payload = await apiJson(`/api/agent/clarification/${encodeURIComponent(parentRequestId)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...answerPayload, context: {},
          ...(interaction.activity_id ? {activity_id: interaction.activity_id} : {}),
          ...(interaction.operation_id ? {operation_id: interaction.operation_id} : {}),
          ...(interaction.authority_request_id ? {
            authority_request_id: interaction.authority_request_id,
            ...(["allow", "deny"].includes(answerPayload.selected_option_id)
              ? {authority_decision: answerPayload.selected_option_id} : {}),
          } : interaction.capability_grant_request_id ? {
            capability_grant_request_id: interaction.capability_grant_request_id,
            ...(["allow", "deny"].includes(answerPayload.selected_option_id)
              ? {capability_decision: answerPayload.selected_option_id} : {}),
          } : {}),
        }),
      });
      accepted = true;
      if (navigation !== state.navigationVersion) return true;
      currentTurn?.actionArea.replaceChildren();
      area?.removeAttribute("aria-busy");
      card?.remove();
      await resumeInteractionTrace(payload, parentRequestId, answered);
      const turn = state.turns.get(payload.request_id);
      for (const event of payload.conversation_events || []) if (turn) appendWorkEvent(turn, event);
      return true;
    } catch (error) {
      if (accepted) {
        showToast("Response accepted. Could not refresh its progress; reconnecting…");
        return true;
      }
      showToast(error.message || "Could not submit clarification");
      controls.forEach(control => { control.disabled = false; });
      return false;
    } finally {
      clarificationSubmissions.delete(parentRequestId);
      area?.removeAttribute("aria-busy");
      updateSubmitState();
    }
  }

  function clearConversation({ keepStoredConversation = false, keepCapabilityPolicy = false } = {}) {
    window.SMTOSelectedConversation?.select(null);
    window.SMTOReadPriority.release();
    commandActions.close();
    conversationHistory.cancel();
    for (const turn of state.turns.values()) releaseHistoricalTurn(turn);
    if (!keepCapabilityPolicy) { draftCache.leave(); state.navigationVersion++; promptQueue.navigation(null); exitSteer(); }
    if (!keepStoredConversation && !keepCapabilityPolicy) { capabilityPolicy.reset(); permissionPolicy.reset(); }
    state.traceStatus = "";
    state.activeEnvelope = null;
    closeTraces();
    state.requestId = null;
    state.currentTurn = null;
    state.identityReady = true;
    state.openingConversation = false;
    state.turns.clear();
    promptNavigator?.reset();
    state.seenEventIds = new Set();
    setRunning(false);
    elements.conversation.replaceChildren();
    taskDisclosure.refresh();
    if (!keepStoredConversation) {
      state.conversationId = null;
      window.SMTOConversationWidth.activate(null);
      selectedConversation.select(null);
      void composerProfile.activate(null).catch(error => showToast(error));
      writeStorage(STORAGE.conversation, "");
      syncConversationUrl();
    }
    void runtimeGuards.refresh();
    contextMeter.activate(state.conversationId);
    conversationTiming.activate(state.conversationId);
    renderHistory();
    void window.SMTONative?.refresh();
    if (!keepCapabilityPolicy) draftCache.activate(draftScope());
    showConversation();
    if (!document.hidden) elements.input.focus();
    historyPane.closeTemporary();
  }

  async function historyWorkFromSnapshot(turn, snapshot, alive, {presentationOnly = false} = {}) {
    const events = Array.isArray(snapshot?.events) ? snapshot.events : [];
    if (!events.length) return;
    if (presentationOnly) activity.restoreOperations(turn.activity, events);
    turn.work.root.hidden = false;
    let slice = performance.now();
    for (const event of events) {
      if (!alive()) return;
      if (!presentationOnly) {
        turn.lastEventId = Math.max(turn.lastEventId || 0, Number(event.id || 0));
        activity.reduce(turn.activity, event);
      }
      appendWorkEvent(turn, event);
      if (performance.now() - slice >= window.SMTOConversationHistory.limits.renderBudgetMs) {
        await window.SMTOConversationHistory.yieldToUi(); slice = performance.now();
      }
    }
    if (!alive()) return;
    renderTimingSpans(turn, timing.restore(turn.timing, snapshot));
    turn.work.root.dataset.running = String(!activity.terminal.has(turn.activity.status));
    renderTaskActivityStatus(turn);
    updateCommandGroup(turn);
    const duration = Number(snapshot?.summary?.duration_ms || 0);
    window.SMTOTimingView.renderTimer(turn.work.duration, duration ? formatDuration(duration) : "");
  }

  function releaseHistoricalTurn(turn) {
    turn.messageTimes?.destroy();
    turn.activityController?.abort();
    turn.historyLoader?.dispose();
    turn.executionInspector?.dispose();
    turn.resultsDisclosure?.dispose();
    turn.checkObservations?.dispose();
    turn.inlineSteer?.dispose();
    for (const row of turn.actionItems.values()) if (row.liveShell) {
      row.liveShell.disposed = true; row.liveShell.viewer?.dispose();
    }
    closeTrace(turn);
    clearInterval(turn.durationTimer);
    turn.extrasObserver?.disconnect();
    turn.visualization?.dispose();
    turn.disposeFastCache?.();
    clearTimeout(turn.previewTimer); clearTimeout(turn.taskSummary?.timer); turn.savedTaskContext?.dispose();
    if (state.turns.get(turn.requestId) === turn) state.turns.delete(turn.requestId);
    if (state.currentTurn === turn) state.currentTurn = null;
    const group = turn.activityGroup || turn.article.closest(".activity-group");
    turn.article.remove();
    cleanupActivityGroup(group);
    scheduleActivityBoundaries();
  }

  let historicalDetailRequests = 0;

  function lazyActivity(turn, alive = () => turn.article.isConnected) {
    if (turn.lazyActivity) return;
    turn.lazyActivity = true;
    turn.work.root.open = window.SMTOProseActivity.preference(turn.conversationId, false);
    if (!alive()) return;
    turn.boundLiveActivity = () => window.SMTOConversationSnapshot.boundActivity(turn.work.items, [turn.actionItems]);
    turn.executionInspector ||= window.SMTOConversationSnapshot.inspectControl({actionContainer: turn.runActions,
      requestId: turn.requestId, apiJson, ready: state.currentSnapshotReady});
  }

  async function renderHistoricalTurn(savedTurn, container, signal, alive) {
    if (taskDeletion.deleted(savedTurn)) return null;
    let turn = null;
    const submitted = [...provisionalTurns.entries()].find(([, item]) => item.taskId === savedTurn.task_id);
    if (submitted && !state.turns.has(savedTurn.request_id)) {
      submitted[1].bindRequest(savedTurn.request_id);
      submitted[1].snapshotBootstrap = true;
      submitted[1].historical = true;
      provisionalTurns.delete(submitted[0]);
    }
    // A page may include an execution accepted after its request began. Its live
    // object, stream, timers and controls remain owned by the runtime surface.
    if (state.turns.has(savedTurn.request_id)) {
      const existing = state.turns.get(savedTurn.request_id);
      renderApprovedPlan(existing, savedTurn);
      setTurnActivityLineage(existing, savedTurn);
      if (existing.snapshotBootstrap) {
        existing.snapshotBootstrap = false;
        setTurnAttemptPrompt(existing, savedTurn.prompt
          ? {followup_prompt: savedTurn.prompt}
          : !savedTurn.attachments?.length ? {continuation: true} : {});
        renderAnswer(existing, savedTurn.final_response || "", {metrics: savedTurn.response_metrics});
        renderDisplayDocument(existing, savedTurn.display_document);
        turn = existing;
        container.append(existing.activityGroup || existing.article);
      }
      if (!turn) return null;
    }
    turn ||= createTurn(savedTurn.prompt || (savedTurn.attachments?.length ? "" : "Request"), savedTurn.request_id,
      {historical: true, continuation: !savedTurn.prompt && !savedTurn.attachments?.length,
        attachments: savedTurn.attachments, container, taskId: savedTurn.task_id, parentRequestId: savedTurn.parent_request_id});
    window.SMTOTaskMode.render(turn.article, savedTurn);
    syncTraceCursor(turn, savedTurn.created_at);
    lazyActivity(turn, () => alive() && turn.article.isConnected);
    if (savedTurn.response_metrics?.conversation_message_count || savedTurn.clarification_required) turn.work.root.open = true;
    if (!alive()) return turn;
    if (!turn.historical) return turn; // Native reconciliation may have reconnected it while replay yielded.
    activity.setStatus(turn.activity, activity.userStatus(savedTurn), {authoritative: true});
    renderResponseTiming(turn, savedTurn);
    renderTaskActivityStatus(turn);
    updateCommandGroup(turn);
    const response = savedTurn.final_response || "";
    renderAnswer(turn, completionAnswerMarkdown(turn, savedTurn, response),
      {error: savedTurn.status === "failed", metrics: savedTurn.response_metrics});
    renderDisplayDocument(turn, savedTurn.display_document);
    // Legacy incomplete snapshots are explicit, cancellable detail reads. Never
    // manufacture approval/clarification controls from flags without their payload.
    const needsDetail = savedTurn.confirmation_required || savedTurn.clarification_required
      || (savedTurn.status === "completed" && !usefulBackendResponse(response));
    if (needsDetail) {
      const detail = document.createElement("button"); detail.type = "button";
      detail.className = "action-button saved-task-details"; detail.textContent = "Load saved task details";
      detail.addEventListener("click", async () => {
        if (historicalDetailRequests >= window.SMTOConversationHistory.limits.detailConcurrency) return;
        historicalDetailRequests++; detail.disabled = true;
        try {
          window.SMTOConversationHistory.measure("lazy_detail_request_count",
            window.SMTOConversationHistory.metrics().lazy_detail_request_count + 1);
          const trace = await apiJson(`/api/agent/trace/${encodeURIComponent(turn.requestId)}/summary`, {signal});
          if (!alive() || !turn.article.isConnected) return;
          renderAnswer(turn, completionAnswerMarkdown(turn, trace, trace.final_response || response), {metrics: trace.response_metrics});
          renderResponseTiming(turn, trace);
          renderNeededAction(turn, trace); detail.remove();
        } catch (error) { if (alive() && error.name !== "AbortError") showToast(error); }
        finally { historicalDetailRequests--; detail.disabled = false; }
      });
      turn.actionArea.append(detail);
    } else renderNeededAction(turn, savedTurn);
    if (turn.activity.status === "failed" && !window.SMTOSelectedConversation)
      void window.SMTONative?.refreshTaskSnapshot(turn.requestId);
    return turn;
  }

  conversationHistory = window.SMTOConversationHistory.create({
    viewport: elements.viewport, content: elements.conversation, apiJson,
    renderTurn: renderHistoricalTurn, releaseTurn: releaseHistoricalTurn,
    onPage: taskDeletion.observe, isDeleted: taskDeletion.deleted,
    protectedTurn: turn => !turn.historical || ["pending", "queued", "running", "paused", "paused_budget",
      "waiting_job", "waiting_event", "waiting_user",
      "awaiting_confirmation", "awaiting_clarification", "awaiting_resource_reconciliation"].includes(turn.activity.status),
    onLatest: (turn, sourceRequestId, {followLatest = false} = {}) => {
      if (!turn && !window.SMTOSelectedConversation) void window.SMTONative?.refresh();
      if (turn && !state.currentTurn) {
        state.currentTurn = turn;
        updateContextMeter(turn.responseMetrics?.llm_context_usage);
        renderActivity();
        if (!sourceRequestId && ["pending", "queued", "running", "waiting_job", "waiting_event",
          "waiting_user", "awaiting_confirmation", "awaiting_clarification", "paused", "paused_budget",
          "awaiting_resource_reconciliation"].includes(turn.activity.status)) {
          // Reserve this attachment while its summary is in flight. Queue
          // reconciliation must not race it with a stream starting at event 0.
          state.requestId = turn.requestId;
          if (!window.SMTOSelectedConversation) void loadFinalTrace(turn.requestId, turn);
        }
        if (!sourceRequestId) scrollToBottom("auto", true);
      }
      if (!turn && sourceRequestId && !state.requestId) {
        const source = state.turns.get(sourceRequestId);
        if (source) {
          navigateToConversationTurn(sourceRequestId);
          // Initial deep-link placement is immediate; an in-progress smooth
          // scroll must not compete with page-height anchor compensation.
          source.article.scrollIntoView({block: "start", behavior: "instant"});
          if (!elements.input.value && document.activeElement !== elements.input) {
            source.article.tabIndex = -1; source.article.focus({preventScroll: true});
          }
        }
      }
      if (followLatest && !sourceRequestId) scrollToBottom("auto", true);
      showConversation();
    },
    onChange: () => { promptNavigator?.refresh(); scheduleActivityBoundaries(); },
  });

  const selectedConversation = window.SMTOConversationSnapshot.create({
    apiJson,
    freshness: (freshness, snapshot, error) => {
      elements.conversation.dataset.freshness = freshness;
      if (freshness === "current" && Number.isFinite(snapshot?.observed_at))
        window.SMTOStreamActivity.syncClock(streamActivityHistory, snapshot.observed_at * 1000);
      if (error && !snapshot) showToast(error);
    },
    apply: async (snapshot, lane) => {
      if (snapshot.conversation.conversation_id !== state.conversationId) return;
      taskDeletion.observe(snapshot);
      lane.tasks = lane.tasks.filter(task => !taskDeletion.deleted(task));
      state.conversationSnapshot = snapshot;
      taskDisclosure.refresh();
      state.openingConversation = false;
      promptQueue.applyLane(lane);
      for (const task of lane.tasks) {
        if (task.has_approved_plan && !task.current_request_id && !task.latest_request_id) showPlanTask(task);
      }
      for (const [rid, run] of Object.entries(snapshot.executions_by_request_id)) {
        if (taskDeletion.deleted({request_id: rid, task_id: run.task_id})) continue;
        const task = lane.tasks.find(task => (task.current_request_id || task.latest_request_id) === rid);
        let turn = state.turns.get(rid);
        if (!turn && task?.client_submission_id) {
          const submitted = provisionalTurns.get(task.client_submission_id);
          if (submitted?.article.isConnected) {
            turn = submitted; turn.bindRequest(rid);
            setTurnActivityLineage(turn, {task_id: task.task_id});
            provisionalTurns.delete(task.client_submission_id);
          }
        }
        if (!turn) {
          const continuation = Boolean(run.continuation) && !run.followup_prompt;
          turn = createTurn(run.followup_prompt || (continuation ? "" : task?.prompt || "Current request"), rid, {
            continuation, taskId: run.task_id || task?.task_id, parentRequestId: run.parent_request_id,
          });
          turn.historical = true;
          turn.snapshotBootstrap = true;
          turn.snapshotNeedsAnswer = !state.booting && !state.openingConversation;
          lazyActivity(turn);
        }
        if ((run.state_revision || 0) < (turn.nativeRevision || 0)) continue;
        if (observeReply(turn, run)) {
          if (rid === snapshot.current_request_id) {
            state.currentTurn = turn;
            if (turn.replyResume.pending) { state.requestId = rid; setRunning(true); }
          }
          if (turn.replyResume.pending && !turn.source)
            connectTrace(rid, turn.replyResume.streamUrl, turn, turn.lastEventId || 0, false, false);
          renderTurnActivity(turn);
          continue;
        }
        setTurnActivityLineage(turn, run);
        setTurnAttemptPrompt(turn, run);
        renderApprovedPlan(turn, task);
        const trace = run.trace || {};
        let status = run.user_visible_status || run.status;
        const previous = turn.activity.status;
        turn.messageTimes?.user(task?.created_at);
        turn.messageTimes?.restore(run.trace || {});
        syncTraceCursor(turn, run.stream.generation);
        if (!turn.source) turn.lastEventId = Number(run.stream.after_id || 0);
        if (!turn.activity.executionStatus || !run.execution_status?.trace_event_id
          || run.execution_status.trace_event_id >= (turn.activity.executionStatus.trace_event_id || 0)) {
          turn.executionStatus = run.execution_status;
          turn.activity.executionStatus = run.execution_status;
        }
        const serverNow = Date.parse(run.timing?.server_now);
        if (Number.isFinite(serverNow)) window.SMTOStreamActivity.syncClock(streamActivityHistory, serverNow);
        turn.executionInspector ||= window.SMTOConversationSnapshot.inspectControl({actionContainer: turn.runActions, requestId: rid, apiJson});
        turn.executionInspector.update(run.observation);
        renderTimingSpans(turn, timing.restore(turn.timing, {...trace,
          request_runtime_timing: run.timing, runtime_timing: run.timing}));
        conversationTiming.restore(rid, {request_runtime_timing: run.timing});
        activity.setStatus(turn.activity, status, {...run, authoritative: true,
          ...(run.state_revision > (turn.nativeRevision || 0) ? {trace_event_id: undefined} : {})});
        turn.nativeRevision = Math.max(turn.nativeRevision || 0, run.state_revision || 0);
        status = turn.activity.status;
        if (rid === snapshot.current_request_id) {
          state.currentTurn = turn; state.traceStatus = status;
          state.requestId = ["running", "pending", "waiting_job", "waiting_event"].includes(status) ? rid : null;
          setRunning(Boolean(state.requestId));
        }
        const observing = turn.awaitingFinalTrace || window.SMTOTaskLifecycle.replyHandoff(run)
          || ["running", "pending", "waiting_job", "waiting_event"].includes(status);
        if (observing) {
          turn.historical = false;
          startDurationClock(turn);
          if (!turn.source) connectTrace(rid, run.stream.url, turn, turn.lastEventId, false, false);
          if (!turn.replyResume && window.SMTOTaskLifecycle.replyHandoff(run))
            void loadFinalTrace(rid, turn);
        } else {
          closeTrace(turn);
          clearInterval(turn.durationTimer);
          // Compact snapshots omit diagnostics; omission must not erase checks
          // already restored from history or a full trace. Explicit {} still clears.
          renderNeededAction(turn, {...trace, ...run,
            response_metrics: trace.response_metrics || turn.responseMetrics,
            agent_checks: window.SMTOAgentChecks.stateOf(run)
              ?? window.SMTOAgentChecks.stateOf(trace) ?? turn.agentChecksSnapshot ?? {}});
          // Native terminal truth can precede the last trace frame. Keep answer
          // restoration explicit; it does not participate in bootstrap hydration.
          const planNeedsAnswer = run.proposed_plan && turn.responseMetrics?.proposed_plan?.digest !== run.proposed_plan.digest;
          if ((planNeedsAnswer || previous !== status && (!turn.snapshotBootstrap || turn.snapshotNeedsAnswer))
              && ["completed", "answered", "failed", "cancelled", "interrupted"].includes(status))
            void window.SMTOReadPriority.ready.then(() => reloadRetainedFinal(rid, turn));
        }
        renderTurnActivity(turn);
      }
      if (!snapshot.current_request_id) {
        state.currentTurn = null; state.requestId = null; state.traceStatus = ""; setRunning(false);
      }
      await window.SMTONative?.applyConversation(snapshot);
      renderActivity(); showConversation();
    },
  });
  window.SMTOSelectedConversation = selectedConversation;
  window.SMTOUiUpdates.subscribe(["runs.changed", "tasks.changed", "chats.changed", "runtime-controls.changed", "events.changed"],
    async payload => {
      if (payload.syncRequired || payload.topics?.includes("chats.changed")) {
        const feedback = await import("./deletion_progress.js?v=20261015-smto");
        await feedback.conversations.refresh();
      }
      return selectedConversation.invalidate(payload);
    }, {critical: true});

  function applyConversationMetadata(conversationId, chat, {keepCapabilityPolicy = false, restoring = false} = {}) {
    state.conversationId = conversationId;
    state.identityReady = true;
    state.openingConversation = false;
    void runtimeGuards.refresh();
    writeStorage(STORAGE.conversation, conversationId); syncConversationUrl();

    if (keepCapabilityPolicy) { capabilityPolicy.followConversation(conversationId); permissionPolicy.followConversation(conversationId); }
    else { capabilityPolicy.setConversation(conversationId); permissionPolicy.setConversation(conversationId); }
    const provenance = document.createElement("div");
    taskFork.source(provenance, chat);
    if (chat.provenance?.source === "schedule" && chat.provenance.schedule_id) {
      const link = document.createElement("a"); link.textContent = "View schedule";
      link.href = `/schedules?event=${encodeURIComponent(chat.provenance.schedule_id)}`;
      provenance.append(link);
    }
    if (provenance.childElementCount) elements.conversation.prepend(provenance);
    updateSubmitState(); renderHistory();
  }

  async function openConversation(conversationId, {excludeRequestId = "", internal = false, keepCapabilityPolicy = false, sourceRequestId = "", fallbackOnMissing = false} = {}) {
    if (window.SMTOConversationDeletion?.blocked(conversationId)) {
      showToast("This conversation is being deleted. Open another conversation or start a new chat."); return;
    }
    const restoring = state.booting;
    selectedConversation.select(conversationId);
    if (!internal) { draftCache.leave(); state.navigationVersion++; promptQueue.navigation(conversationId); exitSteer(); }
    const navigationVersion = state.navigationVersion;
    commandActions.close();
    conversationHistory.cancel();
    for (const turn of state.turns.values()) releaseHistoricalTurn(turn);
    state.openingConversation = true; state.identityReady = false;
    state.conversationId = conversationId;
    window.SMTOConversationWidth.activate(conversationId);
    contextMeter.activate(conversationId); state.traceStatus = "";
    conversationTiming.activate(conversationId);
    if (!restoring) historyPane.closeTemporary();
    closeTraces(); state.requestId = null; state.currentTurn = null;
    state.turns.clear(); promptNavigator?.reset(); state.seenEventIds = new Set();
    setRunning(false); elements.conversation.replaceChildren(); elements.empty.hidden = true;
    const history = conversationHistory.begin(conversationId, {excludeRequestId, sourceRequestId,
      isCurrent: () => navigationVersion === state.navigationVersion && state.conversationId === conversationId});
    // Read and paint saved state immediately. Composer settings and metadata only
    // gate submission; neither is needed to display this scoped history window.
    state.historyLoad = history.load();
    state.currentSnapshotReady = selectedConversation.refresh();
    try {
      const loaded = await state.currentSnapshotReady;
      if (!history.valid()) return;
      if (!loaded) throw new Error("Could not refresh current execution state. Reconnect to retry.");
      const payload = selectedConversation.current();
      applyConversationMetadata(conversationId, payload.conversation, {keepCapabilityPolicy, restoring});
      await composerProfile.activate(conversationId);
      if (!history.valid()) return;
      if (sourceRequestId) {
        const url = new URL(location.href); url.searchParams.set("task", sourceRequestId);
        window.history.replaceState(null, "", url);
      }
      if (internal) draftCache.rebind(draftScope());
      else if (!restoring) draftCache.activate(draftScope());
    } catch (error) {
      if (!history.valid() || error.name === "AbortError") return;
      if (fallbackOnMissing && error.status === 404) { clearConversation(); return; }
      const host = elements.conversation.querySelector(".history-sentinel"); host?.replaceChildren();
      const message = document.createElement("p"); message.className = "history-retry";
      message.textContent = error.message || "This chat could not be loaded.";
      const retry = document.createElement("button"); retry.type = "button"; retry.textContent = "Retry";
      retry.addEventListener("click", () => { void openConversation(conversationId, {sourceRequestId}); });
      message.append(retry); host?.append(message);
      // Unknown/deleted identity cannot silently turn a saved-chat submission into a new chat.
      state.openingConversation = false; updateSubmitState();
    }
  }

  function relativeDate(value) {
    const timestamp = Date.parse(value || "");
    if (!Number.isFinite(timestamp)) return "";
    const seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
    if (seconds < 60) return "now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
    return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(timestamp));
  }

  async function reconcileMissingConversation() {
    const id = state.conversationId;
    const feedback = await import("./deletion_progress.js?v=20261015-smto");
    await feedback.conversations.refresh();
    if (id !== state.conversationId) return;
    if (id && feedback.conversations.autoPurged(id))
      await deletedCurrentConversation(id, {reason: "auto_purge"});
    else clearConversation();
  }

  async function deletedCurrentConversation(id, deletion = null) {
    if (state.conversationId !== id || state.submitting) return;
    if (!deletion) {
      const feedback = await import("./deletion_progress.js?v=20261015-smto");
      await feedback.conversations.refresh();
      if (state.conversationId !== id || state.submitting) return;
      if (feedback.conversations.autoPurged(id)) deletion = {reason: "auto_purge"};
    }
    const wasOpen = elements.historyDrawer.getAttribute("aria-hidden") === "false";
    const draft = draftCache.snapshot();
    contextMeter.forget(id);
    state.conversationId = null;
    selectedConversation.select(null);
    draftCache.rebind(draftScope());
    state.navigationVersion++;
    promptQueue.navigation(null);
    clearConversation({keepCapabilityPolicy: true});
    capabilityPolicy.reset(); permissionPolicy.reset();
    if (draft) {
      capabilityPolicy.restoreDraftState(draft.capabilities);
      permissionPolicy.restoreDraftState(draft.permissions);
      behaviorEffort.restore(draft.behavior_effort);
    }
    draftCache.touch(true);
    if (deletion?.fallback_conversation_id && !window.SMTOConversationDeletion?.blocked(deletion.fallback_conversation_id)) {
      await openConversation(deletion.fallback_conversation_id, {fallbackOnMissing: true});
    } else {
      showToast(deletion?.reason === "auto_purge"
        ? "Conversation automatically deleted after inactivity. Your unsent draft is preserved in a new chat."
        : "Conversation deleted. Your unsent draft is preserved in a new chat.");
      if (wasOpen) openHistory();
    }
  }

  const historyManagement = window.SMTOConversationManagement.create({
    drawer: elements.historyDrawer, list: elements.historyList, apiJson, notify: showToast,
    openConversation, conversationUrl, currentId: () => state.conversationId, deletedCurrent: deletedCurrentConversation, relativeDate,
  });
  function renderHistory() { historyManagement.render(); }
  window.addEventListener("smto:conversation-deletion", updateSubmitState);
  window.addEventListener("smto:conversation-deletion", () => {
    if (window.SMTOConversationDeletion?.autoPurged(state.conversationId))
      void deletedCurrentConversation(state.conversationId, {reason: "auto_purge"});
  });
  async function loadHistory() { await historyManagement.refresh(); }

  const historyPane = window.SMTOConversationPane.create({
    drawer: elements.historyDrawer, shell: $(".app-shell"), layout: $(".workspace-layout"),
    scrim: elements.scrim, toggle: elements.historyToggle, close: elements.historyClose,
    dock: $("#history-dock"), resize: $("#history-resize"), refresh: loadHistory,
    closeMenu: historyManagement.closeMenu,
  });
  function openHistory() { historyPane.open(); }

  async function loadModels(notify = false) {
    if (state.modelsLoading) return;
    state.modelsLoading = true;
    elements.model.setAttribute("aria-busy", "true");
    try {
      const payload = await apiJson(`/api/agent/model/config${notify ? "?refresh=true" : ""}`, {cache: "no-store"});
      const available = Array.isArray(payload.options) ? payload.options : [];
      modelOptions = available.filter(option => option.value);
      renderProfileModel(); updateSubmitState();
      if (!modelOptions.length) throw window.SMTOErrors.error("ui_model_required");
    } catch (error) {
      if (!elements.model.value) elements.model.replaceChildren(new Option("No models available", ""));
      state.activeModelName = elements.model.value;
      elements.model.title = `${error.message || "Could not load models."} Open the model dropdown to try again.`;
      if (notify) showToast(elements.model.title);
    } finally {
      state.modelsLoading = false;
      elements.model.disabled = !composerProfile?.ready();
      elements.model.removeAttribute("aria-busy");
    }
  }

  function renderGenerateProse() {
    elements.generateProse.checked = composerProfile?.current().generate_prose === true;
    elements.generateProse.disabled = !composerProfile?.ready() || state.generateProseSaving;
  }

  function renderTaskContract() {
    renderIntegrityGuard();
    elements.taskContract.checked = composerProfile?.current().task_contract_compilation_enabled === true;
    elements.taskContract.disabled = !composerProfile?.ready() || state.taskContractSaving;
  }

  function renderWaveletTimelineToggle() {
    const toggle = $("#wavelet-timeline-toggle");
    const enabled = state.settings.ui_wavelet_timeline_enabled !== false;
    toggle.setAttribute("aria-pressed", String(enabled));
    toggle.title = enabled ? "Hide activity timeline" : "Show activity timeline";
    toggle.disabled = !state.settingsLoaded || state.waveletTimelineSaving;
  }

  $("#wavelet-timeline-toggle").addEventListener("click", async () => {
    if (!state.settingsLoaded || state.waveletTimelineSaving) return;
    state.waveletTimelineSaving = true;
    ++state.settingsVersion; // Invalidate preference reads started before this write.
    renderWaveletTimelineToggle();
    try {
      const payload = await Core.writeSettingsBackendPreferences({settings: {
        ui_wavelet_timeline_enabled: state.settings.ui_wavelet_timeline_enabled === false,
      }});
      applySettings(payload);
    } catch (error) {
      showToast(error.message || "Could not save the timeline preference.");
    } finally {
      state.waveletTimelineSaving = false;
      renderWaveletTimelineToggle();
      void loadSettings();
    }
  });

  function applySettings(payload) {
    state.settings = payload?.settings && typeof payload.settings === "object" ? payload.settings : {};
    state.settingsLoaded = true;
    Core.applyAgentAppearance(state.settings);
    activityPresentation.applySettings(state.settings);
    renderWaveletTimelineToggle();
    promptNavigator?.setEnabled(state.settings.conversation_navigator_enabled);
    renderGenerateProse();
    renderTaskContract();
    void renderParallel();
  }

  async function loadSettings() {
    if (state.generateProseSaving || state.taskContractSaving || state.waveletTimelineSaving) return;
    const version = ++state.settingsVersion;
    try {
      const payload = await apiJson("/api/agent/settings/preferences");
      if (version === state.settingsVersion) applySettings(payload);
    } catch (_error) {
      // Retain the last saved value. Initial failures leave the shortcut disabled.
    }
  }
  window.SMTOUiUpdates.observeFreshness(() => {
    renderConnectionIndicator();
    renderActivity();
  });
  window.SMTOUiUpdates.subscribe(["settings.changed"], loadSettings);
  window.SMTOUiUpdates.subscribe(["settings.changed"], () => void composerProfile.refresh());
  window.SMTOUiUpdates.subscribe(["settings.changed"], runtimeGuards.refresh);
  window.SMTOUiUpdates.subscribe(["runs.changed"], payload => {
    if (payload.syncRequired) return; // Initial saved answers belong to the turn page.
    if (state.currentTurn?.requestId && !state.running && state.currentTurn.answerText) {
      void reloadRetainedFinal(state.currentTurn.requestId, state.currentTurn);
    }
  });
  window.addEventListener("online", () => { void loadSettings(); });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) void loadSettings();
  });

  window.SMTOWorkflows?.configure({
    context: () => targetSelector.submissionSnapshot(),
    schedule: source => promptSchedules.openWorkflow(source),
    onRun: run => openConversation(run.conversation_id, {sourceRequestId: run.request_id}),
  });
  $("#workflows-open")?.addEventListener("click", () => {
    void window.SMTOWorkflows.library().catch(error => showToast(error.message));
  });

  function agentContext() {
    return {
      context_refs: window.SMTONative?.refs() || [],
      ...window.SMTONative?.credentialContext(),
      target_ui: "agent_ui",
      active_llm_model: state.activeModelName,
    };
  }

  async function restoreLiveRun(probe, navigationVersion) {
    const alive = () => navigationVersion === state.navigationVersion;
    try {
      const payload = await probe;
      const run = payload?.current_run;
      if (!alive() || !run?.request_id || payload.reconnectable !== true) return false;
      if (run.conversation_id) {
        await openConversation(run.conversation_id);
        return true;
      }
      const trace = await apiJson(`/api/agent/trace/${encodeURIComponent(run.request_id)}/summary`);
      if (!alive()) return false;
      const status = activity.userStatus(trace) || run.status;
      if (!["pending", "running", "awaiting_confirmation", "awaiting_clarification", "awaiting_resource_reconciliation", "waiting_user", "waiting_event", "waiting_job", "paused", "paused_budget", "partial", "blocked"].includes(status)) return false;
      conversationHistory.cancel(); elements.conversation.replaceChildren();
      state.conversationId = String(run.conversation_id || "") || null;
      window.SMTOConversationWidth.activate(state.conversationId);
      await composerProfile.activate(state.conversationId);
      if (!alive()) return false;
      contextMeter.activate(state.conversationId); syncConversationUrl();
      conversationTiming.activate(state.conversationId);
      writeStorage(STORAGE.conversation, state.conversationId || "");
      const turn = createTurn(trace.prompt || run.prompt_preview || "Active request", run.request_id, {compact: !trace.prompt && !run.prompt_preview});
      state.currentTurn = turn; state.requestId = run.request_id; state.seenEventIds = new Set();
      lazyActivity(turn);
      renderTimingSpans(turn, timing.restore(turn.timing, trace));
      conversationTiming.restore(turn.requestId, trace);
      timingView.refresh();
      activity.setStatus(turn.activity, status, {cancel_requested: run.cancel_requested});
      renderActivity();
      const lastId = Number(trace.last_event_id || run.last_event_id || 0);
      syncTraceCursor(turn, trace.created_at);
      turn.lastEventId = lastId;
      if (status === "running" || status === "pending") {
        setRunning(true);
        connectTrace(run.request_id, run.stream_url || `/api/agent/stream/${run.request_id}`, turn, lastId);
      } else {
        completeWork(turn, trace);
        renderAnswer(turn, trace.final_response || "I need your input before I can continue."); renderNeededAction(turn, trace);
      }
      showConversation(); scrollToBottom("auto", true);
      void window.SMTONative?.refresh();
      requestAnimationFrame(() => { if (alive()) window.SMTOConversationHistory.mark("boot_to_current_run_painted_ms"); });
      // The live object and stream are established before any historical read.
      if (state.conversationId) {
        const conversationId = state.conversationId;
        const history = conversationHistory.begin(conversationId, {excludeRequestId: run.request_id, isCurrent: alive});
        scrollToBottom("auto", true);
        state.historyLoad = history.load();
        try {
          const metadata = await apiJson(`/api/agent/chats/${encodeURIComponent(conversationId)}/metadata`, {signal: history.signal});
          if (history.valid()) applyConversationMetadata(conversationId, metadata.conversation, {restoring: true});
        } catch (error) { if (history.valid() && error.name !== "AbortError") showToast(error); }
      } else { state.identityReady = true; updateSubmitState(); }
      return true;
    } catch (_error) { return false; }
  }

  async function boot() {
    applyTheme(document.documentElement.dataset.theme
      || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
    resizeInput(); updateSubmitState();
    window.SMTOConversationHistory.mark("boot_to_input_editable_ms");
    const navigationVersion = state.navigationVersion;
    const url = new URL(location.href), linkedConversation = url.searchParams.get("conversation");
    const paletteLaunch = url.searchParams.get("palette") === "1";
    const savedConversation = readStorage(STORAGE.conversation);
    const initial = window.SMTOConversationHistory.skeleton("Loading latest messages…");
    elements.conversation.append(initial); showConversation();
    if (!composerBrowsing.isCompact() && !document.querySelector("dialog[open]") && !historyPane.isTemporary()) elements.input.focus();

    // Independent eager lanes: neither data pipeline is an execution prerequisite.
    const probe = paletteLaunch || linkedConversation ? Promise.resolve(null) : apiJson("/api/agent/current-run").catch(() => null);
    const execution = (async () => {
      await window.SMTOReadPriority.ready;
      void loadHistory();
      void synchronizeActivityClock();
      void apiJson("/api/agent/health").then(() => setConnection("connected")).catch(() => setConnection("disconnected"));
      void loadPromptHistory();
      void slashCommands.load().catch(error => showToast(error));
      await Promise.all([window.SMTOLegal.ready, loadModels(), loadSettings(), targetSelector.load(),
        permissionPolicy.loadDefaults(), capabilityPolicy.loadDefaults()]);
      Core.applyAgentAppearance(state.settings);
      capabilityPolicy.modeChanged(); permissionPolicy.modeChanged();
      state.executionReady = true; updateSubmitState();
    })().catch(error => { showToast(error.message || "Could not prepare execution. Reload to retry."); });
    const selection = (async () => {
      if (linkedConversation) await openConversation(linkedConversation, {sourceRequestId: url.searchParams.get("task") || ""});
      else if (paletteLaunch) {
        window.SMTOReadPriority.release(); await composerProfile.activate(null); initial.remove(); state.identityReady = true;
        showConversation(); updateSubmitState();
      }
      else if (!await restoreLiveRun(probe, navigationVersion) && navigationVersion === state.navigationVersion) {
        if (savedConversation) await openConversation(savedConversation);
        else { window.SMTOReadPriority.release(); await composerProfile.activate(null); initial.remove(); state.identityReady = true; showConversation(); updateSubmitState(); }
      }
    })();
    await Promise.all([execution, selection]);
    // Only metadata/defaults are awaited here. Pages, recall and the rail continue independently.
    if (state.identityReady) draftCache.activate(draftScope());
    if (paletteLaunch) {
      const clean = new URL(location.href); clean.searchParams.delete("palette");
      window.history.replaceState(null, "", clean);
      commandPalette.open({launcher: true});
    }
  }

  /** Submit the shared live form through canonical command, interaction or task admission. */
  function submitComposer(event) {
    event.preventDefault();
    if (state.pendingSteer) return;
    const commandText = elements.input.value.trim();
    if (slashCommands.isCommand(commandText)) {
      if (state.identityReady && !elements.composer.hidden && !slashCommands.isBusy())
        void slashCommands.execute(commandText);
      return;
    }
    if (window.SMTOConversationDeletion?.blocked(state.conversationId)) return;
    if (!window.SMTOLegal.canExecute()) { void window.SMTOLegal.open(); return; }
    if (!state.executionReady || !state.identityReady || elements.composer.hidden || state.composerBusy || state.generateProseSaving || state.taskContractSaving || slashCommands.isBusy() || mentionPalette.isBusy()) return;
    const prompt = elements.input.value;
    if (!prompt.trim()) return;
    const intendedSteer = state.steerRequestId;
    const intendedInteraction = currentInteraction();
    const intendedNavigation = state.navigationVersion;
    let snapshot = null, policySnapshot = null, permissionSnapshot = null;
    try {
      if (!intendedInteraction && !intendedSteer && !slashCommands.isCommand(prompt)) {
        snapshot = promptSnapshot(prompt);
        policySnapshot = capabilityPolicy.submissionSnapshot();
        permissionSnapshot = permissionPolicy.submissionSnapshot();
      }
    } catch (error) { showToast(error); return; }
    state.composerBusy = true;
    updateSubmitState();
    const submissionFeedback = composerBrowsing?.beginSubmission({steering: Boolean(intendedSteer)});
    const steeringMode = state.steeringMode || "interrupt";
    const steerKey = JSON.stringify([intendedSteer, prompt, steeringMode]);
    if (intendedSteer && !steerSubmissions.has(steerKey)) steerSubmissions.set(steerKey,
      `composer_steer_${globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)}`);
    const steerSubmissionId = steerSubmissions.get(steerKey);
    const steeringTracker = intendedSteer ? window.SMTOInlineSteer.track(intendedSteer,
      message => { composerBrowsing?.steeringProgress(submissionFeedback, message); updateSubmitState(); },
      {steeringMode, cancel: () => window.SMTONative.cancelSteer({requestId: intendedSteer, submissionId: steerSubmissionId})}) : null;
    if (steeringTracker && steeringMode === "after_response")
      composerBrowsing?.steeringProgress(submissionFeedback, window.SMTOInlineSteer.gentleWaiting);
    if (steeringTracker) state.pendingSteer = {tracker: steeringTracker, navigation: intendedNavigation};
    updateSubmitState();
    void (async () => {
      let directSubmission = false, pendingDraft = null, submitted = false;
      const markAccepted = () => {
        submitted = true;
        if (intendedNavigation === state.navigationVersion) {
          composerBrowsing?.finishSubmission(submissionFeedback, true);
          scrollToBottom("instant", true);
        }
      };
      try {
        if (intendedNavigation !== state.navigationVersion || elements.input.value !== prompt) return;
        if (intendedSteer && state.steerRequestId !== intendedSteer) return;
        const current = currentRun();
        const clearInput = () => {
          if (elements.input.value === prompt) elements.input.value = "";
          state.promptHistoryNavigation = null; resizeInput();
        };
        const interaction = currentInteraction();
        if (intendedInteraction && (interaction?.requestId !== intendedInteraction.requestId || interaction.kind !== intendedInteraction.kind)) {
          showToast("The task's input request changed. Review its current state before sending."); return;
        }
        if (interaction) {
          if (interaction.kind !== "reply") { await focusInteraction(interaction); return; }
          const submittedDraft = draftCache.snapshot();
          if (await submitClarification(interaction.requestId, {answer: prompt})) {
            if (intendedNavigation === state.navigationVersion) clearInput();
            draftCache.consume(submittedDraft);
            markAccepted();
          }
          return;
        }
        if (slashCommands.isCommand(prompt)) { await slashCommands.execute(prompt); return; }
        if (state.steerRequestId) {
          const submittedDraft = draftCache.snapshot();
          const result = await window.SMTONative.steer(prompt, intendedSteer, steerSubmissionId, steeringMode);
          const outcome = await steeringTracker.accepted(result);
          if (["applied", "withdrawn"].includes(outcome)) steerSubmissions.delete(steerKey);
          if (outcome === "withdrawn" && intendedNavigation === state.navigationVersion)
            showToast("Steer cancelled. Your text is retained.");
          if (!window.SMTOInlineSteer.requireApplied(outcome)) return;
          if (intendedNavigation !== state.navigationVersion) return;
          if (intendedNavigation === state.navigationVersion && elements.input.value === prompt) clearInput();
          draftCache.consume(submittedDraft);
          markAccepted();
          state.pendingSteer = null;
          exitSteer(); void promptQueue.reconcile(); return;
        }
        if (state.modelsLoading || !elements.model.value) {
          showToast(state.modelsLoading ? "Models are loading. Please try again in a moment."
            : "No model is available. Check the LLM endpoint in Settings, then open the model dropdown to retry.");
          return;
        }
        if (isOperational() || promptQueue.hasItems()) {
          const submittedDraft = draftCache.snapshot();
          const accepted = await promptQueue.enqueue(snapshot || promptSnapshot(prompt), {onAccepted: () => {
            if (intendedNavigation === state.navigationVersion) clearInput();
            draftCache.consume(submittedDraft);
            markAccepted();
          }});
          if (accepted) {
            if (permissionSnapshot) void permissionPolicy.requestAccepted(accepted.conversation_id, permissionSnapshot);
          }
          return;
        }
        pendingDraft = draftCache.beginSubmission();
        clearInput();
        // Release the composer while prepare/request runs so the next input can queue.
        state.submitting = true;
        directSubmission = true;
        state.preparingDirect = true;
        updateSubmitState();
        await prepareAndSubmit(prompt, null, {nativeRefreshed: true, snapshot, policySnapshot, permissionSnapshot,
          onAccepted: () => { pendingDraft = null; markAccepted(); },
          onFailure: () => {
            draftCache.recover(pendingDraft);
            pendingDraft = null;
          },
        });
      } catch (error) {
        draftCache.recover(pendingDraft);
        if (intendedNavigation === state.navigationVersion)
          showToast(error.message || "Could not send this input. Your text remains in the composer.");
      }
      finally {
        steeringTracker?.cancel();
        if (state.pendingSteer?.tracker === steeringTracker) state.pendingSteer = null;
        if (!steeringTracker || intendedNavigation === state.navigationVersion) state.composerBusy = false;
        if (directSubmission) { state.submitting = false; state.preparingDirect = false; }
        updateSubmitState();
        if (!submitted && intendedNavigation === state.navigationVersion) composerBrowsing?.finishSubmission(submissionFeedback, false);
      }
    })();
  }
  elements.composer.addEventListener("submit", submitComposer);
  $("#exit-steer").addEventListener("click", cancelOrExitSteer);
  elements.input.addEventListener("input", () => {
    draftCache.touch();
    resizeInput();
    updateSubmitState();
  });
  elements.input.addEventListener("keydown", (event) => {
    if (state.pendingSteer) { if (event.key !== "Tab") event.preventDefault(); return; }
    if (mentionPalette.keydown(event) || slashCommands.keydown(event) || promptRecall.keydown(event)) return;
    if (window.SMTOPromptEditing.keydown(event)) return;
    if (event.key === "Home" && !event.isComposing
      && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
      event.preventDefault();
      elements.input.setSelectionRange(0, 0);
      elements.input.scrollTop = 0;
      elements.input.scrollLeft = 0;
      return;
    }
    if (["ArrowUp", "ArrowDown"].includes(event.key) && !event.isComposing
      && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
      if (navigatePromptHistory(event.key === "ArrowUp" ? -1 : 1)) event.preventDefault();
      return;
    }
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      elements.composer.requestSubmit();
    }
  });
  elements.mode.addEventListener("change", () => {
    // Changing how to send a prompt keeps its text and selection in place.
    draftCache.leave({preserveText: true});
    state.navigationVersion++;
    exitSteer();
    capabilityPolicy.modeChanged();
    permissionPolicy.modeChanged();
    window.SMTONative.syncRefs();
    draftCache.activate(draftScope(), {preserveText: true});
    void composerProfile.selectMode(elements.mode.value);
  });
  elements.model.addEventListener("change", () => {
    state.activeModelName = elements.model.value;
    void composerProfile.patch({llm_model: elements.model.value});
  });
  elements.model.addEventListener("pointerdown", (event) => {
    if (event.button === 0) void loadModels(true);
  });
  elements.model.addEventListener("keydown", (event) => {
    if (!event.repeat && !event.ctrlKey && !event.metaKey
      && [" ", "Enter", "ArrowDown", "ArrowUp", "F4"].includes(event.key)) void loadModels(true);
  });
  window.addEventListener("focus", () => { if (!state.booting) { void loadModels(); void composerProfile.refresh(); } });
  elements.newChat.addEventListener("click", () => clearConversation());
  elements.drawerNewChat.addEventListener("click", () => clearConversation());
  elements.themeToggle.addEventListener("click", () => {
    applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark", { persist: true });
  });
  window.addEventListener("smto:appearance", () => applyTheme(document.documentElement.dataset.theme));
  window.addEventListener("smto:font-scale", () => resizeInput());
  window.addEventListener("smto:appearance-saved", event => {
    ++state.settingsVersion;
    applySettings({settings: event.detail});
  });
  $("#appearance-open").addEventListener("click", () => {
    elements.moreMenu.hidden = true;
    elements.moreToggle.setAttribute("aria-expanded", "false");
    window.SMTOAppearance.openDialog(elements.moreToggle);
  });
  elements.moreToggle.addEventListener("click", () => {
    elements.moreMenu.hidden = !elements.moreMenu.hidden;
    elements.moreToggle.setAttribute("aria-expanded", String(!elements.moreMenu.hidden));
  });
  document.addEventListener("click", (event) => {
    if (elements.composerOptions.open && !elements.composerOptions.contains(event.target) && !event.target.closest("dialog")) {
      elements.composerOptions.open = false;
    }
    if (!elements.moreMenu.hidden && !elements.moreMenu.contains(event.target) && !elements.moreToggle.contains(event.target)) {
      elements.moreMenu.hidden = true;
      elements.moreToggle.setAttribute("aria-expanded", "false");
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && elements.composerOptions.open && !document.querySelector("dialog[open]")) {
      elements.composerOptions.open = false;
      elements.composerOptions.querySelector("summary").focus();
      event.preventDefault();
      return;
    }
    if (event.key === "Escape") {
      exitSteer();
      historyPane.closeTemporary();
      elements.moreMenu.hidden = true;
    }
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") {
      event.preventDefault();
      clearConversation();
    }
  });
  document.querySelectorAll("[data-starter]").forEach((button) => {
    button.addEventListener("click", () => {
      state.promptHistoryNavigation = null;
      elements.input.value = button.dataset.starter || "";
      draftCache.touch();
      resizeInput();
      updateSubmitState();
      elements.input.focus();
    });
  });
  window.addEventListener("beforeunload", () => {
    closeTraces();
  });

  window.SMTONative?.init({requestId: () => state.requestId, conversationId: () => state.conversationId,
    renderGateways: (root, snapshot) => targetSelector.renderGateways(root, snapshot),
    onPermissions: requestId => permissionPolicy.open({requestId}),
    isSteering: () => Boolean(state.steerRequestId),
    contextScope: () => draftCache.scope() || draftScope(),
    onContextRefsChanged: snapshot => { if (draftCache.scope() || snapshot.length) draftCache.touch(true); },
    contextUsage: usage => {
      if (state.openingConversation) return;
      updateContextMeter(usage);
      const turn = state.turns.get(window.SMTONative.current()?.request_id);
      if (turn && window.SMTOContextMeter.remaining(usage) != null) {
        turn.contextUsage = usage;
        renderResponseTokens(turn, turn.responseMetrics || {});
      }
    },
    onCompacted: async requestId => {
      const turn = state.turns.get(requestId);
      if (!turn) return;
      const trace = await apiJson(`/api/agent/trace/${encodeURIComponent(requestId)}`);
      if (!turn.article.isConnected) return;
      for (const event of trace.events || []) {
        if (isCompactionEvent(event)) handleTraceEvent(event, turn, {terminal: false});
      }
    },
    currentRun, notify: showToast, onSteer: startSteer, onCancel: id => promptQueue.cancel(id),
    onTaskState: (snapshot, requestId) => {
      const turn = state.turns.get(requestId);
      setTurnActivityLineage(turn, snapshot);
      setTurnAttemptPrompt(turn, snapshot);
      turn?.artifacts?.update(snapshot.artifact_summary);
      turn?.visualization?.statusChanged(snapshot.status);
      if (!turn || turn === state.currentTurn) return;
      if (observeReply(turn, snapshot)) { renderTurnActivity(turn); return; }
      if (turn.activity.resuming) return;
      const previousStatus = turn.activity.status;
      syncTraceCursor(turn, snapshot.trace_created_at);
      if (Number.isFinite(snapshot.trace_event_id) && snapshot.trace_event_id < turn.activity.sequence) return;
      const status = activity.userStatus(snapshot);
      activity.setStatus(turn.activity, status, {...snapshot, authoritative: true});
      if (window.SMTOInlineSteer.isSteerable({...snapshot, status})) turn.inlineInteraction = false;
      renderTurnActivity(turn);
      if (status === "running" && (previousStatus !== "running" || !turn.source || turn.historical) && !turn.awaitingResume) {
        if (previousStatus !== "running") turn.traceGeneration = (turn.traceGeneration || 0) + 1;
        if (turn.historical && Number.isFinite(snapshot.trace_event_id)) turn.lastEventId = snapshot.trace_event_id;
        turn.historical = false;
        connectTrace(requestId, `/api/agent/stream/${requestId}`, turn, turn.lastEventId || 0, false, false);
      }
      if (previousStatus !== status) void loadFinalTrace(requestId, turn);
    },
    onContinued: (response, previousId, conversationId) => {
      promptQueue.continued(response, previousId);
      if ((state.conversationId || "") !== conversationId) return;
      const lineage = {...response, parent_request_id: response.parent_request_id || response.continuation?.parent_request_id || previousId};
      setTurnActivityLineage(state.turns.get(response.request_id), lineage);
      setTurnAttemptPrompt(state.turns.get(response.request_id), response);
      if (state.requestId && state.requestId !== previousId && state.requestId !== response.request_id) {
        if (response.followup_prompt) {
          const turn = state.turns.get(response.request_id) || createTurn(response.followup_prompt, response.request_id, {
            taskId: response.task_id, parentRequestId: lineage.parent_request_id,
          });
          setTurnActivityLineage(turn, lineage);
          setTurnAttemptPrompt(turn, response);
          connectTrace(response.request_id, response.stream_url || `/api/agent/stream/${response.request_id}`, turn, 0, false, false);
        }
        return;
      }
      if (state.requestId === response.request_id) return;
      const turn = state.turns.get(response.request_id) || createTurn(response.followup_prompt || "", response.request_id, {
        continuation: !response.followup_prompt, taskId: response.task_id, parentRequestId: lineage.parent_request_id,
      });
      setTurnActivityLineage(turn, lineage);
      setTurnAttemptPrompt(turn, response);
      state.currentTurn = turn; state.requestId = response.request_id;
      state.activeEnvelope = null; state.seenEventIds = new Set();
      state.traceStatus = response.status;
      setRunning(response.status === "running");
      connectTrace(response.request_id, response.stream_url || `/api/agent/stream/${response.request_id}`, turn);
      void window.SMTONative.refresh();
    },
    onResuming: requestId => {
      const turn = state.turns.get(requestId);
      if (turn) {
        turn.traceGeneration = (turn.traceGeneration || 0) + 1;
        turn.activity.resuming = true;
        turn.historical = false;
        renderTurnActivity(turn);
      }
    },
    onResumeFailed: requestId => {
      const turn = state.turns.get(requestId);
      if (turn) { turn.activity.resuming = false; renderTurnActivity(turn); }
    },
    onResumed: (response, requestId) => {
      const turn = state.turns.get(requestId);
      if (!turn) return;
      turn.traceGeneration = (turn.traceGeneration || 0) + 1;
      syncTraceCursor(turn, response.trace_created_at);
      const status = activity.userStatus(response);
      const autonomous = ["running", "waiting_job", "waiting_event"].includes(status);
      turn.awaitingResume = false;
      activity.setStatus(turn.activity, status, {...response, authoritative: true});
      turn.activity.pausing = false;
      if (state.currentTurn !== turn) {
        renderTurnActivity(turn);
        connectTrace(requestId, `/api/agent/stream/${requestId}`, turn, turn.lastEventId || 0, false, false);
        if (!autonomous) void loadFinalTrace(requestId, turn);
        window.SMTONative.renderTaskActions();
        return;
      }
      state.traceStatus = status; setRunning(autonomous);
      renderActivity();
      connectTrace(requestId, `/api/agent/stream/${requestId}`, turn, turn.lastEventId || 0);
      if (!autonomous) void loadFinalTrace(requestId, turn);
      void promptQueue.reconcile();
    },
    onPausing: (id, pausing) => {
      const turn = state.turns.get(id);
      if (turn) turn.activity.pausing = pausing;
      if (turn) renderTurnActivity(turn);
    },
    onStopping: (id, stopping) => {
      const turn = state.turns.get(id);
      if (turn) turn.activity.stopping = stopping;
      if (turn) renderTurnActivity(turn);
      const current = window.SMTONative.current();
      if (current.request_id === id) syncInteractionPrompts({...current.snapshot, cancel_requested: stopping}, id);
    },
    onCredentialState: (snapshot, requestId) => {
      targetSelector.setRunTarget(snapshot?.target, requestId);
      syncInteractionPrompts(snapshot, requestId);
    },
    onState: (snapshot, requestId) => {
      const activityTurn = state.turns.get(requestId);
      setTurnActivityLineage(activityTurn, snapshot);
      setTurnAttemptPrompt(activityTurn, snapshot);
      activityTurn?.artifacts?.update(snapshot.artifact_summary);
      activityTurn?.visualization?.statusChanged(snapshot.status);
      const previousStatus = activityTurn?.activity.status;
      const wasAwaitingResume = activityTurn?.awaitingResume;
      syncTraceCursor(activityTurn, snapshot.trace_created_at);
      if (activityTurn && Number.isFinite(snapshot.trace_event_id) && snapshot.trace_event_id < activityTurn.activity.sequence) return;
      if (observeReply(activityTurn, snapshot)) { renderTurnActivity(activityTurn); return; }
      if (activityTurn?.activity.resuming) return;
      if (activityTurn?.awaitingResume && snapshot.status !== "awaiting_confirmation") activityTurn.awaitingResume = false;
      snapshot = {...snapshot, status: activity.userStatus(snapshot), authoritative: true};
      // A wait can be paused again before the resumed worker emits request.running.
      // Native controls discard reads that predate our completed control POST.
      if (activityTurn?.awaitingResume && snapshot.status === "paused" && snapshot.manual_pause) {
        activityTurn.awaitingResume = false;
        if (activityTurn === state.currentTurn) {
          closeTrace(activityTurn); setRunning(false);
        }
      }
      if (activityTurn && !activityTurn.activity.resuming && (!activityTurn.awaitingResume)) {
        activity.setStatus(activityTurn.activity, snapshot.status, snapshot);
        if (window.SMTOInlineSteer.isSteerable(snapshot)) activityTurn.inlineInteraction = false;
        const changed = timing.jobs(activityTurn.timing, snapshot.jobs);
        renderTimingSpans(activityTurn, changed);
        if (activityTurn === state.currentTurn) timingView.refresh(changed);
        if (activityTurn === state.currentTurn) renderActivity();
      }
      // A Resume in another tab reattaches the same turn's existing event stream.
      if (activityTurn === state.currentTurn && snapshot.status === "running" && (previousStatus !== "running" || wasAwaitingResume || activityTurn.historical)
        && !activityTurn.activity.resuming && !activityTurn.awaitingResume) {
        if (activityTurn.historical && Number.isFinite(snapshot.trace_event_id)) activityTurn.lastEventId = snapshot.trace_event_id;
        activityTurn.historical = false;
        activityTurn.traceGeneration = (activityTurn.traceGeneration || 0) + 1;
        state.traceStatus = "running"; setRunning(true);
        connectTrace(requestId, `/api/agent/stream/${requestId}`, activityTurn, activityTurn.lastEventId || 0);
      }
      if (state.steerRequestId && !state.pendingSteer && (!window.SMTOPromptQueue.isSteerable(snapshot.status) || state.steerRequestId !== requestId)) {
        exitSteer(); showToast("The task finished or changed state before the update was sent. Your text is still in the composer.");
      }
      updateSubmitState();
      if (selectedConversation.applying()) return;
      void promptQueue.reconcile();
      const turn = state.turns.get(requestId);
      if (turn?.awaitingResume && !["cancelled", "interrupted"].includes(snapshot.status)) return;
      if (turn && ["cancelled", "interrupted"].includes(snapshot.status)) turn.awaitingResume = false;
      if (turn && ["cancelled", "interrupted"].includes(snapshot.status)) {
        // Keep observing until the trace's terminal event arrives; native save can precede it.
        setRunning(false);
      }
      // Refresh the summary when shared native updates beat the trace stream.
      if (turn === state.currentTurn && ["completed", "answered", "partial", "paused", "paused_budget", "cancelled", "interrupted", "failed"].includes(snapshot.status)) {
        void loadFinalTrace(requestId, turn);
      }
    }});
  window.addEventListener("smto:legal-status", updateSubmitState);
  commandPalette = window.SMTOCommandPalette.create({
    composer: elements.composer, input: elements.input, slash: slashCommands, getView: commandView, showToast,
    getContext: () => ({
      conversation: state.conversationId || "New conversation",
      target: targetSelector.draftSnapshot().gateways.map(item => `${item.gateway_label} (${item.gateway_id})`).join(", ") || "No execution target",
      targetProblem: targetSelector.unavailable(),
    }),
    getProgress: observed => {
      if (observed?.conversation_id && observed.conversation_id !== state.conversationId) return {};
      const task = observed?.task_id ? promptQueue.task(observed.task_id) : null;
      const requestId = task?.current_request_id || task?.latest_request_id || observed?.request_id;
      const turn = requestId ? state.turns.get(requestId) : null;
      return {status: turn?.activity.status || task?.status || observed?.status,
        request_id: requestId, result: turn?.answerText || "",
        target: (task?.context?.gateway_selection?.gateway_ids || turn?.envelope?.snapshot?.gateway_selection?.gateway_ids || []).join(", ")
          || task?.gateway_id || turn?.envelope?.snapshot?.gateway_id || ""};
    },
    newConversation: clearConversation, chooseConversation: openHistory,
    openConversation: scope => {
      const requestId = scope.current_request_id || scope.request_id || (scope.task_id && promptQueue.task(scope.task_id)?.current_request_id);
      if (scope.conversation_id !== state.conversationId && scope.conversation_id)
        void openConversation(scope.conversation_id, {sourceRequestId: requestId || ""});
      else {
        const turn = state.turns.get(requestId);
        turn?.article.scrollIntoView({block: "nearest"});
        if (currentInteraction()?.requestId === requestId) void focusInteraction(currentInteraction());
        else elements.input.focus();
      }
    },
  });
  void boot().finally(() => { state.booting = false; promptQueue.start(); updateSubmitState(); });
})();
