/**
 * @file src/agent_runtime/api/static/agent_ui/header_persistence.js
 * @brief Trigger the controller's SQL checkpoint from the chat header.
 * @details
 * Responsibilities: Request a save, track completion and indicate live background maintenance.
 * Boundaries: Only the server worker writes SQL; this view polls revision metadata.
 * Lifecycle: Poll until confirmed or the server restarts; transient outages keep polling.
 * State: The latest click owns a page-local target epoch/revision and observation token.
 * Security: Same-origin requests contain no database paths or user content.
 * Collaborators: CoreRoutes exposes persistence progress; the shell owns the button.
 * Public surface: persist-now and persistence-status element IDs.
 * @see src/agent_runtime/api/agent_ui_support/route_groups/core.py
 */
(() => {
  "use strict";
  const button = document.getElementById("persist-now");
  const status = document.getElementById("persistence-status");
  if (!button || !status) return;
  let observation = 0;
  let saveBusy = false, maintenanceBusy = false, maintenanceKnown = true;
  let maintenance = null;
  let saveState = button.dataset.state || "idle";
  let saveMessage = button.title || "Save all data to SQL";
  const slowAfterMs = 120000;
  /** Background activity and manual saves independently own the disabled state. */
  function render() {
    const busy = saveBusy || maintenanceBusy;
    const waiting = maintenanceKnown && maintenance?.phase === 'waiting' && !saveBusy && !maintenanceBusy;
    const detail = window.SMTOBackendActivity?.describeMaintenance(maintenance);
    const message = maintenanceBusy && !saveBusy ? (maintenanceKnown
      ? detail || "Background storage maintenance in progress…" : "Waiting for background storage status…")
      : waiting && saveState !== 'error' ? detail : saveMessage;
    button.dataset.state = maintenanceBusy ? (maintenanceKnown ? "maintenance" : "maintenance-wait")
      : waiting && saveState !== 'error' ? 'waiting' : saveState;
    button.disabled = busy;
    button.setAttribute("aria-busy", String(busy));
    button.title = message;
    button.setAttribute("aria-label", message);
    if (status.textContent !== message) status.textContent = message;
  }
  /** Reflect the save state without clearing an overlapping background operation. */
  function show(state, message) {
    saveState = state;
    saveMessage = message;
    render();
  }
  /** Prevent duplicate saves while pending; a reported write failure permits retry. */
  function setBusy(busy) {
    saveBusy = busy;
    render();
  }
  window.addEventListener("smto:backend-activity", event => {
    const active = event.detail?.maintenance?.active;
    maintenanceKnown = typeof active === "boolean";
    if (maintenanceKnown) { maintenanceBusy = active; maintenance = event.detail.maintenance; }
    render();
  });
  /** Read bounded, uncached progress from the controller that accepted the save. */
  async function request(method) {
    const response = await fetch("/api/agent/persistence", {
      method, cache: "no-store", signal: AbortSignal.timeout(15000),
    });
    if (!response.ok) throw new Error("Save unavailable. Try again.");
    return response.json();
  }
  /** Observe the accepted revision, never treating elapsed time as a failed write.
   * A failed checkpoint can recover automatically. Keep watching while allowing a
   * manual retry; its new token prevents older requests from changing the button.
   */
  async function observe(target, token) {
    const started = Date.now();
    while (token === observation) {
      let current;
      try {
        current = await request("GET");
      } catch (_) {
        if (token !== observation) return;
        show("saving", "Waiting for the server to confirm the SQL save… Checking automatically.");
        await new Promise(resolve => setTimeout(resolve, 5000));
        continue;
      }
      if (token !== observation) return;
      if (current.epoch !== target.target_epoch) {
        show("error", "Server restarted before the save could be confirmed. Save again.");
        return;
      }
      if (current.last_checkpoint_epoch === target.target_epoch
          && current.last_checkpoint_revision >= target.target_revision
          && (target.target_checkpoint_sequence == null
              || current.completed_checkpoint_sequence >= target.target_checkpoint_sequence)) {
        const cleanup = current.cleanup;
        show("saved", cleanup && (cleanup.pending || cleanup.last_error || cleanup.phase === "deferred")
          ? "Data saved to SQL; cleanup pending. It will retry when possible."
          : cleanup?.retained ? "Data saved to SQL. Cleanup finished; shared or unresolved work is retained."
          : "Data saved to SQL. Save again");
        return;
      }
      const slow = Date.now() - started >= slowAfterMs;
      if (current.last_error && current.checkpoint_failure_count > target.checkpoint_failure_count
          && !current.checkpoint_in_progress) {
        setBusy(false);
        show("error", "Could not save data to SQL. The server will retry automatically, or click to retry now.");
      } else {
        setBusy(true);
        const phase = current.cleanup?.phase;
        show("saving", phase === "preparing" ? "Preparing storage cleanup…"
          : phase === "purging" ? "Data saved to SQL. Removing obsolete files…" : slow
          ? "Still saving to SQL… Large saves can take several minutes. Checking automatically."
          : "Saving all data to SQL…");
      }
      await new Promise(resolve => setTimeout(resolve, slow ? 5000 : 1000));
    }
  }
  button.addEventListener("click", async () => {
    if (button.disabled) return;
    const token = ++observation;
    setBusy(true);
    show("saving", "Saving all data to SQL…");
    try {
      const target = await request("POST");
      await observe(target, token);
    } catch (error) {
      if (token !== observation) return;
      show("error", error.name === "TimeoutError" || error.name === "TypeError"
        ? "Could not confirm the save. Check your connection and try again." : error.message);
    } finally {
      if (token === observation) setBusy(false);
    }
  });
})();
