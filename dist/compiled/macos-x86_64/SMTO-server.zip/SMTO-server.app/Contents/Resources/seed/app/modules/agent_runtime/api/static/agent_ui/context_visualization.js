/* On-demand ASCII context accounting, using the latest request's recorded facts. */
(() => {
  "use strict";
  const finite = value => typeof value === "number" && Number.isFinite(value) && value >= 0;
  const count = value => Math.round(value).toLocaleString();
  const components = [
    ["stable_system_tokens", "System instructions"],
    ["tool_schema_tokens", "Tool definitions"],
    ["runtime_fact_tokens", "Runtime facts"],
    ["current_turn_tokens", "Current turn"],
    ["conversation_history_tokens", "Conversation history"],
  ];
  function render(usage) {
    const capacity = usage?.context_window_tokens, used = usage?.used_tokens ?? usage?.used_tokens_estimate;
    const exceeded = usage?.status === "exceeded";
    const lines = ["Context window", "Latest recorded model request", ""];
    if (!finite(capacity) || !capacity || !finite(used)) {
      return [...lines, "+------------------------------------------------------------+",
        "| ?????????????????????????????????????????????????????????? |",
        "+------------------------------------------------------------+", "",
        exceeded ? "Context capacity exceeded; token counts are unavailable."
          : "Context usage is not available yet.",
        "The partition will update when request measurements arrive."].join("\n");
    }
    lines.push(`Capacity: ${count(capacity)} tokens`,
      `Counts: ${usage.estimated === false ? "measured" : "estimated"}`, "");
    const hasInput = finite(usage.input_tokens);
    const output = hasInput ? Math.max(0, used - usage.input_tokens) : null;
    const reserved = finite(usage.reserved_output_tokens) ? usage.reserved_output_tokens : 0;
    const rows = hasInput ? [
      ["I", "Input (prompt, history, tools)", usage.input_tokens],
      ["O", "Generated output", output],
      ["R", "Unused output reservation", Math.max(0, reserved - output)],
    ] : [["U", "Recorded usage (unsplit)", used]];
    const required = rows.reduce((sum, row) => sum + row[2], 0);
    rows.push(exceeded ? ["?", "Unavailable after rejection", Math.max(0, capacity - required)]
      : [".", "Remaining", Math.max(0, capacity - required)]);
    const width = 60;
    let total = 0, filled = 0, bar = "";
    for (const [glyph, , tokens] of rows) {
      total += tokens;
      const end = Math.min(width, Math.round(total / capacity * width));
      bar += glyph.repeat(Math.max(0, end - filled)); filled = end;
    }
    lines.push(`+${"-".repeat(width)}+`, `|${bar.padEnd(width, "?")}|`, `+${"-".repeat(width)}+`, "");
    for (const [glyph, label, tokens] of rows) {
      lines.push(`${glyph}  ${label.padEnd(30)} ${count(tokens).padStart(10)}  ${(tokens / capacity * 100).toFixed(1).padStart(5)}%`);
    }
    if (required > capacity) lines.push("", `Over capacity by ${count(required - capacity)} tokens.`);
    else if (exceeded) lines.push("", "The provider rejected this request for exceeding context capacity.");
    if (hasInput) lines.push("", `Output reservation: ${count(reserved)} tokens total.`,
      "Generated output consumes that reservation; it is not counted twice.");
    const details = components.filter(([key]) => finite(usage.component_estimates?.[key]));
    if (details.length) {
      lines.push("", "Input components (estimates)", "-".repeat(width));
      for (const [key, label] of details) lines.push(`  ${label.padEnd(32)} ~${count(usage.component_estimates[key])}`);
      lines.push("Component estimates may differ from the measured input total.");
    }
    lines.push("", "This is one request, not the task's cumulative token totals.",
      "New messages and tool results can change the next request.");
    return lines.join("\n");
  }

  const node = (tag, text, className) => {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (className) el.className = className;
    return el;
  };
  let sequence = 0;
  function create(action, root) {
    const id = `context-visualization-${++sequence}`;
    let usage = null, panel = null, pre = null, diagram = "";
    action.setAttribute("aria-controls", id);
    action.setAttribute("aria-expanded", "false");
    function draw() {
      if (!panel || panel.hidden) return;
      const next = render(usage);
      if (next !== diagram) { diagram = next; pre.textContent = diagram; }
    }
    action.addEventListener("click", () => {
      if (!panel) {
        panel = node("section", "", "run-execution-visualization context-visualization");
        panel.id = id; panel.hidden = true;
        panel.setAttribute("aria-label", "Context window visualization");
        pre = node("pre"); pre.tabIndex = 0;
        pre.setAttribute("aria-label", "Context window partition");
        const controls = node("div", "", "run-execution-controls");
        const feedback = node("span", "", "run-execution-feedback"); feedback.setAttribute("role", "status");
        const copy = node("button", "Copy diagram", "run-detail-action"); copy.type = "button";
        const copied = window.SMTOCopyFeedback.bind(copy);
        copy.addEventListener("click", async () => {
          try { await navigator.clipboard.writeText(diagram); copied(); feedback.textContent = "Copied"; }
          catch (_) { feedback.textContent = "Could not copy diagram. Select the text to copy."; }
        });
        controls.append(feedback, copy); panel.append(pre, controls); root.append(panel);
      }
      panel.hidden = !panel.hidden;
      action.setAttribute("aria-expanded", String(!panel.hidden));
      draw();
    });
    return {update(value) { usage = value; draw(); }};
  }
  window.SMTOContextVisualization = {render, create};
})();
