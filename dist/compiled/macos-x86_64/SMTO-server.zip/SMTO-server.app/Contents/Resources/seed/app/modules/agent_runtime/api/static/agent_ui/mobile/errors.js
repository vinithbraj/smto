/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/errors.js
 * @brief Present canonical errors within the independently loaded mobile page.
 * @details
 * Responsibilities: Build mobile cards and bounded notification summaries from
 * canonical server copy. Compact cards and toasts expand their guidance; notifications retain retry cautions.
 * Boundaries: The desktop repair-copy behavior is separate. This renderer neither
 * reconciles uncertain effects nor changes settings or execution authorization.
 * Lifecycle: Mobile modules load this global facade; a missing ManualLinks module
 * is imported on demand and updates the card's existing help link after loading.
 * State: Definitions and up to 128 cached lookup promises live for the page;
 * mounting replaces one error slot, without persisting error occurrences.
 * Security: Build textContent nodes with bounded display masking; technical
 * details are presentation copies and never replace authoritative receipts.
 * Collaborators: Mobile API uses the fetch/JSON wrappers; error_catalog supplies
 * identities; manual_links.js resolves the separately served manual location.
 * Public surface: SMTOErrors retains the shared facade names for mobile
 * consumers, propagates aborts, and maps transport failures without retrying.
 * Compatibility: Preserve mobile notification copy and legacy fallback identity;
 * sharing a global name does not make the desktop implementation interchangeable.
 * @see src/error_catalog/http_boundary.py
 * @see src/agent_runtime/api/static/agent_ui/mobile/api.js
 * @see src/agent_runtime/api/static/agent_ui/manual_links.js
 */
(() => {
  "use strict";
  const cache = new Map();
  const definitions = new Map();
  for (const definition of window.SMTOErrorDefinitions || []) {
    for (const ref of [definition.error_id, definition.error_guid, definition.slug, ...(definition.aliases?.error_kinds || [])]) definitions.set(ref, definition);
  }
  /** Produce bounded masked text for mobile display; the original response remains authoritative. */
  const safe = (value, limit = 4000) => String(value ?? "").slice(0, limit)
    .replace(/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?(?:-----END [^-]*PRIVATE KEY-----|$)/g, "[redacted private key]")
    .replace(/(authorization\s*:?\s*(?:bearer|basic)\s+)[^\s,;]+/gi, "$1[redacted]")
    .replace(/(\bbearer\s+)[^\s,;]+|(\bbasic\s+)[a-z0-9+/]{12,}={0,2}/gi, (_match, bearer, basic) => `${bearer || basic}[redacted]`)
    .replace(/(["']?(?:authorization|proxy-authorization|cookie|set-cookie)["']?\s*:\s*)(?:"[^"\r\n]*"|'[^'\r\n]*'|[^\r\n]+)/gi, "$1[redacted]")
    .replace(/((?:[\w-]*(?:password|passwd|passphrase|token|secret|credential|api[_-]?key|cookie)[\w-]*)["']?\s*[=:]\s*)(?:"(?:\\.|[^"\r\n])*"|'(?:\\.|[^'\r\n])*'|[^\s,;&}]+)/gi, "$1[redacted]")
    .replace(/(--(?:password|token|secret|api-key)\s+)(?:"[^"]*"|'[^']*'|\S+)/gi, "$1[redacted]")
    .replace(/([a-z][a-z0-9+.-]*:\/\/)[^/@\s]+@/gi, "$1[redacted]@");
  /** Allocate an unattached node using textContent; the mobile host owns its lifetime. */
  const element = (tag, text, className) => {
    const node = document.createElement(tag);
    if (text != null) node.textContent = safe(text);
    if (className) node.className = className;
    return node;
  };

  /** Resolve only exact server-owned identities, keeping catalog copy out of browser code. */
  async function lookup(ref) {
    if (definitions.has(ref)) return definitions.get(ref);
    if (!cache.has(ref)) {
      if (cache.size >= 128) cache.delete(cache.keys().next().value);
      cache.set(ref, fetch(`/api/agent/errors/${encodeURIComponent(ref)}`).then(async response => {
        if (!response.ok) throw new Error("SMTO-SYS-0001");
        return response.json();
      }).catch(error => { cache.delete(ref); throw error; }));
    }
    return cache.get(ref);
  }

  /** Build a synchronous field error from the generated canonical UI subset. */
  function error(ref, facts = {}) {
    const definition = definitions.get(ref);
    const failure = new Error(definition ? `${definition.error_id} · ${displayCopy(definition.short_description)}` : "SMTO-SYS-0001");
    failure.error_ref = ref;
    if (definition) {
      const runtimeFacts = {};
      for (const name of ["field", "minimum", "maximum", "exclusiveMinimum", "expected"]) {
        if (["string", "number", "boolean"].includes(typeof facts[name])) runtimeFacts[name] = safe(facts[name], 200);
      }
      failure.error_detail = {...definition, runtime_facts: runtimeFacts, technical_detail: "",
        occurrence_id: globalThis.crypto?.randomUUID?.() || "", stage: "browser_validation"};
    }
    return failure;
  }

  /** Carry the server's canonical envelope through clients that already parsed JSON. */
  function fromPayload(payload, status) {
    const legacyRef = payload?.error_kind || payload?.category;
    const failure = error(definitions.has(legacyRef) ? legacyRef : "SMTO-SYS-0001");
    const detail = payload?.error_detail || (payload?.error_id ? payload : null);
    if (detail) {
      failure.error_detail = detail;
      failure.message = `${detail.error_id} · ${safe(displayCopy(observation(detail)))}`;
    } else if (failure.error_detail) {
      const legacyText = typeof payload === "string" ? payload : payload?.error || payload?.detail || payload?.message;
      failure.error_detail = {...failure.error_detail, technical_detail: typeof legacyText === "string" ? safe(legacyText) : ""};
    }
    failure.status = status;
    return failure;
  }

  /** Display field/API failures using the same presenter while preserving focus ownership. */
  function present(host, value, options = {profile: "compact"}) {
    const detail = value?.error_detail || value;
    if (host) host.replaceChildren(render(detail, options));
    if (!value?.error_detail && value?.error_ref) {
      lookup(value.error_ref).then(definition => {
        if (host?.isConnected) host.replaceChildren(render(definition, options));
      }).catch(() => {});
    }
  }

  /** Resolve optional branding at render time; preserve server copy if it is not loaded. */
  const displayCopy = value => window.SMTOBranding?.text(value) ?? value;

  /** Prefer server-projected facts; historical likely_cause prose is not evidence. */
  const observation = detail => detail.presentation?.observation || detail.short_description;
  /** Keep reconciliation ahead of all advisory repair steps. */
  const nextStep = detail => detail.resolution?.retry?.guidance === "unsafe_without_reconciliation"
    ? detail.resolution.primary || detail.presentation?.next_step || detail.how_to_fix?.summary
    : detail.presentation?.next_step || detail.resolution?.primary || detail.how_to_fix?.summary || detail.fix_hint;


  /** Use only server-projected guidance; old payloads retain their existing help. */
  const legacyGuidance = {
    summary: "Check whether your action already happened, then keep the error reference for help.",
    steps: [{instruction: "Check the task’s saved results or the item you were changing before trying again.",
      why: "This older error message does not establish whether the action already happened."},
      {instruction: "Share the error reference with the person managing the app. If you manage it yourself, use Technical details to investigate.",
      why: "The reference helps locate the failure without copying your task content."}],
    success_check: "The earlier action’s result is known and the underlying problem has been addressed.",
    if_still_failing: "Keep the original task and error reference. Ask the person managing the app to check it before repeating work.",
  };
  const userGuidance = detail => detail.presentation?.user_guidance || detail.how_to_fix?.user_guidance
    || definitions.get(detail.error_id)?.how_to_fix?.user_guidance || legacyGuidance;
  const plainLanguage = detail => detail.presentation?.plain_language || detail.explain_like_5 || observation(detail);
  const uncertain = detail => detail.resolution?.retry?.guidance === "unsafe_without_reconciliation";
  const userAction = detail => uncertain(detail)
    ? "Check whether the earlier action already happened before trying again."
    : userGuidance(detail)?.summary || nextStep(detail);

  /** An allowlist keeps task content, exceptions and runtime facts off the clipboard. */
  function supportText(detail) {
    const lines = [`${safe(detail.error_id, 40)} · ${safe(displayCopy(detail.title), 180)}`];
    if (/^[a-z0-9-]{1,160}$/.test(detail.slug || "")) lines.push(`Error: ${detail.slug}`);
    if (/^[a-z0-9_.:-]{1,120}$/i.test(detail.occurrence_id || "")) lines.push(`Error reference: ${safe(detail.occurrence_id, 120)}`);
    if (/^[a-z0-9_.:-]{1,120}$/i.test(detail.stage || "")) lines.push(`Stage: ${safe(detail.stage, 120)}`);
    return lines.join("\n");
  }

  /** Clipboard failure exposes selectable text; it never creates another error card. */
  function copyControl(parent, detail) {
    const button = element("button", "Copy error details", "of-error-copy"); button.type = "button";
    const feedback = element("span", "", "of-error-copy-status"); feedback.setAttribute("role", "status");
    let fallback;
    button.onclick = async () => {
      const text = supportText(detail);
      try {
        await navigator.clipboard.writeText(text);
        feedback.textContent = "Error details copied.";
        fallback?.remove(); fallback = null;
      } catch (_) {
        feedback.textContent = "Automatic copying is unavailable. Select and copy the text below.";
        if (!fallback) {
          fallback = element("textarea", null, "of-error-copy-text");
          fallback.readOnly = true; fallback.rows = 4;
          fallback.setAttribute("aria-label", "Error details to copy"); parent.append(fallback);
        }
        fallback.value = text; fallback.focus(); fallback.select();
      }
    };
    parent.append(button, feedback);
  }

  function guidanceSteps(parent, guidance) {
    const list = element("ol", null, "of-error-steps");
    for (const step of guidance.steps || []) {
      const item = element("li");
      item.append(element("p", displayCopy(step.instruction)));
      item.append(element("p", displayCopy(step.why), "of-error-why"));
      list.append(item);
    }
    parent.append(list);
    parent.append(element("strong", "What success looks like"));
    parent.append(element("p", displayCopy(guidance.success_check)));
    parent.append(element("strong", "If it still fails"));
    parent.append(element("p", displayCopy(guidance.if_still_failing)));
  }

  function notificationText(value) {
    const detail = value?.error_detail || value;
    if (!detail || detail.severity === "info" || detail.resolution?.status === "informational") return "";
    if (!/^SMTO-[A-Z0-9]{2,5}-\d{4}$/.test(detail.error_id || "")) return "";
    // Put the next action first, so truncation cannot remove the reconciliation caution.
    const action = safe(displayCopy(userAction(detail)), 260);
    return safe(`${detail.error_id} · ${action} ${safe(displayCopy(plainLanguage(detail)), 260)}`, 600);
  }

  /** Construct one safe card; all links navigate existing product flows. */
  function render(value, {profile = "full"} = {}) {
    const detail = value?.error_detail || value;
    const canonical = detail && typeof detail === "object" && /^SMTO-[A-Z0-9]{2,5}-\d{4}$/.test(detail.error_id);
    const root = element("section", null, `of-error-card of-error-${profile}`);
    root.setAttribute("role", "alert");
    const id = canonical ? detail.error_id : "SMTO-SYS-0001";
    root.append(element("strong", canonical ? displayCopy(detail.title) : "Request failed", "of-error-title"));
    root.append(element("p", `${id}${canonical && profile === "full" ? ` · ${detail.slug}` : ""}`, "of-error-identity"));
    const explanation = canonical ? displayCopy(plainLanguage(detail)) : typeof detail === "string" ? detail : detail?.message_markdown || detail?.message || detail?.detail || detail?.technical_detail || "";
    root.append(element("p", explanation));
    if (canonical) {
      const guidance = userGuidance(detail);
      if (uncertain(detail)) root.append(element("p", userAction(detail), "of-error-caution"));
      if (guidance) {
        root.append(element("strong", "How to fix", "of-error-heading"));
        if (profile === "full") guidanceSteps(root, guidance);
        else {
          root.append(element("p", displayCopy(userAction(detail)), "of-error-fix"));
          const steps = element("details"); steps.append(element("summary", "Show steps"));
          guidanceSteps(steps, guidance); root.append(steps);
        }
      } else {
        const fix = nextStep(detail);
        if (fix) root.append(element("p", displayCopy(fix), "of-error-fix"));
      }
      const links = element("nav", null, "of-error-actions");
      links.setAttribute("aria-label", "Error help");
      for (const action of profile === "toast" ? [] : detail.settings_actions || []) {
        const url = new URL("/settings", location.origin);
        url.searchParams.set("section", action.section_id);
        for (const [field, query] of [["setting_key", "setting"], ["parameter_key", "parameter"], ["component_action", "action"]]) {
          if (action[field]) url.searchParams.set(query, action[field]);
        }
        const link = element("a", action.label); link.href = url.pathname + url.search;
        links.append(link);
        if (action.applies_to === "new_task") links.append(element("span", "Applies to a new task; resumed tasks keep their saved value."));
      }
      const explain = element("a", "Explain this error");
      explain.href = window.SMTOManualLinks?.manualUrl(detail.manual_doc_id) || `/manual#doc=${encodeURIComponent(detail.manual_doc_id)}`;
      explain.target = "_blank"; explain.rel = "noopener"; links.append(explain);
      if (!window.SMTOManualLinks) {
        import("../manual_links.js").then(() => {
          explain.href = window.SMTOManualLinks?.manualUrl(detail.manual_doc_id) || explain.href;
        }).catch(() => {});
      }
      copyControl(links, detail); root.append(links);
      const disclosure = element("details"); disclosure.append(element("summary", "Technical details"));
      disclosure.append(element("p", displayCopy(observation(detail))));
      disclosure.append(element("p", displayCopy(nextStep(detail))));
      for (const step of detail.how_to_fix?.steps || []) disclosure.append(element("p", displayCopy(step.instruction)));
      if (detail.resolution?.retry?.condition) disclosure.append(element("p", displayCopy(detail.resolution.retry.condition)));
      if (detail.technical_detail) disclosure.append(element("pre", detail.technical_detail));
      disclosure.append(element("pre", JSON.stringify(detail.runtime_facts || {}, null, 2)));
      if (detail.occurrence_id) disclosure.append(element("p", `Occurrence: ${detail.occurrence_id}`));
      root.append(disclosure);
    } else {
      root.append(element("strong", "How to fix", "of-error-heading"));
      guidanceSteps(root, legacyGuidance);
      copyControl(root, {error_id: id, title: "Request failed"});
      const disclosure = element("details"); disclosure.append(element("summary", "Technical details"));
      disclosure.append(element("pre", explanation)); root.append(disclosure);
    }
    return root;
  }

  /** Update one host-owned slot without replacing answers, receipts or action controls. */
  function mount(host, detail, options) {
    if (!host) return;
    let slot = [...host.children].find(child => child.classList.contains("of-error-slot"));
    if (!detail || detail.severity === "info" || detail.resolution?.status === "informational") { slot?.remove(); return; }
    if (!slot) { slot = element("div", null, "of-error-slot"); host.append(slot); }
    slot.replaceChildren(render(detail, options));
  }

  /** Preserve canonical API payloads on client errors for the shared presenter. */
  async function fromResponse(response) {
    let payload;
    try { payload = await response.json(); } catch { payload = await lookup("ui_response_invalid").catch(() => null); }
    return fromPayload(payload, response.status);
  }

  /** Preserve abort semantics and identify a failed browser transport without retrying it. */
  async function fetchResponse(input, options) {
    try { return await window.fetch(input, options); }
    catch (failure) {
      if (failure?.name === "AbortError") throw failure;
      throw error("ui_network_failed");
    }
  }

  /** Identify a malformed API payload without reflecting the response body. */
  async function readJson(response) {
    try { return await response.json(); }
    catch (failure) {
      if (failure?.name === "AbortError") throw failure;
      throw error("ui_response_invalid");
    }
  }
  window.SMTOErrors = {render, mount, lookup, fromResponse, fromPayload, error, present, notificationText,
    fetch: fetchResponse, readJson};
})();
