/** Read-only startup report. Poll only while the controller's single check is running. */
(() => {
  "use strict";
  const labels = {not_started: "Startup model check not run", checking: "Checking model at startup…",
    ready: "Startup model check passed", failed: "Startup model check failed", unverified: "Startup model check inconclusive"};
  const node = (tag, text, className) => {
    const result = document.createElement(tag);
    if (text != null) result.textContent = text;
    if (className) result.className = className;
    return result;
  };
  function create() {
    const element = node("section", null, "model-readiness");
    element.setAttribute("aria-label", "Startup model check");
    const title = node("h3", "Startup model check", "model-readiness-title");
    const status = node("p", null, "model-readiness-meta");
    status.setAttribute("role", "status");
    const note = node("p", "One model request is checked when the controller starts. This report describes the startup configuration; later tasks report their own errors.");
    const checks = node("div", null, "model-readiness-checks");
    const actions = node("div", null, "model-readiness-actions");
    const copy = node("button", "Copy diagnostic report");
    copy.type = "button"; copy.disabled = true; actions.append(copy);
    element.append(title, status, note, checks, actions);
    let report = null, timer = null, disposed = false, revision = 0;
    function render(value) {
      report = value;
      title.textContent = labels[value.status] || labels.unverified;
      status.textContent = `${value.resolved_model || value.target?.model || "Configured model"}${value.checked_at ? ` · Checked ${new Date(value.checked_at * 1000).toLocaleString()}` : ""}`;
      checks.replaceChildren();
      copy.disabled = false;
      if (value.note) checks.append(node("p", value.note));
      for (const item of value.checks || []) {
        const row = node("details");
        row.append(node("summary", `${item.name.replaceAll("_", " ")}: ${item.outcome}`));
        if (item.error_detail) {
          if (window.SMTOErrors) row.append(window.SMTOErrors.render(item.error_detail));
          else row.append(node("p", item.error_detail.short_description), node("p", item.error_detail.how_to_fix?.summary));
        }
        checks.append(row);
      }
    }
    async function refresh() {
      clearTimeout(timer);
      if (disposed) return;
      const own = ++revision;
      try {
        const response = await fetch("/api/agent/readiness", {cache: "no-store"});
        const value = await response.json();
        if (disposed || own !== revision) return;
        if (!response.ok) {
          status.textContent = "The startup report could not be loaded.";
          return;
        }
        render(value);
        if (value.status === "checking") timer = setTimeout(() => {
          if (element.isConnected) void refresh();
          else dispose();
        }, 1000);
      } catch {
        if (!disposed && own === revision) status.textContent = "The startup report is temporarily unavailable.";
      }
    }
    copy.addEventListener("click", async () => {
      if (!report) return;
      try { await navigator.clipboard.writeText(JSON.stringify(report, null, 2)); status.textContent = "Diagnostic report copied."; }
      catch { status.textContent = "Clipboard access is unavailable. Expand the check to read its details."; }
    });
    function dispose() { disposed = true; revision += 1; clearTimeout(timer); }
    queueMicrotask(() => void refresh());
    return {element, refresh, dispose};
  }
  window.SMTOReadiness = {create};
})();
