---
{"title": "Try your first task", "status": "published"}
---
## Choose a small task you can check

Start with a short text file that contains no private information. Ask the assistant
to read it and summarize the main points. A small task makes it easier to see whether
the tool worked and whether the AI understood the contents.

Before you start, follow the [installation guide](/docs/getting-started/install)
and connect a supported AI model. The [model settings guide](/docs/configuration/models)
explains the available settings.

## Say what you want and what should stay unchanged

For example: “Read this text file and summarize its three main points. Do not change
the file.” Tell the assistant which file you mean, and choose the computer that has it.
SMTO's Gateway program runs file tools on the selected computer.

The assistant needs the file-reading tool and permission to use it. If SMTO asks
for approval, check the file and requested action before answering.

## Watch the work

The AI chooses the file tool. SMTO checks access, runs it, and records its result.
The AI then uses the returned text to write an answer. If the file is missing or
cannot be read, that problem needs to be addressed before a summary can be trusted.

You can open the activity history to see which tools ran and what they returned.
A message saying that an action started is not the same as a completed result.

## When a task needs more time or your input

A short action returns its result when it finishes. A supported longer action can
run as a saved background job. SMTO follows its progress and can continue when the
result arrives. If the task needs your answer or approval, it saves its progress
and waits without repeatedly asking the model for another decision.

You can close the browser while the controller keeps working. The controller and
any model connection, Gateway or tool needed for the next step must still be
available. A waiting task is not a finished task. Read about
[jobs and waiting](/docs/concepts/jobs) before trying longer work.

## Compare the answer with the file

Did the summary include the main points? Did it add anything the file did not say?
Did the assistant follow the instruction to leave the file unchanged? Even when a
tool runs successfully, the AI can misunderstand the text.

If something is wrong, point out the specific problem and ask for a correction.
Keep the first few tasks easy to check before relying on a larger piece of work.

Read [how a task runs](/learn/agent-execution-loop) and
[how to check results](/learn/verifiable-agent-completion).
Explore [SMTO's features](/product) or [installation options](/download).
