/* Literal HTTP connection configuration. Projection policy is independent of execution. */
(() => {
  "use strict";
  const words = value => value.replaceAll("_", " ");
  const title = value => words(value).replace(/^./, c => c.toUpperCase());
  let sequence = 0;
  async function api(path, method = "GET", body) {
    const response = await window.SMTOErrors.fetch(`/api/agent/http/${path}`, {method, cache: "no-store", headers: {"Content-Type": "application/json"}, body: body === undefined ? undefined : JSON.stringify(body)});
    const result = await window.SMTOErrors.readJson(response);
    if (!response.ok) throw window.SMTOErrors.fromPayload(result, response.status);
    return result;
  }
  function el(tag, text, className) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function button(label, action, className) {
    const node = el("button", label, className); node.type = "button"; node.onclick = action; return node;
  }
  function field(parent, label, value = "", kind = "text", choices = []) {
    const wrapper = el("div", "", "http-field"), caption = el("label", label);
    const input = el(kind === "select" ? "select" : kind === "textarea" ? "textarea" : "input");
    input.id = `http-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${++sequence}`;
    caption.htmlFor = input.id;
    if (kind === "select") {
      for (const choice of choices) {
        const [key, text] = Array.isArray(choice) ? choice : [choice, title(choice)];
        const option = el("option", text); option.value = key; input.append(option);
      }
    } else if (kind !== "textarea") input.type = kind;
    if (kind === "checkbox") {
      input.checked = Boolean(value);
      wrapper.classList.add("http-checkbox");
    }
    else input.value = value ?? "";
    input.autocomplete = "off"; input.spellcheck = false;
    if (kind === "textarea") input.rows = 5;
    wrapper.append(caption, input); parent.append(wrapper); return input;
  }
  const choose = (parent, label, options, value) => field(parent, label, value ?? options[0], "select", options);
  function group(parent, label, collapsed = false) {
    const node = el(collapsed ? "details" : "fieldset", "", "http-form-section");
    node.append(el(collapsed ? "summary" : "legend", label));
    const body = el("div", "", "http-form-grid"); node.append(body); parent.append(node); return body;
  }
  function show(node, visible) {
    node.hidden = !visible;
    node.querySelectorAll("input,select,textarea").forEach(input => { input.disabled = !visible; });
  }
  function optional(object, key, input) { if (input.value !== "") object[key] = input.value; }
  const commas = value => value.split(",").map(item => item.trim()).filter(Boolean);
  function rows(parent, label, initial, columns, limit = 32) {
    const section = group(parent, label), list = el("div", "", "http-field-rows"); section.append(list);
    const items = [];
    function add(value = {}) {
      if (items.length >= limit) return;
      const row = el("fieldset", "", "http-field-row"); row.append(el("legend", `${label} item ${items.length + 1}`));
      const controls = {};
      for (const [key, label, options, fallback] of columns) controls[key] = options
        ? choose(row, label, options, value[key] ?? fallback)
        : field(row, label, value[key] ?? fallback ?? "");
      const item = {row, controls}; items.push(item);
      row.append(button("Remove item", () => { items.splice(items.indexOf(item), 1); row.remove(); addButton.disabled = false; addButton.focus(); }));
      list.append(row); addButton.disabled = items.length >= limit;
    }
    const addButton = button(`Add ${label.toLowerCase()} item`, () => { add(); items.at(-1)?.row.querySelector("input,select")?.focus(); });
    section.append(addButton); initial.forEach(add);
    return () => items.map(({controls}) => Object.fromEntries(Object.entries(controls).map(([key, input]) => [key, input.value])));
  }
  function dialog(title, submitLabel) {
    const invoker = document.activeElement, modal = el("dialog", "", "http-connection-dialog");
    const form = el("form"), heading = el("h2", title), body = el("div", "", "http-dialog-body");
    heading.id = `http-dialog-heading-${++sequence}`; modal.setAttribute("aria-labelledby", heading.id);
    const status = el("p", "", "http-dialog-status"); status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
    const actions = el("footer", "", "http-dialog-actions"), cancel = button("Cancel", () => modal.close()), save = el("button", submitLabel);
    save.type = "submit"; actions.append(cancel, save); form.append(heading, body, status, actions); modal.append(form); document.body.append(modal);
    modal.addEventListener("close", () => {
      form.querySelectorAll("input,textarea").forEach(input => { input.value = ""; }); modal.remove();
      if (invoker?.isConnected) invoker.focus();
    });
    return {modal, form, body, status, save, show() { modal.showModal(); (body.querySelector("input:not(:disabled),select,textarea") || cancel).focus(); }};
  }
  function authEditor(parent, initial, types) {
    const type = choose(parent, "Authentication", types, initial.type || "none"), area = el("div", "", "http-auth-fields"); parent.append(area);
    const drafts = {[initial.type || "none"]: initial}; let read = () => initial, previous = type.value;
    function render() {
      area.replaceChildren(); const config = drafts[type.value] || {type: type.value}, body = group(area, "Authentication settings");
      const kind = type.value;
      if (["basic", "digest", "ntlm"].includes(kind)) {
        const username = field(body, "Username", config.username || ""), password = field(body, "Password", config.password || "");
        read = () => ({type: kind, username: username.value, password: password.value});
      } else if (kind.startsWith("api_key_")) {
        const key = {api_key_header: "header_name", api_key_query: "query_name", api_key_cookie: "cookie_name"}[kind];
        const name = field(body, title(key), config[key] || {header_name: "Authorization", query_name: "api_key", cookie_name: "session"}[key]); name.required = true;
        const value = field(body, "API key", config.value || "");
        const prefix = kind === "api_key_header" ? field(body, "Prefix", config.prefix || "") : null;
        const suffix = prefix ? field(body, "Suffix", config.suffix || "") : null;
        read = () => ({type: kind, [key]: name.value, value: value.value, ...(prefix ? {prefix: prefix.value, suffix: suffix.value} : {})});
      } else if (kind === "secret_headers") {
        const readRows = rows(body, "Secret header", config.headers || [{name: "X-Access-Key", value: ""}], [["name", "Header name"], ["value", "Header value"], ["prefix", "Prefix"], ["suffix", "Suffix"]], 16);
        read = () => ({type: kind, headers: readRows()});
      } else if (kind === "bearer") {
        const token = field(body, "Token", config.token || "");
        read = () => ({type: kind, token: token.value});
      } else if (kind === "session_login") read = sessionEditor(body, config.login || {});
      else if (kind === "oauth2") read = oauthEditor(body, config);
      else {
        body.append(el("p", kind === "negotiate" ? "Uses the Gateway's available Negotiate authentication support." : "No API credentials required.", "http-form-note"));
        read = () => ({type: kind});
      }
    }
    type.onchange = () => { try { drafts[previous] = read(); } catch (_) { /* An incomplete draft does not prevent selecting another auth type. */ } previous = type.value; render(); };
    render(); return () => read();
  }
  function sessionEditor(body, login) {
    const path = field(body, "Login path", login.path || ""); path.required = true;
    const mode = choose(body, "Login body format", ["form", "json"], login.body_mode || "form");
    const fields = login.fields || {};
    const userKey = login.username_field || (Object.hasOwn(fields, "username") || !Object.keys(fields).length ? "username" : "");
    const passKey = (Object.hasOwn(fields, "password") || !Object.keys(fields).length ? "password" : "");
    const username = field(body, "Username (optional)", typeof fields[userKey] === "string" ? fields[userKey] : "");
    const usernameField = field(body, "Username field", userKey), passwordField = field(body, "Password field", passKey);
    const password = field(body, "Password", fields[passKey] || "");
    const extract = [...(login.extract || [])];
    const cookieIndex = extract.findIndex(item => item.target === "cookie" && !item.methods && !item.prefix && !item.suffix);
    const cookie = cookieIndex >= 0 ? extract.splice(cookieIndex, 1)[0] : {};
    const csrfIndex = extract.findIndex(item => item.target === "header" && item.methods?.length && item.methods.every(method => ["POST", "PUT", "PATCH", "DELETE"].includes(method)) && !item.prefix && !item.suffix);
    const csrf = csrfIndex >= 0 ? extract.splice(csrfIndex, 1)[0] : {};
    const cookies = group(body, "Session cookie");
    const cookieName = field(cookies, "Cookie name", cookie.name || ""), cookieSource = choose(cookies, "Cookie source", ["json", "header", "cookie"], cookie.source || "json"), cookiePath = field(cookies, "Cookie extraction path", cookie.path || "");
    const protection = group(body, "CSRF protection");
    const csrfName = field(protection, "CSRF header name", csrf.name || ""), csrfSource = choose(protection, "CSRF source", ["json", "header", "cookie"], csrf.source || "json"), csrfPath = field(protection, "CSRF extraction path", csrf.path || ""), csrfMethods = field(protection, "CSRF methods (comma separated)", (csrf.methods || ["POST", "PUT", "PATCH", "DELETE"]).join(", "));
    const advanced = group(body, "Advanced login settings", true);
    const success = field(advanced, "Login success codes (comma separated)", (login.success_codes || [200]).join(", "));
    const additional = Object.entries(fields).filter(([key]) => ![userKey, passKey].includes(key)).map(([name, value]) => ({name, kind: value === null ? "null" : typeof value, value: String(value ?? "")}));
    const loginRows = rows(advanced, "Login field", additional, [["name", "Field name"], ["kind", "Value type", ["string", "number", "boolean", "null"], "string"], ["value", "Value"]], 30);
    const extractionRows = rows(advanced, "Extracted value", extract.map(item => ({...item, methods: (item.methods || []).join(", ")})), [["source", "Source", ["json", "header", "cookie"], "json"], ["path", "Extraction path"], ["target", "Destination", ["header", "cookie", "query", "body"], "header"], ["name", "Destination name"], ["methods", "Methods (comma separated)"], ["prefix", "Prefix"], ["suffix", "Suffix"]], 16);
    return () => {
      if (usernameField.value && usernameField.value === passwordField.value) throw window.SMTOErrors.error("ui_login_field_conflict");
      const values = {};
      for (const row of loginRows()) {
        if (!row.name || Object.hasOwn(values, row.name) || [usernameField.value, passwordField.value].includes(row.name)) throw window.SMTOErrors.error("ui_login_field_conflict");
        if (row.kind === "number" && (!row.value.trim() || !Number.isFinite(Number(row.value)))) throw window.SMTOErrors.error("ui_login_number_invalid");
        if (row.kind === "boolean" && !["true", "false"].includes(row.value)) throw window.SMTOErrors.error("ui_login_boolean_invalid");
        values[row.name] = row.kind === "null" ? null : row.kind === "number" ? Number(row.value) : row.kind === "boolean" ? row.value === "true" : row.value;
      }
      if (usernameField.value) values[usernameField.value] = username.value;
      if (passwordField.value) values[passwordField.value] = password.value;
      const extracted = extractionRows().map(row => { const value = {...row}; if (row.methods) value.methods = commas(row.methods).map(method => method.toUpperCase()); else delete value.methods; return value; });
      if (cookieName.value || cookiePath.value) extracted.unshift({source: cookieSource.value, path: cookiePath.value, target: "cookie", name: cookieName.value});
      if (csrfName.value || csrfPath.value) extracted.push({source: csrfSource.value, path: csrfPath.value, target: "header", name: csrfName.value, methods: commas(csrfMethods.value).map(method => method.toUpperCase())});
      return {type: "session_login", login: {path: path.value, method: "POST", body_mode: mode.value, ...(usernameField.value ? {username_field: usernameField.value} : {}), fields: values, extract: extracted, success_codes: commas(success.value).map(Number)}};
    };
  }
  function oauthEditor(body, config) {
    const grant = choose(body, "OAuth grant", ["client_credentials", "authorization_code", "device_authorization"], config.grant_type || "client_credentials");
    const inputs = {};
    for (const [key, label] of [["client_id", "Client ID"], ["client_secret", "Client secret"], ["access_token", "Access token"], ["refresh_token", "Refresh token"], ["token_endpoint", "Token endpoint"], ["issuer", "Issuer (optional discovery URL)"], ["scope", "Scopes"], ["audience", "Audience"], ["resource", "Resource"]]) inputs[key] = field(body, label, config[key] || "");
    inputs.client_id.required = true;
    inputs.client_auth = choose(body, "Client authentication", ["client_secret_basic", "client_secret_post", "none", "tls_client_auth"], config.client_auth || "client_secret_basic");
    const authorization = group(body, "Browser authorization"), device = group(body, "Device authorization");
    inputs.authorization_endpoint = field(authorization, "Authorization endpoint", config.authorization_endpoint || "");
    inputs.redirect_uri = field(authorization, "Redirect URI", config.redirect_uri || "");
    inputs.device_authorization_endpoint = field(device, "Device authorization endpoint", config.device_authorization_endpoint || "");
    const update = () => { show(authorization.parentElement, grant.value === "authorization_code"); show(device.parentElement, grant.value === "device_authorization"); };
    grant.onchange = update; update();
    return () => {
      const auth = {type: "oauth2", grant_type: grant.value};
      for (const [key, input] of Object.entries(inputs)) if (!input.disabled) optional(auth, key, input);
      return auth;
    };
  }
  function tlsEditor(parent, config = {}) {
    const body = group(parent, "TLS & transport"), mode = choose(body, "TLS verification", ["system", "custom_ca", "insecure"], config.mode || "system");
    const warning = el("p", "TLS certificate verification disabled", "http-warning"); body.append(warning);
    const ca = group(body, "Custom certificate authority"), caSource = choose(ca, "CA source", [["slot", "Certificate PEM"], ["path", "File on Gateway"]], config.ca_path ? "path" : "slot");
    const caSlot = field(ca, "CA certificate PEM", config.ca_certificate || ""), caPath = field(ca, "CA file path", config.ca_path || "");
    const mtls = choose(body, "Client certificate", [["none", "None"], ["slots", "Certificate and key PEM"], ["paths", "Files on Gateway"]], config.client_cert_path ? "paths" : config.client_certificate ? "slots" : "none");
    const material = group(body, "Client certificate material"), cert = field(material, "Client certificate PEM", config.client_certificate || ""), key = field(material, "Client key PEM", config.client_key || ""), certPath = field(material, "Client certificate file path", config.client_cert_path || ""), keyPath = field(material, "Client key file path", config.client_key_path || "");
    function update() {
      warning.hidden = mode.value !== "insecure"; show(ca.parentElement, mode.value === "custom_ca");
      show(caSlot.parentElement, mode.value === "custom_ca" && caSource.value === "slot"); show(caPath.parentElement, mode.value === "custom_ca" && caSource.value === "path");
      show(material.parentElement, mtls.value !== "none");
      for (const input of [cert, key]) show(input.parentElement, mtls.value === "slots");
      for (const input of [certPath, keyPath]) show(input.parentElement, mtls.value === "paths");
    }
    mode.onchange = caSource.onchange = mtls.onchange = update; update();
    return () => {
      const tls = {mode: mode.value};
      if (mode.value === "custom_ca") tls[caSource.value === "path" ? "ca_path" : "ca_certificate"] = caSource.value === "path" ? caPath.value : caSlot.value;
      if (mtls.value === "slots") Object.assign(tls, {client_certificate: cert.value, client_key: key.value});
      if (mtls.value === "paths") Object.assign(tls, {client_cert_path: certPath.value, client_key_path: keyPath.value});
      return tls;
    };
  }
  function advancedEditor(parent, profile) {
    const body = group(parent, "Advanced connection settings", true);
    const ttl = field(body, "Session lifetime (seconds)", profile.session?.ttl_seconds ?? 3600, "number"); ttl.min = 1; ttl.max = 86400;
    const reauth = field(body, "Reauthenticate safe reads", profile.session?.reauthenticate_reads !== false, "checkbox");
    const origins = rows(body, "Allowed origin", (profile.allowed_origins || []).map(url => ({url})), [["url", "Origin URL"]], 8);
    const headers = rows(body, "Default header", Object.entries(profile.default_headers || {}).map(([name, value]) => ({name, value})), [["name", "Header name"], ["value", "Header value"]], 64);
    const proxy = group(body, "Proxy"), proxyInputs = {};
    for (const [key, label] of [["http", "HTTP proxy URL"], ["https", "HTTPS proxy URL"], ["username", "Proxy username"], ["password", "Proxy password"]]) proxyInputs[key] = field(proxy, label, profile.proxy?.[key] || "");
    return () => {
      const proxy = {}; for (const [key, input] of Object.entries(proxyInputs)) optional(proxy, key, input);
      const defaultHeaders = {};
      for (const row of headers()) { if (!row.name || Object.keys(defaultHeaders).some(name => name.toLowerCase() === row.name.toLowerCase())) throw window.SMTOErrors.error("ui_header_name_conflict"); defaultHeaders[row.name] = row.value; }
      return {session: {ttl_seconds: Number(ttl.value), reauthenticate_reads: reauth.checked}, allowed_origins: origins().map(row => row.url), default_headers: defaultHeaders, proxy};
    };
  }
  function create({profile, connection = null, types, onChange = () => {}, onUpdated = () => {}}) {
    const element = el("div", "", "http-profile-editor");
    const controls = el("fieldset", "", "http-profile-controls");
    controls.append(el("legend", "HTTP Configuration"));
    const general = group(controls, "Connection");
    const endpoint = field(general, "Base URL", profile.base_url || "", "url"); endpoint.required = true;
    const readAuth = authEditor(controls, profile.auth || {type: "none"}, types);
    const readTls = tlsEditor(controls, profile.tls);
    const testFields = group(controls, "Connection test");
    const testPath = field(testFields, "Test endpoint", profile.test_request?.url || "/");
    const testMethod = choose(testFields, "Test method", ["GET", "HEAD", "OPTIONS"], profile.test_request?.method || "GET");
    const timeout = field(testFields, "Test timeout (seconds)", profile.test_request?.timeout_seconds ?? 10, "number"); timeout.min = 1; timeout.max = 30;
    const bound = field(testFields, "Test response limit (bytes)", profile.test_request?.max_response_bytes ?? 4096, "number"); bound.min = 1; bound.max = 65536;
    const readAdvanced = advancedEditor(controls, profile);
    const status = el("p", "", "http-dialog-status"); status.setAttribute("role", "status");
    const actions = el("div", "", "http-connection-actions");
    const preview = el("details", "", "http-form-section"); preview.append(el("summary", "Profile JSON"));
    const json = el("pre", "", "http-public-json"); preview.append(json);
    const runtime = el("div", "", "http-connection-status");
    element.append(runtime, actions, status, controls, preview);
    let busy = false, disabled = false, hostDirty = false;
    const fieldsSnapshot = () => JSON.stringify([...controls.querySelectorAll("input,select,textarea")].map(input => [input.id, input.value, input.checked]));
    const initialFields = fieldsSnapshot();
    const readFields = () => ({profile_type: "http_connection", profile_version: 3,
      base_url: endpoint.value, auth: readAuth(), tls: readTls(), ...readAdvanced(),
      test_request: {method: testMethod.value, url: testPath.value || "/", timeout_seconds: Number(timeout.value), max_response_bytes: Number(bound.value)}});
    // Preserve untouched public fields, including optional fields absent from older profiles.
    const initial = readFields();
    function read() {
      if (connection?.projection_applied) throw window.SMTOErrors.error("ui_parameter_reveal_required");
      const result = structuredClone(profile);
      for (const [key, value] of Object.entries(readFields())) {
        if (JSON.stringify(value) !== JSON.stringify(initial[key])) result[key] = value;
      }
      return result;
    }
    const isDirty = () => fieldsSnapshot() !== initialFields;
    function changed() {
      try { json.textContent = JSON.stringify(read(), null, 2); } catch (_) { json.textContent = "Complete the configuration fields to preview JSON."; }
      onChange();
    }
    controls.addEventListener("input", changed);
    controls.addEventListener("change", changed);
    controls.addEventListener("click", event => { if (event.target.closest("button")) changed(); });
    json.textContent = JSON.stringify(profile, null, 2);
    if (connection?.projection_applied) {
      controls.disabled = true;
      status.textContent = "This profile is redacted. Reveal the raw Parameter value to edit it.";
    }
    async function refresh() {
      if (!connection) return;
      connection = await api(`connections/${encodeURIComponent(connection.profile_key)}`);
      renderActions();
      await onUpdated();
    }
    function renderActions() {
      actions.replaceChildren(); runtime.replaceChildren();
      if (!connection) { runtime.textContent = "Save this Parameter to test the connection."; return; }
      runtime.append(el("p", !connection.credential_fields?.length ? "No credentials required" : connection.credentials_configured ? "Credentials configured" : "Configuration required"),
        el("p", connection.session_state === "authenticated" ? "Authenticated" : "Not authenticated"),
        el("p", connection.tls_mode === "insecure" ? "TLS certificate verification disabled" : `TLS: ${connection.tls_mode || "system"}`));
      actions.append(button("Test connection", () => test(connection)));
      const disconnect = button("Disconnect Session", async () => {
        busy = true; renderActions();
        try { await api(`connections/${encodeURIComponent(connection.profile_key)}/disconnect`, "POST", {}); await refresh(); }
        catch (error) { window.SMTOErrors.present(status, error); }
        finally { busy = false; renderActions(); }
      });
      actions.append(disconnect);
      actions.querySelectorAll("button").forEach(input => { input.disabled = disabled || busy || hostDirty; });
      disconnect.disabled ||= connection.session_state !== "authenticated";
      if (hostDirty) status.textContent = "Save changes before using connection actions.";
      else if (status.textContent === "Save changes before using connection actions.") status.textContent = "";
    }
    async function test(connection) {
      const d = dialog(`Test · ${connection.profile_key}`, "Test connection"), gateway = choose(d.body, "Gateway", [["", "Default Gateway"]], "");
      d.save.disabled = true; d.show();
      try {
        const response = await window.SMTOErrors.fetch("/api/agent/gateways"), data = await window.SMTOErrors.readJson(response);
        if (!response.ok) throw window.SMTOErrors.fromPayload(data, response.status);
        for (const item of data.gateways || []) {
          const option = el("option", `${item.label || item.node} · ${item.node}`); option.value = item.node; gateway.append(option);
        }
        d.save.disabled = false;
      } catch (error) { window.SMTOErrors.present(d.status, error); }
      d.form.onsubmit = async event => {
        event.preventDefault(); d.save.disabled = true; d.status.textContent = "Testing connection…";
        try {
          const data = await api(`connections/${encodeURIComponent(connection.profile_key)}/test`, "POST", gateway.value ? {gateway_node: gateway.value} : {});
          const kind = data.result?.error_kind;
          d.status.textContent = data.configuration_required ? "Authentication required. Edit the authentication values, or use this connection in a task for OAuth authorization." : kind === "http_tls_verification_failed" ? "TLS verification failed" : data.result?.ok ? `Reachable · ${data.result.authenticated ? "Authenticated" : "No authentication"} · HTTP ${data.result.status_code}` : data.result?.message || `HTTP ${data.result?.status_code || "request failed"}`;
          await refresh();
        } catch (error) { window.SMTOErrors.present(d.status, error); }
        finally { d.save.disabled = false; }
      };
    }
    renderActions();
    return {element, read, isDirty,
      setState({loading, dirty}) {
        disabled = loading; hostDirty = dirty;
        controls.disabled = loading || connection?.projection_applied === true;
        renderActions();
      },
    };
  }
  window.SMTOHttpProfileEditor = {create};
})();
