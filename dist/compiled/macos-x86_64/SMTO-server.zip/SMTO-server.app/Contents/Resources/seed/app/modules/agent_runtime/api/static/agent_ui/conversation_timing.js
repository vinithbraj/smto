/* Current response clock while running; conversation total once responses settle. */
(() => {
  "use strict";
  const timing = window.SMTOPerformanceTiming;
  const finite = value => typeof value === "number" && Number.isFinite(value) && value >= 0;
  function create({root, apiJson, now, changed = () => {}}) {
    let conversationId = null, generation = 0, controller = null, timer = null, refreshTimer = null, pending = null;
    let saved = new Map(), live = new Map(), states = new Map(), loaded = false, failed = false;
    function render() {
      clearTimeout(timer); timer = null;
      const values = new Map(saved), at = now();
      let active = null;
      for (const [id, span] of live) {
        const duration = timing.duration(span, at);
        if (finite(duration)) values.set(id, duration);
        if (!span.terminal && Number.isFinite(span.start) && (!active || span.start >= active.start)) active = span;
      }
      const durations = [...values.values()].filter(finite);
      root.hidden = !conversationId || (!values.size && loaded);
      const incomplete = !loaded || durations.length < values.size;
      const text = active
        ? `Working on this response for ${timing.format(timing.duration(active, at))}`
        : durations.length
        ? `Worked on this conversation for ${timing.format(durations.reduce((total, ms) => total + ms, 0))}${incomplete ? " · partial" : ""}`
        : loaded || failed ? "Conversation time unavailable" : "Loading conversation time…";
      window.SMTONumberOdometer.render(root, text, {decimalSeparator: "."});
      root.title = active ? "Time spent on the current response."
        : "Time spent on all responses in this conversation. Time between responses is excluded."
          + (incomplete ? " Some response times are unavailable." : "");
      if (active && !document.hidden) timer = setTimeout(render, 1000);
      changed();
    }
    function refresh() {
      if (pending) return pending;
      const read = readTiming().finally(() => { if (pending === read) pending = null; });
      pending = read; return read;
    }
    async function readTiming() {
      await window.SMTOReadPriority?.ready;
      clearTimeout(refreshTimer); refreshTimer = null;
      if (!conversationId) return;
      controller?.abort();
      const request = new AbortController(), version = generation;
      controller = request;
      try {
        const data = await apiJson(`/api/agent/chats/${encodeURIComponent(conversationId)}/timing`, {signal: request.signal});
        if (version !== generation || request.signal.aborted) return;
        if (Array.isArray(data.requests)) {
          saved = new Map(data.requests.map(item => [item.request_id, item.duration_ms]));
          loaded = true;
          failed = false;
        }
      } catch (_) {
        if (version === generation && !request.signal.aborted) failed = true;
      }
      if (version === generation && !request.signal.aborted) render();
    }
    function activate(id) {
      id ||= null;
      if (id === conversationId) return;
      controller?.abort(); pending = null; clearTimeout(refreshTimer);
      generation++; conversationId = id; saved = new Map(); live = new Map(); states = new Map(); loaded = failed = false;
      render(); void refresh();
    }
    function scheduleRefresh() {
      clearTimeout(refreshTimer);
      if (conversationId) refreshTimer = setTimeout(refresh, 120);
    }
    window.SMTOUiUpdates.subscribe(["chats.changed", "runs.changed"], scheduleRefresh);
    document.addEventListener("visibilitychange", () => { render(); if (!document.hidden) void refresh(); });
    window.addEventListener("pagehide", () => { clearTimeout(timer); clearTimeout(refreshTimer); controller?.abort(); });
    window.addEventListener("pageshow", () => { render(); void refresh(); });
    function track(id, span) {
      if (id) live.set(id, span);
      render();
    }
    function requestState(id) {
      if (!states.has(id)) states.set(id, timing.create());
      return states.get(id);
    }
    return {activate, refresh: scheduleRefresh, track,
      duration(id) { return live.has(id) ? timing.duration(live.get(id), now()) : saved.get(id) ?? null; },
      event(id, event) {
        // Request clocks only: model/tool spans already belong to the waveform.
        if (!id || !(event.event_type?.startsWith("request.") || event.event_type === "run.resumed")) return;
        const state = requestState(id);
        timing.reduce(state, event); track(id, state.run);
      },
      restore(id, trace) {
        if (!id) return;
        const state = requestState(id);
        // A continuation's chain timing includes its parent and gaps. Count each request once.
        timing.restore(state, {...trace, runtime_timing: trace.request_runtime_timing || trace.timing || trace.runtime_timing});
        track(id, state.run);
      },
    };
  }
  window.SMTOConversationTiming = {create};
})();
