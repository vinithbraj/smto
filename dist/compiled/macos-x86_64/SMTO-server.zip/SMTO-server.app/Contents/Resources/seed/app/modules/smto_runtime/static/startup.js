(() => {
  "use strict";
  // Apply the existing tab override before first paint; otherwise shared.css
  // follows the device theme until database-backed preferences are available.
  const theme = window.SMTOUiSession?.get("theme");
  if (["light", "dark"].includes(theme)) document.documentElement.dataset.theme = theme;
  document.addEventListener("DOMContentLoaded", start, {once: true});

  function start() {
    const brand = document.getElementById("brand");
    const heading = document.getElementById("heading");
    const stage = document.getElementById("stage");
    const stageCopy = document.getElementById("stage-copy");
    const stageLabel = document.getElementById("stage-label");
    const message = document.getElementById("message");
    const elapsed = document.getElementById("elapsed");
    const diagnostic = document.getElementById("startup-error");
    let failures = 0;
    let reloading = false;
    let diagnosticKey = "";
    let last = null, receivedAt = 0;
    const reportOnly = document.body.dataset.reportOnly === 'true';
    const details = document.getElementById('startup-details');
    const updateReport = window.SMTOStartupReport?.mount(details);
    const ageLabel = document.getElementById('startup-age');
    const caption = document.getElementById('lifecycle-caption');
    const retry = document.getElementById('retry-restart');
    let waitForShutdown = document.body.dataset.waitForShutdown === 'true';
    let previousInstance = null, sawShutdown = !waitForShutdown && document.body.dataset.lifecycle === 'shutdown';
    window.addEventListener('message', event => {
      if (event.source !== window.parent || event.origin !== window.location.origin) return;
      if (event.data?.type === 'smto:restart-accepted') previousInstance = event.data.previous_instance_id;
      if (event.data?.type === 'smto:restart-uncertain') {
        retry.hidden = false;
        text(message, 'Could not confirm the restart request. Checking the server automatically; you can retry.');
      }
    });
    retry.onclick = async () => {
      retry.disabled = true;
      try {
        const response = await fetch(document.body.dataset.statusUrl.replace(/\/api\/startup$/, '/api/agent/restart'), {method: 'POST'});
        if (!response.ok) throw new Error('Restart unavailable');
        const result = await response.json();
        previousInstance = result.client_action?.previous_instance_id;
        text(message, 'Retrying shutdown and the final database save…');
      } catch {
        text(message, 'Could not confirm the restart request. Checking the server automatically; you can retry.');
      } finally { retry.disabled = false; }
    };
    updateStage(stage.textContent, document.body.dataset.state);

    function tick() {
      if (!last) return;
      const since = Math.max(0, (performance.now() - receivedAt) / 1000);
      const age = (last.last_progress_age_seconds || 0) + since;
      const stale = failures > 0 || since > 5;
      const extra = ['initializing', 'stopping'].includes(last.status) ? since : 0;
      numericText(elapsed, `${Math.floor(last.elapsed_seconds + extra)} seconds elapsed`);
      if (ageLabel) {
        ageLabel.hidden = !stale;
        numericText(ageLabel, `Last server response ${Math.floor(since)} seconds ago. Progress rates are paused.`);
      }
      updateReport?.(last, {age, stale, localElapsed: extra});
    }
    if (updateReport) window.setInterval(tick, 250);

    // Repeated snapshots must not re-announce unchanged live regions.
    function text(element, value) {
      if (element.textContent !== value) element.textContent = value;
    }
    function numericText(element, value) {
      if (window.SMTONumberOdometer) window.SMTONumberOdometer.render(element, value);
      else text(element, value);
    }
    function updateStage(value, status) {
      text(stage, value);
      window.SMTOActivityUpdates?.update(stageCopy, {
        label: value, kind: ['initializing', 'stopping'].includes(status) ? 'runtime' : 'terminal',
      });
    }

    function showDiagnostic(detail) {
      const key = JSON.stringify(detail || null);
      if (key === diagnosticKey) return;
      diagnosticKey = key;
      diagnostic.replaceChildren();
      diagnostic.hidden = !detail;
      if (!detail) return;
      function line(tag, value, className = "", parent = diagnostic) {
        if (!value) return;
        const element = document.createElement(tag);
        element.className = className;
        element.textContent = value;
        parent.append(element);
        return element;
      }
      function list(tag, values, parent = diagnostic) {
        if (!values.length) return;
        const element = document.createElement(tag);
        for (const value of values) line("li", value, "", element);
        parent.append(element);
      }
      line("h2", detail.title);
      line("p", detail.error_id, "diagnostic-id");
      line("p", detail.presentation?.plain_language || detail.explain_like_5);
      line("h3", "How to fix");
      const guidance = detail.presentation?.user_guidance || detail.how_to_fix?.user_guidance;
      if (guidance) {
        list("ol", (guidance.steps || []).map(step => `${step.instruction} ${step.why}`));
        line("h3", "What success looks like"); line("p", guidance.success_check);
        line("h3", "If it still fails"); line("p", guidance.if_still_failing);
      } else {
        line("p", detail.how_to_fix?.summary);
        list("ul", (detail.configuration_issues || []).map(item => `${item.field}: ${item.requirement}`));
        list("ol", (detail.how_to_fix?.steps || []).map(item => item.instruction));
        if (detail.resolution?.verify?.length) {
          line("h3", "Verify the fix"); list("ul", detail.resolution.verify);
        }
      }
      line("p", `Occurrence: ${detail.occurrence_id || "unavailable"}`, "diagnostic-occurrence");
      const copy = line("button", "Copy error details"); copy.type = "button";
      const feedback = document.createElement("p"); feedback.setAttribute("role", "status"); diagnostic.append(feedback);
      let fallback;
      copy.onclick = async () => {
        // The public startup endpoint already omits exception text and private
        // inputs. Copy only identifiers, never configuration or runtime facts.
        const lines = [];
        if (/^SMTO-[A-Z0-9]{2,5}-\d{4}$/.test(detail.error_id || "")) lines.push(detail.error_id);
        if (typeof detail.title === "string") lines.push(detail.title.slice(0, 180));
        if (/^[a-z0-9-]{1,160}$/.test(detail.slug || "")) lines.push(`Error: ${detail.slug}`);
        if (/^[a-z0-9_.:-]{1,120}$/i.test(detail.occurrence_id || "")) lines.push(`Error reference: ${detail.occurrence_id}`);
        if (/^[a-z0-9_.:-]{1,120}$/i.test(detail.stage || "")) lines.push(`Stage: ${detail.stage}`);
        const content = lines.join("\n");
        try {
          await navigator.clipboard.writeText(content); feedback.textContent = "Error details copied.";
          fallback?.remove(); fallback = null;
        } catch (_) {
          feedback.textContent = "Automatic copying is unavailable. Select and copy the text below.";
          if (!fallback) {
            fallback = document.createElement("textarea"); fallback.readOnly = true; fallback.rows = 4;
            fallback.setAttribute("aria-label", "Error details to copy"); diagnostic.append(fallback);
          }
          fallback.value = content; fallback.focus(); fallback.select();
        }
      };
      if (guidance) {
        const technical = document.createElement("details"); diagnostic.append(technical);
        line("summary", "Technical details", "", technical);
        line("p", detail.how_to_fix?.summary, "", technical);
        list("ul", (detail.configuration_issues || []).map(item => `${item.field}: ${item.requirement}`), technical);
        list("ol", (detail.how_to_fix?.steps || []).map(item => item.instruction), technical);
        list("ul", detail.resolution?.verify || [], technical);
      }
    }

    async function poll() {
      let delay = 1000;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      try {
        const response = await fetch(document.body.dataset.statusUrl, {
          cache: "no-store", signal: controller.signal,
        });
        if (!response.ok) throw new Error("Status unavailable");
        const state = await response.json();
        if (!["initializing", "ready", "failed", "stopping", "stopped"].includes(state?.status)
            || typeof state.stage !== "string" || !Number.isFinite(state.elapsed_seconds)
            || state.elapsed_seconds < 0) {
          throw new Error("Invalid startup status");
        }
        failures = 0;
        if (state.lifecycle === 'shutdown') sawShutdown = true;
        // A request can still be reaching the server. An old ready response is not a restart.
        if (waitForShutdown && !sawShutdown && state.status === 'ready'
            && (!previousInstance || state.instance_id === previousInstance)) {
          previousInstance ||= state.instance_id;
          setTimeout(poll, 1000);
          return;
        }
        const shutdown = state.lifecycle === 'shutdown';
        document.body.dataset.lifecycle = shutdown ? 'shutdown' : 'startup';
        text(caption, shutdown ? 'Workspace shutdown' : 'Workspace startup');
        retry.hidden = !(shutdown && state.status === 'failed' && state.restart_requested);
        const cleanup = document.getElementById('background-gc');
        if (shutdown && cleanup) {
          cleanup.hidden = !state.cleanup_pending;
          if (state.cleanup_pending) numericText(cleanup, `Database save complete. ${state.cleanup_pending} storage cleanup operations remain pending and will retry after startup.`);
        } else if (!reportOnly && cleanup) cleanup.hidden = true;
        if (last?.boot_id && last.boot_id !== state.boot_id) diagnosticKey = '';
        last = state;
        receivedAt = performance.now();
        if (typeof state.brand === "string" && state.brand) {
          text(brand, state.brand);
          const title = `${shutdown ? 'Shutting down' : reportOnly && state.status === 'ready' ? 'Last startup' : 'Starting'} · ${state.brand}`;
          if (document.title !== title) document.title = title;
        }
        document.body.dataset.state = state.status;
        updateStage(state.stage, state.status);
        showDiagnostic(state.status === "failed" ? state.error_detail : null);
        tick();
        if (state.status === "ready") {
          text(heading, reportOnly ? 'Last startup' : "Ready");
          text(message, reportOnly ? 'Completed phase timings for this service process.' : "Opening your workspace…");
          text(stageLabel, "Complete");
          if (reportOnly) {
            setTimeout(poll, 1000);
            const gc = document.getElementById('background-gc');
            try {
              const response = await fetch(document.body.dataset.statusUrl.replace(/\/api\/startup$/, '/api/agent/conversation-gc'), {cache: 'no-store'});
              if (response.ok && gc) {
                const value = await response.json(); gc.hidden = false;
                numericText(gc, `Background conversation cleanup: ${value.pending_disk} pending disk purges; ${value.unresolved_operations} unresolved operations. This does not block readiness.`);
              }
            } catch { /* Independent background diagnostics are optional. */ }
          } else if (!reloading) {
            reloading = true;
            if (window.parent && window.parent !== window) window.parent.postMessage({type: 'smto:lifecycle-ready'}, window.location.origin);
            else if (window.location.pathname?.endsWith('/shutdown')) window.location.replace(window.location.pathname.replace(/\/shutdown$/, '/agent-ui'));
            else window.location.reload();
          }
          return;
        }
        if (state.status === "failed") {
          text(heading, shutdown ? 'Shutdown stopped' : "Initialization failed");
          text(stageLabel, "Stopped at");
          text(message, state.error_detail?.short_description || state.error
            || "The app could not finish starting. Follow the help steps below, or share the error reference with the person who manages the app.");
        } else if (state.status === 'stopped') {
          text(heading, 'Shutdown complete');
          text(stageLabel, 'Complete');
          text(message, 'The database save is complete. Waiting for the service to start.');
        } else {
          text(heading, state.status === "stopping" ? "Shutting down…" : "Preparing your workspace");
          text(stageLabel, state.status === "stopping" && !shutdown ? "Last step" : "Current step");
          text(message, state.status === "stopping"
            ? shutdown ? state.restart_requested
              ? 'Saving your workspace before restarting. Controls are unavailable until the service is ready.'
              : 'Saving your workspace before shutdown. Controls are unavailable while the service is stopping.'
              : "Waiting for the service to restart."
            : "Your workspace will open automatically when it’s ready.");
        }
      } catch {
        failures += 1;
        delay = 1000;
        document.body.dataset.state = "reconnecting";
        text(heading, "Reconnecting…");
        text(stageLabel, "Last known step");
        text(message, "The connection was interrupted. Checking again automatically.");
        tick();
      } finally {
        clearTimeout(timeout);
      }
      setTimeout(poll, delay);
    }
    void poll();
  }
})();
