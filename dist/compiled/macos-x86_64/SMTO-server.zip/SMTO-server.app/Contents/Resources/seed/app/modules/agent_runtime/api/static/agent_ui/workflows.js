/* Reviewed Agent Recipes. Execution, graph validation and revisions are server-owned. */
(() => {
  "use strict";
  let options = {};
  const el = (tag, text = "", cls = "") => {
    const node = document.createElement(tag); node.textContent = text;
    if (cls) node.className = cls; return node;
  };
  const button = (label, action) => {
    const node = el("button", label, "agent-dialog-button"); node.type = "button";
    node.addEventListener("click", () => Promise.resolve().then(action).catch(showError)); return node;
  };
  async function api(path = "", method = "GET", body) {
    const response = await window.SMTOErrors.fetch(`/api/agent/recipes${path}`, {
      method, headers: {"Content-Type": "application/json"},
      ...(body === undefined ? {} : {body: JSON.stringify(body)})});
    const data = await window.SMTOErrors.readJson(response);
    if (!response.ok) throw window.SMTOErrors.fromPayload(data, response.status);
    return data;
  }
  const dialog = el("dialog", "", "agent-dialog workflow-dialog");
  dialog.id = "workflow-editor"; dialog.setAttribute("aria-labelledby", "workflow-title");
  const heading = el("h2", "Workflows"); heading.id = "workflow-title";
  const close = button("Close", () => dialog.close());
  const header = el("header", "", "agent-dialog-header"); header.append(heading, close);
  const body = el("div", "", "workflow-content");
  const error = el("p", "", "workflow-error"); error.setAttribute("role", "alert");
  dialog.append(header, body, error); document.body.append(dialog);
  function showError(err) { error.textContent = err.message || "Workflow could not be saved."; }
  function open(title) {
    heading.textContent = title; body.replaceChildren(); error.textContent = "";
    if (!dialog.open) dialog.showModal();
    dialog.scrollTop = 0;
  }
  function field(label, value, multiline = false) {
    const wrap = el("label", label, "agent-dialog-field"), input = el(multiline ? "textarea" : "input");
    input.value = value ?? ""; wrap.append(input); body.append(wrap); return input;
  }
  function setPointer(root, pointer, value) {
    const keys = pointer.slice(1).split("/").map(p => p.replaceAll("~1", "/").replaceAll("~0", "~"));
    let parent = root; keys.slice(0, -1).forEach(key => { parent = parent[key]; });
    parent[keys.at(-1)] = value;
  }
  function review(original, suggestions = []) {
    const recipe = structuredClone(original), existing = Boolean(recipe.recipe_id);
    open(existing ? `Edit workflow · revision ${recipe.recipe_revision}` : "Save to workflow");
    const title = field("Name", recipe.title), description = field("Description", recipe.description, true);
    body.append(el("p", `Source run: ${recipe.source_request_id || "Saved intent"}`));
    const isWorkflow = recipe.artifact_kind === "recorded_workflow_v1";
    if (!isWorkflow) {
      body.append(el("p", "Saved intent · each invocation uses fresh Agent reasoning."));
    } else {
      body.append(el("p", "Agent guided · stop on failure · current approvals apply to every run."));
      const target = el("select");
      for (const [value, label] of [["fixed", "Fixed Gateway"], ["invocation", "Choose Gateway at each run"]]) {
        const option = el("option", label); option.value = value; target.append(option);
      }
      target.value = recipe.artifact.target_policy.mode;
      const targetField = el("label", "Gateway policy", "agent-dialog-field"); targetField.append(target); body.append(targetField);
      const gateway = field("Fixed Gateway ID", recipe.artifact.target_policy.gateway_id);
      const stepList = el("ol", "", "workflow-steps"); body.append(stepList);
      const renderSteps = () => {
        stepList.replaceChildren();
        recipe.artifact.steps.forEach((step, index) => {
          const item = el("li");
          item.append(el("strong", `${step.step_id} · ${step.canonical_tool_id || step.kind}`),
            el("p", `${step.effect} · depends on: ${step.depends_on.join(", ") || "none"}`));
          const label = el("label", "Arguments (JSON)", "agent-dialog-field"), args = el("textarea");
          args.value = JSON.stringify(step.argument_template, null, 2); args.rows = 4;
          args.addEventListener("change", () => {
            try { step.argument_template = JSON.parse(args.value); error.textContent = ""; }
            catch (_) { showError(new Error("Arguments must be valid JSON.")); }
          }); label.append(args); item.append(label);
          if (index) item.append(button("Move earlier", () => {
            const previous = recipe.artifact.steps[index - 1];
            if (step.depends_on.includes(previous.step_id)) throw new Error("Keep this step after its dependency.");
            [recipe.artifact.steps[index - 1], recipe.artifact.steps[index]] = [step, previous]; renderSteps();
          }));
          if (step.optional) item.append(button("Remove optional step", () => {
            if (recipe.artifact.steps.some(s => s.depends_on.includes(step.step_id))) throw new Error("Another step requires this result.");
            recipe.artifact.steps.splice(index, 1); renderSteps();
          }));
          stepList.append(item);
        });
      }; renderSteps();
      if (suggestions.length) body.append(el("h3", "Suggested parameters"));
      for (const suggestion of suggestions) {
        const label = el("label", "", "workflow-choice"), checkbox = el("input"); checkbox.type = "checkbox";
        label.append(checkbox, el("span", `${suggestion.name} · ${suggestion.type} · ${suggestion.fields.length} field(s)`)); body.append(label);
        checkbox.addEventListener("change", () => {
          if (checkbox.checked) {
            recipe.parameter_schema.push({name: suggestion.name, type: suggestion.type,
              required: true, default: suggestion.default, reference_only: suggestion.reference_only,
              source_step_id: suggestion.fields[0].step_id, source_field: suggestion.fields[0].pointer});
          } else {
            recipe.parameter_schema = recipe.parameter_schema.filter(p => p.name !== suggestion.name);
          }
          for (const binding of suggestion.fields) {
            const step = recipe.artifact.steps.find(s => s.step_id === binding.step_id);
            setPointer(step.argument_template, binding.pointer, checkbox.checked ? {$param: suggestion.name} : suggestion.default);
          }
          parameterEditor.value = JSON.stringify(recipe.parameter_schema, null, 2); renderSteps();
        });
      }
      var parameterEditor = field("Parameters: names, types, defaults and reference-only slots (JSON)", JSON.stringify(recipe.parameter_schema, null, 2), true);
      var defaults = field("Default parameter values (JSON)", JSON.stringify(recipe.default_parameters, null, 2), true);
      body.append(el("p", `Capabilities: ${recipe.capability_ids.join(", ")}`),
        el("p", `Account references: ${(recipe.artifact.required_parameter_refs || []).join(", ") || "None recorded"}`),
        el("p", `Risks: ${(recipe.risk_summary.effects || []).join(", ")} · ${recipe.risk_summary.write_steps || 0} write step(s)`));
      recipe.readEditor = () => {
        recipe.artifact.target_policy = {mode: target.value, gateway_id: target.value === "fixed" ? gateway.value : ""};
        recipe.parameter_schema = JSON.parse(parameterEditor.value); recipe.default_parameters = JSON.parse(defaults.value);
      };
    }
    const save = button(existing ? "Save revision" : "Save workflow", async () => {
      recipe.readEditor?.();
      recipe.title = title.value; recipe.description = description.value;
      if (existing) {
        await api(`/${encodeURIComponent(recipe.recipe_id)}`, "PATCH", {
          title: recipe.title, description: recipe.description, artifact: recipe.artifact,
          parameter_schema: recipe.parameter_schema, default_parameters: recipe.default_parameters,
          expected_revision: recipe.recipe_revision});
      } else { await api("", "POST", recipe); }
      await library();
    });
    save.classList.add("agent-dialog-primary"); body.append(save);
  }
  async function invoke(recipe, scheduled = false) {
    open(`${scheduled ? "Schedule" : "Run"} ${recipe.title} · revision ${recipe.recipe_revision}`);
    body.append(el("p", `Gateway: ${recipe.artifact.target_policy?.mode === "fixed" ? recipe.artifact.target_policy.gateway_id : "Current selected Gateway"}`));
    const inputs = [];
    for (const param of recipe.parameter_schema) {
      const value = recipe.default_parameters[param.name] ?? param.default;
      const input = field(`${param.label || param.name}${param.required ? " (required)" : ""}${param.reference_only ? " · @account reference" : ""}`,
        param.type === "json" ? JSON.stringify(value ?? null) : value ?? "");
      inputs.push([param, input]);
    }
    body.append(button(scheduled ? "Choose schedule" : "Run now", async () => {
      const parameters = {};
      for (const [param, input] of inputs) {
        if (!input.value && !param.required) continue;
        parameters[param.name] = param.type === "number" ? Number(input.value) : param.type === "boolean" ? JSON.parse(input.value) : param.type === "json" ? JSON.parse(input.value) : input.value;
      }
      const context = options.context?.() || {};
      await api(`/${recipe.recipe_id}/preview`, "POST", {parameters, context, recipe_revision: recipe.recipe_revision});
      if (scheduled) {
        dialog.close();
        options.schedule({prompt: `Run workflow: ${recipe.title}`, title: recipe.title, execution: context,
          save: patch => {
            const schedule = {prompt: `Run workflow: ${recipe.title}`, action_type: "agent_prompt"};
            for (const key of ["schedule_type", "interval_seconds", "next_run_at", "timezone", "recurrence", "notify_on"]) if (key in patch) schedule[key] = patch[key];
            return api(`/${recipe.recipe_id}/schedule`, "POST", {schedule, parameters, context, recipe_revision: recipe.recipe_revision});
          }});
      } else {
        const run = await api(`/${recipe.recipe_id}/execute`, "POST", {parameters, context, recipe_revision: recipe.recipe_revision});
        dialog.close(); await options.onRun?.(run);
      }
    }));
  }
  async function library() {
    const data = await api(); open("Workflows");
    body.append(el("p", "Save completed tasks as reusable workflows, then review, run or schedule them here."));
    if (!data.enabled) { body.append(el("p", "Workflows are disabled in Settings.")); return; }
    if (!data.recipes.length) body.append(el("p", "Complete a task, then choose Save to workflow below its response to review its verified steps."));
    for (const recipe of data.recipes) {
      const item = el("section", "", "workflow-entry");
      item.append(el("h3", recipe.title), el("p", `Revision ${recipe.recipe_revision} · ${recipe.run_count} run(s)`));
      const actions = el("div", "", "workflow-actions");
      actions.append(button("Review", async () => review((await api(`/${recipe.recipe_id}`)).recipe)),
        button("Run now", () => invoke(recipe)), button("Schedule", () => invoke(recipe, true)),
        button("History", async () => {
          const detail = (await api(`/${recipe.recipe_id}`)).recipe; open(`${recipe.title} · history`);
          for (const run of detail.runs) {
            body.append(el("h3", `Revision ${run.recipe_revision} · ${run.status}`));
            for (const [step, status] of Object.entries(run.metadata.step_states || {})) body.append(el("p", `${step}: ${status.status} · ${status.reconciliation}`));
          }
          body.append(el("p", `Definition revisions: ${detail.revisions.map(r => r.recipe_revision).join(", ")}`));
        }), button("Archive", async () => { await api(`/${recipe.recipe_id}`, "DELETE"); await library(); }));
      item.append(actions); body.append(item);
    }
  }
  function attach(turn, container) {
    if (turn.refreshWorkflow) return;
    const control = button("Save to workflow", async () => {
      open("Save to workflow");
      const loading = el("p", "Checking this chat…"); loading.setAttribute("role", "status"); body.append(loading);
      try {
        const candidate = await api(`/candidates/${encodeURIComponent(turn.requestId)}`);
        if (!dialog.open || !loading.isConnected) return;
        if (!candidate.enabled) { body.append(el("p", "Workflows are disabled in Settings.")); return; }
        if (!candidate.saveable) {
          body.append(el("p", candidate.reason || "This chat has no reusable steps to save."),
            el("p", "Workflows need a completed task with verified actions. A text-only chat may not have steps to reuse."));
          return;
        }
        review(candidate.recipe, candidate.parameter_suggestions);
      } finally { loading.remove(); }
    });
    control.className = "workflow-save"; control.hidden = true;
    control.setAttribute("aria-haspopup", "dialog"); control.setAttribute("aria-controls", dialog.id);
    container.append(control);
    let checked = "", generation = 0;
    turn.refreshWorkflow = async (status = turn.activity?.status) => {
      if (!turn.requestId || !["completed", "answered"].includes(status)) {
        checked = ""; generation++; control.hidden = true; return;
      }
      const key = `${turn.requestId}:${status}`;
      if (checked === key) return;
      checked = key;
      const current = ++generation;
      await window.SMTOReadPriority?.ready;
      if (current !== generation || !container.isConnected) return;
      try {
        const candidate = await api(`/candidates/${encodeURIComponent(turn.requestId)}`);
        if (current !== generation || !container.isConnected) return;
        control.hidden = !(candidate.enabled && candidate.offer_after_success);
        control.title = candidate.saveable ? "Review and save this task as a workflow" : "Check which steps can be saved as a workflow";
      } catch (_) {
        // Keep an explicit retry path when eligibility cannot be read.
        if (current === generation && container.isConnected) {
          control.hidden = false; control.title = "Check workflow availability";
        }
      }
    };
    void turn.refreshWorkflow();
  }
  window.SMTOWorkflows = {api, library, review, attach, configure: value => { options = value; }};
})();
