import { $, button } from "../api.js";
import { openSheet, mountControls } from "../overlays.js";

export function open(hooks) {
  const body = openSheet("Conversation options", {returnFocus: $("#options")});
  mountControls(body, $("#status-strip"), $("#activity-details-toggle"), $("#conversation-navigator"));
  body.append(button("Appearance", async () => {
    const {openAppearance} = await import("./agent_options.js?v=20261015-smto");
    if (body.isConnected) openAppearance(() => open(hooks));
  }, "choice"));
}
