---
{"title": "What the AI does and what SMTO does", "status": "published"}
---
## The AI chooses an action

An AI model reads your instructions and decides what response or action may help.
For example, it may ask to read a file before summarizing it. A model server is
the program or online service that runs the model and receives those requests.

The model's request to read a file does not mean the file has been read. It is an
instruction that another program needs to check and carry out.

## SMTO runs the tool

SMTO checks which file the AI wants to read, which computer holds it, and whether
access is allowed. It then runs the file tool and saves the result. The AI receives
that result and uses it to decide what to do next.

If the tool reports an error, the AI needs to work from that error. It should not
write an answer that assumes the file was successfully read.

## Follow one request

| Step | What happens |
| --- | --- |
| You ask for a summary | The AI reads your instructions. |
| The AI asks to read the file | SMTO checks the tool and permission. |
| The tool reads the file | SMTO saves the text or any error. |
| The AI receives the result | It writes the summary or explains a problem. |
| The task ends | SMTO checks for required results and unfinished work where supported. |

## Choose where each part runs

The AI can run on your own computer or through a supported online service. The
computer running your tools can be a separate choice. SMTO uses a program called
a Gateway to run file and command tools on the computer you select.
Other tools can run inside the controller or through a connected service. The
controller records their results and returns information to the model.

A model connection address is sometimes called an **endpoint**. A compatible
endpoint is one whose way of sending and receiving requests works with SMTO.
Even with a compatible connection, models can differ in how well they follow
instructions or use tools. Test your setup with a small task first.

## Start with what you already have

If you already use a supported model server, SMTO adds the tools and task tracking
around it. SMTO does not download or run the model for you. You still need to set
up that connection and allow the tools your task needs.

See [AI model settings](/docs/configuration/models),
[how SMTO manages tasks](/learn/what-is-an-agent-runtime), and
[the parts of a setup](/learn/model-and-gateway).
Explore [the features](/product) or [installation options](/download).
