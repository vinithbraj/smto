/* Presentation of server-owned top-level task edges; no scheduling authority. */
(() => {
  "use strict";
  const helper = "Runs only after the selected task completes successfully.";
  const independent = "No dependency — run independently";
  let scope = "", lane = null, tasks = new Map(), revision = 0;
  const control = () => document.getElementById("depends-on-task");
  const selectedTaskId = () => control().value || null;
  const query = () => selectedTaskId() ? `?dependency_task_id=${encodeURIComponent(selectedTaskId())}` : "";
  const title = task => task.title || task.prompt || "Untitled task";
  const label = task => `Task ${task.creation_sequence || task.task_id} · ${stateLabel(task)} · ${title(task)}`;
  function render(selected = control()?.value || "") {
    const input = control();
    if (!input) return;
    const candidates = [...(lane?.dependency_candidates || [])].filter(task => tasks.has(task.task_id));
    if (selected && !candidates.some(task => task.task_id === selected)) {
      candidates.push(tasks.get(selected) || {task_id: selected, status: "missing"});
    }
    candidates.sort((a, b) => b.creation_sequence - a.creation_sequence || b.task_id.localeCompare(a.task_id));
    const options = [{task_id: "", text: independent}, ...candidates.map(task => ({task_id: task.task_id, text: label(task)}))];
    // Keep the select node and unchanged options intact through invalidations/typing.
    // Task titles are text, never HTML.
    if (input.options.length !== options.length || options.some((option, i) =>
      input.options[i].value !== option.task_id || input.options[i].textContent !== option.text)) {
      input.replaceChildren(...options.map(item => {
        const option = document.createElement("option");
        option.value = item.task_id; option.textContent = item.text; return option;
      }));
    }
    if (input.value !== selected) input.value = selected;
    input.disabled = candidates.length === 0 && document.activeElement !== input;
    input.onchange = () => { revision++; render(); };
    const target = tasks.get(input.value);
    const preview = document.getElementById("dependency-preview");
    const detail = target ? label(target) : candidates.length ? "" : "No active tasks available";
    if (preview) preview.textContent = detail;
    input.closest(".task-dependency-control").title = [helper, detail,
      target?.prompt && target.prompt !== title(target) ? target.prompt : ""].filter(Boolean).join("\n");
    document.getElementById("dependency-help").textContent = helper;
  }
  function composer(next, conversationId) {
    const input = control();
    if (!input) return;
    const nextScope = conversationId || "";
    if (scope !== nextScope) { input.value = ""; tasks.clear(); revision++; }
    scope = nextScope;
    lane = next?.conversation_id === scope ? next : null;
    const selected = tasks.get(input.value);
    tasks = new Map(selected ? [[selected.task_id, selected]] : []);
    for (const task of [...(lane?.tasks || []), ...(lane?.dependency_candidates || []), lane?.selected_dependency_task]) {
      if (task && (!task.conversation_id || task.conversation_id === scope)) tasks.set(task.task_id, task);
    }
    if (input.value && lane?.dependency_task_id === input.value && !lane.selected_dependency_task) {
      tasks.set(input.value, {...tasks.get(input.value), task_id: input.value, status: "missing", user_visible_status: "missing"});
    }
    render();
  }
  function reset() {
    const input = control();
    if (!input) return () => {};
    const id = input.value, target = tasks.get(id), capturedScope = scope, capturedRevision = ++revision;
    input.value = ""; render();
    // An unconfirmed send can retry its exact intent, unless the user edited or navigated.
    return () => {
      if (!id || scope !== capturedScope || revision !== capturedRevision || input.value) return;
      if (target && !tasks.has(id)) tasks.set(id, target);
      render(id);
    };
  }
  function stateLabel(task) {
    const status = task.status === "queued" && task.dependency?.state === "waiting" ? "waiting_dependency"
      : task.status === "queued" && task.dependency?.state === "blocked" ? "dependency_blocked"
      : task.user_visible_status || task.status;
    return ({queued: "Queued", running: "Running", awaiting_confirmation: "Waiting for confirmation",
      awaiting_clarification: "Waiting for clarification", waiting_user: "Waiting for user",
      waiting_job: "Waiting for job", waiting_event: "Waiting for event", paused: "Paused",
      paused_budget: "Paused — budget reached", waiting_dependency: "Waiting for dependency",
      dependency_blocked: "Dependency blocked", completed: "Completed", answered: "Completed",
      failed: "Failed", cancelled: "Cancelled", interrupted: "Interrupted", missing: "Unavailable"})[status]
      || (status ? status.replaceAll("_", " ") : "Status unavailable");
  }
  function describe(task, taskLookup = [...tasks.values()]) {
    if (!task.dependencies?.length) return task.dependency?.message || "";
    const result = task.dependency || {};
    const targetLabel = id => {
      const target = task.dependency_tasks?.find(t => t.task_id === id)
        || taskLookup.find(t => t.task_id === id);
      const name = target ? `Task ${target.creation_sequence || id} · ${target.title || target.prompt || "Untitled task"}` : `Task ${id}`;
      const status = target ? stateLabel(target)
        : stateLabel({status: id === result.direct_task_id ? result.target_status : "missing"});
      return `${name} — ${status}${target?.archived_at ? " (archived)" : ""}`;
    };
    const targets = task.dependencies.map(edge => targetLabel(edge.task_id)).join(", ");
    if (task.status !== "queued") return `${task.status.replaceAll("_", " ")} · Depends on ${targets}`;
    const state = result.state;
    const prefix = state === "satisfied" && result.skipped_dependencies?.length ? "Dependency skipped ·"
      : state === "waiting" || state === "blocked" ? "Waiting on" : "Dependency satisfied ·";
    return `${prefix} ${targets}${result.root_task_id && result.root_task_id !== result.direct_task_id ? ` · Upstream: ${targetLabel(result.root_task_id)}` : ""}`;
  }
  window.SMTOTaskDependencies = {composer, selectedTaskId, query, reset, describe};
})();
