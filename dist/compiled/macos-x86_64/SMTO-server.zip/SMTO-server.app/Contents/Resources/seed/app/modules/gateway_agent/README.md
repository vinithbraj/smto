# Gateway Agent

Gateway operations require the paired smTO controller (V148.1). The configured
smTO client verifies Gateway TLS, pairs automatically on first use, and signs
requests. `/healthz` is the only public operational health surface and returns only
`{"status":"ok"}`. Raw unsigned HTTP/HTTPS examples below illustrate payload shapes;
use the smTO client to execute them.

Outbound Email uses shared `gateway_core` handlers on this platform. The private
`/email/operation` route performs SMTP and Email OAuth HTTPS on the selected Gateway,
supports bounded volatile attachment staging and socket cancellation, and never falls
back to controller SMTP/token requests. Upgrade both controller and Gateway for the
OAuth action. See [Email setup and limits](../manual/content/26-auth-and-email.md).

Pairing and TLS identity survive restarts and upgrades. If the controller identity
is lost, stop the Gateway and run `./src/gateway_agent/reset-pairing.sh` locally
from the checkout root, then restart the Gateway and reconnect the intended
controller. Use the same OS account and `GATEWAY_TLS_STATE_DIR` setting as startup.
The script uses the Gateway's installed virtual environment and resets only the
controller pairing; it preserves the Gateway's TLS identity.
For pairing plus connection cleanup, use `./src/gateway_agent/reset.sh` or
`./src/gateway_agent/startup.sh reset`. Compiled Gateways accept `reset`, for
example `./smto-gateway-linux-x86_64 reset`. Add `--dry-run` to preview,
or `--tls-state-dir PATH` to select explicit state. This also clears saved outbound
server pins and abandoned authentication temporary files, while preserving TLS
identity, replay protection, job history, downloads, artifacts and configuration.
Stop the Gateway and any restart service first; current Gateways hold a runtime
lease that prevents resetting live state. Restart and reconnect after reset.
See [installation and recovery](../manual/content/02-install-startup.md).

This intentionally permits a new first controller. Automatic first-controller
pairing cannot prevent an active hostile client from winning the very first race
without an out-of-band secret or user confirmation.

Outbound control requires an existing configured Gateway record on the Agent and
a pinned WSS connection to its HTTPS listener. Plain WS is refused. Mutual proofs
bind the session before any operations; encrypted, authenticated sessions may carry
credentials under the existing credential policy. See
[the V148.1 report](../../docs/v148_1-gateway-client-auth-mutual-pairing-report.md)
for protocol and recovery details.


`src/gateway_agent/` is the node-local execution service used by the Agent
Runtime for shell commands.
The served manual is the canonical current documentation surface. The gateway
docs here cover shell execution; Gmail and other external services use their
own service boundaries and are documented in the manual.

The gateway:

- runs on one host;
- executes concrete validated commands locally on that host;
- only accepts requests whose `node` matches its configured logical node name;
- supports buffered execution, streaming execution, and cancellation;
- supports PTY-backed terminal sessions for interactive Agent UI commands;
- exposes a small local LLM process manager used by the Agent UI Settings
  launch terminal/status controls;
- returns command failures as structured command results instead of HTTP
  failures.


## Install and update

From the checkout root, run `./src/gateway_agent/install.sh`. It creates or updates
`src/gateway_agent/.venv` from the canonical `pyproject.toml` dependency contract,
then checks dependencies and mandatory runtime imports. Normal `./install.sh` on
Linux also runs this setup. Restart the Gateway after updating; installation does
not restart active services. Repeat this on each remote Gateway host after its
checkout is updated. A degraded `/capabilities` response reports
`http_runtime.ready=false` and omits `http_request`; repair through the installer.

The installer attempts the `.[full]` profile after installing the core, including Docker SDK, PDF, Office, Linux
accessibility, enterprise HTTP authentication, manual/site and Python tooling
dependencies. Native setup provisions OCR/English data, `psql`, 7-Zip, clipboard
tools, accessibility/Kerberos build libraries and shell utilities. Debian/Ubuntu
and Fedora/Arch install missing Docker CLI/Compose/Buildx packages from configured
repositories; openSUSE hosts must provide those Docker clients themselves.
Docker Engine configuration and access remain operator-owned. Unsupported or
missing optional distro packages are reported and other packages are still attempted;
no package repositories are added.

The installer checks both browser renderers, native imports, package versions,
all bundled skill registrations and native clients. Optional failures are recorded in
`.venv/smto-installation.json` and leave dependent operations unavailable while
core Gateway installation continues. Only core runtime failures stop installation.
System-dependency skip flags leave absent optional dependencies unavailable.
Repair dependencies, rerun installation and restart the Gateway to retry features.
Use `.venv/bin/python -I -m gateway_core.installation_check` from this directory
to rerun the package/native audit without changing the environment. See the
[root installation contract](../../README.md) for configuration prerequisites.

Browser execution is enabled by default with no additional startup arguments. Gateway
setup installs Playwright and its matching Chromium, then verifies a headless JavaScript
render. On apt-based Linux it also installs browser OS dependencies unless the existing
system-dependency skip settings are set. Run installation under the Gateway's OS account
so its browser cache is available at startup. `GATEWAY_BROWSER_ENABLED=false` is an explicit
operator opt-out. Conversation capability permissions remain separate.

## API endpoints

- `GET /healthz`
  - returns `{ "status": "ok", "node": "<configured node>" }`
- `GET /capabilities`
  - returns `{ "node": "<configured node>", "version": "...", "capabilities": [...] }`
- `POST /exec`
  - request: `{ "node": str, "command": str, "execution_id": str | null }`
  - response: `{ "stdout": str, "stderr": str, "exit_code": int }`
- `POST /exec/stream`
  - request: `{ "node": str, "command": str, "execution_id": str | null }`
  - response: `text/event-stream`
- `POST /exec/privileged`
  - buffered compatibility API: one sanitized JSON execution receipt
- `POST /exec/privileged/stream`
  - the same privileged request and execution semantics, with `text/event-stream`
  - request fields: `node`, `command`, optional `cwd`, `execution_id`, `username`,
    and a runtime-owned private `password`; authentication stdin is isolated
- `POST /exec/ssh-v2/privileged` and `POST /exec/ssh-v2/privileged/stream`
  - separate buffered/streamed remote sudo protocol, advertised as
    `ssh_remote_privilege_v2` on POSIX Gateways
  - requires the exact direct SSH command plus bounded `ssh_context` with an
    already verified public host identity; ordinary `/exec/ssh-v1` establishes it
  - an ordinary SSH client authenticates using native noninteractive key/agent
    authentication; sudo and the requested command run on the SSH destination
  - remote sudo credentials use SSH stdin, never argv or environment variables
  - revalidates the host/user/port configuration, uses a fresh connection and a
    temporary strict host-key pin; no keyscan, TOFU or relaxed host checking
  - V1 excludes proxy hops, sshpass/wrappers, PTYs, application stdin, alternate
    sudo identities and background remote jobs; `cwd` remains Gateway-local
  - unsupported/missing endpoints return not-executed failure. Remote requests
    never fall back to `/exec/privileged`; that API remains Gateway-local
  - receipts distinguish the execution target, transport Gateway, privilege locus,
    confirmed elevation and uncertain remote effects. A lost outcome is not replayed
- `POST /exec/cancel`
  - request: `{ "node": str, "execution_id": str }`
  - response: `{ "cancelled": bool, "execution_id": str, "message": str }`
- `WebSocket /terminal/ws`
  - opens or attaches to a PTY-backed terminal session
- `POST /terminal/exec/stream`
  - runs one command inside an active terminal session and streams structured
    output
- `POST /terminal/exec/detach`
  - starts a terminal-owned command without runtime output capture
- `POST /terminal/write`
  - mirrors runtime-produced output into an active terminal session
- `POST /terminal/input`
  - writes runtime-provided input bytes into an active terminal PTY
- `GET /llm/status`
  - returns status for the gateway-managed local LLM launch command
- `GET /llm/log`
  - returns recent local LLM launch log output
- `POST /llm/start`
  - starts or restarts the configured local LLM command
- `POST /llm/stop`
  - stops the configured local LLM command

Command failures return `200` with a non-zero `exit_code`. Request validation
problems return `4xx`.


## Streaming Events

`POST /exec/stream` emits server-sent events.

Common event names:

- `stdout`
- `stderr`
- `completed`
- `cancelled`
- `error`

The Agent UI renders these events as collapsible command output capsules.

Privileged foreground commands use `/exec/privileged/stream` and the same
`stdout`, `stderr`, and `completed` vocabulary. Text events contain sanitized
`text` and `elevated`. Completion includes `exit_code`, `executed`, `elevated`,
`error_kind`, and `truncated`; unknown outcomes also carry
`status: "outcome_unknown"`. Aggregate the text events to reconstruct the
buffered receipt. Both APIs share one privilege core and classifier.

The gateway consumes authentication diagnostics and elevation markers before
network emission, redacts credentials across fragment boundaries, and preserves
target stdout/stderr within the existing one MiB receipt quota. Authentication
failures return safe diagnostics. Starting the stream is an execution attempt;
only elevation evidence establishes that the target executed. A missing terminal
receipt is an unknown outcome and must not cause an automatic retry.

Both ordinary and privileged foreground execution emit the Agent's canonical
`execution.command.started`, `.stdout`, `.stderr`, and `.completed` events.
Privileged events add `privileged` and `elevated` metadata. The displayed command
is the original target, and the existing command renderer handles the output.
These events do not trigger model inference per chunk.

Runtime credential delivery allows loopback connections and verified, pinned remote HTTPS.
Remote outbound WS/WSS credentials require client pairing that is not yet provided.
Remote plaintext HTTP/WS carrying a password is refused with
`privilege_transport_insecure`, including under Full Access. HTTP redirects are
disabled for privileged requests. The same guard protects credential-bearing job
starts; existing job execution and log inspection semantics remain unchanged.


## Terminal Sessions

The terminal API is used by the Agent UI for commands that need a real PTY:

- SSH passphrases;
- password or credential prompts;
- tools that require a controlling terminal;
- long-running commands the user wants to observe directly.

The runtime marks such commands with `interaction_mode: may_prompt` or
`execution_mode: terminal_detached`. If the command output looks like it is
waiting for input, the Agent UI brings the terminal forward so the user can
type into it.

Terminal sessions are process-local. They can disappear when the gateway
restarts or when idle cleanup closes them.

The Agent UI stores one saved terminal cwd per gateway in
`artifacts/agent_gateways.db`. The terminal Save Workspace button, browser
close/pagehide autosave, and gateway-change autosave update that record so
requests against each gateway resume in the expected directory.


## Cancellation

The gateway tracks active streamed commands by `execution_id`.

When `/exec/cancel` is called, the gateway attempts to terminate the active
process group for that execution id. The runtime stop button uses this path when
a long-running command is active and an execution id is available.


## Install

```bash
cd /path/to/smto
./src/gateway_agent/install.sh
```

This creates a dedicated gateway virtual environment at
`src/gateway_agent/.venv`.


## Configuration

- `GATEWAY_NODE_NAME`
  - logical node served by this agent
  - default: `localhost`
- `GATEWAY_BIND_HOST`
  - bind host
  - default: `127.0.0.1`
- `GATEWAY_BIND_PORT`
  - bind port
  - default: `8787`
- `GATEWAY_EXEC_TIMEOUT_SECONDS`
  - per-command timeout; set to `0` to disable task timeouts
  - default: `0`
- `GATEWAY_TERMINAL_IDLE_TIMEOUT_SECONDS`
  - terminal idle cleanup window, when configured by the gateway settings
- `GATEWAY_TRACE_COMMANDS`
  - log each requested command on the gateway server
  - default: `0`
- `GATEWAY_SERVER_HOST`
  - Agent server host for outbound gateway mode
- `GATEWAY_SERVER_PORT`
  - Agent server port for outbound gateway mode
- `GATEWAY_SERVER_SCHEME`
  - Agent server scheme for outbound gateway mode
  - default: `http`
- `GATEWAY_WORKDIR`
  - optional working directory for command execution
- `GATEWAY_LLM_LOG_DIR`
  - log directory for the gateway-managed local LLM process
  - default: `/tmp/smto-llm`


## Run

```bash
export GATEWAY_NODE_NAME=localhost
export GATEWAY_BIND_HOST=127.0.0.1
export GATEWAY_BIND_PORT=8787

python -m gateway_core.serve gateway_agent.app:app --host "${GATEWAY_BIND_HOST}" --port "${GATEWAY_BIND_PORT}"
```

Or use the helper script:

```bash
./src/gateway_agent/startup.sh
```

The helper accepts host and port overrides:

```bash
./src/gateway_agent/startup.sh --host 0.0.0.0 --port 8787
```

This is useful when the Agent UI/runtime is on a different machine from the
gateway. Because the gateway has no built-in authentication, bind to
`0.0.0.0` only on a trusted network or behind a trusted proxy/firewall.

If the Agent server is reachable from the gateway but the gateway cannot accept
inbound connections, use outbound mode. The gateway opens a persistent
WebSocket back to the Agent server and does not expose its own HTTP listener:

```bash
aor serve --host 0.0.0.0 --port 8011
./src/gateway_agent/startup.sh --server-host 192.168.1.10 --server-port 8011
```

To print each requested command on the gateway server side:

```bash
./src/gateway_agent/startup.sh --trace-commands
```

or:

```bash
export GATEWAY_TRACE_COMMANDS=1
./src/gateway_agent/startup.sh
```


### Multiple independent instances

Different listener ports automatically select different Gateway state. For example,
run these in separate terminals:

```bash
./src/gateway_agent/startup.sh --port 8787
./src/gateway_agent/startup.sh --port 8989
./src/gateway_agent/startup.sh --port 8990
```

Port 8787 keeps the existing installation and pairing. Other ports use
`~/.smto/gateway/instances/port-PORT/`, with independent TLS keys, controller
pairing, replay protection, jobs, recovery checkpoints, Docker operation state,
browser profiles, artifacts, managed temporary files and LLM logs. Each instance
must be enrolled separately in the controller. Starting another process against
an already-owned instance fails at startup; it does not leave a broken listener.

Use `--instance build-worker` (or `GATEWAY_INSTANCE=build-worker`) to retain the same
identity and history when changing ports. Names use lowercase letters, digits,
hyphens and underscores. Outbound gateways also support named instances:

```bash
./src/gateway_agent/startup.sh --instance build-worker --port 8989
./src/gateway_agent/startup.sh --instance remote-worker --server-host 192.168.1.10 --server-port 8011 --server-scheme https
```

`GATEWAY_INSTANCES_ROOT` changes the parent directory for isolated instances.
Existing per-directory overrides such as `GATEWAY_JOB_DIR` and
`GATEWAY_TLS_STATE_DIR` remain authoritative; use distinct paths for independent
instances. `--instance default` explicitly selects the legacy installation,
including when retaining a gateway that previously used a nondefault port.
This isolates Gateway-managed state. Instances still share the OS account, host
files, physical devices and external services they are authorized to access.

For instance-specific pairing recovery, stop that instance and use
`./src/gateway_agent/startup.sh reset --port 8989`, or
`./src/gateway_agent/startup.sh reset --instance build-worker` for a named instance.
The macOS scripts accept the same options; Windows startup accepts `-Instance`
and `-Port`. Compiled Gateway executables accept `--instance` and `--port` too.
On Windows the default instance parent is
`%LOCALAPPDATA%/SMTO/Gateway/instances`.

Source startup uses the installed Gateway environment. After updating this
checkout, run the platform installer before launching with the new behavior.

## Runtime Wiring

The runtime can discover the gateway through config or environment variables.
A typical node entry points at the gateway `/exec` endpoint:

```yaml
nodes:
  default: localhost
  endpoints:
    - name: localhost
      url: https://127.0.0.1:8787/exec
```

The runtime can derive the matching streaming and cancellation endpoints from
the gateway base URL when shell streaming is enabled.


## Security Notes

This service does not include authentication. Keep it bound to loopback or
behind a trusted proxy/network boundary.

The gateway is not a prompt interpreter. It should receive only concrete
commands that have already passed runtime validation and approval policy.

## Automatic Gateway TLS

Supported startup now serves HTTPS on the existing port, normally `https://host:8787`.
smTO generates a durable RSA identity and renews its self-signed certificate
automatically at startup. No OpenSSL executable, certificate copying, CA installation,
fingerprint confirmation, or OS trust-store changes are needed. The Agent pins the
public key on first configured use and verifies it before sending requests. Existing
remote HTTP profiles upgrade automatically when the updated listener is available.

A changed identity key stops operations. After checking the intended machine, use
**Settings → Gateways → Forget trusted identity** for an intentional reinstall/reset,
then reconnect and select the Gateway again. Normal certificate renewal needs no reset.

This protects traffic from passive snooping and pins the Gateway server identity.
Automatic first-use trust cannot prevent an active attacker during first contact.
TLS does not authenticate clients: reachable execution endpoints still require the
existing trusted network/firewall boundary. Remote legacy HTTP cannot carry credentials.
Remote outbound WSS pins the configured Agent server, but credential delivery remains
blocked until independent outbound Gateway client pairing is available; loopback
outbound development remains supported.

See [the V148 report](../../docs/v148-secure-gateway-prerequisite-recovery-report.md)
for identity locations, trust semantics, and acceptance evidence.


### Gateway runtime coherence (V151.1)

The supported installer installs a non-editable package snapshot from the current checkout,
checks canonical dependencies with `pip check`, and validates job and HTTP readiness. Run the
platform installer again after pulling or switching branches, then explicitly restart the
Gateway to use that revision. A Git checkout alone does not upgrade or restart a running Gateway.
Updating dependencies belongs to the installer; the server never installs packages on demand.

`startup.sh` / `startup.ps1` use Python isolated mode and reject legacy editable environments.
Startup checks load jobs, shell execution, privilege, terminal, and available HTTP support before
serving requests. Missing or incompatible `psutil` fails startup with installer guidance.
Authenticated `/capabilities` includes `background_jobs.ready` and a bounded `runtime_identity`
(package version, source snapshot fingerprint, and psutil version), without filesystem paths.

For development, use a separate development environment and invoke `python -m gateway_core.serve`
or the platform app directly. Source/editable development is an explicit opt-in by bypassing the
production startup script; restart that development process whenever code or dependencies change.
Production startup deliberately provides no editable/hot-upgrade switch. Installer updates to an
in-use environment require a coordinated explicit restart; they are not a hot-upgrade mechanism.

## Desktop UI automation

Linux semantics require PyGObject (`gi`), the AT-SPI typelib and a graphical session accessibility bus. X11 keyboard/pointer fallback additionally requires XTEST. Wayland semantics may work, but input fallback is unavailable. Use the optional `ui-linux` Python extra with native GI development libraries, or install distribution GI packages for the same Python version as the Gateway; do not replace its dependency environment.

The optional `ui` skill reports live partial capabilities through `ui.status`; it is disabled
in fresh Agent capability defaults. See the [Desktop UI manual](../manual/content/architecture/40-desktop-ui.md)
for reference lifetime, secure-field behavior, input bounds and platform validation limitations.
