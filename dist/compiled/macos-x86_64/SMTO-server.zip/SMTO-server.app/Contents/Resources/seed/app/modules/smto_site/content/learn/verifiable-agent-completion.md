---
{"title": "How to check whether a task is really finished", "status": "published"}
---
## A finished action may not finish the whole task

Suppose you ask the assistant to read a file and summarize its main points. The
file tool may finish successfully, but you still need an accurate summary. The AI
saying “done” does not by itself prove that both parts were completed.

Check three things: did the tool run, did it return the information needed, and
does the answer match what you asked for? These questions help you spot the
difference between a completed step and a useful final result.

## What SMTO checks

SMTO saves tool results and checks for required results, unanswered questions,
and unfinished work where supported. If an action's outcome is unclear, a confident
final answer should not make that uncertainty disappear.

The optional Task Contract feature records what the task is meant to achieve.
It is a plan for the work, not proof that the work succeeded. The AI still makes
judgments about whether the answer is good enough, and those judgments can be wrong.

## Look at the current result

Open the file that was created, read the tool output, or check the changed
information yourself. Make sure the result belongs to the task you are reviewing.
A successful result from an earlier attempt does not prove a later attempt worked.

Saved memories can help the assistant choose a useful action. They do not show
what happened today. A working command from last week may fail on a different
computer or after a setting changes.

## Check sources in research answers

If you enable Web Research, the assistant can read online sources and use them
in an answer. Search previews help find pages; they do not replace reading the
page itself. Check that the cited source supports the statement being made.

A website can be wrong or outdated. If a page could not be opened, its contents
remain unknown. Opening websites with the separate Browser tool also needs the
right access and setup.

## A partial answer should say what is missing

A task may stop because a service is unavailable, permission was denied, or some
information could not be checked. A useful answer says what was done and what
remains. It should not present unfinished work as a success.

See the [activity history guide](/docs/operations/activity),
[how a task runs](/learn/agent-execution-loop), and
[what memory can retain](/learn/context-and-memory).
Explore [SMTO's features](/product) and [installation options](/download).
