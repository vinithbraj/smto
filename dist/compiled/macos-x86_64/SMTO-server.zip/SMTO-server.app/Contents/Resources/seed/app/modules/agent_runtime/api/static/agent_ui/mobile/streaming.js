/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/streaming.js
 * @brief Own mobile run trace streams and the page's separate invalidation connection.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Attach one trace owner per displayed turn, resume its cursor and
 * reconcile authoritative snapshots after disconnects or terminal trace frames.
 * Boundaries: Callbacks own turn rendering, navigation generation and active-run selection.
 * Reconnection observes existing work; it never submits or resumes an execution request.
 * Lifecycle: The mobile app creates one controller, starts updates after bootstrap and
 * attaches displayed active turns. Hide/pagehide close streams and cancel pending timers;
 * visibility/online recovery refreshes snapshots and replaces the update transport.
 * State: Controller-local trace owners, retry timers and update cursor. Owner/stream identity
 * fences late callbacks. Trace retries back off to 15 seconds; update retries use 3 seconds.
 * Security: Server snapshots determine current work; SSE status text grants no authority.
 * Request IDs are URL-encoded and retained cursors only select observation history.
 * Collaborators: mobile/app.js supplies reconciliation callbacks; api.js performs scoped
 * reads and connection presentation; conversation_snapshot.js tracks active trace transports.
 * Public surface: createStreams returns attach, stopTrace and updates. Instantiate once
 * per page: its global event listeners have page lifetime, not per-conversation lifetime.
 * @see src/agent_runtime/api/static/agent_ui/mobile/app.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/api.js
 * @see src/agent_runtime/api/static/agent_ui/conversation_snapshot.js
 * @see src/agent_runtime/api/static/agent_ui/ui_updates.js
 */
import { api, encode, connection } from "./api.js";

/** Bind page-owned callbacks; they retain turn state and decide whether a run is still current. */
export function createStreams({ event, snapshot, cursor, refresh, current }) {
  const traces = new Map();
  let updateSource = null, updateTimer = null, updatesAfter = 0;
  /** Close a turn's transport/timer and remove its owner, or stop every attached trace. */
  function stopTrace(turn) {
    if (!turn) {
      for (const owner of traces.values()) stopTrace(owner.turn);
      return;
    }
    const owner = traces.get(turn.id);
    if (!owner) return;
    owner.source?.close();
    clearTimeout(owner.timer);
    traces.delete(turn.id);
  }
  /** Idempotently attach this turn object while visible, replacing an older same-ID owner. */
  function attach(turn) {
    if (document.hidden) return;
    if (traces.get(turn.id)?.turn === turn) return;
    stopTrace(turn);
    const owner = {turn, source: null, timer: null, retry: 0};
    traces.set(turn.id, owner);
    /** Reject work for replaced owners or turns disposed by conversation navigation. */
    const valid = () => traces.get(turn.id) === owner && !turn.disposed;
    /** Open observation from the saved cursor only if this owner remains visible and valid. */
    const connect = () => {
      owner.timer = null;
      if (!valid() || document.hidden) return;
      const url = new URL(turn.replyStreamUrl || turn.replyResume?.streamUrl || `/api/agent/stream/${encode(turn.id)}`, location.href);
      const params = url.searchParams;
      if (turn.cursor) params.set("after_id", String(Math.max(turn.cursor, Number(params.get("after_id")) || 0)));
      if (turn.createdAt) params.set("trace_created_at", turn.createdAt);
      const stream = new EventSource(url.href);
      owner.source = stream;
      window.SMTOReadPriority?.stream(stream);
      /** Fence callbacks from a previous transport even when the turn owner still exists. */
      const live = () => valid() && owner.source === stream;
      stream.addEventListener("open", () => {
        if (live()) {
          owner.retry = 0;
          connection();
        }
      });
      stream.addEventListener("heartbeat", () => {
        if (live()) connection();
      });
      stream.addEventListener("trace.cursor", (message) => {
        if (!live()) return;
        try {
          cursor(turn, JSON.parse(message.data).created_at);
        } catch {
          /* Ignore malformed receipts. */
        }
      });
      stream.addEventListener("trace", (message) => {
        if (!live()) return;
        let payload;
        try {
          payload = JSON.parse(message.data);
        } catch {
          return;
        }
        const answeredWait = window.SMTOTaskLifecycle?.observeReply(turn.replyResume, payload);
        event(turn, payload);
        if (
          !answeredWait && !turn.replyResume?.pending && /^request\.(completed|suspended|failed|cancelled|interrupted)$/.test(
            payload.event_type || "",
          )
        ) {
          stream.close();
          owner.source = null;
          void reconcile();
        }
      });
      stream.addEventListener("error", () => {
        if (!live()) return;
        stream.close();
        owner.source = null;
        connection(navigator.onLine ? "Reconnecting…" : "Waiting for network…");
        void reconcile();
      });
    };
    /** Refresh active ownership before reconnecting; settled turns receive a final summary.
     * Failed reads retain bounded-delay retries. Recheck the owner after awaits so a
     * navigation cannot paint an old snapshot or close a replacement's transport. The
     * snapshot callback may itself await, so cleanup needs a second ownership check.
     */
    const reconcile = async () => {
      try {
        await refresh();
        if (!valid()) return;
        if (!current(turn.id)) {
          const trace = await api(`trace/${encode(turn.id)}/summary`);
          if (!valid()) return;
          await snapshot(turn, trace);
          if (!valid()) return;
          stopTrace(turn);
          connection();
          return;
        }
      } catch {
        if (valid())
          connection(
            navigator.onLine
              ? "Couldn’t reconnect. Retrying…"
              : "Waiting for network…",
          );
      }
      if (valid())
        owner.timer = setTimeout(connect, Math.min(1000 * 2 ** owner.retry++, 15000));
    };
    connect();
  }
  /** Replace the visible page's update stream at its retained sequence cursor.
   * A sync-required frame may reset the cursor after server restart. Refresh only relevant
   * invalidations; failures close this source before scheduling the existing fixed retry.
   */
  function updates() {
    updateSource?.close();
    clearTimeout(updateTimer);
    if (document.hidden) return;
    const stream = new EventSource(
      `/api/agent/updates/stream?after=${updatesAfter}`,
    );
    updateSource = stream;
    stream.addEventListener("ui_update", (message) => {
      if (updateSource !== stream) return;
      try {
        const payload = JSON.parse(message.data),
          sync = (payload.topics || []).includes("sync.required");
        updatesAfter = sync
          ? Number(payload.seq) || 0
          : Math.max(updatesAfter, Number(payload.seq) || 0);
        if (
          sync ||
          (payload.topics || []).some((topic) =>
            [
              "runs.changed",
              "events.changed",
              "tasks.changed",
              "chats.changed",
              "settings.changed",
            ].includes(topic),
          )
        )
          void refresh(payload);
      } catch {
        /* Unknown future update events are harmless. */
      }
    });
    stream.addEventListener("open", () => {
      if (updateSource === stream) {
        connection();
        void refresh();
      }
    });
    stream.addEventListener("error", () => {
      if (updateSource !== stream) return;
      stream.close();
      updateSource = null;
      connection(
        navigator.onLine
          ? "Live updates disconnected. Reconnecting…"
          : "Waiting for network…",
      );
      updateTimer = setTimeout(() => {
        void refresh();
        updates();
      }, 3000);
    });
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      stopTrace();
      updateSource?.close();
      updateSource = null;
      clearTimeout(updateTimer);
    } else {
      void refresh();
      updates();
    }
  });
  window.addEventListener("online", () => {
    void refresh();
    updates();
  });
  window.addEventListener("offline", () => connection("Waiting for network…"));
  window.addEventListener("pagehide", () => {
    stopTrace();
    updateSource?.close();
    clearTimeout(updateTimer);
  });
  return { attach, stopTrace, updates };
}
