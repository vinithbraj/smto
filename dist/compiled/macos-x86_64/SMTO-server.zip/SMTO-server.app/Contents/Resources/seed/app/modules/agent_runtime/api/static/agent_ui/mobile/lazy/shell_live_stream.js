/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/lazy/shell_live_stream.js
 * @brief Expose the shared command observer at the mobile disclosure's lazy entry point.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Forward mountShellInspector without loading desktop composition.
 * Boundaries: The shared observer owns rendering/transport; mobile rows own panels.
 * Lifecycle: Mobile conversation rows load this adapter when output is expanded.
 * State: No adapter state; ES module caching retains the shared viewer owner.
 * Security: The forwarded observer reads server-scoped output and cannot execute commands.
 * Collaborators: conversation.js supplies the panel and request/operation identity.
 * Public surface: mountShellInspector is the original shared export, with its existing
 * lifecycle contract and identity preserved.
 * @see src/agent_runtime/api/static/agent_ui/mobile/conversation.js
 * @see src/agent_runtime/api/static/agent_ui/shell_live_stream.js
 */
export {mountShellInspector} from "../../shell_live_stream.js?v=20261015-smto";
