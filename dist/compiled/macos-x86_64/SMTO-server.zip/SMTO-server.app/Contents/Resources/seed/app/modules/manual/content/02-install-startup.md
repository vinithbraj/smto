---
id: install-startup
title: Install and startup
kind: manual
tags: [manual, gateway, install]
order: 18
---
# Install and startup

## Start from source

This guide installs SMTO from source code, meaning the original project files
rather than a ready-made installer. You need Python 3.11 or newer, a copy of the
project supplied by the maintainer, and an AI model that works with SMTO. These steps
use a terminal, an app for entering commands. You may need help from someone with
technical experience.

For ready-made downloads, visit the
[release repository](https://github.com/vinithbraj/smto) and choose
the folder for your operating system. Follow the instructions supplied with those
files; the commands below apply to a source checkout.

SMTO has a main program that manages tasks and a Gateway program that runs tools
on the computer you choose. The AI model is a separate program or online service.
Read the installer before running it, and use a computer you are allowed to manage.

### Install on Linux

Open a terminal in the project folder. Run the installer:

```bash
./install.sh
```

Start the Gateway, which runs tools on this computer:

```bash
./src/gateway_agent/startup.sh
```

In another terminal in the project folder, start the main SMTO program:

```bash
./startup.sh
```

### Install on macOS

Use the same installer and main startup command. For the Gateway, use
`./src/gateway_macos/startup.sh` instead of the Linux command.

To use a Mac only as a computer that runs tools, use
`./src/gateway_macos/install.sh` and `./src/gateway_macos/startup.sh`.
This installs the Gateway and its required software without installing the main
SMTO program. It also attempts to set up optional tools such as Browser.

### Use a Windows computer to run tools

The Windows Gateway uses `src/gateway_windows/install.ps1` and
`src/gateway_windows/startup.ps1` in PowerShell. These set up the computer that
runs tools; they are not instructions for installing the main SMTO program on Windows.

### Open SMTO and connect your AI

After the main program starts, open its `/agent-ui` page in a browser. With the
default setup on the same computer, the address is `http://127.0.0.1:8011/agent-ui`.
While saved data loads, an initialization page shows the current stage and elapsed
time. It opens the requested page automatically when the program is ready. If it
reports initialization failed, check the main program's terminal logs, correct the
cause, and restart the program. Refreshing the page does not retry initialization.

Requesting `/restart` switches the workspace to the same progress screen for shutdown.
A flashing red indicator shows that shutdown is underway; normal workspace controls
remain unavailable. Expand the phases to see service stops, pending operations,
repository saves, validation, durable publication, and elapsed timings. Remaining-time
estimates use measured progress or previous shutdowns when available. The screen then
shows startup and returns to your original page when the new process is ready. If the
final save fails, the screen explains the failure and offers **Retry restart** while
keeping the workspace locked.

In Mission Control, choose the Gateway and enter the connection details for a
supported AI model. Select the model before asking the assistant to do work.

The main program uses port 8011 and the Gateway uses 8787 by default. A port is the
number in a network address that identifies a service. The startup script also opens
the manual on port 8013 and a troubleshooting console on port 8015. They close when
the main startup script exits. The Gateway and AI service have their own start and
stop commands.

For a direct Uvicorn launch from the project folder, use:

```bash
.venv/bin/python -m uvicorn --app-dir src smto_runtime.server:create_app --factory --host 127.0.0.1 --port 8011 --timeout-graceful-shutdown 5
```

Service monitors can use `/livez` to check that the web server is responding and
`/healthz` to check runtime readiness. `/healthz` and runtime APIs return HTTP 503
during initialization or after initialization failure; `/api/startup` reports the
stage and status without reading the database. The eager
`agent_runtime.api.app:create_app` factory remains available for embedded callers.

While saved data loads, the browser shows **Preparing your workspace**, the current
startup step, and elapsed time. The page uses the app’s shared theme and cube mark;
it follows your tab’s light/dark override, or your device theme until saved settings
are available. The progress animation respects reduced-motion preferences. Leave
the page open: it reconnects automatically and opens your original page, including
any conversation link, when startup finishes. If startup fails, it shows the failed
step and recovery instructions instead of continuing the loading animation.

For advanced setup, `AOR_MANUAL_AUTOSTART=0` and `AOR_CONSOLE_AUTOSTART=0` turn off
those automatic starts. `./startmanual.sh` starts the manual separately. Do not start
a second copy on a port already in use. Availability of ready-made downloads is
listed separately on the website's Download page.

## Gateway pairing and platform setup

For connection recovery, stop the Gateway and its automatic restart service,
then run the command for your installation:

| Installation | Reset command |
| --- | --- |
| Compiled Gateway | `./smto-gateway-linux-x86_64 reset` (use your platform's executable) |
| Linux source | `./src/gateway_agent/reset.sh` or `./src/gateway_agent/startup.sh reset` |
| macOS source | `./src/gateway_macos/reset.sh` or `./src/gateway_macos/startup.sh reset` |
| Windows source | `./src/gateway_windows/reset.ps1` |
| Installed Python environment | `python -m gateway_core.reset` |

Use the same OS account and `GATEWAY_TLS_STATE_DIR` as startup. Add `--dry-run`
to preview without changing files, or `--tls-state-dir PATH` to select an explicit
state directory. The PowerShell equivalents are `-DryRun` and `-TlsStateDir PATH`.
Reset clears controller pairing, saved outbound server identity pins, and
abandoned authentication temporary files. It preserves the Gateway's TLS identity,
replay protection, job history, artifacts, downloaded files, and configuration.
It does not stop jobs or repair installed dependencies. Restart the Gateway and
connect the intended controller. A runtime lease blocks reset while a current
Gateway is using that state; older Gateway versions must be stopped explicitly.

To reset Gateway controller pairing, stop the Gateway and run
`./src/gateway_agent/reset-pairing.sh` on Linux or
`./src/gateway_macos/reset-pairing.sh` on macOS. Use the same OS account and
`GATEWAY_TLS_STATE_DIR` setting as startup. Then restart the Gateway and connect
the intended controller. These scripts use the Gateway's installed virtual
environment and preserve its TLS identity.

macOS requires a 64-bit Python 3.11+ and compatible canonical dependencies.
Existing PATH, MacPorts, Homebrew, and Python.org framework interpreters are
discovered even when standard install locations are absent from PATH. Use
`PYTHON_BIN=/path/to/python3.11` to select a specific interpreter. With no
compatible Python, the installer can use an existing package manager:
`AOR_MACOS_PACKAGE_MANAGER=auto` prefers Homebrew on Apple Silicon and MacPorts
on Intel, then tries the other usable manager. `homebrew` and `macports` force
one manager; `none` prevents package installation. `AOR_SKIP_SYSTEM_DEPS=1`,
`GATEWAY_SKIP_SYSTEM_DEPS=1` (Gateway only), or `AOR_INSTALL_SYSTEM_DEPS=0` also
prevent installation. Root setup passes its resolved Python to Gateway setup
with `GATEWAY_SKIP_SYSTEM_DEPS=1` to avoid duplicate system installs.

Neither package manager is bootstrapped, and shell profiles and global Python
selection are left alone. Existing Python can run the core Gateway without
either manager; missing Git only disables Git-specific workflows. Intel and
Apple Silicon installer support does not certify every older macOS version.
Optional browser components can impose stricter requirements; their failure leaves
Browser unavailable without blocking core installation. Both root and standalone
installers record optional failures in each venv's `smto-installation.json`.
Repair dependencies, rerun installation and restart services to retry those features. See the
[macOS Gateway guide](../../gateway_macos/README.md) for examples and diagnostics.

Configure the model endpoint with the active LLM settings and use the inference defaults in `src/agent_runtime/llm/product_profile.py`. Provider/model processes are separate from the deterministic runtime. See `src/llm/README.md` for model launch scripts.

`./setupplaywright.sh` installs Chromium for UI tests. It creates no runtime browser profile.

Set `AOR_AGENT_STATE_DIR` for an isolated state directory. Preserve existing user databases when upgrading. Seed builders are for fresh development installations, not resetting a running user's data.


## Public manual

The public website uses `https://smtorch.com`. Its manual is served separately at
`https://manual.smtorch.com/manual`; the service root redirects to `/manual`.

Prepare the repository environment with `./setup-manual.sh`, then run:

```bash
./scripts/start-smto-manual.sh
```

On Windows, install the project with its `manual` extra into `.venv`, then use
`./scripts/start-smto-manual.ps1`. Both launchers accept `--host`, `--port`, and
`--reload`. CLI options override `AOR_MANUAL_HOST`, `AOR_MANUAL_PORT`, and
`AOR_MANUAL_RELOAD`. The defaults are `127.0.0.1:8013` with reload disabled.
`SMTO_MANUAL_PYTHON` selects a different interpreter. The launchers check dependencies
and start one manual process; they do not install packages or start the Agent, Gateway,
or website. The public manual always uses product branding and does not query personal
Agent settings. `./startmanual.sh` retains local sidecar behavior through `--local`.

For a Linux deployment, place the checkout and its `.venv` at `/opt/smto-manual` and
run the service as a dedicated `smto-manual` user. Adapt
`packaging/manual/smto-manual.service.example` to your installation. It gives generated
manual references a writable cache under `/var/cache/smto-manual` while keeping the
checkout read-only. Use `packaging/manual/Caddyfile.example` to terminate HTTPS and
proxy `manual.smtorch.com` to `127.0.0.1:8013`. Point the subdomain's DNS to that host
and make its HTTPS endpoint reachable before activating the proxy.

Only one process can own port 8013. When the public launcher and the Agent run on the
same host, set `AOR_MANUAL_AUTOSTART=0` for the Agent. Stopping the public launcher
stops only its own manual process; an occupied port is an error, not a request to stop
another service. Keep reload disabled in the deployed service.

App manual links retain their local behavior: localhost and private LAN hosts use the
app host on the configured manual port (8013 by default). Public app hosts link to
`https://manual.smtorch.com/manual`, preserving document and heading fragments.
