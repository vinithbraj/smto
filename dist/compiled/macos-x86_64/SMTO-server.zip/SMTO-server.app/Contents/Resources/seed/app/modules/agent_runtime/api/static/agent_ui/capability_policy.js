/* Explicit composer policy. Catalog and saved defaults are server-owned; no polling. */
(() => {
  "use strict";
  const defaultSkills = ["agent", "email", "file", "gateway", "memory", "python", "shell"];
  const fields = ["enabled_skill_ids", "enabled_tool_ids", "preferred_skill_ids", "excluded_skill_ids", "preferred_tool_ids", "excluded_tool_ids",
    "preferred_shell_executables", "excluded_shell_executables"];
  const copy = value => JSON.parse(JSON.stringify(value));
  const selection = (value = {}) => ({schema_version: 1, mode: value?.mode === "manual" ? "manual" : "automatic",
    always_skill_ids: [...new Set(value?.always_skill_ids || [])].sort(), always_tool_ids: [...new Set(value?.always_tool_ids || [])].sort()});
  const canonical = (value = {}) => Object.fromEntries([["schema_version", 1],
    ...fields.map(key => [key, [...new Set(value[key] ?? (key === "enabled_skill_ids" ? defaultSkills : []))].sort()])]);
  // Accept only the local policy contract; never carry server defaults or arbitrary fields.
  function safeDraftState(value = {}) {
    const policy = value => {
      if (!value || typeof value !== "object" || value.schema_version !== 1) return null;
      for (const key of fields) {
        if (key.startsWith("enabled_") && value[key] === undefined) continue;
        const limit = key.endsWith("skill_ids") ? 64 : key.endsWith("tool_ids") ? 128 : 64;
        const pattern = key.endsWith("skill_ids") ? /^[a-z][a-z0-9_]{0,127}$/
          : key.endsWith("tool_ids") ? /^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$/ : /^[A-Za-z0-9_+@.][A-Za-z0-9_+@.-]*$/;
        if (!Array.isArray(value[key]) || value[key].length > limit
          || value[key].some(id => typeof id !== "string" || id.length > (key.endsWith("tool_ids") ? 256 : 512) || !pattern.test(id))) return null;
      }
      return canonical(value);
    };
    const prompt = value?.has_prompt_override === true ? policy(value.policy) : null;
    const pending = policy(value?.pending_policy);
    const safeSelection = v => v && ["manual", "automatic"].includes(v.mode)
      && ["always_skill_ids", "always_tool_ids"].every(key => Array.isArray(v[key]) && v[key].length <= 128
        && v[key].every(id => typeof id === "string" && /^[a-z][a-z0-9_.]{0,255}$/.test(id))) ? selection(v) : null;
    const selected = safeSelection(value.selection), pendingSelected = safeSelection(value.pending_selection);
    return {has_prompt_override: prompt !== null, ...(prompt ? {policy: prompt} : {}),
      ...(pending ? {pending_policy: pending} : {}), ...(selected ? {selection: selected} : {}),
      ...(pendingSelected ? {pending_selection: pendingSelected} : {})};
  }

  window.SMTOCapabilityPolicy = {safeDraftState, create({apiJson, mode, button, chips, quickButton, scopeSelect, globalOnly = false, gatewayId = () => "", notify = () => {}, onDraftChanged = () => {}}) {
    let catalog = null, catalogLoad = null, conversationId = null;
    let catalogTarget = null, catalogConversation = null, catalogVersion = 0;
    let promptPolicy = null, pendingPolicy = null, generation = 0, revision = 0, readVersion = 0;
    let promptSelection = null, pendingSelection = null, draftSelection = selection();
    const autoToggle = document.querySelector("#automatic-capability-selection");
    let draft = canonical(), dirty = false, saving = false, refresh = null, refreshAgain = false;
    let resolved = {policy: canonical(), source: "default", scopes: {}, at_scope: {}};
    let loaded = false, editingRevision = 0;
    const scopeNames = {prompt: "This prompt", conversation: "This conversation", global: "Global", default: "Product default"};
    const json = (method, value) => ({method, headers: {"Content-Type": "application/json"},
      ...(value === undefined ? {} : {body: JSON.stringify(value)})});
    const dialog = document.createElement("dialog");
    dialog.className = "capability-dialog";
    dialog.setAttribute("aria-labelledby", "capability-title");
    dialog.innerHTML = `<form method="dialog">
      <header><h2 id="capability-title">Capabilities</h2><button type="button" data-close aria-label="Close capability editor" data-ui-symbol="cross">×</button></header>
      <label><input data-automatic type="checkbox" class="mission-switch" role="switch" checked>Automatic Capability Selection</label>
      <p data-selection-help class="capability-help">Auto: eligible for selection · Always: included for every request · Never: unavailable to the Agent. Agent Introspection, Task Context, Memory and Shell are always included. File read is included whenever permitted.</p>
      <label>Apply to <select data-scope aria-label="Capability policy scope"><option value="prompt">This prompt</option><option value="conversation">This conversation</option><option value="global">Global</option></select></label>
      <p data-source class="capability-help"></p>
      <p data-mode-note class="capability-help" hidden></p>
      <p data-error role="alert" hidden></p>
      <div class="capability-editor-scroll"><fieldset data-editor>
        <input type="search" data-search aria-label="Search capabilities" placeholder="Search Skills, tools, and runtime controls">
        <div class="capability-actions"><button type="button" data-reset>Reset</button><button type="button" data-exclude-others>Exclude all others</button><button type="button" data-refresh>Refresh catalog</button></div>
        <div data-skills class="capability-skills"></div>
        <section data-shell><h3>Shell executable rules</h3>
          <p class="capability-help">Match actual executables such as curl or wget. Excluding curl does not block network access through another allowed tool.</p>
          <div class="capability-executable-input"><input data-executable aria-label="Shell executable" placeholder="Executable, e.g. curl" maxlength="512"><button type="button" data-prefer-executable>+ Prefer</button><button type="button" data-exclude-executable>− Exclude</button></div>
          <div data-executables></div>
        </section>
      </fieldset></div>
      <footer><span class="capability-help">Changes apply to the next request.</span><button type="button" data-inherit>Use inherited capabilities</button><button type="button" data-cancel>Cancel</button><button type="button" data-apply>Apply</button></footer>
    </form>`;
    document.body.append(dialog);
    const find = selector => dialog.querySelector(selector);
    const scope = find("[data-scope]"), search = find("[data-search]"), error = find("[data-error]");
    if (globalOnly) {
      for (const option of [...scope.options]) if (option.value !== "global") option.remove();
      scope.value = scopeSelect.value = "global";
    }
    const report = message => { error.textContent = message || ""; error.hidden = !message; };
    const policyUrl = id => `/api/agent/chats/${encodeURIComponent(id)}/capability-policy`;
    const quick = document.createElement("section");
    quick.id = "capability-quick-menu"; quick.className = "capability-quick-menu"; quick.hidden = true;
    quick.setAttribute("aria-label", "Quick capabilities");
    quick.innerHTML = `<h3>Capabilities</h3>
      <p class="capability-help">Unchecked capabilities are removed from the Agent's available tool set and are not advertised to the model.</p>
      <p data-quick-error role="alert" hidden></p>
      <div data-quick-list></div>
      <div class="capability-actions"><button class="capability-button" type="button" data-all>Select all</button><button class="capability-button" type="button" data-none>Clear all</button></div>
      <p class="capability-help">Agent Introspection, Task Context, Memory, Shell and core Agent controls remain selected. Execution permissions still apply.</p>
      <footer><button class="capability-button" type="button" data-quick-cancel>Cancel</button><button class="capability-button" type="button" data-quick-apply>Apply</button></footer>`;
    document.body.append(quick);
    const quickReport = message => {
      const target = quick.querySelector("[data-quick-error]");
      target.textContent = message; target.hidden = !message;
    };
    function closeQuick(focus = false) {
      if (quick.hidden) return;
      quick.hidden = true; dirty = false;
      quickButton.setAttribute("aria-expanded", "false");
      if (focus) quickButton.focus();
    }
    function positionQuick() {
      if (quick.hidden) return;
      const anchor = quickButton.getBoundingClientRect();
      const above = anchor.top > window.innerHeight - anchor.bottom;
      quick.style.maxHeight = `${Math.max(160, (above ? anchor.top : window.innerHeight - anchor.bottom) - 20)}px`;
      quick.style.left = `${Math.max(12, Math.min(anchor.left, window.innerWidth - quick.offsetWidth - 12))}px`;
      quick.style.top = above ? "auto" : `${anchor.bottom + 8}px`;
      quick.style.bottom = above ? `${window.innerHeight - anchor.top + 8}px` : "auto";
    }
    function renderQuick() {
      if (quick.hidden) return;
      const list = quick.querySelector("[data-quick-list]"); list.replaceChildren();
      function checkbox(kind, id, name, available, reason, tools = []) {
        if (alwaysEnabled(kind, id)) {
          const entry = document.createElement("div"); entry.dataset.rule = id; entry.className = "capability-builtin";
          const title = document.createElement("strong"); title.textContent = name;
          const note = document.createElement("small"); note.textContent = "Built in · Always enabled";
          entry.append(title, note);
          if (!available) {
            const unavailable = document.createElement("small");
            unavailable.textContent = `Unavailable: ${String(reason || "Not currently supported").slice(0, 160)}`;
            entry.append(unavailable);
          }
          list.append(entry); return;
        }
        const label = document.createElement("label"), input = document.createElement("input");
        input.type = "checkbox"; input.checked = stateFor(kind, id) !== "excluded";
        // Keep checkbox semantics for the mixed state of custom tool rules.
        input.className = "mission-switch";
        input.disabled = saving || !available;
        input.setAttribute("aria-label", name);
        const custom = input.checked && tools.some(tool => draft.enabled_tool_ids.includes(tool.tool_id) || draft.preferred_tool_ids.includes(tool.tool_id) || draft.excluded_tool_ids.includes(tool.tool_id));
        input.indeterminate = custom;
        const text = document.createElement("span"); text.textContent = name;
        const notes = [];
        if (custom) {
          notes.push("Custom tool rules");
          label.title = "Some tools in this capability have custom rules. Open the full Capability editor for details.";
        } else if (stateFor(kind, id) === "preferred") notes.push(draftSelection.mode === "automatic" ? "Always" : "+ Preferred");
        if (!available) notes.push(`Unavailable on selected Gateway: ${String(reason || "Not currently supported").slice(0, 160)}`);
        if (notes.length) { const note = document.createElement("small"); note.textContent = notes.join(" · "); text.append(note); }
        input.addEventListener("change", () => {
          setRule(kind, id, input.checked ? "default" : "excluded"); renderQuick();
          [...list.querySelectorAll("input")].find(el => el.getAttribute("aria-label") === name)?.focus();
        });
        label.append(input, text); list.append(label);
      }
      for (const skill of catalog?.skills || []) checkbox("skill_ids", skill.skill_id, skill.display_name, skill.available, skill.reason, skill.tools);
      if (catalog?.tools?.length) {
        const heading = document.createElement("h3"); heading.textContent = "Other tools"; list.append(heading);
        for (const tool of catalog.tools) checkbox("tool_ids", tool.tool_id, tool.display_name, tool.available, tool.reason);
      }
      const runtime = runtimeControls("", true);
      if (runtime) list.append(runtime);
      if (!catalog) list.append(Object.assign(document.createElement("p"), {textContent: "Loading capabilities…"}));
      for (const button of quick.querySelectorAll("button")) button.disabled = saving || (!catalog && !button.matches("[data-quick-cancel]"));
      positionQuick();
    }
    quickButton.addEventListener("click", async () => {
      if (!quick.hidden) { closeQuick(true); return; }
      if (!loaded || saving) return;
      beginDraft(scopeSelect.value); quick.hidden = false;
      quickButton.setAttribute("aria-expanded", "true"); renderQuick();
      try {
        await loadCatalog();
        if (!quick.hidden) { renderQuick(); quick.querySelector("input")?.focus(); }
      } catch (error) { if (!quick.hidden) quickReport(error.message || "Could not load capabilities. Reopen to retry."); }
    });
    scopeSelect.addEventListener("change", () => { closeQuick(); renderChips(); });
    quickButton.closest(".policy-inline")?.addEventListener("policy-collapse", () => closeQuick());
    quick.querySelector("[data-quick-cancel]").onclick = () => closeQuick(true);
    quick.querySelector("[data-quick-apply]").onclick = () => void apply();
    for (const [selector, value] of [["[data-all]", "default"], ["[data-none]", "excluded"]]) {
      quick.querySelector(selector).onclick = () => {
        for (const skill of catalog?.skills || []) {
          if (value === "default" && !skill.available) continue;
          setRule("skill_ids", skill.skill_id, value);
        }
        for (const tool of catalog?.tools || []) {
          if (value === "default" && !tool.available) continue;
          setRule("tool_ids", tool.tool_id, value);
        }
        renderQuick();
      };
    }
    const outsideQuick = event => {
      if (!saving && !quick.contains(event.target) && !quickButton.contains(event.target)) closeQuick();
    };
    const escapeQuick = event => {
      if (event.key === "Escape" && !quick.hidden && !saving) { event.preventDefault(); closeQuick(true); }
    };
    document.addEventListener("pointerdown", outsideQuick);
    document.addEventListener("keydown", escapeQuick);
    window.addEventListener("resize", positionQuick);
    const effectivePolicy = () => copy(resolved.policy);
    const selectionForRequest = () => promptSelection === null ? undefined : copy(promptSelection);
    const policyForRequest = () => promptPolicy === null ? undefined : copy(promptPolicy);
    const selectedPolicy = (selected = scope.value) => resolved.at_scope[selected]?.policy || canonical();
    const draftSnapshot = () => safeDraftState({has_prompt_override: promptPolicy !== null,
      policy: promptPolicy, pending_policy: pendingPolicy, selection: promptSelection, pending_selection: pendingSelection});
    function restoreDraftState(value) {
      const restored = safeDraftState(value);
      // Scope restoration invalidates editor saves started for the previous draft.
      generation += 1; revision += 1;
      promptPolicy = restored.has_prompt_override ? restored.policy : null;
      pendingPolicy = !conversationId ? restored.pending_policy || null : null;
      promptSelection = restored.selection || null;
      pendingSelection = !conversationId ? restored.pending_selection || null : null;
      dialog.close(); closeQuick(); loaded = false; modeChanged(); void refreshConversation(); onDraftChanged();
    }

    function entries(policy) {
      return fields.filter(key => !key.startsWith("enabled_")).flatMap(key => (policy[key] || []).map(id => ({key, id,
        label: key.endsWith("skill_ids") ? catalog?.skills.find(skill => skill.skill_id === id)?.display_name || id : id,
        sign: key.startsWith("preferred") ? "+" : "−"})));
    }
    function renderChips() {
      chips.replaceChildren();
      const forced = resolved.selection?.mode === "automatic" ? ["skill_ids", "tool_ids"].flatMap(kind =>
        (resolved.selection[`always_${kind}`] || []).map(id => ({id, key: `always_${kind}`, sign: "+", always: true,
          label: kind === "skill_ids" ? catalog?.skills.find(skill => skill.skill_id === id)?.display_name || id : id}))) : [];
      const rules = [...forced, ...entries(effectivePolicy())];
      for (const rule of rules.slice(0, 3)) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "capability-chip";
        chip.dataset.state = rule.sign === "+" ? "preferred" : "excluded";
        chip.textContent = rule.always ? `Always · ${rule.label}` : `${rule.sign}${rule.label}`;
        chip.setAttribute("aria-label", `${rule.always ? "Always" : rule.sign === "+" ? "Preferred" : "Excluded"}: ${rule.label}. Edit rule`);
        chip.addEventListener("click", () => open(rule));
        chips.append(chip);
      }
      if (rules.length > 3) {
        const more = document.createElement("button");
        more.type = "button"; more.className = "capability-chip";
        more.textContent = `+${rules.length - 3} more`;
        more.addEventListener("click", () => open());
        chips.append(more);
      }
      chips.hidden = !rules.length;
      chips.dataset.advisory = String(mode() === "advisory");
      button.title = `Capabilities — ${scopeNames[resolved.source]}`;
      const policy = selectedPolicy(scopeSelect.value);
      const skills = catalog?.skills || [];
      quickButton.textContent = catalog ? `Enabled ${skills.filter(skill => stateFor("skill_ids", skill.skill_id, policy) !== "excluded").length}/${skills.length} ▾` : "Capabilities ▾";
      if ((resolved.selection?.mode || "automatic") === "automatic") quickButton.textContent = "Capabilities · Auto ▾";
      if (autoToggle) { autoToggle.checked = (resolved.selection?.mode || "automatic") === "automatic"; autoToggle.disabled = !loaded || saving; }
      quickButton.title = `Editing ${scopeNames[scopeSelect.value]}. Active: ${scopeNames[resolved.source]}.`;
      quickButton.disabled = !loaded || saving;
      scopeSelect.disabled = !loaded || saving;
      find("[data-source]").textContent = `Capabilities — ${scopeNames[resolved.source]}`;
    }
    function alwaysEnabled(kind, id) {
      if (kind === "skill_ids") return catalog?.skills.find(skill => skill.skill_id === id)?.always_enabled === true;
      if (kind === "tool_ids") return [...(catalog?.tools || []), ...(catalog?.skills || []).flatMap(skill => skill.tools)]
        .some(tool => tool.tool_id === id && tool.always_enabled === true);
      return false;
    }
    function stateFor(kind, id, policy = draft) {
      if (policy === draft && kind !== "shell_executables" && draftSelection.mode === "automatic"
          && draftSelection[`always_${kind}`].includes(id)) return "preferred";
      if (alwaysEnabled(kind, id)) return policy[`preferred_${kind}`].includes(id) ? "preferred" : "default";
      if (policy[`excluded_${kind}`].includes(id)) return "excluded";
      if (policy[`preferred_${kind}`].includes(id)) return policy === draft && kind !== "shell_executables" && draftSelection.mode === "automatic" ? "default" : "preferred";
      if (kind === "shell_executables") return "default";
      if (policy[`enabled_${kind}`].includes(id)) return "default";
      if (kind === "tool_ids") {
        const parent = catalog?.skills.find(skill => skill.tools.some(tool => tool.tool_id === id));
        if (parent && !policy.excluded_skill_ids.includes(parent.skill_id)
          && [...policy.enabled_skill_ids, ...policy.preferred_skill_ids].includes(parent.skill_id)) return "default";
      } else {
        const skill = catalog?.skills.find(skill => skill.skill_id === id);
        if (skill?.tools.some(tool => !policy.excluded_tool_ids.includes(tool.tool_id)
          && [...policy.enabled_tool_ids, ...policy.preferred_tool_ids].includes(tool.tool_id))) return "default";
      }
      return "excluded";
    }
    function setRule(kind, id, value) {
      if (alwaysEnabled(kind, id)) return;
      if (kind !== "shell_executables") {
        draftSelection[`always_${kind}`] = draftSelection[`always_${kind}`].filter(item => item !== id);
        if (draftSelection.mode === "automatic" && value === "preferred") draftSelection[`always_${kind}`].push(id);
      }
      if (kind !== "shell_executables") {
        const key = `enabled_${kind}`;
        draft[key] = draft[key].filter(item => item !== id);
        if (value !== "excluded") draft[key].push(id);
      }
      for (const prefix of ["preferred", "excluded"]) {
        const key = `${prefix}_${kind}`;
        draft[key] = draft[key].filter(item => item !== id);
        if (value === prefix && !(prefix === "preferred" && kind !== "shell_executables" && draftSelection.mode === "automatic")) draft[key].push(id);
      }
      if (kind === "skill_ids" && value === "excluded") {
        const tools = new Set(catalog?.skills.find(skill => skill.skill_id === id)?.tools.map(tool => tool.tool_id) || []);
        draft.enabled_tool_ids = draft.enabled_tool_ids.filter(tool => !tools.has(tool));
        draft.preferred_tool_ids = draft.preferred_tool_ids.filter(tool => !tools.has(tool));
        draft.excluded_tool_ids = draft.excluded_tool_ids.filter(tool => !tools.has(tool));
        draftSelection.always_tool_ids = draftSelection.always_tool_ids.filter(tool => !tools.has(tool));
      }
      draft = canonical(draft); dirty = true; report("");
    }
    function row(kind, id, name, description, unavailable, disabled = false) {
      const root = document.createElement("div");
      root.className = "capability-row"; root.dataset.rule = id;
      const text = document.createElement("div");
      const title = document.createElement("strong"); title.textContent = name; text.append(title);
      if (description) { const detail = document.createElement("small"); detail.textContent = description; detail.title = description; detail.className = "capability-description"; text.append(detail); }
      if (unavailable) { const reason = document.createElement("small"); reason.className = "capability-unavailable"; reason.textContent = unavailable; text.append(reason); }
      if (alwaysEnabled(kind, id)) {
        const note = document.createElement("small"); note.textContent = "Built in · Always enabled";
        text.append(note); root.append(text); return root;
      }
      const controls = document.createElement("div"); controls.className = "capability-states";
      controls.setAttribute("role", "group"); controls.setAttribute("aria-label", name);
      const automatic = draftSelection.mode === "automatic" && kind !== "shell_executables";
      controls.dataset.mode = automatic ? "automatic" : "manual";
      const states = automatic
        ? [["default", "Auto", "Auto"], ["preferred", "Always", "Always"], ["excluded", "Never", "Never"]]
        : [["preferred", "+", "Prefer"], ["default", "○", kind === "shell_executables" ? "Default" : "Enable"], ["excluded", "−", "Exclude"]];
      for (const [value, symbol, label] of states) {
        const toggle = document.createElement("button"); toggle.type = "button"; toggle.textContent = symbol;
        toggle.setAttribute("aria-label", `${label} ${name}`); toggle.title = `${label} ${name}`;
        toggle.setAttribute("aria-pressed", String(stateFor(kind, id) === value));
        toggle.disabled = disabled;
        toggle.addEventListener("click", () => { setRule(kind, id, value); renderEditor();
          dialog.querySelector(`[data-rule="${CSS.escape(id)}"] button[aria-pressed="true"]`)?.focus(); });
        controls.append(toggle);
      }
      root.append(text, controls); return root;
    }
    function runtimeControls(query = "", collapsed = false) {
      const controls = (catalog?.runtime_controls || []).filter(control =>
        ["runtime controls read only", control.tool_id, control.description, control.policy_note]
          .join(" ").toLocaleLowerCase().includes(query));
      if (!controls.length) return null;
      const section = document.createElement(collapsed ? "details" : "section");
      section.className = "capability-runtime-controls";
      const heading = document.createElement(collapsed ? "summary" : "h3");
      heading.textContent = `Runtime controls (${controls.length}) · Read only`;
      const help = document.createElement("p"); help.className = "capability-help";
      help.textContent = "Managed automatically. These controls cannot be changed here.";
      section.append(heading, help);
      for (const control of controls) {
        const row = document.createElement("div"); row.className = "capability-runtime-control";
        row.dataset.runtimeControl = control.tool_id;
        const name = document.createElement("strong"); name.textContent = control.tool_id;
        const description = document.createElement("small"); description.textContent = control.description;
        const note = document.createElement("small"); note.textContent = control.policy_note;
        row.append(name, description, note); section.append(row);
      }
      return section;
    }
    function renderEditor() {
      find("[data-automatic]").checked = draftSelection.mode === "automatic";
      find("[data-selection-help]").textContent = draftSelection.mode === "automatic"
        ? "Auto: eligible for selection · Always: included for every request · Never: unavailable to the Agent. Agent Introspection, Task Context, Memory and Shell are always included. File read is included whenever permitted. Execution permissions still apply."
        : "+ Prefer when applicable · ○ Enabled · − Disabled. Agent Introspection, Task Context, Memory and Shell are always enabled.";
      const expanded = new Set([...dialog.querySelectorAll("details[open]")].map(el => el.dataset.skill));
      const list = find("[data-skills]"); list.replaceChildren();
      const query = search.value.toLocaleLowerCase().trim();
      for (const skill of catalog?.skills || []) {
        const matches = [skill.skill_id, skill.display_name, skill.description,
          ...skill.tools.flatMap(tool => [tool.tool_id, tool.display_name, tool.description])].join(" ").toLocaleLowerCase().includes(query);
        if (!matches) continue;
        const item = document.createElement("section"); item.className = "capability-skill";
        item.append(row("skill_ids", skill.skill_id, skill.display_name, skill.description,
          !skill.available ? `Unavailable: ${skill.reason}` : ""));
        if (skill.configurable) {
          const configure = document.createElement("button"); configure.type = "button";
          configure.className = "skill-configure-button";
          configure.textContent = `Configure ${skill.display_name} · ${skill.configuration_status === "ready" ? "Ready" : "Partially configured"}`;
          configure.addEventListener("click", () => window.SMTOSkillConfiguration.open(skill.skill_id, skill.display_name));
          item.append(configure);
        }
        const details = document.createElement("details"); details.dataset.skill = skill.skill_id;
        details.open = Boolean(query) || expanded.has(skill.skill_id);
        const summary = document.createElement("summary"); summary.textContent = `Tools (${skill.tools.length})`; details.append(summary);
        for (const tool of skill.tools) {
          details.append(row("tool_ids", tool.tool_id, tool.tool_id, `${tool.display_name} · ${tool.effect}`,
            !tool.available ? `Unavailable: ${tool.reason}` : "", draft.excluded_skill_ids.includes(skill.skill_id)));
        }
        item.append(details); list.append(item);
      }
      for (const tool of catalog?.tools || []) {
        if (![tool.tool_id, tool.display_name, tool.description].join(" ").toLocaleLowerCase().includes(query)) continue;
        list.append(row("tool_ids", tool.tool_id, tool.tool_id, `${tool.display_name} · ${tool.effect}`,
          !tool.available ? `Unavailable: ${tool.reason}` : ""));
      }
      const runtime = runtimeControls(query);
      if (runtime) list.append(runtime);
      if (!list.children.length) { const empty = document.createElement("p"); empty.textContent = catalog ? "No matching capabilities." : "Loading capabilities…"; list.append(empty); }
      find("[data-shell]").hidden = stateFor("tool_ids", "shell.command") === "excluded";
      const executables = find("[data-executables]"); executables.replaceChildren();
      for (const id of [...new Set([...draft.preferred_shell_executables, ...draft.excluded_shell_executables])].sort()) {
        executables.append(row("shell_executables", id, id, "", ""));
      }
    }
    function modeChanged() {
      const advisory = mode() === "advisory";
      scope.disabled = globalOnly || saving;
      find("[data-editor]").disabled = saving || !loaded;
      find("[data-apply]").disabled = saving || !loaded || !catalog;
      find("[data-inherit]").disabled = saving || !loaded;
      find("[data-inherit]").textContent = scope.value === "global" ? "Reset to product default" : "Use inherited capabilities";
      find("[data-mode-note]").hidden = !advisory;
      find("[data-mode-note]").textContent = "Ask mode does not execute operational Skills. You can still edit conversation and global preferences.";
      renderChips();
    }
    function invalidateCatalog() {
      catalogVersion++; catalogTarget = gatewayId(); catalogConversation = conversationId;
      catalog = null; catalogLoad = null;
      modeChanged(); if (dialog.open) renderEditor(); if (!quick.hidden) renderQuick();
    }
    async function loadCatalog(force = false) {
      const id = gatewayId(), cid = conversationId;
      if (catalogTarget !== id || catalogConversation !== cid || force) {
        invalidateCatalog();
      }
      if (catalog) return catalog;
      if (!catalogLoad) {
        const version = catalogVersion;
        const query = new URLSearchParams();
        if (id) query.set("gateway_id", id);
        if (cid) query.set("conversation_id", cid);
        catalogLoad = apiJson(`/api/agent/capabilities/catalog${query.size ? `?${query}` : ""}`).then(value => {
          if (version !== catalogVersion || id !== gatewayId() || cid !== conversationId) return;
          catalog = value; modeChanged(); if (dialog.open) renderEditor(); if (!quick.hidden) renderQuick(); return value;
        }).finally(() => { if (version === catalogVersion) catalogLoad = null; });
      }
      return catalogLoad;
    }
    async function targetChanged() {
      if (catalogTarget !== gatewayId() || catalogConversation !== conversationId) invalidateCatalog();
      renderChips(); if (dialog.open) renderEditor();
      try { if (dialog.open || !quick.hidden) await loadCatalog(); }
      catch (error) { if (dialog.open) report("Could not verify capabilities for this target."); throw error; }
    }
    function beginDraft(selected) {
      scope.value = selected;
      editingRevision = resolved.scopes[selected]?.revision || 0;
      draft = canonical(selectedPolicy()); dirty = false; report("");
      draftSelection = selection(resolved.at_scope[selected]?.selection);
      quickReport(""); modeChanged();
    }
    async function open(rule) {
      if (saving) return;
      closeQuick();
      beginDraft(globalOnly ? "global" : rule ? "prompt" : scopeSelect.value);
      search.value = ""; renderEditor();
      if (!dialog.open) dialog.showModal();
      try {
        await Promise.all([loadCatalog(), refreshConversation()]);
        if (!dialog.open) return;
        renderEditor(); modeChanged();
        if (rule) {
          const target = dialog.querySelector(`[data-rule="${CSS.escape(rule.id)}"]`);
          if (target?.closest("details")) target.closest("details").open = true;
          target?.scrollIntoView({block: "nearest"}); target?.querySelector("button[aria-pressed=true]")?.focus();
        } else search.focus();
      } catch (failure) { report(failure.message || "Could not load capabilities. Reopen to retry."); }
    }
    async function refreshConversation() {
      if (catalogTarget !== gatewayId() || catalogConversation !== conversationId) invalidateCatalog();
      if (dialog.open || !quick.hidden) void loadCatalog().catch(failure => notify(failure.message || "Could not refresh capabilities"));
      if (refresh) { refreshAgain = true; return refresh; }
      const epoch = generation, version = readVersion, localRevision = revision;
      const payload = {conversation_id: conversationId, prompt_policy: promptPolicy,
        conversation_policy: conversationId ? null : pendingPolicy, prompt_selection: promptSelection,
        conversation_selection: conversationId ? null : pendingSelection};
      refresh = apiJson("/api/agent/capabilities/effective", json("POST", payload)).then(value => {
        if (epoch !== generation || version !== readVersion || localRevision !== revision) {
          refreshAgain = true; return;
        }
        resolved = value; loaded = true; modeChanged();
        if (dialog.open || !quick.hidden) {
          if (dirty) {
            const message = "Defaults refreshed. Your unsaved edits are still shown; newer saved choices are protected.";
            report(message); quickReport(message);
          } else {
            beginDraft(scope.value);
            if (dialog.open) renderEditor(); else renderQuick();
          }
        }
      }).catch(failure => { notify(failure.message || "Could not refresh capability defaults"); })
        .finally(() => { refresh = null; if (refreshAgain) { refreshAgain = false; void refreshConversation(); } });
      return refresh;
    }
    function setConversation(id) {
      generation += 1; revision += 1; conversationId = id || null;
      promptPolicy = null; pendingPolicy = null; loaded = false;
      promptSelection = null; pendingSelection = null;
      dialog.close(); closeQuick(); modeChanged(); void refreshConversation();
    }
    function followConversation(id) {
      // Keep any explicit unsent prompt choice when queued work changes the visible chat.
      if ((id || null) === conversationId) return;
      generation += 1; revision += 1; conversationId = id || null;
      dialog.close(); closeQuick(); loaded = false; modeChanged(); void refreshConversation();
    }
    function submissionSnapshot() {
      return {policy: policyForRequest(), selection: selectionForRequest(), pending: copy(pendingPolicy), generation, revision};
    }
    async function requestAccepted(id, snapshot) {
      if (generation !== snapshot.generation) return;
      conversationId = id || null;
      if (revision === snapshot.revision) { promptPolicy = null; pendingPolicy = null; promptSelection = null; pendingSelection = null; }
      await refreshConversation(); onDraftChanged(false);
    }
    async function apply(inherit = false) {
      if (saving || !loaded || !catalog) return;
      saving = true; modeChanged(); renderQuick(); report(""); quickReport("");
      const epoch = generation, selected = scope.value, expected = editingRevision;
      try {
        const policy = inherit ? null : await apiJson("/api/agent/capabilities/validate", json("POST", canonical(draft)));
        const selectedConfig = inherit ? null : selection(draftSelection);
        if (!inherit) await apiJson("/api/agent/capabilities/effective", json("POST", {prompt_policy: policy, prompt_selection: selectedConfig}));
        if (generation !== epoch) return;
        if (selected === "prompt") { promptPolicy = policy; promptSelection = selectedConfig; }
        else if (selected === "conversation" && !conversationId) { pendingPolicy = policy; pendingSelection = selectedConfig; }
        else {
          const url = selected === "global" ? "/api/agent/capabilities/settings/global" : `/api/agent/chats/${encodeURIComponent(conversationId)}/capability-settings`;
          readVersion += 1;
          await apiJson(`${url}?expected_revision=${expected}`, json("PUT", {policy, selection: selectedConfig}));
          readVersion += 1;
          if (generation !== epoch) return;
        }
        revision += 1; dirty = false; scopeSelect.value = selected; dialog.close(); closeQuick();
        await refreshConversation(); onDraftChanged();
      } catch (failure) { report(failure.message || "Could not save capability policy"); quickReport(failure.message || "Could not save capability policy"); }
      finally { saving = false; modeChanged(); renderQuick(); }
    }
    function addExecutable(value) {
      const input = find("[data-executable]"), token = input.value;
      if (!/^\/?[A-Za-z0-9_.+@-]+(?:\/[A-Za-z0-9_.+@-]+)*$/.test(token) || token.length > 512) {
        report("Enter an executable name only, such as curl."); return;
      }
      const id = token.split("/").at(-1);
      if ([".", ".."].includes(id) || id.startsWith("-")) { report("Enter an executable name only, such as curl."); return; }
      if (draft[`${value}_shell_executables`].length >= 64 && !draft[`${value}_shell_executables`].includes(id)) {
        report("At most 64 executable rules per state."); return;
      }
      setRule("shell_executables", id, value); input.value = ""; renderEditor(); input.focus();
    }
    button.addEventListener("click", () => open());
    find("[data-automatic]").addEventListener("change", event => {
      draftSelection.mode = event.target.checked ? "automatic" : "manual"; dirty = true; renderEditor();
    });
    autoToggle?.addEventListener("change", () => {
      promptSelection = {...selection(resolved.selection), mode: autoToggle.checked ? "automatic" : "manual"};
      revision += 1; void refreshConversation(); onDraftChanged();
    });
    find("[data-close]").addEventListener("click", () => dialog.close());
    find("[data-cancel]").addEventListener("click", () => dialog.close());
    find("[data-apply]").addEventListener("click", () => void apply());
    find("form").addEventListener("submit", event => event.preventDefault());
    scope.addEventListener("change", () => { beginDraft(scope.value); renderEditor(); });
    find("[data-inherit]").addEventListener("click", () => void apply(true));
    search.addEventListener("input", renderEditor);
    find("[data-refresh]").addEventListener("click", () => {
      void loadCatalog(true).then(() => report("")).catch(failure => report(failure.message || "Could not refresh catalog"));
    });
    find("[data-reset]").addEventListener("click", () => { draft = canonical(); draftSelection = selection(); dirty = true; report(""); renderEditor(); });
    find("[data-exclude-others]").addEventListener("click", () => {
      for (const skill of catalog?.skills || []) {
        const retainedTools = draftSelection.mode === "automatic" ? draftSelection.always_tool_ids : draft.preferred_tool_ids;
        if (stateFor("skill_ids", skill.skill_id) === "default" && !skill.tools.some(tool => retainedTools.includes(tool.tool_id))) setRule("skill_ids", skill.skill_id, "excluded");
      }
      renderEditor();
    });
    find("[data-prefer-executable]").addEventListener("click", () => addExecutable("preferred"));
    find("[data-exclude-executable]").addEventListener("click", () => addExecutable("excluded"));
    find("[data-executable]").addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); addExecutable("excluded"); } });
    const unsubscribe = window.SMTOUiUpdates?.subscribe(["capability-policy.changed", "skill-configuration.changed"], payload => {
      if (payload.topics.includes("skill-configuration.changed")) {
        invalidateCatalog();
        if (dialog.open || !quick.hidden) void loadCatalog().catch(error => notify(error.message));
      }
      if (payload.syncRequired || payload.events.some(event => event.topics?.includes("capability-policy.changed") && (!event.ids?.conversation_id || event.ids.conversation_id === conversationId))) void refreshConversation();
    });
    modeChanged();
    return {loadDefaults: refreshConversation, pendingConversationPolicy: () => copy(pendingPolicy),
      pendingConversationSelection: () => copy(pendingSelection), selectionForRequest,
      loadCatalog, targetChanged, setConversation, followConversation, effectivePolicy, policyForRequest, submissionSnapshot, draftSnapshot, restoreDraftState,
      requestAccepted, modeChanged, reset: () => setConversation(null),
      destroy: () => { unsubscribe?.(); document.removeEventListener("pointerdown", outsideQuick); document.removeEventListener("keydown", escapeQuick); window.removeEventListener("resize", positionQuick); dialog.remove(); quick.remove(); }};
  }};
})();
