import { api, node, button } from "../api.js";
import { openSheet, closeSheet } from "../overlays.js";
import { markdown } from "../markdown.js";

export async function ensureAgreement() {
  const status = await api("/api/legal/eula/status");
  if (status.accepted === true) return true;
  const body = openSheet(`${window.__BRANDING__.display_name} agreement`);
  const document = await api("/api/legal/eula");
  if (!body.isConnected) return false;
  body.append(
    node(
      "p",
      `End User License Agreement & Automation Risk Acknowledgment · ${document.version}`,
    ),
  );
  const terms = node("div");
  markdown(terms, document.display_template || document.text);
  if (document.display_template && typeof document.display_name === "string") {
    const walker = terms.ownerDocument.createTreeWalker(terms, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      // Keep the legal product name independent of personalized UI labels.
      walker.currentNode.textContent = walker.currentNode.textContent.replaceAll(
        "{{brand.display_name}}", () => document.display_name);
    }
  }
  body.append(terms);
  const label = node("label"),
    check = node("input");
  check.type = "checkbox";
  label.append(
    check,
    node(
      "span",
      "I have read and agree to the End User License Agreement and acknowledge the automation risks described above.",
    ),
  );
  body.append(label);
  const agree = button(
    "I Agree",
    async () => {
      if (!check.checked) return;
      await api("/api/legal/eula/accept", {
        method: "POST",
        body: {
          agree: true,
          version: document.version,
          document_sha256: document.document_sha256,
        },
      });
      await closeSheet();
    },
    "primary",
  );
  agree.disabled = true;
  check.onchange = () => {
    agree.disabled = !check.checked;
  };
  body.append(agree);
  // No automatic submission after consent; the intact composer can be sent again.
  return false;
}
