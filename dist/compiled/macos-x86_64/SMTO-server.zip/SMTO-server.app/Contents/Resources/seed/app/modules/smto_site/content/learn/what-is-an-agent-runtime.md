---
{"title": "How SMTO helps an AI assistant do tasks", "status": "published"}
---
## An AI assistant needs tools to do things

An AI model is software that reads your request and produces a response. It can
also suggest an action, such as reading a file. Something still needs to carry out
that action. SMTO connects the AI to tools and keeps track of the work.

For example, you might ask, “Read this text file and list the main points.” The AI
chooses a file tool. SMTO checks whether access is allowed, runs the tool, and saves
the result. The AI uses the returned text to write its answer.

## What “agent” and “runtime” mean

An **agent** is an AI assistant that can use tools to work on a task. A **runtime**
is the software that manages those actions while the task runs. SMTO is that
software. You do not need to remember these terms to use the guides.

The AI decides which step to try next. SMTO handles permissions, tool results,
pauses, and errors. The model you choose still affects how well the task is done.

The browser is your interface to the controller, SMTO's main program. You connect
a separate model for AI decisions. A selected Gateway runs machine-local tools;
other tools run inside the controller or through connected services. These roles
can share a computer or run separately. The public SMTO website explains the setup
and provides downloads; it does not run your tasks.

## SMTO saves more than the chat

The chat shows what you and the assistant said. SMTO also saves which actions ran,
what they returned, and what is still waiting. A message saying a file was read
is different from a saved result showing that the file tool actually read it.

These records help when a task takes several steps or is interrupted. The AI may
receive only part of a long result at once, so it may need to read more before
answering your question.

## You control access

An installed tool is not automatically allowed to do everything. Some actions need
your approval or a signed-in account. If a task needs your input, SMTO can save its
progress and wait for your response.

## Check the result yourself

Saved progress helps SMTO continue work, but it cannot guarantee a correct answer.
The AI can misunderstand the request, and a tool can fail. Start with a small task
and compare the answer with something you can check.

Read about [the AI and SMTO's different jobs](/learn/model-server-vs-agent-runtime),
[paused tasks](/learn/durable-execution-for-ai-agents), and
[following longer tasks](/docs/concepts/jobs). See [SMTO's features](/product)
and [current installation options](/download).
