import "../conversation_composer_profile.js?v=20261015-smto";
/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/composer_profile.js
 * @brief Adapt the shared server profile controller to mobile conversation state.
 * @details
 * Responsibilities: Render profile status, restore targets and gate unavailable selections.
 * Boundaries: Mobile does not create a second persistence or authority model.
 * Lifecycle: Navigation loads profile/catalog; edits autosave; focus/events invalidate revisions.
 * State: api.js owns mobile projections; the shared controller owns transient preference intent.
 * Security: Render safe text and ID-only targets; policy remains global.
 * Collaborators: Shared composer controller, targets.js, mobile app/composer/options.
 * Public surface: composerProfile and loadComposer.
 * @see docs/engineering/conversation-composer.md
 */
import {api, state, notice, $} from "./api.js";
import {targets, loadTargets} from "./targets.js";
let reportedError = null;
export const composerProfile = window.SMTOComposerProfile.create({
  apiJson: (path, options = {}) => api(path, {...options,
    ...(typeof options.body === "string" ? {body: JSON.parse(options.body)} : {})}),
  notify: notice,
  onMissing: () => window.dispatchEvent(new Event("mobile-conversation-missing")),
  changed: profile => {
    state.composerReady = !profile.loading && Boolean(profile.agent_mode);
    if (state.composerReady) {
      for (const key of window.SMTOComposerProfile.fields) state.choices[key] = profile[key];
      const scope = profile.gateway_selection || {schema_version: 1, gateway_ids: profile.gateway_id ? [profile.gateway_id] : [], primary_gateway_id: profile.gateway_id || ""};
      targets().restoreDraftState({schema_version: 2, gateway_selection: scope, gateways: scope.gateway_ids.map(id =>
        ({gateway_id: id, gateway_label: id === profile.gateway_id ? profile.gateway_label_hint || id : id, gateway_locality: "unknown"}))});
    } else {
      state.choices = {}; targets().restoreDraftState({});
    }
    const status = $("#composer-profile-status");
    status.textContent = profile.loading ? "Loading conversation settings…"
      : profile.error || (profile.unsynced ? "Saving conversation settings…" : "");
    if (profile.error) { reportedError = profile.error; notice(profile.error); }
    else if (reportedError) {
      const inline = document.querySelector("[data-sheet-notice]");
      if (inline?.textContent === reportedError) inline.remove();
      if ($("#notice-summary")?.textContent === reportedError) notice();
      reportedError = null;
    }
    validate();
  },
});
function validate() {
  const profile = composerProfile.current();
  state.composerProblem = !composerProfile.ready() ? "Load conversation settings before sending."
    : profile.policyPending ? "Saving conversation policy…" : profile.error && !profile.unsynced ? profile.error
    : !(state.config?.models || []).some(model => model.value === profile.llm_model) ? "Saved model is unavailable. Choose an available model in Prompt settings."
    : targets().unavailable();
  window.dispatchEvent(new Event("mobile-composer-profile-changed"));
}
export async function loadComposer(cid) {
  const loading = composerProfile.activate(cid);
  const catalog = api("model/config").then(models => { state.config = {models: models.options || [], loadedAt: Date.now()}; });
  await Promise.all([loading, catalog, loadTargets()]); validate();
}
window.addEventListener("mobile-targets-changed", event => {
  if (event.detail?.edited && composerProfile.ready()) {
    const selection = targets().gatewaySelection();
    void composerProfile.patch({gateway_id: selection.primary_gateway_id || null,
      gateway_selection: selection.gateway_ids.length ? selection : null});
  }
  validate();
});
window.addEventListener("focus", () => void composerProfile.refresh());
