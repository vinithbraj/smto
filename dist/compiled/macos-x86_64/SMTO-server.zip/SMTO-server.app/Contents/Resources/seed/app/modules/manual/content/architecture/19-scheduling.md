---
id: scheduling-concurrency
title: Scheduling and concurrency
kind: architecture
tags: [architecture, current, scheduling-concurrency]
order: 19
---
# Scheduling and concurrency

An activity is one admitted piece of work in a run. A batch groups proposed activities;
a dependency graph determines readiness; resource admission decides whether ready work
may overlap on the selected target. These layers remain distinct from durable background
jobs and from the model's task board.

Settings → **Resource locking** owns participation in resource admission. The master
switch and every tool-family switch default to **OFF**, including upgrades. Only
`master_enabled AND family_enabled` participates: disabled families neither wait on
nor impose resource conflicts, fairness queues, or inferred CPU, disk, GPU, network,
lightweight and unknown-workload budgets. Worker limits, explicit dependencies,
permissions, cancellation, duplicate-execution protection and database synchronization
remain effective. Operating-system and application-native locking is unchanged.

This is one persisted global policy, independent of conversation/run settings and
Agent Checks. Canonical capability ownership assigns families; internal adapters retain
their originating family. `GET` and `PUT /api/agent/resource-locking` expose the catalog,
revision and Gateway synchronization status; saves require an expected revision.
Authenticated Gateway updates are monotonic and durable. An older Gateway must be
upgraded before execution; a disconnected Gateway remains pending synchronization.

Changes affect running and queued tasks. Disabling wakes resource waiters and resumes
proven unstarted candidates through existing continuation fences. It never turns an
uncertain execution into a completed receipt or automatically replays it. Enabling
uses retained descriptions from active operations to gate new conflicts; already-running
operations continue. The conflict and inferred-budget rules below apply only between
participating families.

`native/activities.py` constructs and preflights batches, isolates activity state, joins
workers and records results. `native/dependency_graph.py` validates predecessor edges
and handles branch transitions. Branch-local behavior allows unrelated work to progress
when the selected policy permits it; a failed or unresolved predecessor does not become
a successful result. `native/resource_scheduler.py` maintains admission queues, classes,
per-target capacity and claim lifetimes in the native store.

Captured multi-Gateway runs use these same owners. `shell.parallel` batches independent
observations; `schedule_activities` expresses per-Gateway inspect/update/verify chains
with `target` and `depends_on`. Proven independent writes on different Gateways may
overlap when parallel execution and disjoint mutations are enabled. Proven disjoint paths on the same target may also overlap under the selected
mutation policy. Shared and unproven effects retain their conflicts. Target selection alone does not prove resource independence.

Group receipts include each child's target/state and a bounded per-target outcome
summary. Failures block dependent branches under the selected policy; unrelated targets
continue. Unknown effects retain resource-local or global blocking according to the
accepted setting. Saturated/offline targets do not reserve other Gateways' tokens.

The effective foreground upper bound comes from `parallel_policy.execution_limit`.
When Parallel Execution is OFF it returns **1**. Dependency admission can lower the
limit and resource admission can delay work; neither can increase that bound. Turning
OFF parallel execution therefore retains a single execution lane even when later
scheduling features are enabled. Unknown resource classification has its own conservative
capacity; it is not proof that work is read-only or safe to overlap.

Capacity policy resolution starts with product defaults, then global, conversation and explicit
prompt settings. Runs retain accepted snapshots; missing legacy snapshots preserve
disabled behavior. Capacity-policy revisions synchronize from persisted run policy.
Resource locking participation always reads the current global policy.
Use supported settings/override APIs for live changes; modifying an old global default
does not mean every paused run inherits it. Cancellation generations, retained jobs and
recovery records govern whether an activity can restart or release its claim.

The execution visualization reads activity/trace projections. It cannot admit work,
release resource claims or declare dependency success. Inspect an activity's reason and
receipt when diagnosing a wait; a queued state may represent dependency readiness,
resource contention or another policy boundary.

Source owners: `native/activities.py`, `dependency_graph.py`, `parallel_policy.py`,
`dependency_policy.py`, `resource_policy.py`, `resource_scheduler.py`.

When changing dispatch, keep budget spend, approval consumption, physical claims
and receipts in their existing order in `native/operations.py`. Eligibility checks
are not necessarily pure: some save state or record guard observations. The
foreground invocation owns its cancellation watcher and signals completion before
joining it. A projection refactor must not add an observer, polling tail or second
job launch. The [state publication contract](07-state.md) also preserves the same
Activity objects across saves while these workers are waiting.

## Execution data and runtime services

`execution/context.py` owns the target snapshot boundary. `target_snapshot` copies
explicit routing, platform, capability, directory and credential-reference fields.
It recursively detaches plain data and rejects live objects within those fields.
`target_snapshots` applies the same boundary to a selected-target map. Only transient
planning may include the authenticated preflight profile; saved targets omit current
dispatch IDs, timeout overrides and preflight state.

RuntimeHost and the execution engine own clients, management services, stores,
connections and cancellation controls. Tool contexts borrow these objects; they are
not durable records. `bind_target` replaces target data while retaining the current
runtime's service references. It does not copy services or inherit omitted machine
defaults from another Gateway. Gateway selection remains run-wide authority.

Background registration, job launch persistence, foreground supervision, external
blocker recovery, dependency activities and artifact collection use this boundary.
Initial preflight copies target data rather than the entire tool context. Activity
routing and run restoration use the same target projection. A new `gateway_*` field
does not become persistent or machine-local merely because of its name.

OAuth callbacks use the same projection to detach routes while borrowing live
services. Gateway transfers use the shared activity target binding and save explicit
ID/path checkpoints. Scheduled events and monitors already capture explicit admission
scope; queued-task compilation and continuations copy saved data. These paths do not
clone a live runtime. The Gateway ingress prefix filter remains a rejection boundary
for untrusted routing fields, not a rule for copying or persisting context.

An invalid snapshot raises the source-owned `execution_context_not_data` runtime
fault. Existing fault handling stops inference and retains the diagnostic rather
than asking the model to retry the command. Target process failures retain their
ordinary execution semantics.

## Human interaction checkpoints

Authority waits are runtime controls. When a future-work request needs the disabled
Schedules capability, discovery immediately opens one approval card and stops inference.
The temporal tool filter needs no special `ask_user` exception. Allow renews capability
authority in a child continuation while preserving the captured due time and future
task. Permission Policy can still require a separate approval for `schedule.create`.
Deny creates no schedule and resumes with a durable denial fact. Repository inspection,
staging, commits and pushes belonging to the future task do not run during this wait.

`native/authority_control.py` keeps independent Activity approvals addressed by their
Activity and operation identities. Accepted replies use the existing durable Activity
wake journal; they cannot overwrite another running Activity or answer its checkpoint.

`ask_user` is a conversation control, independent of Background Activities and Resource
Scheduling settings. Standalone calls go directly to native control dispatch. Explicit
`schedule_activities` graphs may still contain `ask_user` nodes; unresolved nodes block
dependents and parent inference. Already-started jobs continue under their existing
identities and resource claims. Independent, already-declared DAG branches remain
eligible for admission; their Activity-local running state cannot clear the parent's
question or reply identity. Manual Pause and Stop still prevent admission. No new
model decisions occur until the human checkpoint resolves.

At wait and completion boundaries, an actionable human wait takes precedence over
`waiting_job`. The shared Activity projection maps ordinary input, credential and
approval waits to their existing dedicated parent states. Older checkpoints with a
local ordinary wait and a running/job-waiting parent are repaired before inference.
Multiple ordinary waits surface in accepted batch/Activity order, with persisted record
order as the fallback for legacy checkpoints. Answering one exposes the next unresolved
wait without a model polling call. Agent Checks shows the selected ordinary Activity as
waiting for a reply in the conversation; its duplicate text form is suppressed.

An explicit graph that reaches clarification before concrete work leaves terminal output
intent unfrozen. Its accepted proposal is retained on concrete Activities and frozen when
such work starts. Existing frozen output contracts remain unchanged by clarification.

## Structural resource admission

The model represents independent work as separate calls or `shell.parallel`; smTO
alone decides which Activities can overlap. Use `shell.sequence` for known ordered steps,
side-effect dependencies and fail-fast ordering. Sequence steps have separate subprocesses
and explicit working directories; shared shell state requires one ordinary Shell command.
The runtime never rewrites semicolons into background processes or adds a planning call.

Resource classification reuses `shell_operation_facts` and the effect system's read proof.
Punctuation is not a resource class: `echo start; du /tmp; echo done` and
`du /cache/* | sort -rh | head -25` claim `disk_read_heavy=1`. File output and mutating
`find` forms retain conservative disk/unknown admission. Unsupported substitutions,
external scripts and unknown components retain an unknown demand.

Immutable `ResourceClaims` holds bounded integer tokens for every required dimension.
Pipelines union dimensions; sequential commands and Shell Sequence steps hold the maximum
per dimension for their Activity lifetime. Tokens count Activities, not child processes.
Incidental lightweight components add no token when substantive work exists. A CPU/network
Activity reserves both dimensions atomically with global, run and Gateway slots; waiting
work never holds a partial reservation. Selection can skip a full class or target.

| Capacity | Auto/default |
| --- | ---: |
| P1 foreground | 8 |
| P4 Activities per run | 8 |
| Activities per Gateway | 8 |
| Disk read-heavy per Gateway | 2 |
| Disk-heavy / unknown per Gateway | 1 each |
| CPU / network / GPU / lightweight per Gateway | 2 / 2 / 1 / 8 |
| Global Activity slots | 32 |

Settings → **Scheduler capacity** collects the global parallel, background and dependency
activity ceilings, graph sizes, resource budgets, fairness, global Activity slots and
per-Gateway overrides. The section has its own navigation link and searchable field labels.
Enable the corresponding features in **Asynchronous task execution**; inactive features
keep their capacity controls disabled. Choose **Custom** to edit CPU, disk read-heavy,
disk-heavy, network, GPU, lightweight and unknown budgets. Policy controls save on change.
These inferred budgets apply only to families enabled in **Resource locking**;
general activity limits remain independently effective.

| Control | Allowed values |
| --- | --- |
| Parallel / background activities per run | 1–16 |
| Activities per dependency graph / run | 1–256 / 1–1024 |
| Concurrent dependency activities per run / Gateway | 1–16 each |
| Scheduled activities per run | 1–16 |
| Default total activities per Gateway / each resource budget | 1–64 each |
| Global Activity slots | 1–128 |
| Scheduler fairness | Balanced / Interactive first |
| Gateway total / each resource override | Blank for Auto, or 1–64 |

Under **Gateway overrides**, choose a Gateway, edit its limits and select **Save capacity**.
These are the same shared limits exposed by Gateway Management → Details → Activity capacity.
Clearing a Gateway override restores Auto without changing the global policy. Global policy
defaults apply to newly accepted tasks; shared Gateway overrides and global Activity slots
apply to subsequent admissions across tasks. Lowering a limit does not cancel running work.

Agent Checks → Advanced resource limits continues to support conversation, prompt and run
Custom values. An override never exceeds the P1, run, global or target-total ceilings. Auto is
static and conservative; no hardware benchmark or natural-language capacity estimate is used.
With the defaults, seven compatible lightweight observations can physically overlap,
with P4 enabled or disabled. Disk, CPU, network, GPU and unknown budgets remain separate
constraints. Explicit lower run, Gateway and global ceilings remain authoritative.

The existing queue stores sparse JSON claims beside its display class. Startup adds the
column idempotently without removing old rows. Legacy `mixed` maps to the unknown bucket;
old policy JSON receives historical fallback ceilings while preserving its enabled/disabled
state. A captured foreground limit of four stays four. Missing historical policy stays
disabled, with foreground fallback four and P4 run/Gateway/lightweight fallbacks six/three/four.
Run snapshots, durable job reconciliation, receipt identity and authoritative Stop remain
unchanged. Availability updates merge only their owned signal fields, preserving saturation.

Activity details show claims and the admission snapshot: P1 ceiling, run/global/Gateway
usage and limits, each claimed dimension, policy source, Gateway overrides, and the actual
limiting factor. Compact labels distinguish disk-read capacity from Gateway-total waits.
These diagnostics describe admission time; they do not claim to be live hardware telemetry.
Classification, capacity release and ready dispatch use zero LLM calls.

## NVIDIA inspection effects

Shell effects use literal executable/argv evidence through `execution/shell_operations.py`.
Its `execution/nvidia_smi.py` helper proves bounded NVIDIA summary, GPU-list, diagnostic
and selective CSV query forms, including GPU selectors. For example,
`nvidia-smi --query-gpu=index,name,power.limit,power.draw --format=csv` is read-only.
Known configuration operations such as `-pl 250`, `-pm 1` and `--gpu-reset` are
effectful (`gpu_configuration`). Unsupported options, mixed operations, malformed
arguments and NVIDIA continuous-monitoring modes remain unknown.

Existing Shell redirects, compounds, wrapper restrictions and authorization still apply.
Activity descriptors receive these same facts; no user command whitelist or model
classification call is involved. Bounded local NVIDIA queries claim lightweight capacity and a GPU read lock;
configuration claims GPU capacity and a GPU write lock. A query cannot race a
conflicting configuration operation. The exact supported grammar and
verification are recorded in `docs/nvidia-smi-effect-classification-report.md`.

The first-class [GPU skill](/manual#doc=gpu) distinguishes lightweight telemetry from
`gpu_heavy` configuration. Its Gateway job claims exact UUID resources and refuses unknown-effect
replay. The configured GPU capacity remains authoritative; it does not prevent unrelated telemetry.

## Literal remote inspections

Bounded `ssh host 'literal program'` and `sshpass -p VALUE ssh ...` / `sshpass -e ssh ...`
forms propagate the remote program's canonical effect, including NVIDIA configuration
mutations and unknown commands. The accepted transport options include separate `-p`
and `-l` operands, `-T`, `-n`, `-4`, `-6`, `-q`, `-v`/`-vv`/`-vvv`, and explicit bounded
`-o StrictHostKeyChecking=...`, `UserKnownHostsFile=/dev/null`, `ConnectTimeout=...` values.
Forwarding, proxies, local commands, persistent controls and other unsupported options
cannot inherit a read proof. Recursion stops after four SSH layers.

A proven read whose literal SSH chain ends in one supported `nvidia-smi --query-gpu=...`
CSV query claims `lightweight=1` on the dispatching Gateway. The remote GPU is not that
Gateway's local GPU resource. Other remote reads, including `du /`, `find /` and large
content reads, retain `unknown=1`; a read proof alone does not imply lightweight demand.
The Activity target remains the dispatching smTO Gateway, distinct from the SSH
destination. Foreground, resource, global and Gateway limits and accepted policy snapshots
remain authoritative; Parallel OFF still executes sequentially. New product defaults permit
seven such probes on one dispatching Gateway without registering their SSH destinations as
smTO Gateways. The complete grammar and verification are recorded in
`docs/nested-ssh-effect-propagation-report.md`; seven-host capacity acceptance is recorded in
`docs/safe-parallel-wave-expansion-report.md`.

Timing summaries use recorded physical execution intervals, not the parallel tool name or
configured ceiling. The same seven-item batch can truthfully display **Ran up to 7
simultaneously**, **Ran up to 2 simultaneously**, or **Ran sequentially**, depending on
observed overlap. Classification, waves, admission, waiting and joining add no inference.

## Top-level tasks

The composer’s **Depends on** selector creates an explicit success edge to the
chosen live task in the same conversation. It defaults to **No dependency — run
independently** for each submission and resets on conversation changes. This graph
is owned by `tasks/dependencies.py`, separately from the native Activity graph
described above.

Task creation validates and saves the exact selected task ID under the task
store’s SQLite writer transaction. Running and queued tasks are selectable; a
selected task remains selected even if it finishes before submission. Legacy API
clients can still request the immediately previous task. Queue reordering changes
only queue order. The existing conversation coordinator scans for the oldest runnable
task, skipping waiting or failed dependency branches. Parallel Agent tasks retain
global capacity and accepted policy limits; Conversation/Ask tasks retain their
exclusive shared transcript gate.

Failure and interruption affect explicit dependents, not the entire conversation
queue. Retry retains the logical task ID, allowing descendants to resume
eligibility automatically after success. Cancellation of a dependent remains
explicit and final until a user intentionally reopens that task. Native permission,
resource and reconciliation rules continue to apply when eligible work executes.

Running task cards offer **Pause** beside **Stop** on desktop and mobile, including
tasks waiting for a job or event. Pause lets the current action finish, preserves
progress and then offers **Resume** on the same task. Stop remains available while
Pause is pending.

Stopped and interrupted tasks offer **Continue task** and **Restart task** together
on desktop and mobile. Continue preserves execution progress. Restart begins a fresh
attempt from the saved user inputs, retaining the target, model, permissions and other
task settings. It rebuilds execution progress and keeps previous results as historical
context. Previous external actions are not undone, and unresolved effects still require
reconciliation. Both actions retain the logical task ID and queue dependencies; repeated
clicks on either action return the same child attempt.

Stalled, failed and paused tasks also offer **Restart task**, including tasks stopped
by a context-window overflow. Resume, when available, keeps the current attempt;
Restart clears its execution context and starts a new attempt. Restart becomes
available after the previous execution settles and while the task still owns its
conversation position. A replaced attempt cannot resume or launch another child.
Restart retains the original model settings: after correcting a context or output
limit in Settings, submit a new task to use that configuration.

Stalled task cards also offer **Stop** and, when a next queued task is eligible,
**Skip** on desktop and mobile. Stop cancels the stalled attempt and lets the next
task proceed. Skip releases the attempt's run slot while keeping its native status,
results and history unchanged. Failed, stopped and interrupted cards can also Skip
to the next task. Both actions save a decision against the observed request and
waive only the selected next task's dependency on it; other prerequisites still
apply. Later chained tasks wait for their own predecessor. The observed queue
version and next task ID reject stale or duplicate requests.

The saved queue decision prevents automatic execution of a skipped attempt and
survives server recovery. The queue reconciler completes a saved Stop decision
before dispatching its successor. Skip uses an interrupted task-ledger projection
to release capacity while the native run remains stalled. Explicit Resume must
reclaim an available slot; a skipped Conversation turn cannot resume after a later
turn has taken ownership of the shared journal.

Schema version 4 adds optional edge arrays, immutable creation order and cached
dependency projections to the existing task database. Legacy tasks load without
edges. Recovery derives dependency state from recovered execution outcomes;
missing or corrupt dependency targets block execution. Task checkpoints record
transitions, and the execution visualization keeps top-level edges distinct from
internal activity dependencies.


## Structured waits and independent branches

Dependency edges express required predecessor evidence; resource capacity expresses an
admission constraint. Sharing a target, Shell capability or conversation creates no
synthetic dependency. Ready candidates are scanned past blocked branches: an unrelated
lightweight read can start while a disk read is held, and another Gateway remains eligible
when the first Gateway is saturated. Real global/run ceilings, effect overlaps and failed
or unresolved prerequisites still block the affected work. A task lane likewise skips
an ineligible dependent row while preserving explicit dependency selection.

Retained admission waits distinguish dependency, effect guard, resource class, Gateway,
run, global and fairness constraints. They preserve wait-start time and bounded blocker
identities; foreign runs expose only aggregate blocker counts. `Scheduler.observe` reads
these facts and the same admission diagnostic calculation without `_reap`, PID probing or
state repair. Existing execution/lifecycle writers remain the only claim owners.

Deterministic barrier tests in `tests/test_independent_work_hardening.py` hold A, keep B
pending on A, allow independent C (and E on another target), and prevent truly conflicting
D until A releases. They also cover real ceiling limits, task-lane independence and bound
inputs through the existing graph tests. Timing/order evidence is recorded in
`docs/assets/instant-refresh-hardening/scheduler-concurrency.json`.


## Deterministic scheduling profiles and resource locks

Scheduling has three different units of ownership:

| Unit | Owner | Lifetime |
| --- | --- | --- |
| Logical task and predecessor edges | Task store / dependency graph | Until the accepted task settles |
| Agent turn | `native/agent_turns.py` | Actual model call, including its physical I/O lifetime |
| Physical activity | Existing P4 resource scheduler | From atomic admission until physical release evidence |

A task waiting for a job, approval, event, or resource is still open but does not own
an Agent turn. Ready startup reservations prevent excess dispatch before the first
model call. Actual calls acquire FIFO SQLite leases; the configured Agent concurrency
limit bounds calls across runs. Nested tracing uses the same lease. Cancellation of a
caller cannot release a permit while its underlying model I/O remains active. Background
jobs retain physical capacity and locks independently. Existing bounded executors still
limit dispatch workers; parallel Agent journals do not use open-task count as a physical
or model-capacity proxy. Shared Conversation/Ask journals retain their ordering rules.

Each activity receives an immutable `SchedulingProfileV2`: operation/target identity,
execution mode and priority, multidimensional capacity, READ/WRITE/EXCLUSIVE/OBSERVE
identities, effect and confidence, provenance, unresolved scope, requested and inferred
evidence, and a SHA-256 digest. Background is an execution mode, not an unknown resource
class. For example, a literal local download with an explicit output has network and
disk-write demand and a destination write lock whether it runs foreground or background.
An opaque program still has unresolved effects even when its CPU demand is known.

The shared structural Shell parser supplies bounded executable facts. Native Files,
KV, GPU, and existing Docker contracts supply their established resource proofs. Local
filesystem identities include lexical paths, real paths and existing hard-link identities;
parent/child paths conflict. Remote filesystem claims name the normalized target path;
unknown aliases are not replaced with a host or filesystem-root reservation. Namespace V2
binds each resource to its captured Gateway and pinned TLS enrollment. Physical topology
merges known aliases of one host. Shared storage requires an explicit shared-resource key.
The Controller has a separate local domain. Transfers claim their source and destination paths.

A host is a routing target, never a lock. Opaque Shell/Python programs retain any concrete
inferred resources and disclose unresolved effects without a host/global fallback lock.
The operator is responsible for scheduling workloads whose hidden effects could collide.
Named HTTP origins and explicit shared resources still conflict across targets. Missing or
changed target trust prevents dispatch with `requires_target_identity`.

READ/READ overlaps. WRITE/READ and WRITE/WRITE overlapping resources serialize.
Exclusive assertions add conflicts; observing a managed job does not lock its workload.
Capacity and locks activate together in the existing P4 `BEGIN IMMEDIATE` transaction.
A pending candidate owns neither partial capacity nor active locks. Admission examines
compatible candidates beyond a blocked head. Persisted fairness and aging still apply.

All mutation policies enforce overlap on concrete resources. Disjoint resources on the
same host can run concurrently. P4 OFF preserves P1/P2/P3 admission; turning it off does
not discard concrete claims already owned by live work.

Per-target capacity uses the same captured host/Gateway domains, including both endpoints
of a transfer. Proven aliases share limits and the most restrictive applicable override.
An explicit Controller `global_slots` ceiling still applies; diagnostics call this
`waiting_capacity_global`, not a resource lock.

Host locks, unbounded wildcard locks, and V1/global claim compatibility are removed.
Restart does not synthesize historical global fences. Current concrete claims retain
operation ownership until physical completion or reconciliation. Server and Gateway both
use the shared resource overlap rules; both need this code update.

Resource inspection distinguishes local/shared lock waits, physical reconciliation,
target availability, fairness and capacity dimensions. An admitted reservation alone
does not prove a running process. Retained observer deadlines and liveness explain what
happens next; foreign operation IDs and resource paths are omitted. The bounded
`/api/agent/resource-scheduling/waits/{request_id}` read joins lock and accepted dependency
edges without Gateway probes, model calls or ownership writes. Long silent execution is
not a deadlock. Only a closed cycle with no independent progress proves deadlock; an
uncertain physical owner remains a reconciliation problem. Diagnostics never release it.

## Scheduling preferences and exact user contracts

Desktop and mobile Agent Checks expose optional scheduling preset, mode and priority.
Shell/Python tool schemas expose `__smto_scheduling` hints. This reserved envelope
is removed before business argument validation/execution. A hint may add capacity or
exclusive access; it cannot erase a write, narrow unknown scope, grant permissions, or
rewrite a tool's accepted lifecycle. Background preferences use existing captured Shell
job support; foreground preferences suppress automatic promotion. Other tools preserve
their supported execution modes.

An advanced user can GET `/api/agent/resource-scheduling/profiles/{request_id}/{operation_id}`
and PUT the `/contract` subresource with `expected_profile_digest` and `contract`.
Contracts bind the exact tool, target, canonical argument digest, cwd, and script/content
SHA-256 when locally available. The operation must be pending and never admitted. The
update compares the old digest and commits profile, queue demand, and pending locks in
one transaction. Revisions must increase. Accepted execution mode cannot change through
this endpoint; the profile is frozen at admission.

An exact contract may replace the unresolved part of an opaque footprint. It preserves
all known concrete writes and known substantive capacity and records `user_declared`
confidence. For example, a proprietary downloader can declare network and disk capacity
and `fs:local:/models/output`. The declaration applies to that bound invocation only.
A changed locally fingerprinted script is rejected before dispatch. It does not make the
program safe or authorize it: capability, permission, unsafe-action, target, and approval
checks still run. Contracts cannot contain policy or approval fields.

## Observation, diagnostics and recovery

`inspect_execution`, saved context/result reads, job observation/control and native
`agent.info` remain available independently of workload saturation. Controller reads use
a bounded observation reservation (default four); control has a separate reservation.
Nested observation shares its reservation. Status reads are query-only: they neither reap
claims nor invoke a model. Managed job status uses existing job progress and liveness
facts, without scheduling a generic Shell check behind the job itself.

Capacity snapshots contain compact activity counts, target usage, up to 32 waiter
summaries, Agent-turn counts/metrics and observation capacity. They omit full arguments,
receipts, traces and task history. Detailed profiles load by operation identity on demand.
Activity details distinguish resource-lock waits from capacity, fairness and target waits,
and expose inferred/requested/effective evidence. Physical intervals, capacity/lock waits,
peak concurrency, critical-path estimates and aggregate Agent-turn timings remain separate.

In-process releases, model-turn completion, terminal job evidence, cancellation and policy
changes invalidate scheduler waiters. Versioned condition waits avoid lost notifications;
a 500 ms fallback covers cross-process updates and missed external events. Durable task
queue dispatch also subscribes to invalidations. No 50 ms capacity polling is required.

Accepted profiles and normalized locks persist alongside the existing queue. Supported
legacy rows receive conservative profiles from saved claims, without running new classifiers.
A restart restores the same profile digest for live work. Dead Agent-turn process owners
are reaped; unknown physical activity remains held until the existing lifecycle proves
release. Logical cancellation, loss of connectivity or an unknown outcome alone does not
prove death. Conversely, mechanically ended work can release capacity while its historical
outcome stays unknown. Queue status triggers keep locks synchronized during recovery.

All classification, scheduling, observation, stall checks and recovery are deterministic
and add zero model calls. See `docs/smart-effect-resource-scheduler-vnext-report.md` for
exact validation commands, benchmark scope and remaining conservative cases.
