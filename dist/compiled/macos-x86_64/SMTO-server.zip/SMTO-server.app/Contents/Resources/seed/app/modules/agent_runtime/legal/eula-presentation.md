# {{brand.display_name}} End User License Agreement & Automation Risk Acknowledgment

## 1. Acceptance

By selecting "I Agree," you acknowledge that you have read, understood, and agree to this End User License Agreement and Automation Risk Acknowledgment.

If you do not agree, do not use {{brand.display_name}}.

---

## 2. Nature of {{brand.display_name}}

{{brand.display_name}} is an automation agent capable of interacting with computers, operating systems, files, processes, networks, remote systems, APIs, databases, development tools, scheduled tasks, and other connected resources.

Depending on the permissions and capabilities you provide, {{brand.display_name}} may perform actions including, but not limited to:

* creating, editing, moving, or deleting files;
* starting or terminating processes;
* installing or removing software;
* changing system configuration;
* executing shell commands;
* using elevated or administrative privileges when authorized;
* communicating with remote systems and services;
* using credentials or connection profiles that you provide;
* executing scheduled or unattended tasks;
* making changes to data, systems, repositories, databases, or other resources.

{{brand.display_name}} may perform multiple actions autonomously in attempting to complete a task.

---

## 3. User Responsibility

You are responsible for determining whether a requested action is appropriate for the systems and data involved.

You are responsible for:

* maintaining appropriate backups;
* reviewing and configuring {{brand.display_name}} permissions appropriately;
* protecting credentials and access to systems;
* ensuring you are authorized to access or modify connected systems and data;
* verifying important results when appropriate;
* understanding that automated actions may have unintended consequences.

You should maintain current backups of important data before allowing automated tools to modify that data.

---

## 4. Automation and Data-Loss Risk

Automation involves inherent risk.

Commands, system changes, software installation, file operations, database operations, remote execution, or other automated actions may result in:

* deletion or corruption of data;
* interruption of services;
* software or configuration changes;
* loss of availability;
* unintended system behavior;
* security consequences;
* financial or operational loss;
* irreversible changes.

{{brand.display_name}} includes safety controls intended to reduce these risks, but no safety system can guarantee that every requested or generated action will be correct or harmless.

You acknowledge and accept the risks associated with allowing an autonomous agent to operate on your systems.

---

## 5. No Warranty

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, {{brand.display_name}} IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED.

No representation or warranty is made that {{brand.display_name}} will:

* operate without interruption or error;
* correctly interpret every request;
* produce correct results;
* avoid unintended changes;
* preserve all data;
* identify every security or operational risk;
* successfully recover from every failure.

---

## 6. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, {{brand.display_name}}, ITS AUTHORS, CONTRIBUTORS, MAINTAINERS, AND DISTRIBUTORS SHALL NOT BE LIABLE FOR DATA LOSS, DATA CORRUPTION, SYSTEM DAMAGE, SERVICE INTERRUPTION, LOSS OF PROFITS, LOSS OF BUSINESS, SECURITY INCIDENTS, OR OTHER DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR SIMILAR DAMAGES ARISING FROM OR RELATED TO THE USE OF {{brand.display_name}}.

Some jurisdictions do not permit certain warranty exclusions or limitations of liability. In those jurisdictions, these provisions apply only to the maximum extent permitted by law.

---

## 7. Third-Party Systems and Services

{{brand.display_name}} may interact with third-party software, services, APIs, operating systems, networks, databases, and other resources.

{{brand.display_name}} does not control those third-party systems and does not guarantee their availability, behavior, compatibility, security, or accuracy.

You remain responsible for complying with the terms, policies, and authorization requirements of third-party systems you connect to {{brand.display_name}}.

---

## 8. Security and Credentials

{{brand.display_name}} may use credentials, keys, tokens, or other authentication mechanisms that you provide or configure.

You are responsible for ensuring that:

* credentials are authorized for their intended use;
* permissions are appropriately limited;
* connected systems are adequately protected;
* access to {{brand.display_name}} itself is appropriately secured.

---

## 9. Scheduled and Unattended Execution

{{brand.display_name}} may execute tasks without active user supervision when scheduling or unattended execution is enabled.

You acknowledge that scheduled automation can modify systems or data even when you are not actively monitoring the application.

You are responsible for reviewing scheduled tasks and their permissions.

---

## 10. Software License

The proprietary portions of this distribution are licensed under the {{brand.display_name}} Proprietary Software License included in LICENSE. Subject to that license and any separate written agreement with the rights holder, you may install and run the object-code application for your authorized use and retain reasonable backup copies. No right to redistribute, sublicense, publish, or create derivative works of proprietary portions is granted by this agreement.

Earlier Apache License 2.0 grants and other valid earlier licenses remain effective for the material to which they apply. This agreement does not revoke those grants or relicense third-party components. Each separately identified third-party component remains subject to its own license and notices, including applicable source-availability obligations.

You may replace and modify third-party libraries, and reverse engineer portions as necessary to debug those modifications, to the extent required by their licenses, including the LGPL. Mandatory statutory rights are unaffected. A compatible customer-managed Python environment may be selected through --use-runtime.

---

## 11. Changes to These Terms

{{brand.display_name}} may require acceptance of an updated agreement when material terms change.

The application will not treat mere continued use as acceptance when explicit re-acceptance is required.

---

## 12. Agreement

By selecting "I Agree," you acknowledge that:

```text
you understand {{brand.display_name}} can autonomously perform real actions;

those actions can modify or destroy data or system state;

you are responsible for maintaining appropriate backups
and configuring permissions appropriately;

and you accept the risks associated with using an automation agent.
```
