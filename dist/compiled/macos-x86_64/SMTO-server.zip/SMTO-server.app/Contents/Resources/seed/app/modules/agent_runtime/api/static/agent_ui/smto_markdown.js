/* Shared Agent/Notification Markdown. All source HTML is escaped; only renderer-owned
 * markup and safeHref-approved links reach the DOM. Keep this policy common to both. */
(() => {
  "use strict";
  const renderings = new WeakMap();
  function track(target, source, renderer = render) {
    target.dataset.artifactMarkdown = 'true';
    renderings.set(target, {source: String(source || ''), renderer});
  }
  function project(root, projection) {
    if (!projection || typeof projection.content !== 'string') return;
    for (const target of root.querySelectorAll?.('[data-artifact-markdown]') || []) {
      const prior = renderings.get(target);
      if (prior && prior.source === projection.source && prior.source !== projection.content) {
        prior.renderer(target, projection.content);
      }
    }
  }
  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function safeHref(value) {
    const href = String(value || "").trim();
    if (/^https?:\/\//i.test(href)) return href;
    if (/^mailto:/i.test(href)) return href;
    // A temp reference belongs to its source Gateway, never the controller Files route.
    if (/^\/(?:tmp|private\/tmp|var\/folders)(?:\/|$)/i.test(href)
        || /^[a-z]:[\\/]/i.test(href) || /^file:/i.test(href)) return "#";
    if (href.startsWith("#") || href.startsWith("/api/agent/file")) return href;
    if (href.startsWith("/")) return "#";
    if (href && !/^[a-z][a-z0-9+.-]*:/i.test(href)) {
      return `/api/agent/file?path=${encodeURIComponent(href)}`;
    }
    return "#";
  }

  function artifactId(value) {
    return /^artifact:\/\/(art_[a-f0-9]{32})$/.exec(String(value || ""))?.[1] || "";
  }

  function artifactReference(href, label, image = false) {
    const id = artifactId(href);
    if (!id) return `<span>Artifact unavailable · ${escapeHtml(label)}</span>`;
    return `<span class="artifact-reference" data-artifact-id="${id}" data-artifact-label="${escapeHtml(label)}" data-artifact-image="${image}">Artifact unavailable · ${escapeHtml(label)}</span>`;
  }

  function renderInline(value) {
    const tokens = [];
    // Source text cannot forge our internal placeholders. Explicit escapes stay
    // literal, including legacy records whose escaping provenance is unknown.
    let text = String(value || "").replaceAll("\u0000", "\ufffd");
    text = text.replace(/\\[\\`*_[\]{}()#+.!>|-]|`([^`]+)`/g, (match, code) => {
      const token = `\u0000CODE${tokens.length}\u0000`;
      tokens.push(code === undefined ? escapeHtml(match) : `<code>${escapeHtml(code)}</code>`);
      return token;
    });
    text = text.replace(/(!?)\[([^\]\n]*)\]\(<?([^\s)>]+)>?(?:\s+"[^"\n]*")?\)/g, (_match, image, label, rawHref) => {
      const href = safeHref(rawHref);
      const external = /^https?:\/\//i.test(href) ? ' target="_blank" rel="noopener noreferrer"' : "";
      const token = `\u0000LINK${tokens.length}\u0000`;
      const labelHtml = escapeHtml(label).replace(/\u0000CODE(\d+)\u0000/g,
        (_match, index) => tokens[Number(index)] || "");
      if (rawHref.startsWith("artifact:")) {
        const plainLabel = label.replace(/\u0000CODE(\d+)\u0000/g,
          (_match, index) => tokens[Number(index)].replace(/<[^>]+>/g, ""));
        tokens.push(artifactReference(rawHref, plainLabel, Boolean(image)));
      } else if (image) {
        // Filesystem paths and arbitrary browser URLs never become image sources.
        tokens.push(`<span>${labelHtml}</span>`);
      } else {
        tokens.push(`<a href="${escapeHtml(href)}"${external}>${labelHtml}</a>`);
      }
      return token;
    });
    text = escapeHtml(text)
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/__([^_]+)__/g, "<strong>$1</strong>")
      .replace(/(^|[\s(])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    return text.replace(/\u0000(?:CODE|LINK)(\d+)\u0000/g, (_match, index) => tokens[Number(index)] || "");
  }

  function isBlockStart(lines, index) {
    const line = lines[index] || "";
    const next = lines[index + 1] || "";
    return !line.trim()
      || /^```/.test(line.trim())
      || /^#{1,4}\s+/.test(line)
      || /^>\s?/.test(line)
      || /^\s*[-*+]\s+/.test(line)
      || /^\s*\d+[.)]\s+/.test(line)
      || /^\s*(?:---+|\*\*\*+)\s*$/.test(line)
      || (line.includes("|") && /^\s*\|?\s*:?-{3,}/.test(next));
  }

  function markdownToHtml(markdown, depth = 0) {
    // Bound recursive blockquotes in untrusted content; preserve excess as text.
    if (depth >= 32) return `<p>${escapeHtml(markdown)}</p>`;
    const lines = String(markdown || "").replace(/\r\n?/g, "\n").split("\n");
    const output = [];
    let index = 0;
    while (index < lines.length) {
      const raw = lines[index];
      const line = raw.trimEnd();
      if (!line.trim()) {
        index += 1;
        continue;
      }
      const fence = line.trim().match(/^```\s*([\w.+-]*)\s*$/);
      if (fence) {
        const code = [];
        index += 1;
        while (index < lines.length && !/^```\s*$/.test(lines[index].trim())) {
          code.push(lines[index]);
          index += 1;
        }
        if (index < lines.length) index += 1;
        const language = fence[1] ? ` data-language="${escapeHtml(fence[1])}"` : "";
        output.push(`<pre${language}><code>${escapeHtml(code.join("\n"))}</code></pre>`);
        continue;
      }
      const heading = line.match(/^(#{1,4})\s+(.+)$/);
      if (heading) {
        const level = heading[1].length;
        output.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
        index += 1;
        continue;
      }
      if (/^\s*(?:---+|\*\*\*+)\s*$/.test(line)) {
        output.push("<hr>");
        index += 1;
        continue;
      }
      if (/^>\s?/.test(line)) {
        const quote = [];
        while (index < lines.length && /^>\s?/.test(lines[index])) {
          quote.push(lines[index].replace(/^>\s?/, ""));
          index += 1;
        }
        output.push(`<blockquote>${markdownToHtml(quote.join("\n"), depth + 1)}</blockquote>`);
        continue;
      }
      if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+[.)]\s+/.test(line)) {
        const ordered = /^\s*\d+[.)]\s+/.test(line);
        const pattern = ordered ? /^\s*\d+[.)]\s+(.+)$/ : /^\s*[-*+]\s+(.+)$/;
        const items = [];
        while (index < lines.length) {
          const match = lines[index].match(pattern);
          if (!match) break;
          items.push(`<li>${renderInline(match[1])}</li>`);
          index += 1;
        }
        const tag = ordered ? "ol" : "ul";
        output.push(`<${tag}>${items.join("")}</${tag}>`);
        continue;
      }
      if (line.includes("|") && /^\s*\|?\s*:?-{3,}/.test(lines[index + 1] || "")) {
        const cells = (row) => row.replace(/^\s*\||\|\s*$/g, "").split("|").map((cell) => cell.trim());
        const headers = cells(line);
        index += 2;
        const rows = [];
        while (index < lines.length && lines[index].includes("|") && lines[index].trim()) {
          rows.push(cells(lines[index]));
          index += 1;
        }
        output.push(`<table><thead><tr>${headers.map((cell) => `<th>${renderInline(cell)}</th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${row.map((cell) => `<td>${renderInline(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>`);
        continue;
      }
      const paragraph = [line.trim()];
      index += 1;
      while (index < lines.length && !isBlockStart(lines, index)) {
        paragraph.push(lines[index].trim());
        index += 1;
      }
      output.push(`<p>${renderInline(paragraph.join("\n")).replaceAll("\n", "<br>")}</p>`);
    }
    return output.join("");
  }

  function render(target, markdown) {
    track(target, markdown);
    const restore = window.SMTOArtifacts?.capture(target);
    target.innerHTML = markdownToHtml(markdown);
    restore?.();
    window.SMTOArtifacts?.hydrate(target);
  }

  function toText(markdown, {limit = 240} = {}) {
    // Parse with the same safe renderer in an inert fragment, then preserve word
    // boundaries between blocks/cells. Never strip Markdown with a second parser.
    const template = document.createElement("template");
    render(template, markdown);
    const blocks = new Set(["P", "H1", "H2", "H3", "H4", "LI", "PRE", "BLOCKQUOTE", "TR", "TH", "TD", "HR", "BR"]);
    function textOf(node) {
      if (node.nodeType === Node.TEXT_NODE) return node.textContent;
      const text = Array.from(node.childNodes, textOf).join("");
      return blocks.has(node.nodeName) ? " " + text + " " : text;
    }
    const text = textOf(template.content).replace(/\s+/g, " ").trim();
    // Truncate the plain presentation, never the Markdown document or a surrogate pair.
    const chars = Array.from(text);
    return chars.length > limit ? chars.slice(0, limit - 1).join("") + "…" : text;
  }

  window.SMTOMarkdown = Object.freeze({render, toText, artifactId, artifactReference, track, project});
})();
