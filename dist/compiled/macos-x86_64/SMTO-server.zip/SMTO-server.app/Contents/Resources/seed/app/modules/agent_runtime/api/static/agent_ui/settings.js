(() => {
  "use strict";

  const Core = window.SMTOAgentUi;
  const session = window.SMTOUiSession;
  const purgeKeys = ["conversation_auto_purge_enabled", "conversation_auto_purge_days"];
  const purgeDaysKey = purgeKeys[1];

  const elements = {
    boot: document.querySelector("#app-boot-screen"),
    search: document.querySelector("#settings-search"),
    refresh: document.querySelector("#settings-refresh-button"),
    status: document.querySelector("#settings-sync-status"),
    scope: document.querySelector("#settings-scope-summary"),
    nav: document.querySelector("#settings-section-nav"),
    sections: document.querySelector("#settings-sections"),
    version: document.querySelector("#settings-registry-version"),
  };

  // Chromium can leave a partially visible horizontal nav link unscrolled on
  // Tab. Explicit nearest alignment honors the CSS focus gutter in that case.
  elements.nav.addEventListener("focusin", event => {
    if (elements.nav.scrollWidth > elements.nav.clientWidth && event.target.matches("a")) {
      event.target.scrollIntoView({block: "nearest", inline: "nearest"});
    }
  });

  const state = {
    registry: null,
    defaults: {},
    settings: {},
    runtimeControls: {},
    settingDefinitions: new Map(),
    saveTimer: null,
    dirtyKeys: new Set(),
    invalidKeys: new Set(),
    saving: false,
    lastSignature: "",
    pendingRemoteSync: false,
    syncing: false,
    loading: true,
    editVersion: 0,
    backendUnavailable: false,
    runtimeUnavailable: false,
    gatewayManager: null,
    policyEditors: [],
    searching: false,
  };

  function isPlainObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function hasOwn(object, key) {
    return Object.prototype.hasOwnProperty.call(object || {}, key);
  }

  function compactText(value, fallback = "") {
    const text = String(value ?? "").replace(/\s+/g, " ").trim();
    return text || fallback;
  }

  function clampNumber(value, min, max, fallback) {
    const number = Number(value);
    const safe = Number.isFinite(number) ? number : fallback;
    return Math.min(max, Math.max(min, safe));
  }

  function settingSignature(settings) {
    try {
      return JSON.stringify(settings);
    } catch (_error) {
      return "";
    }
  }

  function setStatus(message, status = "saved") {
    if (!elements.status) return;
    elements.status.dataset.state = status;
    elements.status.textContent = message;
    document.querySelector("#settings-retry-button").hidden = status !== "error" || !state.dirtyKeys.size;
  }

  function notifyUiError(title, message, fix = "") {
    Core?.notifyUiError?.({ title, message, fix });
  }

  function finishBoot() {
    document.documentElement.classList.remove("app-booting");
    if (elements.boot) {
      elements.boot.hidden = true;
    }
  }

  async function apiJson(path, options = {}) {
    if (!Core?.apiJson) {
      throw window.SMTOErrors.error("ui_shared_component_unavailable");
    }
    return Core.apiJson(path, options);
  }

  function collectSettingDefinitions(registry) {
    state.settingDefinitions.clear();
    for (const section of registry?.sections || []) {
      for (const setting of section.settings || []) {
        state.settingDefinitions.set(setting.key, setting);
      }
    }
  }

  function optionValues(definition) {
    return new Set((definition.options || []).map((item) => String(item.value)));
  }

  function normalizeValue(value, definition) {
    if (!definition) return value;
    if (definition.key === "task_context_read_policy") return isPlainObject(value) ? value : {schema_version: 1, default_characters_per_read: 4000, max_characters_per_read: 12000};
    if (definition.key === "context_carry_forward") return isPlainObject(value) ? value : {mode: "all"};
    if (definition.key === "ui_font_family") return window.SMTOAppearance.normalizeFamily(value);
    if (definition.control === "json") return structuredClone(value ?? {});
    if (definition.control === "boolean") {
      return value === true;
    }
    if (definition.control === "number") {
      const limit = definition.limit || {};
      const fallback = Number(definition.default ?? 0);
      const min = Number.isFinite(Number(limit.min)) ? Number(limit.min) : Number.NEGATIVE_INFINITY;
      const max = Number.isFinite(Number(limit.max)) ? Number(limit.max) : Number.POSITIVE_INFINITY;
      const number = Number(value);
      if (!Number.isFinite(number)) return fallback;
      return clampNumber(number, min, max, fallback);
    }
    if (definition.control === "select") {
      if (definition.key === "max_foreground_execution_seconds") return Number(value ?? definition.default);
      const candidate = String(value ?? definition.default ?? "").trim();
      const values = optionValues(definition);
      if (values.has(candidate)) return candidate;
      const fallback = String(definition.default ?? "").trim();
      return values.has(fallback) ? fallback : [...values][0] || fallback;
    }
    return String(value ?? definition.default ?? "").trim();
  }

  function normalizeSettings(input = {}) {
    const source = isPlainObject(input) ? input : {};
    const normalized = {};
    for (const [key, definition] of state.settingDefinitions.entries()) {
      const raw = hasOwn(source, key) ? source[key] : definition.default;
      normalized[key] = normalizeValue(raw, definition);
    }
    return normalized;
  }

  function currentValue(definition) {
    return state.settings[definition.key];
  }

  function applyTheme(themeOrSettings) {
    const settings = isPlainObject(themeOrSettings)
      ? { ...state.settings, ...themeOrSettings }
      : { ...state.settings, ui_theme: themeOrSettings || state.settings.ui_theme };
    Core.applyAgentAppearance(settings);
  }

  function definitionTargetsRuntime(definition) {
    return definition?.target === "runtime";
  }

  function runtimePayloadForKeys(keys) {
    const body = {};
    for (const key of keys) {
      const definition = state.settingDefinitions.get(key);
      if (!definitionTargetsRuntime(definition)) continue;
      body[key] = normalizeValue(state.settings[key], definition);
    }
    return body;
  }

  async function saveNow() {
    if (state.saving) return;
    if (state.saveTimer) {
      window.clearTimeout(state.saveTimer);
      state.saveTimer = null;
    }
    const keys = [...state.dirtyKeys];
    if (!keys.length) return;
    if (state.invalidKeys.size) {
      setStatus("Enter a positive whole number of days before saving Auto-purge.", "error");
      return;
    }
    if (keys.some(key => purgeKeys.includes(key))) {
      for (const key of purgeKeys) if (!keys.includes(key)) keys.push(key);
    }
    if (state.modelConfiguration?.hasErrors()) {
      setStatus("Model Configuration has invalid values. Correct them before saving.", "error");
      return;
    }
    state.dirtyKeys.clear();
    state.saving = true;
    let saved = false;
    setStatus("Saving shared settings...", "saving");

    try {
      if (keys.includes("automatic_capability_selection")) {
        const effective = await apiJson("/capabilities/effective");
        const scope = effective.scopes.global;
        await apiJson(`/capabilities/settings/global?expected_revision=${scope.revision}`, {
          method: "PUT", body: {policy: scope.policy,
            selection: {...effective.at_scope.global.selection, mode: state.settings.automatic_capability_selection ? "automatic" : "manual"}},
        });
      }
      if (keys.some((key) => state.settingDefinitions.get(key)?.target === "ui")) {
        const settings = Object.fromEntries(keys
          .filter((key) => state.settingDefinitions.get(key)?.target === "ui")
          .map((key) => [key, state.settings[key]]));
        const savedPreferences = await Core.writeSettingsBackendPreferences({ settings });
        window.SMTOBranding.apply(savedPreferences.settings);
      }
      const runtimePayload = runtimePayloadForKeys(keys);
      if (Object.keys(runtimePayload).length) {
        state.runtimeControls = await apiJson("/runtime-controls", {
          method: "POST",
          body: runtimePayload,
        });
        for (const [key, value] of Object.entries(state.runtimeControls)) {
          const definition = state.settingDefinitions.get(key);
          if (!definition || state.dirtyKeys.has(key)) continue;
          state.settings[key] = normalizeValue(value, definition);
          renderControlValue(key);
        }
        state.runtimeUnavailable = false;
      }
      state.lastSignature = settingSignature(state.settings);
      if (state.modelConfiguration?.hasErrors()) {
        setStatus("Model Configuration has invalid values. Correct them before saving.", "error");
      } else {
        setStatus("Saved shared settings.", "saved");
      }
      void refreshModelConfigurationMetadata();
      updateScopeSummary();
      saved = true;
    } catch (error) {
      for (const key of keys) state.dirtyKeys.add(key);
      const message = compactText(error?.message, "unknown error");
      setStatus(`Autosave failed: ${message}`, "error");
      notifyUiError(
        "Settings autosave failed",
        message,
        "Check the backend connection, then press Retry save.",
      );
    } finally {
      state.saving = false;
      // A second edit's debounce may have elapsed during this save.
      if (saved && state.dirtyKeys.size) void saveNow();
      else if (!state.dirtyKeys.size && state.pendingRemoteSync) void syncFromBackend();
    }
  }

  function scheduleAutosave(key) {
    state.dirtyKeys.add(key);
    setStatus("Autosave pending...", "saving");
    if (state.saveTimer) window.clearTimeout(state.saveTimer);
    state.saveTimer = window.setTimeout(() => {
      void saveNow();
    }, 350);
  }

  function setSettingValue(key, value) {
    const definition = state.settingDefinitions.get(key);
    if (!definition) return;
    if (key === purgeDaysKey && !validatePurgeDays(value)) return;
    state.editVersion += 1;
    state.settings[key] = normalizeValue(value, definition);
    if (key === "ui_theme" || key === "ui_theme_mode") {
      window.SMTOUiSession.set("theme", key === "ui_theme" ? state.settings.ui_theme : undefined);
      applyTheme(state.settings);
      if (key === "ui_theme_mode") {
        renderControlValue("ui_theme");
      }
    }
    renderControlValue(key);

    if (["ui_thinking_animation", "ui_activity_update_animation", "ui_font_family", "ui_font_scale_percent", "ui_high_contrast"].includes(key)) applyTheme(state.settings);
    scheduleAutosave(key);
    if (key === "unsafe_action_policy") void saveNow();
  }

  function controlSelector(key) {
    return `[data-setting-control="${CSS.escape(key)}"]`;
  }

  function validatePurgeDays(value) {
    const valid = String(value).trim() !== "" && Number.isSafeInteger(Number(value)) && Number(value) >= 1;
    const control = document.querySelector(controlSelector(purgeDaysKey));
    const message = valid ? "" : "Enter a positive whole number of days.";
    control?.setCustomValidity(message);
    control?.setAttribute("aria-invalid", String(!valid));
    const error = document.querySelector("#auto-purge-validation");
    if (error) { error.textContent = message; error.hidden = valid; }
    if (valid) state.invalidKeys.delete(purgeDaysKey);
    else {
      state.invalidKeys.add(purgeDaysKey); state.dirtyKeys.add(purgeDaysKey);
      state.editVersion += 1; setStatus(message, "error");
    }
    return valid;
  }

  function renderControlValue(key) {
    if (key.startsWith("llm_execution_") || key.startsWith("llm_budget_growth_") || ["llm_reasoning_budget_percent", "llm_prevent_brain_freeze"].includes(key)) state.modelConfiguration?.refresh();
    const definition = state.settingDefinitions.get(key);
    if (!definition) return;
    const element = document.querySelector(controlSelector(key));
    if (!element) return;
    const value = currentValue(definition);
    if (["ui_font_scale_percent", "ui_font_family"].includes(key)) element.update(value);
    if (key === "task_context_read_policy" && element?.setValue) { element.setValue(value); return; }
    if (key === "context_carry_forward" && element?.setValue) { element.setValue(value); return; }
    if (element instanceof HTMLInputElement && element.type === "checkbox") {
      element.checked = value === true;
    } else if (element instanceof HTMLInputElement || element instanceof HTMLSelectElement) {
      element.value = String(value ?? "");
    }
    if (key === "ui_theme" && element instanceof HTMLSelectElement) {
      element.disabled = Core?.normalizeThemeMode?.(state.settings?.ui_theme_mode) === "auto_day_night";
    }
  }

  function createControl(definition) {
    const value = currentValue(definition);
    if (definition.key === "task_context_read_policy") {
      const root = document.createElement("fieldset");
      root.dataset.settingControl = definition.key;
      root.className = "task-context-read-settings";
      root.id = `setting-${definition.key}`;
      const inputs = {};
      for (const [key, label] of [["default_characters_per_read", "Default characters per read"], ["max_characters_per_read", "Maximum characters per read"]]) {
        const wrapper = document.createElement("label"); wrapper.textContent = label;
        const input = document.createElement("input"); input.type = "number"; input.min = "1"; input.step = "1";
        input.setAttribute("aria-label", label); inputs[key] = input; wrapper.append(input); root.append(wrapper);
        input.addEventListener("change", () => {
          const next = {schema_version: 1};
          for (const [name, element] of Object.entries(inputs)) {
            element.setCustomValidity("");
            if (!element.value || !Number.isSafeInteger(Number(element.value)) || Number(element.value) < 1) {
              element.setCustomValidity("Enter a positive whole number."); element.reportValidity(); return;
            }
            next[name] = Number(element.value);
          }
          if (next.default_characters_per_read > next.max_characters_per_read) {
            inputs.default_characters_per_read.setCustomValidity("Default cannot exceed the maximum.");
            inputs.default_characters_per_read.reportValidity(); return;
          }
          setSettingValue(definition.key, next);
        });
      }
      root.setValue = next => { for (const [key, input] of Object.entries(inputs)) { input.value = next[key]; input.setCustomValidity(""); } };
      const reset = document.createElement("button"); reset.type = "button"; reset.textContent = "Restore defaults";
      reset.addEventListener("click", () => { const defaults = {schema_version: 1, default_characters_per_read: 4000, max_characters_per_read: 12000}; root.setValue(defaults); setSettingValue(definition.key, defaults); });
      root.append(reset); root.setValue(value); return root;
    }
    if (definition.key === "context_carry_forward") {
      const control = window.SMTOContextCarryForward.create({value: value || {mode: "all"},
        allowDefault: false, onChange: next => setSettingValue(definition.key, next)});
      control.dataset.settingControl = definition.key;
      control.id = `setting-${definition.key}`;
      return control;
    }

    if (definition.key === "ui_font_family") {
      const picker = window.SMTOAppearance.createFontPicker({value,
        onChange: next => setSettingValue(definition.key, next)});
      picker.select.dataset.settingControl = definition.key;
      picker.select.id = `setting-${definition.key}`;
      picker.select.setAttribute("aria-describedby", `${picker.select.id}-description`);
      return picker;
    }

    if (definition.key === "ui_font_scale_percent") {
      const stepper = window.SMTOAppearance.createStepper({value,
        onChange: next => setSettingValue(definition.key, next)});
      stepper.dataset.settingControl = definition.key;
      stepper.id = `setting-${definition.key}`;
      stepper.setAttribute("aria-describedby", `${stepper.id}-description`);
      return stepper;
    }

    let control;
    if (definition.control === "boolean") {
      control = document.createElement("input");
      control.type = "checkbox";
      control.className = "mission-switch";
      // Native checked state supplies the switch's accessible on/off state.
      control.setAttribute("role", "switch");
      control.checked = value === true;
    } else if (definition.control === "select") {
      control = document.createElement("select");
      for (const option of definition.options || []) {
        const item = document.createElement("option");
        item.value = String(option.value);
        item.hidden = option.hidden === true;
        item.disabled = option.hidden === true;
        window.SMTOAgentUi.bindBrandCopy(item, option.label || option.value);
        control.append(item);
      }
      control.value = String(value ?? "");
    } else if (definition.control === "number") {
      control = document.createElement("input");
      control.type = "number";
      const limit = definition.limit || {};
      if (limit.min !== undefined) control.min = String(limit.min);
      if (limit.max !== undefined) control.max = String(limit.max);
      control.step = String(definition.step || 1);
      control.value = String(value ?? "");
    } else {
      control = document.createElement("input");
      control.type = "text";
      control.value = String(value ?? "");
      control.spellcheck = false;
      control.autocomplete = "off";
      if (definition.limit?.max_length !== undefined) control.maxLength = definition.limit.max_length;
      if (definition.placeholder) control.placeholder = definition.placeholder;
    }
    control.dataset.settingControl = definition.key;
    control.id = `setting-${definition.key}`;
    control.setAttribute("aria-label", definition.label);
    if (definition.description) control.setAttribute("aria-describedby", `${control.id}-description`);
    if (definition.key === purgeDaysKey) {
      control.required = true;
      control.setAttribute("aria-describedby", `${control.id}-description auto-purge-validation`);
      control.addEventListener("input", () => setSettingValue(definition.key, control.value));
    }
    control.addEventListener("change", async () => {
      const nextValue = control instanceof HTMLInputElement && control.type === "checkbox"
        ? control.checked
        : control.value;
      setSettingValue(definition.key, nextValue);
    });
    return control;
  }

  function createSettingRow(definition) {
    const row = document.createElement("article");
    row.className = "mission-setting-row";
    row.dataset.controlType = definition.control;
    row.dataset.settingKey = definition.key;
    row.dataset.settingSearch = [
      definition.label,
      definition.key,
      definition.description,
    ].join(" ").toLowerCase();

    const copy = document.createElement("div");
    copy.className = "mission-setting-copy";
    const heading = document.createElement("div");
    heading.className = "mission-setting-heading";
    const label = document.createElement("label");
    label.className = "mission-setting-label";
    label.htmlFor = `setting-${definition.key}`;
    label.textContent = definition.label;
    heading.append(label);
    copy.append(heading);

    for (const [className, text] of [
      ["mission-setting-description", definition.description],
    ]) {
      if (!text) continue;
      const paragraph = document.createElement("p");
      paragraph.className = className;
      paragraph.id = `setting-${definition.key}-description`;
      window.SMTOAgentUi.bindBrandCopy(paragraph, text);
      copy.append(paragraph);
    }

    const control = document.createElement("div");
    control.className = "mission-setting-control";
    if (definition.key === "ui_thinking_animation") {
      const preview = window.SMTOThinkingAnimations.create();
      preview.classList.add("thinking-animation-preview");
      control.append(preview);
    }
    control.append(createControl(definition));
    if (definition.key === purgeDaysKey) {
      const error = document.createElement("p");
      error.id = "auto-purge-validation";
      error.className = "mission-setting-description";
      error.setAttribute("role", "alert"); error.hidden = true;
      copy.append(error);
    }
    row.append(copy, control);
    return row;
  }

  function rememberSection(section, open) {
    const expanded = new Set(session.get("settings_open_sections", []));
    if (open) expanded.add(section.id);
    else expanded.delete(section.id);
    session.set("settings_open_sections", [...expanded]);
  }

  function revealSection(hash, remember = false) {
    const section = [...elements.sections.children].find(item => `#${item.id}` === hash);
    if (!section) return;
    if (elements.search.value) {
      elements.search.value = "";
      applySearchFilter();
    }
    section.open = true;
    if (remember) rememberSection(section, true);
    requestAnimationFrame(() => {
      section.scrollIntoView({block: "start"});
      section.querySelector("summary").focus({preventScroll: true});
    });
  }

  // Native summary activation also covers Enter/Space. Remember user choices,
  // not the temporary expansion used by search or initial deep-link navigation.
  elements.sections.addEventListener("click", event => {
    const summary = event.target.closest("summary");
    const section = summary?.parentElement;
    if (!event.defaultPrevented && section?.parentElement === elements.sections
        && section.matches(".mission-settings-section")) {
      rememberSection(section, !section.open);
      // Closing the linked section must stay closed on reload, too.
      if (section.open && location.hash === `#${section.id}`) {
        history.replaceState(history.state, "", location.pathname + location.search);
      }
    }
  });
  elements.nav.addEventListener("click", event => {
    const link = event.target.closest("a");
    if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    if (location.hash === link.hash) revealSection(link.hash, true);
    else location.hash = link.hash;
  });
  window.addEventListener("hashchange", () => revealSection(location.hash, true));

  async function renderSupervision(container) {
    try {
      const response = await fetch("/api/agent/activity-supervision");
      if (!response.ok) throw new Error("Could not load Activity supervision settings");
      let policy = (await response.json()).activity_supervision_policy;
      const help = document.createElement("p");
      help.textContent = "Health inspection checks progress of long-running work. It does not control how quickly normal commands report completion.";
      container.append(help);
      const controls = [];
      for (const [key, title, type, min, max] of [
        ["enabled", "Supervise managed work", "checkbox"],
        ["healthy_observation_seconds", "Normal health inspection interval (seconds)", "number", 1, 60],
        ["attention_after_seconds", "Attention after no progress (seconds)", "number", policy.suspect_after_seconds, 86400],
      ]) {
        const row = document.createElement("label");
        row.className = "mission-setting-row";
        row.dataset.controlType = type === "checkbox" ? "boolean" : "number";
        const text = document.createElement("span");
        text.className = "mission-setting-label";
        text.textContent = title;
        const input = document.createElement("input");
        input.type = type;
        input.dataset.supervision = key;
        input.setAttribute("aria-label", title);
        if (type === "checkbox") {
          input.checked = policy[key]; input.className = "mission-switch"; input.setAttribute("role", "switch");
        }
        else { input.value = policy[key]; input.min = min; input.max = max; input.step = 1; }
        controls.push(input);
        input.addEventListener("change", async () => {
          if (!input.reportValidity()) return;
          const next = {...policy, [key]: type === "checkbox" ? input.checked : Number(input.value)};
          controls.forEach(control => { control.disabled = true; });
          try {
            const saved = await fetch("/api/agent/activity-supervision", {method: "PUT",
              headers: {"Content-Type": "application/json"}, body: JSON.stringify({scope: "global", policy: next})});
            if (!saved.ok) throw new Error("Could not save Activity supervision settings");
            policy = (await saved.json()).activity_supervision_policy;
            setStatus("Activity supervision saved", "success");
          } catch (error) {
            if (type === "checkbox") input.checked = policy[key]; else input.value = policy[key];
            setStatus(error.message, "error");
          } finally { controls.forEach(control => { control.disabled = false; }); }
        });
        const holder = document.createElement("span");
        holder.className = "mission-setting-control";
        holder.append(input);
        row.append(text, holder);
        container.append(row);
      }
      applySearchFilter();
    } catch (error) { setStatus(error.message, "error"); }
  }

  function renderSections() {
    if (!elements.sections || !elements.nav) return;
    for (const editor of state.policyEditors) editor.destroy();
    state.policyEditors = [];
    elements.sections.replaceChildren();
    elements.nav.replaceChildren();
    for (const section of state.registry?.sections || []) {
      const navLink = document.createElement("a");
      navLink.href = `#settings-section-${section.id}`;
      navLink.textContent = section.title;
      elements.nav.append(navLink);

      const details = document.createElement("details");
      details.className = "mission-settings-section";
      details.id = `settings-section-${section.id}`;
      details.dataset.sectionSearch = [
        section.title,
        section.description,
      ].join(" ").toLowerCase();

      const summary = document.createElement("summary");
      summary.className = "mission-settings-section-summary";
      const title = document.createElement("h2");
      title.textContent = section.title;
      summary.append(title);

      const body = document.createElement("div");
      body.className = "mission-section-body";
      for (const text of [section.description]) {
        if (!text) continue;
        const paragraph = document.createElement("p");
        paragraph.className = "mission-section-copy";
        window.SMTOAgentUi.bindBrandCopy(paragraph, text);
        body.append(paragraph);
      }
      const settingGrid = document.createElement("div");
      settingGrid.className = "mission-section-settings";
      if (section.component === "data_transfer") {
        window.SMTODataTransfer.mount(settingGrid, {beforeExport: async () => {
          for (let attempt = 0; state.saving && attempt < 100; attempt++) {
            await new Promise(resolve => window.setTimeout(resolve, 100));
          }
          await saveNow();
          if (state.saving || state.dirtyKeys.size) {
            throw new Error("Wait for your settings to finish saving, then export again.");
          }
        }});
      } else if (section.component === "activity_supervision") {
        void renderSupervision(settingGrid);
      } else if (section.component === "gateway_management") {
        state.gatewayManager ||= window.SMTOGatewayManagement.create({ onChange: applySearchFilter });
        settingGrid.append(state.gatewayManager.element);
      } else if (section.component === "model_configuration") {
        state.modelConfiguration = window.SMTOModelConfiguration.create({
          section, getValues: () => state.settings,
          connectionRows: section.settings.filter(item => !item.key.startsWith("llm_execution_")
            && !item.key.startsWith("llm_budget_growth_")
            && !["llm_reasoning_budget_percent", "llm_recovery_thinking", "llm_prevent_brain_freeze"].includes(item.key)).map(createSettingRow),
          growthRows: section.settings.filter(item => item.key.startsWith("llm_budget_growth_")).map(createSettingRow),
          reasoningRows: section.settings.filter(item => ["llm_reasoning_budget_percent", "llm_recovery_thinking", "llm_prevent_brain_freeze"].includes(item.key)).map(createSettingRow),
          onChange(values) {
            state.editVersion += 1;
            Object.assign(state.settings, structuredClone(values));
            state.modelConfiguration.refresh();
            for (const key of Object.keys(values)) scheduleAutosave(key);
          },
          onError: message => setStatus(message, "error"),
        });
        settingGrid.append(state.modelConfiguration.element);
      } else {
        for (const setting of section.settings || []) {
          settingGrid.append(createSettingRow(setting));
        }
      }
      if (["capability_policy", "permission_policy"].includes(section.component)) {
        state.policyEditors.push(window.SMTOPolicySettings.mount(settingGrid, {
          kind: section.component, onChange: applySearchFilter, onSave: () => void syncFromBackend(),
        }));
      }
      if (section.id === "redaction") {
        for (const [label, enabled] of [["Enable all", true], ["Disable all", false]]) {
          const button = document.createElement("button");
          button.type = "button";
          button.textContent = label;
          button.addEventListener("click", () => {
            for (const setting of section.settings) setSettingValue(setting.key, enabled);
            void saveNow();
          });
          body.append(button);
        }
      }
      body.append(settingGrid);
      details.append(summary, body);
      elements.sections.append(details);
    }
    window.SMTOCompletionSettings.mount(elements.sections, elements.nav, {setStatus, onChange: applySearchFilter});
    window.SMTOFastCache?.mountSettings(elements.sections, elements.nav);
    window.SMTOLegal.mountSettings(elements.sections, elements.nav);
    const about = document.createElement("details");
    about.id = "settings-section-about";
    about.className = "mission-settings-section";
    about.dataset.sectionSearch = "about product version " + window.SMTOBranding.displayName().toLowerCase();
    const summary = document.createElement("summary");
    summary.className = "mission-settings-section-summary";
    const heading = document.createElement("h2"); heading.textContent = "About";
    summary.append(heading);
    const body = document.createElement("div"); body.className = "mission-section-body mission-setting-row";
    for (const [tag, value] of [["h3", window.SMTOBranding.displayName()], ["p", window.__BRANDING__.tagline]]) {
      const text = document.createElement(tag); text.textContent = value;
      if (tag === "h3") text.dataset.brandDisplayName = "";
      body.append(text);
    }
    const version = document.createElement("p"); body.append(version);
    fetch("/api/agent/version").then(response => response.json()).then(data => {
      if (data.version) version.textContent = `Version: ${data.version}`;
    }).catch(() => {});
    about.append(summary, body); elements.sections.append(about);
    const link = document.createElement("a"); link.href = "#" + about.id; link.textContent = "About";
    elements.nav.append(link);
    const expanded = new Set(session.get("settings_open_sections", []));
    for (const section of elements.sections.children) section.open = expanded.has(section.id);
    focusErrorSetting();
  }

  /** Resolve a semantic catalog target only after the server-owned registry is rendered. */
  function focusErrorSetting() {
    const query = new URLSearchParams(location.search);
    const sectionId = query.get("section");
    if (!sectionId) return;
    const section = state.registry?.sections.find(item => item.id === sectionId);
    const requestedKey = query.get("setting");
    const key = requestedKey === "full_tool_results" ? "tool_result_delivery_mode" : requestedKey;
    const parameter = query.get("parameter"), action = query.get("action");
    const valid = section && (!key || section.settings?.some(item => item.key === key))
      && (!parameter || section.parameters?.some(item => item.key === parameter))
      && (!action || section.actions?.includes(action))
      && [key, parameter, action].filter(Boolean).length <= 1;
    if (!valid) {
      setStatus("", "error");
      window.SMTOErrors.present(elements.status, window.SMTOErrors.error("ui_setting_target_missing"));
      return;
    }
    const panel = [...elements.sections.children].find(item => item.id === `settings-section-${section.id}`);
    if (!panel) return;
    panel.hidden = false; panel.open = true;
    const target = key ? [...panel.querySelectorAll("[data-setting-control]")].find(item => item.dataset.settingControl === key)
      : parameter ? [...panel.querySelectorAll("[data-parameter-key]")].find(item => item.dataset.parameterKey === parameter)?.querySelector("input, select, textarea")
      : action ? [...panel.querySelectorAll("[data-component-action]")].find(item => item.dataset.componentAction === action) || panel.querySelector("summary")
      : panel.querySelector("summary");
    if (target) {
      target.closest(".mission-setting-row")?.classList.add("error-setting-focus");
      requestAnimationFrame(() => { target.scrollIntoView({block: "center"}); target.focus({preventScroll: true}); });
    }
  }

  function updateScopeSummary() {
    if (!elements.scope) return;
    const editableCount = state.settingDefinitions.size;
    const runtimeCount = [...state.settingDefinitions.values()].filter(definitionTargetsRuntime).length;
    elements.scope.textContent = `${editableCount} editable settings, ${runtimeCount} live runtime controls`;
  }

  function applySearchFilter() {
    const query = compactText(elements.search?.value || "").toLowerCase();
    const expanded = new Set(session.get("settings_open_sections", []));
    for (const section of document.querySelectorAll(".mission-settings-section")) {
      let visibleRows = 0;
      for (const row of section.querySelectorAll(".mission-setting-row, .gateway-card, .agent-check-row, .resource-locking-row")) {
        const text = `${row.dataset.settingSearch || ""} ${section.dataset.sectionSearch || ""} ${row.textContent.toLowerCase()}`;
        const visible = !query || text.includes(query);
        row.hidden = !visible;
        if (visible) visibleRows += 1;
        if (visible && query) {
          const additional = row.closest(".resource-locking-additional");
          if (additional) additional.open = true;
        }
      }
      for (const heading of section.querySelectorAll(".agent-check-panel h4")) {
        let visible = false;
        for (let row = heading.nextElementSibling; row?.matches(".agent-check-row"); row = row.nextElementSibling) {
          if (!row.hidden) { visible = true; break; }
        }
        heading.hidden = !visible;
      }
      for (const group of section.querySelectorAll(".model-parameter-group")) {
        group.hidden = !Array.from(group.querySelectorAll(".mission-setting-row")).some(row => !row.hidden);
      }
      const emptyGatewayMatch = section.id === "settings-section-gateways"
        && section.dataset.sectionSearch.includes(query);
      section.hidden = Boolean(query) && visibleRows === 0 && !emptyGatewayMatch;
      if (query && !section.hidden) section.open = true;
      else if (!query && state.searching) section.open = expanded.has(section.id);
    }
    state.searching = Boolean(query);
  }

  async function refreshModelConfigurationMetadata() {
    if (!state.modelConfiguration) return;
    try {
      const registry = await apiJson("/settings/registry");
      const section = registry.sections.find(item => item.component === "model_configuration");
      if (section) state.modelConfiguration.updateMetadata(section.recommendation);
    } catch (_error) { /* Keep the last resolved metadata; ordinary sync owns connectivity status. */ }
  }

  async function loadRegistryAndSettings({ announce = false } = {}) {
    if (announce) setStatus("Refreshing settings...", "saving");
    const registry = await apiJson("/settings/registry");
    state.registry = registry;
    state.defaults = isPlainObject(registry.defaults) ? registry.defaults : {};
    collectSettingDefinitions(registry);

    let preferences = { settings: {} };
    let runtimeControls = {};
    state.backendUnavailable = false;
    state.runtimeUnavailable = false;
    try {
      preferences = await Core.fetchSettingsBackendPreferences();
    } catch (_error) {
      state.backendUnavailable = true;
    }
    try {
      runtimeControls = await apiJson("/runtime-controls");
    } catch (_error) {
      state.runtimeUnavailable = true;
    }
    state.runtimeControls = isPlainObject(runtimeControls) ? runtimeControls : {};
    const backendSettings = isPlainObject(preferences?.settings) ? preferences.settings : {};
    const sourceSettings = backendSettings;
    const merged = normalizeSettings({
      ...state.defaults,
      ...sourceSettings,
    });
    for (const [key, definition] of state.settingDefinitions.entries()) {
      if (!definitionTargetsRuntime(definition)) continue;
      if (hasOwn(state.runtimeControls, key)) {
        merged[key] = normalizeValue(state.runtimeControls[key], definition);
      }
    }
    state.settings = merged;
    const capability = await apiJson("/capabilities/effective");
    state.settings.automatic_capability_selection = capability.at_scope.global.selection.mode === "automatic";
    state.lastSignature = settingSignature(state.settings);

    renderSections();
    applySearchFilter();
    if (state.loading) revealSection(location.hash);

    updateScopeSummary();
    if (elements.version) {
      elements.version.textContent = `Settings schema ${registry.schema_version}`;
    }
    setStatus(
      state.backendUnavailable || state.runtimeUnavailable
        ? "Some settings could not be loaded. Refresh to reconnect."
        : "Shared settings loaded.",
      state.backendUnavailable || state.runtimeUnavailable ? "error" : "saved",
    );
    focusErrorSetting();
    if (state.settings.ui_theme) applyTheme(state.settings);
    // Connection panels own their loading/error messages. They must not hold
    // the entire settings page behind the boot screen.
    void state.gatewayManager?.refresh();
  }

  async function syncFromBackend() {
    state.pendingRemoteSync = true;
    if (state.loading || state.syncing || state.saving || state.dirtyKeys.size || document.hidden) return;
    state.pendingRemoteSync = false;
    state.syncing = true;
    const editVersion = state.editVersion;
    try {
      const [preferences, runtime, capability] = await Promise.all([
        Core.fetchSettingsBackendPreferences(), apiJson("/runtime-controls"), apiJson("/capabilities/effective"),
      ]);
      if (state.saving || state.dirtyKeys.size || state.editVersion !== editVersion) {
        state.pendingRemoteSync = true;
        return;
      }
      state.runtimeControls = runtime;
      void refreshModelConfigurationMetadata();
      state.backendUnavailable = false;
      const remote = isPlainObject(preferences?.settings) ? preferences.settings : {};
      const next = normalizeSettings({ ...state.defaults, ...remote, ...runtime });
      next.automatic_capability_selection = capability.at_scope.global.selection.mode === "automatic";
      const signature = settingSignature(next);
      if (signature && signature !== state.lastSignature) {
        state.settings = next;
        state.lastSignature = signature;
        for (const key of state.settingDefinitions.keys()) renderControlValue(key);
        applyTheme(state.settings);

        setStatus("Synced changes from shared backend settings.", "saved");
      }
    } catch (_error) {
      state.backendUnavailable = true;
      setStatus("Shared settings are temporarily unavailable.", "error");
    } finally {
      state.syncing = false;
      if (state.pendingRemoteSync && !state.saving && !state.dirtyKeys.size && !document.hidden) {
        void syncFromBackend();
      }
    }
  }

  async function boot() {
    try {
      await loadRegistryAndSettings();
    } catch (error) {
      setStatus(`Could not load settings: ${compactText(error?.message, "unknown error")}`, "error");
      if (elements.sections) {
        const empty = document.createElement("div");
        empty.className = "mission-settings-empty";
        empty.textContent = "Settings registry could not be loaded.";
        elements.sections.replaceChildren(empty);
      }
    } finally {
      state.loading = false;
      finishBoot();
      if (state.pendingRemoteSync) void syncFromBackend();
    }
  }

  elements.search?.addEventListener("input", applySearchFilter);
  document.querySelector("#settings-retry-button").addEventListener("click", () => void saveNow());
  elements.refresh?.addEventListener("click", () => {
    void loadRegistryAndSettings({ announce: true });
  });
  window.addEventListener("focus", () => applyTheme(state.settings));
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      applyTheme(state.settings);
      void syncFromBackend();
    }
  });
  window.addEventListener("online", () => { void syncFromBackend(); });
  window.SMTOUiUpdates.subscribe(
    ["settings.changed", "runtime-controls.changed", "model-config.changed", "capability-policy.changed"], syncFromBackend,
  );

  void boot();
})();
