import "./advanced.js";
/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/lazy/interactions.js
 * @brief Render the phone conversation's existing bound human-interaction controls.
 * @details
 * Responsibilities: Present ordinary questions, OAuth authorization and explicit approvals distinctly.
 * Boundaries: Native checkpoints own wait truth and reply validation; this module does not start tasks.
 * Lifecycle: render projects trace state; Send answer carries observed IDs to clarification/<request>.
 * State: In-flight submissions are page local; reload reconstructs the question from durable trace state.
 * Security: Credentials use ordinary replies; OAuth and approval protocol actions retain their own controls.
 * Collaborators: native_flow.py supplies identities; conversation.js restores traces after navigation.
 * Public surface: render binds one active interaction to its request, Activity and operation.
 * @see src/agent_runtime/api/agent_ui_support/native_flow.py
 */
import "../../resource_reconciliation.js";
import "../../agent_checks.js?v=20261015-smto";
import { decision } from "./completion_handling.js?v=20261015-smto";
import { api, state, node, button, encode, safeUrl, notice } from "../api.js";
import { markdown } from "../markdown.js";

export function render(root, rid, trace, run, hooks) {
  if (root.getAttribute("aria-busy") === "true") return;
  root.replaceChildren();
  const generation = state.generation,
    card = node("section", null, "action-card"),
    error = node("p", null, "error");
  error.setAttribute("role", "status");
  /** Check that the interaction sheet still owns the active conversation. */
  const attached = () => root.isConnected && generation === state.generation;
  const fresh = () => attached() && rid === state.requestId;
  const retained =
    trace.response_metrics?.final_response ||
    trace.native_profile?.final_response;
  window.SMTOAgentChecks.render(root, {...trace, agent_checks: run}, {
    requestId: rid, conversationId: state.conversationId,
    apiJson: (url, options = {}) => api(url.replace("/api/agent/", ""), {
      ...options, ...(options.body ? {body: JSON.parse(options.body)} : {})}),
    reload: () => fresh() && hooks.refresh(),
    onAccepted: result => fresh() && hooks.resumeResponse(result),
  });
  const operation = run?.foreground_operation;
  if (operation?.long_running && !run.cancel_requested) {
    const foreground = node("section", null, "action-card");
    foreground.append(node("h3", "Operation is still running"));
    for (const [action, title] of [
      ["continue", "Keep running"],
      ["terminate", "Terminate operation"],
    ]) {
      if (
        operation.long_running_user_decision === "terminate" ||
        operation.long_running_user_decision === action
      )
        continue;
      foreground.append(
        button(title, async () => {
          if (!fresh()) return;
          await api(
            `native/${encode(rid)}/operations/${encode(operation.operation_id)}/control`,
            { method: "POST", body: { action } },
          );
          if (fresh()) await hooks.refresh();
        }),
      );
    }
    root.append(foreground);
  }
  let busy = false;
  async function send(path, body) {
    if (busy || !fresh()) return;
    busy = true;
    root.setAttribute("aria-busy", "true");
    error.textContent = "";
    const controls = [...card.querySelectorAll("button,input,textarea,select")];
    controls.forEach((c) => {
      c.disabled = true;
    });
    const answered = path.startsWith("clarification/") ? {
      question: trace.clarification_request || {}, cursor: Number(trace.last_event_id || 0),
      generation: trace.created_at,
    } : null;
    let accepted = false;
    try {
      const response = await api(path, { method: "POST", body });
      accepted = true;
      // A grant's child can become current through a snapshot before this reply.
      if (!attached()) return;
      if (response.recovery_refreshed) {
        root.removeAttribute("aria-busy");
        await hooks.refresh();
        return;
      }
      card.replaceChildren(node("p", "Response accepted. Waiting for the task to continue…"));
      root.removeAttribute("aria-busy");
      await hooks.resumeResponse(response, rid, answered);
    } catch (failure) {
      if (accepted) {
        if (attached()) notice("Response accepted. Could not refresh its progress; reconnecting…");
        return;
      }
      if (fresh()) {
        error.textContent = failure.message;
        notice(failure);
        if (failure.status === 409) void Promise.resolve().then(() => hooks.refresh()).catch(notice);
      }
    } finally {
      busy = false;
      // Resuming can mount the next question before this handler settles.
      if (card.parentElement === root) root.removeAttribute("aria-busy");
      if (fresh() && card.contains(error))
        controls.forEach((c) => {
          c.disabled = false;
        });
    }
  }
  const oauth = run?.oauth_authorization_request;
  if (oauth?.kind === "oauth" && run.status === "waiting_user" && oauth.request_id === rid) {
    root.append(card);
    card.append(node("h3", "Complete OAuth authorization"));
    const url = safeUrl(oauth.authorization_url || oauth.verification_uri || "");
    if (url) {
      const link = node("a", "Open authorization page");
      link.href = url; link.target = "_blank"; link.rel = "noopener noreferrer";
      card.append(link);
    }
    if (oauth.user_code) card.append(node("p", `Device code: ${oauth.user_code}`));
    const stop = button("Cancel task", () => hooks.control("cancel"));
    stop.disabled = run.cancel_requested === true;
    card.append(stop);
    return;
  }
  if (run?.resource_reconciliation_request) return;
  const unsafe = run?.unsafe_action_request;
  if (unsafe) {
    root.append(card);
    card.append(
      node("h3", "Confirm consequential action"),
      node("p", unsafe.target || "Current task target", "muted"),
      node(
        "p",
        unsafe.warning ||
          unsafe.description ||
          unsafe.summary ||
          "Review this action before continuing.",
      ),
      node(
        "pre",
        JSON.stringify(unsafe.invocations || unsafe.arguments || {}, null, 2),
      ),
    );
    card.append(
      error,
      button("Cancel action", () =>
        send(`native/${encode(rid)}/unsafe-action`, {
          action: "cancel",
          challenge_id: unsafe.challenge_id,
          ...(unsafe.authority_request_id ? {authority_request_id: unsafe.authority_request_id} : {}),
        }),
      ),
      button(
        "Confirm action",
        () => {
          const payload = {
            action: "confirm",
            challenge_id: unsafe.challenge_id,
            ...(unsafe.authority_request_id ? {authority_request_id: unsafe.authority_request_id} : {}),
          };
          return send(`native/${encode(rid)}/unsafe-action`, payload);
        },
        "primary",
      ),
    );
    const confirm = card.querySelector("button.primary");
    if (!unsafe.valid || unsafe.accepted) {
      confirm.disabled = true;
      error.textContent = unsafe.accepted
        ? "Authorization accepted. Waiting for the action to resume…"
        : "This authorization has expired or was revoked. Cancel and request the action again.";
    } else if (Number.isFinite(unsafe.expires_at)) {
      setTimeout(
        () => {
          if (!card.isConnected) return;
          confirm.disabled = true;
          error.textContent =
            "This authorization expired. Cancel and request the action again.";
        },
        Math.max(0, unsafe.expires_at * 1000 - Date.now()),
      );
    }
    return;
  }
  if (trace.confirmation_required) {
    const authorityId = trace.confirmation_actions?.[0]?.authority_request_id
      || (run?.authority_request?.kind === "permission" ? run.authority_request.authority_request_id : null);
    const authorityFields = authorityId ? {authority_request_id: authorityId} : {};
    root.append(card);
    card.append(node("h3", "Approval required"));
    for (const action of trace.confirmation_actions || []) {
      const d = action.display || {};
      card.append(
        node(
          "p",
          [action.capability_id, d.title, d.summary]
            .filter(Boolean)
            .join(" · "),
        ),
      );
    }
    card.append(node("p", "Scope: this action", "muted"), error);
    card.append(
      button("Deny / stop task", () =>
        send(`confirmation/${encode(rid)}`, { action: "deny", context: {}, ...authorityFields }),
      ),
      button(
        "Allow once",
        () =>
          send(`confirmation/${encode(rid)}`, {
            action: "approve",
            context: {},
            ...authorityFields,
          }),
        "primary",
      ),
    );
    const grants = (trace.confirmation_actions || []).flatMap(
      (action) => action.permission_grants || [],
    );
    if (grants.length) {
      const details = node("details");
      details.append(node("summary", "More permission choices"));
      for (const grant of grants)
        details.append(
          button(grant.label, () =>
            send(`confirmation/${encode(rid)}`, {
              action: "approve",
              context: {},
              ...authorityFields,
              grant: { scope: grant.scope, rule: grant.rule, expected_revision: grant.expected_revision },
            }),
          ),
        );
      card.append(details);
    }
    return;
  }
  if (trace.clarification_required) {
    root.append(card);
    const request = trace.clarification_request || {};
    const question = node("div", null, "clarification-question markdown");
    // Keep the source for duplicate matching after Markdown has changed the rendered text.
    question.dataset.questionSource = String(request.question || request.missing_information || "What should I use to continue?");
    markdown(question, question.dataset.questionSource);
    question.hidden = hooks.conversationQuestions?.has(question.dataset.questionSource.trim()) || false;
    card.append(node("h3", "I need your input"), question, error);
    const answer = async (payload) => {
      await send(`clarification/${encode(rid)}`, { ...payload, context: {},
        ...(request.activity_id ? {activity_id: request.activity_id} : {}),
        ...(request.operation_id ? {operation_id: request.operation_id} : {}),
        ...(request.authority_request_id ? {
          authority_request_id: request.authority_request_id,
          ...(["allow", "deny"].includes(payload.selected_option_id)
            ? {authority_decision: payload.selected_option_id} : {}),
        } : request.capability_grant_request_id ? {
          capability_grant_request_id: request.capability_grant_request_id,
          ...(["allow", "deny"].includes(payload.selected_option_id)
            ? {capability_decision: payload.selected_option_id} : {}),
        } : {}),
      });
    };
    for (const [index, option] of (request.options || []).entries())
      card.append(
        button(
          (option.label || option.title || option.value || option.option_id)
            + (request.recommended_id === option.option_id ? " (Recommended)" : "")
            + (option.description ? " — " + option.description : ""),
          () =>
            answer({
              answer: String(
                option.value ||
                  option.label ||
                  option.title ||
                  option.option_id,
              ),
              selected_option_id: String(option.option_id || index),
            }),
        ),
      );
    if (request.allow_freeform !== false || !request.options?.length) {
      const label = node("label", request.options?.length ? "Other answer" : "Your answer"),
        input = node("textarea");
      input.rows = 2;
      input.maxLength = 24000;
      label.append(input);
      card.append(
        label,
        button(
          "Send answer",
          () =>
            input.value.trim() ? answer({ answer: input.value }) : null,
          "primary",
        ),
      );
    }
  }
}
