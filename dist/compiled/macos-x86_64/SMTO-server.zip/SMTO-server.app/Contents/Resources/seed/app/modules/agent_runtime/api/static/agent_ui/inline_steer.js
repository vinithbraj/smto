/* Shared steering feedback. Existing snapshot owners report durable application. */
(() => {
  "use strict";
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted", "partial", "blocked"]);
  // Every subconversation keeps an inbox at its latest turn. Execution readiness
  // controls processing, not whether the user can write to that conversation.
  const isEditable = snapshot => Boolean(snapshot && !snapshot.continued_by);
  const isSteerable = snapshot => isEditable(snapshot) && !terminal.has(snapshot.status);
  const canContinue = snapshot => Boolean(snapshot && terminal.has(snapshot.status)
    && !snapshot.continued_by);
  const pending = new Set();
  const progressMarkup = `<svg class="steering-progress" viewBox="0 0 24 12" aria-hidden="true" focusable="false">
    <path d="M-12 6q3-6 6 0t6 0t6 0t6 0t6 0t6 0t6 0t6 0" /></svg><span>Steering conversation…</span>`;
  const gentleLabel = "Steer without interrupting";
  const gentleHint = "Let the current response finish, then apply your update before the next action.";
  const gentleWaiting = "Waiting for the current response to finish…";
  function track(requestId, onChange = () => {}, {cancel, steeringMode = "interrupt"} = {}) {
    let snapshot = null, sequence = null, settled = false, resolve;
    let cancelling = false, cancellable = true, cancelUnconfirmed = false;
    const completion = new Promise(done => { resolve = done; });
    const finish = outcome => {
      if (settled) return;
      settled = true; pending.delete(observer); resolve(outcome);
    };
    const check = () => {
      if (settled || sequence === null || cancelling) return;
      if (cancelUnconfirmed) { onChange(window.SMTOErrors.error("steering_state_invalid").message); return; }
      if (Number(snapshot?.amendment_seq || 0) >= sequence) finish("applied");
      else if (terminal.has(snapshot?.status)) finish("stopped");
      else onChange(["paused", "paused_budget"].includes(snapshot?.status)
        ? "Waiting for resume to steer…" : steeringMode === "after_response"
          ? gentleWaiting : "Finding the next safe point to steer…");
    };
    const observer = {requestId, update(value) { snapshot = value; check(); }};
    pending.add(observer);
    return {
      get canCancel() { return !settled && sequence !== null && cancellable && !cancelling && typeof cancel === "function"; },
      get cancelling() { return cancelling; },
      async requestCancel() {
        if (!this.canCancel) return;
        cancelling = true;
        onChange("Cancelling steer…");
        try {
          const result = await cancel();
          if (result?.status !== "cancelled") throw window.SMTOErrors.error("steering_state_invalid");
          finish("withdrawn");
        } catch (error) {
          cancelUnconfirmed = error.status !== 409;
          if (error.status === 409) {
            cancellable = false;
            throw Object.assign(window.SMTOErrors.error("steering_state_invalid"), {status: 409});
          }
          throw error;
        } finally {
          cancelling = false;
          check();
        }
      },
      accepted(result) {
        steeringMode = result?.steering_mode || steeringMode;
        if (result?.status === "cancelled") {
          finish("withdrawn");
        } else if (!Number.isSafeInteger(result?.amendment_seq) || result.amendment_seq < 1) {
          finish("unconfirmed");
        } else { sequence = result.amendment_seq; check(); }
        return completion;
      },
      cancel() { finish("cancelled"); },
    };
  }
  function observe(requestId, snapshot) {
    for (const observer of pending) if (observer.requestId === requestId) observer.update(snapshot);
  }
  function requireApplied(outcome) {
    if (outcome === "stopped") throw Object.assign(new Error("The run finished while steering was pending. Your text is retained."), {status: 409});
    if (outcome === "unconfirmed") throw new Error("Couldn’t confirm steering. Your text is retained; retry to confirm it safely.");
    return outcome === "applied";
  }

  function create({requestId, submit, cancel, followup, reconcile, onAccepted = () => {}, notify = () => {}}) {
    if (!requestId) throw window.SMTOErrors.error("ui_run_required");
    const root = document.createElement("form");
    root.className = "inline-steer";
    root.dataset.requestId = requestId;
    root.setAttribute("aria-label", `Steer run ${requestId}`);
    root.hidden = true;
    let input, button, gentleButton, cancelButton, listeners, busy = false, available = false, disposed = false, lastStatus = "";
    let continuing = false, steering = null, progress;
    let latestSnapshot = null, followupPreview = null, acceptedContinuation = null;
    const retries = new Map();
    const clearFollowupPreview = () => {
      followupPreview?.remove(); followupPreview = null;
    };
    function showFollowupPreview(text, submissionId, ownedFocus) {
      if (!followupPreview) {
        followupPreview = document.createElement("div");
        followupPreview.className = "followup-submission";
        followupPreview.dataset.parentRequestId = requestId;
        const row = document.createElement("div"); row.className = "user-message-row";
        const message = document.createElement("div"); message.className = "user-message";
        const status = document.createElement("p"); status.className = "submission-status";
        status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
        row.append(message); followupPreview.append(row, status);
        root.before(followupPreview);
      }
      followupPreview.dataset.submissionId = submissionId;
      followupPreview.querySelector(".user-message").textContent = text;
      followupPreview.querySelector(".submission-status").textContent = "Submitting…";
      requestAnimationFrame(() => {
        if (ownedFocus && !disposed && !document.hidden && followupPreview?.isConnected)
          followupPreview.scrollIntoView({block: "nearest", behavior: "instant"});
      });
    }
    const resize = () => {
      input.style.height = "auto";
      input.style.height = `${input.scrollHeight}px`;
    };
    const render = () => {
      root.dataset.state = busy ? "submitting" : available ? "ready" : "hidden";
      root.setAttribute("aria-busy", String(busy));
      root.toggleAttribute("data-steering", Boolean(steering));
      if (button) {
        button.disabled = busy || !available || !input.value.trim();
        button.textContent = continuing ? (retries.has(`steer:${input.value}`) ? "Retry" : "Continue")
          : retries.get(`steer:${input.value}`)?.steeringMode === "after_response" ? "Retry steer without interrupting" : "Steer";
        input.placeholder = continuing ? "Continue this conversation…" : "Steer this run…";
        input.setAttribute("aria-label", continuing ? "Continue this conversation" : "Steer this run");
        input.title = continuing ? "Enter to continue; Shift+Enter for a new line."
          : retries.has(`steer:${input.value}`) ? "Enter to retry the original steer; Shift+Enter for a new line."
          : "Enter to steer without interrupting; Shift+Enter for a new line.";
        input.readOnly = busy;
        input.setAttribute("aria-busy", String(busy));
        progress.hidden = !steering;
        button.hidden = Boolean(steering && cancel);
        gentleButton.hidden = continuing || Boolean(steering);
        gentleButton.disabled = button.disabled;
        cancelButton.hidden = !steering || !cancel;
        cancelButton.disabled = !steering?.canCancel;
        cancelButton.textContent = steering?.cancelling ? "Cancelling…" : "Cancel";
      }
    };
    async function send(event) {
      event.preventDefault();
      if (disposed || busy || !available || !input.value.trim()) return;
      const submitted = input.value;
      // An ambiguous active submission must reconcile its original identity even
      // if the run finished meanwhile; never turn that retry into a new attempt.
      const mode = continuing && !retries.has(`steer:${submitted}`) ? "followup" : "steer";
      const retryKey = `${mode}:${submitted}`;
      const prior = retries.get(retryKey);
      const steeringMode = prior?.steeringMode || (event.submitter === button ? "interrupt" : "after_response");
      const submissionId = prior?.submissionId || `inline_${mode}_${globalThis.crypto?.randomUUID?.()
        || Date.now().toString(36) + Math.random().toString(36).slice(2)}`;
      retries.set(retryKey, {submissionId, steeringMode});
      const ownedFocus = root.contains(document.activeElement);
      if (mode === "followup") showFollowupPreview(submitted, submissionId, ownedFocus);
      if (mode === "steer") {
        progress.innerHTML = progressMarkup;
        if (steeringMode === "after_response") progress.querySelector("span").textContent = gentleWaiting;
        steering = track(requestId, message => {
          progress.querySelector("span").textContent = message; render();
        }, {steeringMode, cancel: cancel && (() => cancel({requestId, submissionId}))});
        observe(requestId, latestSnapshot);
      }
      busy = true; render();
      const tracking = steering;
      let failed = false, accepted = false, nextRequest = "";
      try {
        const result = await (mode === "followup" ? followup : submit)({requestId, amendment: submitted, submissionId, steeringMode});
        if (mode === "followup") {
          nextRequest = result?.request_id || "";
          clearFollowupPreview();
          // The POST receipt already establishes the child. A slow or stale
          // snapshot must not keep this parent busy or reopen its old inbox.
          if (nextRequest) acceptedContinuation = {request_id: nextRequest};
        }
        if (disposed) return;
        if (tracking) {
          void Promise.resolve(reconcile?.(requestId)).catch(() => {});
          const outcome = await tracking.accepted(result);
          if (outcome === "withdrawn") {
            retries.delete(retryKey);
            if (!disposed) notify("Steer cancelled. Your text is retained.");
          }
          if (!requireApplied(outcome) || disposed) return;
        }
        retries.delete(retryKey);
        if (input.value === submitted) { input.value = ""; resize(); }
        accepted = true;
        if (mode === "followup") notify("Continuing this conversation.");
      } catch (error) {
        if (disposed) return;
        failed = true;
        if ([404, 409, 422].includes(error.status)) {
          retries.delete(retryKey);
          if (mode === "followup") clearFollowupPreview();
        } else if (mode === "followup" && followupPreview) {
          followupPreview.querySelector(".submission-status").textContent =
            "Couldn’t confirm submission · Retry with the same prompt.";
        }
        const message = error.status === 404 ? "This run is no longer available. Your text is retained."
          : error.status === 409 ? (error.message || "This run changed before the update could be applied.")
          : error.status === 422 ? "Enter an instruction of at most 24,000 characters."
          : error.status >= 500 ? "The server couldn’t confirm the update. Your text is retained; retry safely."
          : !navigator.onLine ? "You’re offline. Your text is retained; retry when connected."
          : "Couldn’t confirm the update. Your text is retained; retry to confirm it safely.";
        notify(message);
      } finally {
        tracking?.cancel(); steering = null;
        if (!disposed) {
          busy = false; render();
          update(latestSnapshot);
          // Reads repair presentation in the background; they cannot delay an
          // accepted follow-up or turn it into a failed submission.
          if (!tracking || failed) void Promise.resolve().then(() => reconcile?.(requestId)).catch(() => {});
          if (failed && terminal.has(lastStatus) && mode === "steer") {
            notify(retries.has(retryKey)
              ? "This run finished. Retry to check whether your instruction was saved."
              : "This run finished. Your text is retained; use Continue to send it as a follow-up.");
          }
          if (!disposed && available && root.isConnected && !document.hidden && ownedFocus
              && (root.contains(document.activeElement) || document.activeElement === document.body)) {
            input.focus({preventScroll: true});
          } else if (!disposed && nextRequest && !document.hidden && ownedFocus
              && (root.contains(document.activeElement) || document.activeElement === root.closest("article")
                || document.activeElement === document.body)) {
            const nextInput = document.querySelector(`.inline-steer[data-request-id="${CSS.escape(nextRequest)}"]:not([hidden]) textarea`);
            nextInput?.focus({preventScroll: true});
          }
          if (accepted && !disposed) onAccepted({requestId: nextRequest || requestId});
        }
      }
    }
    function mount() {
      input = document.createElement("textarea");
      input.rows = 1; input.maxLength = 24000;
      input.placeholder = "Steer this run…";
      input.setAttribute("aria-label", "Steer this run");
      input.setAttribute("aria-keyshortcuts", "Enter");
      input.title = "Enter to steer without interrupting; Shift+Enter for a new line.";
      const field = document.createElement("div");
      field.className = "steering-input";
      progress = document.createElement("span");
      progress.className = "steering-status"; progress.hidden = true;
      progress.id = `steering-status-${requestId}`;
      progress.setAttribute("role", "status"); progress.setAttribute("aria-live", "polite");
      input.setAttribute("aria-describedby", progress.id);
      field.append(input, progress);
      button = document.createElement("button");
      button.type = "submit"; button.textContent = "Steer";
      button.className = "stop-button activity-stop-button";
      gentleButton = document.createElement("button");
      gentleButton.type = "submit"; gentleButton.textContent = gentleLabel;
      gentleButton.title = gentleHint;
      gentleButton.className = "stop-button activity-stop-button gentle-steer";
      cancelButton = document.createElement("button");
      cancelButton.type = "button"; cancelButton.textContent = "Cancel";
      cancelButton.setAttribute("aria-label", "Cancel steer");
      cancelButton.className = "stop-button activity-stop-button";
      cancelButton.hidden = true;
      root.append(field, button, gentleButton, cancelButton);
    }
    function listen() {
      listeners = new AbortController();
      const options = {signal: listeners.signal};
      root.addEventListener("submit", send, options);
      cancelButton.addEventListener("click", async () => {
        try { await steering?.requestCancel(); }
        catch (error) { if (!disposed) notify(error.message || "Couldn’t cancel this steer. Try again."); }
        if (!disposed) render();
      }, options);
      input.addEventListener("input", () => { resize(); render(); }, options);
      input.addEventListener("keydown", event => {
        if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
          event.preventDefault();
          if (!button.disabled) root.requestSubmit(continuing ? button : gentleButton);
        }
      }, options);
    }
    function update(snapshot) {
      if (disposed) return;
      if (acceptedContinuation) {
        snapshot = {...snapshot, continued_by: acceptedContinuation};
      }
      // Only this inbox's POST receipt is sticky. Task-list projections can
      // temporarily still name an older head while the new turn is mounting.
      if (snapshot?.continued_by) clearFollowupPreview();
      latestSnapshot = snapshot;
      lastStatus = snapshot?.status || "";
      continuing = canContinue(snapshot);
      available = isSteerable(snapshot) || (continuing && typeof followup === "function");
      if (available && !input) mount();
      if (available && (!listeners || listeners.signal.aborted)) listen();
      if (!available && root.contains(document.activeElement)) {
        const turn = root.closest("article");
        if (turn) { turn.tabIndex = -1; turn.focus({preventScroll: true}); }
      }
      const wasHidden = root.hidden;
      root.hidden = !available && !steering;
      if (available && wasHidden) resize();
      render();
      if (!available && terminal.has(snapshot?.status) && !steering) listeners?.abort();
    }
    return {root, requestId, update, updateStatus(status) {
      update({...latestSnapshot, status});
    }, dispose() {
      disposed = true; available = false; steering?.cancel(); listeners?.abort(); retries.clear(); root.hidden = true;
      clearFollowupPreview();
    }};
  }
  window.SMTOInlineSteer = {create, isSteerable, isEditable, track, observe, requireApplied, progressMarkup,
    gentleLabel, gentleHint, gentleWaiting};
})();
