/* Shared task-scoped deletion and monotonic history exclusions for both clients. */
(() => {
  "use strict";
  function create({conversationId, apiJson, notify, changed = () => {}}) {
    const scopes = new Map(), pending = new Set();
    const scope = cid => {
      if (!scopes.has(cid)) scopes.set(cid, {tasks: new Set(), requests: new Set(), revision: 0});
      return scopes.get(cid);
    };
    function deleted(value, cid = conversationId()) {
      const state = scopes.get(cid);
      return Boolean(state && (state.tasks.has(value.task_id || value.taskId)
        || state.requests.has(value.request_id || value.requestId || value.id)));
    }
    function observe(payload, cid = payload.conversation_id || payload.conversation?.conversation_id || conversationId()) {
      if (!cid) return;
      const state = scope(cid);
      let updated = false;
      for (const [field, set] of [["deleted_task_ids", state.tasks], ["deleted_request_ids", state.requests]]) {
        if (payload[field]?.length) window.SMTOTaskDisclosure?.forget(cid,
          payload[field].map(id => `${field === "deleted_task_ids" ? "task" : "request"}:${id}`));
        for (const id of payload[field] || []) if (!set.has(id)) { set.add(id); updated = true; }
      }
      state.revision = Math.max(state.revision, payload.history_revision || 0);
      if (updated) changed(cid, value => deleted(value, cid));
    }
    async function remove(taskId, opener) {
      const cid = conversationId(), key = `${cid}:${taskId}`;
      if (!cid || pending.has(key)) return;
      pending.add(key); opener.disabled = true;
      const url = `/api/agent/conversations/${encodeURIComponent(cid)}/tasks/${encodeURIComponent(taskId)}`;
      const hadFocus = document.activeElement === opener;
      try {
        const preview = await apiJson(`${url}/delete-preview`, {method: "POST"});
        const result = await apiJson(url, {method: "DELETE", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({selection_digest: preview.selection_digest})});
        observe(result, cid);
        if (result.gc) {
          const feedback = await import('./deletion_progress.js?v=20261015-smto');
          feedback.conversations.track(result.gc);
        }
        notify(result.accepted ? "Task removed. Cleanup queued for idle time." : "Task deleted");
        // Never move focus away from a draft edited while acceptance was in flight.
        if (hadFocus && !opener.isConnected && document.activeElement === document.body && cid === conversationId())
          (document.querySelector(".task-delete-button") || document.querySelector("#prompt-input, #message"))?.focus({preventScroll: true});
      } catch (error) { notify(error.message || "Could not delete this task. Try again."); }
      finally { pending.delete(key); if (opener.isConnected) opener.disabled = false; }
    }

    function decorate(root) {
      // A follow-up accepted before deletion can arrive afterward.
      // Reconcile its mounted identity before the next paint, too.
      if ([...root.querySelectorAll(".turn")].some(turn => deleted(turn.dataset)))
        changed(conversationId(), value => deleted(value));
      const seen = new Set();
      for (const group of root.querySelectorAll(".activity-group[data-task-id]")) {
        const id = group.dataset.taskId;
        let button = group.querySelector(":scope > .task-delete-button");
        if (seen.has(id) || deleted({task_id: id})) { button?.remove(); continue; }
        seen.add(id);
        if (!button) {
          button = document.createElement("button"); button.type = "button";
          button.className = "icon-button task-delete-button"; button.title = "Delete task";
          button.setAttribute("aria-label", "Delete task");
          button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7m4-7v7"/></svg>';
          button.addEventListener("click", event => {
            event.preventDefault(); event.stopPropagation(); void remove(group.dataset.taskId, button);
          });
          group.prepend(button);
        }
        button.disabled = pending.has(`${conversationId()}:${id}`);
      }
    }
    return {observe, deleted, decorate};
  }
  window.SMTOTaskDeletion = {create};
})();
