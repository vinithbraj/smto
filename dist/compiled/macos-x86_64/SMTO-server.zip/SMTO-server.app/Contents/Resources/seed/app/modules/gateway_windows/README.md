# Windows Gateway Agent

Multiple instances on different ports use separate state automatically. Use
`./src/gateway_windows/startup.ps1 -Instance worker -Port 8989` for a stable named
instance. See [instance isolation and recovery](../gateway_agent/README.md#multiple-independent-instances).

Gateway operations require the paired smTO controller (V148.1). The configured
smTO client verifies Gateway TLS, pairs automatically on first use, and signs
requests. `/healthz` is the only public operational health surface and returns only
`{"status":"ok"}`. Raw unsigned HTTP/HTTPS examples below illustrate payload shapes;
use the smTO client to execute them.

Outbound Email uses shared `gateway_core` handlers on this platform. The private
`/email/operation` route performs SMTP and Email OAuth HTTPS on the selected Gateway,
supports bounded volatile attachment staging and socket cancellation, and never falls
back to controller SMTP/token requests. Upgrade both controller and Gateway for the
OAuth action. See [Email setup and limits](../manual/content/26-auth-and-email.md).

Pairing and TLS identity survive restarts and upgrades. If the controller identity
is lost, run `python -m gateway_core.pairing reset-pairing` locally in the Gateway
Python environment, restart the Gateway, and reconnect the intended controller.
For pairing plus connection cleanup, stop the Gateway and its restart service,
then run `./src/gateway_windows/reset.ps1` or your compiled Gateway executable
with `reset`. The script accepts `-DryRun` and `-TlsStateDir PATH`; compiled
Gateways accept `reset --dry-run` and `reset --tls-state-dir PATH`. This clears
saved outbound server pins and abandoned authentication temporary files while
preserving TLS identity, replay protection, job history, downloads, artifacts and
configuration. Restart and reconnect afterward. Current Gateways hold a runtime
lease that prevents resetting live state.
See [installation and recovery](../manual/content/02-install-startup.md).

This intentionally permits a new first controller. Automatic first-controller
pairing cannot prevent an active hostile client from winning the very first race
without an out-of-band secret or user confirmation.

Outbound control requires an existing configured Gateway record on the Agent and
a pinned WSS connection to its HTTPS listener. Plain WS is refused. Mutual proofs
bind the session before any operations; encrypted, authenticated sessions may carry
credentials under the existing credential policy. See
[the V148.1 report](../../docs/v148_1-gateway-client-auth-mutual-pairing-report.md)
for protocol and recovery details.


`src/gateway_windows/` is the native Windows wrapper for the smTO gateway
agent. It uses the shared gateway core and advertises `platform=windows` with
`command_profile=powershell-windows` so the runtime can generate PowerShell
commands for this gateway.

## Scope

Windows v1 supports:

- shell command execution through PowerShell;
- streamed shell execution;
- cancellation by execution id;
- Windows platform and command profile discovery.

Native Windows v1 does not advertise interactive terminal sessions or the
gateway-managed local LLM runtime. For POSIX terminal workflows on a Windows
machine, run the existing Linux gateway inside WSL and register it as a separate
Linux/POSIX gateway node.

## Install

```powershell
cd C:\path\to\smto
.\src\gateway_windows\install.ps1
```

This creates or updates `src\gateway_windows\.venv` from the canonical
`pyproject.toml` dependency contract, then checks dependencies and mandatory
runtime imports. Run this PowerShell installer after source updates and restart
the Gateway; installation does not restart services. Each remote Gateway host
must run its installer against its own updated checkout. If `/capabilities`
reports `http_runtime.ready=false`, rerun the installer and restart.

The installer also installs Playwright and its matching Chromium and verifies a headless
JavaScript render. Browser execution is enabled by default; no extra startup arguments
are required. Install under the Gateway's Windows account so its browser cache is
available. `GATEWAY_BROWSER_ENABLED=false` is an explicit operator opt-out; conversation
capability permissions remain separate.

The shared updater installs the core and attempts the `.[full]` Python profile, including PDF, Office,
Docker SDK, HTTP authentication, manual/site and Python tooling dependencies.
It also installs and tests Kaleido's browser for Plotly PNG exports. WinGet installs
missing Git, PostgreSQL command-line tools (without its server), Tesseract with English
data, 7-Zip, Docker CLI, Compose and Buildx. Install Microsoft App Installer first if
WinGet is unavailable. Missing Python is provisioned through WinGet unless `PYTHON_BIN`
is explicit or system installation is skipped. A 64-bit Python is required.
Discovered native client paths are preserved inside the Gateway environment for
future launches. Windows Negotiate authentication uses native SSPI credentials;
it does not require the MIT Kerberos SDK. Optional client, Python package and feature
check failures are reported without blocking the core Gateway. Failures are recorded in
`.venv/smto-installation.json`; dependent operations remain unavailable. Missing
Python or failed core runtime checks still stop setup. Repair dependencies, rerun the
installer and restart the Gateway to refresh availability.
Docker Desktop, GPU drivers, service accounts, desktop permissions and a running
Docker Engine remain separate requirements.

## Run

```powershell
.\src\gateway_windows\startup.ps1
```

The helper accepts host and port overrides:

```powershell
.\src\gateway_windows\startup.ps1 -Host 0.0.0.0 -Port 8787
```

Because the gateway executes local commands and has no built-in authentication,
bind to `0.0.0.0` only on a trusted network or behind a trusted proxy/firewall.

When inbound access to the gateway is blocked, run outbound mode so the gateway
connects back to the Agent server:

```powershell
aor serve --host 0.0.0.0 --port 8011
.\src\gateway_windows\startup.ps1 -ServerHost 192.168.1.10 -ServerPort 8011
```

## Configuration

- `GATEWAY_NODE_NAME`
  - logical node served by this gateway
  - default: `COMPUTERNAME`, short hostname, then `windows`
- `GATEWAY_BIND_HOST`
  - bind host
  - default: `127.0.0.1`
- `GATEWAY_BIND_PORT`
  - bind port
  - default: `8787`
- `GATEWAY_EXEC_TIMEOUT_SECONDS`
  - per-command timeout; `0` disables task timeouts
- `GATEWAY_WORKDIR`
  - optional working directory for command execution
- `GATEWAY_TRACE_COMMANDS`
  - log each requested command on the gateway server
- `GATEWAY_SHELL`
  - command shell path
  - default: `powershell.exe`
  - set to `pwsh.exe` to use PowerShell 7+
- `GATEWAY_SERVER_HOST`
  - Agent server host for outbound gateway mode
- `GATEWAY_SERVER_PORT`
  - Agent server port for outbound gateway mode
- `GATEWAY_SERVER_SCHEME`
  - Agent server scheme for outbound gateway mode
  - default: `http`

## Automatic Gateway TLS

Supported startup now serves HTTPS on the existing port, normally `https://host:8787`.
smTO generates a durable RSA identity and renews its self-signed certificate
automatically at startup. No OpenSSL executable, certificate copying, CA installation,
fingerprint confirmation, or OS trust-store changes are needed. The Agent pins the
public key on first configured use and verifies it before sending requests. Existing
remote HTTP profiles upgrade automatically when the updated listener is available.

A changed identity key stops operations. After checking the intended machine, use
**Settings → Gateways → Forget trusted identity** for an intentional reinstall/reset,
then reconnect and select the Gateway again. Normal certificate renewal needs no reset.

This protects traffic from passive snooping and pins the Gateway server identity.
Automatic first-use trust cannot prevent an active attacker during first contact.
TLS does not authenticate clients: reachable execution endpoints still require the
existing trusted network/firewall boundary. Remote legacy HTTP cannot carry credentials.
Remote outbound WSS pins the configured Agent server, but credential delivery remains
blocked until independent outbound Gateway client pairing is available; loopback
outbound development remains supported.

See [the V148 report](../../docs/v148-secure-gateway-prerequisite-recovery-report.md)
for identity locations, trust semantics, and acceptance evidence.


### Gateway runtime coherence (V151.1)

The supported installer installs a non-editable package snapshot from the current checkout,
checks canonical dependencies with `pip check`, and validates job and HTTP readiness. Run the
platform installer again after pulling or switching branches, then explicitly restart the
Gateway to use that revision. A Git checkout alone does not upgrade or restart a running Gateway.
Updating dependencies belongs to the installer; the server never installs packages on demand.

`startup.sh` / `startup.ps1` use Python isolated mode and reject legacy editable environments.
Startup checks load jobs, shell execution, privilege, terminal, and available HTTP support before
serving requests. Missing or incompatible `psutil` fails startup with installer guidance.
Authenticated `/capabilities` includes `background_jobs.ready` and a bounded `runtime_identity`
(package version, source snapshot fingerprint, and psutil version), without filesystem paths.

For development, use a separate development environment and invoke `python -m gateway_core.serve`
or the platform app directly. Source/editable development is an explicit opt-in by bypassing the
production startup script; restart that development process whenever code or dependencies change.
Production startup deliberately provides no editable/hot-upgrade switch. Installer updates to an
in-use environment require a coordinated explicit restart; they are not a hot-upgrade mechanism.

## Desktop UI automation

Windows UIA requires `comtypes` (included in the Windows project dependencies) and an interactive user session; session 0 and Secure Desktop are unavailable.

The optional `ui` skill reports live partial capabilities through `ui.status`; it is disabled
in fresh Agent capability defaults. See the [Desktop UI manual](../manual/content/architecture/40-desktop-ui.md)
for reference lifetime, secure-field behavior, input bounds and platform validation limitations.
