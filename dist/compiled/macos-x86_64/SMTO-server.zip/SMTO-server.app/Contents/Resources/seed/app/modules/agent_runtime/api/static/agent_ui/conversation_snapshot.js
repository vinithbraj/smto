/* One selected-conversation read owner. Shares the existing invalidation transport. */
(() => {
  "use strict";
  let release, released = false;
  const initialStreams = [];
  window.SMTOReadPriority = {ready: new Promise(resolve => { release = resolve; }),
    stream(source) {
      if (released) return;
      initialStreams.push(new Promise(resolve => {
        source.addEventListener("open", resolve, {once:true}); source.addEventListener("error", resolve, {once:true});
      }));
    },
    release() {
      if (released) return;
      released = true;
      // Give the active trace connection priority over optional catalog fan-out.
      // A failed/quiet transport cannot indefinitely block composer preparation.
      const fallback = setTimeout(release, 250);
      Promise.all(initialStreams).then(() => { clearTimeout(fallback); release(); });
    }};
  const reads = new Map();
  function coalesceRead(key, read) {
    if (!reads.has(key)) {
      const pending = Promise.resolve().then(read).finally(() => { if (reads.get(key) === pending) reads.delete(key); });
      reads.set(key, pending);
    }
    // Consumers can annotate their own payload without changing another view.
    return reads.get(key).then(value => structuredClone(value));
  }
  function laneView(value) {
    if (value?.schema_version !== 2) return value;
    const tasks = value.tasks_by_id;
    const list = key => (value[key] || []).map(id => tasks[id]).filter(Boolean);
    return {...value, tasks: list("ordered_task_ids"), active_tasks: list("active_task_ids"),
      queued_tasks: list("queued_task_ids"), dependency_candidates: list("dependency_candidate_ids"),
      active_task: tasks[value.active_task_id] || null, blocked_task: tasks[value.blocked_task_id] || null,
      previous_task: tasks[value.previous_task_id] || null,
      selected_dependency_task: tasks[value.selected_dependency_task_id] || null};
  }
  function create({apiJson, apply, freshness = () => {}}) {
    let selected = null, generation = 0, current = null, pending = null, controller = null;
    let applying = false, appliedKey = null, dirty = false;
    function select(id) {
      if (selected === id) return;
      controller?.abort(); generation++; selected = id; pending = null; current = null; appliedKey = null; dirty = false;
    }
    function refresh() {
      if (!selected) return Promise.resolve(true);
      if (applying) return Promise.resolve(true);
      if (pending) return pending;
      const id = selected, version = generation;
      controller = new AbortController();
      const query = window.SMTOTaskDependencies?.query() || "";
      freshness(current ? "reconciling" : "loading", current);
      const operation = (async () => {
        try {
          do {
            dirty = false;
            const params = new URLSearchParams(query);
            for (const rid of current?.active_request_ids || []) params.append("observe_request_id", rid);
            const suffix = params.size ? `?${params}` : "";
            const snapshot = await apiJson(`/api/agent/conversations/${encodeURIComponent(id)}/snapshot${suffix}`,
              {signal: controller.signal});
            if (version !== generation || id !== selected) return false;
            applying = true;
            try {
              if (snapshot.snapshot_version !== appliedKey) await apply(snapshot, laneView(snapshot.lane));
              if (version !== generation || id !== selected) return false;
              current = snapshot; appliedKey = snapshot.snapshot_version;
            } finally { applying = false; }
            freshness(dirty ? "reconciling" : "current", current);
            performance.mark("conversation_snapshot_applied");
            window.SMTOReadPriority.release();
          } while (dirty && version === generation && id === selected);
          return true;
        } catch (error) {
          if (version === generation && error.name !== "AbortError") {
            freshness("stale", current, error);
            window.SMTOReadPriority.release();
          }
          return false;
        } finally { if (version === generation) pending = null; }
      })();
      pending = operation;
      return operation;
    }
    function invalidate(payload = {}) {
      // Initial SSE synchronization joins bootstrap. Committed changes received
      // during a read require one trailing reconciliation, never another owner.
      if (pending && (current || payload.events?.length || !payload.syncRequired)) dirty = true;
      return pending || refresh();
    }
    return {select, refresh, invalidate, current: () => current, selected: () => selected,
      applying: () => applying, version: () => appliedKey,
      execution: id => current?.executions_by_request_id[id] || null};
  }
  let inspectionSequence = 0;
  const pageLoaded = new Promise(resolve => {
    if (document.readyState === "complete") resolve();
    else window.addEventListener("load", resolve, {once: true});
  });
  function loadHistoryControl({actionContainer, disclosure, host, requestId, apiJson, conversationId = "", renderMarkdown,
    ready = () => Promise.resolve(), onAnswerArchived}) {
    const action = document.createElement("button");
    action.type = "button"; action.className = "run-detail-action run-history-action";
    action.textContent = "Load history"; action.hidden = true;
    disclosure.id ||= `run-activity-${++inspectionSequence}`;
    action.setAttribute("aria-controls", disclosure.id);
    const notice = document.createElement("span");
    notice.setAttribute("role", "status"); notice.hidden = true;
    actionContainer.append(action, notice);
    let pager = null, disposed = false, requested = false, autoScheduled = false, version = 0;
    let runStatus = "running", autoLoad = false;
    const buffered = [];
    async function loadHistory() {
      if (disposed || action.disabled) return;
      const owner = version;
      notice.hidden = true;
      requested = true; action.disabled = true; action.textContent = "Loading history…";
      disclosure.hidden = false; disclosure.open = true;
      try {
        if (pager) { await pager.reload(); return; }
        const {mountActivityPages} = await import("./activity_pages.js?v=20261015-smto");
        if (disposed || owner !== version || !disclosure.isConnected) return;
        pager = mountActivityPages({disclosure, host, requestId, apiJson, conversationId, renderMarkdown, onAnswerArchived, allHistory: true,
          visible: () => !disposed && disclosure.isConnected,
          onState(state) {
            if (disposed || owner !== version) return;
            action.disabled = state === "loading";
            action.textContent = action.disabled ? "Loading history…" : "Load history";
          }});
        pager.update(runStatus);
        for (const event of buffered.splice(0)) pager.event(event);
      } catch (_) {
        if (disposed || owner !== version) return;
        notice.textContent = "Could not load history. Select Load history to retry."; notice.hidden = false;
        action.disabled = false; action.textContent = "Load history";
      }
    }
    action.onclick = loadHistory;
    function scheduleHistory() {
      if (disposed || requested || autoScheduled || !autoLoad || action.hidden) return;
      autoScheduled = true;
      const owner = version;
      const current = () => !disposed && owner === version && !requested && autoLoad
        && !action.hidden && disclosure.isConnected;
      // Keep history off the initial page/connection path and allow the current
      // run to paint before starting the same progressive load as the button.
      void Promise.all([pageLoaded, window.SMTOReadPriority.ready, ready()]).then(() => {
        if (!current()) return;
        requestAnimationFrame(() => setTimeout(() => {
          if (current()) void loadHistory();
        }, 0));
      });
    }
    return {
      update(status) {
        runStatus = status; pager?.update(status);
        autoLoad = ["pending", "running", "waiting_job", "waiting_event", "paused", "paused_budget",
          "waiting_user", "awaiting_confirmation", "awaiting_clarification", "awaiting_resource_reconciliation"].includes(status);
        action.hidden = false; actionContainer.hidden = false;
        scheduleHistory();
      },
      event(event) {
        if (!requested || disposed) return;
        if (pager) pager.event(event); else buffered.push(event);
      },
      reset() {
        version++; pager?.dispose(); pager = null; requested = false; autoScheduled = false;
        buffered.length = 0;
        action.disabled = false; action.textContent = "Load history"; notice.hidden = true;
        scheduleHistory();
      },
      dispose() { disposed = true; version++; pager?.dispose(); action.remove(); notice.remove(); },
    };
  }
  function disclosureAction({actionContainer, panel, label}) {
    const action = document.createElement("button");
    action.type = "button"; action.className = "run-detail-action"; action.textContent = label;
    panel.id ||= `run-detail-${++inspectionSequence}`;
    action.setAttribute("aria-controls", panel.id);
    const sync = () => {
      panel.hidden = !panel.open;
      action.setAttribute("aria-expanded", String(panel.open));
      if (!panel.open && panel.contains(document.activeElement)) action.focus({preventScroll: true});
    };
    action.onclick = () => { panel.open = !panel.open; sync(); };
    panel.addEventListener("toggle", sync);
    actionContainer.append(action); actionContainer.hidden = false;
    sync();
    return {action, dispose() { panel.removeEventListener("toggle", sync); action.remove(); }};
  }
  function inspectControl({actionContainer, requestId, apiJson, ready = Promise.resolve()}) {
    const element = (tag, text = "", className = "") => {
      const node = document.createElement(tag); node.textContent = text;
      if (className) node.className = className;
      return node;
    };
    const human = value => String(value || "unknown").replaceAll("_", " ");
    const date = value => {
      if (value == null) return null;
      const parsed = new Date(typeof value === "number" ? value * 1000 : value);
      return Number.isNaN(parsed.getTime()) ? null : parsed.toLocaleString(undefined,
        {month: "short", day: "numeric", hour: "numeric", minute: "2-digit", second: "2-digit"});
    };
    const bytes = value => {
      if (!Number.isFinite(value) || value < 0) return null;
      const units = ["B", "KB", "MB", "GB", "TB"];
      const index = value ? Math.max(0, Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1)) : 0;
      return `${(value / 1024 ** index).toLocaleString(undefined, {maximumFractionDigits: index ? 1 : 0})} ${units[index]}`;
    };
    const root = element("details", "", "execution-inspection");
    const summary = element("summary");
    const title = element("span", "Inspect execution", "execution-inspection-title");
    const badge = element("span", "", "execution-inspection-badge"); badge.hidden = true;
    const notice = element("div", "", "execution-inspection-notice");
    notice.setAttribute("role", "status"); notice.hidden = true;
    const content = element("div", "", "execution-inspection-groups");
    const back = element("button", "Back to current operation", "execution-inspection-back");
    back.type = "button"; back.hidden = true; back.setAttribute("aria-label", "Inspect current operation");
    const tabs = element("div", "", "execution-inspection-tabs");
    tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "Execution inspection");
    const evidencePanel = element("div"), eventsPanel = element("div");
    const eventsHost = element("div"); eventsPanel.append(eventsHost);
    evidencePanel.append(notice, content, back);
    const prefix = `execution-inspection-${++inspectionSequence}`;
    const tabButtons = new Map(), tabPanels = new Map([["evidence", evidencePanel], ["events", eventsPanel]]);
    for (const [name, panel] of tabPanels) {
      const tab = element("button", name === "evidence" ? "Evidence" : "Events");
      tab.type = "button"; tab.id = `${prefix}-${name}-tab`; tab.setAttribute("role", "tab");
      tab.setAttribute("aria-controls", `${prefix}-${name}`);
      tab.setAttribute("aria-selected", String(name === "evidence")); tab.tabIndex = name === "evidence" ? 0 : -1;
      panel.id = `${prefix}-${name}`; panel.setAttribute("role", "tabpanel");
      panel.setAttribute("aria-labelledby", tab.id); panel.hidden = name !== "evidence";
      tab.addEventListener("click", () => selectTab(name));
      tabButtons.set(name, tab); tabs.append(tab);
    }
    tabs.addEventListener("keydown", event => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const name = event.key === "Home" ? "evidence" : event.key === "End" ? "events"
        : selectedTab === "evidence" ? "events" : "evidence";
      selectTab(name); tabButtons.get(name).focus();
    });
    root.id = prefix;
    summary.append(title, badge); root.append(summary, tabs, evidencePanel, eventsPanel); actionContainer.after(root);
    const shortcut = disclosureAction({actionContainer, panel: root, label: "Inspect execution"});
    const resultsAction = actionContainer.querySelector(".run-results-action, .run-checks-action");
    if (resultsAction) resultsAction.before(shortcut.action);
    let target = null, controller = null, selectedTab = "evidence", pager = null, pagerLoading = false;
    let disposed = false, lastEventId = null;
    back.onclick = () => { target = null; showRetained(); void read(); };
    const retained = new Map();
    const commandViews = new Map();
    function group(title) {
      const section = element("section", "", "execution-inspection-group");
      section.append(element("h3", title)); content.append(section); return section;
    }
    function facts(section, rows) {
      const list = element("dl", "", "execution-inspection-facts");
      for (const [key, label, value] of rows) {
        if (value == null || value === "") continue;
        const row = element("div"); row.dataset.field = key;
        row.append(element("dt", label), element("dd", value)); list.append(row);
      }
      section.append(list);
    }
    function render(value) {
      const lifecycle = value.lifecycle || {}, progress = value.progress || {}, job = value.job || {};
      const wait = value.wait || {}, evidence = value.evidence || {}, metrics = progress.metrics || {};
      badge.textContent = human(lifecycle.user_visible_state);
      badge.dataset.state = lifecycle.terminal ? "terminal" : wait.kind && wait.kind !== "none" ? "waiting" : "active";
      badge.hidden = false;
      if (!root.open || selectedTab !== "evidence") return;
      const focused = content.contains(document.activeElement) ? document.activeElement.dataset.inspectionAction : null;
      content.replaceChildren();
      const execution = group(target ? "Blocking operation" : "Execution");
      facts(execution, [
        ["execution", "Status", human(lifecycle.user_visible_state)],
        ["started", "Started", lifecycle.started === true ? date(job.started_at) || "Confirmed"
          : lifecycle.started === false ? "Not started" : "Not confirmed"],
        ["liveness", "Process", {known_alive: "Observed alive", known_ended: "Ended"}[job.liveness] || "Not confirmed"],
        ["exit-code", "Exit code", job.exit_code],
        ["completed", "Completed", date(value.completed_at)],
        ["operation", "Operation", target],
      ]);
      const command = value.operation_command, context = value.operation_context || {};
      const saved = (context.files || []).filter(file => file.role !== "Source" &&
        (["Created", "Written", "Changed", "Collected"].includes(file.state)
          || file.role === "Destination" && file.state === "Reported" && lifecycle.terminal
            && ["completed", "succeeded"].includes(lifecycle.state)));
      if (saved.length) facts(execution, [["saved-to", "Saved to", saved.map(file => file.path + (file.path_truncated ? "…" : "")).join("\n")]]);
      if (command?.command_preview) {
        execution.append(element("h4", "Command", "execution-inspection-subtitle"));
        const key = JSON.stringify(command);
        let view = commandViews.get(key);
        if (!view) {
          view = window.SMTOCommandPreview.mount(execution, command, apiJson);
          commandViews.set(key, view);
          if (commandViews.size > 8) commandViews.delete(commandViews.keys().next().value);
        } else execution.append(view);
      }
      const capability = value.operation_presentation?.capability_id || "";
      if (command || context.cwd || context.files?.length || capability.startsWith("file.") || capability === "gateway.copy") {
        const files = group("Files and folders");
        facts(files, [["cwd", "Working folder", context.cwd]]);
        for (const file of context.files || []) {
          const card = element("div", "", "execution-inspection-file");
          const heading = element("div", "", "execution-inspection-file-heading");
          heading.append(element("span", file.role || "File"), element("span", file.state || "Recorded"));
          card.append(heading, element("code", file.path + (file.path_truncated ? "…" : "")));
          if (file.size_bytes != null) card.append(element("span", bytes(file.size_bytes), "execution-inspection-note"));
          files.append(card);
        }
        if (!context.files?.length) files.append(element("p", "No file paths were recorded for this operation.", "execution-inspection-note"));
        if (context.files?.some(file => file.state === "Named in command")) files.append(element("p",
          "Paths named in a command show its intended inputs or outputs; they do not confirm that a file was created.", "execution-inspection-note"));
        if (context.files_truncated) files.append(element("p", "Showing the first recorded files. More are available in Events.", "execution-inspection-note"));
      }
      if (lifecycle.started === false) execution.append(element("p", "This operation has not started.", "execution-inspection-note"));
      const progressSection = group("Progress");
      const progressLabel = {unknown: "Not reported", idle: "No recent progress", progressing: "Recent progress confirmed",
        possibly_stalled: "Possibly stalled", terminal: "Finished"}[progress.state] || human(progress.state);
      const transferred = bytes(metrics.bytes_transferred), total = bytes(metrics.bytes_total);
      facts(progressSection, [
        ["progress", "Activity", progressLabel],
        ["last-progress", "Last progress", date(progress.last_progress_at)],
        ["last-output", "Last output", date(progress.last_output_at)],
        ["bytes", "Transferred", transferred == null ? null : `${transferred}${total == null ? "" : ` of ${total}`}`],
        ["rate", "Transfer rate", bytes(metrics.transfer_rate) == null ? null : `${bytes(metrics.transfer_rate)}/s`],
        ["items", "Items completed", metrics.items_completed == null ? null
          : `${metrics.items_completed}${metrics.items_total == null ? "" : ` of ${metrics.items_total}`}`],
      ]);
      if (value.supervision) {
        const s = value.supervision;
        facts(progressSection, [
          ["supervision", "Supervision", human(s.health_state)],
          ["last-observation", "Last checked", date(s.last_observed_at)],
          ["next-observation", "Next automatic check", s.enabled ? date(s.next_observation_at) : "Finished"],
          ["observation-freshness", "Observation freshness", human(s.freshness)],
        ]);
      }
      if (progress.state === "unknown") progressSection.append(element("p",
        "No progress measurement is available for this operation.", "execution-inspection-note"));
      if (progress.state === "possibly_stalled") progressSection.append(element("p",
        "The process was observed alive, but expected progress has not changed.", "execution-inspection-note"));
      const blockers = wait.blocking_operation_ids || [];
      if (wait.reason || blockers.length || wait.kind && wait.kind !== "none") {
        const waiting = group("Waiting on");
        if (wait.reason) waiting.append(element("p", wait.reason, "execution-inspection-note"));
        facts(waiting, [["wait-kind", "Reason", wait.reason ? null : human(wait.kind)],
          ["waiting-since", "Since", date(wait.since)]]);
        if (blockers.length) {
          const actions = element("div", "", "execution-inspection-actions");
          for (const operation of blockers) {
            const button = element("button", "", "execution-inspection-blocker"); button.type = "button";
            button.dataset.inspectionAction = operation;
            button.setAttribute("aria-label", `Inspect blocking operation ${operation}`);
            button.append(element("span", "Inspect blocker"), element("code", operation));
            button.onclick = () => { target = operation; showRetained(); void read(); }; actions.append(button);
          }
          waiting.append(actions);
        }
      }
      if (value.task_context && Object.keys(value.task_context).length) {
        const context = group("Task context");
        const c = value.task_context;
        facts(context, [["transition", "Continuation", human(c.transition)],
          ["delivery", "Delivery", human(c.delivery_status || "prepared")],
          ["epoch", "Source epoch", c.source_epoch_id],
          ["instruction", "Epoch instruction", c.active_instruction?.reference],
          ["instruction-epoch", "Instruction source epoch", c.active_instruction?.source_epoch_id],
          ["instruction-kind", "Input representation", human(c.active_instruction?.representation)],
          ["instruction-revision", "Input revision", c.active_instruction?.contract_revision ?? c.active_instruction?.revision],
          ["instruction-inherited", "Inherited instruction", c.active_instruction ? (c.active_instruction.inherited ? "Yes" : "No") : null],
          ["tail-delivery", "Epoch tail delivery", human(c.tail_delivery_status)],
          ["tail-position", "Tail message position", Number.isInteger(c.tail_message_index) ? c.tail_message_index + 1 : null],
          ["tail-size", "Tail characters", c.tail_characters],
          ["saved", "Saved messages", c.saved_message_ids?.length],
          ["essential", "Essential context characters", c.essential_characters],
          ["optional", "Optional history reduced", c.progress_omitted_for_capacity ? "Yes" : "No"]]);
        const details = element("details"); details.append(element("summary", "Context delivery details"));
        details.append(element("pre", JSON.stringify(c, null, 2), "execution-inspection-output")); context.append(details);
      }
      const source = group("Evidence");
      facts(source, [["freshness", "Source", {retained: "Last recorded state", current: "Latest observation"}[evidence.freshness] || "Not available"],
        ["observed", "Observed", date(value.observed_at)]]);
      if (typeof job.output_tail === "string" && job.output_tail) {
        source.append(element("h4", "Latest output · last 5 lines", "execution-inspection-subtitle"));
        const output = element("pre", job.output_tail, "execution-inspection-output");
        output.setAttribute("aria-label", "Latest output, last 5 lines");
        source.append(output);
      }
      source.append(element("p", "Inspecting these details does not run a command.", "execution-inspection-note"));
      if (focused) [...content.querySelectorAll("[data-inspection-action]")]
        .find(button => button.dataset.inspectionAction === focused)?.focus({preventScroll: true});
    }
    function showRetained() {
      back.hidden = !target;
      const value = retained.get(target);
      if (value) render(value);
      else { content.replaceChildren(); badge.hidden = true; }
    }
    function update(value) {
      if (!value) return;
      const eventId = value.evidence?.trace_last_event_id;
      if (eventId != null && eventId !== lastEventId) { lastEventId = eventId; pager?.invalidate(); }
      // Snapshot updates still belong to the current operation while browsing a blocker.
      retained.set(null, value);
      if (!target) render(value);
    }
    async function read() {
      if (!root.open || selectedTab !== "evidence" || disposed) return;
      controller?.abort(); const request = controller = new AbortController(), inspected = target;
      root.setAttribute("aria-busy", "true");
      notice.hidden = false; notice.textContent = "Updating execution details…";
      try {
        const value = await apiJson(`/api/agent/executions/${encodeURIComponent(requestId)}/observation${inspected ? `?operation_id=${encodeURIComponent(inspected)}` : ""}`,
          {signal: request.signal});
        if (controller !== request || request.signal.aborted) return;
        const cached = retained.get(inspected);
        if (!cached || !(cached.observed_at > value.observed_at)) retained.set(inspected, value);
        render(retained.get(inspected)); notice.hidden = true;
      } catch (error) {
        if (controller !== request || request.signal.aborted) return;
        notice.textContent = "Could not refresh execution details. ";
        const retry = element("button", "Retry"); retry.type = "button"; retry.onclick = read; notice.append(retry);
      } finally {
        if (controller === request) { controller = null; root.removeAttribute("aria-busy"); }
      }
    }
    async function showEvents() {
      if (!root.open || selectedTab !== "events" || disposed) return;
      if (pager) { pager.reconcile(); return; }
      if (pagerLoading) return;
      pagerLoading = true;
      eventsHost.textContent = "Loading events…";
      try {
        const {mountActivityPages} = await import("./activity_pages.js?v=20261015-smto");
        if (disposed || !root.isConnected) return;
        eventsHost.textContent = "";
        pager = mountActivityPages({disclosure: root, host: eventsHost, requestId, apiJson, ready,
          visible: () => root.open && selectedTab === "events" && !disposed});
      } catch (_) { eventsHost.textContent = "Could not load events. Select Events again to retry."; }
      finally { pagerLoading = false; }
    }
    function selectTab(name) {
      selectedTab = name;
      for (const [key, tab] of tabButtons) {
        tab.setAttribute("aria-selected", String(key === name)); tab.tabIndex = key === name ? 0 : -1;
        tabPanels.get(key).hidden = key !== name;
      }
      reconcile();
    }
    function reconcile() {
      if (root.open && selectedTab === "evidence") { showRetained(); void read(); }
      else { controller?.abort(); controller = null; root.removeAttribute("aria-busy"); notice.hidden = true; }
      pager?.reconcile();
      if (root.open && selectedTab === "events") void showEvents();
    }
    root.addEventListener("toggle", reconcile);
    return {update, root, dispose() {
      disposed = true; controller?.abort(); pager?.dispose(); shortcut.dispose(); root.removeEventListener("toggle", reconcile); root.remove();
    }};
  }
  function executionEvent(current, event) {
    const d = event.detail || {}, type = event.event_type || "";
    if (current?.trace_event_id && Number(event.id) <= current.trace_event_id) return current;
    const matching = !current || d.operation_id && d.operation_id === current.operation_id
      || d.activity_id && d.activity_id === current.activity_id
      || !current.operation_id && !current.activity_id && ["running", "pending"].includes(current.state);
    const base = {operation_id: d.operation_id || current?.operation_id, activity_id: d.activity_id || current?.activity_id,
      trace_event_id: Number(event.id), observed_at: event.timestamp, detail: ""};
    if (type === "llm.scheduler_wait.started") return {...base, operation_id: null, activity_id: null,
      state: "running", kind: "waiting", label: d.queue === "agent_turn" ? "Waiting for controller capacity…" : "Waiting for model capacity…"};
    if (["llm.request", "llm.scheduler_wait.completed", "capability_selection.started"].includes(type)) {
      if (type === "llm.scheduler_wait.completed" && d.acquired === false) return null;
      const phase = type === "capability_selection.started" ? "capability_selection" : d.phase || event.stage;
      if (current?.kind === "waiting" && !["running", "pending"].includes(current.state)) return current;
      const label = {capability_selection: "Selecting capabilities…", task_contract: "Generating task contract…"}[phase] || "Thinking…";
      const runtime = ["capability_selection", "task_contract"].includes(phase);
      return {...base, operation_id: null, activity_id: null, state: "running", phase,
        kind: runtime ? "runtime" : "thinking", iconKind: runtime ? phase === "task_contract" ? "file" : "user" : "thinking", label};
    }
    if (["thinking", "runtime"].includes(current?.kind) && ["llm.response", "llm.error", "llm.cancelled", "model.usage",
      "capability_selection.completed", "capability_selection.degraded"].includes(type)) return null;
    if (/^activity\.(waiting_capacity|runnable_waiting_capacity|pending_dependency|blocked_resource)$/.test(type)) {
      const dependency = type.endsWith("pending_dependency"), conflict = type.endsWith("blocked_resource");
      return {...base, state: dependency ? "waiting_dependencies" : conflict ? "waiting_effect" : "waiting_capacity",
        kind: "waiting", label: (d.reason || (dependency ? "Waiting for dependencies" : conflict ? "Waiting for a conflicting operation" : "Waiting for capacity")) + " · Not started"};
    }
    if ((matching || current?.kind !== "waiting") && ["execution.command.started", "execution.command.resource_admitted", "invocation.started", "tool.started", "activity.running"].includes(type))
      return {...base, state: type.endsWith("resource_admitted") ? "admitted" : "running", kind: "running",
        label: type.endsWith("resource_admitted") ? "Admitted · not yet started" : type === "invocation.started" ? "Starting operation" : "Running"};
    if (matching && type === "execution.command.resource_wait")
      return {...base, state: "waiting_capacity", kind: "waiting", label: (d.resource_wait_reason || "Waiting for resource") + " · Not started"};
    if (matching && ["execution.command.completed", "invocation.completed", "tool.completed", "tool.failed", "tool.cancelled"].includes(type)) {
      const unknown = d.process_state === "outcome_unknown" || d.effect_unknown || d.status === "outcome_unknown";
      const background = ["running", "queued", "starting"].includes(d.job_state) || ["running", "waiting_job"].includes(d.status);
      return {...base, state: unknown ? "outcome_unknown" : background ? "running_background" : "operation_completed",
        kind: "running", label: unknown ? "Outcome unknown" : background ? "Background job remains active"
          : d.executed === false ? "Operation was not executed" : "Operation finished · task continuing"};
    }
    if (type === "model.started" && (current?.kind !== "waiting" || ["running", "pending"].includes(current?.state))) return null;
    return current;
  }
const rowSelector = ".work-item, .model-step, .prose-activity, .steering-milestone, .conversation-message, .activity-event";

function boundActivity(host, maps = []) {
  // Removed rows remain available through the retained-history pager. Dispose
  // their streams and release keyed renderer references, not just CSS visibility.
  while (host.querySelectorAll(rowSelector).length > 125 && host.firstElementChild) {
    const oldest = host.firstElementChild;
    // A prose-free run can share one Working... group for its entire lifetime.
    // Trim its oldest activity instead of dropping the whole visible history.
    const items = oldest.dataset.fallbackProse === "true"
      ? oldest.querySelector(".prose-activity-items") : null;
    (items?.firstElementChild || oldest).remove();
  }
  for (const map of maps) if (map instanceof Map) for (const [key, row] of map) {
    const root = row.item || row.root || row.view?.root;
    if (root && !host.contains(root)) {
      row.liveShell?.viewer?.dispose(); row.viewer?.dispose(); map.delete(key);
    }
  }
}

  window.SMTOConversationSnapshot = {create, laneView, inspectControl, loadHistoryControl, disclosureAction, executionEvent, boundActivity, coalesceRead};
})();
