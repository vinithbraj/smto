/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/targets.js
 * @brief Bind shared Gateway intent to mobile drafts and touch controls.
 * @details
 * Responsibilities: Project selected count, primary and availability using the shared selector.
 * Boundaries: Registry resolution and execution authority remain server owned.
 * Lifecycle: Conversation navigation restores intent; registry refresh validates new submissions.
 * State: The server profile restores ID-only intent; api.js caches unsent text only.
 * Security: Credentials and connection profiles are never copied into choices or storage.
 * Collaborators: composer_profile restores intent; agent_options renders the selection sheet.
 * Public surface: targets, loadTargets and targetChoices.
 * @see src/agent_runtime/api/static/agent_ui/target_selector.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/api.js
 */
import { api, state, node, button, notice } from "./api.js";
import * as targetState from "./target_state.js";
let model = null, loading = null;
/** One shared selector instance per mobile page; its state is scoped by draft navigation. */
export function targets() {
  if (!model) model = targetState.createState({
    isSteering: () => state.steering,
    announce: message => { notice(message); },
    onChanged: edited => {
      state.gatewayDraft = model.isInitialized() ? model.draftSnapshot() : null;
      state.choices.gateway_id = model.gatewayId();
      state.choices.gateway_selection = model.gatewaySelection();
      window.dispatchEvent(new CustomEvent("mobile-targets-changed", {detail: {edited}}));
    },
  });
  return model;
}
/** Coalesce registry reads; offline enabled targets remain selected. */
export async function loadTargets() {
  if (!loading) loading = api("gateways").then(payload => targets().updateRecords(payload))
    .catch(error => { targets().markFailed(); throw error; }).finally(() => { loading = null; });
  await loading;
  return targets();
}
/** Native checkboxes and separate primary buttons keep selection and primary distinct. */
export function targetChoices(body) {
  const container = node("section", null, "mobile-target-choices");
  const status = node("p", "", "muted"); status.setAttribute("role", "status");
  const rows = node("div"); container.append(status, rows); body.append(container);
  /** Rebuild checkboxes from shared intent and restore focus to the same identity. */
  function paint() {
    const focused = rows.contains(document.activeElement) ? document.activeElement.dataset.focusKey : null;
    const run = targetState.fromNative(state.run);
    const ids = state.steering ? run?.gateway_selection?.gateway_ids || (run?.gateway_id ? [run.gateway_id] : []) : targets().gatewayIds();
    const primary = state.steering ? run?.gateway_id : targets().gatewayId();
    status.textContent = state.steering ? `Run targets · ${ids.length} · Locked while steering` : ids.length > 1 ? `Multiple gateways · ${ids.length}` : ids.length ? "1 Gateway selected" : "Choose at least one execution Gateway.";
    rows.replaceChildren();
    for (const record of targets().recordsSnapshot()) {
      const row = node("div", null, "mobile-target-row"), label = node("label"), check = node("input");
      check.type = "checkbox"; check.checked = ids.includes(record.gateway_id);
      check.disabled = state.steering || record.status === "disabled";
      check.dataset.focusKey = `select:${record.gateway_id}`;
      check.setAttribute("aria-label", record.label);
      check.onchange = () => { check.checked ? targets().addGateway(record.gateway_id) : targets().removeGateway(record.gateway_id); paint(); };
      const text = node("span", record.label);
      text.append(node("small", `${record.locality} · ${record.status}${record.gateway_id === primary ? " · Primary" : ""}`));
      label.append(check, text); row.append(label);
      if (ids.includes(record.gateway_id) && record.gateway_id !== primary) {
        const make = button("Make primary", () => { targets().setPrimaryGateway(record.gateway_id); paint(); });
        make.setAttribute("aria-label", `Make primary: ${record.label}`); make.dataset.focusKey = `primary:${record.gateway_id}`;
        make.disabled = state.steering || record.status === "disabled"; row.append(make);
      }
      rows.append(row);
    }
    // Deleted choices remain visible and removable; refreshing never substitutes a default.
    for (const item of (state.steering ? [] : targets().draftSnapshot().gateways).filter(item => !targets().recordsSnapshot().some(record => record.gateway_id === item.gateway_id))) {
      const remove = button(`Remove unavailable Gateway: ${item.gateway_label}`, () => { targets().removeGateway(item.gateway_id); paint(); });
      remove.disabled = state.steering; rows.append(remove);
    }
    if (focused) [...rows.querySelectorAll('[data-focus-key]')].find(item => item.dataset.focusKey === focused)?.focus();
  }
  const refresh = button("Refresh targets", async () => { await loadTargets(); paint(); });
  container.append(refresh); paint();
}
