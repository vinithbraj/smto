/* Explicit clickwrap. Backend status is authoritative; no browser acceptance flag. */
(() => {
  "use strict";
  let status = null, pending = false, dialog = null, declined = false;
  let returnFocus = null, settingsHost = null;
  async function api(path, options = {}) {
    const response = await window.SMTOErrors.fetch(path, {cache: "no-store", ...options,
      headers: {"Content-Type": "application/json"},
      ...(options.body ? {body: JSON.stringify(options.body)} : {})});
    const data = await window.SMTOErrors.readJson(response);
    if (!response.ok) throw window.SMTOErrors.fromPayload(data, response.status);
    return data;
  }
  const canExecute = () => status?.accepted === true;
  const node = (tag, text, className) => {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    if (className) el.className = className;
    return el;
  };
  const button = (text, action) => {
    const el = node("button", text); el.type = "button";
    el.addEventListener("click", action); return el;
  };
  const banner = node("div", "", "legal-banner");
  banner.id = "legal-banner";
  banner.setAttribute("role", "status");
  banner.hidden = true;
  (document.querySelector(".composer-dock") || document.querySelector("main"))?.prepend(banner);

  function changed() {
    banner.replaceChildren();
    banner.hidden = canExecute() || location.pathname === "/settings";
    if (!banner.hidden) {
      banner.append(node("span", `You must accept the End User License Agreement to use ${window.__BRANDING__.display_name}’s automation features.`),
        button("Review agreement", () => void open()));
    }
    renderSettings();
    window.dispatchEvent(new CustomEvent("smto:legal-status", {detail: status}));
  }

  async function refresh() {
    await window.SMTOReadPriority?.ready;
    try { status = await api("/api/legal/eula/status"); }
    catch (error) { status = null; throw error; }
    finally { changed(); }
    return status;
  }

  function close() {
    if (pending) return;
    if (!canExecute()) declined = true;
    dialog?.close();
    if (returnFocus?.isConnected) returnFocus.focus({preventScroll: true});
    changed();
  }

  async function open() {
    if (dialog?.open) return;
    let agreement = null;
    returnFocus = document.activeElement;
    dialog?.remove();
    dialog = node("dialog", "", "legal-dialog");
    dialog.id = "eula-dialog";
    dialog.setAttribute("aria-labelledby", "eula-heading");
    const heading = node("h2", `${window.__BRANDING__.display_name} End User License Agreement & Automation Risk Acknowledgment`);
    heading.id = "eula-heading"; heading.tabIndex = -1;
    const version = node("p", "Loading agreement…", "legal-version");
    const terms = node("div", "", "legal-terms");
    terms.tabIndex = 0; terms.setAttribute("role", "region");
    terms.setAttribute("aria-label", "Agreement text");
    const full = node("a", "Open full agreement");
    full.href = "/legal/eula"; full.target = "_blank"; full.rel = "noopener";
    const label = node("label", "", "legal-affirmation");
    const checkbox = node("input"); checkbox.type = "checkbox"; checkbox.id = "eula-checkbox";
    checkbox.disabled = true;
    label.htmlFor = checkbox.id;
    label.append(checkbox, node("span", "I have read and agree to the End User License Agreement and acknowledge the automation risks described above."));
    const error = node("p", "", "legal-error"); error.setAttribute("role", "alert");
    const actions = node("div", "", "legal-actions");
    const decline = button("Decline", close);
    const agree = button("I Agree", async () => {
      if (!checkbox.checked || !agreement || pending) return;
      pending = true; agree.disabled = true; decline.disabled = true; checkbox.disabled = true;
      error.textContent = "";
      try {
        status = await api("/api/legal/eula/accept", {method: "POST", body: {
          agree: true, version: agreement.version, document_sha256: agreement.document_sha256,
        }});
        pending = false; declined = false; close();
        const input = document.querySelector("#prompt-input");
        if (input && !document.querySelector("#empty-state")?.hidden &&
            !document.querySelector("dialog[open], [role=dialog]:not([hidden])")) input.focus();
      } catch (failure) {
        // A stale document or lost response never becomes inferred assent.
        error.textContent = failure.message;
        checkbox.checked = false;
        try { await load(); } catch (loadError) { error.textContent = loadError.message; }
      } finally {
        pending = false; decline.disabled = false; checkbox.disabled = false;
        agree.disabled = !checkbox.checked || !agreement;
      }
    });
    agree.className = "legal-agree"; agree.disabled = true;
    checkbox.addEventListener("change", () => { agree.disabled = !checkbox.checked || !agreement; });
    const settings = node("a", "Settings"); settings.href = "/settings#settings-section-legal";
    actions.append(settings, decline, agree);
    dialog.append(heading, version, terms, full, label, error, actions);
    dialog.addEventListener("cancel", event => { event.preventDefault(); close(); });
    dialog.addEventListener("keydown", event => {
      if (event.key === "Escape") event.stopPropagation();
      if (event.key !== "Tab") return;
      const controls = [...dialog.querySelectorAll("a[href], button:not(:disabled), input:not(:disabled), [tabindex='0']")]
        .filter(el => el.getClientRects().length > 0);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && (document.activeElement === first || document.activeElement === heading)) {
        event.preventDefault(); last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault(); first?.focus();
      }
    });
    // Native dialog makes the rest of the shell inert and contains keyboard focus.
    document.body.append(dialog); dialog.showModal(); heading.focus();
    async function load() {
      agreement = null;
      agree.disabled = true;
      const [document, current] = await Promise.all([api("/api/legal/eula"), api("/api/legal/eula/status")]);
      agreement = document; status = current;
      checkbox.disabled = false;
      version.textContent = `Version ${document.version}`;
      window.SMTOMarkdown.render(terms, document.display_template || document.text);
      if (document.display_template && typeof document.display_name === "string") {
        heading.textContent = `${document.display_name} End User License Agreement & Automation Risk Acknowledgment`;
        const walker = terms.ownerDocument.createTreeWalker(terms, NodeFilter.SHOW_TEXT);
        while (walker.nextNode()) {
          // Use the agreement's product name as literal text, never the assistant nickname.
          walker.currentNode.textContent = walker.currentNode.textContent.replaceAll(
            "{{brand.display_name}}", () => document.display_name);
        }
      }
      label.hidden = canExecute(); agree.hidden = canExecute();
      decline.textContent = canExecute() ? "Close" : "Decline";
      changed();
    }
    try { await load(); }
    catch (failure) {
      error.textContent = `Could not load the agreement. ${failure.message}`;
      error.append(button("Retry", () => { close(); void open(); }));
    }
  }

  function renderSettings() {
    if (!settingsHost) return;
    settingsHost.replaceChildren(node("p", "End User License Agreement & Automation Risk Acknowledgment"));
    if (status) {
      settingsHost.append(node("p", `Current version: ${status.current_version}`),
        node("p", `Accepted version: ${status.accepted_version || "None"}`),
        node("p", `Accepted date: ${status.accepted_at ? new Date(status.accepted_at).toLocaleString() : "Not accepted"}`));
    } else settingsHost.append(node("p", "Agreement status unavailable. Review the agreement to retry."));
    settingsHost.append(button(canExecute() ? "View agreement" : "Accept current version", () => void open()));
  }

  function mountSettings(host, nav) {
    const link = node("a", "Legal"); link.href = "#settings-section-legal"; nav.append(link);
    const section = node("details", "", "mission-settings-section");
    section.id = "settings-section-legal";
    section.dataset.sectionSearch = "legal eula end user license agreement acceptance terms";
    const summary = node("summary", "", "mission-settings-section-summary");
    summary.append(node("h2", "Legal"));
    settingsHost = node("div", "", "mission-section-body legal-settings");
    section.append(summary, settingsHost); host.append(section); renderSettings();
  }

  const ready = refresh().then(() => {
    if (!canExecute() && location.pathname !== "/settings") return open();
  }).catch(() => { if (location.pathname !== "/settings") return open(); });
  window.SMTOLegal = Object.freeze({ready, canExecute, open, refresh, mountSettings});
  window.addEventListener("smto:eula-required", () => {
    status = null; changed();
    if (!declined) void open();
  });
})();
