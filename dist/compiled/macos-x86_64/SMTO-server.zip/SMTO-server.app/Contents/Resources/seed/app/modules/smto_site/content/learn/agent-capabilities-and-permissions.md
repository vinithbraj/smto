---
{"title": "Choose which tools the assistant can use", "status": "published"}
---
## A tool needs both access and permission

A tool lets the assistant do something, such as read a file or search the web.
SMTO groups related tools into Skills. You may also see the word **capability**:
it means a kind of work the assistant can do with the available tools.

Installing a tool does not allow it to take every possible action. Reading a file
and changing that file may need different permissions. A tool that uses an online
service may also need you to connect an account.

## There are several checks before a tool runs

| Check | What it means |
| --- | --- |
| Installed | This SMTO setup has the tool. |
| Selected | The tool is relevant to the task. |
| Allowed | The task has permission to use it. |
| Approved | Any required approval for this action has been given. |
| Connected | The account or computer needed for the action is available. |

These are separate checks. The AI learning that a tool exists does not make the
tool run. Your approval of an action is not proof that it ran successfully.
The table explains the conditions; it does not prescribe the order of checks in
the software. Approval is needed only when the task's policy requires it.

## The assistant may ask for another tool

A task can reveal a need for something that was not selected at the start. The
assistant can request another Skill. SMTO checks whether that access is already
allowed, needs your decision, or is blocked.

If your approval is needed, review the request shown. A permitted change can let
the saved task continue with the new access. It does not erase other restrictions,
sign into an account, or approve every future change. The AI cannot approve its
own request by saying that you agreed.

## Read the reason when a tool cannot run

A missing account connection, an offline computer, and a blocked action need
different responses. Look at the message before changing settings. You may need
to reconnect a service, select an available computer, or leave the action blocked.

The assistant should not use another route simply to get around a denied action.
If the task cannot continue with the allowed tools, that limit should be clear.

## Review what actually happened

The activity history records requests for tools, access changes, approvals, and
blocked actions. It also shows tool results. Check the selected computer and action
before approving work, then check the result afterward.

Read [permissions and privacy](/security),
[the activity history guide](/docs/operations/activity),
[how SMTO manages tasks](/learn/what-is-an-agent-runtime), and
[how to check results](/learn/verifiable-agent-completion).
See [SMTO's features](/product) and [installation options](/download).
