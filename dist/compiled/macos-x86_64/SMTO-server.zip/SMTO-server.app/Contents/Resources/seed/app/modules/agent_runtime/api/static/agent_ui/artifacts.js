/* Generated files are immutable registry entries; rendering never scans or runs tools. */
(() => {
  "use strict";
  let session;
  const contexts = new WeakMap();
  const validId = value => /^art_[a-f0-9]{32}$/.test(value);
  const references = root => Array.from(root.querySelectorAll?.('.artifact-reference') || []);
  const node = (tag, text, className) => {
    const element = document.createElement(tag);
    if (text !== undefined) element.textContent = text;
    if (className) element.className = className;
    return element;
  };
  function url(id, context, action = '') {
    return `/api/agent/artifacts/${encodeURIComponent(id)}${action ? '/' + action : ''}?conversation_id=${encodeURIComponent(context.conversationId)}`;
  }
  function download(item, context) {
    const link = node('a', 'Download');
    link.href = url(item.artifact_id, context, 'download');
    link.setAttribute('aria-label', `Download ${item.display_name}`);
    return link;
  }
  function action(label, callback) {
    const button = node('button', label);
    button.type = 'button';
    button.onclick = callback;
    return button;
  }
  function capture(root) {
    const retained = new Map();
    const key = ref => JSON.stringify([ref.dataset.artifactId, ref.dataset.artifactLabel, ref.dataset.artifactImage]);
    for (const ref of references(root)) {
      const items = retained.get(key(ref)) || [];
      items.push(ref); retained.set(key(ref), items);
    }
    return () => {
      for (const ref of references(root)) {
        const old = retained.get(key(ref))?.shift();
        if (old) ref.replaceWith(old);
      }
    };
  }
  function contextFor(root) {
    for (let parent = root; parent; parent = parent.parentElement) {
      if (contexts.has(parent)) return contexts.get(parent);
    }
    return null;
  }
  function makeContext(parent, conversationId, apiJson) {
    const context = {parent, conversationId, cache: new Map(), data: new Map(), waiting: [], active: 0};
    // A per-turn queue bounds metadata/data work even for a response with many links.
    context.request = (path, options) => new Promise((resolve, reject) => {
      context.waiting.push(async () => {
        try {
          await authenticate(apiJson);
          let result;
          try { result = await apiJson(path, options); }
          catch (error) {
            if (error.status !== 401 && !/session|credential/i.test(error.message)) throw error;
            session = null;
            await authenticate(apiJson);
            result = await apiJson(path, options);
          }
          resolve(result);
        } catch (error) { reject(error); }
        finally { context.active--; pump(); }
      });
      pump();
    });
    function pump() {
      while (context.active < 4 && context.waiting.length) {
        context.active++;
        void context.waiting.shift()();
      }
    }
    contexts.set(parent, context);
    return context;
  }
  function resolve(id, context) {
    if (!context.cache.has(id)) {
      const record = {};
      record.promise = context.request(url(id, context)).then(item => {
        record.item = item;
        return item;
      }).catch(() => null);
      context.cache.set(id, record);
    }
    return context.cache.get(id);
  }
  function hydrate(root) {
    const context = contextFor(root);
    if (!context) return;
    window.SMTOMarkdown?.project(context.parent, context.attachmentProjection);
    for (const ref of references(root)) {
      const id = ref.dataset.artifactId;
      if (!validId(id)) continue;
      const record = resolve(id, context);
      if (ref._artifactRecord === record) continue;
      ref._artifactRecord = record;
      void record.promise.then(item => {
        if (!ref.isConnected || ref._artifactRecord !== record) return;
        if (!item || item.status !== 'available' || item.artifact_id !== id) {
          ref.replaceChildren(node('span', `Artifact unavailable · ${ref.dataset.artifactLabel || 'File'}`));
          ref.className = 'artifact-reference artifact-unavailable';
          return;
        }
        renderReference(ref, item, context);
      });
    }
  }
  function image(item, context, alt) {
    const img = node('img');
    img.alt = alt ?? item.display_name;
    img.loading = 'lazy'; img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.src = url(item.artifact_id, context, 'content');
    return img;
  }
  function highlightJson(code, text) {
    // Highlight tokens as text nodes. JSON is never interpreted as HTML or code.
    const pattern = /"(?:\\.|[^"\\])*"\s*:?|\b(?:true|false|null)\b|-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b/g;
    let offset = 0, count = 0;
    for (const match of text.matchAll(pattern)) {
      if (count++ >= 2048) break;
      code.append(document.createTextNode(text.slice(offset, match.index)));
      code.append(node('span', match[0], 'artifact-json-token'));
      offset = match.index + match[0].length;
    }
    code.append(document.createTextNode(text.slice(offset)));
  }
  function dataView(body, data) {
    body.replaceChildren();
    if (data.kind === 'csv') {
      const table = node('table'), head = node('thead'), heading = node('tr'), rows = node('tbody');
      for (const value of data.headers) {
        const th = node('th', value); th.scope = 'col'; heading.append(th);
      }
      head.append(heading);
      for (const values of data.rows) {
        const row = node('tr');
        for (const value of values) row.append(node('td', value));
        rows.append(row);
      }
      table.append(head, rows); body.append(table);
      body.append(node('p', `${data.counts_complete ? '' : 'At least '}${data.row_count} rows · ${data.column_count} columns${data.counts_complete ? '' : ' in sampled records'}`));
    } else {
      const pre = node('pre'), code = node('code');
      if (data.kind === 'json') highlightJson(code, data.text);
      else code.textContent = data.text;
      pre.append(code); body.append(pre);
      if (data.invalid_json) body.append(node('p', 'Invalid JSON; showing the original text.'));
      if (data.formatting_limited) body.append(node('p', 'Deeply nested JSON is shown as original text.'));
    }
    if (data.truncated) body.append(node('p', 'Preview is limited. Download the complete file.'));
  }
  function loadData(item, context) {
    if (!context.data.has(item.artifact_id)) {
      const promise = context.request(url(item.artifact_id, context, 'preview')).catch(error => {
        context.data.delete(item.artifact_id);
        throw error;
      });
      context.data.set(item.artifact_id, promise);
    }
    return context.data.get(item.artifact_id);
  }
  function openPreview(item, context, alt, opener) {
    const dialog = node('dialog', undefined, 'artifact-dialog markdown');
    dialog.setAttribute('aria-label', item.display_name);
    const header = node('div', undefined, 'artifact-dialog-header');
    const close = action('Close', () => dialog.close());
    header.append(node('strong', item.display_name), download(item, context), close);
    const body = node('div', undefined, 'artifact-preview-body');
    dialog.append(header, body);
    const observer = new MutationObserver(() => {
      if (!context.parent.isConnected) dialog.close();
    });
    observer.observe(document.body, {childList: true, subtree: true});
    dialog.addEventListener('close', () => {
      observer.disconnect(); dialog.remove(); opener?.focus();
    }, {once: true});
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    document.body.append(dialog);
    dialog.showModal(); close.focus();
    const kind = item.preview.kind;
    if (kind === 'image') {
      const img = image(item, context, alt);
      img.onerror = () => body.replaceChildren(node('p', 'Preview unavailable. Use Download to get the original.'));
      body.append(img);
    } else if (kind === 'html') {
      const frame = node('iframe');
      frame.title = item.display_name;
      frame.setAttribute('sandbox', 'allow-scripts');
      frame.referrerPolicy = 'no-referrer';
      frame.src = url(item.artifact_id, context, 'viewer');
      frame.onerror = () => body.replaceChildren(node('p', 'Preview unavailable. Use Download to get the original.'));
      body.append(frame, node('p', 'External resources are blocked in this preview.'));
    } else {
      body.append(node('p', 'Loading preview…'));
      void loadData(item, context).then(data => {
        if (dialog.isConnected) dataView(body, data);
      }).catch(() => {
        if (dialog.isConnected) body.replaceChildren(node('p', 'Preview unavailable. Use Download to get the original.'));
      });
    }
  }
  function previewControl(item, context, label, alt) {
    if (!item.preview?.enabled || item.sensitive) return null;
    if (item.preview.kind === 'pdf') {
      const link = node('a', label);
      link.href = url(item.artifact_id, context, 'viewer');
      link.target = '_blank'; link.rel = 'noopener noreferrer';
      return link;
    }
    const button = action(label, () => openPreview(item, context, alt, button));
    return button;
  }
  function renderReference(ref, item, context) {
    const {kind = 'file', reason = ''} = item.preview || {};
    const enabled = Boolean(item.preview?.enabled && !item.sensitive);
    const label = ref.dataset.artifactLabel;
    ref.className = 'artifact-reference artifact-card';
    const caption = node('span', undefined, 'artifact-caption');
    const type = kind === 'file' ? 'File' : kind.toUpperCase();
    caption.append(node('span', `${type} · ${item.display_name} · ${bytes(item.size_bytes)}`));
    if (item.sensitive) caption.append(node('strong', '🔒 Sensitive · download only', 'artifact-label'));
    if (label && label !== item.display_name) caption.append(node('span', label, 'artifact-label'));
    caption.title = `Generated during run ${item.run_id} · version ${item.version}`;
    const controls = node('span', undefined, 'artifact-actions');
    const preview = previewControl(item, context,
      kind === 'image' ? 'View' : ['html', 'pdf'].includes(kind) ? 'Open preview' : 'Preview', label);
    if (preview) controls.append(preview);
    controls.append(download(item, context));
    ref.replaceChildren();
    if (enabled && kind === 'image') {
      const button = action('', () => openPreview(item, context, label, button));
      button.className = 'artifact-image';
      button.setAttribute('aria-label', `Expand ${label || item.display_name}`);
      const img = image(item, context, label);
      img.onerror = () => button.replaceChildren(node('span', 'Preview unavailable'));
      button.append(img); ref.append(button);
    }
    ref.append(caption, controls);
    if (enabled && kind === 'csv') {
      void loadData(item, context).then(data => {
        if (caption.isConnected) caption.append(node('span',
          `${data.counts_complete ? '' : 'At least '}${data.row_count} rows · ${data.column_count} columns${data.counts_complete ? '' : ' in sampled records'}`,
          'artifact-label'));
      }).catch(() => {
        if (caption.isConnected) caption.append(node('span', 'Preview unavailable', 'artifact-label'));
      });
    }
    if (reason) ref.append(node('span', reason, 'artifact-label'));
  }
  async function authenticate(apiJson) {
    await window.SMTOReadPriority?.ready;
    if (!session) session = apiJson('/api/agent/artifact-session', {method: 'POST'})
      .catch(error => { session = null; throw error; });
    return session;
  }
  function bytes(value) {
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  }
  const groups = ['Images', 'Data', 'Documents', 'Interactive', 'Archives', 'Other'];
  function category(item) {
    // API derives the authoritative category from the sniffed MIME; older servers
    // still get a safe MIME-only fallback, never an extension-based promotion.
    if (groups.includes(item.category)) return item.category;
    const mime = item.mime_type || '';
    if (mime.startsWith('image/')) return 'Images';
    if (['text/csv', 'application/json', 'text/tab-separated-values'].includes(mime)) return 'Data';
    if (mime === 'text/html') return 'Interactive';
    if (['application/pdf', 'text/plain', 'text/markdown'].includes(mime)) return 'Documents';
    if (['application/zip', 'application/gzip', 'application/x-tar'].includes(mime)) return 'Archives';
    return 'Other';
  }
  function artifactRow(item, context) {
    const row = node('tr', undefined, 'artifact-center-file');
    row.dataset.artifactId = item.artifact_id;
    const name = node('td', undefined, 'artifact-table-name');
    const filename = node('span', item.display_name, 'artifact-filename');
    name.title = `${item.logical_relative_path || item.display_name} · ${bytes(item.size_bytes)} · v${item.version}${item.latest === false ? ' · Earlier version' : ''}`;
    const caption = node('span', undefined, 'artifact-table-caption');
    caption.append(filename);
    if (item.latest === false) caption.append(node('span', `v${item.version}`, 'artifact-version'));
    if (item.sensitive) {
      const sensitive = node('span', '🔒');
      sensitive.title = 'Sensitive · download only';
      sensitive.setAttribute('role', 'img');
      sensitive.setAttribute('aria-label', sensitive.title);
      caption.append(sensitive);
    }
    name.append(caption);
    const kind = item.preview?.kind || 'file';
    const type = node('td', kind === 'file' ? 'File' : kind.toUpperCase(), 'artifact-table-type');
    type.title = item.mime_type || type.textContent;
    const view = node('td');
    const preview = previewControl(item, context, 'View');
    if (preview) {
      preview.setAttribute('aria-label', `View ${item.display_name}`);
      view.append(preview);
    } else {
      const unavailable = node('button', 'View');
      unavailable.type = 'button'; unavailable.disabled = true;
      unavailable.title = item.sensitive ? 'Sensitive · download only' : item.preview?.reason || 'Preview unavailable';
      unavailable.setAttribute('aria-label', `View ${item.display_name}: ${unavailable.title}`);
      view.append(unavailable);
    }
    const save = node('td'); save.append(download(item, context));
    row.append(name, type, view, save);
    return row;
  }
  function render(root, artifacts, conversationId, collection = [], retry, context, result = {}) {
    const available = artifacts.filter(item => item.status === 'available' && validId(item.artifact_id));
    const pending = collection.filter(item => item.state && item.state !== 'idle');
    const title = node('summary', `Artifacts · ${available.length}`);
    root.replaceChildren(title);
    root.hidden = false; // Every run remains discoverable, including empty/deleted runs.
    const panel = node('section', undefined, 'artifact-center');
    panel.setAttribute('aria-label', 'Artifacts from this run');
    root.append(panel);
    context ||= {parent: root, conversationId};
    const runId = result.run_id || available[0]?.run_id;
    const build = () => {
      panel.replaceChildren(node('h3', 'Artifacts from this run'));
      const tools = node('div', undefined, 'artifact-center-tools');
      const filter = node('select');
      filter.setAttribute('aria-label', 'Filter artifacts');
      for (const group of ['All', ...groups]) {
        const option = node('option', group); option.value = group; filter.append(option);
      }
      filter.value = root._artifactFilter || 'All';
      tools.append(filter);
      if (runId && available.length) {
        const all = node('a', 'Download all');
        all.href = `/api/agent/native/${encodeURIComponent(runId)}/artifacts/download-all?conversation_id=${encodeURIComponent(conversationId)}`;
        all.setAttribute('aria-label', 'Download all artifacts for this run');
        if (result.export?.allowed === false) {
          all.removeAttribute('href'); all.setAttribute('aria-disabled', 'true');
        }
        tools.append(all);
      }
      panel.append(tools);
      panel.append(node('p', result.export?.message ||
        'Download all includes the latest version of each path and an artifact manifest.', 'artifact-label'));
      if (available.some(item => item.sensitive)) panel.append(node('p',
        '🔒 Download all includes sensitive files. Sensitive previews and thumbnails are disabled.', 'artifact-label'));
      const listing = node('div', undefined, 'artifact-center-list');
      const draw = () => {
        listing.replaceChildren();
        root._artifactFilter = filter.value;
        const items = available.filter(item => filter.value === 'All' || category(item) === filter.value);
        if (items.length) {
          const table = node('table', undefined, 'artifact-table');
          table.setAttribute('aria-label', 'Artifacts from this run');
          const head = node('thead'), heading = node('tr'), body = node('tbody');
          for (const label of ['Name', 'Type', 'View', 'Download']) {
            const th = node('th', label); th.scope = 'col'; heading.append(th);
          }
          head.append(heading);
          for (const item of items) body.append(artifactRow(item, context));
          table.append(head, body); listing.append(table);
        }
        if (!listing.children.length) listing.append(node('p', result.retired ?
          'Artifact unavailable · Files from this run have been deleted.' : 'No artifacts in this view.'));
      };
      filter.onchange = draw;
      draw(); panel.append(listing);
      for (const item of artifacts.filter(item => item.status !== 'available')) {
        panel.append(node('p', `Artifact unavailable · ${item.display_name} · v${item.version}`, 'artifact-unavailable'));
      }
      for (const item of pending) {
        panel.append(node('p', item.message || 'Artifact collection is pending.'));
        for (const error of item.errors || []) panel.append(node('p', `${error.path}: ${error.message}`));
      }
      const controls = node('div', undefined, 'artifact-center-controls');
      if (pending.length && retry) controls.append(action('Retry collection', retry));
      panel.append(controls);
      const retained = result.retention;
      if (retained && context.request) {
        const label = node('label', undefined, 'artifact-retention');
        label.append(node('span', 'Artifact retention for this conversation'));
        const select = node('select'); select.setAttribute('aria-label', 'Artifact retention');
        for (const [value, text] of [['conversation', 'Follow conversation retention'], ['7', '7 days'],
          ['30', '30 days'], ['90', '90 days'], ['forever', 'Keep until deleted']]) {
          const option = node('option', text); option.value = value; select.append(option);
        }
        select.value = retained.policy;
        const message = node('p', retained.explanation, 'artifact-label');
        message.setAttribute('role', 'status');
        select.onchange = async () => {
          select.disabled = true;
          try {
            const saved = await context.request(`/api/agent/native-conversations/${encodeURIComponent(conversationId)}/artifact-retention?policy=${encodeURIComponent(select.value)}`, {method: 'PUT'});
            retained.policy = saved.policy; message.textContent = `Saved. ${saved.explanation}`;
            window.dispatchEvent(new CustomEvent('smto:artifact-retention-changed', {detail: {conversationId}}));
          } catch (error) { select.value = retained.policy; window.SMTOErrors.present(message, error); }
          finally { select.disabled = false; }
        };
        label.append(select); controls.append(label); panel.append(message);
        if (retained.last_cleanup) panel.append(node('p',
          `Last cleanup: ${new Date(retained.last_cleanup.at * 1000).toLocaleString()}${retained.last_cleanup.error ? ' · ' + retained.last_cleanup.error : ''}`, 'artifact-label'));
      }
    };
    // Build the listing only when the user opens the center.
    root.ontoggle = () => { if (root.open) build(); };
    if (root.open) build();
  }
  function attach(parent, requestId, conversationId, apiJson, {actionContainer = null} = {}) {
    const context = makeContext(parent, conversationId || requestId, apiJson);
    const root = document.createElement('details');
    root.className = 'run-artifacts';
    root.hidden = true;
    root.open = false;
    parent.append(root);
    const openCenter = () => { root.open = true; root.scrollIntoView?.({block: 'nearest'}); };
    const detailArea = parent.querySelector?.('.work-disclosure, .activity');
    const shortcut = actionContainer
      ? action('Artifacts from this run', () => { if (root.open) root.open = false; else openCenter(); })
      : detailArea ? action('Artifacts · 0', openCenter) : null;
    if (actionContainer) {
      root.classList.add('run-artifacts-with-action');
      root.id = `run-artifacts-${requestId}`;
      shortcut.className = 'artifact-center-action';
      shortcut.setAttribute('aria-controls', root.id);
      shortcut.setAttribute('aria-expanded', 'false');
      root.addEventListener('toggle', () => shortcut.setAttribute('aria-expanded', String(root.open)));
      actionContainer.append(shortcut);
    } else if (shortcut) { shortcut.className = 'artifact-center-shortcut'; detailArea.append(shortcut); }
    let revision, busy = false, again = false;
    async function retryCollection() {
      try {
        await authenticate(apiJson);
        await apiJson(`/api/agent/native/${encodeURIComponent(requestId)}/artifacts/reconcile?conversation_id=${encodeURIComponent(conversationId || requestId)}`, {method: 'POST'});
        await refresh();
      } catch (error) {
        const message = document.createElement('p');
        window.SMTOErrors.present(message, error);
        root.append(message);
      }
    }
    async function refresh() {
      if (busy) { again = true; return; }
      busy = true;
      try {
        await authenticate(apiJson);
        let result;
        const url = `/api/agent/native/${encodeURIComponent(requestId)}/artifacts?conversation_id=${encodeURIComponent(conversationId || requestId)}`;
        try { result = await apiJson(url); }
        catch (error) {
          // A restarted server or expired browser session is recoverable without reload.
          if (error.status !== 401 && !/session|credential/i.test(error.message)) throw error;
          session = null;
          await authenticate(apiJson);
          result = await apiJson(url);
        }
        if (root.isConnected) {
          const items = result.artifacts || [];
          const byId = new Map(items.map(item => [item.artifact_id, item]));
          for (const [id, record] of context.cache) {
            if (!record.item || (record.item.run_id === result.run_id && !byId.has(id))) {
              context.cache.delete(id); context.data.delete(id);
            }
          }
          for (const item of items) {
            if (JSON.stringify(context.cache.get(item.artifact_id)?.item) !== JSON.stringify(item)) {
              context.cache.set(item.artifact_id, {item, promise: Promise.resolve(item)});
            }
          }
          render(root, items, conversationId || result.run_id, result.collection || [], retryCollection, context, result);
          if (shortcut) {
            const count = items.filter(item => item.status === 'available').length;
            if (actionContainer) shortcut.title = `${count} artifacts from this run`;
            else shortcut.textContent = `Artifacts · ${count}`;
          }
          context.attachmentProjection = result.attachment_projection;
          hydrate(parent);
        }
      } catch (error) {
        // Queued intent may not have a native run yet; the next snapshot refreshes it.
        if (/not found|unavailable in this conversation/i.test(error.message)) return;
        if (!root.isConnected) return;
        root.hidden = false;
        const title = document.createElement('summary');
        title.textContent = 'Artifacts';
        const message = document.createElement('p');
        window.SMTOErrors.present(message, error);
        const retry = document.createElement('button');
        retry.type = 'button'; retry.textContent = 'Retry'; retry.onclick = refresh;
        root.replaceChildren(title, message, retry);
      } finally {
        busy = false;
        if (again) { again = false; void refresh(); }
      }
    }
    const refreshEvent = event => {
      if (!root.isConnected) {
        window.removeEventListener('smto:artifacts-deleted', refreshEvent);
        window.removeEventListener('smto:artifact-retention-changed', refreshEvent);
        window.removeEventListener('smto:open-artifacts', openEvent);
      } else if (event.detail?.conversationId === context.conversationId) void refresh();
    };
    const openEvent = event => {
      if (root.isConnected && event.detail?.requestId === requestId) openCenter();
    };
    window.addEventListener('smto:open-artifacts', openEvent);
    window.addEventListener('smto:artifacts-deleted', refreshEvent);
    window.addEventListener('smto:artifact-retention-changed', refreshEvent);
    void refresh();
    return {root, action: actionContainer ? shortcut : null, refresh, open: openCenter, update(summary) {
      if (!summary) return;
      const next = `${summary.count}:${summary.revision}`;
      if (next !== revision) { revision = next; void refresh(); }
    }};
  }
  window.SMTOArtifacts = {attach, render, hydrate, capture};
})();
