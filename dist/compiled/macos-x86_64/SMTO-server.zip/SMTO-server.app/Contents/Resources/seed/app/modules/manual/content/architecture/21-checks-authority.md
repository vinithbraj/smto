---
id: checks-authority
title: Agent Checks and execution authority
kind: architecture
tags: [architecture, current, checks-authority]
order: 21
---
# Agent Checks and execution authority

Agent Checks are the named guard definitions in `runtime_guard_policy.py`. Categories
include completion/evidence, mutation/execution, environment/target, routing,
resource limits and recovery/convergence. Each definition records its enforcement owner,
resume strategy and bypass meaning. The resolver combines accepted snapshots with
versioned run overrides; the algorithm being controlled stays with its subsystem.

Capability policy controls which registered capabilities and executables are available.
Permission policy evaluates execution authority. Behavior policy guides decisions and
reuse. Unsafe-action policy controls dangerous operations and exact approval binding.
Changing one does not imply changing all the others or granting external permissions.

## Shared authority lifecycle

`native/authority_control.py` owns opening, correlation, recovery and safe presentation
of authority checkpoints. It makes no model calls and delegates decisions to these owners:

| Kind | Domain authority | Effect of an accepted decision |
| --- | --- | --- |
| Capability | Capability Authority and `native/capability_grants.py` | Update eligibility and renew the frozen run ceiling in a continuation, or accept an explicit-only trigger within the ceiling. |
| Permission | `permission_scopes.PermissionAuthority` and Permission Policy | Approve the exact pending operation or apply a revision-checked rule at the chosen scope. |
| Unsafe action | `execution/unsafe_authorization.py` | Accept one exact operation challenge with its existing volatile lifetime. |
| Agent Check override | `native/guard_strikes.py` and the guard registry | Change a run rule and use the guard's declared resume strategy. |

The native checkpoint retains bounded `authority_requests` envelopes and one foreground
`pending_authority_request_id`, with separate Activity pointers. Envelopes contain IDs,
digests, scope, revisions and safe labels. Invocation arguments remain in their existing
domain records. OAuth, credentials, unavailable implementations, target identity, hard
safety and OS permissions remain separate.

Existing reply routes are compatibility adapters. Desktop and mobile submit the common
request ID when available; supplied stale IDs are rejected. Duplicate replies cannot
create a second continuation or execution. Exact permission consent survives a crash
before resume starts and is retired when its pending operation is consumed. Unsafe
consent remains volatile: restart, expiry or revocation cannot recreate a usable grant.
Pause and Stop retain precedence over replies and admission. Existing domain events
remain the Activity Trace owners, so centralization does not add duplicate cards.

Checkpoint counters record prompts opened without inference and duplicate opens;
bounded process counters record rejected stale/conflicting decisions. They contain no
request text or credentials and rejection counters reset when the process restarts.

Agent Introspection, Memory and Shell are always selected in Automatic and Manual
capability selection. This prevents the selector or capability editor from removing
those Skills and their tools. It does not grant execution approval or bypass workflow
restrictions, Shell executable exclusions, target prerequisites or OS permissions.
Advisory mode allows local Memory while external Shell execution remains unavailable.
Only `agent.info` is exempt from an existing workflow tool fence.

`native/unsafe_actions.py` preflights concrete invocations before presenting an approval.
The binding includes arguments, operation/run/request identities, authority and resolved
inputs. The execution engine enforces the grant at execution. Background unsafe work
cannot bypass the captured foreground path. A prior grant is not blanket authority for
an unrelated command or target.

A guard rejection is a controller decision and can occur before a tool executes. An
execution error records what transport/provider execution actually did. Inspect receipt
metadata before assuming either means that external state is unchanged. Interrupted
mutations remain unknown until the appropriate reconciliation path supplies evidence.
Disabling a check does not rewrite that evidence. Redaction is an independent optional consumer projection. The retired secure-prompt guard is ignored; see [Redaction](31-redaction.md).

Unsafe approval has no password field. A missing or rejected sudo value returns to
the ordinary Agent loop. `execution/unsafe_authorization.py` retains only operation
digests, receipt identities and proven non-execution facts for bounded retries; it
does not store the password. The new invocation carries the literal password.
The original expiry, cancellation, pause and policy revocation rules remain in force.
A sequence retry preserves its completed prefix only when every prefix receipt
proves success and the failed child proves that execution never started.

## Monitoring disabled checks

Individual Agent Check switches continue to control enforcement. Fresh installations
start with four checks ON: **Enforce discovery-first routing**, **Enforce saved
HTTP connection reuse**, **Enforce temporal routing**, and **Strict tool schema
validation**. The other 27 checks start OFF.
**Settings → Agent Checks →
Monitor disabled Agent Checks** starts ON, so disabled checks can report observations
without enforcing them.

This preset is saved once when the settings database is first created. Existing
installations, explicit preferences and accepted run snapshots keep their settings;
an absent preference in an existing installation does not trigger the preset. The
registry's inherited fallback remains ON for the original 30 checks and OFF for
**Research proof validation**. That check controls proof requirements for research
completion, including generic citation, receipt, completeness and strict response
structure checks in research runs. Missing or unavailable research proof checks are
not enforced; generated answers remain available with their actual verification
status. **Disable all** changes enforcement switches independently of monitoring.

When monitoring is ON, a disabled check can assess its native fault condition and add an informational Activity note with **Learn more**. The Agent continues with the established disabled-check behavior. Monitoring makes no additional model calls, opens no approval prompts, adds no model guidance, and does not change tools, routes, arguments, budgets, receipt truth or completion acceptance. Enabled checks retain their normal enforcement without passive duplicates. With monitoring OFF, disabled detectors retain their existing fast paths.

`agent_checks.py` owns disposition and bounded reporting; native subsystems retain their predicates. `agent_check.observed` is diagnostic information, not a guard strike or authority to resume/retry. The strict boolean `disabled_agent_check_monitoring_enabled` is captured when work is accepted. Running, queued, resumed and continued work retain that snapshot; legacy/missing values resolve OFF.

## Productive thinking and generation quality

`protocol.generation_quality` detects sustained exact repetition in private reasoning
and inactivity in observable generation. It does not judge whether novel reasoning is
useful. Reasoning, answers, tool arguments and increasing provider generation counters
reset inactivity; whitespace, heartbeats and unchanged counters do not. Startup uses
the configured model request timeout until the first observable generation. A provider
without observable reasoning gets inactivity protection where progress is measurable,
but no reasoning-loop detection. Nonstreaming responses retain their normal transport
limits because intermediate generation progress is unavailable.

The exact-repeat detector keeps at most 65,536 characters per request/channel. It checks
periods up to 8,192 characters, requires six copies covering at least 8,192 characters,
and confirms across two checks separated by 1,024 new characters. Words, punctuation
and numbers are compared exactly. Repetitive answer text and tool arguments are diagnostic
only. Completed valid responses are not retroactively rejected. Activity and history
receive numeric evidence and reason codes, never the detector's private text buffer.

Thinking target (%) is guidance. Passing the target emits one continuing notice for the
pending decision; it does not discard thinking or consume output-growth attempts. Provider
token limits, task resource limits and output growth remain separate. The retired automatic
thinking-increase fields remain accepted by the API for compatibility. Budget state version 2
preserves the effective output allowance and pending output increase, counts that pending
increase as one output attempt, and drops pending thinking-limit recovery. Migration occurs once.

A generation-quality failure schedules one retry through the existing decision loop. It
retains the execution model, sampling settings, thinking configuration and effective output
allowance. A second failure pauses with completed work and receipts preserved, even if
malformed-response retry limits are disabled. The retry is recorded before dispatch, so
restart cannot replenish it. Explicit Resume starts a new bounded episode. Cancellation,
supersession and disabling the check invalidate its pending recovery. Rejected partial tool
calls never execute; completed operations are not automatically replayed.

Recovery thinking's Auto and Unchanged values preserve normal settings. Explicit thinking
overrides and Retry with thinking off remain opt-in and use the same single attempt.
Generation inactivity timeout (`llm_no_actionable_output_timeout_seconds`) and Recovery
inactivity timeout (`llm_constrained_recovery_timeout_seconds`) both default to 300 seconds
and accept 30–1,800 seconds. Saved values remain unchanged and now mean inactivity allowances.
Continuous progress can exceed either allowance and the soft thinking target. The optional
Total recovery deadline (`llm_recovery_deadline_seconds`, environment
`AOR_LLM_RECOVERY_DEADLINE_SECONDS`) defaults to 0/Off; 30–86,400 seconds imposes a total limit
from dispatch, including startup. An explicit total deadline applies even with the check off.
Rejected-stream cleanup remains separately bounded to at most 30 seconds. Task Contract and
capability-selection limits retain their own policies.

These changes do not enable checks or replace existing scoped preferences. Observe-only
monitoring reports the same conservative signal without rejecting generation or scheduling
recovery. Compare observation and enforcement using an offline replay with tool dispatch
disabled before enabling enforcement for a provider.
