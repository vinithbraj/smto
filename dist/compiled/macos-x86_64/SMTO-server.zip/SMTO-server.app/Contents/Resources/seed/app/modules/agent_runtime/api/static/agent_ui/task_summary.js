/* Deferred summaries are fetched from task storage; rendering never starts inference. */
(() => {
  function attach(turn, initial, {apiJson, conversationId}) {
    if (!turn.requestId || !initial) return;
    if (turn.taskSummary) { turn.meta.append(turn.taskSummary.action); return; }
    if (!initial.available && initial.status !== "in_progress" && initial.source !== "on_demand") return;
    const container = document.createElement("div");
    container.className = "task-summary";
    const action = document.createElement("button");
    action.type = "button";
    action.className = "task-summary-action";
    const error = document.createElement("span");
    error.className = "task-summary-error";
    error.setAttribute("role", "status");
    const output = document.createElement("div");
    output.className = "task-summary-text markdown";
    turn.meta.append(action);
    container.append(error, output);
    turn.meta.after(container);
    const suffix = conversationId ? `?conversation_id=${encodeURIComponent(conversationId)}` : "";
    const url = `/api/agent/native/${encodeURIComponent(turn.requestId)}/summary${suffix}`;
    const model = {value: initial, busy: false, timer: null, action};
    turn.taskSummary = model;

    function draw() {
      const value = model.value;
      const loading = model.busy || value.status === "in_progress";
      const generated = value.status === "generated";
      action.hidden = generated || (!value.available && !loading);
      action.disabled = loading;
      action.textContent = loading ? "Summarizing…" : value.status === "failed" ? "Retry summary" : "Summarize";
      action.setAttribute("aria-label", loading ? "Summarizing task" : action.textContent);
      container.setAttribute("aria-busy", String(loading));
      error.textContent = value.error || "";
      output.hidden = !generated || value.source !== "on_demand";
      if (!output.hidden) window.SMTOMarkdown.render(output, value.text || "");
      clearTimeout(model.timer);
      if (value.status === "in_progress" && !model.busy) {
        model.timer = setTimeout(() => { if (container.isConnected) void refresh(); }, 1500);
      }
    }
    async function refresh() {
      try {
        const result = await apiJson(url);
        model.value = result.summary;
      } catch (failure) {
        model.value = {...model.value, status: "failed", error: failure.message || "Could not load the summary."};
      }
      draw();
    }
    action.addEventListener("click", async () => {
      if (model.busy || model.value.status === "in_progress") return;
      model.busy = true;
      model.value = {...model.value, error: ""};
      draw();
      try {
        const result = await apiJson(url, {method: "POST"});
        model.value = result.summary;
      } catch (failure) {
        model.value = {...model.value, status: "failed", error: failure.message || "Could not generate the summary. Try again."};
      } finally {
        model.busy = false;
        draw();
      }
    });
    draw();
    if (!turn.historical) void refresh();
  }
  window.SMTOTaskSummary = {attach};
})();
