import "./advanced.js";
import "../../agent_checks.js?v=20261015-smto";
export const activities = (...args) => window.SMTOAgentChecks.activities(...args);
