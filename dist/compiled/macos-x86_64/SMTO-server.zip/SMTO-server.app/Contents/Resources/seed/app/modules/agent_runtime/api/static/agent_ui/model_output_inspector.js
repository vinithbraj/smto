/* A cheap collapsed disclosure; the transcript viewer loads only when opened. */
(() => {
  function attach(parent, requestId, callId) {
    const disclosure = document.createElement("details"), summary = document.createElement("summary");
    const panel = document.createElement("div");
    disclosure.className = "event-output trace-output model-output-inspector shell-live";
    summary.textContent = "Inspect thinking";
    disclosure.append(summary, panel); parent.append(disclosure);
    let loading = false;
    disclosure.addEventListener("toggle", async () => {
      if (!disclosure.open || panel.modelViewer || loading) return;
      loading = true; panel.textContent = "Loading model output…";
      try {
        const {mountModelOutput} = await import("/agent-ui/static/model_output_viewer.js?v=20261015-smto");
        if (!disclosure.isConnected || !disclosure.open) return;
        panel.replaceChildren();
        mountModelOutput({disclosure, panel, requestId, callId});
      } catch (_) { panel.textContent = "Could not load inspector. Close and reopen to retry."; }
      finally { loading = false; }
    });
    return disclosure;
  }
  window.SMTOModelOutput = {attach};
})();
