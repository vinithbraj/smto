---
id: architecture-http-rest
title: HTTP / REST Skill
kind: architecture
tags: [architecture, http, rest, parameters, gateway]
order: 25
---
# HTTP / REST Skill

For routine Proxmox server and guest operations, enable the optional
[Proxmox VE skill](../24-proxmox.md) and use its domain tools. It reuses this Gateway
HTTP authentication and transport implementation. Its typed **Proxmox Server**
parameter is distinct from the generic HTTP Connection profiles described below;
neither creating a profile nor registering a skill enables Proxmox automatically.

Use `http.request` for HTTP, REST and API work. It is advertised immediately when the selected Gateway supports HTTP. Use curl/wget only when the user explicitly requests them, or native HTTP reports a genuinely unsupported required feature and the task allows an alternative. Explicit user constraints on capabilities must be respected. TLS, authentication, profile and connection-reference failures are recoverable configuration problems; they do not imply that native HTTP is unsupported. Capability Policy remains the authority for deterministic tool exclusion.

```text
Agent chooses endpoint, method and literal connection configuration
  → existing Permission Policy and ExecutionEngine
  → HTTP capability and literal profile and OAuth session state
  → GatewayClient private envelope
  → selected Gateway: auth provider, session, TLS, target socket
  → bounded literal HTTP receipt
```

The Gateway retains private LAN, VPN, internal DNS and its own localhost reachability. The Agent backend never logs into the destination API. Inbound `POST /http/request` and outbound WebSocket dispatch use the same Gateway service and transaction engine.

## Gateway runtime readiness and updates

After a source update, `./install.sh` updates the main application environment and
the local Linux or macOS Gateway environment. `install-no-build.sh` inherits the
same setup; `AOR_SKIP_GATEWAY_SETUP=1` explicitly opts out for server-only hosts.
The platform installers share `scripts/update_gateway_runtime.py` and the
`pyproject.toml` dependency contract. Installation verifies `pip check` and
mandatory runtime imports, identifies the updated environment and fails if the
checks fail. Restart the local Gateway and smTO after updating; installers
do not restart them. Run the supported platform installer separately on each
remote Gateway host after updating its checkout. Windows uses
`src/gateway_windows/install.ps1`.

`GET /capabilities` reports `http_runtime.ready`. A missing mandatory HTTP
dependency removes `http_request` from both capability lists while other usable
Gateway capabilities remain available. Before collecting API credentials, the
Agent validates the public recipe and probes the selected Gateway's current
capabilities over its existing inbound or outbound route. A stale or legacy
advertisement without affirmative readiness cannot authorize secret collection.
No API credential is sent in that probe.

`http_gateway_dependency_missing` and `http_gateway_runtime_error` identify
Gateway runtime defects. Repair them by running the supported installer on that
Gateway host and restarting it. Endpoint or password changes do not repair a
broken environment. A known pre-dispatch failure reports `executed=false` and
`effect_unknown=false`; a target HTTP 404 remains an observed response with
`executed=true` and `status_code=404`. A dispatched write whose response is lost
retains `effect_unknown=true`. Error reasons survive into Results. OAuth waits use ordinary activity input; missing literal credentials return an ordinary authentication failure.

## Tools and connection discovery

| Tool | Effect | Purpose |
| --- | --- | --- |
| `http.request` | Dynamic | Structured API request; core when available |
| `http.connect` | Read | Establish a scoped one-off connection from literal authentication values and TLS configuration |
| `http.inspect_connections` | Read | List, search or get connection configuration |
| `http.manage_connection` | Write, normal confirmation | Create, update or delete literal configuration |
| `http.test_connection` | Read | Authenticate if needed and call a bounded configured test endpoint |

Discover the three connection tools with `discover_tools(skill_ids=["http"])`.

```json
{"query":"Proxmox"}
```

Call `http.inspect_connections` with that query, observe the returned canonical `profile_key`, then use it:

```json
{"method":"GET","profile_key":"Proxmox Lab","url":"/api2/json/cluster/resources","query":{"type":"vm"}}
```

If multiple connections match, ask the user which one. Neither first-row ordering, last use nor credential presence selects a secret profile. An already observed exact key can be used directly. Generic `parameters.inspect/manage` remains available; HTTP profiles use the ordinary parameter environment export.

## Parameter Store connections and storage

Parameter Store → **New → HTTP Connection** is the saved connection management surface. Its HTTP Connection tab supports structured configuration, literal credential editing, disconnect and a test from a selected Gateway; normal Parameter controls own metadata, rename and delete. Basic, Bearer, API Key, Session Login and OAuth2 templates are public prefills. The nickname is the Parameter key. Aliases and description support discovery. The editor accepts authentication metadata, TLS configuration, optional session/proxy settings and a test endpoint. Credential inputs show the stored literal values when PARAMETERS is off.

Saved HTTP connections are typed Parameter Store entries. `@production_api`
captures the exact accepted literal profile, including credentials, in the run
snapshot. PARAMETERS controls model and UI copies independently; execution uses
raw values. Profiles can be exported to the existing parameter shell environment.

The `/api/agent/http/connections/*` routes use the same Parameter Store. The editor
saves literal provider fields. Disconnect invalidates sessions; delete removes the
record and invalidates sessions. Raw reveal remains an explicit audited endpoint.

Version 1/2 profiles normalize to version 3 on read and save. Old credential maps,
slot references and unused values are preserved by migration. New profiles use v3:

```json
{
  "profile_type": "http_connection",
  "profile_version": 3,
  "base_url": "https://api.example.com/v1/",
  "default_headers": {"Accept": "application/json"},
  "auth": {"type": "bearer"},
  "tls": {"mode": "system"},
  "session": {"ttl_seconds": 3600, "reauthenticate_reads": true},
  "test_request": {"method": "GET", "url": "/health", "timeout_seconds": 15}
}
```

This profile contains literal authentication values. PARAMETERS controls inspection copies; it never changes the stored profile.

Stored credentials use the Parameter Store's existing sensitive-record semantics. This release does not introduce encryption at rest or a new vault/database; protect the existing local storage accordingly.

## Literal authentication

HTTP accepts literal authentication values in chat, tool arguments and saved v3
profiles. Missing values use ordinary `ask_user`; no credential form, volatile
password vault or credential-specific wait state is created. OAuth browser/device
authorization uses the ordinary user wait with its protocol-specific controls.

Saved profiles keep credentials in their provider fields. Legacy private maps and
credential slots migrate on normalization without dropping unused values. The
[Redaction settings](31-redaction.md) control consumer copies; all switches default
off. Raw authentication, receipts and recovery data remain unchanged by projection.

## Authentication providers

| Provider | Public configuration | Literal values / behavior |
| --- | --- | --- |
| `none` | None | No authentication |
| `basic`, `digest` | Optional `username` | `username` when no hint; `password`; Requests implementations |
| `bearer` | None | `token` → Bearer Authorization |
| `api_key_header` | `header_name`, optional `prefix`/`suffix` | `value` |
| `api_key_query` | `query_name` | `value`, optionally projected at URL/HTTP consumers |
| `api_key_cookie` | `cookie_name` | `value`, private cookie jar |
| `secret_headers` | `headers:[{name,value,prefix?,suffix?}]` | Literal header values |
| `session_login` | `login` specification below | Form/JSON login, cookies and extracted session values |
| `oauth2` | Grant and endpoint/client metadata | Client credentials, code + PKCE, device authorization and refresh |
| `ntlm` | Optional `username` | Install `.[http-ntlm]` on the Gateway; username/password |
| `negotiate` | None | Install `.[http-negotiate]`, native GSSAPI and valid Kerberos credentials on the Gateway |

Optional enterprise dependencies load lazily. Missing prerequisites return `http_auth_provider_unavailable`; no downgrade to Basic occurs. The source-controlled provider registry is the extension point for signers. AWS SigV4, OAuth1 and private-key JWT are not implemented; profiles cannot contain signing scripts.

### Generic session login and Proxmox examples

An API-token connection needs no service-specific client:

```json
{
  "profile_type":"http_connection",
  "profile_version":3,
  "base_url":"https://pve.example.internal:8006",
  "auth":{"type":"api_key_header","header_name":"Authorization","prefix":"PVEAPIToken="}
}
```

Set `auth.value` to the complete token credential.

A generic password/session profile expresses the ticket and CSRF flow entirely in metadata:

```json
{
  "profile_type":"http_connection",
  "profile_version":3,
  "base_url":"https://pve.example.internal:8006",
  "auth":{
    "type":"session_login",
    "login":{
      "path":"/api2/json/access/ticket",
      "method":"POST",
      "body_mode":"form",
      "fields":{
        "username":"root@pam",
        "password":"example-password"
      },
      "success_codes":[200],
      "extract":[
        {"source":"json","path":"/data/ticket","target":"cookie","name":"PVEAuthCookie"},
        {"source":"json","path":"/data/CSRFPreventionToken","target":"header","name":"CSRFPreventionToken","methods":["POST","PUT","PATCH","DELETE"]}
      ]
    }
  },
  "tls":{"mode":"custom_ca","ca_certificate":"-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"},
  "test_request":{"method":"GET","url":"/api2/json/cluster/resources"}
}
```

`body_mode` can be `form` or `json`. Fields are literal scalars, including username and password. Login is a bounded internal POST, not a second resource-mutation approval. Login redirects never carry credentials elsewhere.

Extraction supports RFC 6901 JSON pointers, named response headers and the actual cookie jar. Apply values to a cookie, header, query parameter or JSON/form body. `methods` restricts injection, and body injection requires explicitly configured mutating methods. Cookie and CSRF values remain available to the protocol and raw receipts; optional HTTP projection controls previews.

An expected login success status alone is insufficient when an API returns a
ticket in JSON without setting a reusable cookie. Missing or incomplete
extraction produces `http_session_mapping_required`, classified as
`authentication_configuration`. It means credentials were not rejected; inspect
authoritative API documentation and correct `session_cookie`, `session_values`
and/or CSRF extraction. Login bodies and returned tickets are never exposed in
that error. The literal recipe remains available for the next attempt.

Connection recipes retain literal authentication. Correcting extraction/session/test settings can establish a fresh session using those values. Saved revisions and run-scoped connection references retain their existing validation.

The Agent interprets `/cluster/resources` data and identifies running guests. Production HTTP code contains no VM filtering, PVE URL construction or service-specific parser.

### OAuth 2

Use `auth.type=oauth2` and `grant_type=client_credentials`, `authorization_code` or `device_authorization`. Configure `client_id`, `token_endpoint`, optional `scope`, `audience`/`resource`, and `client_auth=client_secret_basic|client_secret_post|none|tls_client_auth`.

For authorization code, configure `authorization_endpoint` and the exact `redirect_uri`:

```text
https://your-smto-host/api/agent/http/oauth/callback
```

The OAuth UI opens authorization. State, PKCE S256 verifier, expiry and single-use exchange are runtime-owned; callbacks cannot forward arbitrary redirects. Callback query strings are removed from application HTTP access logs. For device authorization, configure `device_authorization_endpoint`; the OAuth UI shows the verification page and user code. The runtime polls with provider intervals, `authorization_pending`, `slow_down`, denial and expiry handling.

Known access-token expiry triggers refresh before the resource call. Supplied access/refresh tokens can initialize a session. Newly exchanged session tokens remain in the HTTP session cache; callers may explicitly save literal token fields in a profile.

An `issuer` enables OIDC metadata discovery with exact issuer validation. Discovered endpoints must remain on a configured approved origin. If a provider uses a separate auth origin, add it explicitly to `allowed_origins`. OAuth resource-owner password grant is deliberately rejected.

## TLS, mTLS and proxies

TLS belongs to `http.connect` or a saved profile. Passing `tls` or other
connection-only fields to `http.request` is strictly rejected with
`http_connect_required`: call `http.connect` with the connection settings, then use
its exact returned `connection_ref`. The request schema does not accept TLS.

TLS modes are `system` (default), `custom_ca` or explicitly configured `insecure`. The UI prominently displays **TLS certificate verification disabled** for insecure profiles. A certificate failure returns `http_tls_verification_failed` with `failure_class=tls` and `recoverable_with_http=true`. Prefer a trusted private CA using `custom_ca`. Explicit `insecure` keeps HTTPS encryption but disables certificate identity verification for that connection. A certificate failure never causes an automatic insecure retry or a curl fallback. `allow_insecure_http` is a legacy compatibility field; literal credentials are accepted on HTTP without this switch.

Custom CA accepts a Gateway-local `ca_path` or `ca_certificate`. mTLS accepts paired `client_cert_path`/`client_key_path`, or paired `client_certificate`/`client_key`. Paths refer to the selected Gateway, never the Agent server. Literal PEM material uses unique temporary files with restricted permissions and cleanup. The same options apply to resource requests and OAuth client authentication.

Explicit `proxy.http`/`proxy.https` URLs are supported, with optional literal `username` and `password`. `trust_env=False` prevents inherited proxy credentials and netrc behavior.

Literal credentials are permitted over HTTP and HTTPS. Explicit TLS configuration and Gateway identity verification still apply; redaction does not change either.

## Requests, files and results

GET, HEAD and OPTIONS are reads. Other valid HTTP method tokens are writes; CONNECT and TRACE are blocked. Standard write confirmation remains unchanged. Ordinary auth handshakes execute internally after the operation has been authorized.

Use one body mode: native `json_body`, UTF-8 `text_body`, `form_body`, `multipart_body` or `body_reference`. Read methods cannot carry a body. Inline JSON/text/form bodies are bounded to 1 MiB. Serialized JSON objects/arrays still return `json_body_appears_serialized`; supply native JSON instead.

```json
{
  "method":"POST",
  "url":"https://api.example.com/upload",
  "multipart_body":{
    "fields":{"description":"Report"},
    "files":[{"name":"file","context_id":"ctx_observed_reference"}]
  }
}
```

Use an actual observed/granted context ID. No arbitrary file paths or inline base64 file copies are accepted. `body_reference:{context_id:...}` sends a granted source as raw bytes. Aggregate referenced content is bounded to 8 MiB to fit both Gateway transports.

Inline responses default to 256 KiB and are capped at 2 MiB. `response_mode=artifact` allows a bounded response up to 8 MiB; set `max_response_bytes` explicitly for larger downloads. The Gateway reads a bounded raw stream and returns a transfer envelope; the Agent retains it as a granted ContextStore source. The model receives a context ID, byte count, media type and SHA-256, not megabytes of base64. Temporary buffering is bounded; downloads are not unlimited.

Results retain method, URL, status/reason, headers, content type, body/encoding, bytes read, truncation/completeness, redirects, Gateway and execution status. Raw headers may include Set-Cookie. Optional HTTP projection masks the consumer copy without changing status, raw bytes or artifacts.

## Sessions, origins and failures

Gateway sessions are memory-only, bounded and synchronized. Identity includes run/connection, profile revision, credential material, Gateway instance and resource origin. Profile changes, credential replacement, delete, disconnect and run termination revoke reachable sessions through the private Gateway control envelope. If a Gateway is disconnected, old state is unreachable through the new identity and expires from memory; no cookies are persisted to disk.

Explicit authenticated URLs must remain on the profile origin or a configured allowed origin. `//attacker.example` cannot escape this check. Authenticated redirects remain on the current approved request origin; cross-origin forwarding and scheme downgrade are blocked by default.

A read with a definitive expired session can reauthenticate and retry once if `session.reauthenticate_reads` permits. A write is never automatically replayed on session expiry or ambiguous transport failure. Lost mutation responses still produce `HttpMutationOutcomeUnknown`. A failed login can report an executed authentication endpoint with `resource_executed=false`; it does not imply an executed resource mutation.

Errors distinguish missing/rejected credentials, unavailable providers, expired sessions, OAuth authorization/denial/expiry/state, TLS failure, invalid/missing profiles, unsafe target/Gateway transport and unavailable file contexts. ERRORS optionally projects diagnostic copies.
## One-off connections and recovery

For a new endpoint, call `http.connect` with `base_url`, literal `auth` values and optional `tls`. A literal recipe is retained during OAuth authorization, but only a successful connection is advertised in CURRENT TASK. Use the exact returned `connection_ref` with `http.request`; never invent or edit it. An unavailable reference requires an exact established reference or a new `http.connect` call. References remain scoped to the run, origin and selected Gateway. Saved profiles remain in Parameter Store.

For generic session login, configure `login_path`, `body_mode`, literal `username` and `password`, field names and documented extraction paths. Successful login still requires valid session extraction or a returned cookie. JSON extraction uses JSON Pointer.

Literal credentials are accepted in Shell, Web and ordinary HTTP fields. HTTP response receipts retain execution truth: a received 404 remains an executed response. Recovery never automatically replays mutations.

## Transient values for a saved profile

`http.connect({"profile_key":"Lab API","auth_values":{"username":"user",
"password":"literal value"}})` applies the values to a copy for the returned
connection. It never edits Parameter Store. Missing/rejected results advertise
`missing_fields`/`retry_fields` for a normal Agent question and retry. Supported
paths are provider leaves such as `token`, `value`, `client_secret`,
`login.fields.<name>`, `headers.<name>.value`, and proxy username/password. These
paths cannot change provider type, URLs, header names, extraction, TLS or origins.

The profile digest is bound when the connection is established. Editing its saved
configuration invalidates that reference; reconnect using the new configuration.
Saving credentials remains an explicit profile-management operation.

## Shared Auth Broker

A saved v3 HTTP connection may use `auth: {"type":"auth_ref",
"auth_ref":"work_identity","required_scopes":["api.read"]}` to consume a generic
Parameter Store OAuth connection. The controller's Auth Broker obtains and refreshes
tokens; a revision-bound private lease supplies the selected verified Gateway immediately
before a resource request. An unresolved `auth_ref` reaching the Gateway fails closed.
Existing inline HTTP OAuth profiles retain their supported v3 interface through
`auth/http_compat.py`. New shared connections use the generic
`/api/agent/auth/oauth/callback`; existing callback routes remain compatible.
See [Auth and Email](../26-auth-and-email.md).
