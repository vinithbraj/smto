---
{"title": "How an AI assistant works through a task", "status": "published"}
---
## Say what you want done

A clear request gives the assistant something you can check. For example:
“Read this text file and summarize its three main points.” Include the file you
mean and any limits, such as “Do not change the file.”

The AI model reads the request and chooses a tool. SMTO manages the actions and
keeps a record of the work. The repeated steps are sometimes called an execution
loop: choose an action, run it, read the result, then decide what to do next.

## SMTO checks the requested action

Before a tool runs, SMTO checks that it is available, that the request is valid,
and that the action is allowed on the selected computer. A useful action can still
need your permission or an account connection.

If an answer or approval is needed, the task can pause. A longer action can run
as a saved job. Starting a job does not mean it has finished.

## The tool returns a result

A file tool might return the text, report that the file is missing, or say access
was denied. SMTO saves the actual result. That saved record is sometimes called
a receipt. The AI receives information from the result for its next decision.

Long results may be shortened before they reach the AI. The full saved record
still exists, but the AI may need to ask for more detail before answering.

## The AI decides what to do next

If the file was read, the AI can write the summary. If the file was missing, it
may need to ask you which file you meant. If the task needs another tool, the
assistant can request access. That request does not bypass permission checks.

When a connection fails after an action starts, SMTO checks what happened before
repeating an action that might already have changed something.

## Review the final answer

When the AI says it is finished, SMTO checks for required results and unfinished
work where supported. The task may end with an answer, a partial result, an error,
or a cancellation. These checks cannot guarantee the answer is correct.

Compare the summary with the original file. The tool might have read it correctly
while the AI misunderstood it. The [activity history](/docs/operations/activity)
helps you see which steps ran.

Read about [interrupted tasks](/learn/durable-execution-for-ai-agents) and
[checking results](/learn/verifiable-agent-completion).
See [SMTO's features](/product) and [installation options](/download).
