/* One export, one live sentence. Timer ticks never replay the status animation. */
(() => {
  "use strict";
  const base = "/api/agent/settings/data/exports";
  function node(tag, className, parent, text = "") {
    const element = document.createElement(tag);
    element.className = className; element.textContent = text; parent.append(element);
    return element;
  }
  function duration(value) {
    const seconds = Math.max(1, Math.ceil(value));
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    return minutes < 60 ? `${minutes}m ${seconds % 60}s` : `${Math.floor(minutes / 60)}h ${minutes % 60}m`;
  }
  window.SMTOExportProgress = {create({host, announcement}) {
    const line = node("div", "data-export-status", host); line.hidden = true;
    const copy = node("span", "task-activity-copy", line);
    const label = node("span", "data-export-label", copy);
    const detail = node("span", "task-activity-detail data-export-time", copy);
    label.setAttribute("aria-hidden", "true");
    detail.setAttribute("aria-live", "off");
    let active = false, leaving = false, job = null, abort = null, timer = null;
    let value = null, observedAt = 0, dialog = null;

    function paint() {
      if (!value) return;
      const age = (performance.now() - observedAt) / 1000;
      let eta = value.remaining_seconds;
      const stale = active && age > 5;
      if (eta !== null && eta !== undefined && !stale) eta = Math.max(1, eta - age);
      const time = !active ? "" : eta != null && !stale ? `~${duration(eta)} remaining`
        : stale || value.estimating === "reestimating" ? "Re-estimating…" : "Estimating…";
      label.textContent = value.label;
      label.title = value.label;
      detail.textContent = time ? ` · ${time}` : "";
      window.SMTOActivityUpdates?.update(copy, {label: value.label, detail: detail.textContent,
        detailTransitionKey: value.stage, kind: active ? "runtime" : "terminal"});
    }
    function show(next) {
      value = next; observedAt = performance.now();
      line.hidden = false;
      announcement.classList.add("data-export-announcement");
      // The accessible live region only changes when the stage sentence changes.
      if (announcement.textContent !== next.label) announcement.textContent = next.label;
      paint();
    }
    async function request(path = "", options = {}) {
      const response = await fetch(base + path, {cache: "no-store", signal: abort?.signal, ...options});
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(typeof error.detail === "string" ? error.detail : "Export failed. Please retry.");
      }
      return response;
    }
    function delay(ms) {
      return new Promise((resolve, reject) => {
        const signal = abort.signal;
        if (signal.aborted) { reject(new DOMException("Cancelled", "AbortError")); return; }
        const cancelled = () => { clearTimeout(id); reject(new DOMException("Cancelled", "AbortError")); };
        const id = setTimeout(() => { signal.removeEventListener("abort", cancelled); resolve(); }, ms);
        signal.addEventListener("abort", cancelled, {once: true});
      });
    }
    function cancelRequest() {
      if (!job) return Promise.resolve();
      return fetch(`${base}/${job}/cancel`, {method: "POST", keepalive: true, cache: "no-store"}).catch(() => {});
    }
    function beforeUnload(event) {
      if (!active || leaving) return;
      event.preventDefault(); event.returnValue = "";
    }
    function departed() {
      if (!active) return;
      leaving = true;
      if (job && !navigator.sendBeacon?.(`${base}/${job}/cancel`)) void cancelRequest();
      abort?.abort();
      clearInterval(timer);
    }
    function confirmLeave(destination) {
      if (dialog?.open) return;
      dialog = node("dialog", "data-export-leave", document.body);
      const title = node("h2", "", dialog, "Cancel this export?");
      title.id = "data-export-leave-title";
      dialog.setAttribute("aria-labelledby", title.id);
      node("p", "", dialog, "An export is in progress. Leaving will cancel it.");
      const actions = node("div", "data-transfer-actions", dialog);
      const stay = node("button", "", actions, "Stay"); stay.type = "button";
      const leave = node("button", "", actions, "Cancel export and leave"); leave.type = "button";
      const close = () => { dialog?.close(); dialog?.remove(); dialog = null; };
      stay.onclick = close;
      dialog.addEventListener("cancel", event => { event.preventDefault(); close(); });
      leave.onclick = () => {
        leaving = true;
        void cancelRequest(); // keepalive survives the confirmed navigation.
        abort?.abort(); close();
        window.location.assign(destination);
      };
      dialog.showModal(); stay.focus();
    }
    function navigation(event) {
      if (!active || leaving || event.defaultPrevented || event.button !== 0
          || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      const link = event.target.closest("a[href]");
      if (!link || link.hasAttribute("download") || link.target && link.target !== "_self") return;
      const target = new URL(link.href, location.href);
      if (!["http:", "https:"].includes(target.protocol)) return;
      if (target.origin === location.origin && target.pathname === location.pathname
          && target.search === location.search && target.hash) return;
      event.preventDefault();
      confirmLeave(target.href);
    }
    async function download() {
      show({stage: "download", label: "Downloading JSON", remaining_seconds: null});
      const response = await request(`/${job}/download`);
      const total = Number(response.headers.get("Content-Length")) || null;
      const reader = response.body.getReader();
      const chunks = [];
      let received = 0, sampledBytes = 0, rate = null, samples = 0;
      const started = performance.now(); let sampledAt = started;
      try {
        while (true) {
          const {value: chunk, done} = await reader.read();
          if (done) break;
          chunks.push(chunk); received += chunk.byteLength;
          const now = performance.now(), seconds = (now - sampledAt) / 1000;
          if (seconds >= .25) {
            const measured = (received - sampledBytes) / seconds;
            rate = rate === null ? measured : .3 * measured + .7 * rate;
            sampledAt = now; sampledBytes = received; samples++;
          }
          if (seconds >= .25) show({stage: "download", label: "Downloading JSON", remaining_seconds:
            total && rate && samples >= 3 && now - started >= 2000 ? Math.max(1, (total - received) / rate) : null});
        }
      } finally { reader.releaseLock(); }
      if (abort.signal.aborted) throw new DOMException("Cancelled", "AbortError");
      if (total && received !== total) throw new Error("The download was interrupted. Export again to retry.");
      const url = URL.createObjectURL(new Blob(chunks, {type: "application/json"}));
      const link = node("a", "", document.body);
      link.href = url;
      link.download = response.headers.get("Content-Disposition")?.match(/filename="([^"]+)"/)?.[1]
        || "smto-backup.json";
      link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
    async function start(beforeExport) {
      if (active) return;
      active = true; leaving = false; job = null; abort = new AbortController();
      window.addEventListener("beforeunload", beforeUnload);
      window.addEventListener("pagehide", departed);
      document.addEventListener("click", navigation);
      show({stage: "saving", label: "Saving settings", remaining_seconds: null});
      timer = setInterval(paint, 1000);
      try {
        await beforeExport();
        if (abort.signal.aborted) throw new DOMException("Cancelled", "AbortError");
        show({stage: "snapshot", label: "Capturing application data", remaining_seconds: null});
        // Keep the creation response observable if cancellation races acceptance.
        let status = await (await request("", {method: "POST", signal: undefined})).json();
        job = status.id;
        if (abort.signal.aborted) { void cancelRequest(); throw new DOMException("Cancelled", "AbortError"); }
        let failures = 0;
        while (true) {
          if (status.state === "ready") break;
          if (["failed", "cancelled", "expired"].includes(status.state)) {
            throw new Error(status.error || "Export cancelled. Export again to retry.");
          }
          show(status);
          await delay(1000);
          try {
            status = await (await request(`/${job}`)).json(); failures = 0;
          } catch (error) {
            if (abort.signal.aborted || ++failures >= 3) throw error;
            status = {...status, label: "Reconnecting to export", remaining_seconds: null, estimating: "reestimating"};
          }
        }
        await download();
        active = false;
        show({stage: "complete", label: "JSON ready · Download started"});
      } catch (error) {
        void cancelRequest();
        active = false;
        show({stage: "failed", label: leaving ? "Export cancelled" : error.message || "Export failed. Please retry."});
      } finally {
        active = false; clearInterval(timer);
        window.removeEventListener("beforeunload", beforeUnload);
        window.removeEventListener("pagehide", departed);
        document.removeEventListener("click", navigation);
        dialog?.remove(); dialog = null;
      }
    }
    function hide() {
      if (active) return;
      line.hidden = true;
      announcement.classList.remove("data-export-announcement");
      window.SMTOActivityUpdates?.update(copy, {label: "", kind: "idle"});
    }
    return {start, hide};
  }};
})();
