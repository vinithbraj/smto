---
{"title": "Set up the AI and the computer doing the work", "status": "published"}
---
## The three parts can run together or separately

SMTO uses an AI model to decide what to do and tools to carry out the actions.
There are three main parts to set up:

- **AI model:** reads your request and chooses the next step.
- **Controller:** the main SMTO program, which manages tasks and saves results.
- **Gateway:** the SMTO program that runs tools on a selected computer.

They can share one computer or run on different computers on your private network.
This setup does not need an SMTO-hosted cloud service. Some tools may use their own
online services, which need separate connections.

## Choose where the AI runs

A local model runs on your computer or private network. A remote model runs through
an online provider. SMTO sends requests to the connection address you configure,
which is also called the model endpoint.

Use a supported connection and test a small task. Models differ in how well they
follow instructions and use tools. General settings changes apply to future work;
a saved task keeps the model settings accepted for that work.
See [AI model settings](/docs/configuration/models).

## Choose the computer that runs the tools

File and command tools run through the selected Gateway. Make sure you choose the
computer that holds the files or programs you want to use. A tool running on another
computer sees that computer's files, not the files on the computer with your browser.

A saved connection does not prove a computer is online. Check that it is available
and that the requested tool is installed and allowed.

One controller can keep connections to several Gateways. Different tasks can use
different selected computers. A task does not automatically run on every connected
computer, switch targets when one is unavailable, or share files between them.
Each target has its own files, programs, account connections and permissions.
Some tools run inside the controller or connect to services instead of a Gateway.

## Prepare for disconnected work

To work without an internet connection:

1. Install SMTO and the Gateway program on the computers you will use.
2. Set up a local AI model and download all its required files.
3. Install the tools and other software your tasks need.
4. Keep those parts connected on one computer or your private network.
5. Try a small task with internet access turned off and check the result.

Choose tasks that use files and tools already available there. Downloading new
software, searching the web, or using an online AI service still needs internet access.

## Review online connections

An online AI provider receives information sent with your requests. Tools may also
send data to other services. Check those connections before using private information.

Read [permissions and privacy](/security),
[using your own computer](/learn/local-first-ai-agents), and
[how AI and SMTO work together](/learn/model-server-vs-agent-runtime).
See [SMTO's features](/product) and [installation options](/download).
