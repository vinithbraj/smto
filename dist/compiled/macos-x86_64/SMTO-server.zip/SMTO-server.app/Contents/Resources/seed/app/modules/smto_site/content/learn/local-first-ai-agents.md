---
{"title": "Run SMTO on your own computer", "status": "published"}
---
## You choose where SMTO runs

You run SMTO's main program on a computer you control. That program manages tasks
and stores their progress. The guides sometimes call this setup **local-first**.
You do not need an SMTO-hosted cloud service to manage those tasks.

You can still choose a supported online AI service. A local installation does not
mean that every part of a task happens without an internet connection.

## Know the three parts of your setup

| Part | What it does |
| --- | --- |
| AI model | Reads your request and chooses the next action. It can run on your computer or through an online service. |
| SMTO controller | The main SMTO program. It checks permissions, manages tasks, and saves results. |
| Gateway | The SMTO program that runs file and command tools on the computer you choose. |

These parts can share one computer or run on different computers. Some tools also
use their own online services. Before starting a task, check which computer will
do the work and whether its tools are available.

## Check where your information goes

If you use an online AI service, the provider receives the information sent in the
request. This may include your instructions and text returned by tools. A local AI
model keeps those AI requests within your chosen computer or private network.

Tools can still contact online services even when the AI is local. For example,
web research needs access to websites. Review both the AI connection and the tools
when deciding how to handle private information.

## Choose a model for the task

SMTO does not automatically switch between local and online models for you. Choose
a supported model and try a small task. Different models can give different results.
Tasks already accepted keep their saved settings; a later change to general settings
does not silently replace the AI used by that work.

## Prepare before working offline

Install the AI model, its files, SMTO, and any tool requirements before disconnecting
from the internet. Keep the needed computers connected on your private network.
Choose tasks that use files and tools already available there.

Test the actual task with internet access turned off. Downloading files, searching
the web, and using an online AI service still need a connection.

Follow the [offline preparation steps](/learn/model-and-gateway#prepare-for-disconnected-work),
read [permissions and privacy](/security), and check
[AI model settings](/docs/configuration/models).
See [how AI and SMTO work together](/learn/model-server-vs-agent-runtime),
[SMTO's features](/product), and [installation options](/download).
