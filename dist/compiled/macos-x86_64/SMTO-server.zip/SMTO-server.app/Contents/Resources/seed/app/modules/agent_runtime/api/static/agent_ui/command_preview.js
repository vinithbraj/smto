/* Shared command display and exact-copy behavior for Activity and execution details. */
(() => {
  "use strict";
  const node = (tag, text, className = "") => {
    const el = document.createElement(tag); el.textContent = text || ""; el.className = className; return el;
  };
  function commandPreview(row, event, apiJson) {
    const preview = event.command_preview || event.detail?.command;
    if (typeof preview !== "string" || !preview) return null;
    const container = node("div", "", "activity-command"), code = node("code", preview);
    const pre = node("pre"), actions = node("div", "", "activity-command-actions");
    const copy = node("button", "", "copy-button activity-command-copy"), feedback = node("span", "", "sr-only");
    copy.type = "button"; feedback.setAttribute("role", "status");
    copy.title = "Copy command"; copy.setAttribute("aria-label", "Copy command");
    copy.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
    copy.dataset.inspectionAction = `copy:${event.command_detail_url || event.detail_url || preview}`;
    const copied = window.SMTOCopyFeedback?.bind(copy);
    let command = event.command_truncated ? null : preview, pending;
    async function fullCommand() {
      if (command != null) return command;
      if (!pending) pending = apiJson(event.command_detail_url || event.detail_url).then(value => {
        if (typeof value.detail?.command !== "string") throw new Error("Command unavailable");
        command = value.detail.command; return command;
      }).finally(() => { pending = null; });
      return pending;
    }
    copy.onclick = async event => {
      event.preventDefault(); event.stopPropagation();
      feedback.className = "sr-only"; feedback.textContent = "";
      try {
        const text = await fullCommand();
        try {
          if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
          await navigator.clipboard.writeText(text);
        } catch (_) {
          const input = node("textarea", text);
          input.style.cssText = "position:fixed;opacity:0;pointer-events:none";
          document.body.append(input); input.select();
          try { if (!document.execCommand("copy")) throw new Error("Clipboard unavailable"); }
          finally { input.remove(); copy.focus(); }
        }
        copied?.(); feedback.textContent = "Copied";
      } catch (_) {
        feedback.className = "activity-command-error";
        feedback.textContent = "Could not copy command. Try again.";
      }
    };
    if (event.command_truncated) {
      const expand = node("button", "Show full command"); expand.type = "button";
      expand.dataset.inspectionAction = `expand:${event.command_detail_url || event.detail_url || preview}`;
      expand.onclick = async () => {
        expand.disabled = true;
        try {
          code.textContent = await fullCommand(); actions.remove();
          feedback.className = "sr-only"; feedback.textContent = "";
        }
        catch (_) {
          feedback.className = "activity-command-error";
          feedback.textContent = "Could not load command. Try again."; expand.disabled = false;
        }
      };
      actions.append(expand);
      code.append(document.createTextNode("…"));
    }
    pre.append(code); container.append(pre, copy, feedback);
    if (event.command_truncated) container.append(actions);
    row.append(container);
    return container;
  }

  window.SMTOCommandPreview = {mount: commandPreview};
})();
