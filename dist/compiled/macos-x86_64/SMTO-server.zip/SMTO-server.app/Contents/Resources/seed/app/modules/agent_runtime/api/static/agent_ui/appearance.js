/* Shared typography/contrast presentation and serialized preference edits. No desktop dependencies. */
(() => {
  "use strict";
  const FONT = "ui_font_scale_percent", FAMILY = "ui_font_family", CONTRAST = "ui_high_contrast";
  const systemFont = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
  const fontOptions = [
    {value: "system", label: "System default", stack: systemFont},
    {value: "macos", label: "macOS (San Francisco)", stack: `-apple-system, BlinkMacSystemFont, "Helvetica Neue", ${systemFont}`},
    {value: "segoe-ui", label: "Windows (Segoe UI)", stack: `"Segoe UI", ${systemFont}`},
    {value: "ubuntu", label: "Ubuntu", stack: `Ubuntu, ${systemFont}`},
    {value: "cantarell", label: "Cantarell", stack: `Cantarell, ${systemFont}`},
    {value: "noto-sans", label: "Noto Sans", stack: `"Noto Sans", ${systemFont}`},
    {value: "dejavu-sans", label: "DejaVu Sans", stack: `"DejaVu Sans", ${systemFont}`},
    {value: "roboto", label: "Roboto", stack: `Roboto, ${systemFont}`},
    {value: "arial", label: "Arial", stack: `Arial, "Liberation Sans", ${systemFont}`},
    {value: "helvetica", label: "Helvetica", stack: `"Helvetica Neue", Helvetica, Arial, ${systemFont}`},
    {value: "verdana", label: "Verdana", stack: `Verdana, ${systemFont}`},
    {value: "georgia", label: "Georgia", stack: 'Georgia, "Times New Roman", "Liberation Serif", serif'},
  ];
  const fontStacks = new Map(fontOptions.map(option => [option.value, option.stack]));
  let localFonts = [];
  let fontDetection;
  /** Validate the same bounded family names accepted by the preference API. */
  const familyName = value => typeof value === "string" && [...value].length <= 200
    && !/[\u0000-\u001f\u007f-\u009f]/u.test(value) ? value.trim() : "";
  /** Retain preset IDs and installed family names, defaulting invalid stored values. */
  const normalizeFamily = value => familyName(value) || "system";
  /** Quote an installed name as one CSS family; preserve legacy presets and their fallbacks. */
  const fontStack = value => fontStacks.get(value)
    || `"${value.replace(/["\\]/g, "\\$&")}", ${systemFont}`;
  /** Validate, deduplicate and sort client results without sending the inventory to the server. */
  function uniqueFamilies(names) {
    const families = new Map();
    for (const name of names) {
      const family = familyName(name);
      if (family && !families.has(family.toLowerCase())) families.set(family.toLowerCase(), family);
    }
    return [...families.values()].sort((a, b) => a.localeCompare(b));
  }
  /** Detect usable client families when the browser cannot enumerate its installed fonts.
   * The static catalogue supplies candidates, not an inventory of the server's fonts.
   * Compare each candidate against several fallback metrics: fonts.check alone also
   * succeeds for missing system fonts. Browser-hidden and unknown families stay absent.
   */
  function detectBrowserFonts() {
    if (!fontDetection) fontDetection = (async () => {
      const response = await fetch("/agent-ui/static/font_families.json?v=20261010-browser-fonts");
      if (!response.ok) throw new Error("Font catalogue unavailable");
      const candidates = uniqueFamilies(await response.json());
      const context = document.createElement("canvas").getContext("2d");
      if (!context) throw new Error("Font detection unavailable");
      const samples = ["mmmmmmmmmmWWWiii0123456789", "漢字かな한글 العربية हिन्दी Ελληνικά Ж"];
      const fallbacks = ["monospace", "sans-serif", "serif"];
      const widths = font => {
        context.font = `48px ${font}`;
        return samples.map(sample => context.measureText(sample).width);
      };
      const baseline = fallbacks.map(widths), found = [];
      for (let i = 0; i < candidates.length; i++) {
        const family = candidates[i], quoted = `"${family.replace(/["\\]/g, "\\$&")}"`;
        if (fallbacks.some((fallback, index) => widths(`${quoted}, ${fallback}`)
          .some((width, sample) => Math.abs(width - baseline[index][sample]) > .01))) found.push(family);
        if (i % 20 === 19) await new Promise(resolve => setTimeout(resolve, 0));
      }
      return found;
    })().catch(error => { fontDetection = null; throw error; });
    return fontDetection;
  }
  const root = document.documentElement;
  let saved = {[FONT]: 100, [FAMILY]: "system", [CONTRAST]: false}, pending = {}, versions = {};
  let serial = 0, saving = false, timer, error = false, restoreFrame;
  const listeners = new Set();
  const normalize = settings => ({
    [FONT]: Number.isInteger(settings?.[FONT]) && settings[FONT] >= 80
      && settings[FONT] <= 200 && settings[FONT] % 10 === 0 ? settings[FONT] : 100,
    [FAMILY]: normalizeFamily(settings?.[FAMILY]),
    [CONTRAST]: settings?.[CONTRAST] === true,
  });
  const current = () => ({...saved, ...pending});
  function notify() { for (const listener of listeners) listener(); }

  function render() {
    const value = current(), previous = root.dataset.fontScale;
    const changed = previous !== String(value[FONT]) || root.dataset.fontFamily !== value[FAMILY];
    const viewport = changed ? document.querySelector("#conversation-viewport, #thread") : null;
    const content = viewport?.querySelector("#conversation, #messages");
    const atBottom = viewport && viewport.scrollHeight - viewport.scrollTop - viewport.clientHeight < 16;
    // Use the same visible turn as the history scroll owner, including nested/virtual pages.
    const turns = content?.querySelectorAll(".turn");
    const candidates = turns?.length ? Array.from(turns) : Array.from(content?.children || []);
    const view = viewport?.getBoundingClientRect();
    const anchor = candidates.find(el => {
      const box = el.getBoundingClientRect(); return box.top >= view.top && box.top < view.bottom;
    }) || candidates.find(el => el.getBoundingClientRect().bottom > view.top);
    const offset = anchor && anchor.getBoundingClientRect().top - viewport.getBoundingClientRect().top;
    root.dataset.fontScale = String(value[FONT]);
    root.dataset.fontFamily = value[FAMILY];
    root.dataset.fontEnlarged = String(value[FONT] > 100);
    root.dataset.contrast = value[CONTRAST] ? "high" : "normal";
    root.style.setProperty("--ui-font-scale", String(value[FONT] / 100));
    root.style.setProperty("--ui-font", root.dataset.mobileAppearance ? systemFont : fontStack(value[FAMILY]));
    if (changed) {
      // Font family also changes wrapping, composer height and navigator measurements.
      window.dispatchEvent(new CustomEvent("smto:font-scale", {detail: value[FONT]}));
      cancelAnimationFrame(restoreFrame);
      restoreFrame = requestAnimationFrame(() => {
        if (!viewport?.isConnected) return;
        if (atBottom) viewport.scrollTop = viewport.scrollHeight;
        else if (anchor?.isConnected) viewport.scrollTop +=
          anchor.getBoundingClientRect().top - viewport.getBoundingClientRect().top - offset;
      });
    }
    notify();
  }
  function apply(settings) {
    saved = normalize(settings);
    render();
  }

  async function save() {
    clearTimeout(timer);
    if (saving || !Object.keys(pending).length) return;
    const batch = {...pending}, sentVersions = {...versions};
    saving = true; error = false; notify();
    try {
      const response = await fetch("/api/agent/settings/preferences", {
        method: "PUT", cache: "no-store", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({settings: batch}),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = await response.json();
      saved = normalize(payload.settings);
      for (const key of Object.keys(batch)) {
        if (versions[key] === sentVersions[key]) delete pending[key];
      }
      window.dispatchEvent(new CustomEvent("smto:appearance-saved", {detail: payload.settings}));
    } catch (_) {
      error = true; // Retain the preview and latest edits until an explicit retry or another edit.
    } finally {
      saving = false; render();
      if (!error && Object.keys(pending).length) void save();
    }
  }
  function set(key, value) {
    if (![FONT, FAMILY, CONTRAST].includes(key)) return;
    pending[key] = normalize({...current(), [key]: value})[key];
    versions[key] = ++serial;
    error = false; render();
    clearTimeout(timer); timer = setTimeout(save, 350);
  }
  function element(tag, text, className = "") {
    const el = document.createElement(tag);
    if (text) el.textContent = text;
    el.className = className;
    return el;
  }
  function button(text, label, action) {
    const el = element("button", text);
    el.type = "button";
    if (label) el.setAttribute("aria-label", label);
    el.addEventListener("click", action);
    return el;
  }
  function createStepper({value = 100, onChange} = {}) {
    const group = element("div", "", "appearance-stepper");
    group.setAttribute("role", "group"); group.setAttribute("aria-label", "Font size");
    let percent = value;
    const output = element("output");
    output.setAttribute("aria-live", "polite"); output.setAttribute("aria-atomic", "true");
    const decrease = button("A−", "Decrease font size", () => onChange(percent - 10));
    const increase = button("A+", "Increase font size", () => onChange(percent + 10));
    const reset = button("Reset to 100%", null, () => onChange(100));
    function update(next) {
      percent = normalize({[FONT]: next})[FONT];
      if (output.value !== `${percent}%`) output.value = `${percent}%`;
      decrease.disabled = percent <= 80; increase.disabled = percent >= 200;
      reset.disabled = percent === 100;
    }
    group.append(decrease, output, increase, reset);
    group.update = update;
    update(value);
    return group;
  }
  /** Build the shared font control; enumeration stays local and only a selection calls onChange. */
  function createFontPicker({value = "system", onChange} = {}) {
    const picker = element("div", "", "appearance-font-picker");
    const fontSelect = element("select");
    fontSelect.name = FAMILY; fontSelect.setAttribute("aria-label", "Font");
    let selected, listedFonts, enumerated = false, detectionFinished = false, loadMessage = "";
    /** Retain saved families even when this browser cannot enumerate or render them. */
    function update(next) {
      next = normalizeFamily(next);
      if (selected !== next || listedFonts !== localFonts) {
        const options = new Map(fontOptions.map(option => [option.value, option.label]));
        const presets = new Set(fontOptions.flatMap(option => [option.label.toLowerCase(), option.value]));
        for (const family of localFonts) {
          if (!presets.has(family.toLowerCase())) options.set(family, family);
        }
        if (!options.has(next)) options.set(next, next);
        fontSelect.replaceChildren();
        for (const [name, label] of options) {
          const option = element("option", label);
          option.value = name; option.style.fontFamily = fontStack(name);
          fontSelect.append(option);
        }
        selected = next; listedFonts = localFonts;
      }
      fontSelect.value = selected;
    }
    fontSelect.addEventListener("change", () => { update(fontSelect.value); onChange(selected); });
    const status = element("p", "", "appearance-help");
    status.setAttribute("role", "status");
    /** Keep fallback discovery and permission requests from overwriting each other's status. */
    function showFontStatus() {
      status.textContent = load.disabled ? "Loading system fonts…" : enumerated
        ? `${localFonts.length} system font families loaded.`
        : `${detectionFinished ? `${localFonts.length} font${localFonts.length === 1 ? "" : "s"} detected on this device.`
          : "Finding fonts available on this device…"} ${loadMessage ||
          "Your browser may hide additional installed fonts."}`;
    }
    /** Enumerate from a click or an existing grant; never prompt during automatic detection. */
    async function loadSystemFonts() {
      if (load.disabled) return;
      load.disabled = true; status.textContent = "Loading fonts…";
      try {
        // Call directly from the click: browsers require user activation and local-fonts permission.
        const fonts = await window.queryLocalFonts();
        const families = uniqueFamilies(fonts.map(font => font.family));
        if (families.length) {
          localFonts = families; enumerated = true; loadMessage = "";
          update(selected);
        } else {
          loadMessage = "No fonts were shared. You can still choose a detected font.";
        }
      } catch (_) {
        loadMessage = "Could not load system fonts. You can still choose a detected font.";
      } finally { load.disabled = false; showFontStatus(); }
    }
    const load = button("Load system fonts", null, loadSystemFonts);
    load.hidden = typeof window.queryLocalFonts !== "function";
    showFontStatus();
    void detectBrowserFonts().then(families => {
      if (!enumerated) localFonts = uniqueFamilies([...localFonts, ...families]);
      detectionFinished = true; update(selected); showFontStatus();
    }).catch(() => {
      detectionFinished = true;
      loadMessage = "Automatic detection is unavailable. Choose a preset or use another font name.";
      showFontStatus();
    });
    if (!load.hidden && navigator.permissions?.query) {
      void navigator.permissions.query({name: "local-fonts"}).then(permission => {
        if (permission.state === "granted" && !enumerated) void loadSystemFonts();
      }).catch(() => {});
    }
    const custom = element("div", "", "appearance-custom-font");
    const input = document.createElement("input");
    input.type = "text"; input.maxLength = 200; input.placeholder = "Font family name";
    input.setAttribute("aria-label", "Font family name");
    input.autocomplete = "off"; input.spellcheck = false;
    /** Apply a validated family from manual entry without requiring enumeration permission. */
    function useFont() {
      const family = familyName(input.value);
      if (!family) {
        input.setCustomValidity("Enter a font family name (up to 200 characters, without control characters).");
        input.reportValidity(); return;
      }
      input.setCustomValidity(""); update(family); onChange(selected);
    }
    input.addEventListener("input", () => input.setCustomValidity(""));
    input.addEventListener("keydown", event => {
      if (event.key === "Enter" && !event.isComposing) { event.preventDefault(); useFont(); }
    });
    custom.append(input, button("Use font", null, useFont));
    const more = element("details", "", "appearance-font-manual");
    more.append(element("summary", "Use another font"), custom);
    picker.append(fontSelect, load, status, more);
    picker.select = fontSelect; picker.update = fontSelect.update = update;
    update(value);
    return picker;
  }
  function createEditor({showFontPicker = true} = {}) {
    const editor = element("div", "", "appearance-editor");
    const fontPicker = showFontPicker ? createFontPicker({value: current()[FAMILY], onChange: value => set(FAMILY, value)}) : null;
    const title = element("p", "Font size", "appearance-label");
    const stepper = createStepper({value: current()[FONT], onChange: value => set(FONT, value)});
    const label = element("label", "", "appearance-contrast");
    const toggle = document.createElement("input");
    toggle.type = "checkbox"; toggle.setAttribute("role", "switch");
    toggle.addEventListener("change", () => set(CONTRAST, toggle.checked));
    label.append(toggle, document.createTextNode("High contrast"));
    const status = element("p", "", "appearance-status");
    status.setAttribute("role", "status");
    const retry = button("Retry", "Retry saving appearance", save);
    if (fontPicker) editor.append(element("p", "Font", "appearance-label"), fontPicker,
      element("p", "Fonts must be installed on your device. Unavailable fonts use a fallback.", "appearance-help"));
    editor.append(title, stepper, label,
      element("p", showFontPicker ? "Font, font size and high contrast are shared across your devices." : "Mobile uses your device’s system font. Text size and high contrast are shared across your devices.", "appearance-help"), status, retry);
    function update() {
      fontPicker?.update(current()[FAMILY]);
      stepper.update(current()[FONT]); toggle.checked = current()[CONTRAST];
      status.textContent = error ? "Could not save appearance. Your changes are still shown here."
        : saving || Object.keys(pending).length ? "Saving appearance…" : "";
      retry.hidden = !error;
    }
    listeners.add(update); update();
    editor.dispose = () => listeners.delete(update);
    return editor;
  }
  function openDialog(returnFocus) {
    const dialog = element("dialog", "", "appearance-dialog");
    dialog.setAttribute("aria-label", "Appearance");
    const header = element("div", "", "appearance-dialog-header");
    header.append(element("h2", "Appearance"), button("×", "Close Appearance", () => dialog.close()));
    const editor = createEditor(); dialog.append(header, editor);
    dialog.addEventListener("close", () => {
      editor.dispose(); dialog.remove(); returnFocus?.focus({preventScroll: true});
    }, {once: true});
    document.body.append(dialog); dialog.showModal();
  }
  // Mobile keeps its existing per-browser theme choice, resolved before paint too.
  function applyMobileTheme() {
    let choice;
    try { choice = JSON.parse(localStorage.getItem("smto.agentUi.mobile.appearance")); } catch (_) {}
    if (["light", "dark"].includes(choice)) root.dataset.theme = choice;
    else delete root.dataset.theme;
  }
  window.SMTOAppearance = Object.freeze({apply, current, normalizeFamily, createFontPicker,
    createStepper, createEditor, openDialog, applyMobileTheme});
})();
