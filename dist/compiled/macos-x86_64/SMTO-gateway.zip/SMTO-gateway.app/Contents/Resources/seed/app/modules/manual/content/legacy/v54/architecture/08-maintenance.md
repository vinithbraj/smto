---
id: historical-v54-architecture-maintenance
title: Historical V54 - Maintenance Guide
kind: legacy
tags: [architecture, maintenance, docs]
summary: How to keep authored docs, legacy docs, generated references, tests, and launch scripts healthy.
order: 8
---

> Historical reference. See the current V55 architecture guide before using this material.

# Maintenance Guide

Keep the manual useful by preserving three layers: readable authored docs,
historical legacy source material, and generated references that make drift
visible. The served manual is canonical for current behavior.

## Updating Authored Pages

Add Markdown files under `src/manual/content`. Include frontmatter with `id`, `title`, `kind`, `tags`, `summary`, and `order`.

Use slug-only document IDs:

```text
lowercase-letters-numbers-and-dashes
```

## Updating Legacy Docs

Legacy docs are copied from root `docs/` into `src/manual/content/legacy`. The
loader infers metadata when no frontmatter exists. Treat these pages as
historical context, not the product source of truth. When behavior changes,
update authored manual pages first and leave legacy copies only when older
architecture notes are intentionally preserved.

## Checking Generated Pages

Generated references inspect source files under:

- `src/agent_runtime`
- `src/audio_runtime`
- `src/gateway_agent`
- `src/gateway_core`
- `src/llm`

Caches, artifacts, virtual environments, vendored files, and binaries are skipped.

Curated references such as System Surfaces And API Reference are authored
manually and should be updated whenever routes, standalone pages, settings
preferences, or UI drawer behavior changes. Generated references make source
drift visible, but they do not replace the curated reader-facing API map.
For Gmail changes, update the Gmail Integration manual page, Gmail Integration
Architecture, System Surfaces And API Reference, Configuration And Storage, and
any website cards that link to `data-manual-doc="gmail-integration"`.

## Test Commands

```bash
python -m pytest tests/test_manual_service.py
bash -n setup-manual.sh startmanual.sh
```

## Release Checklist

- Manual opens at `/manual`.
- Health returns `mode: manual`.
- Search works with and without FTS5.
- Legacy docs appear in the catalog.
- Legacy docs are labeled historical in the catalog and maintenance guidance.
- The current browser surfaces and API groups are represented in System
  Surfaces And API Reference.
- Gmail routes, account scoping, cache storage, OAuth configuration, and
  confirmation-gated mutations are represented when Gmail code changes.
- Root docs and served manual pages agree on settings persistence, standalone
  pages, drawers, and immersive-mode behavior.
- Generated route and environment pages reflect source changes.
- Mermaid diagrams render locally.
