/**
 * @file src/agent_runtime/api/static/agent_ui/stream_activity.js
 * @brief Keep bounded receipt history and render observed stream rates and context headroom.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Merge cumulative per-call observations into a 60-second ring, preserve
 * corrected input intervals and expose receipt/token/context series to desktop and mobile.
 * Boundaries: Receipts measure transport arrivals, not task success or model intent. The
 * owner supplies observations; this module opens no stream, fetch, store or model request.
 * Lifecycle: Owners create history, align the server clock, feed observations and request
 * samples. The optional desktop renderer repaints at 100 ms only while visible/enabled.
 * State: Caller-owned ring of 600 buckets, bounded source maps and context anchors. Server
 * time advances monotonically after alignment. Renderer timers/listeners have page lifetime;
 * pagehide clears the timer, and pageshow/visibility/preferences may restart painting.
 * Security: Validate numeric bounds before recording observations. Rates and retained
 * readouts are presentation estimates, never authority to retry or declare completion.
 * Collaborators: llm/stream_activity.py publishes receipt facts; rolling_history.js draws
 * paths; ui_session_state.js retains display preferences; app.js owns desktop history.
 * Public surface: SMTOStreamActivity exposes state creation, receipt/context ingestion,
 * clock alignment, sample projections, renderer construction and the fixed sampling bounds.
 * @see src/agent_runtime/llm/stream_activity.py
 * @see src/agent_runtime/api/static/agent_ui/rolling_history.js
 * @see src/agent_runtime/api/static/agent_ui/ui_session_state.js
 * @see src/agent_runtime/api/static/agent_ui/app.js
 */
(() => {
  "use strict";
  const bucketMs = 100, windowMs = 60000, maxSamples = windowMs / bucketMs;
  const refreshMs = 100, maxSourcesPerBucket = 64;
  /** Map a bucket-aligned timestamp to its reusable ring slot, including negative epochs. */
  const indexOf = t => ((t / bucketMs) % maxSamples + maxSamples) % maxSamples;
  /** Allocate an independent receipt/input slot for one aligned timestamp. */
  const empty = t => ({t, value: 0, sources: new Map(), inputs: new Map()});
  // Provider timestamps are server UTC. The viewing device may have a different
  // wall clock; after synchronization only monotonic elapsed time advances it.
  /** Use monotonic elapsed time after server alignment; fall back to device wall time initially. */
  const now = state => state?.clock
    ? state.clock.serverMs + performance.now() - state.clock.monotonicMs : Date.now();
  /** Align to valid server time without moving an established receipt clock backwards. */
  function syncClock(state, serverMs) {
    if (!Number.isFinite(serverMs) || serverMs <= 0) return;
    // A delayed clock response must not move behind a newer receipt observation.
    if (state.clock) serverMs = Math.max(serverMs, now(state));
    state.clock = {serverMs, monotonicMs: performance.now()};
    advance(state, serverMs);
  }
  /** Initialize caller-owned empty history; no renderer, subscription or timer is installed. */
  function create(now = Date.now()) {
    const state = {buckets: Array(maxSamples), latest: null,
      inputUpdates: new Map(), outputScales: new Map(), contextUpdates: []};
    advance(state, now);
    return state;
  }
  /** Advance at most one ring's slots and expire source metadata, preserving overlapping history. */
  function advance(state, nowMs = now(state)) {
    const latest = Math.floor(nowMs / bucketMs) * bucketMs;
    if (state.latest !== null && latest === state.latest) return;
    // Catch up after a background tab or a long idle in at most one ring's work.
    const first = Math.max(latest - windowMs + bucketMs,
      state.latest === null || latest < state.latest ? -Infinity : state.latest + bucketMs);
    for (let t = first; t <= latest; t += bucketMs) {
      // Initial clock alignment can move either way. Preserve existing receipt
      // slots at their server timestamps instead of resetting the history.
      if (state.buckets[indexOf(t)]?.t !== t) state.buckets[indexOf(t)] = empty(t);
    }
    state.latest = latest;
    for (const entries of [state.inputUpdates, state.outputScales])
      for (const [source, entry] of entries)
        if (entry.observed <= latest - windowMs) entries.delete(source);
    pruneContext(state);
  }
  /** Retain the last context level preceding the visible window as its left-edge anchor. */
  function pruneContext(state) {
    const updates = state.contextUpdates, first = state.latest - windowMs + bucketMs;
    // Retain one anchor before the visible window: available context is a level,
    // not a rate, and stays at its last observed value during silence.
    let expired = 0;
    while (expired + 1 < updates.length && updates[expired + 1].t <= first) expired++;
    if (expired) updates.splice(0, expired);
  }
  /** Forget context levels only, leaving receipt and token history intact. */
  function resetContext(state) { state.contextUpdates = []; }
  /** Insert a bounded percentage at its observation time; newer same-bucket facts win. */
  function receiveContext(state, remaining, observedAt = now(state)) {
    if (!Number.isFinite(remaining) || remaining < 0 || remaining > 100
        || !Number.isFinite(observedAt) || observedAt <= 0) return;
    if (state.clock && observedAt > now(state)) syncClock(state, observedAt);
    advance(state);
    const t = Math.floor(observedAt / bucketMs) * bucketMs;
    if (t > state.latest) return;
    const updates = state.contextUpdates;
    const index = updates.findIndex(point => point.t >= t);
    const point = {t, value: remaining, observedAt};
    if (index < 0) updates.push(point);
    else if (updates[index].t !== t) updates.splice(index, 0, point);
    else if (updates[index].observedAt <= observedAt) updates[index] = point;
    pruneContext(state);
  }
  /** Project a held context level across the ring; use null until the first known observation. */
  function contextSamples(state, nowMs = now(state)) {
    let index = 0, value = null;
    return samples(state, nowMs).map(point => {
      while (index < state.contextUpdates.length && state.contextUpdates[index].t <= point.t)
        value = state.contextUpdates[index++].value;
      return {t: point.t, value};
    });
  }
  /** Merge a source's cumulative receipt counts without adding replayed arrivals twice.
   * Validate time/count bounds; newer output calibration revises that call's past buckets,
   * rather than creating a false completion spike. Source limits bound per-slot ownership.
   */
  function receive(state, sample, source, nowMs = now(state)) {
    advance(state, nowMs);
    if (!source || sample?.bucket_ms !== bucketMs || !Array.isArray(sample.buckets)
        || !Number.isFinite(sample.observed_at_ms)) return;
    // The server clock snapshot was generated before its network trip. A newer
    // observation is a lower bound on server time, including after device sleep.
    if (state.clock && sample.observed_at_ms > nowMs) syncClock(state, sample.observed_at_ms);
    receiveInput(state, sample, source, state.clock ? now(state) : nowMs);
    const scaleUpdate = state.outputScales.get(source);
    if (Number.isFinite(sample.tokens_per_character) && sample.tokens_per_character >= 0
        && sample.tokens_per_character <= Number.MAX_SAFE_INTEGER
        && (!scaleUpdate || scaleUpdate.observed <= sample.observed_at_ms)
        && (scaleUpdate || state.outputScales.size < maxSamples * maxSourcesPerBucket))
      state.outputScales.set(source, {scale: sample.tokens_per_character, observed: sample.observed_at_ms});
    for (const bucket of sample.buckets.slice(-maxSamples)) {
      if (!Number.isSafeInteger(bucket?.t) || bucket.t % bucketMs !== 0
          || bucket.t > sample.observed_at_ms || bucket.t > state.latest
          || bucket.t <= state.latest - windowMs
          || !Number.isSafeInteger(bucket.chunks) || bucket.chunks <= 0) continue;
      const slot = state.buckets[indexOf(bucket.t)];
      // Totals are cumulative per call, not per session. Calls sharing an interval
      // add together, while replay and late aggregates replace only their own count.
      if (!slot.sources.has(source) && slot.sources.size >= maxSourcesPerBucket) continue;
      const previous = slot.sources.get(source) || {chunks: 0, characters: 0,
        scale: state.outputScales.get(source)?.scale ?? .25};
      slot.value += Math.max(0, bucket.chunks - previous.chunks);
      previous.chunks = Math.max(previous.chunks, bucket.chunks);
      if (Number.isSafeInteger(bucket.output_characters) && bucket.output_characters >= 0)
        previous.characters = Math.max(previous.characters, bucket.output_characters);
      slot.sources.set(source, previous);
    }
    // Final provider usage refines the call's existing history, never a spike
    // at completion. Timing remains an estimate based on output character arrivals.
    if (state.outputScales.has(source)) {
      for (const slot of state.buckets) {
        const receipt = slot?.sources.get(source);
        if (receipt) receipt.scale = state.outputScales.get(source).scale;
      }
    }
  }
  /** Replace a valid input-processing interval using revision/provenance precedence.
   * Remove all old slots for this source before distributing corrected segment tokens;
   * zero corrections remain meaningful and invalid/older reports leave history untouched.
   */
  function receiveInput(state, sample, source, nowMs) {
    const input = sample.input_processing;
    if (!input || !Number.isFinite(input.start_ms) || input.start_ms <= 0
        || !Number.isFinite(input.end_ms) || input.end_ms <= input.start_ms
        || input.end_ms > sample.observed_at_ms || input.end_ms > nowMs
        || !Number.isSafeInteger(input.tokens) || input.tokens < 0
        || typeof input.estimated !== "boolean") return;
    const segments = input.segments === undefined ? [input] : input.segments;
    if (!Array.isArray(segments) || !segments.length || segments.length > maxSamples) return;
    let lastEnd = input.start_ms;
    for (const segment of segments) {
      if (!Number.isFinite(segment?.start_ms) || !Number.isFinite(segment.end_ms)
          || segment.start_ms < lastEnd || segment.end_ms <= segment.start_ms
          || segment.end_ms > input.end_ms || !Number.isSafeInteger(segment.tokens)
          || segment.tokens < 0) return;
      lastEnd = segment.end_ms;
    }
    const previous = state.inputUpdates.get(source);
    const revision = Number.isSafeInteger(input.revision) && input.revision > 0 ? input.revision : 0;
    const rank = ["provider_progress", "provider_timing"].includes(input.source) ? 2
      : input.source === "usage" || !input.estimated ? 1 : 0;
    if (previous && (sample.observed_at_ms < previous.observed
        || (revision && previous.revision ? revision <= previous.revision : rank < previous.rank))) return;
    if (!previous && state.inputUpdates.size >= maxSamples * maxSourcesPerBucket) return;
    state.inputUpdates.set(source, {revision, rank, observed: sample.observed_at_ms});
    // A corrected interval can be shorter or move. Remove the whole old source
    // before replacement, including zero corrections and slots outside its new bounds.
    for (const slot of state.buckets) slot.inputs.delete(source);
    for (const segment of segments) {
      const first = Math.max(state.latest - windowMs + bucketMs,
        Math.floor(segment.start_ms / bucketMs) * bucketMs);
      for (let t = first; t < segment.end_ms && t <= state.latest; t += bucketMs) {
        const slot = state.buckets[indexOf(t)];
        if (!slot.inputs.has(source) && slot.inputs.size >= maxSourcesPerBucket) continue;
        const overlap = Math.min(t + bucketMs, segment.end_ms) - Math.max(t, segment.start_ms);
        slot.inputs.set(source, {tokens: (slot.inputs.get(source)?.tokens || 0)
          + segment.tokens * (overlap / (segment.end_ms - segment.start_ms)),
          estimated: input.estimated || !["provider_progress", "provider_timing"].includes(input.source)});
      }
    }
  }
  /** Advance history and return all 600 receipt-count points in chronological order. */
  function samples(state, nowMs = now(state)) {
    advance(state, nowMs);
    const first = state.latest - windowMs + bucketMs;
    return Array.from({length: maxSamples}, (_, index) => {
      const slot = state.buckets[indexOf(first + index * bucketMs)];
      return {t: slot.t, value: slot.value};
    });
  }

  /** Project independent one-second rolling input/output token totals at each ring point. */
  function tokenSamples(state, nowMs = now(state)) {
    const points = samples(state, nowMs), counts = [], inputCounts = [];
    return points.map((point, index) => {
      const slot = state.buckets[indexOf(point.t)];
      const tokens = [...slot.sources.values()].reduce((sum, receipt) =>
        sum + receipt.characters * receipt.scale, 0);
      counts.push(tokens);
      inputCounts.push([...slot.inputs.values()].reduce((sum, input) => sum + input.tokens, 0));
      // Sum this small window directly. Subtracting expired fractional counts
      // leaves positive roundoff in silent gaps, joining unrelated sections.
      const rolling = counts.slice(Math.max(0, index - 9)).reduce((sum, count) => sum + count, 0);
      const inputRolling = inputCounts.slice(Math.max(0, index - 9)).reduce((sum, count) => sum + count, 0);
      return {t: point.t, value: rolling, inputValue: inputRolling};
    });
  }

  /** Choose a readable token-axis ceiling with a floor of ten, without changing sample values. */
  function tokenMaximum(peak) {
    if (!(peak > 10)) return 10;
    const magnitude = 10 ** Math.floor(Math.log10(peak));
    return [1, 2, 2.5, 5, 10].find(step => step * magnitude >= peak) * magnitude;
  }

  /** Bind one desktop waveform root to existing history and page-lifetime display listeners.
   * Own the repaint timer and SVG nodes; retain history/readouts while collapsed or hidden.
   * Return a live-indicator update callback, with transport ownership left to the caller.
   */
  function createRenderer(root, state) {
    const svg = root.querySelector(".rolling-history"), line = root.querySelector(".stream-activity-line");
    const area = document.createElementNS("http://www.w3.org/2000/svg", "path");
    area.setAttribute("class", "stream-token-area");
    area.setAttribute("aria-hidden", "true");
    const inputArea = document.createElementNS("http://www.w3.org/2000/svg", "path");
    inputArea.setAttribute("class", "stream-input-area");
    inputArea.setAttribute("aria-hidden", "true");
    const inputLine = document.createElementNS("http://www.w3.org/2000/svg", "path");
    inputLine.setAttribute("class", "stream-input-line");
    inputLine.setAttribute("aria-hidden", "true");
    const contextLine = document.createElementNS("http://www.w3.org/2000/svg", "path");
    contextLine.setAttribute("class", "stream-context-line");
    contextLine.setAttribute("aria-hidden", "true");
    const panel = root.closest(".run-activity");
    const toggle = panel?.querySelector(".activity-toggle");
    const sizeToggle = root.querySelector(".stream-size-toggle");
    const modes = [...root.querySelectorAll("[data-stream-mode]")];
    const palettes = [...root.querySelectorAll("[data-stream-palette]")];
    const rate = root.querySelector(".stream-token-value");
    const inputRate = root.querySelector(".stream-input-value");
    const inputQuality = root.querySelector(".stream-input-quality");
    const contextValue = root.querySelector(".stream-context-value");
    const chart = root.querySelector(".stream-chart");
    const inputAxis = [...root.querySelectorAll('[data-token-axis="input"] [data-token-tick]')];
    const outputAxis = [...root.querySelectorAll('[data-token-axis="output"] [data-token-tick]')];
    /** Format displayed rates using the device locale without altering stored measurements. */
    const format = value => value.toLocaleString(undefined, {maximumFractionDigits: 1});
    let mode = window.SMTOUiSession.get("waveform_mode", "trace");
    let palette = window.SMTOUiSession.get("waveform_palette", "teal-blue");
    let timer = null, lastPaint = -Infinity, maximized = false;
    let lastInputRate = 0, lastOutputRate = 0, lastInputQuality = "Est.";
    /** Paint only visible enabled plots, throttling to 100 ms and retaining silent readouts. */
    function tick() {
      clearTimeout(timer); timer = null;
      if (document.hidden || root.hidden || !enabled()) return;
      const delay = refreshMs - (performance.now() - lastPaint);
      if (delay > 0) { timer = setTimeout(tick, Math.ceil(delay)); return; }
      const tokens = mode === "tokens";
      const points = tokens ? tokenSamples(state) : samples(state);
      const peak = Math.max(4, ...points.map(point => point.value));
      const maximum = tokenMaximum(peak);
      // A visual floor keeps even one receipt legible; zero stays exactly zero.
      /** Scale receipt heights logarithmically; retain a visible positive floor and exact zero. */
      const normalize = value => value > 0 ? Math.max(.15, Math.log1p(value) / Math.log1p(peak)) : 0;
      const width = Math.max(48, Math.round(svg.clientWidth));
      const height = Math.max(1, Math.round(svg.clientHeight));
      const viewBox = `0 0 ${width} ${height}`;
      if (svg.getAttribute("viewBox") !== viewBox) svg.setAttribute("viewBox", viewBox);
      const geometry = {end: points.at(-1).t + bucketMs, windowMs, width, height,
        bucketMs: tokens ? 0 : bucketMs, normalize: tokens ? value => value / maximum : normalize};
      const linePath = window.SMTORollingHistory.path(points, geometry);
      line.setAttribute("d", linePath);
      if (tokens) {
        // Each direction fills its own vertical range. Large prompt rates must
        // not flatten the output series, or vice versa.
        const inputMaximum = tokenMaximum(Math.max(...points.map(point => point.inputValue)));
        const inputPath = window.SMTORollingHistory.path(
          points.map(point => ({t: point.t, value: point.inputValue})),
          {...geometry, normalize: value => value / inputMaximum});
        const lastX = width - 1 - bucketMs / windowMs * (width - 2);
        /** Close a token stroke to the graph baseline for the corresponding translucent fill. */
        const filled = path => `${path} L${lastX.toFixed(2)},${height - 1} L1,${height - 1} Z`;
        area.setAttribute("d", filled(linePath));
        inputArea.setAttribute("d", filled(inputPath));
        inputLine.setAttribute("d", inputPath);
        const context = contextSamples(state);
        contextLine.setAttribute("d", window.SMTORollingHistory.path(context,
          {...geometry, normalize: value => value / 100}));
        const remaining = context.at(-1).value;
        const contextLabel = remaining === null ? "unavailable" : `${format(remaining)}%`;
        if (contextValue) window.SMTONumberOdometer.render(contextValue, remaining === null ? "—" : contextLabel);
        inputAxis.forEach(label => { window.SMTONumberOdometer.render(label, format(inputMaximum * Number(label.dataset.tokenTick))); });
        outputAxis.forEach(label => { window.SMTONumberOdometer.render(label, format(maximum * Number(label.dataset.tokenTick))); });
        const inputs = state.buckets.flatMap(slot => [...slot.inputs.values()]);
        const measured = inputs.some(input => !input.estimated);
        const estimated = inputs.some(input => input.estimated);
        const quality = measured ? estimated ? "Mixed" : "Measured" : "Est.";
        // Hold each readout independently during silence. Keep the plotted
        // history unchanged, and ignore tiny rates that would display as zero.
        if (Math.round(points.at(-1).value * 10) > 0) lastOutputRate = points.at(-1).value;
        if (Math.round(points.at(-1).inputValue * 10) > 0) {
          lastInputRate = points.at(-1).inputValue;
          lastInputQuality = quality;
        }
        window.SMTONumberOdometer.render(rate, format(lastOutputRate));
        window.SMTONumberOdometer.render(inputRate, format(lastInputRate));
        if (inputQuality) inputQuality.textContent = lastInputQuality;
        const description = lastInputQuality !== "Est." ? `${lastInputQuality} input and estimated output tokens`
          : "Estimated input and output tokens";
        svg.setAttribute("aria-label", `${description} per second over the last minute, averaged over one second. Displayed input ${format(lastInputRate)}, output ${format(lastOutputRate)}; counters retain their last non-zero readings during silence. Left input scale 0 to ${format(inputMaximum)}, right output scale 0 to ${format(maximum)} tokens per second. Token rates scale independently. Context remaining ${contextLabel}, solid line with 100 percent at the top and 0 percent at the bottom, held at the latest recorded value until the next context update.`);
      }
      lastPaint = performance.now();
      timer = setTimeout(tick, refreshMs);
    }
    /** Set the caller's live presentation flag without starting or stopping any transport. */
    function update(live) {
      if (root.dataset.live !== String(live)) root.dataset.live = String(live);
    }
    /** Apply disclosure/preference state and accessibility labels while retaining maximized size. */
    function renderExpanded(expanded) {
      root.hidden = !enabled() || !expanded;
      // Collapsing hides the plot without forgetting its size or captured bounds.
      panel?.classList.toggle("wavelet-maximized", maximized && !root.hidden);
      if (toggle) toggle.hidden = !enabled();
      toggle?.setAttribute("aria-expanded", String(!root.hidden));
      const label = root.hidden ? "Expand timeline waveform" : "Collapse timeline waveform";
      toggle?.setAttribute("aria-label", label);
      if (toggle) toggle.title = label;
    }
    /** Read the page's waveform preference; absence preserves its enabled default. */
    const enabled = () => document.documentElement.dataset.waveletEnabled !== "false";
    /** Resize within the existing activity panel, preserve composer space and repaint immediately. */
    function renderMaximized(value) {
      if (!panel || !sizeToggle) return;
      // Capture the current border box before hiding the toolbar and timeline.
      // Only the plot grows; the composer and conversation keep their space.
      if (value) panel.style.setProperty("--wavelet-panel-height", `${panel.getBoundingClientRect().height}px`);
      else panel.style.removeProperty("--wavelet-panel-height");
      maximized = value;
      panel.classList.toggle("wavelet-maximized", maximized);
      sizeToggle.setAttribute("aria-expanded", String(maximized));
      const label = maximized ? "Restore graph size" : "Maximize graph";
      sizeToggle.setAttribute("aria-label", label);
      sizeToggle.title = label;
      lastPaint = -Infinity;
      tick();
    }
    sizeToggle?.addEventListener("click", () => renderMaximized(!maximized));
    panel?.addEventListener("keydown", event => {
      if (event.key === "Escape" && maximized && !root.hidden) {
        event.preventDefault();
        renderMaximized(false);
        sizeToggle.focus();
      }
    });
    /** Apply the selected palette and pressed-state accessibility without changing observations. */
    function renderPalette() {
      root.dataset.palette = palette;
      palettes.forEach(button => button.setAttribute("aria-pressed", String(button.dataset.streamPalette === palette)));
    }
    palettes.forEach(button => button.addEventListener("click", () => {
      palette = button.dataset.streamPalette;
      window.SMTOUiSession.set("waveform_palette", palette);
      renderPalette();
    }));
    /** Switch receipt/token paths and accessible descriptions without rebuilding history. */
    function renderMode() {
      root.dataset.mode = mode;
      modes.forEach(button => button.setAttribute("aria-pressed", String(button.dataset.streamMode === mode)));
      chart?.setAttribute("data-mode", mode);
      if (mode === "tokens") {
        // Both translucent fills sit behind all three strokes, keeping overlaps legible.
        svg.insertBefore(area, line);
        svg.insertBefore(inputArea, line);
        svg.append(inputLine, contextLine);
      } else { area.remove(); inputArea.remove(); inputLine.remove(); contextLine.remove(); }
      if (mode === "trace") svg.setAttribute("aria-label", "Response stream receipts over the last minute");
      lastPaint = -Infinity;
      tick();
    }
    modes.forEach(button => button.addEventListener("click", () => {
      mode = button.dataset.streamMode;
      window.SMTOUiSession.set("waveform_mode", mode);
      renderMode();
    }));
    /** Restore the session disclosure preference after appearance changes and reevaluate painting. */
    function applyPreference() {
      renderExpanded(window.SMTOUiSession.get("waveform_expanded", true));
      tick();
    }
    renderPalette();
    renderExpanded(window.SMTOUiSession.get("waveform_expanded", true));
    renderMode();
    toggle?.addEventListener("click", () => {
      if (!enabled()) return;
      renderExpanded(root.hidden);
      window.SMTOUiSession.set("waveform_expanded", !root.hidden);
      // Receipt history continues accumulating while only painting is paused.
      tick();
    });
    document.addEventListener("visibilitychange", tick);
    window.addEventListener("smto:appearance", applyPreference);
    window.addEventListener("pagehide", () => { clearTimeout(timer); timer = null; });
    window.addEventListener("pageshow", tick);
    update(false);
    tick();
    return {update};
  }
  window.SMTOStreamActivity = {create, advance, receive, samples, now, syncClock,
    receiveContext, resetContext, contextSamples,
    tokenSamples, tokenMaximum, createRenderer, bucketMs, windowMs, maxSamples, refreshMs, maxSourcesPerBucket};
})();
