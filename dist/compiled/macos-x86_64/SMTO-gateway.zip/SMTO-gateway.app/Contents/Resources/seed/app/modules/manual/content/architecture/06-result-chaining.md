---
id: result-chaining
title: Exact results and JSON Pointer
kind: architecture
tags: [architecture, tools]
order: 6
---
# Exact results and JSON Pointer

Use one RFC 6901 string JSON Pointer for exact nested addressing. `src/agent_runtime/execution/json_pointer.py:resolve_pointer` powers bindings, `read_result` and completion checks.

```json
{"input_bindings":[{"input_name":"patient_id","source_operation_id":"observed-operation-id","source_pointer":"/rows/0/patient_id"}]}
```

The engine passes the exact JSON value as `inputs.patient_id`, preserving strings, newlines, Unicode, empty strings, false, zero, null, arrays and objects. The model does not have to transcribe it. The receiving tool must declare `input_bindings` and `inputs` in its argument schema.

| Pointer | Meaning |
| --- | --- |
| empty string | Whole result data |
| `/stdout` | Top-level stdout |
| `/response/user/id` | Nested object value |
| `/rows/0/id` | First array item ID |
| `/a~1b/~0key` | Keys `a/b` then `~key` |
| `/` | Empty object key |

Arrays require unsigned decimal indices without leading zeros. Missing keys, invalid escapes, out-of-range indices and traversal through scalars produce precise errors. Dotted paths, bracket syntax, URI fragments and fallback guessing are not supported.

Bindings require a successful, executed, complete receipt readable in the run's allowed scope. An in-memory index cannot grant access to another run. Conversation-linked historical results still require a durable scope link. `read_result` also checks scope before resolving a pointer; it can inspect incomplete receipts, whereas bindings and completion require complete evidence.

Activity preflight receives the existing receipt store and a compact index combining
historical and current results, with current records taking precedence. This authority
stays local to preflight; it is not copied into Activity records or sent to a Gateway.
Preflight leaves the proposed binding specification unchanged. Ordinary execution
resolves it again against durable truth after admission, including resource or approval
waits. A caller that omits the required authority gets
`input_binding_authority_unavailable` rather than a Python lookup error.

Dependency graphs accept bindings to existing receipt operation IDs. Node names and
Activity IDs are scheduling identities, not receipt aliases. The graph API does not
provide future-value binding syntax: references to a new node or an unfinished
Activity are rejected structurally before graph admission. Submit the consumer after
the producer completes, using its receipt operation ID. Dependency-ready consumers
revalidate existing bindings before execution; strict admission still checks the whole
unstarted group and retains its existing conflict rules.

`read_result` with a pointer reads result data; omitting the pointer reads the receipt envelope. Its `text` is bounded JSON with offset/length information. Completion checks use `{"operation_id":"observed-id","pointer":"/exit_code","equals":0}`. Exact JSON types matter: false is not zero.

On historical input only, `source_field="stdout"` maps to `/stdout`; slash and tilde in old keys are escaped. It never guesses that dots in an old key meant nesting. See [RFC 6901](https://www.rfc-editor.org/rfc/rfc6901).

## Recovering an omitted model view

Adaptive can show selected exact excerpts while leaving the stored receipt intact.
`observation_complete: false` means captured content was omitted from the model's
view. Producer flags such as `has_more`, `truncated` and `output_complete: false`
separately describe capture limits. A stored-result read cannot recover content
the producer never captured.

```json
{"reference":"observed-operation-id","pointer":"/stdout","offset":0,"limit":6000}
```

`read_result` offsets count characters of serialized JSON, including surrounding
quotes and escaped newlines, not raw stdout characters or UTF-8 bytes. Its maximum
page is 12,000 characters. Follow returned offsets; never guess an offset from a
preview excerpt. Pointer `""` selects receipt data; omitting the pointer selects
the receipt envelope. References remain scoped across checkpoints and branches.

Files list/find/search previews contain whole records and counts. Their supplied
continuations use the same serialized-array offsets; oversized records use clearly
labeled JSON fragments. Recover omitted records in the stored page before advancing
the producer cursor to new source content. Explicit result pages remain intact for
the next decision or produce an explicit capacity error; they are not compressed
into a request to retrieve themselves again.
