/**
 * @file src/agent_runtime/api/static/agent_ui/prose_activity.js
 * @brief Render shared prose disclosures and operation monitoring details.
 * @details
 * Responsibilities: Group activity, correlate monitoring with public operation events and explain observations.
 * Boundaries: Presentation does not execute work or establish completion authority.
 * Lifecycle: Desktop, mobile and retained history feed the same ordered events and preserve disclosure choices.
 * State: Weak maps hold per-container monitoring context; only chat display preferences persist locally.
 * Security: Already-projected event fields render as bounded text, never HTML or executable commands.
 * Collaborators: Live controllers and retained_conversation.js supply events; prose_activity.css styles disclosures.
 * Public surface: SMTOProseActivity exposes disclosure, monitoring, narration and outcome helpers.
 * @see src/manual/content/architecture/23-observability.md
 */
(() => {
  "use strict";
  const memory = new Map();
  const monitoringGroups = new WeakMap();
  const monitoringOperations = new WeakMap();
  const workingGroups = new WeakMap();
  const answerHistory = new WeakMap();
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted", "partial"]);

  function policyRejection(event) {
    const labels = {
      "guard.strike": "Action rejected by policy",
      "activity.rejected_policy": "Action rejected by policy",
      "activity.blocked_conflict": "Action blocked by a conflict",
      "activity.blocked_dependency": "Action blocked by a dependency",
      "batch.rejected": "Activity batch rejected", "graph.rejected": "Activity plan rejected",
      "web_research.acquisition.rejected": "Research acquisition could not proceed",
      "web_research.reference.rejected": "Research result reference rejected",
      "web_research.completion.rejected": "Research completion rejected",
      "web_research.completion.repair_failed": "Research completion correction failed",
      "activity.failed": "Action failed",
      "tool.validation_rejected": "Tool arguments rejected",
      "operation.replay_blocked": "Repeated action blocked",
      "completion.rejected": "Completion rejected", "completion.output_rejected": "Output rejected",
      "provider.response_rejected": "Provider response rejected",
      "protocol.metadata_rejected": "Protocol metadata rejected",
      "model.rejected": "Model response rejected",
      "http.connection_ref_rejected": "Connection selection rejected",
    };
    if (!Object.hasOwn(labels, event?.event_type)) return null;
    const d = event.detail || {}, type = event.event_type;
    const action = d.capability_id || d.tool_name || d.tool || d.presentation?.capability_id;
    const code = String(d.reason || "").startsWith("research_") ? d.reason : d.error_kind || d.reason;
    const reason = d.rejection_reason || d.problem || (typeof code === "string"
      && /^[a-z][a-z0-9_.]{0,160}$/.test(code) ? code.replaceAll("_", " ") : "");
    const uncertain = d.remote_effect_possible === true || d.effect_unknown === true;
    const prevented = d.executed === false || d.candidate_executed === false
      || d.nothing_executed === true || ["activity.rejected_policy", "batch.rejected",
        "web_research.acquisition.rejected", "tool.validation_rejected"].includes(type);
    const outcome = uncertain ? "Execution outcome is uncertain."
      : prevented ? "This action was not executed." : d.executed === true
        ? "This action had already executed." : "Execution status was not reported.";
    return {title: labels[type], summary: [action, reason, outcome].filter(Boolean).join(" · "),
      prevented: prevented && !uncertain,
      key: d.error_instance_id || d.blocked_operation_id || d.operation_id || d.activity_id || d.batch_id
        || d.strike_id || event.event_id || event.id};
  }

  function researchNotice(event) {
    const labels = {
      "web_research.browser.required": "Browser requested for this research",
      "web_research.browser.satisfied": "Requested Browser observation completed",
      "web_research.browser.blocked": "Requested Browser research could not be completed",
      "web_research.reference.resolved": "Source reference resolved to its research result",
      "web_research.budget.requested": "Additional research steps requested",
      "web_research.budget.approved": "Additional research steps approved",
      "web_research.budget.denied": "Additional research steps declined",
      "web_research.completion.prose_discarded": "Research correction accepted for validation",
      "web_research.document.acquired": "Public PDF acquired",
      "web_research.document.discovered": "Public PDF link discovered",
      "web_research.source.blocked": "Static Web source access blocked",
      "web_research.document.inspected": "PDF pages inspected",
      "web_research.document.images_presented": "Rendered PDF pages presented to the primary model",
      "web_research.entity.unresolved": "Exact requested identifier remains unresolved",
      "web_research.entity.clarification_requested": "Asked user to clarify exact identity",
      "web_research.entity.clarification_resolved": "User clarified identity; research intent revised",
      "web_research.contract.frozen": "Research intent recorded",
    };
    const title = labels[event?.event_type];
    if (!title) return null;
    return {title, warning: /blocked|denied|unresolved/.test(event.event_type),
      key: event.event_id || event.id || `${event.event_type}-${event.detail?.operation_id || event.detail?.intent_revision || ""}`};
  }

  function preference(conversationId, fallback = false) {
    if (!conversationId) return fallback;
    if (memory.has(conversationId)) return memory.get(conversationId);
    let expanded = fallback;
    try {
      const saved = localStorage.getItem(`smto.agentUi.activityDetails.v1:${conversationId}`);
      if (saved === "true" || saved === "false") expanded = saved === "true";
    } catch (_) { /* Keep disclosures usable when storage is unavailable. */ }
    return expanded;
  }

  function setExpanded(conversationId, expanded) {
    if (!conversationId) return;
    memory.set(conversationId, expanded);
    try { localStorage.setItem(`smto.agentUi.activityDetails.v1:${conversationId}`, String(expanded)); } catch (_) {}
    for (const root of document.querySelectorAll("[data-activity-conversation]")) {
      if (root.dataset.activityConversation === conversationId && !root.classList.contains("progress-timeline")) root.open = expanded;
    }
  }

  function renderToggle(button, conversationId) {
    button.disabled = !conversationId;
    button.setAttribute("aria-pressed", String(preference(conversationId)));
    button.title = conversationId ? `${preference(conversationId) ? "Hide" : "Show"} activity details in this conversation`
      : "Activity details can be set once a conversation starts";
  }

  // A direction change is a main-rail milestone, never a collapsible tool row.
  // Use the applied event, not the earlier receipt of the user's instruction.
  function steering(container, event) {
    if (event.detail?.is_followup === true) {
      // A continued turn also renders this instruction as its user prompt.
      // Mark the journal copy so the chat-only presentation can avoid repeating it.
      const id = `steering-${event.detail.sequence}`;
      const message = [...container.children].find(row => row.dataset.messageId === id);
      if (message) message.dataset.followupMessage = "true";
      return null;
    }
    const sequence = event.detail?.sequence;
    const key = String(sequence ?? event.event_id ?? event.id ?? "");
    if (!key || [...container.children].some(row => row.dataset.steeringKey === key)) return null;
    const root = document.createElement("div");
    root.className = "steering-milestone";
    root.dataset.steeringKey = key;
    root.setAttribute("role", "note");
    root.setAttribute("aria-label", "Conversation steered here");
    const graph = document.createElement("span");
    graph.className = "steering-milestone-graph";
    graph.setAttribute("aria-hidden", "true");
    graph.innerHTML = `<svg viewBox="0 0 38 44" focusable="false">
      <path d="M33 4v3c0 12-22 8-22 23" />
      <rect x="30.5" y="1.5" width="5" height="5" rx="1.5" />
      <circle cx="11" cy="30" r="5" />
      <circle class="steering-milestone-core" cx="11" cy="30" r="1.5" />
    </svg>`;
    const copy = document.createElement("div"); copy.className = "steering-milestone-copy";
    const heading = document.createElement("div"); heading.className = "steering-milestone-heading";
    const label = document.createElement("strong"); label.textContent = "Conversation steered here";
    heading.append(label);
    const timestamp = new Date(event.timestamp || NaN);
    if (Number.isFinite(timestamp.getTime())) {
      const time = document.createElement("time");
      time.dateTime = timestamp.toISOString(); time.title = timestamp.toLocaleString();
      time.textContent = timestamp.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"});
      heading.append(time);
    }
    const description = document.createElement("p");
    description.textContent = "Updated instructions apply from this point.";
    copy.append(heading, description); root.append(graph, copy); container.append(root);
    return root;
  }

  // Adopt only the activity since the last main-rail node. Steering must retain
  // its place when the next prose block arrives, including during history replay.
  function leadingItems(container) {
    const items = [];
    for (const child of [...container.children].reverse()) {
      if (child.matches(".prose-activity, .steering-milestone, .conversation-message, .monitoring-activity, [data-supervision]")) break;
      items.unshift(child);
    }
    return items;
  }

  /** Bound public labels and command previews before retaining them in a monitoring view. */
  const monitoringText = (value, limit = 400) => typeof value === "string" ? value.slice(0, limit) : "";
  /** Join supervision and execution events by operation identity, falling back for older traces. */
  const monitoringKey = detail => String(detail.operation_id || detail.action_id || detail.job_id || detail.activity_id || "unknown");
  const monitoringStates = {
    starting: "Monitoring has started; the first process observation is pending.",
    progressing: "Recent output or progress was observed for this operation.",
    alive_quiet: "The process was observed alive, with no recent progress evidence.",
    progress_unknown: "The process was observed alive, but progress has not been confirmed.",
    possibly_stalled: "The process was observed alive, but expected progress has not changed.",
    attention_required: "Expected progress has not changed and this operation needs attention.",
    waiting_for_input: "The process is waiting for input.",
    observation_degraded: "The latest process observation could not be obtained.",
    unobservable: "Process observations are unavailable and this operation needs attention.",
    cancel_pending: "A stop was requested; process exit has not yet been confirmed.",
    terminal: "The process has ended. Check the operation's result for its outcome.",
  };

  /** Retain only public operation context, including compact history previews, without fetching or polling. */
  function observeMonitoring(container, event) {
    const type = event.event_type || "", detail = event.detail || {};
    if (!/^(execution\.command\.|invocation\.|activity\.)/.test(type)
        || type.startsWith("activity.supervision.") || /\.(stdout|stderr)$/.test(type)) return;
    const key = monitoringKey(detail);
    if (key === "unknown") return;
    let operations = monitoringOperations.get(container);
    if (!operations) { operations = new Map(); monitoringOperations.set(container, operations); }
    const context = operations.get(key) || {};
    const presentation = detail.presentation || {};
    const fields = {
      label: presentation.running_label || detail.display_name || context.label || detail.capability_id || detail.tool_name,
      description: presentation.context_detail || presentation.trace_detail || presentation.detail,
      target: detail.target_label || detail.gateway_node || context.target || detail.gateway_id || detail.target,
      cwd: detail.cwd,
    };
    for (const [field, value] of Object.entries(fields)) {
      if (typeof value === "string" && value) context[field] = monitoringText(value);
    }
    const command = event.command_preview || detail.command;
    if (typeof command === "string" && command) {
      context.command = monitoringText(command, 4000);
      context.truncated = command.length > 4000 || event.command_truncated === true;
    }
    operations.set(key, context);
    const view = monitoringGroups.get(container)?.contexts.get(key);
    if (view) renderMonitoringContext(view, context, key);
  }

  /** Explain a specific observed operation using text-only, already-redacted trace facts. */
  function renderMonitoringContext(view, context, key) {
    view.heading.textContent = context.label || (context.command ? "Shell command" : "Operation");
    view.description.textContent = context.description || (context.command || context.label ? "" : `Operation: ${key}. Operation details are not available in the loaded activity.`);
    view.description.hidden = !view.description.textContent;
    view.location.textContent = [context.target && `Target: ${context.target}`, context.cwd && `Working directory: ${context.cwd}`].filter(Boolean).join(" · ");
    view.location.hidden = !view.location.textContent;
    view.command.textContent = context.command ? context.command + (context.truncated ? "\n… (command preview truncated)" : "") : "";
    view.command.hidden = !context.command;
  }

  /** Recover missing context on expansion from the existing read-only, operation-scoped observation API. */
  async function loadMonitoringContext(container, group, key, view) {
 const busyFeedback = window.SMTOBusy?.begin({host: container, label: "Loading monitoring context…"});
 try {
    const context = monitoringOperations.get(container)?.get(key) || {};
    if (!group.root.open || !view.requestId || key === "unknown" || view.loaded
        || context.command || context.description) return;
    view.loaded = true;
    try {
      const response = await (window.SMTOAuth?.fetch || window.fetch)(`/api/agent/executions/${encodeURIComponent(view.requestId)}/observation?operation_id=${encodeURIComponent(key)}`);
      if (!response.ok) return;
      const observation = await response.json();
      if (monitoringGroups.get(container) !== group
          || observation.identity?.operation_id !== key
          || observation.identity?.request_id !== view.requestId) return;
      observeMonitoring(container, {event_type: "invocation.context", ...observation.operation_command,
        detail: {operation_id: key, presentation: observation.operation_presentation,
          cwd: observation.operation_context?.cwd}});
    } catch (_) { /* Missing or deleted retained context keeps the explicit fallback. */ }

 } finally { busyFeedback?.finish(); }
}

  // One top-level disclosure per turn. Keep the user's expansion choice while
  // live events arrive, and rebuild naturally when the trace is reset/replayed.
  function monitoring(container, event) {
    let group = monitoringGroups.get(container);
    if (!group || group.root.parentElement !== container) {
      const root = document.createElement("details");
      root.className = "prose-activity monitoring-activity";
      const summary = document.createElement("summary");
      const indicator = document.createElement("span");
      indicator.className = "prose-activity-status monitoring-activity-icon";
      indicator.setAttribute("aria-hidden", "true");
      indicator.innerHTML = `<svg viewBox="0 0 16 16" focusable="false">
        <path d="M1 8h3l2-4 4 8 2-4h3" />
      </svg>`;
      const heading = document.createElement("div");
      heading.textContent = "Monitoring activity";
      const items = document.createElement("div");
      items.className = "prose-activity-items monitoring-activity-items";
      summary.append(indicator, heading);
      root.append(summary, items);
      container.append(root);
      group = {root, items, seen: new Set(), contexts: new Map()};
      monitoringGroups.set(container, group);
      root.addEventListener("toggle", () => {
        if (root.open) for (const [key, view] of group.contexts) void loadMonitoringContext(container, group, key, view);
      });
    }
    const detail = event.detail || {};
    const key = String(event.event_id ?? event.id
      ?? `${event.event_type}:${detail.activity_id || detail.operation_id}:${detail.observed_at || event.timestamp}`);
    if (group.seen.has(key)) return false;
    group.seen.add(key);
    const operationKey = monitoringKey(detail);
    let contextView = group.contexts.get(operationKey);
    if (!contextView) {
      const block = document.createElement("section");
      block.className = "monitoring-activity-context";
      block.dataset.monitoringOperation = operationKey;
      const heading = document.createElement("strong");
      const description = document.createElement("p");
      const location = document.createElement("p");
      const command = document.createElement("pre");
      command.setAttribute("aria-label", "Monitored command");
      const explanation = document.createElement("p");
      explanation.textContent = "Checking process state, recent output and progress, and whether the operation has finished.";
      block.append(heading, description, location, command, explanation);
      group.items.append(block);
      contextView = {root: block, heading, description, location, command, requestId: event.request_id};
      group.contexts.set(operationKey, contextView);
    }
    renderMonitoringContext(contextView, monitoringOperations.get(container)?.get(operationKey) || {}, operationKey);
    const row = document.createElement("div");
    row.className = "activity-event monitoring-activity-event";
    row.dataset.supervision = detail.health_state;
    const label = document.createElement("span");
    label.textContent = event.title || "Activity supervision";
    row.append(label);
    const timestamp = new Date(detail.observed_at ? detail.observed_at * 1000 : event.timestamp || NaN);
    if (Number.isFinite(timestamp.getTime())) {
      const time = document.createElement("time");
      time.dateTime = timestamp.toISOString();
      time.title = timestamp.toLocaleString();
      time.textContent = timestamp.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit", second: "2-digit"});
      row.append(time);
    }
    const explanation = document.createElement("p");
    explanation.className = "monitoring-activity-explanation";
    explanation.textContent = monitoringStates[detail.health_state] || "Checking the operation's latest process and progress observations.";
    row.append(explanation);
    contextView.root.append(row);
    void loadMonitoringContext(container, group, operationKey, contextView);
    return group;
  }

  function message(container, event, renderMarkdown) {
    const detail = event.detail || {};
    if (event.event_type !== "conversation.message" || !detail.message_id
        || !["assistant", "user"].includes(detail.role) || typeof detail.content !== "string") return null;
    const key = String(detail.message_id);
    const existing = [...container.children].find(row => row.dataset.messageId === key);
    if (existing) return null;
    const root = document.createElement("section");
    root.className = "conversation-message";
    root.dataset.messageId = key;
    root.dataset.role = detail.role;
    root.contextSourceText = detail.content;
    root.dataset.questionId = detail.question_id || "";
    const heading = document.createElement("div");
    heading.className = "conversation-message-heading";
    heading.textContent = detail.role === "user" ? "You" : "Agent";
    const clock = window.SMTOMessageTimestamps?.create(detail.timestamp_inferred ? null : event.timestamp);
    if (clock) heading.append(clock.root);
    root.setAttribute("aria-label", detail.role === "user" ? "Your reply"
      : detail.kind === "answer" ? "Agent answer" : "Agent question");
    const body = document.createElement("div");
    body.className = "conversation-message-body markdown";
    renderMarkdown(body, detail.content);
    root.append(heading, body);
    container.append(root);
    return root;
  }

  // Retained answers belong before the next accepted user input, including
  // clarification replies in the same request. Shared by live views and replay.
  function answerBoundary(container, event, renderMarkdown, fallback = null, onArchived = () => {}) {
    let state = answerHistory.get(container);
    if (!state) { state = {answer: null, boundaries: new Set()}; answerHistory.set(container, state); }
    const d = event.detail || {}, type = event.event_type;
    if (type === "agent.final_response.retained" && d.decision_id
        && Number.isInteger(d.sequence) && typeof d.content === "string") {
      if (state.answer?.id !== d.decision_id) state.answer = {id: d.decision_id, sequence: 0, text: "", startedAt: d.started_at || event.timestamp};
      if (d.sequence === state.answer.sequence + 1) {
        state.answer.sequence = d.sequence; state.answer.text += d.content;
      }
    }
    if (type === "completion.rejected" && d.reason === "terminal_continuation_requires_ask_user") state.answer = null;
    const key = type === "conversation.message" && d.role === "user"
      ? d.message_id : type === "user.steered" ? `steering-${d.sequence ?? event.event_id ?? event.id}` : null;
    if (!key || state.boundaries.has(key)) return false;
    state.boundaries.add(key);
    const answer = state.answer || fallback;
    if (answer?.text?.trim()) {
      message(container, {event_type: "conversation.message", timestamp: answer.startedAt, detail: {
        message_id: `answer-${answer.id || key}`, role: "assistant", kind: "answer", content: answer.text,
      }}, renderMarkdown);
      onArchived(answer);
    }
    state.answer = null;
    return true;
  }

  function create({conversationId, decisionId, block, itemsClass = "", timestamp}) {
    const root = document.createElement("details");
    root.className = "prose-activity";
    root.dataset.decisionId = decisionId;
    root.dataset.activityConversation = conversationId || "";
    root.open = preference(conversationId);
    const summary = document.createElement("summary");
    const indicator = document.createElement("span");
    indicator.className = "prose-activity-status";
    indicator.setAttribute("role", "img");
    const items = document.createElement("div");
    items.className = `prose-activity-items ${itemsClass}`.trim();
    summary.append(indicator, block);
    const clock = window.SMTOMessageTimestamps?.create(timestamp);
    if (clock) summary.append(clock.root);
    root.append(summary, items);
    // Native summary activation (pointer, Enter, Space) is deliberately temporary.
    return {root, summary, indicator, items, block, clock};
  }

  function withdraw(view) {
    view.clock?.update(null);
    view.block.textContent = "Working...";
    delete view.block.dataset.decisionId;
    delete view.root.dataset.decisionId;
    view.root.dataset.fallbackProse = "true";
    workingGroups.set(view.root, view);
    return view;
  }

  function working(container, {conversationId, itemsClass = ""}) {
    const existing = workingGroups.get(container.lastElementChild);
    if (existing) return existing;
    const block = document.createElement("div");
    block.className = "agent-progress-narration narration markdown";
    const view = withdraw(create({conversationId, block, itemsClass}));
    view.items.append(...leadingItems(container));
    container.append(view.root);
    return view;
  }

  function promoteWorking(view, {decisionId, block, timestamp}) {
    if (!view || !workingGroups.has(view.root)) return null;
    workingGroups.delete(view.root);
    view.clock?.update(timestamp);
    delete view.root.dataset.fallbackProse;
    view.root.dataset.decisionId = decisionId;
    view.block.replaceWith(block);
    view.block = block;
    return view;
  }

  function entries(container, narrations) {
    const recorded = new Map([...(narrations?.values() || [])]
      .filter(entry => entry.view).map(entry => [entry.view.root, entry]));
    return [...container.children].flatMap(root => {
      const entry = recorded.get(root), view = workingGroups.get(root);
      return entry ? [entry] : view ? [{view}] : [];
    });
  }

  // Task summaries follow the final result; individual attempt rows retain their outcomes.
  function summaryOutcome(outcome, status, last = true) {
    if (["completed", "answered"].includes(status)) return "success";
    if (status === "failed" && (last || outcome === "failure")) return "failure";
    if (outcome === "failure") {
      return last && ["pending", "running", "waiting_job", "waiting_event"].includes(status)
        ? "running" : "incomplete";
    }
    return outcome;
  }

  function update(view, facts, {status = "running", closed = false, last = true} = {}) {
    const ended = terminal.has(status);
    const waiting = !ended && !["pending", "running", "waiting_job", "waiting_event"].includes(status);
    const running = !ended && !waiting && (facts.some(fact => fact.running)
      || last && (!closed || !facts.some(fact => !fact.model)));
    const failed = facts.some(fact => fact.failed);
    const incomplete = facts.some(fact => !fact.running && !fact.succeeded && !fact.failed);
    const outcome = running ? "running" : failed || last && status === "failed" ? "failure"
      : waiting && (last || facts.some(fact => fact.running)) || incomplete
          || last && ended && !["completed", "answered"].includes(status) ? "incomplete"
        : facts.length && facts.every(fact => fact.succeeded) ? "success"
          : ended || !last ? "incomplete" : "running";
    setOutcome(view.indicator, summaryOutcome(outcome, status, last));
  }

  /** Render an activity outcome glyph and accessible label, skipping unchanged indicators. */
  function setOutcome(indicator, outcome, label) {
    label ||= {running: "Activity running", success: "Activity succeeded", failure: "Activity failed",
      pending: "Activity pending", cancelled: "Activity stopped", incomplete: "Activity paused or incomplete"}[outcome];
    if (indicator.dataset.status === outcome && indicator.title === label) return;
    indicator.dataset.status = outcome;
    indicator.textContent = {running: "", success: "✓", failure: "×", pending: "○", cancelled: "■", incomplete: "!"}[outcome];
    indicator.setAttribute("aria-label", label); indicator.title = label;
  }

  window.SMTOProseActivity = {create, update, summaryOutcome, setOutcome, preference, setExpanded, renderToggle, steering, leadingItems, observeMonitoring, monitoring, message, answerBoundary,
    resetAnswers: container => answerHistory.delete(container), policyRejection, researchNotice,
    working, promoteWorking, withdraw, entries};
})();
