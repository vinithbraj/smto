/* One structured recurrence representation, shared by both editor entry points. */
(() => {
  "use strict";
  const {dateText, dateLabel, wallTime, intervalUnit} = window.SMTOScheduleTime;
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function recurrenceText(event) {
    if (event.schedule_type === "once") return `Once · ${dateText(event.next_run_at || event.last_run_at)}`;
    if (event.schedule_type === "interval") {
      const unit = intervalUnit(event.interval_seconds), n = event.interval_seconds / unit;
      return `Every ${n} ${{86400: "day", 3600: "hour", 60: "minute", 1: "second"}[unit]}${n === 1 ? "" : "s"} · elapsed time`;
    }
    const r = event.recurrence;
    if (!r) return "Choose a recurrence";
    const n = r.interval || 1, selected = r.weekdays || [];
    let text;
    if (r.frequency === "daily") text = n === 1 ? "Daily" : `Every ${n} days`;
    else if (r.frequency === "weekly") text = n === 1 && selected.join() === "0,1,2,3,4" ? "Weekdays" : `${n === 1 ? "Weekly" : `Every ${n} weeks`} · ${selected.map(d => days[d]).join(", ")}`;
    else {
      const yearly = r.frequency.endsWith("yearly"), unit = yearly ? "year" : "month";
      const pattern = r.frequency.startsWith("relative") ? `${r.week_index} ${days[r.weekday]}` : `day ${r.day_of_month}`;
      text = `${n === 1 ? yearly ? "Yearly" : "Monthly" : `Every ${n} ${unit}s`} · ${yearly ? `${months[r.month - 1]} · ` : ""}${pattern}`;
    }
    text += ` at ${wallTime(r.time)}`;
    if (r.range_type === "end_date") text += ` · until ${dateLabel(r.end_date)}`;
    if (r.range_type === "numbered") text += ` · ${r.number_of_occurrences} occurrences`;
    return text;
  }
  function timingPayload(v) {
    const base = {timezone: v.timezone};
    if (v.repeat === "once") return {...base, schedule_type: "once", next_run_at: `${v.date}T${v.onceTime}`};
    if (v.repeat === "interval") return {...base, schedule_type: "interval", interval_seconds: Number(v.interval) * Number(v.unit), ...(v.explicitStart ? {next_run_at: `${v.date}T${v.onceTime}`} : {})};
    const r = {frequency: v.repeat === "weekdays" ? "weekly" : ["monthly", "yearly"].includes(v.repeat) ? `${v.pattern}_${v.repeat}` : v.repeat, time: v.time, interval: v.repeat === "weekdays" ? 1 : Number(v.every), start_date: v.startDate, weekdays: v.repeat === "weekdays" ? [0, 1, 2, 3, 4] : v.repeat === "weekly" ? v.weekdays : [], range_type: v.range};
    if (["monthly", "yearly"].includes(v.repeat)) {
      if (v.pattern === "relative") Object.assign(r, {week_index: v.weekIndex, weekday: Number(v.weekday)});
      else r.day_of_month = Number(v.day);
      if (v.repeat === "yearly") r.month = Number(v.month);
    }
    if (v.range === "end_date") r.end_date = v.endDate;
    if (v.range === "numbered") r.number_of_occurrences = Number(v.count);
    return {...base, schedule_type: "calendar", recurrence: r};
  }
  window.SMTOScheduleRecurrence = {days, months, recurrenceText, timingPayload};
})();
