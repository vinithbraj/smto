import "./advanced.js";
import "../../agent_checks.js?v=20261018-loading";
export const activities = (...args) => window.SMTOAgentChecks.activities(...args);
