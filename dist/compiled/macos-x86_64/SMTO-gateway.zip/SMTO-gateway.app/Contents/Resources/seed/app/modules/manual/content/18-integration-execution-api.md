---
id: integration-execution-api
title: Integration execution API
kind: manual
tags: [manual, integration, external-systems, api]
order: 21
---
# Integration execution API

This page is for developers connecting another program to SMTO. An **API** is a
way for programs to send requests to each other. The integration API lets another
program ask SMTO to do a task and read its status and results. You do not need it
to use SMTO through the normal chat screen.

## Send a task from another program

Send a request with `POST /api/agent/integrations/execute`. SMTO handles it through
the same task system, with the tools and access allowed for that request. The
response reports the actual status, information returned by tools, and references
to saved results. The running SMTO service's `/docs` page and OpenAPI description
list the exact request fields.

For new clients, use `agent` mode and the registered capability IDs, which are the
names SMTO uses to identify groups of tools. Set limits on the allowed tools and
work when accepting requests from another program. Discovering another tool must
not bypass those limits.

When retrying or continuing a task, keep track of the original action and its
saved result. If a change may already have happened, check it before trying again.
A missing reply is not proof that nothing happened.

## Older database requests

The older `POST /api/agent/sql/query` address still works for existing clients.
SQL is a language for working with databases. Its `operation` field accepts:

- `execute`, which calls the registered `database.execute` tool.
- `discover_schema`, which calls `database.discover_schema` to inspect the database
  structure, such as its tables and columns.

Other operation values receive HTTP 422, meaning the request value is not accepted.
The old address stays available, while the actual tools use the Database group.
