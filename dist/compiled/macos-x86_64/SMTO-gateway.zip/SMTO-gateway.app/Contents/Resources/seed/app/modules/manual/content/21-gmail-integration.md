---
id: gmail-integration
title: Gmail Integration
kind: manual
tags: [manual, gmail, multi-account]
order: 25
---
# Gmail Integration

smTO is not an email client. Gmail is the source of truth. smTO does not maintain a mailbox copy, inbox index, message/thread cache, draft mirror, label cache, or background synchronization database. Searches and reads query Gmail when requested.

## Connect with a Gmail app password

In **Parameter Store → New parameter template**, select **Gmail — App Password (Gmail + SMTP)**.
Save the following JSON as `personal_gmail`, replacing the email and password:

```json
{
  "profile_type": "gmail_app_password_account",
  "profile_version": 1,
  "email": "you@gmail.com",
  "app_password": "YOUR_GOOGLE_APP_PASSWORD",
  "display_name": "",
  "timeout_seconds": 30
}
```

Use a Google app password, not your normal Google password. Google requires 2-Step
Verification; account or administrator policies can make app passwords unavailable.
Follow [Google's app-password setup](https://support.google.com/accounts/answer/185833).
Only leading and trailing spaces in app passwords are trimmed when saving; internal
spaces are preserved. Google-hosted custom-domain
addresses work with this profile too. No OAuth application, consent screen, or callback
is needed. Saved accounts are **configured**; saving performs no network request.

The selected paired Gateway needs this release's `gmail_imap` v1 and `email_smtp`
support plus Gmail workflow capability version 1 for compound actions. Update and restart both the controller and selected Gateway to deploy these actions. Older Gateways report `gmail_gateway_upgrade_required` before a new workflow writes mail. Connections use verified TLS to `imap.gmail.com:993` and verified STARTTLS
to `smtp.gmail.com:587`. The profile does not accept custom hosts or insecure TLS.
Update older Gateways if the private Gmail operation route is unavailable.

Example prompts:

- “Test Gmail IMAP and SMTP with @personal_gmail.”
- “Use Gmail with @personal_gmail to summarize unread messages from today.”
- “Use Email / SMTP with @personal_gmail to send this message to alice@example.com.”

`gmail.test_connection(account_ref="@personal_gmail")` tests both connections independently
without changing mail or sending anything. `email.test_connection(profile_key="@personal_gmail")`
tests SMTP only. Both skills use this one saved record. Enable each skill separately in
Capability Policy; enabling Gmail does not require enabling Email / SMTP for Gmail sends.
Setup does not enable either skill automatically.

App-password Gmail supports search, messages, threads, attachments, drafts, send/reply/forward,
read/star/importance state, archive, trash/spam restoration, targeted permanent deletion,
file import/export, and custom labels. Filters, account settings, categories, send-as identities,
and label color/visibility require an OAuth account. System folders are protected. Reads use `BODY.PEEK`
and preserve unread state. Gmail remains the mailbox authority; there is no background sync.

The socket timeout defaults to 30 seconds and can be changed in this profile (1–120 seconds).
Each network operation has a total deadline of `min(300, timeout_seconds × 4)` seconds.
These settings do not control model generation or thinking.

Draft replacement returns a new draft reference after creating and verifying the replacement.
If retiring the original fails, the result reports partial completion and both references.
Removal moves the exact draft to Trash. SMTP acceptance remains confirmed if subsequent
draft cleanup fails; cleanup never resends. A lost write acknowledgment is an unknown effect
and blocks automatic replay. An exact Sent-folder match can reconcile an uncertain send;
an inconclusive search never authorizes another send. Gmail already saves SMTP-sent messages,
so the integration never appends a second Sent copy.

Continuation tokens and bulk previews expire after ten minutes and on restart. Account edits
or mailbox UIDVALIDITY changes invalidate them; request a fresh search/preview. Approved bulk
operations use exactly the previewed IDs and report confirmed, failed and unattempted items.

## Connect with OAuth

Enable the Gmail skill in Capability Policy. In **Parameter Store → New → Gmail OAuth App**, enter your existing Google OAuth application's client ID and client secret. Save it as `gmail_auth_app`. smTO does not supply or register a Google OAuth application.

```json
{
  "profile_type": "gmail_oauth_app",
  "profile_version": 1,
  "service": "gmail",
  "client_type": "desktop",
  "client_id": "YOUR_CLIENT_ID",
  "client_secret": "YOUR_CLIENT_SECRET",
  "authorization_uri": "https://accounts.google.com/o/oauth2/v2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "scopes": [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.labels"
  ]
}
```

The template fills in Google's endpoints. Desktop clients use a temporary loopback callback and the system browser. Web clients require `client_type: "web"` and a `redirect_uri` registered with Google, pointing to your controller's `/api/agent/gmail/oauth/callback`. On a remote controller, use a web application callback reachable from your browser; the desktop callback runs on the controller machine.

Ask:

> Connect Gmail using @gmail_auth_app and save the account as work_gmail.

`gmail.connect` opens Google consent or returns an authorization link. After consent, the callback creates a **Gmail Account** Parameter Store record named `work_gmail`. OAuth handshake state expires after ten minutes and is lost on restart; restart the connection if necessary. No mailbox synchronization runs after connection.

The account record contains email, the linked OAuth app reference, tokens, expiry, and granted scopes. The model receives account identity, never raw secrets. Token refresh is automatic and updates that same Parameter Store entry. A revoked refresh token returns `reauthorization_required`; reconnect to the same key using the same OAuth app and Google account. A different account cannot silently replace it.

## Use Gmail

- “Use @work_gmail and summarize unread mail from today.”
- “Find the latest message from alice@example.com using @work_gmail.”
- “Draft a reply in @work_gmail.”
- “Send the reviewed Gmail draft.”
- “Forward Susan's PDF from @work_gmail to John.”
- “Trash promotions older than one year in @personal_gmail.”

The main agent chooses searches, reads relevant messages or threads, and writes summaries or replies. Gmail tools contain no separate planning or summarization model. Email bodies, headers and attachment filenames remain untrusted external data.

Search supports Gmail query syntax and concrete structured filters, returns metadata first, and exposes continuation tokens. Bodies are bounded and truncation is explicit. Attachment presence is unknown in metadata-only results; read the selected message for attachment details. Counts report a lower bound when their explicit maximum is reached.

Drafts, labels, filters, and sends operate directly in Gmail. Compose and reply support text, HTML, CC/BCC, and attachments. For outgoing attachments, pass an existing `artifact://` reference, a granted uploaded `ctx_...` / `context://` reference, an `artifact-workspace://` path, or a file supported by the normal task temporary-file publication mechanism. Explicit downloads become normal run artifacts; Gmail has no attachment cache. Forwarding can include the original message and attachments.

Filter operations need `https://www.googleapis.com/auth/gmail.settings.basic`. Add that scope to the OAuth app and reconnect explicitly. Tools report missing scope without widening authorization automatically.

## Client actions and supported connections

One Gmail skill exposes client actions in discovery sections. The initial tools include
`gmail.capabilities`, `gmail.mark_all_read`, and `gmail.empty_trash`. The model selects an
action and supplies arguments; selection, batching and verification run in code without
model calls between batches. This adds agent capabilities, not a separate email-client UI.

Use `gmail.capabilities(account_ref="@work_gmail")` to inspect the selected account's
available actions, missing OAuth scopes, Gateway version and protocol requirements.
This is a live capability check for app-password accounts; saving an account remains local.

| Area | Tools and behavior | OAuth | App password / Gateway |
|---|---|---|---|
| Inspection | `mailbox_overview`, `search`, `search_threads`, `count`, `read_message`, `read_thread`, `read_headers` | Yes | Yes |
| Read status | `mark_all_read`, `mark_read`, `mark_unread` | Yes | Yes |
| Priority | `star`, `unstar`, `mark_important`, `mark_not_important` | Yes | Yes |
| Organization | `archive`, `move_to_inbox`, `move_to_label`, `apply_labels`, `remove_labels` | Yes | Yes |
| Categories | `set_category` for Personal, Social, Promotions, Updates or Forums | Yes | Unavailable |
| Cleanup | `trash`, `restore_to_inbox`, `mark_spam`, `mark_not_spam` | Yes | MOVE required when changing folders |
| Permanent deletion | `delete_permanently`, `empty_trash`, `empty_spam` | Full `https://mail.google.com/` scope | UIDPLUS; MOVE when selected mail is outside Trash |
| Composition | Existing compose, reply, reply-all, forward, draft edit/send/discard; `reply_and_archive` | Yes | Yes, using SMTP for sends |
| Forward as attachment | `send_forward` / `create_forward_draft` with `as_attachment=true` | Yes | Yes |
| Send-as identity | Existing compose/reply/forward tools with `send_as` | Existing verified identity only | Unavailable |
| Files | `list_attachments`, `download_attachment`, `download_attachments`, `export_messages`, `import_message` | Yes | Yes; import requires UIDPLUS |
| Labels | `labels`, `get_label`, `create_label`, `update_label`, `delete_label` | Yes, including color and visibility | List, counts, create, rename, delete |
| Rules | Existing filter CRUD, `replace_filter`, `apply_filter`, `create_filter_and_apply` | Yes, subject to settings scopes | Unavailable |
| Settings | `get_settings` / `update_settings`: vacation, language, POP, IMAP, primary identity | Yes, subject to settings scopes | Unavailable |
| Existing identities and forwarding | `list_send_as`, `get_forwarding` | Read only | Unavailable |

All tool IDs above have the `gmail.` prefix. Existing primitive IDs remain supported.
Search accepts Gmail query syntax or structured filters. Reads are bounded and report
truncation. `get_label` returns actual label counts; `mailbox_overview` includes up to
100 label count records and a separately bounded unread count. IMAP exposes message
counts, not invented thread totals. Deleting a custom label leaves its messages intact.

Native snooze, scheduled send, Undo Send, mute/unmute, blocking, subscription management,
and confidential mode are explicitly unavailable. There is no browser fallback, substitute
filter, or local schedule claiming to be a native Gmail feature. Creating/deleting aliases,
changing another send-as identity, and changing forwarding settings are unavailable for
current account types. Contacts, Calendar, security and Workspace administration belong
outside this skill; domain-delegated service-account authentication is not added here.

## Compound mailbox changes

For “mark all unread mail as read,” use one call:

```json
{"account_ref":"@work_gmail"}
```

Pass those arguments to `gmail.mark_all_read`. To restrict it to the Inbox, add
`"scope":"inbox"`. Normal `all_mail` is the default and excludes Spam and Trash.
The cleanup helpers `empty_trash` and `empty_spam` always select their named folder;
**emptying means permanent deletion**, not moving messages into Trash.

Other actions require exactly one selector: `query`, `message_ids`, or `thread_ids`.
An empty query means all messages within the explicit scope. Supported scopes are
`all_mail`, `inbox`, `trash`, `spam`, and `anywhere`. Explicit IDs must agree with the
scope; selected threads expand to their existing message IDs before any write. For example:

```json
{"account_ref":"@work_gmail","query":"older_than:1y","scope":"inbox"}
```

Pass this to `gmail.archive`. `move_to_label` also requires `labels` containing one
user label ID or exact name. It adds that label and removes Inbox, preserving other
labels. `apply_labels` and `remove_labels` accept multiple user labels.

The workflow collects a frozen selection and required state before mutation. Ordinary
state changes never fetch message headers or bodies. Approval, when policy requires it,
shows account, action, scope, count and permanent-deletion semantics. The model never
carries selection tokens between these steps. Prepared selections expire after ten minutes,
on controller restart or account changes; IMAP writes also validate UIDVALIDITY and Gmail
message identity. An invalid approved selection cannot silently become a new selection.

The selection ceiling is 50,000 messages (`max_messages` can lower it). If more match,
the action stops **before mutation** with an explicit limit result. It does not process a
subset as “all,” repeatedly rerun a changing query, or include later arrivals.

Results contain `selected`, `changed`, `unchanged`, `failed`, `unknown`, and `unattempted`
counts, completion/verification state, an operation reference and bounded error details.
`changed` counts acknowledged updates; verification checks the selected IDs' intended
state or disappearance. Remaining matching mail is a separate observation, so a new unread
arrival does not invalidate a successfully completed initial selection. Activity shows
selection, updating and verification progress without intermediate model turns.

OAuth label updates use native batches of up to 1,000 IDs; permanent deletion uses
`messages.batchDelete`. Independent operations such as Trash requests use HTTP multipart
batches of at most 50 with per-item receipts. These have different failure handling.
App-password updates group UID flags, labels and moves in batches of up to 500 IDs, using
one IMAP connection per batch and retaining selection mappings. Permanent deletion moves
only selected messages to Trash when necessary, sets Deleted only on their exact UIDs,
and uses targeted `UID EXPUNGE`. Unrestricted EXPUNGE and expunging CLOSE are never used;
other clients' pending deletions remain untouched. Account-wide deletion settings are
never changed implicitly.

Selection and state verification still require provider traffic. IMAP can be slower than
OAuth and remains subject to mailbox size, server latency and deadlines; batching removes
per-message logins and mutations, not those protocol costs. New guidance changes future
tool choices and does not redirect an already-running header search.

The legacy `preview_modify` → `batch_modify` → `count` workflow remains available. A preview
token covers its full selection; sampled IDs do not. `displayed_ids_truncated` limits the
display, while `truncated` means the selection is incomplete. Keep account, operation and
label name unchanged when executing its token. For legacy count verification use the same
query and explicit `label_ids`: omission means Inbox; `[]` means normal All Mail. Prefer a
named compound action for common tasks.

## Composition, files, rules and settings

`reply_and_archive` freezes the existing thread selection, sends the reply, persists the
send receipt, then archives that selection. Archiving failure never resends the reply.
`send_as` must name an existing verified OAuth identity; the primary account still owns
thread identity and reply-all recipient exclusion. Forward-as-attachment emits a real
`message/rfc822` attachment.

`export_messages` accepts a normal selection and `format="zip"` (default) or `"eml"`.
Individual .eml exports and attachment downloads are limited to 100 files; total source
content is limited to 25 MiB per invocation. ZIP entries use generated safe names. Downloads
and exports become existing run artifacts; only references and metadata enter model context.
`import_message` accepts `file_ref` for a valid .eml artifact/upload through the normal
artifact-access mechanism. Import is a write and an uncertain import is never replayed.

`replace_filter` creates the replacement first, persists its ID, then deletes the old
filter. A cleanup failure reports both IDs. `apply_filter` takes an existing filter ID;
`create_filter_and_apply` takes `criteria` and `action`. Retroactive application validates
queryable criteria and equivalent mailbox label effects before changes. It rejects forwarding
and delivery-time-only settings rather than pretending to apply them to old mail.

Settings use a `setting` of `vacation`, `language`, `pop`, `imap`, or `primary_identity`.
Updates supply `values` with only supported fields; omitted fields are preserved. Primary
identity updates permit signature, display name and reply-to address. Changing an IMAP
deletion setting is possible only through an explicit settings update, never as an internal
delete workaround. Settings writes need `gmail.settings.basic`; additional mail operations
need their own granted scopes. Capabilities report the exact requirements without upgrading
authorization automatically.

Provider contracts: [native batch modification](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/batchModify),
[HTTP batching](https://developers.google.com/workspace/gmail/api/guides/batch),
[permanent deletion scope](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/batchDelete),
[targeted UID expunging](https://www.rfc-editor.org/rfc/rfc4315.html),
[alias restrictions](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.settings.sendAs/create),
[forwarding restrictions](https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.settings/updateAutoForwarding).

## Accounts, confirmation, and reliability

Multiple accounts are separately named parameters: `@work_gmail`, `@personal_gmail`, or any chosen key. Rename an account through the normal Parameter Store editor and use the new `@name` immediately. Explicit tool references win; otherwise a single accepted Gmail reference or a single available account can supply the account. Multiple candidates require selection. Account operations resolve current Parameter Store authorization, so deletion or rename takes effect immediately. If renaming an OAuth app, update the accounts' `oauth_app_ref` as well.

Mutations use the existing permission and confirmation policy. `gmail.preview_modify` resolves a bounded exact selection and returns a ten-minute, one-use selection token. `gmail.batch_modify` executes those IDs after approval, without rerunning the query. A restart or expiry requires a new preview. OAuth label/state changes use native batches of at most 1,000 messages. Trash is reversible; permanent deletion is explicit and follows the same permission policy.

A lost write response may mean Gmail applied the operation. smTO reports an unknown effect and the runtime prevents automatic replay. Sends use RFC822 Message-ID reconciliation against Sent where possible; an inconclusive lookup never triggers another send.

## Existing installations

Existing `gmail_oauth_app` and `gmail_account` Parameter Store records remain supported
without migration. Startup does not import, rewrite, rename or remove old credential
files. Reconnect explicitly if credentials are not already available in Parameter Store.

For a shared Google Workspace identity, use `auth.google_connect` with a
`google_oauth_app` and the Gmail features needed. Existing `gmail.*` tools also accept
the resulting `google_account`. They validate operation-specific granted scopes and
return `google.scope_upgrade_required` on the selected account when access is missing.
Use that same account key when adding Calendar or Drive features. See
[Shared Google Workspace identity](27-google-workspace.md).

OAuth configuration and authorization live in Parameter Store. There is no extra Gmail settings page, credential database, or primary-account database. Legacy sync, cache removal, broker callback, and OAuth configuration routes return HTTP 410. Parameter Store encryption and vault integration are separate future work.
