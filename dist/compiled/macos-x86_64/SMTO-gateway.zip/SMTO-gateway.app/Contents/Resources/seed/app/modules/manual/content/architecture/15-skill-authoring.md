---
id: skill-authoring
title: How to add a Skill
kind: architecture
tags: [architecture, tools]
order: 15
---
# How to add a Skill

A new skill adds deterministic tools to the model's available actions. It must not add another semantic decision owner.

1. Create `src/agent_runtime/skills/<skill_id>/` with `__init__.py`, `skill.py`, owned tools/services and focused tests. Keep shared transport, persistence and runtime infrastructure outside the skill.
2. Define source-owned `ToolDefinition` instances with globally unique IDs, complete argument schemas, accurate result documentation and conservative effects.
3. Implement handlers returning `ExecutionResult` from actual provider/OS observations. Receive services through explicit dependencies or authorized execution context. Enforce target scope, platform and credentials there.
4. Create a `SkillDefinition` grouping those tools and describing prerequisites. For tools with optional services, attach a deterministic `availability_check(context)` that returns `{"available": false, "reason": "..."}` when the service or required local dependency is absent. Return `authentication_required` or `configuration_required` separately when a present service needs sign-in or a profile. Use local checks, without inference or provider mutations.
5. Define `build_skill(registry: CapabilityRegistry) -> SkillDefinition` in `skill.py` and export it from the package. Add one explicit factory entry to `skills/catalog.py::SKILL_FACTORIES`, after any tools referenced by `uses_tools`. Registry/catalog discovery handles schema exposure; packages are never scanned or auto-registered. The registry argument gives configurable skills the existing configuration store.
6. Test discovery and availability, arguments, authorization, execution, receipts, scope isolation, exact result chaining and uncertain external effects.

```python
from agent_runtime.execution.models import ExecutionResult
from agent_runtime.capabilities.registry import CapabilityRegistry
from agent_runtime.tools import SkillDefinition, ToolDefinition, object_schema

# Test/example only: do not ship an echo tool as a product skill.
def echo(arguments, context):
    return ExecutionResult(
        operation_id=context["operation_id"], status="success",
        data_preview={"response": {"value": arguments["value"]}},
    )

def build_skill(registry: CapabilityRegistry) -> SkillDefinition:
    return SkillDefinition(
        skill_id="test", display_name="Echo fixture", description="Test-only example",
        tools=(ToolDefinition(
            id="test.echo", display_name="Echo", description="Return the supplied value",
            effect="read", arguments_schema=object_schema({"value": {"type": "string"}}, ["value"]),
            executor=echo,
        ),),
    )
```

Tools that accept exact references can declare `input_bindings` with `execution.bindings.BINDINGS_SCHEMA` and an `inputs` object. Bindings supply exact values before the executor runs. If an adapter can launch durable jobs, integrate with the existing job identity and cancellation contract.

Every advertised argument must work as documented; test its observable effect and reject irrelevant action-specific options. `result_schema` describes result data and is checked by adapter contract tests. The adapter owns successful output validation and normalization. The generic executor does not turn a post-effect schema mismatch into evidence that the operation never executed. See the tool contract guide for the complete availability and result semantics.

Do not modify the model's core loop to add a skill. Do not add a sub-agent or semantic routing. Ordinary skills require no edits to completion, persistence or output formatting. A new skill must not import `AgentLoop`.

Guidance-only skills may declare `tools=()`, `uses_tools=("python.run",)` and concise
`instructions`. Referenced tools must already be registered. The catalog includes
the instructions in those tools' existing model descriptions and resolves skill
discovery to the same tools. An optional local `availability_check(context)` can
report prerequisite state; unavailable skills contribute the reason rather than
execution instructions. This adds no routing inference or tool invocation.
Tool ownership, execution authorization and receipts stay with the original tool.
Skills with longer shared guidance can set the source-only `instructions_once=True`
flag. The catalog attaches that guidance to the first allowed advertised tool;
existing skills retain their default per-tool behavior. Memory uses this to keep
proactive learning instructions capability-scoped without repeating them per tool.
Excluding a guidance skill hides its instructions; excluding its underlying tool
removes execution access as usual. The Visualization skill is the production example.

`tests/test_v55_skill_contract.py` is the executable example. Its test-only Echo skill is discovered, called by a scripted model, executed by the production engine, persisted as receipts, chained with JSON Pointer into another tool, read, and checked at completion.

`tests/test_v55_final_cleanup.py` covers missing services, platform restrictions, new-skill availability, descriptive result schemas and compatibility boundaries.

## Generated APIs and private connection profiles

Use `entry_tool_ids` for the common domain operations of a large API and
`SkillSectionDefinition` for its source hierarchy. Keep discovery non-recursive,
validate ownership/cycles and use deterministic generated descriptors with one
executor factory. The Proxmox package is the production example: its four entries
coordinate guest resolution and task waits internally while advanced operations
are discovered by section. See [discovery](04-discovery.md) and
[Proxmox source generation](19-proxmox.md#updating-the-pinned-api).

Set `default_enabled=false` for an optional integration and preserve the existing
policy envelope when promoting entries from typed parameters. Select the
appropriate `cancellation_transport` when reusing Gateway HTTP. A domain client
must use the existing transport, ordinary ask_user and approval boundaries.

JSON templates belong in `parameters/templates.py` and prefill the shared editor.
Recognized private profiles need strict save validation, an allowlisted model
projection and exact accepted revision bindings. Never put credentials into
Working Context. A new Working Context adapter implements `validate`, `project`,
`supersedes`, `check_target` and `GUIDANCE`; colocate it with its skill and register
it in `skills/catalog.py::working_context_adapters`. Non-skill resource adapters
belong in `native/resource_adapters/`. Test a real Conversation-mode follow-up. Register volatile cleanup through
`native/conversation_resources.py` when the state belongs to a conversation.

Document the file and significant symbols under the
[source standard](../../../../docs/engineering/source-documentation-standard.md),
classify new operational scripts and data, and register unstaged source files in
the source-scope manifest so generated reference pages include them during review.
