/* A tab-local monitoring lease, shared by Chat, Settings and Inference. */
(() => {
  if (window.SMTOInferenceMonitor) return;
  const key = "smto.inference.monitor.v1", base = "/api/agent/inference/v1/telemetry/sessions";
  let current = null, timer, pending = false, renewing = false, departed = false, indicator, status, stopButton;
  try {
    const saved = JSON.parse(sessionStorage.getItem(key) || "null");
    if (/^[a-f0-9]{32}$/.test(saved?.id) && typeof saved.host === "string") current = saved;
  } catch (_) {}
  function save(value) {
    current = value;
    try { sessionStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
    render();
    window.dispatchEvent(new CustomEvent("smto:inference-monitor", {detail: current}));
  }
  async function request(path = "", options = {}) {
    const response = await (window.SMTOAuth?.fetch || window.fetch.bind(window))(base + path,
      {cache: "no-store", ...options, headers: {"Content-Type": "application/json", ...options.headers},
        signal: options.signal || AbortSignal.timeout(10000)});
    const body = await response.json();
    if (!response.ok) {
      const error = Error(typeof body.detail === "string" ? body.detail : "Monitoring request failed.");
      error.status = response.status;
      throw error;
    }
    return body;
  }
  function render() {
    if (!document.body) return;
    if (!indicator) {
      indicator = document.createElement("div");
      indicator.className = "inference-monitor-indicator";
      indicator.setAttribute("aria-label", "Inference monitoring session");
      const link = document.createElement("a");
      link.href = "/inference#hosts";
      link.textContent = "Requests & GPU timeline";
      status = document.createElement("span");
      status.setAttribute("role", "status");
      stopButton = document.createElement("button");
      stopButton.type = "button";
      stopButton.textContent = "Stop monitoring";
      stopButton.onclick = async () => {
        stopButton.disabled = true;
        try { await stop(); } catch (error) { status.textContent = error.message; }
        finally { stopButton.disabled = false; }
      };
      indicator.append(link, status, stopButton);
      (document.querySelector(".product-topbar, header") || document.body).append(indicator);
      const style = document.createElement("style");
      style.textContent = `.inference-monitor-indicator{display:flex;align-items:center;flex-wrap:wrap;gap:8px;padding:6px 10px;border:1px solid var(--border,#888);border-radius:8px;font-size:.8rem;max-width:100%;min-width:0;box-sizing:border-box;grid-column:1/-1;flex:1 0 100%}.inference-monitor-indicator[hidden]{display:none}.inference-monitor-indicator button{font:inherit;padding:4px 8px}.inference-monitor-indicator a{overflow-wrap:anywhere}.topbar:has(>.inference-monitor-indicator:not([hidden])){flex-wrap:wrap}`;
      document.head.append(style);
    }
    indicator.hidden = !current || current.state !== "running";
    status.textContent = current?.connection_error || "Monitoring active";
  }
  async function renew() {
    if (renewing || departed) return;
    clearTimeout(timer);
    const id = current?.id;
    if (!id || current.state !== "running") return;
    renewing = true;
    try {
      const value = await request(`/${id}/renew`, {method: "POST", body: "{}"});
      if (current?.id === id) save(value);
    } catch (error) {
      if (current?.id === id) save({...current,
        ...(error.status === 404 ? {state: "stopped", reason: error.message} : {}), connection_error: error.message});
    } finally {
      renewing = false;
      clearTimeout(timer);
      if (!departed && current?.state === "running") timer = setTimeout(renew, 15000);
    }
  }
  async function stop() {
    if (!current || current.state !== "running") return current;
    const id = current.id;
    const value = await request(`/${id}/stop`, {method: "POST", body: "{}"});
    if (current?.id === id) { clearTimeout(timer); save(value); }
    return value;
  }
  async function start(host) {
    if (pending) return current;
    pending = true;
    try {
      await stop();
      const value = await request("", {method: "POST", body: JSON.stringify({host})});
      save(value);
      clearTimeout(timer);
      timer = setTimeout(renew, 15000);
      return value;
    } finally { pending = false; }
  }
  window.SMTOInferenceMonitor = {get current() { return current; }, start, stop, request};
  document.addEventListener("DOMContentLoaded", render);
  window.addEventListener("pagehide", () => { departed = true; clearTimeout(timer); });
  window.addEventListener("pageshow", () => { departed = false; render(); void renew(); });
  document.addEventListener("visibilitychange", () => { if (!document.hidden) void renew(); });
})();
