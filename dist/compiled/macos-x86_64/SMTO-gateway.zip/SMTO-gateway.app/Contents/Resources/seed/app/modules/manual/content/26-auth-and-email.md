---
id: auth-and-email
title: Authentication and outbound Email
kind: manual
tags: [manual, auth, oauth, oidc, email, smtp]
order: 26
---
# Authentication and outbound Email

**Email / SMTP** is enabled by default; an explicit saved capability selection or exclusion
still applies. Enable **Authentication** to use its standalone administration tools. Configuration
lives in Parameter Store. Templates are detached prefills: opening a template does
not save a profile, connect an account or send a message.

## Configure authorization

Create an OAuth client from an Auth template and save it as `work_client`. Configure
your own registered client ID, the exact provider issuer or HTTPS endpoints, client
authentication method, allowed scopes and redirect URI. For browser authorization,
register the exact controller URL ending in `/api/agent/auth/oauth/callback` with
the provider. HTTPS is required outside literal loopback development addresses.
Entra discovery uses a tenant-specific issuer; replace template placeholders.

Create an **OAuth Connection** as `work_identity`. Set `client_ref` to `work_client`,
choose `authorization_code_pkce`, `device_authorization` or `client_credentials`, and set
`requested_scopes` to the intended subset of the client's allowlist. Client secrets,
private keys, refresh tokens and access tokens remain private Parameter Store fields.
They are never needed in a prompt or an Email tool argument.

Use `auth.inspect` for safe identities, `auth.connect` to authorize, `auth.test` to
validate/refresh, and `auth.disconnect` to clear authorization and attempt revocation.
Authorization can also begin when HTTP or Email first needs it. Click **Open authorization
page** yourself, or complete the displayed device code. The operation waits without
model inference, then resumes the same accepted invocation. Stop cancels the wait.
After controller restart or expiry, begin a new authorization; old callbacks cannot
be replayed. Profile edits invalidate pending authorization and existing leases.

Supported methods are public clients, client secret Basic/Post, client secret JWT,
private key JWT and mutual TLS. Browser grants always use S256 PKCE. OIDC validates
issuer, signature, audience, timestamps and nonce. Discovery endpoint origins must
match the trusted issuer or an explicitly saved allowlist. PAR supports automatic,
required and disabled modes. DPoP, JARM, token exchange, RAR and dynamic registration
are not supported in this version.

## Configure an Email sender

For Gmail, including Google-hosted custom domains, you can save one **Gmail — App Password
(Gmail + SMTP)** JSON template and use its Parameter Store reference as Email's `profile_key`
and Gmail's `account_ref`. Follow [Gmail app-password setup](21-gmail-integration.md).
Email derives the fixed Gmail SMTP settings privately from this account; it creates no second
credential record. `email.accounts` reports it as **configured**, and `email.test_connection`
tests SMTP without sending a message. Google requires 2-Step Verification to create an app
password; no OAuth application is needed for this option. Existing password and OAuth SMTP
profiles continue to work.

Create an **Email / SMTP** profile, for example `research_mail`. Set SMTP host/port,
TLS mode and fixed `from_email`. Optional `from_name`, `reply_to` and `envelope_from`
are profile-owned; the model cannot override them. Choose one authentication form:

- `none`: an explicitly configured relay; plaintext is permitted only here.
- `password`: saved username/password over STARTTLS or implicit TLS.
- `oauth2`: mailbox username, `auth_ref` pointing to `work_identity`, SASL mechanism
  and required scopes. Email obtains credentials exclusively through Auth.

STARTTLS fails if the server does not advertise or successfully negotiate it.
Certificate verification defaults to system trust; a saved custom CA is supported.
Explicit insecure verification reports a warning. Both password and OAuth require
verified encrypted controller-to-Gateway transport before credentials are released.
SMTP DNS/connections and Email's OAuth discovery, token, refresh and callback exchanges
run on the **selected Gateway**, including private network endpoints reachable only there.
Use `email.connect` to authorize through that Gateway. The controller hosts the browser
callback and owns token persistence; it does not contact Email's token endpoint itself.
An unavailable, changed or unsupported Gateway fails without a local fallback.
Older Gateways must be updated to advertise
`email_smtp` and serve the private Email operation route.

The Microsoft delegated presets use `smtp.office365.com:587`, STARTTLS, XOAUTH2,
`https://outlook.office.com/SMTP.Send` and `offline_access`. The separate app-only presets
use client credentials and `https://outlook.office365.com/.default`. App-only setup requires
administrator consent, SMTP.SendAsApp, an Exchange service principal and mailbox sending
permissions. SMTO does not grant these permissions automatically.
See [Microsoft SMTP OAuth](https://learn.microsoft.com/en-us/exchange/client-developer/legacy-protocols/how-to-authenticate-an-imap-pop-smtp-application-by-using-oauth)
and [SMTP submission settings](https://learn.microsoft.com/en-us/exchange/mail-flow-best-practices/how-to-set-up-a-multifunction-device-or-application-to-send-email-using-microsoft-365-or-office-365).

The Google template uses `smtp.gmail.com:587`, STARTTLS, XOAUTH2 and
`https://mail.google.com/`. This SMTP scope differs from granular Gmail REST scopes;
a Gmail REST authorization does not imply SMTP permission. See
[Google SMTP settings](https://developers.google.com/workspace/gmail/imap/imap-smtp)
and [XOAUTH2 scope and protocol](https://developers.google.com/workspace/gmail/imap/xoauth2-protocol?authuser=110).
Provider defaults were checked on 2026-09-30; provider and tenant policies still apply.

Provider presets form three linked Parameter Store records. Save the **Email OAuth App**
client, save its **Email OAuth Connection** with the matching `client_ref`, then select
that connection as the SMTP sender's `auth.auth_ref`. Microsoft delegated/app-only,
Google SMTP and generic OAuth each have client and connection drafts. Replace tenant,
client, secret, callback and sender placeholders before saving. Selecting a draft performs
no network request and stores nothing. Password and intentional internal relay profiles
need only the SMTP record.

## Test and send

| Tool | Effect and prerequisites |
| --- | --- |
| `email.accounts` | Read saved sender identities and authorization readiness; no network. |
| `email.connection_status` | Read one sender's saved authorization readiness; no network. |
| `email.connect` | Internal OAuth authorization/refresh through the selected verified Gateway. Password/relay profiles need no consent. |
| `email.test_connection` | Test selected Gateway SMTP/TLS/authentication without MAIL, RCPT or DATA. May request OAuth consent. |
| `email.send` | Network-heavy write using normal confirmation or full access. |

`email.inspect` and `email.test` remain compatible aliases. An accepted sender `@parameter`
promotes Email entry tools within the existing capability policy; it cannot override exclusions.
`email.send` takes `profile_key`, `to`, optional `cc`/`bcc`, `subject`, `text_body`
and/or `html_body`, plus optional attachment objects such as
`{"ref":"artifact://art_…","filename":"report.pdf"}`. Use exact existing artifact
or conversation-upload references. Eligible absolute temporary references use the existing
selected-Gateway temp-publication rules, including traversal/symlink protections; they do not
permit arbitrary controller file reads. Model-provided base64 is not accepted. The conversation
must already have access to each artifact/upload. At least one nonblank body is required.

Sending is a write operation and uses normal manual confirmation or full-access
policy. Review the fixed sender, separate To/CC/BCC groups, subject, attachment labels
(sizes when already available) and bounded plain-text body preview. HTML is represented as
text, never rendered by the confirmation preview. The approval binds the saved sender revision;
editing it while approval or OAuth is pending invalidates continuation. An authorization wait
preserves approval for that invocation. Message bodies are
excluded from activity details; the accepted invocation follows normal conversation
retention. BCC addresses are envelope recipients only and never enter MIME headers.

The limit is 100 recipient entries and 20 attachments. Total attachment bytes are
limited to 20 MiB; final encoded MIME must fit the profile limit (at most 25 MiB) and
the server's advertised SIZE. Unicode local parts require SMTPUTF8 and 8BITMIME; Unicode domains
use IDNA. Header control characters and unsafe filenames are rejected before sending.
Exact bytes are transferred to the Gateway in bounded chunks, verified by size and
SHA-256, bound to the run and operation, consumed once, and removed on completion or
within ten minutes. Staging is volatile memory, capped at 64 MiB across 128 entries;
chunks are at most 256 KiB. No separate mail or authorization database exists.

`accepted` means the server returned final SMTP 250, not proof of recipient delivery.
`partially_accepted` lists accepted and rejected recipients; repeating the whole send
would duplicate mail to accepted recipients. A confirmed SMTP rejection is reported
separately. If the connection disappears after message transmission starts and before
a valid final reply, or the Gateway returns incomplete/mismatched send evidence, the result is
`unknown_effect`. The runtime blocks automatic resend.
Use its deterministic Message-ID to reconcile with server logs or the recipient.
Cancellation after DATA cannot undo remote acceptance. An OAuth authentication rejection
permits at most one refresh retry, before MAIL/RCPT/DATA.

Email supplies outbound SMTP only. Continue using the existing Gmail skill for Gmail
search, reads, threads, drafts, labels and mailbox operations.

## Shared Google Workspace identity

For Gmail REST and future Calendar/Drive skills, use **Google Workspace OAuth App** and
**Google Workspace Account** templates with `auth.google_connect`, `auth.google_accounts`
and `auth.google_status`. Features share one verified identity and token bundle.
The generic Auth and Google SMTP profiles above retain their existing contract.
See [Shared Google Workspace identity](27-google-workspace.md).
