/* Explicit source-backed selections. Rendering and saving never start inference. */
(() => {
  "use strict";
  const digest = async text => [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)))].map(v => v.toString(16).padStart(2, "0")).join("");

  function bind(turn, {apiJson, conversationId}) {
    const requestId = turn.requestId || turn.id;
    if (!requestId || turn.savedTaskContext) return turn.savedTaskContext;
    const root = turn.assistant || turn.root || turn.answer?.parentElement;
    if (!root) return null;
    const url = `/api/agent/native/${encodeURIComponent(requestId)}/task-context/saved-messages`;
    const suffix = conversationId ? `?conversation_id=${encodeURIComponent(conversationId)}` : "";
    let sources = [], saved = [], pending = false, scheduled = false, sourceVersion = 0;
    const controls = new Map(), hashes = new Map();
    const panel = document.createElement("details");
    panel.className = "saved-task-context";
    panel.hidden = true;
    const title = document.createElement("summary"); title.textContent = "Saved task context";
    const list = document.createElement("div");
    const status = document.createElement("p"); status.setAttribute("role", "status");
    panel.append(title, status, list);
    (turn.runActions || turn.detailActions || root).append(panel);

    function candidates() {
      const result = [];
      for (const row of root.querySelectorAll(".conversation-message[data-role='assistant'], [data-context-source-complete='true']")) {
        if (row.contextSourceText) result.push({element: row.matches(".conversation-message") ? row.querySelector(".conversation-message-body") : row,
          text: row.contextSourceText, presentationId: row.dataset.decisionId});
      }
      for (const entry of turn.narrations?.values() || []) {
        if (entry.closed && entry.text && (entry.block || entry.root)) result.push({element: entry.block || entry.root, text: entry.text,
          presentationId: (entry.block || entry.root).dataset.decisionId});
      }
      const finalText = turn.answerText || turn.text;
      if (finalText && turn.answer?.dataset.provisional !== "true" && turn.answer?.getAttribute("aria-busy") !== "true") result.push({element: turn.answer, text: finalText, presentationId:
        turn.retainedFinal?.id || turn.retained?.id || turn.responseMetrics?.final_response?.decision_id || turn.trace?.response_metrics?.final_response?.decision_id});
      return result.filter((c, index) => result.findIndex(other => c.element === other.element) === index);
    }

    function accepted(value) {
      sources = value.sources || sources;
      saved = value.saved_messages || [];
      panel.hidden = !saved.length;
      list.replaceChildren();
      for (const item of saved) {
        const row = document.createElement("div");
        const text = document.createElement("p");
        text.textContent = `${(item.text || "Source unavailable").slice(0, 180)} · ${item.delivery_status === "included" ? "Included in model input" : item.delivery_status === "blocked_capacity" ? "Context capacity exceeded" : item.delivery_status === "source_unavailable" ? "Remove unavailable selection to continue" : "Saved for next decision"}`;
        const inspect = document.createElement("details"), label = document.createElement("summary"), body = document.createElement("pre");
        label.textContent = "View saved message"; body.textContent = item.text || "Source unavailable under current access or retention rules.";
        inspect.append(label, body);
        const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "Remove";
        remove.addEventListener("click", () => mutate(item));
        row.append(text, inspect, remove); list.append(row);
      }
      schedule();
    }

    async function mutate(item, source = null, control = null) {
    const busyFeedback = window.SMTOBusy?.begin({host: control, label: "Updating saved context…"});
    try {
      if (pending) return;
      pending = true; status.textContent = "";
      if (control) control.disabled = true;
      try {
        const result = item
          ? await apiJson(`${url}/${encodeURIComponent(item.save_id)}${suffix}`, {method: "DELETE"})
          : await apiJson(url + suffix, {method: "POST", body: JSON.stringify({
              source_reference: source.source_reference, source_revision: source.source_revision,
              client_submission_id: control.submissionId ||= crypto.randomUUID(),
            })});
        if (control) delete control.submissionId;
        accepted(result);
      } catch (error) {
        panel.hidden = false; panel.open = true;
        status.textContent = error.message || "Could not update saved context. Try again.";
      } finally { pending = false; if (control) control.disabled = false; schedule(); }

    } finally { busyFeedback?.finish(); }
  }

    async function draw() {
      const current = candidates();
      const chosen = new Set();
      for (const [element, button] of controls) {
        if (!element.isConnected || !current.some(c => c.element === element)) { button.remove(); controls.delete(element); }
      }
      for (const candidate of current) {
        if (!hashes.has(candidate.text)) hashes.set(candidate.text, digest(candidate.text));
        const hash = await hashes.get(candidate.text);
        if (!candidate.element.isConnected || !candidates().some(c => c.element === candidate.element && c.text === candidate.text)) continue;
        const matches = sources.filter(s => (s.source_revision === hash || s.display_revision === hash) &&
          (!candidate.presentationId || !s.presentation_id || s.presentation_id === candidate.presentationId));
        // Identical prose from different sources is ambiguous without a source identity.
        if (matches.length !== 1) { controls.get(candidate.element)?.remove(); controls.delete(candidate.element); continue; }
        const source = matches[0];
        // Mobile may retain a hidden live view beside the visible history view.
        if (chosen.has(source.source_reference)) { controls.get(candidate.element)?.remove(); controls.delete(candidate.element); continue; }
        chosen.add(source.source_reference);
        let button = controls.get(candidate.element);
        if (!button) {
          button = document.createElement("button"); button.type = "button";
          button.className = "saved-context-action";
          button.addEventListener("click", event => {
            event.preventDefault(); event.stopPropagation();
            const item = saved.find(s => s.source_reference === button.source.source_reference);
            void mutate(item, button.source, button);
          });
          controls.set(candidate.element, button);
        }
        button.source = source;
        const item = saved.find(s => s.source_reference === source.source_reference);
        const label = item ? "Saved · Remove" : "Save to task context";
        if (button.textContent !== label) button.textContent = label;
        button.title = item ? "Remove this message from future task context." : "Keep this complete message through steering, waits and continuation of this task.";
        if (candidate.element.nextSibling !== button) candidate.element.after(button);
      }
    }
    function schedule() {
      if (scheduled) return;
      scheduled = true;
      queueMicrotask(() => { scheduled = false; void draw(); });
    }
    async function refresh() {
      const version = sourceVersion;
      try {
        const value = await apiJson(url + suffix);
        // A completed source event can arrive while the initial GET is in flight.
        if (version !== sourceVersion) value.sources = [...new Map(
          [...(value.sources || []), ...sources].map(s => [s.source_reference, s])).values()];
        accepted(value);
      } catch { /* Older servers and unavailable task sources have no action. */ }
    }
    const observer = new MutationObserver(records => {
      if (!root.isConnected) { observer.disconnect(); return; }
      if (records.some(r => !panel.contains(r.target) && !r.target.closest?.(".saved-context-action"))) schedule();
    });
    observer.observe(root, {subtree: true, childList: true, characterData: true});
    turn.savedTaskContext = {refresh, source(detail) {
      sourceVersion++;
      sources = [...sources.filter(s => s.source_reference !== detail.source_reference), detail]; schedule();
    }, dispose() { observer.disconnect(); }};
    void refresh();
    return turn.savedTaskContext;
  }
  window.SMTOSavedTaskContext = {bind};
})();
