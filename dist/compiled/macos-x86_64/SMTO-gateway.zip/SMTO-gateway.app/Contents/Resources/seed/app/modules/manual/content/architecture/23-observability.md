---
id: observability-visualization
title: Activity, progress and execution visualization
kind: architecture
tags: [architecture, current, observability-visualization]
order: 23
---
# Activity, progress and execution visualization

The controller emits trace/activity events as the run progresses. The browser projects
these into activity rows, tool detail, progress narration, timing and execution diagrams.
A row is a view of server state; selecting it cannot confer scheduler or completion
authority.

## Reading execution activity

**Activity Trace** is the history of what happened during a task. Open it to see
which tools ran, which computer they used, the information they received, and what
they returned. A tool finishing successfully does not prove the whole request was
answered correctly. Check the final result too.

### Check tool access and approvals

The history shows when tools were selected, enabled, blocked, or approved. These
are different steps. Knowing that a tool exists does not mean it ran. Allowing a
tool does not approve every action it could take. When approved access lets a task
continue, the other restrictions still apply.

### Read output without stopping the work

For a command, opening the output only shows what it has returned. Closing that
view or your browser tab does not cancel the command. No new output means only
that nothing new has arrived; it does not prove the work finished.

Check the recorded result to see whether the command completed or failed. If an
action may have made a change but its final result is missing, find out what
happened before repeating it.

### Follow work that is still running

Open **Monitoring activity** to see the action being watched. When available, it
shows the selected computer, folder, and a short command preview. Each dated
update explains the reported status. Actions running at the same time keep their
own details.

If the command's start is outside the visible history, opening the details can
retrieve its saved information. This does not ask the AI to do more work or run
the command again. Older or incomplete records may say that some details are
unavailable. The same recorded actions can be viewed on desktop, mobile, or after
reopening the conversation.

### Understand what the history can show

The amount of detail depends on what your settings keep and display. Looking at
the history does not change permissions. The AI output view can only show fields
the provider sent and SMTO retained; it cannot reveal private internal reasoning.
SMTO checks saved tool results when deciding whether work is complete, rather
than relying only on what is visible in the browser.

Settings that hide sensitive information do not cover every kind of output.
Review records before sharing them. Commands, user content, or account details
may still contain private information.

## Model-call latency

In **Inspect execution**, open **Model call overlap** to compare concurrent calls.
Open a **Model call timeline** event to inspect preparation, token measurement,
capacity waits, transport and response milestones. Calls discarded after steering
are labeled separately from accepted decisions. Acceptance of a model response
does not authorize a tool operation.

**Waiting for controller capacity** means the run is waiting for an agent-turn
lease. **Waiting for model capacity** means the existing inference gate has not
admitted the call. Job, event, approval and resource waits retain their own status.

Unknown timing stays **Unknown**. The first SSE event, first observable reasoning
and first useful answer/tool characters are different milestones. Time before
useful output is not a measurement of provider prefill. Provider queue/prefill
durations appear only when supported numerical telemetry is available. Overlapping
spans and calls are never summed as elapsed time; separate process clocks stay separate.

**Settings → Detailed latency diagnostics** controls new tasks. The default is on;
accepted, queued and resumed tasks retain their saved value. Turning it off disables
the additional call timeline while ordinary activity remains available. Existing
checkpoints without the field use the documented default. The view retains up to
64 recent call records, with at most 96 spans each; incomplete records remain incomplete.

Diagnostics do not change model, reasoning, context, cache, concurrency, tool-result
mode or permission policy. They contain numerical facts and correlation identities,
not additional copies of prompts, reasoning or tool output.

## Capability lifecycle

Automatic capability awareness, selection, activation and grants appear as first-class
Activity rows on desktop and mobile. Labels and bounded detail use the shared capability
presentation contract. The lifecycle includes:

- Manifest availability and initial selection started/completed/degraded/changed.
- Agent capability requests, activation, already-active no-ops, blocks and missing setup
  or authentication after activation.
- Grant required/prompted, allowed/denied/unclear answers, committed/conflicting settings,
  and parent/child authority continuation identities.

`native_capability_events` is an additive durable outbox keyed by `(run_id, event_key)`.
The native checkpoint and its events commit in the same writer transaction. Discovery
operation IDs, selection IDs and grant IDs make retries idempotent. The bounded native
`state.events` list remains a debugging view; it is not the complete audit history.
The AgentTrace journal projects the outbox with a unique `capability_event_id`, preserving
capability history beyond the ordinary recent-event window. Execution and continuation delivery repair missing outbox delivery without repeating
execution or duplicating Activity rows. Trace GET and refresh never repair durable state.

Capability details contain allowlisted IDs, epochs, digests, revisions, reason codes and
lineage. They exclude arbitrary model rationale, tool output, user answer text, prompts,
credentials and configuration values. Durable event delivery uses the existing trace
and native continuation paths; it adds no model calls or background polling loop.
Conversation snapshots preserve these safe details and child lineage so the grant and
continued task remain visible after reload. Diagnostic retention deletes the outbox with
the native run. Older traces without capability events retain their existing presentation.

Historical recovery publishes classifier/resource revisions and events for automatic repair,
baseline decisions and exact candidate continuation. The dedicated desktop and mobile decision
shows selected blocker facts without foreign command text, environment values or logs. Backend
eligibility controls the baseline action; a stale decision refreshes the current facts. Baseline
acceptance never presents an unknown historical operation as successful or failed.

Tool details expose bounded invocation input and output. LOGS, EVENTS, TRACES and ACTIVITY independently control optional projection at their consumer boundaries. Completion uses raw receipts. Structural reasoning exclusions and size limits apply independently. See [Redaction](31-redaction.md).

Shell output continues to be captured by the existing runtime/Gateway execution path
and retained in `AgentTraceStore`. Normal conversation trace GET/SSE carries command
lifecycle and compact metadata, not stdout/stderr transcript chunks; it does not delete
the retained evidence. Full raw records keep their separate explicit inspection route.
Expanding a captured Shell row opens a read-only, request/operation-scoped command SSE
at `/api/agent/trace/{request_id}/commands/{operation_id}/stream`. It replays retained
events and waits on the trace condition for new events. Reconnect uses the trace cursor
and generation; every inspected event advances the server cursor, including filtered events.

Collapsing the row closes only that observer stream. Viewing, copying and reconnecting
never invoke an LLM, execute a command, poll the Gateway or change command lifetime.
Copy output reads the complete retained command transcript on demand, independently
of the bounded browser preview. Tool section copy actions likewise use the retained
public section data before display truncation, with the same redaction policy.
Conversation history retains full final responses so response and code-block copying
continue to include the complete answer after reopening a chat.
Browser connection state is separate from process state; silence means only that no
output has arrived. Completion and exit codes come from receipts. Detached capture and
missing final receipts are reported explicitly. Server-side projection through the
existing TRACES redaction policy precedes browser delivery; this preserves the current
optional redaction contract described above, including literal visibility when disabled.

Each native model call has an **Inspect model output** disclosure in Activity on desktop
and mobile. It replays retained provider-emitted reasoning, answer text and tool-call
fragments and follows new output while open. Channel filtering, Copy output and
Download full capture support debugging, including calls that failed at their output
limit. The download includes call identity, timing, actual request limits, provider usage
when available, and finish reason. Character counts are not presented as token counts.

Capture runs independently of the viewer. Text is kept in a separate SQLite sidecar,
`<current-run-db>.traces.model-output`, keyed by request and model-call ID. Writes are
batched; ordinary trace/history responses contain no captured text. The browser retains
only a 256 Ki-character preview and clearly reports omitted earlier text; copying
includes all retained text for the selected channel, and the download includes the full
retained capture. Closing the disclosure or hiding the page disconnects
inspection without stopping generation or capture. Replay resumes by chunk sequence.

The TRACES redaction setting applies when text is captured, including credentials split
across provider fragments. Captured output never becomes executable conversation history,
accepted completion evidence, or a tool call. Only fields actually emitted by the provider
can be inspected; earlier uncaptured calls and provider-private reasoning cannot be recovered.
Restarted captures without a live owner are marked interrupted. Explicit **Delete diagnostics**
and **Delete everything** remove the conversation's model captures; deleting only the UI chat
preserves diagnostic evidence under the existing retention policy.

Progress narration describes ongoing work. Model and tool timing distinguish reasoning
transport from actual execution. Compaction events report context projection changes.
Execution visualization relates activities, dependencies and observed state transitions;
a dependency edge or resource wait remains owned by the native scheduler.

Operations submitted in the same runtime batch share an expandable activity group;
explicit Shell Parallel calls use the same display. Single operations remain individual
rows, and Shell Sequence retains its ordered group. Group summaries distinguish observed
overlap from sequential execution and expose capacity waits and failures. Elapsed time
measures the group wall-clock span, not the sum of child durations. Successful groups
collapse on completion unless the user chose their expansion state; child command/output
inspectors remain available. New history snapshots retain batch membership for reload;
older snapshots without that identity keep their original ungrouped presentation.

The desktop activity inspector and dedicated mobile lazy trace panel consume server
projections. Reload/reconnect rebuilds the view from available server data. Do not infer
that a closed tab cancels a server process, or that a visible completed tool proves the
entire run's contract has been satisfied.

Source owners: `observability/agent_trace.py`, native event/publication/progress modules,
desktop activity/execution-visualization modules, and `mobile/lazy/trace_details.js`.

Model request diagnostics distinguish normal execution configuration from internal
phase policy. Execution traces report the profile/version, configured catalog names,
configured/omitted counts and output reservation. They do not fabricate a temperature
or provider output limit for omitted fields. Stop strings and expert-map contents are
excluded from these diagnostics. A reservation is a context-budget fact, not proof
that an output limit was sent. Provider rejections can identify configured controls
without recording raw provider error text or changing saved settings.

Interrupted native streams retain the lifecycle `native_stream_error` (or
`native_stream_incomplete`) independently of `provider_diagnostic.category`.
Transport categories reuse the provider classifier; SSE decoding, parsing and
size-limit failures have stable stream categories. Monotonic first-event latency,
largest accepted-event gap, idle time at failure and a bounded failure-stage code
join configured/effective timing limits in the existing diagnostic allowlist.
No raw stream chunks, hidden reasoning or arguments are added. Compact conversation
history retains these safe diagnostics and centralized error copy, so replay uses
the same causal heading as live activity. Historical records without a cause show
“Model response was interrupted”. None of these facts authorize partial output or
trigger a replacement inference.

`execution.command.resource_wait` records the initial admission wait and material
blocker changes, without per-poll trace events. Desktop/mobile show **Waiting for
resource · Not started**. `execution.command.resource_admitted` clears that wait
when admission succeeds. Attention escalation carries backend-derived reason,
waiting age, liveness, revision and eligible actions; raw foreign commands,
environments and logs are excluded. Claim history records stale foreground repair;
resource decision and continuation events record acceptance and zero recovery model
calls. Execution bookkeeping timestamps and material fingerprints do not count as
new observed command output in progress/convergence accounting.

## Disabled-check observations and capability history

The optional **Monitor disabled Agent Checks** preference adds `agent_check.observed` to ordinary Activity. Each informational row identifies the check, states that execution continued because enforcement is disabled, and offers **Learn more** through the shared Manual link resolver. These events contain bounded catalog identities and allowlisted numeric/boolean facts, never raw commands, prompts, paths or tool arguments. They do not become tool results or model messages.

Every durable capability event, including selection started/completed/failed, remains a separate chronological Activity entry on desktop and mobile, live and after reload. The existing capability outbox and trace journal remain authoritative. Replay is deduplicated by `capability_event_id`; distinct events are not merged by type. Unknown future capability families receive a generic Activity row. Passive observations similarly use `agent_check_observation_id` and the existing journal, without another event store or user-facing log.


## Research failures and continuation

Activities classify actual authority/policy denials as policy rejections. `executed=false`
alone is not a policy decision: invalid research references, soft allowance exhaustion,
protocol failures and remote access failures retain their own causes. Execution true,
false and unknown remain distinct. Live, restored and mobile views retain operation,
acquisition and error-occurrence identities without page content. Repeated failures with
the same error kind remain separate occurrences. The Browser privacy latch preserves only
allowlisted identities, catalog causes and execution facts in diagnostics.

Research allowance requests reuse the authority card and reply transaction. Reload shows
the same exact increments and request ID; approval and denial resume the same run without
an extra grant-prompt model call. Completion rejection and correction failures retain the
original causal reason. Incidental prose discarded during the single research correction
is a bounded diagnostic event, never an accepted answer.

Document research emits distinct `web_research.document.discovered`, `.acquired`,
`.inspected` and `.images_presented` events. Static access failures use
`web_research.source.blocked`; existing Browser operations retain their own trace.
Entity resolution uses `web_research.entity.unresolved`, `.clarification_requested`
and `.clarification_resolved`; `web_research.contract.frozen` records the new revision.
Desktop and mobile Activity retain these notices after reload, along with existing
completion validation records. Structural metadata includes bounded source/entity IDs,
page numbers, byte counts, operation names and materialization truth. It includes no
document body, private path, binary image or hidden reasoning. Type/provenance failures
retain their catalog cause and are not relabeled as policy denials.

## Compact conversation reads

Desktop and dedicated mobile share one selected-conversation snapshot owner. A known
conversation deep link reads `/api/agent/conversations/{id}/snapshot` and one bounded
turn page. The snapshot contains conversation metadata, normalized task relationships,
current execution controls, server timing, a trace generation/cursor and execution
observation. Composer catalogs, permissions, attachments and other optional panels load
after current execution state. No current-run discovery is necessary for a known ID.

The owner coalesces in-flight reads, aborts on navigation and checks the navigation
generation before applying a response. A committed invalidation arriving during a read
causes one trailing reconciliation. Reconnect preserves the last coherent status and
server-based elapsed time, with connection freshness displayed separately. Previously
active request IDs remain in the next reconciliation so completion is not lost when the
queue advances. Native terminal truth does not wait for the last trace frame; the final
answer is a separate retained read. Revisions suppress redundant application, not updates
to durable state. Snapshots use `Cache-Control: no-store`.

`AgentTraceStore` has three read tiers: header/status/timing; bounded cursor windows;
and explicit full trace/export. Routine snapshots, compact native/lane reads and Shell
heartbeats use zero `get_trace` calls. Delta windows pair generation, cursor and terminal
state in one read and drain retained events before closing. Idle trace, command and UI
invalidation streams wait on cancellable async notifications from the existing writers;
they do not occupy the API worker pool or add a polling loop. Disconnect removes the
listener immediately. Capture retention and execution lifetime do not depend on listeners.

A projection scope captures live redaction policy once. Nested field/event projections
reuse it, while explicit source policy overrides keep their established semantics. Each
SSE batch ends its scope before yielding. Turning optional redaction off still preserves
literal permitted evidence; execution and completion continue to use raw receipts.

## Bounded Activity history

Opening Activity loads at most 100 presentation events from the retained cursor window.
Older/Newer controls replace that page and dispose its viewers. At most 125 live rows plus
100 historical rows remain mounted. Removed rows remain accessible through retained
history. Only explicitly cumulative model-progress updates for the same call/operation/
phase are grouped; waits, errors, messages and distinct results remain separate. “Show
exact event sequence” disables grouping, and each row links to its full retained event.
Legacy chat-only visualization snapshots have the same bounded paging adapter.

Shell transcript chunks remain on the existing command inspector stream. An unopened
output disclosure creates no output transport. Closing a page/disclosure disposes its
viewer without cancelling the underlying operation. Current execution state never waits
for historical Activity reconstruction, including when the Activity preference is open.

Release budgets: at most three critical JSON reads; zero duplicate authoritative GETs
in flight per owner/key; one policy-provider read per projection; zero full-trace copies
on compact paths; lane ≤16 KiB for one task and ≤192 KiB for 100; native status ≤32 KiB;
first Activity page ≤128 KiB and mounted rows ≤250. Warm localhost p95 gates are 750 ms
for current state, 1,000 ms for trace readiness, 750 ms for Activity disclosure, 500 ms for
a 10k-event snapshot, 100 ms for frame-to-status paint and 100 ms for observation. Open
Activity may add at most 150 ms to current-state p95; Activity reconstruction must not
create a main-thread task over 100 ms.

Run `REFRESH_BENCHMARK=after PYTHONPATH=src:tests .venv/bin/python -m pytest -q
tests/e2e/test_instant_refresh_benchmark.py` from the repository root. It uses an isolated
local server, synthetic retained evidence and 30 warm samples per desktop/mobile case;
JSON evidence lives in `docs/assets/instant-refresh-hardening/`. Deterministic budget and
race tests run without the benchmark environment variable.

## Supervision evidence and narration

Desktop and mobile show the same retained supervision state, last-check time and
observation freshness. An active observation claim can display “Inspecting…” without
adding a durable row. Meaningful health transitions use factual `activity.supervision.*`
events. Ordinary observations replace the latest record; they do not append heartbeat
history. Attached completion probes and background status probes add no supervision
rows. The execution inspector exposes health, cadence and freshness separately.
Completion diagnostics distinguish Gateway finish time, controller terminal observation
time, probe counts/failures and health-inspection counts. No probe calls the model.

Existing status surfaces distinguish progress-unknown, actionable attention, recovery
and restored waiting. `activity.recovery_started`, `activity.recovery_attempt`, and
`activity.wait_restored` record the wake, consumed allowance and restoration reason.
Duplicate-incident suppression uses the existing watchdog diagnostic counter. Unresolved
attention remains inspectable while waiting resumes; ordinary polls add no narration.

Nonterminal attention uses the existing wake journal. Its model envelope contains at
most eight Activities and less than 12 KiB of serialized evidence, with per-Activity log
cursors and bounded recent output. Existing optional redaction preferences apply before
projection bounds. Current raw execution receipts retain their existing ownership.

An attention continuation may emit ordinary investigative prose. Only the established
`agent.progress.narration` path renders that actual model text. The runtime does not
write an assistant sentence, summarize logs with a helper model, or synthesize narration
when Generate prose is off. Factual runtime rows remain before the ensuing model prose
on desktop, mobile and refreshed Activity history.

Observation, classification, recovery and UI projection make no model calls. Worker
`metrics_snapshot()` exposes due lag and observation/Gateway/persistence duration plus
registration, observation, progress, quiet, attention, duplicate suppression, recovery,
failure, terminal discovery, transition and model-wake counters. Healthy model wakes
must remain zero. Counters are process-local except the retained registration count.
