// Shared controllers retain policy/artifact semantics; their skin belongs to mobile.
if (!document.querySelector('[data-mobile-advanced-style]')) {
  const style = document.createElement("link"); style.rel = "stylesheet";
  style.href = new URL("./advanced.css?v=20261015-smto", import.meta.url).href;
  style.dataset.mobileAdvancedStyle = ""; document.head.append(style);
}
