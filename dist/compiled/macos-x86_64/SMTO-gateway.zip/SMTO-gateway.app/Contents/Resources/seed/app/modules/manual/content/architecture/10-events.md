---
id: schedules-events-monitors
title: Schedules, events and monitors
kind: architecture
tags: [architecture, tools]
order: 10
---
# Schedules, events and monitors

The `google_calendar` skill owns live external Google Calendar operations separately
from these durable smTO actions. It shares Google Workspace identity in Parameter
Store but never imports Scheduler recurrence, creates internal schedule records or
mirrors provider events. See [Google Calendar](../28-google-calendar.md).

The **Schedules & Reminders** skill (`schedule`) exposes `schedule.create`,
`schedule.inspect`, `schedule.update`, `schedule.cancel`, `schedule.delete`, and
`schedule.trigger` through the existing durable event store.
Use `action_type="notification"` and `prompt` for exact reminder text. A successful
creation finishes the current request immediately; the scheduler persists the
notification without calling the model. The Agent UI notification inbox also shows
reminders delivered while the browser was disconnected.

Timing uses the existing fields: `once` with `interval_seconds` for a relative delay,
`once` with `next_run_at` for an ISO date/time, `interval` with `interval_seconds` for
recurring intervals, or `calendar` with a daily/weekly `recurrence` and local `time`
(`HH:MM`, Monday=0 through Sunday=6). `timezone` defaults to the user/runtime timezone;
stored trigger timestamps resolve to UTC. Ambiguous/nonexistent absolute local times
require an explicit offset. Calendar recurrence skips nonexistent DST times and uses
the first occurrence of a repeated local time once.

One-shot reminders support delays from one second; recurring reminders support ten
seconds. Offline one-shots fire once on return with late metadata. Recurring schedules
deliver one coalesced late notification, then advance from the current time (calendar
schedules advance to the next matching wall time), without replaying missed intervals.
Notification persistence, its run receipt and schedule advancement commit together in
SQLite. Reopening the database or running competing scheduler instances does not
duplicate a committed reminder.

Use the returned `schedule_id` (`event_id` remains an alias) to inspect or cancel.
Cancellation preserves history and reports `cancelled`, `already_cancelled`,
`already_completed`, or `not_found`. Creating schedules requires an active scheduler;
discovery reports the actual store/worker availability.

### Inspecting and counting schedules

`schedule.inspect` is an initial tool when permitted and the schedule store exists.
It remains readable when the scheduler worker is offline or future execution is
disabled. Capability exclusions still apply. Other management tools retain their
existing execution prerequisites.

Call without an ID to list saved schedules; `status="active"` selects enabled
schedules, while omission includes all non-deleted states. `total_count` and
`status_counts` cover all matches; `returned_count` counts the displayed rows.
`included_statuses` identifies the counted states. Zero counts establish no matches
in those states now, not the absence of deleted schedules or historical activity.
`limit` defaults to 20 and allows up to 100. `complete=false` means the displayed
list was truncated. For count questions, set `summary_only=true`: the tool returns
exact counts without rows and with `complete=true`, providing complete evidence
for a count answer even when more than 100 schedules exist. A truncated listing
cannot be cited as complete evidence; use the count-only view instead.
`scheduler.enabled` and
`scheduler.worker_active` describe execution readiness separately from saved status.
Use one observed `schedule_id` with `include_instruction` or `include_runs` for details.

The current run's jobs, waits and task board are separate from saved schedules.
Models must inspect schedules before reporting their count. Failed discovery or
inspection means the count is unknown; an empty job list is not schedule evidence.
If discovery is needed, use `discover_tools({"skill_ids":["schedule"]})`, then the
advertised `schedule__inspect` function.

`action_type="agent_prompt"` retains the existing scheduled task queue and saved
authorization/target scope for future Agent work, with its existing execution and
recovery semantics. It requires inference at execution time. Use core `wait_for_event`
for suspension and continuation of the current run, `manage_job(wait)` for an already
running process, and Monitors for repeated condition checks. User-facing timers use
schedules; ordinary program sleeps and explicitly requested OS cron/timer setup remain
valid shell tasks.

For a timed wait in the current task, desktop and mobile show **−**, an adjustment
amount and unit, **+**, and **Wake now** beside the countdown. The adjustment defaults
to one minute; seconds and hours are also available. Changes update the saved deadline
and survive refresh or restart. Subtracting all remaining time requests an immediate
wake, just like **Wake now**. **Wake requested · waiting to resume** means the request
is saved and the task will continue when execution capacity is available. These
controls apply to timed sleeps; schedule, monitor, provider and job waits retain their
existing controls. The adjacent **Navigator** button opens the Conversation Navigator
to jump between prompts, including in short conversations.

Scheduled Agent work also retains captured execution generation settings. Scheduler
Manager resolves and saves them at creation; Agent-created schedules inherit the
creating run's configuration. Each occurrence reuses that saved configuration, so
later global changes do not retune it. Legacy schedules without a captured execution
configuration resolve it when they fire. Notification-only reminders perform no
inference. See
[scheduled model configuration](../22-schedules.md#model-configuration-for-scheduled-execution).

`monitor.start` requires an actual command and deterministic settings from the model. `monitor.inspect` and `monitor.stop` operate on observed monitor IDs. The adapter does not draft a missing command. `route_groups/monitor_service.py` owns monitor manager initialization, and `route_groups/monitors.py` owns its routes.

An explicit Create Monitor workflow may call `monitors/drafting.py`. Configured deterministic conditions are evaluated mechanically; an explicitly configured judged/hybrid monitor may use the bounded condition judge at its configured cadence. Ordinary chat never invokes these helpers before the model.

Use actual event/monitor IDs for waits. Keep credentials out of stored prompts; services receive scoped runtime context.

## Monitoring snapshot on scheduled work

Scheduled/event work captures the disabled-Agent-Check monitoring preference with its accepted scope. Updates retain the existing accepted value and dispatch carries it into the run. Missing legacy event scope values mean OFF. This preference adds optional Activity diagnostics only; it creates no new scheduled action, poll, model call or event trigger.
