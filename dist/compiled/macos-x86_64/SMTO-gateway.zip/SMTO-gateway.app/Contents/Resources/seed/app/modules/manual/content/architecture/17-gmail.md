---
id: architecture-gmail-integration
title: Gmail service boundary
kind: architecture
tags: [architecture, gmail]
order: 24
---
# Gmail service boundary

The normal agent uses deterministic `gmail.*` capabilities in `skills/gmail/tools.py`. `GmailService` in `skills/gmail/service.py` calls the live Gmail provider through `skills/gmail/client.py`; the model owns semantic selection, drafting, classification and summarization. Retrieved content is untrusted external data.

`gmail_app_password_account` selects the request-scoped adapter in `skills/gmail/app_password.py`.
OAuth accounts keep the REST path. The adapter reuses Gmail MIME, artifact and bulk-preview
logic and the private Email SMTP delivery/receipt pipeline. Gmail's capability policy owns
Gmail sends independently of the Email skill. App passwords are unconditionally excluded
from parameter projections, history, diagnostics and protocol logging.

`gateway_core/gmail_runtime.py` serves version-one private `/gmail/operation` requests on
inbound and outbound Gateways. IMAPClient 3.x owns each request's verified TLS connection,
inside the existing cancellable socket boundary. Literals, lines, aggregate MIME reads,
cursor counts and private chunk transfers are bounded. Transfers are invocation-owned;
cursors bind account revision, query, run and mailbox UIDVALIDITY, and expire after ten minutes.
Both stores are volatile and discarded on process restart. No controller IMAP/SMTP fallback exists.

Gmail extensions provide hexadecimal message/thread IDs and labels; special-use folder
attributes locate localized mailboxes. Reads use BODY.PEEK, archive removes the Inbox label,
and trash transitions require UID MOVE. No EXPUNGE, expunging CLOSE or permanent-delete
fallback exists. Draft replacement verifies a new APPENDUID before cleanup and checks the
old draft's content identity and draft/sent state again. Confirmed substeps are checkpointed
in the existing native invocation receipt before dependent operations. Restart preserves
those facts while an unfinished operation remains unknown and cannot be replayed.

`AgentParameterStore` is the sole durable owner of OAuth app configuration and account/token bundles. `parameters/templates.py` defines `gmail_oauth_app` and `gmail_account`, validates their version-one contracts and projects safe identities. `skills/gmail/parameter_profiles.py` resolves canonical keys and updates the existing account record after token exchange or refresh. Accepted private references supply account identity; Gmail resolves the current record for token lifecycle, rename and deletion behavior.

`auth/gmail_compat.py` retains the legacy Gmail adapter; `auth/browser.py` owns the common browser/PKCE lifecycle and `auth/google/client.py` owns shared Google/Gmail refresh;
`skills/gmail/oauth.py` is a compatibility import. The adapter holds ten-minute OAuth state and PKCE verifiers only in process memory. Desktop authorization uses a temporary loopback listener; web applications use their configured controller callback. State is consumed once before exchange, and the Gmail profile supplies the authenticated email. Browser launch failure leaves a usable consent URL. Refreshes share process-wide account locks, retain an omitted refresh token and never silently select another account. Provider 401 rejection permits one refresh attempt. Reads have bounded retry for throttling/transient server errors; writes are never blindly retried after an uncertain response.

There are no runtime Gmail account tables, mailbox tables, body caches, indexes, labels/draft mirrors, attachment caches, OAuth-state tables, or sync/watch managers. Gmail authorization is created directly in Parameter Store through the current OAuth flow. The old Gmail database, secret key and configuration importer are absent. Old files are never imported, renamed or deleted by startup. `gmail/store.py`, `gmail/sync.py`, and `gmail/broker.py` remain removed.

Mail reads return bounded results into normal task/model context. Search uses metadata format; full bodies are fetched only for explicit reads, reply/forward construction, or requested attachments. Tool observations follow the normal task lifecycle; there is no separate persistent mailbox. `skills/gmail/files.py` uses the existing artifact registry for explicit downloads and existing artifact/file handoff for outgoing attachments.

Bulk preview selections contain only account identity, operation, IDs, hash and timestamps in bounded process memory. Tokens are one-use and expire after ten minutes. Execution validates the account and uses exactly the selected IDs; native batchModify chunks contain at most 1,000 IDs. No Gmail plan database exists. After restart, preview again.

Generic execution receipts, confirmation grants and replay guards remain authoritative. Ambiguous sends/mutations raise `UnknownEffectError`. Outgoing messages carry an RFC822 Message-ID. Following a lost send response, an exact Sent search can establish successful delivery; otherwise the operation remains unknown and is not repeated. Receipts belong to the existing RunStore, not a Gmail send database.

Parameter Store UI templates and the existing mention palette provide configuration and account selection. Existing live routes remain; retired cache/config routes return 410. No Gmail-specific model, email-client UI, secure vault, encryption system or notification architecture is introduced.

Provider contracts follow [Gmail REST reference](https://developers.google.com/workspace/gmail/api/reference/rest), [native OAuth with PKCE](https://developers.google.com/identity/protocols/oauth2/native-app), and [Gmail scopes](https://developers.google.com/workspace/gmail/api/auth/scopes).

Neutral `google_account` profiles are optional Gmail identities. The shared resolver in
`auth/google/accounts.py` considers eligible legacy and neutral records together. Gmail
`scope_requirements.py` checks each neutral operation, including internal provider calls;
legacy provider scope/error semantics remain stable. Native accepted references and
explicit account keys select exact identities. Gmail sends, uncertain effects, MIME and
public tool IDs retain their existing behavior. See
[Google Workspace foundation](../27-google-workspace.md) for schemas and reuse by Calendar/Drive.
