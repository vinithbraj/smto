/* Observational wall-clock spans. No transport, provider content, or runtime decisions. */
(() => {
  "use strict";
  const finite = value => typeof value === "number" && Number.isFinite(value) && value >= 0;
  const stamp = value => typeof value === "string" && value ? Date.parse(value) : NaN;
  const valid = Number.isFinite;
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted", "partial"]);
  const liveRunStatuses = new Set(["pending", "running", "waiting_job", "waiting_event"]);
  const runStatus = value => value.user_visible_status || value.outcome || value.native_profile?.final_status
    || value.response_metrics?.native_outcome || value.effective_status || value.status;
  const safe = (value, limit = 120) => typeof value === "string"
    ? value.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g, " ").slice(0, limit) : "";
  function format(ms, precise = false) {
    if (!finite(ms)) return "Duration unavailable";
    if (ms < 1000) return `${Math.round(ms)} ms`;
    if (precise) return `${(ms / 1000).toFixed(3)} s`;
    if (ms < 60000) return `${(ms / 1000).toFixed(ms < 10000 ? 2 : 1)} s`;
    const seconds = Math.round(ms / 1000);
    return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  }
  /** Render recorded response timing attribution without estimating missing spans. */
  function responseBreakdown(recorded = {}) {
    const summary = recorded.latency_summary || {}, wall = recorded.breakdown;
    const explanation = "Thought includes model request and response generation time, not a measurement of internal reasoning.";
    if (wall && [wall.thought_ms, wall.executed_ms, wall.overlap_ms, wall.remainder_ms].every(finite)) {
      const parts = [`Thought for ${format(wall.thought_ms)}`, `Executed for ${format(wall.executed_ms)}`];
      if (wall.overlap_ms > 0) parts.push(`Thought + executed for ${format(wall.overlap_ms)}`);
      parts.push(`${wall.incomplete ? "Unmeasured" : "Waited/overhead"} ${format(wall.remainder_ms)}`);
      return {text: parts.join(" · "), title: `${explanation} Parallel work is counted once; simultaneous model and tool work is shown separately. `
        + (wall.incomplete ? "Some timing receipts are missing; unmeasured time cannot be attributed to waiting."
          : "Waited/overhead includes queues, suspended waits, and runtime work outside recorded model/tool spans.")};
    }
    // Legacy aggregates can overlap. Never subtract them to invent a wait duration.
    const parts = [];
    if (summary.llm_call_count > 0 && finite(summary.llm_response_ms) && summary.llm_response_ms > 0)
      parts.push(`Thought for ${format(summary.llm_response_ms)}`);
    if (recorded.command_span_count > 0 && finite(summary.execution_ms))
      parts.push(`Commands ran for ${format(summary.execution_ms)}`);
    if (finite(summary.llm_wait_ms) && summary.llm_wait_ms > 0)
      parts.push(`Model slot wait ${format(summary.llm_wait_ms)}`);
    return {text: parts.length ? `${parts.join(" · ")} · partial timing` : "Timing breakdown unavailable",
      title: `${explanation} This record has no complete wall-clock breakdown. Available durations are cumulative, may overlap, and exclude unrecorded work and waits.`};
  }
  const create = () => ({models: new Map(), tools: new Map(), active: new Set(),
    decisions: new Map(), parents: new Map(), currentDecision: null, currentModel: null, recovery: false,
    groups: new Map(), groupParents: new Map(), activityOperations: new Map(),
    run: {start: NaN, end: NaN, duration: null, terminal: false}, revision: 0});
  const duration = (span, now) => span.notRun ? null : finite(span.duration) ? span.duration
    : valid(span.start) && (valid(span.end) || (!span.terminal && valid(now)))
      ? Math.max(0, (span.terminal ? span.end : now) - span.start) : null;
  function spanFor(state, kind, id, event) {
    const map = kind === "model" ? state.models : state.tools;
    let span = map.get(id);
    if (!span) {
      span = {id, kind, start: NaN, end: NaN, duration: null, terminal: false,
        order: Number(event.id || event.index || 0), label: kind === "model" ? "Thinking" : "Tool",
        status: kind === "model" ? "Thinking" : "Running"};
      map.set(id, span);
    }
    return span;
  }
  function times(span, event, {start = false, end = false, rank = 1} = {}) {
    const d = event.detail || {}, at = stamp(event.timestamp);
    const began = stamp(d.started_at);
    if (valid(began) && rank >= (span.startRank || 0)) {
      span.start = began; span.startRank = rank;
    } else if (start && valid(at) && rank >= (span.startRank || 0)) {
      span.start = at; span.startRank = rank;
    }
    const first = stamp(d.first_actionable_at);
    if (valid(first) && !valid(span.first)) span.first = first;
    if (finite(d.pre_output_ms) && !finite(span.preOutput)) span.preOutput = d.pre_output_ms;
    if (end && rank >= (span.endRank || 0)) {
      span.end = valid(stamp(d.completed_at)) ? stamp(d.completed_at) : at;
      span.endRank = rank;
      if (finite(d.duration_ms)) span.duration = d.duration_ms;
      else if (finite(d.elapsed_ms)) span.duration = d.elapsed_ms;
      else if (rank > (span.durationRank || 0)) span.duration = null;
      span.durationRank = rank;
      span.terminal = true;
    }
    if (!valid(span.start) && valid(span.end) && finite(span.duration)) span.start = span.end - span.duration;
  }
  function finishRun(state, at, changed) {
    state.run.terminal = true;
    if (valid(at)) state.run.end = at;
    for (const span of state.active) {
      // A missing terminal receipt cannot continue ticking forever after a stop/crash.
      // It is bounded by the server's run terminal event, never browser render time.
      span.terminal = true; span.end = at; span.status = "Stopped";
      span.runBounded = true; changed.add(span);
    }
    state.active.clear();
  }
  function resumeRun(state) {
    state.run.terminal = false; state.run.end = NaN; state.run.duration = null;
  }
  function restore(state, trace = {}) {
    const t = trace.runtime_timing || trace.timing || {};
    if (t.startup) state.startup = {...t.startup};
    const start = stamp(t.started_at || trace.created_at), end = stamp(t.completed_at);
    if (valid(start)) state.run.start = valid(state.run.start) ? Math.min(state.run.start, start) : start;
    const status = runStatus(trace) || t.status;
    const changed = new Set();
    if (terminal.has(status)) {
      if (finite(t.duration_ms)) state.run.duration = t.duration_ms;
      finishRun(state, valid(end) ? end : stamp(trace.updated_at), changed);
    } else if (liveRunStatuses.has(status)) resumeRun(state);
    state.revision++;
    return changed;
  }
  function reject(span, detail) {
    const kind = safe(detail.error_kind);
    const stopped = ["model_generation_stalled_no_action", "model_generation_repetitive",
      "model_generation_deadline", "cancelled", "model_cancelled", "user_cancelled", "run_cancelled"].includes(kind);
    span.status = stopped ? "Stopped" : "Rejected";
    span.nothingExecuted ||= detail.nothing_executed === true || detail.executed === false;
    const error = safe(detail.error, 2000).trim(), reason = safe(detail.reason, 2000).trim();
    const description = window.SMTORejectionReasons.describe(detail);
    // Retain only bounded scalar telemetry, never arbitrary provider metadata.
    const diagnostic = detail.provider_diagnostic || {};
    if (description.model_failure) {
      span.modelFailure = true;
      span.noOperationAuthorized ||= diagnostic.no_operation_authorized === true
        || ["native_stream_error", "native_stream_incomplete"].includes(kind);
      span.streamDiagnostic ||= {};
      if (description.reason_code !== "llm_stream_interrupted" || !span.streamDiagnostic.category)
        span.streamDiagnostic.category = description.reason_code;
      for (const key of ["configured_llm_timeout_seconds", "configured_no_actionable_output_timeout_seconds",
        "configured_constrained_recovery_timeout_seconds", "configured_recovery_deadline_seconds", "effective_request_timeout_seconds",
        "effective_no_actionable_timeout_seconds", "effective_generation_deadline_seconds",
        "time_to_first_event_seconds", "stream_events_received", "largest_inter_event_gap_seconds",
        "stream_idle_seconds_at_failure", "elapsed_generation_seconds", "duration_seconds", "threshold_seconds",
        "repeated_period_characters", "repeated_window_characters", "repeated_fragment_count",
        "recovery_attempt", "retry_limit", "effective_output_token_limit", "effective_temperature"]) {
        if (finite(diagnostic[key])) span.streamDiagnostic[key] = diagnostic[key];
      }
      if (["connect", "headers", "first_event", "between_events", "sse_decode", "sse_parse",
        "native_assembly", "terminal_validation", "unknown"].includes(diagnostic.stream_failure_stage))
        span.streamDiagnostic.stream_failure_stage = diagnostic.stream_failure_stage;
    }
    // Several events can reject one decision. Keep its specific error when a
    // later event only says, for example, "invalid_completion".
    const isCode = value => /^[a-z][a-z0-9_]*$/.test(value);
    const rank = description.model_failure ? 5 + description.specificity
      : error && !isCode(error) ? 4 : reason && !isCode(reason) ? 3
      : description.specificity ? 2 : 1;
    if (span.reason && rank < span.reasonRank) return;
    // A duplicate notice may omit the reason code that explained this error.
    if (span.reason === (error || reason) && span.reason_short && !description.specificity) return;
    span.reasonRank = rank;
    span.reason = description.model_failure ? description.reason_short : error || reason || ({model_generation_stalled_no_action: "Generation inactivity timeout",
      model_generation_repetitive: "Repetitive generation", model_generation_deadline: "Generation time limit",
      model_output_truncated: "Output truncated", native_stream_incomplete: "Output truncated",
      invalid_arguments_json: "Malformed agent response", native_protocol_error: "Malformed agent response",
      native_stream_error: "Malformed agent response", cancelled: "Cancelled", model_cancelled: "Cancelled"})[kind]
      || (kind?.includes("truncat") ? "Output truncated" : safe(kind) || "Agent response rejected");
    span.reason_short = description.reason_short;
    span.reason_long = description.reason_long;
  }
  const settledActivities = new Set(["completed", "failed", "cancelled", "rejected_policy",
    "blocked_conflict", "blocked_dependency", "unknown"]);
  /** Roll up leaf outcomes without replacing recorded execution statuses. */
  function groupOutcomes(state) {
    const children = new Map(), members = new Map(), results = new Map(), visiting = new Set();
    const link = (parent, id) => {
      if (!parent || parent === id) return;
      if (!children.has(parent)) children.set(parent, new Set());
      children.get(parent).add(id);
    };
    for (const [id, parent] of state.parents) link(parent, id);
    for (const span of state.tools.values()) link(span.parent, span.id);
    for (const group of state.groups.values()) for (const member of group.members.values()) {
      link(group.id, member.id); members.set(member.id, member);
    }
    const empty = () => ({total: 0, succeeded: 0, failed: 0, pending: 0, other: 0, running: false});
    function collect(id) {
      if (results.has(id)) return results.get(id);
      if (visiting.has(id)) return {...empty(), total: 1, other: 1};
      visiting.add(id);
      const span = state.tools.get(id), member = members.get(id);
      const group = ["sequence", "parallel", "batch"].includes(span?.kind);
      const ids = children.get(id) || new Set(), result = empty();
      if (group || ids.size) {
        for (const child of ids) {
          const counts = collect(child);
          for (const key of ["total", "succeeded", "failed", "pending", "other"]) result[key] += counts[key];
          result.running ||= counts.running;
        }
        // Missing or unstarted steps cannot turn a completed receipt into success.
        const missing = Math.max(0, (span?.steps ?? (ids.size || 1)) - ids.size);
        result.total += missing;
        result[span?.terminal ? "other" : "pending"] += missing;
        result.running ||= !span?.terminal && !state.run.terminal;
      } else {
        const status = String(span?.status || "").toLowerCase();
        const failed = ["failed", "error", "timed_out", "failed_to_start"].includes(status)
          || ["failed", "rejected_policy", "blocked_conflict", "blocked_dependency"].includes(member?.state)
          || Number.isInteger(span?.exitCode) && span.exitCode !== 0;
        const settled = span?.terminal || settledActivities.has(member?.state);
        const succeeded = !span?.notRun && member?.executed !== false
          && (member?.state === "completed" || ["completed", "succeeded"].includes(status));
        result.total = 1;
        result[failed ? "failed" : succeeded ? "succeeded"
          : settled || span?.notRun || state.run.terminal ? "other" : "pending"] = 1;
        result.running = result.pending > 0;
      }
      result.outcome = result.failed === result.total && result.total ? "failure"
        : result.failed || result.other ? "warning"
          : result.total && result.succeeded === result.total && !result.running ? "success" : null;
      visiting.delete(id); results.set(id, result);
      return result;
    }
    for (const span of state.tools.values()) {
      if (["sequence", "parallel", "batch"].includes(span.kind)) collect(span.id);
    }
    return new Map([...results].filter(([id]) =>
      ["sequence", "parallel", "batch"].includes(state.tools.get(id)?.kind)));
  }
  /** Recompute a presentation group from recorded child outcomes and execution intervals.
   * Missing process times remain unknown; admission ceilings never imply overlap. */
  function refreshGroup(state, group, changed) {
    // An explicit parallel call already owns its parent. Ordinary batches only
    // acquire a presentation parent when at least two operations share an ID.
    if (group.implicit && group.members.size < 2) return;
    if (!group.implicit && state.tools.get(group.id)?.kind !== "parallel") return;
    const parent = state.tools.get(group.id) || spanFor(state, "batch", group.id, group.event);
    const members = [...group.members.values()];
    const children = members.map(member => state.tools.get(member.id));
    const shell = members.length && members.every((member, index) => member.tool
      ? member.tool.startsWith("shell__") : children[index]?.label?.startsWith("Shell"));
    parent.label = shell || !group.implicit ? "Shell batch" : "Activities";
    parent.steps = Math.max(parent.steps || 0, members.length);
    for (const child of children.filter(Boolean)) {
      state.parents.set(child.id, parent.id);
      if (child.parent !== parent.id) { child.parent = parent.id; changed.add(child); }
    }
    /** A durable Activity outcome can settle a child before its job snapshot arrives. */
    const settled = (member, index) => children[index]?.terminal || settledActivities.has(member.state);
    const done = members.filter(settled).length;
    const failed = members.filter((member, index) => ["failed", "unknown", "rejected_policy",
      "blocked_conflict", "blocked_dependency"].includes(member.state)
      || children[index]?.status === "Failed" || children[index]?.exitCode > 0).length;
    const stopped = members.some((member, index) => member.state === "cancelled"
      || children[index]?.status === "Stopped" && !settledActivities.has(member.state));
    const waiting = members.filter((member, index) => member.waiting && !settled(member, index)).length;
    const running = children.filter((child, index) => child && !child.terminal && !child.notRun
      && valid(child.start) && !members[index].waiting).length;
    const starts = children.filter(child => child && !child.notRun && valid(child.start));
    if (starts.length) parent.start = Math.min(...starts.map(child => child.start));
    if (group.implicit) {
      parent.terminal = Boolean(members.length && done === members.length) || state.run.terminal;
      parent.notRun = members.length > 0 && children.every((child, index) =>
        child?.notRun || members[index].executed === false);
      parent.status = failed ? "Failed" : stopped || state.run.terminal && done < members.length
        ? "Stopped" : parent.terminal ? parent.notRun ? "Not run" : "Completed"
          : waiting && !running ? "Waiting for capacity" : "Running";
      parent.duration = null;
      parent.end = parent.terminal ? Math.max(...members.map((member, index) => {
        const child = children[index];
        return valid(member.end) && (!valid(child?.end) || child?.runBounded) ? member.end : child?.end;
      }).filter(valid)) : NaN;
      if (!valid(parent.end) && state.run.terminal) parent.end = state.run.end;
    }
    // Count observed overlap, not a configured ceiling or requested parallelism.
    // Shell adapter preparation is not proof of physical execution.
    const measured = starts.filter(child => !child.runBounded && (!child.background || child.jobFinished) &&
      (!child.label?.startsWith("Shell") || child.kind === "sequence" || child.startRank === 2 || child.jobFinished));
    const edges = measured.flatMap(child => valid(child.end)
      ? child.end > child.start ? [[child.start, 1], [child.end, -1]] : []
      : child.terminal ? [] : [[child.start, 1]]);
    let active = 0, peak = 0;
    for (const [, change] of edges.sort((a, b) => a[0] - b[0] || a[1] - b[1])) {
      active += change; peak = Math.max(peak, active);
    }
    const known = members.length === parent.steps && children.every((child, index) =>
      child?.notRun || members[index].executed === false || measured.includes(child) && valid(child.end));
    const concurrency = peak > 1 ? `${parent.terminal ? "Ran" : "Running"} up to ${peak} simultaneously`
      : parent.terminal && known && peak === 1 && measured.length > 1 ? "Ran sequentially"
        : parent.terminal && known && measured.length === 1 ? "1 operation ran"
          : parent.notRun ? "No operations ran" : parent.terminal ? "Execution timing unavailable" : "";
    parent.groupSummary = [parent.terminal ? failed ? `${failed} failed` : stopped ? "Stopped" : ""
      : `${done} of ${parent.steps} completed`, !parent.terminal && running ? `${running} running` : "",
    !parent.terminal && failed ? `${failed} failed` : "",
    waiting ? `${waiting} waiting for capacity` : "", concurrency].filter(Boolean).join(" · ");
    changed.add(parent);
  }
  /** Retain exact batch/parent identities through replay and resolve Activity-only waits.
   * No timestamp or command-text heuristic assigns a child to a group. */
  function groupEvent(state, event, changed) {
    const type = event.event_type || "", d = event.detail || {};
    const id = d.operation_id || d.job_id || state.activityOperations.get(d.activity_id);
    const touched = new Set();
    if (type.startsWith("activity.") && id) {
      if (d.activity_id) state.activityOperations.set(d.activity_id, id);
      const key = d.parallel_parent_id || state.groupParents.get(id)
        || (d.batch_id ? `batch:${d.batch_id}` : null);
      if (key) {
        let group = state.groups.get(key);
        if (!group) {
          group = {id: key, implicit: !d.parallel_parent_id, members: new Map(), event};
          state.groups.set(key, group);
        }
        const member = group.members.get(id) || {id};
        if (d.tool_name) member.tool = d.tool_name;
        if (d.state) member.state = d.state;
        if (typeof d.executed === "boolean") member.executed = d.executed;
        if (type === "activity.waiting_capacity") member.waiting = true;
        else if (d.state || type === "activity.started") member.waiting = false;
        if (settledActivities.has(member.state)) member.end = stamp(event.timestamp);
        group.members.set(id, member); state.groupParents.set(id, key); touched.add(group);
      }
    }
    for (const child of changed) {
      const group = state.groups.get(state.groupParents.get(child.id));
      if (group) touched.add(group);
    }
    if (type.startsWith("parallel.")) {
      const group = state.groups.get(id);
      if (group) touched.add(group);
    }
    if (type.startsWith("request.") || type === "run.resumed") {
      for (const group of state.groups.values()) touched.add(group);
    }
    for (const group of touched) refreshGroup(state, group, changed);
  }
  function reduce(state, event) {
    const type = String(event.event_type || ""), d = event.detail || {}, changed = new Set();
    const at = stamp(event.timestamp);
    if (["request.created", "request.received", "request.submitted", "request.running"].includes(type)) {
      if (!valid(state.run.start) && valid(at)) state.run.start = at;
    }
    if (type === "run.resumed" || (type === "request.running"
      && (!valid(state.run.end) || !valid(at) || at > state.run.end))) {
      resumeRun(state);
    }
    if (/^request\.(completed|failed|cancelled|interrupted)$/.test(type)) {
      finishRun(state, at, changed);
      // A user-input wait ends an execution attempt, while task wall time continues.
      if (type === "request.completed" && liveRunStatuses.has(runStatus(d))) resumeRun(state);
    }
    if (type === "model.started") {
      state.currentDecision = d.call ?? null; state.currentModel = null;
    }
    if (type === "model.recovery_started") state.recovery = true;
    if (["task_contract.completed", "task_contract.failed", "task_contract.clarification_required"].includes(type)) {
      const span = state.models.get(state.contractModel);
      if (span) {
        span.contractOutcome = type.split(".")[1]; changed.add(span);
      }
    }
    if (["model.rejected", "tool.validation_rejected", "provider.response_rejected",
      "completion.rejected", "completion.direct_rejected", "protocol.metadata_rejected",
      "completion.protocol_retry"].includes(type)) {
      const span = state.models.get(d.call_id || (d.call !== undefined
        ? state.decisions.get(d.call) : state.currentModel));
      if (span) {
        reject(span, d);
        if (type === "tool.validation_rejected") span.decision = "Tool call rejected";
        changed.add(span);
      }
    }
    const modelStart = ["llm.request", "llm.request.started"].includes(type);
    const modelEnd = ["llm.response", "llm.error", "llm.cancelled", "llm.response.completed",
      "llm.response.accepted", "llm.response.rejected"].includes(type);
    if (d.call_id && (modelStart || modelEnd || type === "llm.response.progress")) {
      // Progress alone never invents a call; late progress can refine metadata only.
      let span = state.models.get(d.call_id);
      if (modelEnd || (modelStart && !state.run.terminal)) span ||= spanFor(state, "model", d.call_id, event);
      if (span) {
        times(span, event, {start: modelStart, end: modelEnd});
        if (event.stage === "task_contract" || d.phase === "task_contract") span.phase = "task_contract";
        if (modelStart && span.phase === "task_contract") state.contractModel = span.id;
        if (d.model) span.model = safe(d.model);
        if (modelStart && span.phase !== "task_contract" && (event.stage === "native_decision" || d.pipeline_mode === "native_tools")) {
          // Native lifecycle has a decision number; the provider span has a call_id.
          // Retain their existing relationship for later numbered rejection notices.
          if (state.currentDecision !== null) state.decisions.set(state.currentDecision, span.id);
          state.currentModel = span.id;
          span.recovery ||= state.recovery; state.recovery = false;
        }
        if (modelEnd) {
          if (type === "llm.cancelled") { span.status = "Stopped"; span.reason = ""; }
          else if (type === "llm.error" || type.endsWith(".rejected")) reject(span, d);
          else if (!["Rejected", "Stopped"].includes(span.status)) span.status = "Completed";
          const names = Array.isArray(d.functions) ? d.functions : [];
          span.decision = names.some(name => ["finish_task", "complete_task"].includes(name)) ? "Answer"
            : d.decision_kind === "answer" ? "Answer"
              : d.decision_kind === "tool" || names.length ? "Tool decision" : "";
        } else if (!span.terminal) span.status = valid(span.first) ? "Responding" : "Thinking";
        changed.add(span);
      }
    }
    const id = String(d.operation_id || d.action_id || d.execution_id || "");
    if (type === "sequence.step_started" && id && d.child_operation_id) {
      state.parents.set(d.child_operation_id, id);
      const child = state.tools.get(d.child_operation_id);
      if (child) { child.parent = id; changed.add(child); }
    }
    if (type.startsWith("activity.") && id && d.parallel_parent_id) {
      state.parents.set(id, d.parallel_parent_id);
      const child = state.tools.get(id);
      if (child) { child.parent = d.parallel_parent_id; changed.add(child); }
    }
    const toolStart = ["invocation.started", "execution.command.started", "sequence.started", "parallel.started"].includes(type);
    const toolEnd = ["invocation.completed", "execution.command.completed", "execution.command.cancelled",
      "execution.command.error", "sequence.completed", "parallel.completed"].includes(type);
    if (id && (toolEnd || (toolStart && (!state.run.terminal || state.tools.has(id))))) {
      const sequence = type.startsWith("sequence.") || d.capability_id === "shell.sequence";
      const parallel = type.startsWith("parallel.");
      const span = spanFor(state, sequence ? "sequence" : parallel ? "parallel" : "tool", id, event);
      if (sequence || parallel) span.kind = sequence ? "sequence" : "parallel";
      // A retained rejected batch can start after the user resolves its conflict.
      // Historical starts before the terminal event must still leave it frozen.
      if (parallel && toolStart && span.notRun && span.terminal && valid(at) && at > span.end) {
        span.terminal = false; span.notRun = false; span.end = NaN; span.duration = null;
        span.status = "Running";
      }
      // Concrete process timing wins over the surrounding adapter bookkeeping.
      const rank = type.startsWith("execution.command.") ? 2 : 1;
      times(span, event, {start: toolStart, end: toolEnd, rank});
      span.parent = state.parents.get(id) || d.sequence_parent_id || span.parent;
      span.label = sequence ? "Shell Sequence" : parallel ? "Shell Parallel" : safe(d.presentation?.skill_label)
        || (d.kind === "python_action" ? "Python" : type.startsWith("execution.command.") ? "Shell" : span.label);
      if (finite(d.steps)) span.steps = d.steps;
      if (Number.isInteger(d.exit_code)) span.exitCode = d.exit_code;
      if (typeof d.executed === "boolean") span.notRun = d.executed === false;
      if (["confirmation_required", "skipped"].includes(d.status)) span.notRun = true;
      if (sequence && toolEnd && d.executed_steps === 0) span.notRun = true;
      if (d.executed_steps > 0) span.notRun = false;
      if (toolEnd) span.status = span.notRun ? "Not run"
        : d.status === "waiting_job" ? "Wait registered · Agent suspended"
        : /cancelled$/.test(type) || d.status === "cancelled" ? "Stopped"
          : ["failed", "error"].includes(d.status) || type.endsWith(".error") ? "Failed" : "Completed";
      if (toolEnd && (d.process_state === "running" || d.job_id)
          && ["queued", "starting", "running"].includes(d.job_state || "running")) {
        // A background launch receipt is not a process completion. The existing
        // native job snapshot supplies actual process timestamps when available.
        span.background = true; span.start = NaN; span.end = NaN; span.duration = null;
        span.notRun = false;
        span.terminal = false; span.status = ({queued: "Queued", starting: "Starting"})[d.job_state] || "Running";
      }
      changed.add(span);
    }
    if (type.startsWith("activity.") && d.job_id && d.job_state) {
      for (const span of jobs(state, [{job_id: d.job_id, state: d.job_state,
        started_at: d.job_started_at, finished_at: d.job_finished_at, exit_code: d.exit_code}])) changed.add(span);
    }
    groupEvent(state, event, changed);
    for (const span of changed) {
      if (span.terminal || span.notRun || state.run.terminal) state.active.delete(span);
      else state.active.add(span);
    }
    if (changed.size || type.startsWith("request.") || type === "run.resumed") state.revision++;
    return changed;
  }
  function jobs(state, values = []) {
    const changed = new Set();
    if (!Array.isArray(values)) return changed;
    for (const job of values) {
      const span = state.tools.get(job.job_id);
      if (!span || !span.background || span.jobFinished) continue;
      const ended = ["succeeded", "completed", "failed", "cancelled", "lost"].includes(job.state);
      if (state.run.terminal && !ended) continue;
      const started = finite(job.started_at) ? job.started_at * 1000 : NaN;
      const finished = finite(job.finished_at) ? job.finished_at * 1000 : NaN;
      span.start = started; span.end = finished; span.duration = null;
      span.terminal = ended; span.runBounded = false;
      span.status = ({succeeded: "Completed", completed: "Completed", failed: "Failed",
        cancelled: "Stopped", lost: "Outcome unknown", unknown: "Outcome unknown",
        queued: "Queued", starting: "Starting"})[job.state] || "Running";
      if (Number.isInteger(job.exit_code)) span.exitCode = job.exit_code;
      if (span.terminal && valid(finished)) span.jobFinished = true;
      if (span.terminal || state.run.terminal || !valid(started)) state.active.delete(span);
      else state.active.add(span);
      changed.add(span);
    }
    for (const group of state.groups.values()) {
      if ([...group.members.keys()].some(id => changed.has(state.tools.get(id)))) {
        refreshGroup(state, group, changed);
        const parent = state.tools.get(group.id);
        if (parent) {
          if (parent.terminal || state.run.terminal) state.active.delete(parent);
          else state.active.add(parent);
        }
      }
    }
    if (changed.size) state.revision++;
    return changed;
  }
  const ordered = state => [...state.models.values(), ...state.tools.values()].sort((a, b) =>
    valid(a.start) && valid(b.start) && a.start !== b.start ? a.start - b.start : a.order - b.order);
  function interval(span, now) {
    const ms = duration(span, now);
    return finite(ms) && valid(span.start) ? [span.start, span.start + ms] : null;
  }
  function union(intervals) {
    const merged = [];
    for (const [start, end] of intervals.filter(Boolean).sort((a, b) => a[0] - b[0])) {
      const last = merged.at(-1);
      if (last && start <= last[1]) last[1] = Math.max(last[1], end);
      else merged.push([start, end]);
    }
    return merged;
  }
  const length = intervals => intervals.reduce((sum, [a, b]) => sum + Math.max(0, b - a), 0);
  function totals(state, now) {
    // Historical intervals are cached; ticks only add the currently active spans.
    if (state.cache?.revision !== state.revision) {
      const models = [...state.models.values()];
      const tools = [...state.tools.values()].filter(s => !s.notRun && (!s.parent
        || !interval(state.tools.get(s.parent) || {}, now)));
      state.cache = {revision: state.revision,
        llm: union(models.filter(s => s.terminal).map(s => interval(s, now))),
        tools: union(tools.filter(s => s.terminal).map(s => interval(s, now))),
        incomplete: [...models, ...tools].some(s => s.terminal && !interval(s, now))};
    }
    const active = [...state.active];
    const llm = union([...state.cache.llm, ...active.filter(s => s.kind === "model").map(s => interval(s, now))]);
    const tools = union([...state.cache.tools, ...active.filter(s => s.kind !== "model" && !s.parent).map(s => interval(s, now))]);
    const total = duration(state.run, now), known = length(union([...llm, ...tools]));
    return {total, llm: length(llm), tools: length(tools),
      other: finite(total) && !state.cache.incomplete ? Math.max(0, total - known) : null,
      incomplete: state.cache.incomplete};
  }
  // Presentation only: retain provider statuses and decision metadata for diagnostics.
  function activityLabel(span) {
    if (span.kind === "batch" || span.kind === "parallel" && span.groupSummary !== undefined) {
      return `${span.label} ${span.status.toLowerCase()}`;
    }
    if (span.kind === "parallel") return ({Running: "Running Shell Parallel", Completed: "Ran Shell Parallel",
      Failed: "Shell Parallel failed", Stopped: "Shell Parallel stopped", "Not run": "Shell Parallel not run"})[span.status]
      || `Shell Parallel · ${span.status}`;
    if (span.kind !== "model") return span.recovery ? `Recovery ${span.status.toLowerCase()}` : span.status;
    if (span.phase === "task_contract") return span.terminal
      ? span.contractOutcome === "completed" ? "Task contract generated"
        : span.contractOutcome === "clarification_required" ? "Task contract needs clarification"
          : span.contractOutcome === "failed" || ["Rejected", "Stopped"].includes(span.status)
            ? "Task contract generation failed" : "Validating task contract"
      : "Generating task contract";
    if (span.modelFailure) return span.reason_short;
    if (span.status === "Rejected") return `Action Rejected: ${span.reason_short}`;
    return ["Thinking", "Responding", "Completed"].includes(span.status)
      ? "Thinking" : `Thinking ${span.status.toLowerCase()}`;
  }
  function heading(span, now) {
    const ms = duration(span, now);
    return [activityLabel(span), span.notRun ? "" : format(ms),
      span.kind === "model" && span.recovery ? "Retry" : "",
      span.decision === "Tool decision" ? "" : span.decision,
      span.steps !== undefined ? `${span.steps} ${span.steps === 1 ? "operation" : "operations"}` : "",
      Number.isInteger(span.exitCode) ? `exit ${span.exitCode}` : ""].filter(Boolean).join(" · ");
  }
  function detail(span, now) {
    const ms = duration(span, now);
    const pre = finite(span.preOutput) ? span.preOutput
      : valid(span.first) && valid(span.start) ? Math.max(0, span.first - span.start) : null;
    return [span.model ? `Model: ${span.model}` : span.kind === "model" ? "Model" : span.label,
      valid(span.start) ? `Started: ${new Date(span.start).toISOString()}` : "",
      valid(span.end) ? `Finished: ${new Date(span.end).toISOString()}` : "",
      span.notRun ? "Not run" : `Duration: ${format(ms, true)}`,
      finite(pre) ? `Thinking/pre-output: ${format(pre, true)}` : "",
      finite(pre) && finite(ms) ? `Responding: ${format(Math.max(0, ms - pre), true)}` : "",
      span.steps !== undefined ? `Steps: ${span.steps}` : "",
      `Outcome: ${span.status}`, span.decision ? `Decision: ${span.decision}` : "", span.reason,
      span.noOperationAuthorized ? "No operation from the incomplete response executed" : span.nothingExecuted ? "Nothing executed" : "",
      ...Object.entries(span.streamDiagnostic || {}).map(([key, value]) => {
        const labels = {category: "Cause", configured_llm_timeout_seconds: "Configured request timeout (seconds)",
          configured_no_actionable_output_timeout_seconds: "Generation inactivity allowance (seconds)",
          configured_constrained_recovery_timeout_seconds: "Recovery inactivity allowance (seconds)",
          configured_recovery_deadline_seconds: "Optional recovery deadline (seconds; 0 = Off)",
          effective_request_timeout_seconds: "Effective request timeout (seconds)",
          effective_no_actionable_timeout_seconds: "Effective inactivity allowance (seconds)",
          effective_generation_deadline_seconds: "Effective generation deadline (seconds)",
          time_to_first_event_seconds: "Time to first event (seconds)", stream_events_received: "Events received",
          largest_inter_event_gap_seconds: "Largest event gap (seconds)",
          stream_idle_seconds_at_failure: "Idle time at failure (seconds)",
          elapsed_generation_seconds: "Elapsed model time (seconds)", stream_failure_stage: "Failure stage",
          duration_seconds: "Measured duration (seconds)", threshold_seconds: "Threshold (seconds)",
          repeated_period_characters: "Exact repeat period (characters)", repeated_window_characters: "Repeated window (characters)",
          repeated_fragment_count: "Exact repetitions", recovery_attempt: "Recovery attempt", retry_limit: "Recovery limit",
          effective_output_token_limit: "Effective output token limit", effective_temperature: "Effective temperature"};
        return `${labels[key]}: ${value}`;
      }),
      span.runBounded ? "Timing ended at run stop; final receipt unavailable." : "",
      span.background && !valid(span.start) ? "Background process timing is not yet available." : "",
      span.kind === "model" ? "Thinking measures request start to first actionable output, not internal reasoning." : "",
    ].filter(Boolean).join("\n");
  }
  function createTicker({now, tick, schedule = setTimeout, cancel = clearTimeout, visible = () => !document.hidden}) {
    let timer = null, enabled = false;
    function stop() { if (timer !== null) cancel(timer); timer = null; }
    function run() {
      stop();
      if (!enabled || !visible()) return;
      tick(now()); timer = schedule(run, 200);
    }
    return {update(active) { enabled = active; stop(); if (active) run(); },
      pause: stop, resume: run, dispose() { enabled = false; stop(); }};
  }
  window.SMTOPerformanceTiming = {create, reduce, restore, jobs, duration, format, responseBreakdown, activityLabel, heading,
    detail, ordered, totals, groupOutcomes, createTicker, terminal};
})();
