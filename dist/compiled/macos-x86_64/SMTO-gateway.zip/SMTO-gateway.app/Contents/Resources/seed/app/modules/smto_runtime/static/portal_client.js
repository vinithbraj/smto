/* One authenticated request helper for desktop, mobile, lifecycle and console pages. */
(() => {
  'use strict';
  if (window.SMTOAuth) return;
  const nativeFetch = window.fetch.bind(window);
  const prefix = new URL(document.currentScript.src).pathname.replace(/\/auth\/client\.js$/, '');
  let session = null, refreshing = null, redirecting = false;
  const endpoint = path => prefix + path;
  function signIn() {
    if (redirecting) return;
    redirecting = true;
    location.replace(endpoint('/login') + '?next=' + encodeURIComponent(location.pathname + location.search + location.hash));
  }
  async function refresh() {
    if (refreshing) return refreshing;
    refreshing = (async () => {
      const response = await nativeFetch(endpoint('/auth/session'), {cache: 'no-store', credentials: 'same-origin'});
      if (response.status === 401 || response.status === 503) { signIn(); return null; }
      if (!response.ok) throw new Error('Unable to verify sign-in.');
      session = await response.json(); return session;
    })();
    try { return await refreshing; } finally { refreshing = null; }
  }
  async function authenticatedFetch(input, options = {}) {
    const url = new URL(input instanceof Request ? input.url : input, location.href);
    const local = url.origin === location.origin && url.pathname.startsWith(prefix + '/');
    const method = String(options.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    if (local && !['GET', 'HEAD', 'OPTIONS'].includes(method)) {
      if (!session) await refresh();
      if (!session) throw new Error('Sign in to continue.');
      const headers = new Headers(options.headers || (input instanceof Request ? input.headers : undefined));
      headers.set('X-SMTO-CSRF', session.csrf_token);
      options = {...options, headers};
    }
    const response = await nativeFetch(input, options);
    if (local && response.status === 401) signIn();
    return response;
  }
  window.SMTOAuth = Object.freeze({fetch: authenticatedFetch, refresh});
  const initial = refresh().catch(() => null);
  async function mount() {
    if (!await initial) return;
    const button = document.createElement('button');
    button.type = 'button'; button.textContent = 'Sign out'; button.id = 'portal-sign-out';
    button.setAttribute('aria-label', 'Sign out of smTO');
    const target = document.querySelector('#more-menu, #settings-secondary-actions, .console-topbar nav, .header-actions, header nav, .startup-footer') || document.body;
    if (!target.matches('#more-menu, #settings-secondary-actions, .settings-surface-actions')) {
      button.style.cssText = 'min-height:40px;padding:6px 10px;border:1px solid #8795a8;border-radius:8px;background:Canvas;color:CanvasText;font:13px system-ui;cursor:pointer';
    }
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        const response = await authenticatedFetch(endpoint('/auth/logout'), {method: 'POST'});
        if (response.ok) { session = null; signIn(); }
        else button.disabled = false;
      } catch (_) { button.disabled = false; }
    });
    target.append(button);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount, {once: true});
  else mount();
  // Covers EventSource reconnection and restoration from the back/forward cache.
  window.addEventListener('pageshow', () => refresh().catch(() => {}));
  window.addEventListener('focus', () => refresh().catch(() => {}));
  setInterval(() => { if (!document.hidden) refresh().catch(() => {}); }, 15000);
})();
