---
id: context-compaction-kv
title: Context, compaction, Agent KV and Memory
kind: architecture
tags: [architecture, current, context-compaction-kv]
order: 22
---
# Context, compaction, Agent KV and Memory

The exact native journal is durable evidence. Model context is a bounded projection of
that evidence plus current instructions, schemas, working context and user input.
Context read policy constrains how stored material is accessed; it does not turn all
stored data into automatic memory.

Settings → Advanced → **Context carried forward** defaults to All, preserving the
existing projection. Desktop Controls and mobile Agent options can choose Most recent
a Rolling window of 1–24 finished runs, **Use task skill**, or the global default. The policy
applies to Agent continuations and Conversation history (including Ask and Plan).
Independent Agent tasks retain their isolation. Accepted runs and resumes retain
captured settings. Summaries reuse completion output or local facts and never add
an inference call. See the [carry-forward guide](../../../../docs/context-carry-forward.md)
for boundaries, diagnostics, retrieval costs and performance release gates.

**Use task skill** uses a separate clean-epoch projection. The always-available
`task_context` skill exposes metadata-first browsing, scoped lexical search, bounded
reads and revision-checked task notes. Each logical sub-conversation has its own
notebook; Steer and Continue retain it, while independent tasks and branches are
isolated. The agent must inspect first, read applicable constraints, fetch only what
its next decision requires and stop retrieving when it has enough. Historical lookup
covers retained authorized material beyond the capsule window. Task notes aid
resumption but never amend authority or prove an execution outcome.

Full automatic history, setup, artifact and parameter blocks are omitted in this mode.
Protected accepted inputs and bounded task progress remain available. Newly accepted
tasks also receive eligible durable-memory summaries and verified learning candidates.
Saved Memory tools remain available. A new substantive
turn or Continue starts a fresh epoch; recovery, waits and pending-control replies
retain it. Core instructions and ordinary current-epoch tool replies remain present.

**Settings → Advanced → Task Context reads** configures Unicode characters per read:
4,000 by default and 12,000 maximum initially, with **Restore defaults**. Both values
are editable positive integers, including values above 12,000; the default cannot
exceed the maximum. Accepted tasks and continuations retain their snapshot. Source
restrictions and model capacity still apply. These controls do not change attached
Context policy, orientation, listing/search bounds or the 4,000-character note limit.
See the carry-forward guide for the tool contracts, isolation, recovery and costs.

Settings → Advanced → **Reuse request instruction fragments** reuses small immutable
instruction strings within the current run. It preserves the single leading system
message, current authority, tool schemas, history, exact result pages and reasoning
settings. Accepted tasks retain this strict boolean across queue, resume, continuation
and restart; the default is on. Off restores uncached construction with the same
request layout. This setting does not manage the model server's cache. The
[request construction guide](../../../../docs/request-prefix-construction.md) describes
component ownership, invalidation and optional synthetic prefix diagnostics.

The canonical execution prompt in `native/protocol.py` teaches a **bounded working
set**: model context is finite working memory, and tool results or script stdout
may become the next model input. Inspect scope first, use the largest safe bounded
batch, persist large intermediates, and retrieve exact portions when needed. Keep
complete requested deliverables and necessary evidence while avoiding unnecessary
raw data in the next decision. This applies across all effort levels and preserves
independent parallelism. The Task Contract compiler has separate instructions.

Settings → Advanced → **Context-efficient execution** controls this guidance and
defaults to on. The backend captures the boolean at task acceptance and retains it
across resume/continue/restart. The canonical block appears once in the leading
system message when enabled, and zero times when disabled; it is not repeated in
stable/current task context. Projection adds the default block to pre-feature
checkpoints without rewriting user messages or exact receipts. No model or tool
calls implement the guidance, and it does not change observation or overflow rules.

Examples of intended execution:

| Work | Bounded working set |
| --- | --- |
| Inspect 135 Markdown files | Count candidates; process bounded batches or an incremental pass; save the rename mapping; inspect ambiguous records and verify renames. |
| Diagnose a large log | Search the relevant time/error window and read surrounding lines; expand when needed. |
| Generate a large report | Write the complete artifact directly, verify it, and return its path, size and key findings. |
| Edit a large source file | Find the symbol, read its region, apply a focused patch, inspect the diff and run relevant tests. |
| Traverse a large API | Filter/select/page at the source; persist aggregates when exhaustive processing is required. |
| Work with Full Tool Results on | Choose bounded-producing operations when practical; complete current results remain complete and subject to the existing capacity check. |

`native/compaction.py` budgets a coherent provider message projection without summary
inference. It measures context using provider preflight when available and conservative
local estimates otherwise, prunes eligible history/result groups, and retains protected
current material. Manual/forced compaction and overflow recovery have explicit state.
If protected inputs cannot fit, the runtime reports the capacity problem rather than
claiming the omitted input was processed. Exact receipts remain in the journal.
Compaction activity and timing explain changes to the projection, not deletion of work.

Full Tool Results preserves every distinct captured value. For shell and Python results,
an `output` string identical to `stdout` appears once in model context; both fields
remain available in the stored receipt. Saved observations receive the same normalization
when projected, without rewriting the journal. No distinct stdout, stderr or structured
result is discarded.

Failed exchanges and their immediate corrections stay protected until recovery is
proven for the same scoped operation, or trusted capability evidence explicitly
supersedes the failed receipt. Only failures known not to leave uncertain external
effects can become eligible. An unrelated successful script is insufficient. Open
requirements, authentication/permission exchanges, unknown effects and the latest
four exchanges retain their protection.

Provider counters include tool schemas and supported template options. If no exact
count is available, overflow diagnostics explicitly identify a local estimate.
Repeated valid provider usage can calibrate estimates downward as well as upward;
the highest recent ratio and a safety margin remain in force.

Execution budgeting uses the run's pinned `execution_output_reservation_tokens`.
An explicit `max_completion_tokens` request override sets that reservation; Provider
Default omits the wire limit but retains the existing internal output allowance as a
reservation. Preflight, compaction, context reads and goal echo use the same execution
reservation. Internal inference retains `client.max_tokens` and its phase-specific
Task Contract/recovery profile. The execution map, profile, version and reservation
are deep-copied into `effective_model` and `resume_context`; global Settings changes
cannot silently retune a resumed run.

Agent KV is a conversation-scoped durable notebook with explicit `kv.put`, `kv.get`,
`kv.search`, `kv.list` and `kv.delete` operations. It survives restart and compaction,
but is not automatically retrieved or injected. Values are non-secret; validators reject
protected content. The SQLite owner applies revision compare-and-set, quotas, expiry
and conversation deletion rules. Conversation revision counters prevent stale identities
from becoming valid after delete/recreation.

Working Context records verified setup/resource facts with capability-owned access and
publication. These facts are neither fresh external observations nor unrestricted
credential storage. Use the owning capability to validate current external state.


## Durable cross-conversation Memory

**Memory** is a built-in skill, always selected alongside Agent Introspection and Shell
in both Automatic and Manual capability selection. Desktop and mobile show these skills
as always enabled. New requests normalize saved Memory/Shell exclusions away; already
accepted runs retain their captured selection. Execution restrictions still apply, and
Advisory mode allows local Memory but does not execute Shell commands.

The main Agent proactively saves verified reusable learning during ordinary work. The
user does **not** have to say “remember.” Corrected CLI syntax after verified success,
known-good commands, workarounds, compatibility quirks and stable environment/project
conventions are strong candidates. This is selective learning, not a journal: transient
PIDs, load, temporary paths, unresolved failures, guesses, transcripts and raw outputs
should not be copied. A user instruction not to remember information takes precedence.
Optional learning must not delay critical recovery or claim persistence when storage fails.

The routine is **recall → learn → save**. Stable user preferences and verified project
conventions can qualify without a prior failure. When a topic first emerges during work,
search with a few exact metadata terms or aliases, then explicitly get useful values.
Search uses AND semantics, so every term must match; long prose questions usually do not.
Tags should include relevant aliases and singular/plural variants that later requests use.
No qualifying lesson means no write. Most runs need zero to two durable lessons.

After a definite failed operation followed by a materially different successful attempt
in the same literal executable/resource family, the runtime supplies a small learning
opportunity in the next ordinary decision. The Agent writes the meaning; the runtime
never extracts or saves a lesson itself. Help/version calls, identical retries, opaque
commands, unrelated resources and incomplete or unknown outcomes do not prove corrections.
At most four pending and eight resolved candidates are retained, using a 16-operation
correlation window and a 1,200-character projection. Only operation IDs, hashes and safe
metadata are retained, never commands, output or values. Fingerprints use only safe
execution semantics; credentials, protected inputs, approvals and connection references
cannot distinguish retries. Shell identity uses parsed executable/argv and target scope;
structured tools require resource identity and approved schema enums. Uncertain identity
produces no candidate. Foreground and definite durable-job terminal receipts use the same
observer; a durable job marker prevents repeated learning on reconciliation. Recent explicit retrievals can
identify a canonical key/revision for refinement. An ambiguous put does not resolve all
candidates. Two consumable metadata search hints per run can identify newly encountered
literal executables; a successful bounded `cat` result containing only a literal
`tool=identifier` or `executable: identifier` declaration can also suggest that exact
term. Arbitrary output is not indexed or retained. Accepted recall bundles stay pinned
between recall triggers.

Candidate state survives ordinary continuation and runtime reconstruction. A fresh
Restart, like a new conversation/fork, deliberately does not inherit pending candidates
from abandoned execution. Optional candidates do not impose a completion requirement.

`skills/memory/skill.py` owns this guidance. It appears once through generic selected-skill
context before tool choice when the skill is selected. The normal main Agent chooses
`memory.put`; there is no extractor, classifier, post-run summarizer or background
consolidator. Ordinary Agent tool decisions may consume ordinary inference turns;
Memory introduces **zero auxiliary model calls**.

| Tool | Contract |
| --- | --- |
| `memory.put` | Store strict JSON with optional `recall`, `expected_revision`, and top-level `review_id`/`source_refs`; return metadata only. Omitted tags preserve existing tags; `[]` clears them. |
| `memory.get` | Explicitly retrieve an exact value and its revision as historical `prior_note` evidence. |
| `memory.search` | AND-match distinct exact ASCII identifiers against key/tag metadata; at most 50 results, no value snippets. |
| `memory.list` | Lexical metadata pages (at most 100), literal prefix and exact tag filters; cursor is bound to both filters. |
| `memory.delete` | Delete a record, terms and recall descriptor, optionally checking its revision. |
| `task_context.review_epoch` | Freeze and page through retained authorized epoch evidence; return a durable review ID and coverage gaps. |
| `memory.publish_epoch` | Validate reviewed lesson revisions and commit a stand-alone handoff and coverage manifest. |

Put/get/search/publish_epoch and review_epoch are core-advertised when allowed. List/delete use ordinary skill discovery.
Writes/deletes are internal effects; reads do not prove that an external resource is
currently online or configured. Fresh observations override stale Memory. Refine an
existing canonical lesson with get, merge and revision-checked put; avoid `.new`/`.fixed`
duplicates and unchanged rewrites. A successful Memory receipt is not itself new learning.
Identical canonical JSON, effective tags and recall descriptor return `unchanged=true`, without changing
the revision, timestamps, provenance or term index. Revision checks run first, so a stale
`expected_revision` still conflicts even for identical content. Omitted tags preserve the
old set; explicitly clearing a nonempty set is a real update.

Memory opts into the generic selected-skill guidance projection before tool choice.
The catalog includes a whole block only when an owned permitted tool is exposed and
the skill is available, then removes that block from tool descriptions. Other skills
keep their existing placement unless they opt in. Blocks are limited to 4,000 characters
each and 8,000 total; blocks that cannot fit retain their tool placement. This uses one
authoritative copy, is included in context accounting, and makes no inference call.

A leading explicit persistence imperative creates a receipt requirement for successful
completion. It does not enable an excluded capability. If persistence is unavailable,
the Agent must report that limitation using an incomplete outcome. Quoted examples and
ordinary optional learning do not create this requirement.

The dedicated `<controller state directory>/agent_memory.db` uses schema version 3 (migrated from v2),
global normalized-key identity and a monotonic store-wide revision allocator. Keys use
the same 1–160 ASCII character grammar as KV (`letters/digits/._:-`), normalized to
lowercase. Up to 32 tags of 1–64 characters use the same grammar, deduplicated and sorted.
Values may be objects, arrays, strings, finite numbers, booleans or null, with a 1 MiB
canonical UTF-8 JSON limit. Transactions replace entries, indexed terms and the indexed
recall side table atomically. Descriptor edits advance revision; changing the value
without updating `recall` disables its previous summary. Deletes advance the store
revision and remove recall data. SQLite and RAM authority share these contracts,
including checkpoint recovery and whole-store backup/restore.
Source conversation/run IDs are provenance only. Restart, compaction, branching and
ordinary conversation deletion leave Memory intact. Forks access the same store;
handoff does not copy Memory records or create a branch snapshot of its values.

For newly accepted tasks, the runtime snapshots the automatic recall policy. Old
checkpoints retain their previous metadata-only behavior. A record opts into summary
recall only through an explicit descriptor containing `summary` (at most 600 characters),
`kind`, `scope`, `basis`, and optional `source_refs`. Existing JSON values are never
summarized automatically. Verified facts, procedures, decisions and user-stated
preferences qualify. Hypotheses and unresolved questions remain labeled and require
explicit retrieval. A summary is historical knowledge, never authorization or proof
of current external state.

One shared service matches exact key/tag terms and aliases at task/epoch boundaries.
It uses bounded accepted user input and task-book topic metadata, without scanning
full history or arbitrary output. It returns at most three summaries within a
2,000-character serialized bundle. Project scope requires a known Gateway identity
and normalized execution root. Unknown project identity cannot match project records.
Profile scope is for general preferences and deliberately portable lessons. Explicit
search remains available across scopes.

The same typed `durable_memory` entries reach every context mode through the existing
runtime task projection and `task_context.resume`. Task context has budget priority;
`pending_memory` identifies summaries that require another bounded resume page.
New tool/resource topics and relevant failures can trigger at most two refreshes per
epoch. Scope changes immediately invalidate applicability. Positive and empty bundles
carry epoch, scope, topic and store revision; repeated decisions and recovery reuse
them. A store revision change at a trigger prevents retaining older cached summaries.
No-match recall adds no model decision. Full values remain behind `memory.get`.

A direct request such as “save everything learned this epoch” binds a durable source
epoch. A save-only follow-up selects its preceding epoch; a combined work-and-save
request selects the working epoch. An explicit `tce_…` reference can select an older
authorized epoch. Quoted examples, hypothetical questions and tool output do not bind
this requirement.

The main Agent calls `task_context.review_epoch` and follows every cursor. The review
freezes retained user messages, visible assistant messages, tool evidence and authored
fact/work changes; it neither reruns tools nor fetches external resources. Pages honor
notebook ownership, source restrictions, redaction and read limits. Only page ranges
actually delivered to a successful model decision count as reviewed. The accepted
epoch request is also a valid source reference when the runtime verifies that it
contains exactly the same reviewed user text; arbitrary aliases are rejected. Review progress
survives compaction, checkpoint recovery and backup. Changed or unavailable sources,
retention gaps and unresolved operations are explicit in the result.

Comprehensive consolidation has no zero-to-two-lesson limit. Save distinct reusable
lessons, decisions with rationale, observed failed approaches, preferences and labeled
uncertainties. Put `review_id` and supporting `source_refs` **outside `value`**, alongside
`key`, and preserve canonical records with revision-checked updates. Then call
`memory.publish_epoch` with every saved key/revision and a handoff containing objective,
completed work, remaining work, uncertainties and next step. Publication validates
revisions inside the Memory transaction; deterministic manifest identity makes retries
safe even if the separate notebook publication checkpoint fails.

A complete manifest is required for a successful comprehensive-save outcome. Unrelated
puts do not satisfy it. Partial publication remains possible, but the final outcome
must report incomplete coverage and remaining work. A fully reviewed epoch with no new
reusable lessons may publish zero lessons plus its handoff. Complete coverage proves
that all available authorized evidence was delivered for review; it cannot prove the
model extracted every possible insight. Manifests and handoffs are ordinary global
Memory records, usable by another conversation without access to the source notebook.

The existing `/status` panel and run snapshot expose Memory policy, saved-record count,
global revision, and current-run receipt counters. Automatic matches, delivered summaries,
lookup latency, reviewed source counts and publication status are tracked separately. Metadata matches, explicit gets,
writes and unchanged writes are separate facts. Last write/retrieval entries are scoped
to the current run and backed by actual successful receipts. No value is displayed;
matching alone is never reported as retrieval or successful reuse. Counts query the
database only when status is requested, not on each Agent decision.

Sensitive JSON is allowed. Keep secrets out of keys/tags because those are automatically
visible metadata. Put receipts, search/list and diagnostic events never include values. Automatic context
contains only deliberately supplied summaries; those summaries must not contain secrets. **Explicit `memory.get` intentionally exposes the selected value to the
Agent/model**: Memory is not Parameter Store private binding. Existing runtime
redaction/provenance policy applies; Memory adds no implicit redaction. Local sensitive-store creation uses restrictive
file permissions where supported; Memory adds no encryption/keychain layer. Large explicit
get results retain the ordinary bounded observation/exact receipt retrieval behavior.

Example:

1. In Conversation A, the user asks the Agent to use `fdfind`, without asking it to remember.
   An invocation fails; the Agent inspects usage, verifies the corrected command, and
   saves `tools.fdfind.usage` with a scoped recall summary and tags such as `fdfind`,
   `fd`, `fd-find`, `files` and `cli`.
2. In Conversation B, the user asks another `fdfind` task. Exact key/tag matching surfaces
   an opted-in summary or legacy metadata key. The Agent uses the summary or calls
   `memory.get` for detail, checking current behavior when relevant.

Run the configured-model campaign with
`PYTHONPATH=.:src:tests .venv/bin/python scripts/memory_effectiveness_acceptance.py --reliable-memory --stage acceptance --trials 10`.
Initial reuse, mid-task reuse and epoch consolidation followed by a fresh conversation
each require at least nine successful trials out of ten. Behavioral adoption and task
completion are scored separately; tool-call counts alone cannot pass. Staged reports
and baseline-test results are retained in `docs/assets/memory-reliability/`.

This uses no helper model, embedding model, vector search or conversation-handoff copy.
Agent KV remains the conversation-local non-secret notebook. Parameter Store, Working
Context, task contracts, completion, scheduling, compaction and the Agent loop retain
their existing responsibilities.

Source owners: `native/context.py`, `compaction.py`, `projection.py`,
`context_read_policy.py`, `conversation_working_context.py`, `kv/store.py`, `kv/models.py`,
and `skills/memory/`.

## Tool result delivery

**Mission Control → Advanced → Tool result delivery** controls how much captured
output reaches the model. Complete receipts remain available for inspection.

| Choice | Behavior |
| --- | --- |
| Adaptive (recommended) | Keep short results complete; preserve status and source facts, select exact excerpts from large output, and provide scoped recovery. Under pressure, reduce optional older successful views before normal history pruning. |
| Compact (legacy) | Fixed pre-feature previews, including existing tool-specific limits. |
| Full | Complete captured model-entitled data, with an explicit capacity error if protected input cannot fit. |

Changes apply to newly accepted tasks only. Queued, scheduled, paused, resumed and
continued tasks keep their captured choice. Fresh stores start with Adaptive.
An existing saved boolean true migrates to Full, false to Compact; an existing
store without that preference stays Compact. Explicit canonical mode wins over a
stale compatibility boolean. The deprecated boolean is read-only in the settings API.

For `git commit`, the model sees the success, hash and short summary; the complete
receipt stays stored. After thousands of successful test lines, Adaptive selects
failing test names and traceback evidence near the end. Diagnostic selection is a
bounded heuristic, so earlier errors may still require exact retrieval. Large file
reads keep shown whitespace and source identity and distinguish omitted stored-page
content from the producer's next-page cursor. Full captures the same data but may
not fit a smaller model context.

Budgets use conservative local estimates and the served model's output reservation.
Existing preflight remains authoritative. Adaptive is deterministic selection, not
learned summarization, and cannot guarantee zero overflow. No helper model calls,
automatic retrievals, command reruns or new background services are introduced.
