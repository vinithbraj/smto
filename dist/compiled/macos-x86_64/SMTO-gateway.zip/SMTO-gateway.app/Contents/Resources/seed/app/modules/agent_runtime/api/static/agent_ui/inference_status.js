/* One user-only status component for desktop, immersive and mobile Chat.
   Only the click handler submits commands; reads never start or resume work. */
(() => {
  "use strict";
  const base = "/api/agent/inference/v1", destination = "/inference#instances";
  const labels = {stopped: "Stopped", starting: "Starting", stopping: "Stopping",
    ready: "Ready to serve", inferencing: "Inferencing", unknown: "Status unavailable"};
  let button, live, data, timer, staleTimer, pendingRead, readController, commandController;
  let epoch = 0, departed = false, busy = false, featureAbsent = false, dirty = false, transportDown = false;
  const visible = () => !departed && !document.hidden;

  function render() {
    if (!button) return;
    button.hidden = featureAbsent || data?.visible === false;
    const state = transportDown ? "unknown" : labels[data?.state] ? data.state : "unknown";
    button.dataset.state = state;
    button.setAttribute("aria-busy", String(busy));
    const instances = Array.isArray(data?.instances) ? data.instances : [];
    const details = instances.map(row => `${state === "unknown" ? "Last known: " : ""}${row.name} (${row.roles.includes("primary") ? "main agent" : "last loaded instance"}): ${labels[row.state] || labels.unknown}`);
    const count = Number(data?.active_requests) || 0;
    const action = state === "stopped" && data?.can_resume && !busy
      ? "Click to start this instance with its last successful configuration."
      : busy ? "Startup requested. Open Inference to follow it." : "Open Inference.";
    const text = [`Managed inference: ${labels[state]}.`, ...details,
      ...(state !== "unknown" ? [`${count} active request${count === 1 ? "" : "s"}.`] : []), action].join(" ");
    button.title = text;
    button.setAttribute("aria-label", text);
    if (live.textContent !== text) live.textContent = text;
  }

  function unknown() {
    data = {...data, state: "unknown", can_resume: false};
    render();
  }

  async function request(path, {method = "GET", body, signal, key} = {}) {
    const response = await (window.SMTOAuth?.fetch || window.fetch.bind(window))(base + path, {
      method, cache: "no-store", signal: signal || AbortSignal.timeout(3000),
      headers: {...(body ? {"Content-Type": "application/json"} : {}), ...(key ? {"Idempotency-Key": key} : {})},
      ...(body ? {body: JSON.stringify(body)} : {}),
    });
    if (!response.ok) {
      if (path === "/status" && response.status === 404) return {schema_version: 1, visible: false, absent: true, instances: []};
      if (window.SMTOErrors) throw await window.SMTOErrors.fromResponse(response);
      const value = await response.json().catch(() => ({}));
      throw Error(typeof value.detail === "string" ? value.detail : "Inference status unavailable.");
    }
    return response.json();
  }

  function refresh(invalidate = false) {
    if (!visible()) return Promise.resolve(null);
    if (invalidate) { epoch++; dirty = true; }
    if (pendingRead) return pendingRead;
    clearTimeout(timer);
    dirty = false;
    const generation = epoch;
    const controller = new AbortController();
    readController = controller;
    const timeout = setTimeout(() => controller.abort(), 3000);
    pendingRead = (async () => {
      try {
        const snapshot = await request("/status", {signal: controller.signal});
        if (!visible() || generation !== epoch || controller.signal.aborted) return null;
        if (snapshot.schema_version !== 1 || typeof snapshot.visible !== "boolean" || !Array.isArray(snapshot.instances)
          || snapshot.instances.some(row => typeof row.instance_id !== "string" || typeof row.name !== "string"
            || !Array.isArray(row.roles) || !labels[row.state])) throw Error("Invalid status");
        data = snapshot;
        featureAbsent = Boolean(snapshot.absent);
        clearTimeout(staleTimer);
        staleTimer = setTimeout(unknown, 5000);
        render();
        return snapshot;
      } catch (_) {
        if (visible() && generation === epoch) unknown();
        return null;
      } finally {
        clearTimeout(timeout);
        pendingRead = null;
        readController = null;
        if (visible() && !featureAbsent) timer = setTimeout(() => void refresh(), dirty ? 0 : 2000);
      }
    })();
    return pendingRead;
  }

  function report(error) {
    let dialog = document.querySelector(".inference-status-error");
    if (dialog) dialog.remove();
    dialog = document.createElement("dialog");
    dialog.className = "inference-status-error";
    const title = document.createElement("h2"); title.textContent = "Inference startup";
    const message = document.createElement("div");
    if (window.SMTOErrors) window.SMTOErrors.present(message, error);
    else message.textContent = error.message || "Startup could not be confirmed. Open Inference to check its status.";
    const footer = document.createElement("footer");
    const link = document.createElement("a"); link.href = destination; link.textContent = "Open Inference";
    const close = document.createElement("button"); close.type = "button"; close.textContent = "Close";
    close.onclick = () => dialog.close();
    footer.append(link, close); dialog.append(title, message, footer);
    dialog.setAttribute("aria-label", "Inference startup");
    document.body.append(dialog); dialog.showModal();
    dialog.addEventListener("close", () => { dialog.remove(); button.focus(); }, {once: true});
  }

  function delay(signal) {
    return new Promise((resolve, reject) => {
      const abort = () => { clearTimeout(wait); reject(new DOMException("Page left", "AbortError")); };
      const wait = setTimeout(() => { signal.removeEventListener("abort", abort); resolve(); }, 1000);
      signal.addEventListener("abort", abort, {once: true});
      if (signal.aborted) abort();
    });
  }

  async function watch(operation, signal) {
    while (!operation.complete) {
      await delay(signal);
      operation = await request(`/operations/${encodeURIComponent(operation.id)}`, {signal: AbortSignal.any([signal, AbortSignal.timeout(5000)])});
    }
    if (operation.state !== "completed") throw Error(operation.error || `Inference startup ${operation.state}. Open Inference for details.`);
  }

  async function startStopped() {
    if (busy || transportDown) return;
    const wanted = data?.instances?.[0]?.instance_id;
    busy = true; render();
    const controller = new AbortController();
    commandController = controller;
    const signal = () => AbortSignal.any([controller.signal, AbortSignal.timeout(10000)]);
    const key = () => crypto.randomUUID?.() || `inference-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    try {
      // Commands use a fresh selection, never a cached color as authorization.
      let snapshot = await request("/status", {signal: signal()});
      const selected = () => snapshot.instances.find(row => row.instance_id === wanted);
      if (!snapshot.can_resume || !selected()?.can_resume || selected().state !== "stopped") throw Error("The selected model state changed. Open Inference to check it.");
      if (["stopped", "failed"].includes(snapshot.service_phase)) {
        const operation = await request("/service", {method: "POST", body: {action: "start", confirm: true}, signal: signal(), key: key()});
        void refresh(true);
        await watch(operation, controller.signal);
        snapshot = await request("/status", {signal: signal()});
      }
      const row = selected();
      if (!row) throw Error("The selected model state changed. Open Inference to check it.");
      if (row.state === "stopped") {
        controller.signal.throwIfAborted();
        if (!row.can_resume) throw Error(row.reason || "Open Inference to configure this model.");
        const operation = await request(`/instances/${encodeURIComponent(row.instance_id)}/resume-last`, {
          method: "POST", signal: signal(), key: key(),
        });
        void refresh(true);
        await watch(operation, controller.signal);
      }
    } catch (error) {
      if (!controller.signal.aborted) report(error);
    } finally {
      busy = false; commandController = null; render();
      void refresh(true);
    }
  }

  function transport(state) {
    transportDown = state !== "connected";
    if (transportDown) { epoch++; unknown(); }
    else void refresh(true);
  }

  function suspend() {
    departed = true; epoch++;
    clearTimeout(timer); clearTimeout(staleTimer);
    readController?.abort(); commandController?.abort(); unknown();
  }

  function mount() {
    if (button) return;
    const disk = document.getElementById("persist-now");
    const mobile = document.querySelector(".topbar .header-actions");
    if (!disk && !mobile) return;
    button = document.createElement("button");
    button.id = "managed-inference-status"; button.type = "button"; button.hidden = true;
    button.className = disk ? "icon-button" : "icon";
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 2v3m6-3v3M9 19v3m6-3v3M2 9h3m-3 6h3m14-6h3m-3 6h3M9 15V9h6v6z"/></svg>';
    live = document.createElement("span"); live.className = "sr-only"; live.setAttribute("role", "status");
    if (disk) disk.after(button); else mobile.prepend(button);
    button.after(live);
    button.onclick = () => {
      if (busy && button.dataset.state === "stopped") return;
      if (!busy && button.dataset.state === "stopped") {
        if (data?.can_resume) void startStopped();
        else report(Error(data?.instances?.find(row => row.reason)?.reason || "Open Inference to resolve the current transition."));
      } else location.assign(destination);
    };
    window.SMTOInferenceStatus = {refresh: () => refresh(true), transport};
    if (window.SMTOUiUpdates) {
      window.SMTOUiUpdates.subscribe(["inference.status.changed", "settings.changed"], () => refresh(true));
      window.SMTOUiUpdates.observeFreshness(() => transport(window.SMTOUiUpdates.state()));
    }
    window.addEventListener("offline", () => transport("disconnected"));
    window.addEventListener("online", () => { void refresh(true); });
    window.addEventListener("pagehide", suspend);
    window.addEventListener("pageshow", () => { departed = false; void refresh(true); });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) suspend();
      else { departed = false; void refresh(true); }
    });
    void refresh();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount, {once: true});
  else mount();
})();
