---
id: inference
title: Inference management
authority: current
kind: manual
tags: [manual, inference, models, installation, caching]
order: 27
---
# Inference management

The **Inference** area manages vLLM and llama.cpp from the controller. Open
`/inference` from desktop or mobile navigation, or from the surface directory.
It uses your existing sign-in, appearance settings and agent permission policies.
Model engines, builds and installations run in supervised processes and separate
environments; the controller remains available while you manage them.

## Chat toolbar serving indicator

The chip icon beside the SQL-save button controls one instance: the main managed
model, or, when none is assigned, the last successfully loaded local instance.
Mobile shows the same icon in its header. Helper connections do not affect it.
The last loaded instance is remembered across stops and controller restarts,
including instances loaded before this feature was installed. The icon is hidden
only when neither a main managed model nor a previously loaded local instance exists.

| Appearance | Meaning |
| --- | --- |
| Red | The instance is stopped or failed. |
| Flashing gold | The instance is starting or recovering. |
| Green | The instance is ready to serve. |
| Flashing green | The instance is ready and requests are in flight. |
| Steady gold | A model is stopping or management is draining. |
| Gray | Current status is unavailable. |

The tooltip identifies the instance and whether it is the main model or the last
loaded instance. Reduced-motion mode uses static colors with the same
accessible descriptions.

Click red to start that instance using its last successfully served
configuration. Newer saved edits are preserved. If management is stopped, its
existing Start operation runs first. Missing previous configurations and lifecycle
conflicts direct you to Inference. Other states open Inference without starting
anything. Status refreshes never start models or enable GPU monitoring.

## Which installation includes inference?

Linux source installations include inference management automatically:

```bash
./install.sh --launch
```

Run this from the project folder. `--launch` starts the controller after setup.
To install without starting it, use `./install.sh`, then `./startup.sh` when ready.
There is no inference enable flag on `install.sh`. Installation prepares management
dependencies; you still choose your runtime, model and launch settings.

For compiled Linux x86_64 controllers, the build selects the feature:

| Build option | Result |
| --- | --- |
| `--inference=both` | Both controller artifacts; the default for Linux server builds. |
| `--inference=enabled` | `smto-server-inference`, including managed inference and external connections. |
| `--inference=disabled` | `smto-server-external`, using externally configured model endpoints. |

From the repository root, for example:

```bash
./build/build --component server --inference=both
```

These are options for the compiled builder, not the installer or startup command.
The feature is immutable in a compiled artifact. An external-only binary has no
inference management UI, API, tools, workers or state; a runtime setting cannot add
them. Existing external endpoint and controller prompt-caching settings remain
available. Gateway builds are unchanged. Non-Linux controllers and packages from
the older builders use external endpoints.

## Find the controls

Use the magnifying glass or **Ctrl+F / ⌘F** to open the shared search popup.
It filters workflow navigation and highlights matching text on the current page.
**Escape** closes search and restores all tabs. Tab links can be bookmarked, for
example `/inference#models` or `/inference#runtimes`.

| Tab | What you can do |
| --- | --- |
| Overview | Check health, resources, recent operations and agent/helper connections. |
| Hosts & GPUs | Manage local/remote hosts, watch live NVIDIA-SMI output, inspect hardware and reservations, and review placement. |
| Storage & Preferences | Set storage paths, scanning/log retention and credentials; start, restart or shut down inference management. |
| Environments & Builds | Register and inspect existing environments/binaries, install managed vLLM, build llama.cpp and remove runtimes. |
| Models | Configure roots, scan files, inspect metadata/context, and select or download Hugging Face repository revisions and files. |
| Caching | Inspect engine cache configuration/evidence and edit controller prompt-caching settings. |
| Jobs & Logs | Follow installations, builds, downloads and diagnostics; cancel, retry where supported, and export logs. |
| Instances | Find instances across both backends, open details, configure, validate, start and stop. |

The sidebar groups setup before operation, with **Instances** last. Storage &
Preferences keeps its existing `#preferences` bookmark.

**Hosts & GPUs → Live NVIDIA-SMI** shows the selected host’s GPU utilization,
memory, temperature, power and process table. It refreshes every two seconds
while the pane is open and the browser tab is visible. Use **Pause** to inspect
a sample, **Refresh output** for a single update, or the copy icon to copy the
table. The most recent sample replaces the previous one; it is not saved as a
log. Remote hosts need an updated standalone portal with live GPU output support.
Missing NVIDIA-SMI, driver errors and connection failures appear in the pane.
This read-only view does not launch inference or change GPU settings.

**Server resources**, directly below NVIDIA-SMI, has **llama.cpp** and **vLLM**
tabs for the same **Trace host**. Each shows the combined system RAM and CPU used
by that host’s portal-managed servers and workers, including RPC and Ray workers.
CPU is normalized to the entire host: 100% means all logical CPUs are busy.
RAM uses proportional resident memory (PSS) to apportion shared pages; when those
counters are unavailable, an explicitly labelled RSS estimate can count shared
memory more than once. Incomplete readings are marked unavailable rather than zero.

The two graphs retain up to ten minutes of samples in this browser page and
clear on reload. Both backends update every two seconds while the pane is open
and visible. **Pause resource monitoring** and **Refresh resources** operate
independently of NVIDIA-SMI. Use the arrow keys on a graph to inspect samples.
Collection gaps remain visible, and CPU shows **Collecting…** while establishing
its first baseline. This monitor also works on hosts without NVIDIA hardware.
Remote hosts need a portal version supporting the server-resources operation.

**Requests & GPU timeline** adds a correlated view below Server resources.
Choose a **Host**, then **Start monitoring**. The selected GPU's utilization and
fan setting use the percentage axis; temperature uses the °C axis. Shaded
intervals show actual OpenFabric model HTTP attempts, including retries and
cancelled or failed attempts. Dense traffic is grouped visually. Choose an
instance and a 1, 5 (default), or 10 minute window to narrow the view.

Hover over the graph or use its arrow keys to inspect readings at the same time.
Select up to two requests to compare input/output tokens, reported cached tokens,
time to first output, provider prompt-processing time, and request duration.
Unsupported or missing measurements remain **Unknown**. Non-streaming responses
do not expose a first-output timestamp. Backend totals under the chart include
direct clients and overlap the OpenFabric requests; they are not additional calls.
Those counters retain their backend sampling interval and reset on a new launch.

GPU readings are device-wide, including unrelated workloads, and one-second
sampling can miss shorter spikes. Fan setting is the percentage reported by
NVIDIA, not measured RPM; some devices do not report it and some report more
than 100%. Remote readings carry an alignment uncertainty. Cached-token reports
provide evidence of prefix reuse; a quiet GPU or shorter request alone does not
establish a cache hit. Prompt-processing time and time to first output are
different measurements.

Monitoring continues while you navigate to Chat or Settings, with a shared
indicator and **Stop monitoring** button. **Pause chart** freezes inspection
without stopping collection; **Jump to live** catches up. Hidden views stop
rendering and fetching chart records. Changing hosts starts a fresh capture.
**Export JSON/CSV** exports the retained capture, including numerical usage and
timings but no prompt or response content.

Captures are held in controller memory: the most recent ten minutes, at most
600 samples per GPU, 5,000 request records, and 8 MiB per session. Eviction and
collection gaps are explicit. A connected page renews the session every 15
seconds; collection expires after 120 seconds without renewal. Stopped captures
remain exportable for ten minutes. Controller restart ends these sessions.
Older remote portals show an upgrade message while available request observations
continue. Monitoring does not generate model requests or change cache settings.

**Instances** opens a compact list with search and status, backend and host
filters. Open an instance for **Overview**, **Configuration**, **Logs** and
**Diagnostics**. Returning to the list keeps its filters and scroll position.
Duplicate and Delete profile are in the row's More menu.

Configuration groups Basics, GPU & Context, Performance & Cache, and collapsed
Advanced controls. Runtime inspection supplies the option catalog. Advanced
controls preserve explicit options, imported aliases, environment variables, raw
argument ordering and custom templates. JSON edits are validated before saving
or leaving the editor. Save/Discard appears for configuration edits; saving never
restarts a process. Switching detail tabs retains the draft; leaving a dirty
instance asks whether to save, discard, or cancel. Diagnostics contains cache and
cancellation experiments; cancellation route configuration is under Basics.

## First setup

1. In **Hosts & GPUs**, choose the local host or register a remote portal host.
2. In **Storage & Preferences**, choose storage locations, model roots and credentials.
3. In **Environments & Builds**, register and inspect an existing environment or
   llama-server binary, or create a managed runtime.
4. In **Models**,
   scan existing files or select a Hugging Face repository, revision and files to
   download. Select every required GGUF shard and any needed projector. Gated
   repositories require your authorized token.
5. In **Instances**, choose **New instance**. The four steps cover backend/host,
   runtime/model, GPU/context, and review/validation. Networking and advanced
   controls are optional disclosures. Links to missing prerequisites retain the
   draft during this session; return to Instances and choose **Resume setup**.
6. Choose **Create profile**, or validate and explicitly choose **Create & start**.
   A saved profile can be started later from its list row or Overview. Follow
   loading in Logs and confirm readiness.
7. In **Overview → Agent & helper connections**, choose the ready instance and
   served model, then **Use this connection**. You do not need to copy its URL.

The controller resolves the verified endpoint and launch generation before model
dispatch. Helper routing retains its existing policy, compatibility checks,
credentials and generation settings. Selecting a helper does not redirect every
internal model call; explicit helper routing applies to capability selection.
To use an external provider, choose the external connection and configure it through
the shared [Model Configuration](25-model-configuration.md) editor.

## Change a running instance

Saved configuration, the running launch snapshot and observed evidence describe
different things. Editing a profile does not change its process.

1. Edit the profile and choose **Save profile**.
2. Choose **Validate**, then **Review changes** to inspect the saved-versus-running
   difference, active requests and affected tasks.
3. Choose **Apply / Restart** and confirm the change.
4. Follow the operation in **Overview** and the instance logs.

The controller blocks new requests to the affected endpoint, drains existing
requests and checkpoints affected tasks before applying the launch. It verifies
readiness and model compatibility, refreshes bindings and invalidates stale
capability/cache/continuation evidence, then resumes work paused by that operation.
A drain timeout leaves the operation blocked and the running instance intact.

If the candidate fails, the controller attempts restoration of the previous
successful launch snapshot. The failed saved candidate and logs remain available
for correction. Failed restoration keeps affected work paused while management
remains available. **Stop** and task cancellation take precedence over automatic
resume. Stop also works with invalid unsaved form edits.

Concurrent manual and agent edits use revisions; a conflict requires refreshing
the saved state before applying another change. Duplicate lifecycle requests can
use the same idempotency key without starting another operation.

## Read instance and job output

Logs opens with up to 200 recent records and follows live output. Scroll upward
or choose **Pause tail** to read without automatic scrolling; **Jump to latest**
resumes following. **Load older** explicitly retrieves retained history, including
previous participating hosts. Search, copy and export operate on loaded output.
Export preserves structured JSONL records, including host/worker labels.

The viewer buffers at most 5,000 records or 4 MiB and mounts only visible rows.
Large messages are shortened for display and marked; full retained local logs
remain available through the download link. Remote hosts retain their own full
logs. Leaving the view or hiding the browser tab stops its stream/polling; return
resumes from the last cursor and reports any retention gap.

Archive reads scan backwards, at most 2 MiB per page. A sparse instance can have
no matches in the recent window while older history remains available. Host
errors appear beside the viewer and do not delay other hosts. Remote portals
need bounded-log pagination support; older versions display an upgrade message.
Job output uses the same bounded reader and viewer.

## Build a runtime

In **Environments & Builds**, select the host and managed llama.cpp build workflow.
Choose the source release or commit, installed/custom/managed CUDA toolkit, GPU
architecture and build preset. Run preflight before starting the build.

**Jobs & Logs** preserves stage progress and output through download, configuration,
compilation and verification. A successful build registers the runtime; select it
in a profile and validate before launch. Cancellation and supported retries use
the existing job controls. Runtime removal provides a preview before removal.

## Investigate caching

In **Caching**, choose an instance to compare requested engine settings, its
running snapshot, finite RAM reservations and observed cache evidence.
Unknown or unsupported evidence is not a cache hit. Controls shown in multiple
views edit the same backend values; save and explicitly restart to apply them.

The controller prompt-caching editor is shared with **Settings → Prompt caching**.
Its switches default off and affect request construction and controller reuse.
Turning Prompt caching on here also enables the advertised `--cache-prompt`
(llama.cpp) or `--enable-prefix-caching` (vLLM) option in the saved profiles
connected to the agent or helpers. Connecting an instance while caching is on
prepares its flag too. Unsupported or offline runtimes are reported for correction.
Other profiles, external endpoints and cache RAM budgets stay unchanged.
Running instances require **Apply / Restart**; the toggle does not restart them.
Turning it off preserves backend options, which remain editable in each instance.
The Settings entry point shares the controller policy and keeps engine setup manual.

Reading status, opening a page or refreshing evidence does not submit inference.
Explicit diagnostics and comparisons can submit bounded test requests; use their
progress and cancellation controls. This integration does not add native cache
eviction, slot snapshots, or cache save/restore operations.

## State, shutdown and remote hosts

Fresh management state lives in `inference/` beside the controller's current-run
database, normally beneath `AOR_AGENT_STATE_DIR` (default `artifacts` for source
launches). The inference database, private secrets, jobs and rotating logs remain
the authoritative stores. Model roots, permanent installations and build-work
locations are configurable separately.

An existing standalone portal is not discovered, imported, adopted or removed.
A fresh controller state directory starts without its profiles or bindings.
There are no automatic model downloads or background tuning. The standalone
portal remains available for independent and remote hosts; its worker protocol
continues to handle leases, reservations, remote builds/downloads, Ray and RPC.

**Preferences → Restart inference** restarts management and restores requested
running profiles while keeping the controller UI available. **Shutdown inference**
stops its workers and jobs; use **Start inference** to start management again.
An intentional instance shutdown stays stopped. Controller shutdown also cleans up
owned workers and jobs; cleanup failures retain ownership for retry. Controller
startup recovers accepted operations and requested running profiles.

## Agent and API access

The authenticated API is `/api/agent/inference/v1`. The `inference.*` tools use
the same validated operations as the UI and follow existing capability and
permission rules. Long operations return identifiers for status, result, errors,
and cancellation or retry where supported. The controller persists an accepted
agent tool result before interrupting the model serving that task.

The [parity ledger](../../../docs/inference-integration-parity.md) maps every
management contract to UI and tool access and records validation limits.
Local llama.cpp hardware checks are recorded there; vLLM hardware was skipped,
and remote Ray/RPC hardware parity has not been established.

## Further references

- [Compiled build and installation guide](../../../build/README.md)
- [Helper routing policy and compatibility](../../../docs/helper-routing.md)
- [Controller prompt-caching behavior and limits](../../../docs/prompt-caching.md)
- [Shared runtime build reference](../../inference_portal/README.md#managed-llamacpp-builds);
  its navigation labels refer to the standalone portal.
