import { $, button } from "../api.js?v=20261018-loading";
import { openSheet, mountControls } from "../overlays.js?v=20261018-loading";

export function open(hooks) {
  const body = openSheet("Conversation options", {returnFocus: $("#options")});
  const save = button("Save draft to workflow", () => window.SMTOWorkflows.saveDraft(), "choice");
  save.disabled = !$("#message").value.trim();
  body.append(save);
  mountControls(body, $("#status-strip"), $("#conversation-view-controls"), $("#activity-details-toggle"));
  body.append(button("Appearance", async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
    const {openAppearance} = await import("./agent_options.js?v=20261018-loading");
    if (body.isConnected) openAppearance(() => open(hooks));

 } finally { busyFeedback?.finish(); }
}, "choice"));
  body.append(button("Parameter editor", () => location.assign("/parameter-editor"), "choice"));
}
