/* Draft behavior choice. Presets and durable policy snapshots are owned by the server. */
(() => {
  "use strict";
  const labels = {low: "Low", medium: "Medium", high: "High", extra_high: "Extra High", ultra: "Ultra"};
  const levels = Object.keys(labels);
  const valid = value => Object.prototype.hasOwnProperty.call(labels, value);
  function create({select, apiJson, changed = () => {}}) {
    const root = select.closest(".behavior-control"), help = root.querySelector("#behavior-help");
    let choice = "medium", saved = false, locked = null;
    const bars = value => levels.map((_, i) => `<i style="--step:${i}" data-filled="${i <= levels.indexOf(value)}"></i>`).join("");

    function render(current = locked) {
      locked = current;
      const value = valid(locked) ? locked : choice;
      select.disabled = locked !== null;
      select.dataset.effort = value;
      select.value = value;
      root.querySelector(".behavior-steps").innerHTML = bars(value);
      select.title = `Behavior effort: ${labels[value]}${locked !== null ? " — locked for current task" : ""}. ${help.textContent}`;
    }
    function restore(value) {
      if (valid(value)) choice = value;
      render();
    }
    select.addEventListener("change", () => {
      const value = select.value;
      if (locked !== null || !valid(value)) { render(); return; }
      choice = value; saved = true;
      render(); changed();
    });
    render();
    return {value: () => choice, restore, render, async loadDefault() {
      const controls = await apiJson("/api/agent/runtime-controls");
      const value = (controls.runtime_controls || controls).agent_behavior_effort;
      if (!saved) { choice = valid(value) ? value : "medium"; render(); }
    }};
  }
  window.SMTOBehaviorEffort = {create, labels, valid};
})();
