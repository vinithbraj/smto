(() => {
  "use strict";
  const base = "/api/agent/settings/data";
  const labels = {
    agent_chats: "Conversations and messages", agent_current_run: "Runs and artifacts",
    agent_parameters: "Parameter Store", agent_ui_settings: "Settings and preferences",
    agent_events: "Schedules and notifications", agent_gateways: "Gateways",
    agent_monitors: "Monitors", agent_prompts: "Prompt templates", agent_recipes: "Recipes",
    agent_tasks: "Tasks", agent_kv: "Conversation notes", agent_memory: "Memory",
    verified_execution_cache: "Execution cache", agent_trace: "Trace history",
    agent_model_output: "Model output history",
  };

  function element(tag, text, parent) {
    const node = document.createElement(tag);
    if (text) node.textContent = text;
    if (parent) parent.append(node);
    return node;
  }

  async function request(path, options = {}) {
    const response = await (window.SMTOAuth?.fetch || window.fetch)(base + path, {cache: "no-store", ...options});
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(typeof error.detail === "string" ? error.detail : "Backup request failed. Please retry.");
    }
    return response;
  }

  let mounted = null;
  function mount(host, {beforeExport}) {
    if (mounted) {
      mounted.beforeExport = beforeExport;
      host.append(mounted.panel);
      void mounted.refresh?.();
      return;
    }
    const panel = element("div", "", host);
    mounted = {panel, beforeExport};
    panel.className = "mission-setting-row data-transfer-panel";
    element("p", "Move your saved settings, Parameter Store, conversations, tasks, schedules, "
      + "memory, history, uploaded documents and generated artifacts between app versions.", panel);
    element("p", "Backups include credentials in plain text. Store the JSON securely. "
      + "External workspace and Gateway files, environment files, browser-only state and "
      + "device identity keys are excluded.", panel);
    const actions = element("div", "", panel);
    actions.className = "data-transfer-actions";
    const download = element("button", "Export JSON", actions);
    download.type = "button";
    download.dataset.componentAction = "export";
    const label = element("label", "Import JSON (up to 512 MiB)", actions);
    const file = element("input", "", label);
    file.type = "file"; file.accept = ".json,application/json";
    file.dataset.componentAction = "import";
    const preview = element("div", "", panel);
    preview.className = "data-transfer-preview";
    preview.hidden = true;
    const status = element("p", "", panel);
    status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
    const exportView = window.SMTOExportProgress.create({host: panel, announcement: status});
    actions.after(panel.querySelector(".data-export-status"));
    const cancel = element("button", "Cancel pending import", panel);
    cancel.type = "button"; cancel.hidden = true;
    let token = null, pending = false, busy = false;

    function update() {
      download.disabled = busy;
      file.disabled = busy || pending;
      cancel.disabled = busy;
      const confirm = preview.querySelector("button");
      if (confirm) confirm.disabled = busy || !token || !preview.querySelector('input[type="checkbox"]')?.checked;
    }

    async function perform(work, quiet = false, progress = false) {
      if (busy) return;
      busy = true; update();
      const feedback = quiet ? null : window.SMTOBusy?.begin({host: actions, label: progress ? "" : "Processing backup…", announce: !progress});
      try { await work(); }
      catch (error) { status.textContent = error.message || "Backup request failed."; }
      finally { feedback?.finish(); busy = false; update(); }
    }

    function showPending() {
      exportView.hide();
      pending = true; preview.hidden = true; cancel.hidden = false;
      status.textContent = "Import staged. Restart the app to replace its saved data. "
        + "A recovery copy will be kept on this computer. Changes made before restart "
        + "will be in the recovery copy, not the imported data.";
      update();
    }

    download.addEventListener("click", () => perform(async () => {
      await exportView.start(() => mounted.beforeExport());
    }, false, true));

    file.addEventListener("change", () => perform(async () => {
      exportView.hide();
      token = null; preview.hidden = true; preview.replaceChildren();
      const selected = file.files[0];
      if (!selected) { status.textContent = ""; return; }
      if (selected.size > 512 * 1024 * 1024) throw new Error("Backup exceeds the 512 MiB limit.");
      status.textContent = "Validating backup and checking compatibility…";
      const response = await request("/preview", {
        method: "POST", headers: {"Content-Type": "application/json"}, body: selected,
      });
      const data = await response.json();
      token = data.token;
      element("h3", "Review import", preview);
      element("p", `${selected.name} · App ${data.app_version} · ${data.created_at}`, preview);
      const list = element("dl", "", preview);
      for (const [name, count] of Object.entries(data.stores)) {
        element("dt", labels[name] || name, list); element("dd", String(count), list);
      }
      element("p", `${data.records} records and ${data.files} managed files validated.`, preview);
      element("p", "This replaces all saved application data after restart. Existing data is kept "
        + "in a recovery copy. Restored schedules and unfinished tasks will be paused or interrupted. "
        + "Review connections before resuming work.", preview);
      const acknowledgement = element("label", "", preview);
      acknowledgement.className = "data-transfer-confirmation";
      const checkbox = element("input", "", acknowledgement); checkbox.type = "checkbox";
      element("span", "I understand that importing replaces this app’s saved data.", acknowledgement);
      const apply = element("button", "Import on next restart", preview);
      apply.type = "button"; apply.disabled = true;
      checkbox.addEventListener("change", () => { apply.disabled = !checkbox.checked || busy || !token; });
      apply.addEventListener("click", () => perform(async () => {
        exportView.hide();
        apply.disabled = true;
        try {
          await request("/import", {method: "POST", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({token, replace_existing: true})});
          token = null; showPending();
        } catch (error) { apply.disabled = !checkbox.checked; throw error; }
      }));
      preview.hidden = false;
      status.textContent = "Backup validated. Review the preview before confirming replacement.";
    }));

    cancel.addEventListener("click", () => perform(async () => {
      exportView.hide();
      await request("/import", {method: "DELETE"});
      pending = false; token = null; file.value = ""; cancel.hidden = true;
      status.textContent = "Pending import cancelled. Existing data is unchanged.";
    }));
    mounted.refresh = () => perform(async () => {
      const data = await (await request("/status")).json();
      if (data.pending) showPending();
      else if (data.last_import) {
        status.textContent = data.last_import.message;
        if (data.last_import.recovery_directory) {
          element("p", `Recovery copy: ${data.last_import.recovery_directory}`, panel);
        }
      }
    }, true);
    void mounted.refresh();
  }
  window.SMTODataTransfer = {mount};
})();
