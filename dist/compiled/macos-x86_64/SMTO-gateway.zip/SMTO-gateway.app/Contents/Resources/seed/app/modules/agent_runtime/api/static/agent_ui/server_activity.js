/* Passive host telemetry. No run, target, queue, or shared update-stream state. */
(() => {
  "use strict";
  const root = document.getElementById("server-activity");
  if (!root) return;
  const interval = 1000, staleAfter = 5000;
  const meters = Object.fromEntries(["cpu", "gpu"].map(kind => {
    const element = root.querySelector(`[data-activity="${kind}"]`);
    return [kind, {element, value: element.querySelector(".activity-value"),
      path: element.querySelector("path")}];
  }));
  let running = false, timer = null, staleTimer = null, controller = null;
  let inFlight = null, refreshPending = false;
  const finite = value => typeof value === "number" && Number.isFinite(value);
  const percent = value => finite(value) ? Math.max(0, Math.min(100, value)) : null;

  function sparkline(history, kind, end, seconds, sampleInterval) {
    return window.SMTORollingHistory.path(
      history.slice(-90).map(point => ({t: point?.t, value: percent(point?.[kind])})),
      {end, windowMs: seconds * 1000, gapMs: sampleInterval * 2200});
  }

  function render(snapshot, stale = false) {
    const current = snapshot?.current;
    const fresh = current && finite(current.timestamp_ms) && finite(snapshot.generated_at_ms)
      && snapshot.generated_at_ms - current.timestamp_ms < staleAfter;
    const history = Array.isArray(snapshot?.history) ? snapshot.history : [];
    const seconds = finite(snapshot?.history_seconds) ? Math.max(1, Math.min(90, snapshot.history_seconds)) : 60;
    const sampleInterval = finite(snapshot?.sample_interval_seconds) ? Math.max(1, snapshot.sample_interval_seconds) : 1;
    for (const [kind, meter] of Object.entries(meters)) {
      const relevant = kind !== "gpu" || (snapshot?.llm_endpoint?.scope === "local"
        && snapshot.gpu?.available === true && snapshot.gpu.device_count > 0);
      const value = !stale && fresh && relevant
        ? percent(current[`${kind}_percent`]) : null;
      const available = value !== null;
      if (kind === "gpu") meter.element.hidden = !available;
      meter.element.dataset.available = String(available);
      window.SMTONumberOdometer.render(meter.value, available ? `${Math.round(value)}%` : "—");
      meter.element.style.setProperty("--activity-percent", `${value ?? 0}%`);
      if (available) {
        meter.element.setAttribute("aria-valuenow", String(value));
        meter.element.setAttribute("aria-valuetext", `${Math.round(value)} percent`);
      } else {
        meter.element.removeAttribute("aria-valuenow");
        meter.element.setAttribute("aria-valuetext", stale || (current && !fresh)
          ? "Server telemetry stale" : kind === "gpu"
            ? "NVIDIA GPU telemetry unavailable" : "CPU telemetry unavailable");
      }
      meter.element.title = available
        ? `Server ${kind.toUpperCase()} utilization · last ${seconds} seconds${kind === "gpu" ? " · maximum across NVIDIA GPUs · local LLM endpoint" : " · host-wide aggregate"}`
        : meter.element.getAttribute("aria-valuetext");
      meter.path.setAttribute("d", fresh && !stale
        ? sparkline(history, kind, snapshot.generated_at_ms, seconds, sampleInterval) : "");
    }
  }

  function schedule(delay = interval) {
    clearTimeout(timer);
    if (running && !document.hidden) timer = setTimeout(refresh, delay);
  }

  function refresh() {
    if (!running || document.hidden) return Promise.resolve();
    if (inFlight) return inFlight;
    clearTimeout(timer);
    const started = performance.now();
    const request = new AbortController();
    controller = request;
    const timeout = setTimeout(() => request.abort(), 3000);
    inFlight = (async () => {
      try {
        const response = await window.SMTOErrors.fetch("/api/agent/server-activity", {
          signal: request.signal, cache: "no-store",
        });
        if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
        const snapshot = await window.SMTOErrors.readJson(response);
        if (!running || request.signal.aborted) return;
        clearTimeout(staleTimer);
        render(snapshot);
        const age = finite(snapshot.generated_at_ms) && finite(snapshot.current?.timestamp_ms)
          ? Math.max(0, snapshot.generated_at_ms - snapshot.current.timestamp_ms) : staleAfter;
        staleTimer = setTimeout(() => render(null, true), Math.max(0, staleAfter - age));
      } catch (_error) {
        if (running && !document.hidden) render(null);
      } finally {
        clearTimeout(timeout);
        controller = null;
        inFlight = null;
        const delay = refreshPending ? 0 : Math.max(0, interval - (performance.now() - started));
        refreshPending = false;
        schedule(delay);
      }
    })();
    return inFlight;
  }

  function start() {
    if (running || document.documentElement.dataset.footerEnabled === "false") return;
    running = true;
    if (inFlight) refreshPending = true;
    else void refresh();
  }

  function stop() {
    running = false;
    clearTimeout(timer);
    clearTimeout(staleTimer);
    controller?.abort();
    render(null);
  }

  document.addEventListener("visibilitychange", () => {
    if (!running) return;
    clearTimeout(timer);
    if (document.hidden) controller?.abort();
    else if (inFlight) refreshPending = true;
    else void refresh();
  });
  window.addEventListener("pagehide", stop);
  window.addEventListener("pageshow", start);
  window.addEventListener("smto:appearance", () => {
    if (document.documentElement.dataset.footerEnabled === "false") stop();
    else start();
  });
  window.SMTOServerActivity = {start, stop, refresh};
  start();
})();
