/* Shared lifetime token totals and average request rates for all task states. */
(() => {
  "use strict";
  const valid = value => Number.isSafeInteger(value) && value >= 0;
  const views = new WeakMap();
  function render(root, metrics = {}, usage = metrics.usage || {}) {
    const totals = metrics.token_usage;
    const throughput = totals?.token_throughput || metrics.token_throughput;
    root.className = "response-token-usage";
    root.title = "Context remaining uses the latest recorded model request, including reserved output space. Token counts are running totals across this task's model calls, including stopped attempts. Generated tokens can include reasoning and tool calls. Average rates use tokens divided by model request time for finished calls with matching counts and timings; tool and idle time are excluded. Request time includes transport and prefill, so these are not GPU prefill/decode speeds. ≈ means estimated; — means unavailable.";
    let view = views.get(root);
    if (!view || view.input.stat.parentNode !== root) {
      root.replaceChildren(); view = {};
      view.context = document.createElement("button");
      view.context.type = "button";
      view.context.className = "response-token-count response-context-remaining";
      const pie = document.createElement("span");
      pie.className = "response-context-pie"; pie.setAttribute("aria-hidden", "true");
      view.contextValue = document.createElement("span");
      view.contextValue.className = "response-context-value";
      view.context.append(pie, "Context remaining - ", view.contextValue);
      root.append(view.context);
      view.visualization = window.SMTOContextVisualization.create(view.context, root);
      for (const direction of ["input", "output"]) {
        if (root.childNodes.length) {
          const separator = document.createElement("span");
          separator.className = "response-token-separator";
          separator.textContent = " | ";
          root.append(separator);
        }
        const stat = document.createElement("span"), average = document.createElement("span");
        stat.className = "response-token-count";
        average.className = "response-token-count response-token-rate";
        stat.dataset.direction = average.dataset.direction = direction;
        root.append(stat, " ", average); view[direction] = {stat, average};
      }
      views.set(root, view);
    }
    // Sparse progress updates must not blank the last observation for this turn.
    if (window.SMTOContextMeter.remaining(metrics.llm_context_usage) != null) view.contextUsage = metrics.llm_context_usage;
    const remaining = window.SMTOContextMeter.remaining(view.contextUsage);
    const value = remaining == null ? "—" : remaining.toFixed(0) + "%";
    if (view.contextValue.textContent !== value) view.contextValue.textContent = value;
    const used = remaining == null ? 0 : 100 - remaining;
    view.context.style.setProperty("--context-used-percent", `${used.toFixed(1)}%`);
    view.context.dataset.level = remaining == null ? "unknown" : used >= 90 ? "danger" : used >= 75 ? "warning" : "ok";
    view.context.title = "Visualize context window partition (filled pie = used or reserved)";
    view.visualization.update(view.contextUsage);
    let available = remaining != null;
    for (const [direction, providerKey, estimateKey, label] of [
      ["input", "prompt_tokens", "input_tokens_estimate", "tokens read"],
      ["output", "completion_tokens", "output_tokens_estimate", "tokens generated"],
    ]) {
      let value = "—";
      if (totals && valid(totals[direction + "_tokens"])) {
        value = `${totals[direction + "_estimated"] ? "≈" : ""}${totals[direction + "_tokens"].toLocaleString()}`;
      } else if (!totals && valid(usage[providerKey])) value = usage[providerKey].toLocaleString();
      else if (!totals && metrics.source !== "trace_timestamps"
          && !(metrics.source === "native_provider_usage" && metrics.estimated !== false)
          && valid(metrics[estimateKey])) {
        value = `${metrics.estimated === false ? "" : "≈"}${metrics[estimateKey].toLocaleString()}`;
      }
      available ||= value !== "—";
      const {stat, average} = view[direction];
      window.SMTONumberOdometer.render(stat, `${value} ${label}`);
      const sample = throughput?.[direction];
      const measured = valid(sample?.tokens) && valid(sample?.calls) && sample.calls > 0
        && typeof sample.seconds === "number" && Number.isFinite(sample.seconds) && sample.seconds > 0
        && typeof sample.tokens_per_second === "number" && Number.isFinite(sample.tokens_per_second)
        && sample.tokens_per_second >= 0;
      const rate = measured ? `${sample.estimated ? "≈" : ""}${sample.tokens_per_second.toLocaleString(undefined,
        {minimumFractionDigits: 1, maximumFractionDigits: 1})}` : "—";
      window.SMTONumberOdometer.render(average, `(avg ${rate} tokens/s)`);
    }
    return available;
  }
  function latest(previous, next) {
    if (!next || (previous?.revision || 0) > (next.revision || 0)) return previous;
    return next;
  }
  window.SMTOResponseTokens = {render, latest};
})();
