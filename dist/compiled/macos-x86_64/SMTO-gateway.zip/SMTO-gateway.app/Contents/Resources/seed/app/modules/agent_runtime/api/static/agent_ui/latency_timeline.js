/** @file src/agent_runtime/api/static/agent_ui/latency_timeline.js
 * @brief Render bounded model-call evidence in existing activity disclosures.
 * @details
 * Responsibilities: Show local intervals, overlap, evidence quality and incomplete work.
 * Boundaries: No execution controls, polling, backend estimates or task authorization.
 * Lifecycle: Activity pages fetch authorized details, then mount these disclosures.
 * State: DOM only; the trace store owns retained records and per-process clock epochs.
 * Security: Text uses textContent; numeric bar widths are validated before rendering.
 * Collaborators: activity_pages loads details; observability/latency supplies version 1 records.
 * Public surface: timelineRows projects spans; mountLatencyTimeline and mountCallTracks
 * render single-call evidence and overlapping calls without summing inclusive durations.
 * @see src/agent_runtime/api/static/agent_ui/activity_pages.js
 * @see src/agent_runtime/observability/latency.py
 */
/** Create text-only content without parsing provider-controlled HTML. */
const element = (tag, text) => {
  const node = document.createElement(tag); node.textContent = text; return node;
};
/** Format validated local milliseconds; null and malformed values stay unknown. */
const milliseconds = value => Number.isFinite(value) && value >= 0 ? `${value.toFixed(1)} ms` : "Unknown";

/** Project version 1 spans with explicit unknown values for display and tests. */
export function timelineRows(record) {
  if (record?.version !== 1) return [];
  const spans = Array.isArray(record.spans) ? record.spans : [];
  return spans.slice(0, 96).filter(s => s && typeof s === "object").map(s => ({
    phase: String(s.name || "Unknown phase").replaceAll("_", " "),
    start: milliseconds(s.start_ms), duration: milliseconds(s.duration_ms),
    exclusive: milliseconds(s.exclusive_ms), source: String(s.source || "unknown"),
    status: String(s.status || "incomplete"),
  }));
}

/** Mount one collapsible timeline; unavailable durations remain visibly unknown. */
export function mountLatencyTimeline(host, record) {
  if (record?.version !== 1) return;
  const root = element("details", ""); root.className = "latency-timeline";
  root.append(element("summary", `Model call timeline · ${record.disposition || "incomplete"}`));
  root.append(element("p", "Inclusive spans overlap. Exclusive time removes measured children. Unknown values are not zero."));
  const table = element("table", ""); table.className = "activity-events-table";
  table.setAttribute("aria-label", "Model call latency timeline");
  const head = element("tr", "");
  for (const title of ["Phase", "Local offset", "Inclusive", "Exclusive", "Evidence", "Status"]) {
    const cell = element("th", title); cell.scope = "col"; head.append(cell);
  }
  table.append(head);
  for (const row of timelineRows(record)) {
    const tr = element("tr", "");
    for (const value of Object.values(row)) tr.append(element("td", value));
    table.append(tr);
  }
  const scroll = element("div", ""); scroll.className = "activity-events-scroll";
  scroll.append(table); root.append(scroll);
  const milestones = element("dl", "");
  for (const [name, offset] of Object.entries(record.milestones || {}).slice(0, 24)) {
    milestones.append(element("dt", name.replaceAll("_", " ")), element("dd", milliseconds(offset)));
  }
  root.append(milestones);
  for (const [name, fact] of Object.entries(record.context || {})) {
    if (["provider_queue", "provider_prefill"].includes(name))
      root.append(element("p", `${name.replaceAll("_", " ")}: ${milliseconds(fact?.value)} (${fact?.source || "unknown"})`));
  }
  root.append(element("p", `Cache miss reason: ${record.context?.cache_miss_reason || "unknown"}. Backend generation: ${record.backend_generation || "unknown"}.`));
  const cache = record.context?.prompt_cache;
  if (cache) mountPromptCacheObservation(root, cache);
  host.append(root);
}

export function mountPromptCacheObservation(host, cache) {
  if (cache?.version !== 1) return;
  const root = element("section", ""); root.setAttribute("aria-label", "Prompt caching measurements");
  root.append(element("p", `Prompt caching · ${cache.phase} · revision ${cache.policy_revision} · ${cache.verdict}.`));
  root.append(element("p", `Input tokens: ${cache.input_tokens ?? "Unknown"}; cached: ${cache.cached_tokens ?? "Unknown"}; provider reuse: ${cache.reuse_percent == null ? "Unknown" : cache.reuse_percent.toFixed(1) + "%"}.`));
  root.append(element("p", `Construction: ${milliseconds(cache.construction_ms)}; scheduler wait: ${milliseconds(cache.scheduler_wait_ms)}; provider input processing: ${milliseconds(cache.provider_input_ms)}; first actionable output: ${milliseconds(cache.first_actionable_ms)}; total request: ${milliseconds(cache.total_ms)}.`));
  root.append(element("p", `Local fragment hits: ${cache.fragment_hits}; misses: ${cache.fragment_misses}. ${cache.reason}.`));
  root.append(element("p", "A cache hit alone does not establish improvement. These observations describe one model request."));
  const details = element("details", "");
  details.append(element("summary", "Effective configuration and checks"), element("pre", JSON.stringify({
    sample_count: cache.sample_count, configuration: cache.configuration, layouts: cache.layouts,
    correctness_checks: cache.correctness_checks, scope: cache.scope, sources: cache.sources,
    provider_evidence_scope: cache.provider_evidence_scope,
  }, null, 2)));
  root.append(details);
  host.append(root);
}

/** Replace a bounded overlap view; different process clocks retain separate tracks. */
export function mountCallTracks(host, summary) {
  host.replaceChildren();
  if (summary?.version !== 1 || !summary.tracks?.length) return;
  const disclosure = element("details", "");
  disclosure.append(element("summary", "Model call overlap"));
  disclosure.append(element("p", "Each row is one call. Overlapping intervals count once in covered elapsed time. Separate process clocks are not added."));
  for (const track of summary.tracks.slice(0, 64)) {
    const calls = (track.calls || []).slice(0, 64);
    const valid = calls.filter(c => Number.isFinite(c.start_ms) && Number.isFinite(c.end_ms) && c.end_ms >= c.start_ms);
    const first = Math.min(...valid.map(c => c.start_ms)), last = Math.max(...valid.map(c => c.end_ms));
    disclosure.append(element("p", `Covered elapsed: ${milliseconds(track.covered_ms)}`));
    for (const call of calls) {
      const row = element("div", `${call.phase || "Model"} · ${call.disposition || "incomplete"}`);
      row.setAttribute("data-call-status", call.disposition || "incomplete");
      if (valid.includes(call)) {
        const bar = element("div", "");
        const scale = Math.max(1, last - first);
        bar.style.marginLeft = `${100 * (call.start_ms - first) / scale}%`;
        bar.style.width = `${100 * (call.end_ms - call.start_ms) / scale}%`;
        bar.style.height = "0.6rem";
        bar.style.background = call.disposition === "discarded" ? "#777" : "#377ea8";
        bar.title = `${milliseconds(call.start_ms - first)} – ${milliseconds(call.end_ms - first)}`;
        row.append(bar);
      } else row.append(element("span", " · Incomplete interval"));
      disclosure.append(row);
    }
  }
  host.append(disclosure);
}
