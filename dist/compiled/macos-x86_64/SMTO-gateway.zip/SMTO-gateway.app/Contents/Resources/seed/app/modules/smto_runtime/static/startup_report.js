/* Startup disclosure tree. Polls update measurements, never the user's open branches. */
(() => {
  'use strict';
  const number = value => Number.isFinite(value) ? value.toLocaleString(undefined, {maximumFractionDigits: 1}) : 'Unknown';
  const seconds = value => `${number(value)} s`;
  const duration = (value, complete = false) => {
    if (!Number.isFinite(value)) return '—';
    if (value === 0 && complete) return '<1 ms';
    if (value > 0 && value < 1) return `${Math.round(value * 1000)} ms`;
    if (value >= 60) return `${Math.floor(value / 60)}m ${number(value % 60)}s`;
    return seconds(value);
  };
  const bytes = value => {
    if (!Number.isFinite(value)) return 'Unknown';
    const unit = value >= 1024 ** 3 ? 3 : value >= 1024 ** 2 ? 2 : value >= 1024 ? 1 : 0;
    return `${number(value / 1024 ** unit)} ${['B', 'KiB', 'MiB', 'GiB'][unit]}`;
  };
  const names = {
    'loading-runtime-modules': 'Runtime modules', 'loading-configuration': 'Configuration',
    'acquiring-runtime-ownership': 'Runtime ownership', 'restoring-runtime-state': 'Saved data',
    'initializing-execution-services': 'Execution services', 'preparing-api-and-user-interface': 'API & interface',
    'reconciling-runtime-work': 'Work recovery', 'sealing-restored-state': 'Memory finalization',
    'starting-background-services': 'Background services',
  };
  const units = {bytes: 'Work processed', records: 'Records', entities: 'Memory entities', pages: 'Database pages',
    files: 'Files', repositories: 'Repositories', operations: 'Operations', indexes: 'Indexes', objects: 'Objects', intents: 'Deletion intents'};
  const sources = {sqlite: 'SQLite checkpoint', json: 'JSON recovery', legacy_sqlite: 'Existing SQLite stores'};
  function node(tag, text, className) {
    const item = document.createElement(tag);
    if (text) item.textContent = text;
    if (className) item.className = className;
    return item;
  }
  function set(item, value) { if (item.textContent !== value) item.textContent = value; }
  function setNumber(item, value) {
    if (window.SMTONumberOdometer) window.SMTONumberOdometer.render(item, value);
    else set(item, value);
  }
  function icon(kind) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 20 20'); svg.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS(svg.namespaceURI, 'path');
    path.setAttribute('d', kind === 'chevron' ? 'm8 5 5 5-5 5' : 'm5 10 3 3 7-7');
    svg.append(path); return svg;
  }
  function estimate(value) {
    if (!value || !Array.isArray(value.range_seconds)) return 'Estimating remaining time';
    const [low, high] = value.range_seconds;
    return `About ${duration(Math.max(1, low))} – ${duration(Math.max(1, high))} remaining`;
  }
  function metric(parent, label, className = '') {
    const group = node('div', '', className), value = node('dd');
    group.append(node('dt', label), value); parent.append(group);
    return value;
  }
  function mount(root) {
    const summary = node('dl', '', 'startup-summary');
    const eta = metric(summary, 'Estimated remaining', 'startup-estimate');
    const saved = metric(summary, 'Saved data');
    const repositories = metric(summary, 'Repositories');
    const panel = node('section', '', 'startup-breakdown');
    panel.setAttribute('aria-label', 'Startup breakdown');
    const header = node('div', '', 'breakdown-header');
    const titles = node('div'), title = node('h2', 'Startup breakdown'), count = node('span', '', 'breakdown-count');
    const heading = node('div', '', 'breakdown-title'); heading.append(title, count);
    titles.append(heading, node('p', 'Expand a phase for its steps and timings.', 'breakdown-help'));
    const actions = node('div', '', 'breakdown-actions');
    const current = node('button', 'Show current step', 'startup-text-button'); current.type = 'button';
    const collapse = node('button', 'Collapse all', 'startup-text-button'); collapse.type = 'button'; collapse.hidden = true;
    actions.append(current, collapse); header.append(titles, actions);
    const list = node('ol', '', 'startup-phases');
    panel.append(header, list);
    const diagnostics = node('details', '', 'startup-runtime-details');
    const diagnosticsTitle = node('summary', 'Runtime details'); diagnosticsTitle.append(icon('chevron'));
    const diagnosticsGrid = node('dl', '', 'runtime-measurements');
    const memory = metric(diagnosticsGrid, 'Process memory'), retained = metric(diagnosticsGrid, 'Estimated retained state');
    const recovery = metric(diagnosticsGrid, 'Recovery source'), records = metric(diagnosticsGrid, 'Source records');
    const entities = metric(diagnosticsGrid, 'Constructed entities'), work = metric(diagnosticsGrid, 'Work processed');
    const pending = metric(diagnosticsGrid, 'Pending operations'); pending.parentElement.hidden = true;
    diagnostics.append(diagnosticsTitle, diagnosticsGrid,
      node('p', 'Saved data counts the stored source once. Work processed includes repeated reads. Phase times include their nested steps.', 'breakdown-help'));
    root.append(summary, panel, diagnostics);

    const rows = new Map();
    let boot, latest, options = {}, indexed, byId = new Map(), children = new Map(), roots = [];
    let activePath = [];
    function makeRow(phase, parent) {
      const li = node('li'), details = node('details'), heading = node('summary');
      const symbol = node('span', '', 'phase-symbol'); symbol.setAttribute('aria-hidden', 'true'); symbol.append(icon('check'));
      const copy = node('span', '', 'phase-copy'), label = node('span', '', 'phase-label');
      const state = node('span', '', 'phase-state'), time = node('span', '', 'phase-duration');
      copy.append(label, state);
      const chevron = icon('chevron'); chevron.classList.add('phase-chevron');
      heading.append(symbol, copy, time, chevron);
      const body = node('div', '', 'phase-body');
      const measurements = node('dl', '', 'phase-work'), nested = node('ol');
      const progress = node('progress', '', 'phase-progress'); progress.hidden = true;
      const note = node('p', '', 'phase-note');
      body.append(measurements, progress, note, nested); details.append(heading, body); li.append(details); parent.append(li);
      const row = {li, details, heading, label, state, time, measurements, progress, note, nested, metrics: new Map()};
      rows.set(phase.id, row);
      // Native details supplies Enter/Space, focus and expanded-state semantics.
      details.addEventListener('toggle', () => { if (rows.get(phase.id) === row) render(); });
      return row;
    }
    function updateMeasurements(row, phase, elapsed, descendants) {
      const values = [];
      if (!descendants.length || Object.keys(phase.counters || {}).length) {
        values.push(['duration', phase.state === 'complete' ? 'Duration' : 'Elapsed',
          phase.state === 'pending' || phase.state === 'skipped' ? '—' : duration(elapsed, phase.state === 'complete'),
          phase.state === 'pending' ? 'Waiting to start' : '']);
      }
      const fresh = !options.stale && (options.age || 0) < 5 && phase.state === 'running';
      for (const [unit, counter] of Object.entries(phase.counters || {})) {
        const format = unit === 'bytes' ? bytes : number;
        const total = counter.total == null ? '' : ` / ${counter.accuracy === 'estimated' ? '~' : ''}${format(counter.total)}`;
        const rate = fresh ? phase.throughput?.[unit] : null;
        const hint = [counter.total == null ? 'Total unknown' : '', Number.isFinite(rate)
          ? `${unit === 'bytes' ? bytes(rate) : `${number(rate)} ${unit}`}/s` : ''].filter(Boolean).join(' · ');
        values.push([unit, units[unit] || unit, format(counter.done) + total, hint]);
      }
      if (phase.collection) values.push(['collection', 'Collection', phase.collection, '']);
      if (phase.source) values.push(['source', 'Recovery source', sources[phase.source] || phase.source, '']);
      const keys = new Set(values.map(value => value[0]));
      for (const [key, metric] of row.metrics) metric.group.hidden = !keys.has(key);
      for (const [key, label, value, hint] of values) {
        let item = row.metrics.get(key);
        if (!item) {
          const group = node('div', '', ['collection', 'source'].includes(key) ? 'measurement-identity' : ''), term = node('dt', label), definition = node('dd'), extra = node('span', '', 'measurement-hint');
          group.append(term, definition, extra); row.measurements.append(group);
          item = {group, term, definition, extra}; row.metrics.set(key, item);
        }
        item.group.hidden = false; set(item.term, label);
        (['collection', 'source'].includes(key) ? set : setNumber)(item.definition, value);
        setNumber(item.extra, hint); item.extra.hidden = !hint;
      }
      row.measurements.hidden = !values.length;
      const measurable = ['records', 'bytes', 'pages', 'entities', 'files', 'operations']
        .map(unit => [unit, phase.counters?.[unit]]).find(([, value]) => value && value.total > 0);
      row.progress.hidden = !measurable || !['running', 'waiting'].includes(phase.state);
      if (!row.progress.hidden) {
        const [unit, value] = measurable;
        row.progress.max = value.total; row.progress.value = value.done;
        row.progress.setAttribute('aria-label', `${units[unit]}: ${number(value.done)} of ${number(value.total)} for ${phase.label}`);
      }
      const note = fresh && phase.estimate ? estimate(phase.estimate) : descendants.length
        ? `${descendants.length} steps · ${descendants.filter(p => p.state === 'complete').length} complete`
        : phase.state === 'running' && !Object.keys(phase.counters || {}).length ? 'In progress · no measurable total' : '';
      setNumber(row.note, note); row.note.hidden = !note;
    }
    function renderRow(phase, parent) {
      const row = rows.get(phase.id) || makeRow(phase, parent);
      if (row.li.parentNode !== parent) parent.append(row.li);
      const descendants = children.get(phase.id) || [];
      row.li.dataset.state = phase.state; row.li.dataset.phaseId = phase.id;
      row.li.dataset.level = phase.parent_id ? 'child' : 'root';
      set(row.label, names[phase.id] || phase.label);
      row.label.title = phase.label;
      set(row.state, phase.state === 'pending' ? 'Pending' : phase.state[0].toUpperCase() + phase.state.slice(1));
      const elapsed = phase.duration_seconds ?? (phase.elapsed_seconds || 0) + (
        ['running', 'waiting'].includes(phase.state) ? options.localElapsed || 0 : 0);
      setNumber(row.time, ['pending', 'skipped'].includes(phase.state) ? '—' : duration(elapsed, phase.state === 'complete'));
      row.time.title = Number.isFinite(elapsed) ? `${elapsed.toLocaleString(undefined, {maximumFractionDigits: 3})} seconds` : '';
      // Closed branches cost no DOM work and reveal their latest measurements on demand.
      if (row.details.open) {
        updateMeasurements(row, phase, elapsed, descendants);
        for (const child of descendants) renderRow(child, row.nested);
      }
    }
    function render() {
      if (!latest) return;
      for (const phase of roots) renderRow(phase, list);
      collapse.hidden = ![...rows.values()].some(row => row.details.open);
    }
    current.addEventListener('click', () => {
      for (const id of activePath) {
        render();
        const row = rows.get(id);
        if (row) row.details.open = true;
      }
      render();
      const row = rows.get(activePath.at(-1));
      if (row) { row.heading.focus({preventScroll: true}); row.heading.scrollIntoView({block: 'nearest'}); }
    });
    collapse.addEventListener('click', () => {
      for (const row of rows.values()) row.details.open = false;
      // Keep keyboard focus on a visible control when Collapse all disappears.
      if (!current.hidden) current.focus(); else diagnosticsTitle.focus();
      render();
    });
    return function update(report, context = {}) {
      latest = report; options = context;
      const shutdown = report.lifecycle === 'shutdown';
      set(title, shutdown ? 'Shutdown breakdown' : 'Startup breakdown');
      panel.setAttribute('aria-label', shutdown ? 'Shutdown breakdown' : 'Startup breakdown');
      set(recovery.parentElement.querySelector('dt'), shutdown ? 'Save destination' : 'Recovery source');
      entities.parentElement.hidden = shutdown;
      records.parentElement.hidden = shutdown;
      pending.parentElement.hidden = !shutdown;
      setNumber(pending, number(report.pending_operations));
      if (boot !== report.boot_id) {
        boot = report.boot_id; list.replaceChildren(); rows.clear(); diagnostics.open = false; indexed = null;
      }
      if (indexed !== report) {
        indexed = report;
        const phases = Array.isArray(report.phases) ? report.phases : [];
        byId = new Map(phases.map(phase => [phase.id, phase])); children = new Map(); roots = [];
        for (const phase of phases) {
          if (phase.parent_id && byId.has(phase.parent_id)) {
            if (!children.has(phase.parent_id)) children.set(phase.parent_id, []);
            children.get(phase.parent_id).push(phase);
          } else roots.push(phase);
        }
        const active = [...phases].reverse().find(phase => ['running', 'waiting', 'failed'].includes(phase.state));
        activePath = []; let cursor = active;
        while (cursor && !activePath.includes(cursor.id)) { activePath.unshift(cursor.id); cursor = byId.get(cursor.parent_id); }
        current.hidden = !activePath.length || report.status === 'ready';
        set(current, report.status === 'failed' ? 'Show failed step' : 'Show current step');
      }
      setNumber(count, `${roots.filter(p => ['complete', 'skipped'].includes(p.state)).length} of ${roots.length} complete`);
      setNumber(eta, ['ready', 'stopped'].includes(report.status) ? 'Complete' : report.status === 'failed' ? 'Stopped' : context.stale ? 'Unavailable while reconnecting' : estimate(report.estimate));
      eta.title = report.estimate?.basis?.replaceAll('_', ' ') || 'An estimate appears when enough measurements are available.';
      setNumber(saved, bytes(report.saved_data_bytes));
      setNumber(repositories, `${number(report.repositories_complete || 0)} / ${number(report.repositories_total)}`);
      setNumber(memory, bytes(report.memory?.rss_bytes)); setNumber(retained, bytes(report.memory?.estimated_live_bytes));
      set(recovery, sources[report.source] || report.source || 'Not selected yet');
      setNumber(records, number(report.source_records)); setNumber(entities, number(report.constructed_entities)); setNumber(work, bytes(report.work_bytes_processed));
      render();
    };
  }
  window.SMTOStartupReport = {mount, bytes, seconds, duration};
})();
