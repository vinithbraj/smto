/**
 * @file src/agent_runtime/api/static/agent_ui/draft_cache.js
 * @brief Retain bounded tab-local drafts and conversation Gateway intent.
 * @details
 * Responsibilities: Cache unsent text, safe attachment references and composer selections.
 * Boundaries: Requests, credential input and accepted run authority stay with their owners.
 * Lifecycle: Navigation flushes/restores scopes; acceptance consumes text but retains targets.
 * State: Session-storage schema 3 migrates schema 1/2 under the existing key and quotas.
 * Security: Literal text follows ordinary draft retention; target_selector validates ID-only snapshots.
 * Collaborators: app supplies navigation and target_selector owns selection invariants.
 * Public surface: create returns draft lifecycle methods; scopeFor maps mode and conversation.
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/api/static/agent_ui/target_selector.js
 */
(() => {
  "use strict";
  const KEY = "smto.agentUi.drafts.v1";
  const MAX_DRAFTS = 32, MAX_TEXT = 24000, MAX_BYTES = 1024 * 1024;
  const validScope = scope => typeof scope === "string"
    && /^(agent|(?:conversation|advisory):[\w-]{1,200})$/.test(scope);
  const scopeFor = (mode, id) => mode === "agent" && !id ? "agent" : `${mode === "advisory" ? "advisory" : "conversation"}:${id || "new"}`;

  function create({input, native, capabilityPolicy, permissionPolicy, behaviorEffort, runtimeGuards, targetSelector, interactionWaiting, isSteering,
    changed = () => {}, notify = () => {}}) {
    let drafts = Object.create(null), scope = null, timer = null, applying = false;
    let edited = false, consumed = false, revision = 0, warned = false;
    const safeText = text => typeof text === "string";
    const empty = draft => !draft.text.trim() && !draft.attachments.length
      && !draft.capabilities.has_prompt_override && !draft.capabilities.pending_policy
      && !draft.permissions.has_prompt_override && !draft.permissions.pending_policy
      && typeof draft.completion_handling !== "boolean" && !Object.keys(draft.completion_handling || {}).length
      && !draft.gateway_target;
    function canonical(value, key) {
      if (!validScope(key) || !value || ![1, 2, 3].includes(value.schema_version) || value.scope !== key
        || !safeText(value.text) || value.text.length > MAX_TEXT) return null;
      const draft = {schema_version: 3, scope: key, text: value.text,
        attachments: native.safeAttachments(value.attachments),
        capabilities: window.SMTOCapabilityPolicy.safeDraftState(value.capabilities),
        permissions: window.SMTOPermissionPolicy.safeDraftState(value.permissions),
        ...((typeof value.completion_handling === "boolean" || (value.completion_handling && typeof value.completion_handling === "object" && !Array.isArray(value.completion_handling)))
          ? {completion_handling: value.completion_handling} : {}),
        ...(window.SMTOBehaviorEffort?.valid(value.behavior_effort) ? {behavior_effort: value.behavior_effort} : {}),
        ...(value.gateway_target !== undefined ? {gateway_target: window.SMTOTargetSelector.safeDraft(value.gateway_target)
          || {schema_version: 2, gateway_selection: {schema_version: 1, gateway_ids: [], primary_gateway_id: ""}, gateways: []}} : {}),
        was_steering: value.was_steering === true,
        saved_at: typeof value.saved_at === "string" && Number.isFinite(Date.parse(value.saved_at))
          ? new Date(value.saved_at).toISOString() : new Date(0).toISOString()};
      if (key !== "conversation:new") { delete draft.capabilities.pending_policy; delete draft.permissions.pending_policy; }
      return empty(draft) ? null : draft;
    }
    function warn() {
      if (!warned) { warned = true; notify("This draft could not be cached in this tab. Your text is still in the composer."); }
    }
    function persist() {
      const oldest = () => Object.keys(drafts).sort((a, b) => drafts[a].saved_at.localeCompare(drafts[b].saved_at));
      while (Object.keys(drafts).length > MAX_DRAFTS) delete drafts[oldest()[0]];
      let raw = JSON.stringify({schema_version: 3, drafts});
      // UTF-16 accounting is conservative for browser storage quotas.
      while (raw.length * 2 > MAX_BYTES && Object.keys(drafts).length) {
        delete drafts[oldest()[0]];
        raw = JSON.stringify({schema_version: 3, drafts});
      }
      try { window.sessionStorage.setItem(KEY, raw); }
      catch (_) { warn(); }
    }
    try {
      const raw = window.sessionStorage.getItem(KEY);
      const root = raw && raw.length * 2 <= MAX_BYTES ? JSON.parse(raw) : null;
      if ([1, 2, 3].includes(root?.schema_version) && root.drafts && typeof root.drafts === "object" && !Array.isArray(root.drafts)) {
        for (const [key, value] of Object.entries(root.drafts)) {
          if (value?.schema_version !== root.schema_version) continue;
          const draft = canonical(value, key);
          if (draft) drafts[key] = draft;
        }
      }
      if (raw) persist(); // Drop malformed, oversized, or unknown fields on read.
    } catch (_) {
      try { window.sessionStorage.removeItem(KEY); } catch (_) { /* Storage may be disabled. */ }
    }
    const cancel = () => { clearTimeout(timer); timer = null; };
    function snapshot() {
      if (!scope) return null;
      const targetOnly = interactionWaiting() || !safeText(input.value) || (consumed && !input.value) || input.value.length > MAX_TEXT;
      if (input.value.length > MAX_TEXT) warn();
      if (targetOnly) return targetDraft();
      return canonical({schema_version: 3, scope, text: input.value,
        attachments: native.attachmentSnapshot(), capabilities: capabilityPolicy.draftSnapshot(), permissions: permissionPolicy?.draftSnapshot(),
        behavior_effort: behaviorEffort?.value(),
        completion_handling: runtimeGuards?.draftSnapshot(),
        ...(targetSelector?.isInitialized() ? {gateway_target: targetSelector.draftSnapshot()} : {}),
        was_steering: Boolean(isSteering() || (drafts[scope]?.was_steering && drafts[scope]?.text === input.value)),
        saved_at: new Date().toISOString()}, scope);
    }
    // Selection is conversation intent even when its prompt has been sent or is private.
    function targetDraft() {
      return targetSelector?.isInitialized() && scope ? canonical({schema_version: 3, scope, text: "", attachments: [],
        gateway_target: targetSelector.draftSnapshot(), saved_at: new Date().toISOString()}, scope) : null;
    }
    function flush() {
      cancel();
      if (applying || !scope) return;
      const draft = snapshot();
      if (draft) drafts[scope] = draft;
      else delete drafts[scope];
      persist();
    }
    function touch(immediate = false) {
      if (applying) return;
      edited = true; consumed = false; revision++;
      cancel();
      if (immediate) flush();
      else timer = setTimeout(flush, 250);
    }
    function apply(draft, {preserveText = false} = {}) {
      applying = true;
      try {
        capabilityPolicy.restoreDraftState(draft?.capabilities);
        permissionPolicy?.restoreDraftState(draft?.permissions);
        behaviorEffort?.restore(draft?.behavior_effort);
        runtimeGuards?.restoreDraftState(draft?.completion_handling);
        if (draft?.gateway_target && !preserveText) targetSelector?.restoreDraftState(draft.gateway_target);
        native.restoreAttachments(draft?.attachments);
        if (!preserveText) {
          input.value = draft?.text || "";
          input.setSelectionRange(input.value.length, input.value.length);
        }
        changed();
      } finally { applying = false; }
      if (draft?.was_steering && !preserveText) {
        draft.was_steering = false;
        notify("Recovered your unsent task update as a normal draft.");
      }
    }
    function leave({preserveText = false} = {}) {
      if (!scope) return;
      flush(); scope = null; apply(null, {preserveText}); if (!preserveText) targetSelector?.restoreDraftState(null); edited = false; consumed = false;
    }
    function activate(next, {preserveText = false} = {}) {
      if (!validScope(next) || scope === next) return;
      scope = next; consumed = false;
      if (interactionWaiting()) { consume(); return; }
      // Input/options edited during asynchronous boot or navigation always win.
      if (!edited && (!input.value || preserveText)) apply(drafts[scope], {preserveText});
      edited = false;
      flush();
    }
    function rebind(next) {
      if (!scope || scope === next || !validScope(next)) return;
      // A newly accepted conversation inherits only the future composer, not the sent prompt.
      delete drafts[scope]; scope = next;
      applying = true;
      try { native.restoreAttachments(native.attachmentSnapshot()); }
      finally { applying = false; }
      flush();
    }
    function consume(expected = null) {
      const target = expected?.scope || scope;
      if (expected && (target !== scope || (input.value && input.value !== expected.text))) {
        if (drafts[target]?.text === expected.text) { delete drafts[target]; persist(); }
        return;
      }
      cancel(); consumed = true;
      if (target) {
        const retained = target === scope ? targetDraft() : null;
        if (retained) drafts[target] = retained;
        else if (drafts[target]?.gateway_target) drafts[target] = {...drafts[target], text: "", attachments: []};
        else delete drafts[target];
        persist();
      }
    }
    function beginSubmission() {
      const pending = {scope, draft: snapshot(), revision};
      consume();
      return pending;
    }
    function recover(pending) {
      if (!pending?.draft) return;
      if (scope === pending.scope && !input.value && revision === pending.revision && !interactionWaiting()) {
        consumed = false; apply(pending.draft); flush();
      } else notify("Previous prompt could not be submitted.");
    }
    window.addEventListener("pagehide", flush);
    return {touch, flush, leave, activate, rebind, consume, beginSubmission, recover, snapshot,
      scope: () => scope};
  }
  window.SMTODraftCache = {create, scopeFor};
})();
