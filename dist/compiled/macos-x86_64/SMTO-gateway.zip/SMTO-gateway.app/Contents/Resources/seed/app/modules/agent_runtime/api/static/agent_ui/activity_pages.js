/* Bounded retained history shared by both clients. Current state has a separate owner. */
import {retainedConversation} from "./retained_conversation.js?v=20261019-resources";
import {mountCallTracks} from "./latency_timeline.js?v=20261015-smto";
const node = (tag, text, className = "") => {
  const el = document.createElement(tag); el.textContent = text || ""; el.className = className; return el;
};
export const boundLiveActivity = (host, maps) => window.SMTOConversationSnapshot.boundActivity(host, maps);
let detailSequence = 0;

export function mountActivityPages({disclosure, host, requestId, apiJson, ready = Promise.resolve(),
  visible = () => disclosure.open, allHistory = false, onState = () => {}, conversationId = "", renderMarkdown, onAnswerArchived,
  initialFeedback = null, initialForeground = true}) {
  const normallyVisible = visible;
  visible = () => !window.SMTOUiFind?.isRevealed(disclosure) && normallyVisible();
  const root = node("section", "", "activity-pages"), controls = node("nav", "", "activity-page-controls");
  controls.setAttribute("aria-label", "Activity history pages");
  const older = node("button", "Older activity"), newer = node("button", "Newer activity");
  const latest = node("button", "Latest activity"), exact = node("button", "Show exact event sequence");
  const status = node("p", "", "activity-page-status"), rows = node("tbody", "", "activity-page-rows");
  const progress = node("progress", "", "history-load-progress");
  progress.max = 100; progress.setAttribute("aria-label", "History loading progress");
  const transcript = node("div", "", "retained-conversation progress-timeline");
  const callTracks = node("div", "", "latency-call-tracks");
  if (allHistory) {
    root.classList.add("run-history");
    root.setAttribute("aria-label", "Retained activity history");
    status.setAttribute("role", "status");
    transcript.setAttribute("aria-label", "Restored conversation");
    // History restores the chat; raw event browsing belongs to Inspect execution.
    root.append(status, progress, transcript);
  } else {
    const tableWrap = node("div", "", "activity-events-scroll"), table = node("table", "", "activity-events-table");
    table.setAttribute("aria-label", "Execution events");
    const head = node("thead"), headings = node("tr");
    for (const label of ["Time", "Event", "Summary"]) {
      const heading = node("th", label); heading.scope = "col"; headings.append(heading);
    }
    head.append(headings); table.append(head, rows); tableWrap.append(table);
    for (const button of [older, newer, latest, exact]) button.type = "button";
    controls.append(older, newer, latest, exact); root.append(controls, status, callTracks, tableWrap);
  }
  host.before(root);
  let controller = null, generation = "", cursor = null, nextCursor = null, stack = [], version = 0;
  let loaded = false, exactSequence = false, disposed = false, dirty = false;
  let historyCursor = null, historyStarted = false;
  let historyTotal = null, historyScanned = 0, progressTimer = null;
  let attemptStarted = 0, attemptScanned = 0, restoring = false;
  const historyEvents = new Map(), liveEvents = new Map();
  let conversation = null, runStatus = "running";
  const hostWasHidden = host.hidden;
  function setHostHidden(hidden) {
    host.hidden = hidden;
    // Replacing live rows does not emit a disclosure toggle. Suspend their
    // observers explicitly, and reconcile again if the live host is restored.
    for (const panel of host.querySelectorAll(".shell-live-panel"))
      (panel.modelViewer || panel.shellViewer)?.reconcile();
  }
  const viewers = new Set();
  let detail = null;
  const closeDetail = (refresh = false) => {
    if (detail) { detail.controller.abort(); detail.button.setAttribute("aria-expanded", "false"); detail.row.remove(); detail = null; }
    for (const viewer of viewers) viewer.dispose(); viewers.clear();
    if (refresh && dirty && cursor == null && visible()) void load();
  };
  const clean = closeDetail;
  /** Update history-load progress and accessible status using the current attempt's scan rate. */
  function showProgress() {
    const elapsed = Math.max(0, (performance.now() - attemptStarted) / 1000);
    const scanned = historyScanned - attemptScanned;
    const percent = historyTotal ? Math.min(99, Math.floor(100 * historyScanned / historyTotal)) : null;
    if (percent == null) progress.removeAttribute("value"); else progress.value = percent;
    let label = restoring ? "Restoring chat…" : "Loading history…";
    if (percent != null) label += ` ${percent}%`;
    if (!restoring && historyTotal > historyScanned && scanned > 0 && elapsed >= 1) {
      const seconds = Math.max(1, Math.ceil(elapsed * (historyTotal - historyScanned) / scanned));
      label += seconds < 60 ? ` · about ${seconds}s left` : ` · about ${Math.ceil(seconds / 60)} min left`;
    } else if (percent == null && elapsed >= 1) label += ` ${Math.floor(elapsed)}s elapsed`;
    window.SMTONumberOdometer.render(status, label); progress.setAttribute("aria-valuetext", label);
  }
  async function inspect(event, row, button) {
    const busyFeedback = window.SMTOBusy?.begin({host: button, label: "Loading activity details…"});
    try {
    if (detail?.button === button) { closeDetail(true); return; }
    closeDetail();
    const isTable = row.tagName === "TR";
    const detailRow = node(isTable ? "tr" : "div", "", "activity-event-details"), cell = node(isTable ? "td" : "div");
    if (isTable) cell.colSpan = 3;
    if (!button.hasAttribute("aria-controls")) button.setAttribute("aria-controls", `activity-event-detail-${++detailSequence}`);
    detailRow.id = button.getAttribute("aria-controls"); detailRow.append(cell); row.after(detailRow);
    button.setAttribute("aria-expanded", "true");
    const current = detail = {row: detailRow, button, event, controller: new AbortController()};
    window.SMTOCommandPreview.mount(cell, event, apiJson);
    function attachOutput(label, className, loadViewer, options) {
      const output = node("details", "", `event-output shell-live ${className}`), panel = node("div");
      output.append(node("summary", label), panel);
      window.SMTOActivityPresentation.attachSection(cell, output, label);
      let loading = false, viewer = null;
      output.addEventListener("toggle", async () => {
        const busyFeedback = window.SMTOBusy?.action("Loading activity output…", output);
        try {
        if (!output.open || loading || viewer) return;
        loading = true; panel.textContent = "Loading output…";
        try {
          const mount = await loadViewer();
          if (detail !== current || !output.open || !output.isConnected) return;
          panel.replaceChildren();
          viewer = mount({disclosure: output, panel, requestId, ...options});
          viewers.add(viewer);
        } catch (_) {
          if (detail === current) panel.textContent = "Could not load output. Close and reopen to retry.";
        } finally { loading = false; }

        } finally { busyFeedback?.finish(); }
      });
    }
    const d = event.detail || {}, operationId = d.operation_id || d.action_id;
    const shellOutput = operationId && (d.kind === "shell_command" || d.capability_id === "shell.command"
      || typeof event.command_preview === "string" || typeof d.command === "string");
    if (Number.isFinite(d.elapsed_ms) || Number.isFinite(d.wait_seconds)) {
      const timing = node("details", "", "timing-detail"), facts = node("div", "", "timing-facts");
      const milliseconds = Number.isFinite(d.elapsed_ms) ? d.elapsed_ms : d.wait_seconds * 1000;
      facts.textContent = `Duration: ${window.SMTOPerformanceTiming?.format(milliseconds) || `${(milliseconds / 1000).toFixed(2)} s`}`;
      timing.append(node("summary", "Timing"), facts);
      window.SMTOActivityPresentation.attachSection(cell, timing, "Timing", 0);
    }
    if (d.detail_available && (d.invocation_id || operationId) && !shellOutput) {
      // Reuse the live invocation inspector. Its body stays lazy until opened.
      cell.classList.add("retained-tool-output");
      void import("./tool_activity.js?v=20261018-loading").then(() => {
        if (detail !== current) return;
        current.invocation = window.SMTOToolActivity.mount(cell, requestId, current.event.detail, (value, options = {}) => {
          const copy = node("button", "", "copy-button"); copy.type = "button";
          copy.setAttribute("aria-label", options.label || "Copy sanitized data");
          copy.title = options.label || "Copy sanitized data";
          copy.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
          const copied = window.SMTOCopyFeedback.bind(copy);
          copy.onclick = async () => {
        const busyFeedback = window.SMTOBusy?.action("Loading activity output…", copy);
        try {
            try { await navigator.clipboard.writeText(typeof value === "function" ? await value() : value); copied(); }
            catch (_) { copy.textContent = "Could not copy. Try again."; }

        } finally { busyFeedback?.finish(); }
      };
          return copy;
        });
      }).catch(() => { if (detail === current) cell.append(node("p", "Could not load tool details. Close and reopen to retry.")); });
    }
    if (shellOutput) {
      attachOutput("Tool output", "", async () =>
        (await import("./shell_live_stream.js?v=20261018-loading")).mountShellInspector,
      {operationId, initialEvent: event});
    }
    if (d.call_id && /^(llm|model)\./.test(event.event_type)) {
      attachOutput("Model output", "trace-output model-output-inspector", async () =>
        (await import("./model_output_viewer.js?v=20261018-loading")).mountModelOutput,
      {callId: d.call_id});
    }
    const body = node("pre", "Loading event…", "activity-event-json");
    body.setAttribute("aria-label", "Event details");
    const raw = node("details", "", "activity-raw-detail");
    raw.append(node("summary", "Event details"), body);
    window.SMTOActivityPresentation.attachSection(cell, raw, "Event details", 2);
    try {
      const value = await apiJson(event.detail_url, {signal: current.controller.signal});
      if (detail === current) {
        body.textContent = JSON.stringify(value, null, 2);
        if (event.event_type === "prompt_cache.observation") {
          const {mountPromptCacheObservation} = await import("./latency_timeline.js?v=20261019-cache");
          if (detail === current) mountPromptCacheObservation(cell, value.detail || value.event?.detail);
        }
        if (event.event_type === "llm.timeline" || value.detail?.latency_timeline) {
          const {mountLatencyTimeline} = await import("./latency_timeline.js?v=20261015-smto");
          if (detail === current) mountLatencyTimeline(raw, value.detail?.latency_timeline || value.detail || value.event?.detail);
        }
      }
    } catch (error) {
      if (detail === current && error.name !== "AbortError") body.textContent = "Could not load event. Close and reopen to retry.";
    }

    } finally { busyFeedback?.finish(); }
  }
  async function restoreConversation(current) {
    const content = node("div");
    const restored = retainedConversation({host: content, conversationId, inspect, renderMarkdown, onAnswerArchived});
    restored.update(runStatus);
    const events = new Map([...historyEvents, ...liveEvents]);
    let slice = performance.now();
    for (const event of [...events.values()].sort((a, b) => a.id - b.id)) {
      if (!current()) return;
      restored.event(event);
      if (performance.now() - slice > 8) { await new Promise(resolve => setTimeout(resolve, 0)); slice = performance.now(); }
    }
    if (!current()) return;
    // Include frames received while the retained projection yielded to the UI.
    for (const event of liveEvents.values()) restored.event(event);
    restored.update(runStatus);
    clean(); transcript.replaceChildren(content); conversation = restored;
    setHostHidden(true);
    disclosure.classList.add("progress-timeline"); disclosure.open = true;
  }
  async function conversationPage(page, signal) {
    // Chat text is top-level content, not an optional nested event body. Compact
    // pages can truncate both the text and its identity; hydrate only those rows.
    const pending = page.events.filter(event => event.detail_truncated && (
      ["agent.progress.narration", "agent.final_response.retained", "conversation.message", "user.steered"].includes(event.event_type)
      // Compatibility with servers whose compact projection dropped lifecycle
      // identities. New projections retain these without loading diagnostic bodies.
      || /^llm\.(request(\.started)?|response(\.(completed|accepted|rejected))?|error|cancelled)$/.test(event.event_type)
        && !event.detail?.call_id));
    const full = new Map();
    const results = await Promise.allSettled(Array.from({length: Math.min(4, pending.length)}, async () => {
      while (pending.length) {
        const event = pending.shift();
        const value = await apiJson(event.detail_url, {signal});
        full.set(event.id, {...event, ...value});
      }
    }));
    const failed = results.find(result => result.status === "rejected");
    if (failed) throw failed.reason;
    return page.events.map(event => full.get(event.id) || event);
  }
  async function render(page, current) {
    clean(); rows.replaceChildren();
    let slice = performance.now(), duplicates = 0;
    const seenRows = new Set();
    for (const event of page.events) {
      if (!current()) return;
      const row = node("tr", "", "activity-event"), d = event.detail || {};
      const title = event.title || event.event_type || "Event", summary = event.summary || d.content || d.text || "";
      const timestamp = new Date(event.timestamp || NaN), milliseconds = timestamp.getTime();
      // Match the visible row at its displayed second, including the date so
      // events on different days stay distinct. Exact mode retains every event.
      if (!exactSequence && Number.isFinite(milliseconds)) {
        const key = JSON.stringify([event.request_id || requestId, Math.floor(milliseconds / 1000), title, summary]);
        if (seenRows.has(key)) { duplicates++; continue; }
        seenRows.add(key);
      }
      row.dataset.eventId = event.id; row.dataset.eventType = event.event_type;
      row.dataset.stripe = rows.children.length % 2 ? "alternate" : "base";
      const timeCell = node("td"), eventCell = node("td"), description = node("td", summary);
      const time = node("time", Number.isNaN(timestamp.getTime()) ? "—"
        : timestamp.toLocaleTimeString(undefined, {hour: "2-digit", minute: "2-digit", second: "2-digit"}));
      if (!Number.isNaN(timestamp.getTime())) { time.dateTime = timestamp.toISOString(); time.title = timestamp.toLocaleString(); }
      timeCell.append(time);
      const button = node("button", title, "activity-event-toggle");
      button.type = "button"; button.setAttribute("aria-expanded", "false");
      button.setAttribute("aria-controls", `activity-event-detail-${++detailSequence}`);
      button.addEventListener("click", () => { void inspect(event, row, button); });
      eventCell.append(button); row.append(timeCell, eventCell, description);
      rows.append(row);
      if (performance.now() - slice > 8) { await new Promise(resolve => setTimeout(resolve, 0)); slice = performance.now(); }
    }
    if (!page.events.length && !rows.children.length) {
      const row = node("tr"), cell = node("td", "No recorded activity."); cell.colSpan = 3; row.append(cell); rows.append(row);
    }
    performance.mark("activity_page_rendered");
    return duplicates;
  }
  async function loadHistory(feedback = false, operation = null) {
    if (disposed || controller || !visible()) return;
    const busyFeedback = operation || (feedback ? window.SMTOBusy?.begin({host: root, label: "Loading history…"}) : null);
    const owner = ++version; controller = new AbortController();
    const signal = controller.signal;
    const current = () => !disposed && owner === version && !signal.aborted && disclosure.isConnected;
    disclosure.setAttribute("aria-busy", "true");
    onState("loading");
    root.dataset.historyState = "loading"; restoring = false;
    attemptStarted = performance.now(); attemptScanned = historyScanned;
    showProgress(); progressTimer = setInterval(showProgress, 1000);
    try {
      await ready;
      while (current()) {
        const query = new URLSearchParams({view: "compact", limit: "100"});
        if (historyCursor != null) query.set("before_id", historyCursor);
        if (generation) query.set("generation", generation);
        const page = await apiJson(`/api/agent/trace/${encodeURIComponent(requestId)}/activity?${query}`, {signal});
        if (!current()) return;
        if (page.reset) {
          clean(); historyCursor = null;
          historyEvents.clear(); liveEvents.clear(); conversation = null;
          historyTotal = null; historyScanned = 0; attemptScanned = 0;
          transcript.replaceChildren(); host.hidden = hostWasHidden;
        }
        generation = page.trace_created_at;
        if (historyTotal == null && Number.isInteger(page.progress?.remaining))
          historyTotal = historyScanned + page.progress.scanned + page.progress.remaining;
        const conversationEvents = await conversationPage(page, signal);
        if (!current()) return;
        for (const event of conversationEvents) historyEvents.set(event.id, event);
        historyStarted = true;
        historyScanned += page.progress?.scanned ?? (page.events.length + (page.coalesced_count || 0) + (page.on_demand_output_events || 0));
        showProgress();
        if (!page.has_more_before) {
          restoring = true; showProgress();
          await restoreConversation(current);
          if (!current()) return;
          loaded = true;
          progress.value = 100; progress.setAttribute("aria-valuetext", "History loaded");
          status.textContent = "History loaded"; root.dataset.historyState = "loaded";
          onState("loaded");
          return;
        }
        if (page.before_cursor == null || (historyCursor != null && page.before_cursor >= historyCursor))
          throw new Error("History cursor did not advance");
        historyCursor = page.before_cursor;
        await new Promise(resolve => setTimeout(resolve, 0));
      }
    } catch (error) {
      if (current() && error.name !== "AbortError") {
        root.dataset.historyState = "error";
        status.textContent = "Could not load all history. Select Load history to retry.";
        progress.setAttribute("aria-valuetext", "History loading interrupted");
        onState("error");
      }
    } finally {
      busyFeedback?.finish();
      if (owner === version) {
        clearInterval(progressTimer); progressTimer = null;
        controller = null; disclosure.removeAttribute("aria-busy");
      }
    }
  }
  async function load(before = null, feedback = false, operation = null) {
    if (allHistory) return loadHistory(feedback, operation);
    if (!visible()) return;
    const busyFeedback = operation || (feedback ? window.SMTOBusy?.begin({host: root, label: "Loading activity…", key: "page", replace: true}) : null);
    dirty = false;
    controller?.abort(); const owner = ++version; controller = new AbortController();
    const signal = controller.signal;
    const current = () => !disposed && owner === version && !signal.aborted && disclosure.isConnected && visible();
    disclosure.setAttribute("aria-busy", "true"); status.textContent = "Loading activity…";
    try {
      await ready;
      if (!current()) return;
      const query = new URLSearchParams({view: exactSequence ? "exact" : "compact", limit: "100"});
      if (before != null) query.set("before_id", before);
      if (generation) query.set("generation", generation);
      const page = await apiJson(`/api/agent/trace/${encodeURIComponent(requestId)}/activity?${query}`, {signal});
      if (!current()) return;
      if (page.reset) { stack = []; before = null; }
      mountCallTracks(callTracks, page.timing?.latency);
      generation = page.trace_created_at; cursor = before; nextCursor = page.before_cursor;
      const duplicates = await render(page, current);
      if (!current()) return;
      loaded = true; older.disabled = !page.has_more_before; newer.disabled = !stack.length;
      latest.disabled = cursor == null;
      window.SMTONumberOdometer.render(status, `${page.events.length} recorded events${page.coalesced_count ? ` · ${page.coalesced_count} superseded progress updates grouped` : ""}${duplicates ? ` · ${duplicates} duplicate rows grouped` : ""}`);
    } catch (error) {
      if (current() && error.name !== "AbortError") { loaded = false; status.textContent = "Could not load activity. Close and reopen to retry."; }
    } finally {
      busyFeedback?.finish();
      if (owner === version) {
        controller = null; disclosure.removeAttribute("aria-busy");
        if (dirty && cursor == null && visible() && !detail) void load();
      }
    }
  }
  older.onclick = () => { if (nextCursor != null) { stack.push(cursor); void load(nextCursor, true); } };
  newer.onclick = () => { if (stack.length) void load(stack.pop(), true); };
  latest.onclick = () => { stack = []; void load(null, true); };
  exact.onclick = () => { exactSequence = !exactSequence; exact.textContent = exactSequence ? "Group superseded progress" : "Show exact event sequence"; stack = []; void load(null, true); };
  const toggle = (feedback = false, operation = null) => {
    if (allHistory) {
      // Loading is explicitly requested and continues if Activity is collapsed.
      // Disposal on conversation navigation owns cancellation.
      if (!historyStarted && !controller && visible()) return loadHistory(feedback, operation);
      for (const viewer of viewers) viewer.reconcile();
      return;
    }
    if (!visible()) {
      if (controller) loaded = false;
      controller?.abort(); controller = null; version++; disclosure.removeAttribute("aria-busy");
    }
    else if (!loaded && !detail && !controller) return load(null, feedback, operation);
    for (const viewer of viewers) viewer.reconcile();
  };
  const onToggle = () => toggle(true);
  disclosure.addEventListener("toggle", onToggle);
  const initialLoad = toggle(initialForeground, initialFeedback);
  return {ready: initialLoad, reload(operation = null) {
    if (allHistory && loaded) {
      clean();
      historyEvents.clear();
      historyTotal = null; historyScanned = 0;
      historyCursor = null; loaded = false;
    }
    return load(null, Boolean(operation), operation);
  }, reconcile: toggle,
    event(event) {
      if (!allHistory || disposed) return;
      const value = {...event, detail_url: event.detail_url
        || `/api/agent/trace/${encodeURIComponent(requestId)}/activity/events/${event.id}`};
      liveEvents.set(event.id, value); conversation?.event(value);
      const inspected = detail?.event.detail || {}, incoming = event.detail || {};
      const inspectedId = inspected.invocation_id || inspected.operation_id || inspected.action_id;
      if (inspectedId && inspectedId === (incoming.invocation_id || incoming.operation_id || incoming.action_id)) {
        detail.event = window.SMTOActivityPresentation.merge(detail.event, event);
        detail.invocation?.updateDetails(detail.event.detail);
      }
    },
    update(status) { runStatus = status; conversation?.update(status); },
    invalidate() {
      if (cursor != null) return;
      dirty = true; loaded = false;
      if (detail) {
        latest.disabled = false;
        status.textContent = "New events available · select Latest activity to refresh.";
      } else if (!controller) toggle();
    },
    dispose() {
      clearInterval(progressTimer);
      disposed = true; controller?.abort(); clean(); disclosure.removeAttribute("aria-busy");
      if (allHistory) setHostHidden(hostWasHidden);
      disclosure.removeEventListener("toggle", onToggle); root.remove();
    }};
}
