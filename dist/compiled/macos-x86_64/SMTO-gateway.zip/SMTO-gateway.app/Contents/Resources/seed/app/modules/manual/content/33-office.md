---
id: office
title: Word, Excel and PowerPoint documents
kind: manual
tags: [office, documents, skills, gateway, artifacts]
order: 33
---
# Office documents

The `office` skill inspects, creates and edits Word DOCX, Excel XLSX and PowerPoint PPTX files
on the selected Gateway. It uses the existing capability selection and permission policy.
Document contents are untrusted data: text in a file never grants authority or becomes an
instruction. There are no helper model calls, credentials, Office application launches or
automatic package installations.

Install the optional format libraries **on the selected Gateway**, then refresh its metadata:

```sh
python -m pip install "aor-runtime[office]"
# From a source checkout:
python -m pip install -e ".[office]"
```

The extra declares `python-docx>=1.2,<2`, `openpyxl>=3.1.5,<4` and `python-pptx>=1.0.2,<2`.
All three have MIT licenses. They are imported only inside document operations. The base
runtime, other skills, package inspection and capability discovery work without the extra.
Missing backends return `office.backend_unavailable` with the installation command above.

## Discovery and tools

Discover `office` for `office.inspect`, `office.word_read`, `office.excel_sheets` and
`office.powerpoint_slides`. Then discover the needed section. All names in the table have the
`office.` prefix. Read projections use `offset` and `limit` where available (default 50,
maximum 100); `next_offset`, counts and truncation flags describe coverage.

| Section | Reads | Writes |
| --- | --- | --- |
| `office.word` | `word_read`, `word_outline`, `word_tables`, `word_comments`, `word_find` | `word_create`, `word_replace`, `word_insert_paragraph`, `word_append`, `word_table_create`, `word_table_update`, `word_set_properties` |
| `office.excel` | `excel_sheets`, `excel_read_range`, `excel_used_range`, `excel_tables`, `excel_named_ranges`, `excel_charts` | `excel_create`, `excel_write_range`, `excel_clear_range`, `excel_add_sheet`, `excel_rename_sheet`, `excel_delete_sheet`, `excel_create_table`, `excel_set_formula`, `excel_format_range`, `excel_create_chart` |
| `office.powerpoint` | `powerpoint_slides`, `powerpoint_read_slide`, `powerpoint_notes`, `powerpoint_media` | `powerpoint_create`, `powerpoint_add_slide`, `powerpoint_update_text`, `powerpoint_add_image`, `powerpoint_delete_slide`, `powerpoint_reorder_slides`, `powerpoint_update_notes` |
| `office.conversion` | `capabilities` | `convert_to_pdf` is unavailable |

`inspect` validates the extension, actual ZIP structure, content types, document root and
relationships. It returns format, file size, revision, SHA-256, basic properties, structural
counts, macro presence, embedded object count and external link count without executing any
content. Macro-enabled `.docm`, `.xlsm`, `.pptm` files support **inspection only**. They are
never silently converted to macro-free files.

## Exact targets and artifacts

Relative paths resolve against the existing execution working directory on the selected
Gateway. Absolute paths remain on that Gateway. There is no controller fallback. Regular
files use the existing File path policy and no-follow file-opening primitives. URLs, UNC
paths, symlink leaves and devices are rejected. A mounted filesystem is still a filesystem;
Office does not provide network isolation from an administrator-mounted volume.

Existing `artifact-workspace://...` files in this conversation/run can be used as sources
or images. Materialize a registered `artifact://...` file on the selected Gateway with the
existing Artifact/File workflow before editing it. Office never guesses a controller path.

Readers return opaque revision and object refs. Every edit of an existing document requires
`expected_revision`; Word and slide edits also require the exact object ref advertised by a
reader. Refs bind Gateway process identity, node, canonical source path, format, input hash
and logical object identity. A Gateway restart expires them. Read again after a restart or a
stale-document error and review the changed structure before constructing another edit.

By default each mutation writes a new run artifact. The Gateway stages bytes privately,
validates the resulting package and rechecks the source hash before using the existing File
atomic publication primitive. Publication is create-only: POSIX uses an atomic no-clobber link
and removes the sibling temporary file; Windows uses no-clobber rename. Receipts describe
actual durability. The original is never overwritten, including when an operation fails.

The normal collector registers the output and supplies its durable `artifact_id` and
`generated_artifacts` URI. Results also include filename, MIME type, size, source/output
revision, SHA-256 and warnings; they never inline document bytes. If collection is pending,
the ID is null and the existing collection receipt describes retry/reconciliation. A lost
mutation receipt is `office.outcome_unknown` and must never be automatically replayed.

An explicit `output_path` chooses a new file under File policy instead of an artifact. Its
parent must already exist and its extension must match the format. Existing output files,
including the input, return `office.output_conflict`. Default filenames are sanitized and
receive a unique prefix.

## Word behavior

`word_read` projects body paragraphs with indexes, refs, style, heading level and explicit
page-break markers; table counts and optional bounded headers/footers are available.
`word_tables` returns dimensions and an 8-by-8 preview with 256 characters per cell.
Ordinary paragraphs and slide text are limited to 4096 characters in projections; text is
marked when truncated. No rendered page numbers are invented.

To replace text, first call `word_find` with exact `text`. It returns individual occurrence
refs, including repeated matches. Pass one `occurrence_ref`, its `old_text`, the replacement
`text` and `expected_revision` to `word_replace`. Replacing text inside one ordinary run
preserves that run's formatting. Cross-run replacements and paragraphs containing fields,
hyperlinks, comment anchors or revision markup are rejected rather than flattened.

Insertion is before an exact body paragraph. Append and table creation add at the end.
Table cell replacement explicitly resets that cell's paragraph/run content and reports the
formatting behavior. Writes are direct edits, not tracked changes. Nested table editing,
headers/footers editing, footnotes, text boxes and complete rendered layout are not exposed.

## Excel behavior

Ranges require an exact sheet name and explicit finite A1 notation, up to 4096 cells and
256 columns. Read cells include address, literal value, formula separately, cached value,
number format and merged status; style summaries are optional. Hidden sheets, defined names,
table and chart metadata are inspectable. Workbook used range is structural and can include
formatting-only cells.

`excel_write_range` writes literal data, including strings starting with `=` or `#`. Formulas
must use `excel_set_formula`. Formula values are never executed or calculated by SMTO.
Read formula cells use `cached` when a stored result exists, otherwise `unknown`; cached
values can be stale. Mutations may remove cached values and report
`calculation_state=external_recalc_required`, `calculated=false`, `recalc_requested=true`.
The latter asks a separately opened spreadsheet application to recalculate later.

New formulas with external workbook syntax, DDE, URI/UNC references or network-capable
functions are rejected. This intentionally conservative rule also rejects bracketed
structured references; they may be written as literals. Existing formulas and relationships
are data and are not fetched. There is no Excel/LibreOffice calculation process.

Sheet rename/delete do not rewrite formulas, chart references or named ranges; receipts warn
about that limitation. At least one visible sheet must remain. Writes intersecting merged
non-anchor cells are rejected. Tables require unique text headers and must not overlap another
table. Charts support bar/line series from bounded ranges. Formatting supports number format
and bold. Signed packages, Excel embedded objects and backend warnings about unsupported
features block mutation because faithful preservation cannot be established.

## PowerPoint behavior and conversion

Slides expose titles, notes, layout names and refs. Slide readers expose top-level shapes
with IDs, EMU geometry, text, table/chart summaries and media relationship metadata. They do
not render pixels or fetch linked images. Reordering requires every existing slide ref exactly
once. Text replacement resets the selected shape's paragraphs/runs and reports that behavior.
Speaker notes can be replaced. PNG/JPEG image inputs are target-local and limited to 8 MiB
and 16 million pixels. Image geometry uses EMU.

Animations, transitions, themes, masters, template cloning, grouped shape edits and
pixel-perfect rendering are not exposed. PDF/format conversion is unavailable in this release.
`capabilities` reports why; even an installed LibreOffice does not enable conversion because
there is no implemented backend with enforced macro and external-network isolation. Structural
operations do not require LibreOffice.

## Resource and execution boundaries

Every package is limited to 32 MiB compressed, 64 MiB inflated, 16 MiB per part, 2048 parts,
a 200:1 compression ratio, 250000 XML elements and depth 128. Duplicate/unsafe ZIP names,
encryption, DTDs and entities are rejected before any format backend loads the package.
Content-type-declared XML is checked even when its filename lacks an XML extension.
Input/output envelopes are limited to 2 MiB. Smaller projections may be needed for large text
ranges even when the cell count is valid.

Parsing and saving run in a disposable child process, with a 45-second parent deadline and
cancellation. POSIX adds 1 GiB address-space and 40 CPU-second fuses; Windows uses the package
bounds and killable wall-time boundary. Only the parent publishes output after the child exits.
The Gateway admits at most four Office calls concurrently and fences duplicate/cancelled
execution IDs for five minutes in a bounded identity-only cache.

Errors use catalogued `office.*` identities with exact remediation, including backend/file
absence, invalid OOXML, resource limits, stale documents, missing objects, invalid ranges,
macro preservation, external formula blocking, unsupported preservation, output conflicts,
cancellation, artifact failures and unknown outcomes. Diagnostics do not echo document content
or backend exception text.

Implementation: `src/gateway_core/office/` owns deterministic operations;
`src/agent_runtime/skills/office/` owns discovery and authenticated transport bindings.
Tests: `tests/test_office.py` and `tests/test_office_integration.py` generate their own OOXML
fixtures, including macros, cached formulas, media and malformed packages.
