---
id: gateway-platforms
title: Gateway architecture and management
kind: architecture
tags: [architecture, current, gateway-platforms]
order: 24
---
# Gateway architecture and management

The controller reasons and authorizes; the selected Gateway executes against its host.
`gateway_core` owns shared execution, file/HTTP contracts, jobs, terminals, TLS and
controller authentication. Linux (`gateway_agent`), macOS (`gateway_macos`) and Windows
(`gateway_windows`) supply platform configuration and supported lifecycle scripts.

The platform `app.py` facades and available model/executor re-exports are supported
entry/import surfaces, even without inbound production imports. Startup scripts
invoke `python -m gateway_core.serve` with the platform app string. Shared
`gateway_core/models.py` owns HTTP and execution event schemas; its serializers
omit absent optional observations while preserving explicit false/zero facts.
Internal workers use the [loopback IPC protocol](../../../../docs/gateway-ipc-protocol.md),
separate from authenticated public HTTPS and its optional jobs event stream.
Linux fixtures can check shared contracts but cannot certify native macOS/Windows
socket, ACL or process-tree behavior.

Gateway Management is a controller UI/API for profiles, selected targets and lifecycle.
Profiles are not proof of remote health. Capability snapshots and authenticated refresh
make support explicit; execution failures remain authoritative when a host becomes
unavailable or a dependency is missing. Connection/session/job identity belongs to its
owning service, not to a browser label.

Cross-run historical recovery uses the same Gateway jobs authority for foreground and
background execution. POSIX process identity and surviving group members retain live claims;
unobservable Windows descendant ownership stays conservative and cannot offer a baseline
override. The separate advanced unobservable-owner decision, when unsafe policy is Ask,
requires explicit candidate-bound risk confirmation; it never establishes process death. Resource/classifier metadata upgrades lazily in the existing jobs database.

The backend accepts a versioned `gateway_selection` containing 1–16 unique registry
IDs and one explicit primary. The legacy `gateway_id` remains that primary.
Structured scope bypasses nickname inference, survives durable task/schedule
dispatch, and is immutable for the run. Native recovery resolves those same IDs
again and checks primary and sibling identity pins. Offline targets remain selected;
the existing Activity admission reports availability without substituting a target.
The Target menu and `@gateway` palette can select up to 16 Gateways. The first
selected target is primary; **Make primary** changes it, and removing it promotes
the first remaining selection. The composer shows `Multiple gateways · N` with
removable name chips; an empty selection blocks sending and prompt scheduling.
Gateway mentions retain display names in the prompt while structured IDs define
scope. Phone Agent options offers the same selection and primary controls.

Browser drafts restore selection per conversation. Offline targets remain selected;
deleted or disabled targets require correction before a new submission. A prompt
schedule captures the selected IDs and primary when its editor opens. Steering
uses the run's original scope and locks selection; future composer choices do not
retarget accepted or queued work. Schedule retries keep the original task scope; edits
change future runs. Gateway management protects every live sibling reference.

In multi-Gateway runs, `shell.command`, `python.run`, `file.*` and `desktop.*` accept `target`
with a selected ID. Omit it to use the primary. Each invocation checks the selected
host's capabilities and existing permissions; siblings do not inherit the primary's
CWD, terminal session or artifact environment. Effects, resources and receipts name
the actual target. `python.transform` remains local to the controller.

The built-in **Gateway** skill provides controller-side registry management:

| Tool | Purpose |
| --- | --- |
| `gateway.list` | Search registrations by label, ID, host or node, including disabled and unselected Gateways; paginate with `next_offset`. |
| `gateway.get` | Read configuration, observed health and current management restrictions for an exact ID. |
| `gateway.create` | Add an inbound connection using label, host and port; HTTPS and enabled are defaults. A health check follows registration. |
| `gateway.update` | Change only supplied fields: label, scheme, host, port, node, terminal working directory or enabled state. |
| `gateway.delete` | Remove a user-created inbound registration. This does not uninstall or stop the remote process. |
| `gateway.health` | Probe the saved endpoint and refresh health, capabilities and configured TLS trust. |

Requests such as “add a Gateway named Lab at lab.example:8787,” “update Lab to use
port 9443,” and “delete Lab” use these tools. The agent first resolves the exact
registration; ambiguous names require clarification. Mutations and health probes
follow the normal permission policy. Settings and the skill share the same service
and recheck live dependencies at mutation time, including RAM transaction fencing.
An offline endpoint can be registered successfully; the returned status is separate
from registration success. After an endpoint update, use `gateway.health` to verify it.

Connection changes, disabling and deletion remain blocked while tasks, resumable
runs, schedules or monitors reference the Gateway, including the requesting run.
Clear or retarget that work and manage the registration from another Gateway.
Labels remain editable. Startup-configured registrations cannot be deleted here;
outbound registrations remain read-only. Management can inspect registrations
outside the captured selection, but never expands or retargets that selection.
Private transport state and raw capability snapshots are excluded from tool output.

`gateway.scope` inspects the captured
primary and selected Gateways with safe labels, status, platform and capability tags.
This scope tool works while hosts are offline and cannot discover additional hosts
or expose connection secrets. The skill starts enabled in new product-default capability policies;
existing explicit selections remain authoritative. Parallel and dependency Activities
use the captured IDs, preserve per-Gateway sequencing and report each target's outcome.
Independent writes overlap only with proven resource isolation and the user's disjoint
mutation policy; unavailable targets are never substituted.

`gateway.copy` copies one regular file between selected Gateways through the
controller, including inbound/outbound pairs and different target operating systems.
Both Gateways must advertise `file_transfer`. Source read and destination write
permissions apply before streaming. The default is no overwrite, SHA-256 verification
and mtime preservation. Transfers use binary chunks up to 1 MiB and an atomic
destination stage. Older Gateways use compatible base64 chunks, with a 256 KiB
limit for versions that do not advertise larger chunks;
no file bytes enter model context. The controller's artifact file-size limit and each
Gateway's `GATEWAY_TRANSFER_MAX_FILE_BYTES` limit apply (64 MiB defaults). Use
`file.copy` for copies on one Gateway. A lost commit receipt requires reconciliation
before retrying. On owned resume, MG-6 rechecks authority and asks the destination to
verify its original staging identity, size and a fresh whole-file hash. Verified recovery
produces a completion receipt without retransferring bytes. Precommit interruption aborts
the stage safely; a later authorized retry starts from zero. Missing or conflicting
evidence remains unknown and cannot authorize blind replay.

Transfer phase metadata shares the native invocation receipt and Gateway job database;
file bytes never enter either store. Cleanup checks at most 32 registered stages per
pass after five idle minutes. It checks exact names, filesystem ownership and identity
without recursively scanning user files. Unregistered or replaced files are left alone.
Metadata retention is bounded to 256 records per node and up to 24 hours after cleanup;
old unverifiable outcomes remain unknown. Directory/tree copy and offset resume are
optional extensions that are not implemented: regular files and binary assets are the
supported operands, with links and special files rejected.

Existing Activity rows show the selected host. File-copy progress shows source →
destination and acknowledged-byte percentage, throttled to once a second plus terminal
progress. Saved trace replay preserves target attribution and partial failures. This
mechanical work adds no model calls or separate Activity cards.

Monitors remain single-Gateway because each owns one terminal. Their model-led trigger
actions inherit that scope; a multi-Gateway selection is rejected explicitly. Use
separate monitors for separate hosts.
Saved recipe invocations resolve selected Gateway IDs through the same registry before
launch; their native run retains the selection and ignores browser transport overrides.

Each remote host must update its own checkout and run its platform installer. Installing
the controller does not update a remote Gateway environment. Root installation normally
updates the applicable local Gateway environment using the shared dependency contract;
`AOR_SKIP_GATEWAY_SETUP=1` opts out. Existing services require restart after installation.

Default controller Gateway URL uses port 8787. Start Gateways separately from the main
API/manual/console launcher. Pairing reset preserves TLS identity and must use the same
account/state directory as the Gateway. See the [installation page](../02-install-startup.md)
and [macOS guide](../../../gateway_macos/README.md) for supported commands and platform
requirements. Never copy tokens, private keys or parameter values into diagnostics.

Correlated blocker cancellation accepts a job identity, not a caller-supplied PID.
Active detached workers retain their cancellation watcher. Foreground executions
use the registered executor; POSIX orphans are signalled only after creation-time,
process-group and session verification. Windows orphan descendant termination is
not inferred from a dead parent and remains unobservable when no active executor
can establish control. No live production restart is required to clear stale rows
once the upgraded Gateway is installed; source/package deployment itself still
requires the supported installation and coordinated process restart.

Desktop publishes independent process, application and window capability tags from live native
backend probes. See [Desktop control](36-desktop.md) for platform permissions and effect truth.
