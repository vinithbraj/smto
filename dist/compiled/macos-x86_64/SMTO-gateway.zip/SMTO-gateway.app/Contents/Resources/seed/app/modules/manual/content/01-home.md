---
id: manual-home
title: smTO Manual
kind: manual
tags: [manual, gateway]
order: 17
---
# smTO Manual

smTO uses the model to interpret requests and choose tools, with durable execution and actual result receipts.

Start with Architecture overview, then Agent and request lifecycle. Developers should read Tool and Skill contracts, Tool discovery, Exact results and JSON Pointer, and How to add a Skill. Source map gives exact code entry points.

Use Agent for tool execution, Conversation for conversation, and Advisory for advice with execution disabled. Review the selected gateway and Full Access mode before submitting work. The Agent UI uses the normal model-led request entry.

The Historical group contains prior implementation records. Current guidance is in Product Manual and Architecture Guide.

For virtual machines and containers, see [Using Proxmox VE](24-proxmox.md).
Proxmox is optional and disabled by default; the guide covers enabling it,
adding a server parameter and making requests through the selected Gateway.

Use [Model Configuration](25-model-configuration.md) to choose Provider Defaults,
smTO Recommended or Custom generation settings. The guide explains exact
parameter values, context reservations, saved tasks and provider compatibility.

Use [Inference management](45-inference.md) to install, build, configure and launch
managed model instances on Linux, connect them to the agent, and inspect caching
and logs. The guide explains source installation and the two compiled variants.
