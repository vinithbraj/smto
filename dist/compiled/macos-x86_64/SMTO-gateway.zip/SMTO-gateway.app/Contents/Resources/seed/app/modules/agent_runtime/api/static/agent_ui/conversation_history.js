/* Presentation only: cancellable keyset pages, cooperative rendering and bounded DOM. */
(() => {
  "use strict";
  const limits = Object.freeze({initialTurns: 12, pageTurns: 16, mountedPages: 3, cachedPages: 6,
    railPage: 250, railRow: 82, railSearchRow: 114, railOverscan: 8, railMaxRows: 48,
    detailConcurrency: 1, renderBudgetMs: 8});
  const started = performance.now(), metrics = {lazy_detail_request_count: 0};
  const mark = name => { if (!(name in metrics)) metrics[name] = performance.now() - started; };
  const measure = (name, value) => { metrics[name] = value; };
  if (new URLSearchParams(location.search).has("ui_performance") && window.PerformanceObserver) {
    metrics.long_tasks = [];
    try { new PerformanceObserver(list => {
      for (const entry of list.getEntries()) metrics.long_tasks.push({start: entry.startTime, duration: entry.duration});
      if (metrics.long_tasks.length > 200) metrics.long_tasks.splice(0, metrics.long_tasks.length - 200);
    }).observe({type: "longtask", buffered: true}); } catch (_) { /* Optional browser instrumentation. */ }
  }
  function yieldToUi() {
    if (globalThis.scheduler?.postTask) return scheduler.postTask(() => {}, {priority: "background"});
    if (window.requestIdleCallback) return new Promise(resolve => requestIdleCallback(resolve, {timeout: 50}));
    return new Promise(resolve => {
      const timer = setTimeout(resolve, 50);
      if (window.requestAnimationFrame) requestAnimationFrame(() => { clearTimeout(timer); resolve(); });
      else { clearTimeout(timer); setTimeout(resolve, 0); }
    });
  }
  function skeleton(label = "Loading conversation…") {
    const root = document.createElement("div"); root.className = "history-skeleton";
    root.setAttribute("role", "status"); root.setAttribute("aria-label", label);
    const geometry = document.createElement("div"); geometry.setAttribute("aria-hidden", "true");
    geometry.innerHTML = '<i class="skeleton-prompt"></i><i class="skeleton-short"></i><i></i><i></i><i class="skeleton-medium"></i><i class="skeleton-activity"></i>';
    root.append(geometry); return root;
  }
  function create({viewport, content, apiJson, renderTurn, releaseTurn, protectedTurn,
    onLatest = () => {}, onChange = () => {}, onPage = () => {}, isDeleted = () => false}) {
    let session = null, serial = 0;
    const valid = s => session === s && !s.controller.signal.aborted && s.isCurrent();
    const captureAnchor = node => node?.isConnected && !window.SMTOTaskDisclosure?.isFiltered(node) && node.getClientRects().length
      ? {node, top: node.getBoundingClientRect().top, scroll: viewport.scrollTop} : null;
    function anchor() {
      const view = viewport.getBoundingClientRect(), nodes = [...new Set([...content.querySelectorAll(".turn")]
        .filter(node => !window.SMTOTaskDisclosure?.isFiltered(node))
        .map(node => window.SMTOTaskDisclosure?.anchorFor(node) || node))];
      const node = nodes.find(item => { const box = item.getBoundingClientRect(); return box.top >= view.top && box.top < view.bottom; })
        || nodes.find(item => item.getBoundingClientRect().bottom > view.top);
      return captureAnchor(node);
    }
    function restore(saved) {
      if (saved?.node.isConnected && !window.SMTOTaskDisclosure?.isFiltered(saved.node) && saved.node.getClientRects().length) {
        // Subtract user movement from the observed geometry change. A scroll or
        // deep-link jump during an awaited render is intent, not a layout shift.
        const delta = saved.node.getBoundingClientRect().top - saved.top + viewport.scrollTop - saved.scroll;
        if (Math.abs(delta) > .5) viewport.scrollTo({top: viewport.scrollTop + delta, behavior: "instant"});
      }
    }
    function preserve(s, change) {
      const saved = s.mountAnchor || s.anchor || anchor();
      change(); restore(saved); s.anchor = captureAnchor(saved?.node) || anchor();
      if (s.mountAnchor) s.mountAnchor = s.anchor;
      s.expectedScroll = viewport.scrollTop;
    }
    function stats(s) {
      const mounted = s.pages.reduce((n, page) => n + page.turns.length, 0);
      measure("mounted_turn_count", mounted);
      measure("maximum_mounted_turn_count", Math.max(metrics.maximum_mounted_turn_count || 0, mounted));
      measure("history_cache_pages", s.pages.filter(page => page.data).length);
      onChange();
    }
    function cancel() {
      if (!session) return;
      const previous = session; session = null;
      previous.controller.abort(); previous.observer?.disconnect(); previous.resize?.disconnect();
      for (const page of previous.pages) for (const turn of page.turns) releaseTurn(turn);
      previous.root.remove();
    }
    function retrySurface(host, retry, label) {
      const status = document.createElement("p"); status.className = "history-retry"; status.setAttribute("role", "status");
      status.textContent = label;
      const button = document.createElement("button"); button.type = "button"; button.textContent = "Retry";
      button.addEventListener("click", retry); status.append(button); host.replaceChildren(status);
    }
    function distance(page) {
      const box = page.node.getBoundingClientRect(), view = viewport.getBoundingClientRect();
      return Math.max(view.top - box.bottom, box.top - view.bottom, 0);
    }
    function evict(s, incoming) {
      const mounted = s.pages.filter(page => page.mounted && page !== incoming);
      while (mounted.length >= limits.mountedPages) {
        const candidates = mounted.filter(page => !page.turns.some(protectedTurn)
          && !page.node.contains(document.activeElement));
        candidates.sort((a, b) => distance(b) - distance(a));
        const victim = candidates[0];
        if (!victim) break; // Interactive work always wins over terminal history budgets.
        preserve(s, () => {
          // A request already in flight can finish while the filter is on.
          // Retain the unfiltered spacer height if it evicts a hidden page.
          if (content.dataset.activeRunsOnly !== "true") victim.height = victim.node.getBoundingClientRect().height;
          s.resize?.unobserve(victim.node);
          for (const turn of victim.turns) releaseTurn(turn);
          victim.turns = []; victim.mounted = false;
          victim.node.replaceChildren(); victim.node.style.height = `${victim.height}px`;
          victim.node.classList.add("history-page-spacer");
          victim.node.setAttribute("aria-label", "Saved messages; scroll here to load");
        });
        mounted.splice(mounted.indexOf(victim), 1);
      }
    }
    function trimCache(s) {
      const cached = s.pages.filter(page => page.data).sort((a, b) => a.used - b.used);
      let excess = cached.length - limits.cachedPages;
      // Mounted turns own their render state; their duplicate transport payload
      // can also be dropped if interactive pages outnumber the cache budget.
      for (const page of cached) if (excess > 0) { page.data = null; excess--; }
    }
    async function fetchPage(s, params) {
      const query = new URLSearchParams(params);
      if (s.excludeRequestId) query.set("exclude_request_id", s.excludeRequestId);
      const start = performance.now();
      const data = await apiJson(`/api/agent/chats/${encodeURIComponent(s.id)}/turns?${query}`, {signal: s.controller.signal});
      if (valid(s)) onPage(data, s.id);
      data.turns = data.turns.filter(turn => !isDeleted(turn, s.id));
      measure("history_page_fetch_ms", performance.now() - start);
      return data;
    }
    async function mount(s, page, {initial = false} = {}) {
      if (!valid(s) || page.mounted) return;
      if (!page.data) page.data = await fetchPage(s, {through: page.cursor, limit: page.count});
      if (!valid(s)) return;
      evict(s, page);
      page.mounted = true; page.used = ++serial;
      trimCache(s);
      s.mountAnchor = anchor();
      const start = performance.now();
      // Keep measured height while replacing a spacer. Real articles render newest first.
      page.node.replaceChildren(); page.node.classList.remove("history-page-spacer");
      page.node.removeAttribute("aria-label"); page.node.style.minHeight = page.node.style.height;
      page.node.style.height = "";
      s.resize?.observe(page.node);
      for (const saved of [...page.data.turns].reverse()) {
        await yieldToUi();
        if (!valid(s)) return;
        if (isDeleted(saved, s.id)) continue;
        const savedAnchor = s.mountAnchor || anchor();
        const turn = await renderTurn(saved, page.node, s.controller.signal, () => valid(s));
        if (!valid(s)) { if (turn) releaseTurn(turn); return; }
        if (isDeleted(saved, s.id)) { if (turn) releaseTurn(turn); continue; }
        if (turn) {
          page.turns.unshift(turn);
          page.node.prepend(turn.activityGroup || turn.article);
          if (initial && !s.latestShown) {
            s.latestShown = true; onLatest(turn, s.sourceRequestId);
            requestAnimationFrame(() => { if (valid(s)) mark("boot_to_latest_turn_painted_ms"); });
          }
        }
        restore(savedAnchor);
        s.anchor = s.mountAnchor = captureAnchor(savedAnchor?.node) || anchor();
        s.expectedScroll = viewport.scrollTop; stats(s);
      }
      preserve(s, () => { page.node.style.minHeight = ""; });
      if (content.dataset.activeRunsOnly !== "true") page.height = page.node.getBoundingClientRect().height;
      s.mountAnchor = null; trimCache(s); stats(s);
      measure("history_page_render_ms", performance.now() - start);
    }
    function addPage(s, data, direction) {
      const node = document.createElement("section"); node.className = "history-page";
      const page = {node, data, cursor: data.page_cursor, count: data.turns.length,
        members: data.turns.map(turn => ({request_id: turn.request_id, task_id: turn.task_id})),
        height: 0, turns: [], mounted: false, used: ++serial};
      preserve(s, () => {
        if (direction === "older") { s.pages.unshift(page); s.top.after(node); }
        else { s.pages.push(page); s.bottom.before(node); }
      });
      s.observer?.observe(node); return page;
    }
    function controls(s) {
      for (const direction of ["older", "newer"]) {
        const control = direction === "older" ? s.top : s.bottom;
        control.hidden = !s[direction]; control.replaceChildren();
        if (s[direction]) {
          const button = document.createElement("button"); button.type = "button";
          button.textContent = `Load ${direction} messages`;
          button.addEventListener("click", () => { void load(s, direction, true); });
          control.append(button);
        }
      }
    }
    async function load(s, direction = "initial", feedback = false) {
    const busyFeedback = feedback ? window.SMTOBusy?.begin({host: direction === "newer" ? s.bottom : s.top, label: "Loading conversation messages…"}) : null;
    try {
      if (!valid(s) || (direction !== "initial" && !s[direction])) return;
      if (direction !== "initial" && content.dataset.activeRunsOnly === "true") return;
      if (s.busy) { if (direction !== "initial" && direction !== s.loadingDirection) s.pendingDirection = direction; return; }
      s.busy = true; s.loadingDirection = direction; s.failedDirections.delete(direction);
      const host = direction === "newer" ? s.bottom : s.top;
      host.hidden = false;
      preserve(s, () => host.replaceChildren(skeleton(direction === "initial" ? "Loading latest messages…" : `Loading ${direction} messages…`)));
      try {
        const params = direction === "initial" ? {limit: limits.initialTurns,
          ...(s.sourceRequestId ? {around_request_id: s.sourceRequestId} : {})}
          : {limit: limits.pageTurns, [direction === "older" ? "before" : "after"]: s[direction]};
        const data = await fetchPage(s, params);
        if (!valid(s)) return;
        const page = addPage(s, data, direction === "newer" ? "newer" : "older");
        if (direction !== "newer") s.older = data.older_cursor;
        if (direction !== "older") s.newer = data.newer_cursor;
        await mount(s, page, {initial: direction === "initial"});
        if (!valid(s)) return;
        preserve(s, () => controls(s));
        if (direction === "initial") {
          s.ready = true;
          onLatest(null, s.sourceRequestId, {followLatest: !s.userScrolling});
        }
      } catch (error) {
        if (!valid(s) || error.name === "AbortError") return;
        s.failedDirections.add(direction);
        preserve(s, () => retrySurface(host, () => { void load(s, direction, true); },
          `Could not load ${direction === "initial" ? "latest" : direction} messages. `));
      } finally {
        if (valid(s)) {
          s.busy = false; s.loadingDirection = null; s.anchor = anchor();
          if (s.pendingDirection) { const pending = s.pendingDirection; s.pendingDirection = null; void load(s, pending); }
          resumeReconcile(s);
        }
      }

    } finally { busyFeedback?.finish(); }
  }
    function resumeReconcile(s) {
      if (!s.reconcilePending) return;
      s.reconcilePending = false;
      requestAnimationFrame(() => { void reconcile(s); });
    }
    async function reconcile(s) {
      // Find navigates only mounted text; explicit Load older remains available.
      if (!valid(s) || !s.ready || window.SMTOUiFind?.isOpen() || content.dataset.activeRunsOnly === "true") return;
      // Collapsing or scrolling can expose a spacer while another page mounts.
      // Replay that observation after the mount instead of waiting for a second scroll.
      if (s.busy) { s.reconcilePending = true; return; }
      const spacer = s.pages.filter(page => !page.mounted && !page.failed && distance(page) < viewport.clientHeight)
        .sort((a, b) => distance(a) - distance(b))[0];
      if (spacer) {
        s.busy = true;
        try { await mount(s, spacer); }
        catch (error) {
          if (valid(s) && error.name !== "AbortError") {
            spacer.failed = true;
            retrySurface(spacer.node, () => { spacer.failed = false; void reconcile(s); }, "Could not load messages. ");
          }
        } finally {
          if (valid(s)) {
            s.busy = false;
            if (s.pendingDirection) { const pending = s.pendingDirection; s.pendingDirection = null; void load(s, pending); }
            resumeReconcile(s);
          }
        }
        return;
      }
      const view = viewport.getBoundingClientRect();
      if (s.direction === "older" && !s.failedDirections.has("older") && s.older && s.top.getBoundingClientRect().bottom > view.top - viewport.clientHeight * 1.5) void load(s, "older");
      else if (s.direction === "newer" && !s.failedDirections.has("newer") && s.newer && s.bottom.getBoundingClientRect().top < view.bottom + viewport.clientHeight) void load(s, "newer");
    }
    function adopt(parentTurn, turns) {
      if (!session || !parentTurn || !Array.isArray(turns) || !turns.length) return false;
      const page = session.pages.find(candidate => candidate.mounted && candidate.turns.includes(parentTurn));
      if (!page) return false;
      let insertAt = page.turns.indexOf(parentTurn) + 1, changed = false;
      for (const turn of turns) {
        if (!turn || page.turns.includes(turn)) continue;
        page.turns.splice(insertAt++, 0, turn);
        changed = true;
      }
      if (changed) stats(session);
      return changed;
    }

    function remove(predicate) {
      const s = session;
      if (!s) return;
      const viewTop = viewport.getBoundingClientRect().top;
      const survivor = [...content.querySelectorAll(".turn")].find(node => !predicate(node.dataset)
        && node.getBoundingClientRect().bottom > viewTop);
      if (survivor) {
        s.anchor = captureAnchor(survivor);
        if (s.mountAnchor) s.mountAnchor = s.anchor;
      }
      preserve(s, () => {
        for (const page of s.pages) {
          page.members = page.members.filter(turn => !predicate(turn));
          page.count = page.members.length;
          if (page.data) page.data.turns = page.data.turns.filter(turn => !predicate(turn));
          page.turns = page.turns.filter(turn => {
            if (!predicate(turn)) return true;
            releaseTurn(turn); return false;
          });
          if (!page.count && !page.turns.length) {
            page.mounted = true; page.height = 0;
            page.node.replaceChildren(); page.node.style.height = "0px"; page.node.style.minHeight = "";
          }
        }
      });
      stats(s);
    }

    function begin(id, {excludeRequestId = "", sourceRequestId = "", isCurrent = () => true} = {}) {
      cancel();
      const controller = new AbortController(), root = document.createElement("div"); root.className = "conversation-history";
      const top = document.createElement("div"), bottom = document.createElement("div");
      top.className = bottom.className = "history-sentinel"; bottom.hidden = true;
      top.append(skeleton("Loading latest messages…")); root.append(top, bottom); content.prepend(root);
      const s = session = {id, controller, root, top, bottom, isCurrent, excludeRequestId, sourceRequestId,
        pages: [], failedDirections: new Set(), busy: false, ready: false, direction: null, latestShown: false, anchor: null};
      document.addEventListener("ui-find-state", () => {
        s.direction = null; s.userScrolling = false; s.mountAnchor = null;
        s.anchor = anchor(); s.expectedScroll = viewport.scrollTop;
      }, {signal: controller.signal});
      viewport.addEventListener("task-disclosure-change", () => {
        s.direction = null; s.userScrolling = true; s.anchor = anchor(); s.mountAnchor = null;
        s.expectedScroll = viewport.scrollTop;
      }, {signal: controller.signal});
      if (window.IntersectionObserver) {
        s.observer = new IntersectionObserver(() => { void reconcile(s); },
          {root: viewport, rootMargin: `${Math.round((viewport.clientHeight || 600) * 1.5)}px 0px`});
        s.observer.observe(top); s.observer.observe(bottom);
      }
      if (window.ResizeObserver) s.resize = new ResizeObserver(() => {
        if (!valid(s)) return;
        const saved = s.mountAnchor || s.anchor;
        if (!window.SMTOUiFind?.isOpen()) restore(saved);
        s.anchor = captureAnchor(saved?.node) || anchor();
        if (s.mountAnchor) s.mountAnchor = s.anchor;
        s.expectedScroll = viewport.scrollTop;
        if (content.dataset.activeRunsOnly !== "true")
          for (const page of s.pages) if (page.mounted) page.height = page.node.getBoundingClientRect().height;
      });
      let scroll = viewport.scrollTop, frame = 0;
      viewport.addEventListener("scroll", () => {
        const next = viewport.scrollTop;
        const intentional = Math.abs(next - (s.expectedScroll ?? -100)) > 2;
        const moved = s.ready && s.userScrolling && Math.abs(next - scroll) > 2 && intentional;
        if (moved) { s.direction = next < scroll ? "older" : "newer"; if (s.mountAnchor) s.mountAnchor = anchor(); }
        scroll = next;
        // Our compensation also emits scroll. Keep its saved geometry until
        // ResizeObserver catches late content; recapturing here would accept
        // a layout shift that happened between the write and this event.
        if (!s.mountAnchor && intentional) s.anchor = anchor();
        if (!frame) frame = requestAnimationFrame(() => { frame = 0; void reconcile(s); });
      }, {signal: controller.signal, passive: true});
      viewport.addEventListener("wheel", event => {
        s.userScrolling = true;
        s.direction = event.deltaY < 0 ? "older" : "newer"; void reconcile(s);
      }, {signal: controller.signal, passive: true});
      viewport.addEventListener("pointerdown", () => { s.userScrolling = true; }, {signal: controller.signal, passive: true});
      viewport.addEventListener("touchstart", () => { s.userScrolling = true; }, {signal: controller.signal, passive: true});
      viewport.addEventListener("keydown", event => {
        if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End"].includes(event.key)) s.userScrolling = true;
      }, {signal: controller.signal});
      return {signal: controller.signal, load: () => load(s), valid: () => valid(s)};
    }
    return {begin, cancel, adopt, remove};
  }
  window.SMTOConversationHistory = {create, limits, yieldToUi, skeleton, mark, measure,
    metrics: () => structuredClone(metrics)};
})();
