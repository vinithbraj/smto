---
id: branding-compatibility
title: Branding and compatibility
kind: architecture
tags: [architecture, current, branding-compatibility]
order: 30
---
# Branding and compatibility

The public product identity is smTO, Small Model Task Orchestration. `branding.json`
provides presentation metadata. `BrandingLoader` considers an explicit loader path,
`SMTO_BRANDING_PATH`, legacy `JARVMKS_BRANDING_PATH`, application configuration and the
packaged fallback. It retains the last-known-good identity when a selected replacement
is invalid. Branding is presentation, not policy or execution authority.

Distribution/CLI names (`aor-runtime`, `aor`), environment names (`AOR_*`), persisted keys,
Legacy browser namespaces and API compatibility fields are retained interfaces.
A documentation or branding change is not permission to rename them. Historical report
titles keep the names used when their measurements were recorded.

Package metadata, runtime API, Gateway core and manual service have distinct version
domains. A code-freeze label is not a replacement value for every service version.
See the [configuration catalog](../../../../docs/engineering/configuration-catalog.md)
for data owners, override precedence and consumer boundaries.
