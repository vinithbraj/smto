import { $, node, button } from "./api.js?v=20261018-loading";

let current = null, restore = null, closing = null, resolveClose = null, onClosed = null;
let moved = [], closeTimer = null;
const reduceMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;

// Move live controls, retaining their original place and controller identity.
export function mountControls(host, ...controls) {
  for (const control of controls.filter(Boolean)) {
    const anchor = document.createComment("sheet control");
    control.before(anchor);
    moved.push({control, anchor});
    host.append(control);
  }
}
function retainControls() {
  for (const {control, anchor} of moved.splice(0).reverse()) {
    if (anchor.isConnected) anchor.replaceWith(control);
    else control.remove();
  }
  // Older lazy panels also move these persistent controls directly.
  for (const id of ["task-options", "task-control-actions", "conversation-navigator"]) {
    const control = $("#" + id);
    if (current?.contains(control)) $("#sheet-controls")?.append(control);
  }
}
function dispose() {
  clearTimeout(closeTimer); closeTimer = null;
  if (!current) return;
  const returnToTrigger = current.contains(document.activeElement) || document.activeElement === document.body;
  retainControls();
  current.remove(); current = null;
  onClosed?.(); onClosed = null;
  $("#mobile-app").inert = false;
  restore?.removeAttribute("aria-expanded");
  const target = restore?.isConnected && !restore.closest("[hidden]") ? restore : $("#add");
  if (returnToTrigger) target?.focus({preventScroll: true});
  restore = null;
  resolveClose?.(); resolveClose = null; closing = null;
}
function animateClose() {
  if (!current || closeTimer) return;
  current.classList.add("closing");
  $("#mobile-app").inert = false;
  current.inert = true;
  if (reduceMotion()) dispose();
  else closeTimer = setTimeout(dispose, 220);
}
window.addEventListener("popstate", animateClose);
document.addEventListener("keydown", event => {
  // A pending action can disable its focused button, moving focus to body.
  if (current && event.key === "Escape" && !event.defaultPrevented && !document.querySelector("dialog[open]")) {
    event.preventDefault();
    void closeSheet();
  }
});
export function closeSheet() {
  if (!current) return Promise.resolve();
  if (closing) return closing;
  const result = closing = new Promise(resolve => { resolveClose = resolve; });
  if (history.state?.mobileOverlay) history.back();
  else animateClose();
  return result;
}
export function openSheet(title, {drawer = false, back = null, onClose = null, returnFocus = null} = {}) {
  // Opening a new view while the preceding one is closing must finish its cleanup.
  if (closeTimer) dispose();
  if (!current) {
    const focused = document.activeElement;
    restore = returnFocus || (focused?.matches("button,a") ? focused : $("#add"));
    focused?.blur();
    restore?.setAttribute("aria-expanded", "true");
    history.pushState({...history.state, mobileOverlay: true}, "", location.href);
  } else { retainControls(); current.remove(); onClosed?.(); }
  onClosed = onClose;
  $("#mobile-app").inert = true;
  const scrim = node("div", null, "scrim"),
    panel = node("section", null, `sheet${drawer ? " drawer" : ""}`);
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-modal", "true");
  panel.setAttribute("aria-label", title);
  panel.tabIndex = -1;
  if (!drawer) {
    const handle = node("div", null, "sheet-handle");
    handle.setAttribute("aria-hidden", "true");
    let start = null, distance = 0;
    handle.addEventListener("pointerdown", event => {
      if (event.button !== 0) return;
      start = event.clientY; distance = 0;
      handle.setPointerCapture(event.pointerId);
      panel.classList.add("dragging");
    });
    handle.addEventListener("pointermove", event => {
      if (start == null) return;
      distance = Math.max(0, event.clientY - start);
      panel.style.setProperty("--sheet-drag", `${distance}px`);
    });
    const release = event => {
      if (start == null) return;
      start = null;
      if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
      panel.classList.remove("dragging");
      if (event.type !== "pointercancel" && distance >= 64) void closeSheet();
      else panel.style.removeProperty("--sheet-drag");
    };
    handle.addEventListener("pointerup", release);
    handle.addEventListener("pointercancel", release);
    panel.append(handle);
  }
  const head = node("div", null, "sheet-head");
  if (back) { const previous = button("‹", back, "icon"); previous.setAttribute("aria-label", "Back"); head.append(previous); }
  head.append(node("h2", title));
  const close = button("", closeSheet, "icon");
  close.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg>';
  close.setAttribute("aria-label", "Close " + title);
  head.append(close);
  const body = node("div", null, "sheet-body");
  panel.append(head, body); scrim.append(panel);
  $("#overlays").append(scrim); current = scrim;
  scrim.addEventListener("click", event => { if (event.target === scrim) void closeSheet(); });
  panel.addEventListener("keydown", event => {
    if (event.key !== "Tab") return;
    const focusables = [...panel.querySelectorAll(
      'button:not(:disabled),a[href],input:not(:disabled),textarea:not(:disabled),select:not(:disabled),[tabindex="0"]',
    )].filter(e => !e.hidden && e.getClientRects().length);
    const first = focusables[0], last = focusables.at(-1);
    if (!first) { event.preventDefault(); panel.focus(); }
    else if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) {
      event.preventDefault(); last.focus();
    } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === panel)) {
      event.preventDefault(); first.focus();
    }
  });
  panel.focus({preventScroll: true});
  return body;
}
export function choose(title, choices, selected, onSelect, back, {sheet = openSheet} = {}) {
  const body = sheet(title, { back });
  for (const item of choices) {
    const option = button(
      item.label,
      async () => {

        await onSelect(item.value);
        if (body.isConnected) back();
},
      "choice",
    );
    option.setAttribute("aria-pressed", String(item.value === selected));
    if (item.value === selected) {
      const mark = node("span", "✓"); mark.dataset.uiSymbol = "check";
      option.prepend(mark, document.createTextNode(" "));
    }
    option.disabled = Boolean(item.disabled);
    if (item.description) option.append(node("small", item.description));
    body.append(option);
  }
}
