---
id: full-access-sudo
title: Full Access and sudo
kind: architecture
tags: [architecture, gateway, authorization]
order: 11
---
# Full Access and sudo

Plan collaboration applies a non-mutating operation gate before ordinary execution
authorization. Full Access, capability grants and disabled optional checks cannot
permit known writes or opaque/background execution while the accepted task remains
in Plan. Allowed observations still pass normal authorization. Selecting implementation
creates a Default collaboration task under the existing permission/capability scopes;
it does not grant extra authority.

`ExecutionAuthorization` is the authority for an operation's policy decision and approval requirement. The canonical approval modes are `manual` and `full_access`. Full Access authorizes permitted operations within the selected target and scope; deterministic hard blocks and credential boundaries still apply.

For OS elevation, the model puts `sudo` in the `shell.command` command text, for example `sudo du -xhd1 /`. The runtime derives elevation internally, then applies the existing safety and authorization checks. There is no model-facing elevation toggle. Supply a known password through the literal `sudo_password` argument. The Gateway delivers it to sudo through stdin.

Elevation preserves the operation's execution target. A local command elevates on
the selected Gateway. For an already verified direct SSH destination, use
`ssh host 'sudo id'`: the Gateway runs an ordinary SSH client and sudo runs on the
remote host. The result and activity identify that host, its SSH account, and the
transport Gateway separately. Do not wrap SSH in Gateway-local sudo.

Remote elevation requires a verified identity from an ordinary SSH operation in
the current working context. Each elevated operation checks the current SSH
host/user/port mapping and pins the previously verified host key. Changed identity,
unsupported wrappers, PTYs, background execution, application stdin, or an older
Gateway without remote elevation support fail closed. There is no local fallback.
The tool's `cwd` remains the Gateway directory used to start SSH; a remote directory
must be part of the remote command, such as an explicit `sudo sh -c 'cd ...; ...'`.

For a whole script or pipeline that needs root, use `sudo sh -c '...'`. A mixed-elevation pipeline must be split into separate calls: the runtime never changes `sudo A | B` into a root shell running both commands. Sudo options, alternate identities, environment-changing wrappers and nested sudo remain unsupported and return guidance using the same command syntax.

Foreground execution has a persistent **Settings → Advanced → Maximum foreground runtime** ceiling, defaulting to one hour and bounded from five minutes to 24 hours. Each new operation snapshots this setting. A long-running notice offers **Keep Running** and **Terminate** while the process continues; silence keeps it running within the hard deadline. Keep Running preserves the process, privilege and credential state and makes no model call. Background jobs retain their separate lifetime policy. Timeout and user termination are distinct receipts; interrupted mutations require fresh state inspection before retry.

Privilege authentication uses literal `sudo_password` and optional `sudo_username` tool inputs. Consumer projections follow [Redaction](31-redaction.md); execution receives the original values.

Without a supplied password, the Gateway tries root/passwordless sudo. An OS authentication requirement is a truthful failure receipt. The Agent may ask for a password through ordinary input, then issue a new authorized operation. No protected credential wait is created. Sudoers denial and post-elevation command failure retain separate classifications.

For remote sudo, `sudo_password` authenticates the SSH login account on the bound
remote host. It never selects a host or grants permission. Passwords are not cached
or automatically shared between local and remote operations. Credential interaction
still follows ordinary input and a newly authorized Agent operation; it is not an
exact automatic continuation. If a remote command may have started before a
connection loss, the result preserves that uncertainty and must be reconciled
before another mutating attempt.

Passwords supplied through ordinary replies remain literal conversation/task data, subject to the normal retention and redaction settings. There is no automatic replay, alternate `sudo -u` identity, Windows UAC transport, or arbitrary interactive PAM/MFA conversation.

Literal stdout-only `echo`/`printf` instructions are `self_assertion` receipts, including completed jobs. They cannot independently establish completion. File redirection, computation and actual inspection remain usable evidence.

Gateway identity, platform, working directory and workspace restrictions come from trusted context. A tool argument or model message cannot select a different authorization identity. The UI displays the current mode and ordinary input or approval wait from the durable state.
