---
id: schedules
title: Scheduler Manager
kind: manual
tags: [manual, schedules, tasks]
order: 23
---
# Scheduler Manager

These are smTO reminders and future Agent actions. Live Google Calendar appointments,
invitations and availability use the separate [Google Calendar skill](28-google-calendar.md).
Creating or deleting an item in either domain never changes the other.

Open **Schedules** using the calendar icon in the Agent header or the Schedules entry in Directory. `/schedules` manages the same durable tasks and reminders as the native Schedule Skill. The page links back to Agent, Mission Control and Directory.

Search matches names, instructions and reminder text locally. Filter by Active, Paused, Cancelled, Completed or Failed recently, and sort by Next run, Recently updated or Name. Failed recently means at least one of the five most recently loaded runs has failed. It is a run-history filter: the schedule itself can still be Active. Deleted schedules and unscheduled todos do not appear.

Each card shows the schedule status, recurrence, timezone, server-provided next trigger and latest durable run attempt. Manual runs count in Last run. A separate Current run area identifies queued, running or waiting work. **Open task** opens the original conversation. **Open current run** or **Open latest run** opens that occurrence's execution conversation. Expand Recent runs for 30 attempts per page, result/error previews and an **Open run** link for each execution. **Older runs** opens the next page.

Every scheduled Agent execution has its own saved conversation and scheduled prompt before the Agent begins thinking. It appears in normal conversation and run history. Open it to see live activity, tool output and the normal Stop control; **View schedule** returns to its schedule. Stopping or amending one execution leaves the recurring instruction and future triggers unchanged.

Run history reflects the task's actual outcome: completed, partial, failed, cancelled or interrupted. A successful trigger alone does not mean the task completed. After a server restart, an execution that was left running is marked interrupted unless saved execution evidence proves a final outcome. If smTO detects an internal runtime mismatch, it stops the run and displays **Runtime · Blocked · server restart required**, preserving earlier results. Restart smTO with the current code before continuing that task.

## Schedule a prompt

Each genuine user prompt has its own small calendar action beside the message bubble, above that turn's Agent trace and response. Click it to open the schedule editor with that exact prompt attached. The icon stays subtly visible on desktop and becomes more prominent on hover or keyboard focus; it also stays visible on touch and narrow screens. Historical prompts work too. Application commands and internal control turns do not have this action.

The calendar control beside Send schedules the current draft without sending it or clearing it. It is unavailable while replying to an interaction, supplying credentials, approving an action, or steering a running task.

Scheduled prompts run as standalone Agent tasks. Conversation history and temporary attachments are not included. Apparent credential literals are rejected; authentication can be requested securely when the future task runs.

An active or paused schedule for the same source prompt is reused rather than duplicated, including concurrent clicks from different tabs. Editing the schedule instruction retains its original prompt linkage. The icon shows a check for active schedules or a pause mark for paused schedules. Completed, cancelled and deleted schedules do not prevent scheduling the prompt again. **Open in Schedules** opens and focuses the corresponding card; destructive lifecycle actions live there.

## Create and edit

Choose a name, instruction, Agent task or reminder, repeat pattern and IANA timezone. Supported patterns are:

| Choice | Stored representation |
| --- | --- |
| Once | `once`, local date/time in `next_run_at`, resolved by the server using `timezone` |
| Interval · every X | `interval`, exact `interval_seconds` (minutes × 60, hours × 3600, days × 86400) |
| Daily | `calendar`, daily recurrence at local `HH:MM` |
| Weekdays | `calendar`, weekly recurrence with weekdays `[0,1,2,3,4]` |
| Weekly | `calendar`, selected weekdays (Monday = 0, Sunday = 6) |
| Monthly | A day of the month, or the first/second/third/fourth/last chosen weekday |
| Yearly | A month and day, or the first/second/third/fourth/last chosen weekday in a month |

Seconds are also available for precise existing intervals. Agent intervals require at least 60 seconds; recurring reminders require at least 10 seconds. The server validates timing, timezone and daylight saving transitions. An elapsed 24-hour interval is distinct from a daily local wall time. An interval may also have an explicit first-run date and time. Without one, a new interval starts after one interval; routine interval edits retain the saved next trigger.

Calendar series use their start date to anchor **every N days, weeks, months or years**. Weeks start on Monday. The Weekdays preset means Monday–Friday every week. Choose **Never**, **On date** (inclusive), or **After N occurrences** (1–10,000). A day such as the 31st clamps to the last valid day in shorter months; yearly February 29 becomes February 28 in non-leap years. Recurring DST gaps are skipped, and fall-back times run once at the first fold. An ambiguous or nonexistent one-time local time is rejected.

Numbered series count scheduled instants, not successful executions. An occurrence skipped because an earlier run is still open consumes its place. Passing dates while paused or offline does not extend a numbered series. A finite series completes and clears its next trigger after the final due occurrence is claimed or skipped. Resuming a series with no remaining future occurrence requires changing its range.

smTO presents schedule timestamps in the current browser's local timezone. The schedule retains its authoritative IANA recurrence timezone. New schedules default to the browser zone. Cards, run history and the existing editor's next occurrence show local absolute times; a different series zone remains secondary context. Editing from another timezone does not move the series. **Daily at 9 AM** follows the series wall clock across DST; **every 24 hours** measures elapsed time.

New Agent schedules capture the server's current default Gateway routing, resolved model, default Capability Policy, Permission Policy and immutable Behavior Policy. They do not inherit an arbitrary conversation's context. Model discovery can report an unavailable endpoint before a schedule is saved; creation performs no inference or future task execution. Reminders do not require a model endpoint.

Scheduler Manager and the prompt calendar controls capture the current global Permission Policy, including custom rules. Schedules created by an Agent capture that run's effective permissions instead. Later global permission changes do not replace a schedule's saved policy. Expand Recent runs to see the saved permissions under Execution. The schedule editor does not currently edit permissions; changing its timing or instruction preserves them. To use a different global policy through the UI, create a new schedule after setting that policy, and pause the old entry to avoid duplicate triggers. Changing permissions on an individual scheduled run applies to that run, not future occurrences.

Routine edits preserve the schedule's saved execution scope, including chat context, private macros, Gateway, model and policies. Type is read-only while editing. The form sends only changed name, instruction, timing or summary settings; opening and saving an unchanged form does not rewrite the record. Public `event.context` is sanitized and is never sent back through the editor. Notification instructions update the reminder text consistently.

Scheduled Agent tasks always retain summary metadata from their accepted final answer or locally recorded outcomes. There is no summary toggle or separate recap model call. Older saved `summarize_result` values are ignored; requested output formats and notification policies still apply.

## Lifecycle

- **Pause / Resume:** Temporarily stop or restart future scheduling using the same record. Under the current domain behavior, calendar Resume resolves the next remaining calendar occurrence; Pause retains the saved occurrence; interval Pause/Resume keeps its saved due time. A past interval occurrence can become eligible shortly after Resume. A past one-shot may require editing its date before Resume. The page always displays the authoritative server value.
- **Run now:** Add an immediate durable run using the existing trigger operation. It leaves the saved status, recurrence, timezone, next normal trigger and execution scope unchanged. It is available for paused, cancelled and completed schedules. An open run prevents a duplicate launch.
- **Cancel:** Stop future triggers, clearing the next trigger while retaining the record and history. Confirmation is required. Cancelled schedules cannot normally be resumed.
- **Delete:** Remove the schedule from normal management by soft deletion. Confirmation is required. Execution conversations remain available; deleting the schedule does not delete their history. Occurrence summaries remain subject to the existing retention policy.
- **Completed:** A completed one-shot or finite calendar series has no future automatic run. It can still be run manually or deleted.

Pausing, cancelling or deleting a schedule does not cancel an already-started run.

The shared update stream refreshes schedules and run history when the server publishes changes. Search, filters, sort, expanded histories and unsaved form content remain intact; the page does not continuously poll. If scheduling is disabled, the page explains this and links to Mission Control.

## Model Configuration for scheduled execution

Scheduler Manager captures the model and resolved execution configuration at creation.
Agent-created schedules retain the creating run's saved execution scope. Changing
Mission Control's global profile or parameter values does not retune those schedules;
new schedules use the current configuration. Legacy events without a saved execution
configuration retain firing-time resolution.

Scheduled runs use the same request preparation as immediate queries to resolve
model capacity and execution settings. Automatic context detection uses the served
model's capacity; a fallback estimate never becomes a configured context limit.
Explicit context limits and output reservations follow the same rules in both paths.

Each started run pins its map, profile/version and output reservation for resume and
continuation. A pure notification still requires no model call. See
[Model Configuration](25-model-configuration.md) for provider defaults and migration.
