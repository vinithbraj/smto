---
id: historical-v54-example-workflows
title: Historical V54 - Example Workflows
kind: legacy
tags: [examples, workflows, agent-ui]
summary: Practical workflows for learning the runtime through safe, inspectable requests.
order: 11
---

> Historical reference. See the current V55 architecture guide before using this material.

# Example Workflows

These examples are meant to exercise the runtime without requiring risky changes.

## Inspect A Repository

```text
Summarize this repository structure and identify the main FastAPI entry points.
```

Expected behavior:

- source inspection;
- no file mutation;
- route and package summary;
- optional generated table or DisplayDocument.

## Produce A Local Report

```text
Create a short Markdown report about Python files changed most recently and save it as artifacts/source-report.md.
```

Expected behavior:

- approval before writing;
- command or Python action capsule;
- verification that the file exists;
- final response with path.

## Schedule A Reminder

```text
Remind me tomorrow morning to review the gateway logs.
```

Expected behavior:

- event draft;
- timezone handling;
- saved runtime event;
- future execution through the same pipeline.

## Debug A Gateway

```text
Check whether the local gateway is healthy and explain any failure without changing files.
```

Expected behavior:

- health probe;
- no mutation;
- concise diagnosis;
- gateway metadata in trace or capsule.

## Review Email Without Mutating It

```text
In my primary Gmail account, summarize security alerts from the last 30 days.
```

Expected behavior:

- account-scoped Gmail search;
- local metadata cache use where possible;
- bounded selected-message or selected-thread context;
- no send, trash, archive, or label mutation.

## Draft A Gmail Reply

```text
Draft a short reply to the selected email saying I will review it tomorrow.
```

Expected behavior:

- selected-thread context only;
- editable draft text;
- no send until the user explicitly asks and approves;
- trace details showing Gmail account and draft state.
