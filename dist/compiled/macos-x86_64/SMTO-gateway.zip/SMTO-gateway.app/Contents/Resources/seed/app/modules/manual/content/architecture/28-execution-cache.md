---
id: verified-execution-cache
title: Verified execution cache
kind: architecture
tags: [architecture, current, verified-execution-cache]
order: 28
---
# Verified execution cache

The execution cache stores reusable execution knowledge under explicit identity and
safety constraints. Its runtime integration can focus the model's tool projection or
reuse a verified procedure. It does not turn a cached response into fresh proof about
mutable external state.

`execution_cache/store.py` owns persistence; `identity.py` identifies eligible reuse;
`safety.py` and `extraction.py` constrain captured procedures; `runtime.py`, `focus.py`
and `direct.py` integrate selection with the existing loop. Management is separate from
execution authority. Credential material and uncertain mutations must not be promoted
into reusable public procedure data.

A warm run still needs appropriate current execution evidence and completion validation.
Discovery/capability policy and Agent Checks can affect eligibility and focus; a cache
hit is not an authorization override. Review the current [cache architecture guide](../../../../docs/architecture/verified-execution-cache.md)
for detailed source-backed constraints, and keep its historical acceptance measurements
separate from promises about current performance.
