---
id: screen
title: Screen capture, OCR and context
kind: architecture
tags: [architecture, current, screen, gateway, skills, privacy]
order: 38
---
# Screen capture, OCR and context

Enable **Screen** in Capabilities to observe the selected Gateway's screen explicitly.
It starts disabled. Enabling the skill, opening its UI, capability discovery and ordinary
Agent turns never acquire pixels. Existing saved capability selections remain unchanged.
Screen works independently of the Desktop skill. It adds no credential/profile store or
configuration switch and uses the existing Permission policy and execution receipts.

| Tool | Explicit result |
| --- | --- |
| `screen.displays` | Display IDs, native desktop bounds, pixel dimensions, scale and primary flag |
| `screen.active_window` | Current application/window identity, bounded title and bounds; no pixels |
| `screen.capture` | PNG/JPEG artifact, source geometry, timestamp, byte count and SHA-256 |
| `screen.ocr` | Bounded local OCR text and word boxes, source geometry and truncation truth |
| `screen.context` | Active-window metadata with independently requested screenshot/OCR |

All five tools are external **reads**, with no write confirmation for materializing an internal
artifact. Discover `screen` to expose its available tools; five tools need no section hierarchy.
`context` defaults to metadata only. Set `include_screenshot` and/or `include_ocr` to true when
needed. Both together use one capture. `ocr_max_characters` defaults to 4,096.

## Targets and coordinates

Gateway tools reserve `target` for selecting a Gateway. `screen.capture` therefore uses
`capture_target`, for example:

```json
{"capture_target":{"type":"display","display_id":"returned-display-id"},"format":"png"}
```

Window targets use `{"type":"window","window_id":"returned-window-id"}`. Region targets use
`{"type":"region","display_id":"returned-display-id","region":{"x":-100,"y":20,"width":80,"height":40}}`.
Use IDs and bounds returned by the selected Gateway, not invented monitor numbers or another
Gateway's identifiers. `screen.ocr` takes the same target shapes under `source`, or
`{"source":{"type":"image","path":"/absolute/target-local/image.png"}}`. Transfer controller
files explicitly before invoking OCR remotely. No URL or network-path downloads are supported.

The canonical desktop representation preserves the OS's **native global desktop coordinates**:
`desktop_physical_pixels` on Windows/X11; `desktop_points` on macOS. This matches native Desktop
Control semantics and preserves negative origins without inventing a universal mixed-scale
transform. Each display carries its exact `pixel_width`, `pixel_height` and `scale_factor`.
Conversion to display-local physical pixels uses the selected display's origin and separate
horizontal/vertical raster ratios; rectangle edges round outward. OCR boxes always use source-image
pixels with a top-left origin. Unknown rotation is omitted rather than reported as zero.

Regions must be fully contained in their selected display. Window capture is a **visible desktop
rectangle**, including occluding windows; it does not recover hidden/minimized content. Windows
spanning displays are rejected: explicitly capture separate regions. This avoids silent clipping,
rescaling or ambiguous cross-display raster geometry. Window identities are Gateway-local and
expire at restart; native handle reuse inside the same process remains an OS observation race.

PNG is the default. JPEG supports `jpeg_quality` from 1 through 95, default 85. There is no silent
downscaling. `include_cursor` defaults to false; true returns a cataloged unsupported error.

## Platform prerequisites and permission truth

The Gateway advertises `screen_displays`, `screen_active_window`, `screen_capture_display`,
`screen_capture_window`, `screen_capture_region` and `screen_ocr` independently. Configured tags
cannot manufacture native support. Readiness checks prerequisites without acquiring pixels;
execution rechecks permission and exact target support. Refresh Gateway metadata after changing
installed prerequisites, session or OS permissions. Existing runs retain their captured capability
snapshot. A disconnected remote target never falls back to the controller's screen.

| Gateway | Metadata | Capture | OCR |
| --- | --- | --- | --- |
| Windows interactive input desktop | Win32 monitors/foreground windows, per-monitor DPI awareness | Bounded GDI visible rectangle | Installed local Tesseract |
| macOS logged-in console | Quartz/Cocoa; Accessibility is not required | macOS 14+ ScreenCaptureKit and Screen Recording permission | Installed local Tesseract |
| Linux X11 | RandR 1.5 monitors; EWMH window metadata requires supported window manager | Exact XGetImage rectangle on supported 24/32-bit TrueColor visual | Installed local Tesseract |
| Linux Wayland | Unavailable in this release | No portal adapter; compositor boundary remains enforced, no XWayland bypass | Local image OCR remains independent |
| Headless/session zero | Unavailable | Unavailable | Local image OCR remains independent |

On macOS, grant **Screen Recording** to the actual Gateway executable in System Settings, restart
it when required, then refresh capabilities. The runtime never requests this permission itself.
ScreenCaptureKit's platform package is included in macOS dependencies; an older macOS release or
missing bridge leaves capture unavailable. Screenshot acquisition does not require Accessibility.

OCR is optional. Install Tesseract and its language data explicitly on the Gateway. Default OCR
availability requires English (`eng`) data. The `language` argument accepts installed Tesseract
language IDs such as `eng` or `eng+deu`; unavailable data gets a specific remediation. No package,
model weights, cloud OCR, helper LLM or resident OCR worker is installed or started automatically.

## Bounds, artifacts and cancellation

Captures and validated local PNG/JPEG inputs are limited to **16 million pixels** and **16 MiB
encoded bytes**. Dimensions are checked before decoding or native bitmap allocation. Up to 32
displays are returned. OCR defaults to 4,096 characters and 128 word blocks; explicit maxima are
32,768 characters and 512 blocks. Confidence is returned only when supplied by the engine.
Tesseract has a ten-second processing budget, one compute thread and a 2 MiB raw TSV ceiling.
The Gateway operation budget is 15 seconds; transport waits at most 20 seconds. Public response
JSON is capped at 1 MiB. At most four observations can run concurrently. Native IPC and OCR run
in disposable processes that are killed and reaped on timeout/cancellation; no background polling.

Screenshots are atomically published to the existing run artifact workspace with owner-only file
permissions. They join the existing artifact collector, authorized preview/download UI and normal
Gateway/conversation retention. OCR-only operations publish no screenshot. No separate screen cache
or history is created. Cancelled/failed composite operations do not leave a published screenshot.
The Gateway stores only up to 4,096 operation-ID tombstones for five minutes to fence duplicates
and cancellation before dispatch. Cancellation cannot retract an already completed read/artifact.

Response loss does not establish successful observation and never triggers automatic recapture.
There is no external mutation to reconcile. A screenshot published before response loss may remain
in the ordinary run workspace until normal cleanup. Reconnect the same Gateway and deliberately
request fresh evidence only when still needed.

## Privacy and untrusted content

Visible text, window titles and OCR are **untrusted external content**. Their presence does not
authorize instructions they contain. The Agent may reason about explicitly requested results using
its normal loop; these tools add **zero helper-model calls**. No screenshots are injected on each
turn, and there is no recorder, camera, automatic OCR index, mouse/keyboard action or vision model.

Exact explicit output remains in normal source receipts/result storage for the current operation.
The existing structural transient-content policy excludes Screen payloads from diagnostic sinks,
raw model traces, activity inspectors, automatic later-turn history, capsules, handoff copies and
automatic notifications. Once a Screen operation enters a request's diagnostics, later free-text
trace payloads are omitted too. This is unconditional data minimization, independent of optional
credential redaction, and also protects screen titles. No Working Context/Memory adapter registers
screen observations. Explicit artifacts and source receipts retain their existing lifecycle; they
are not an ephemeral substitute for those evidence stores.

## Source ownership

`agent_runtime/skills/screen/` owns one optional skill, validation/effects and selected-Gateway
receipt dispatch. `gateway_core/screen_contract.py` owns schemas and geometry; `screen_service.py`
owns orchestration/cancellation and artifact publication; `screen_worker.py` owns bounded native
processes; `platform_screen/` owns OS APIs; `ocr/` owns deterministic local text extraction.
Existing authenticated `/screen/operation` and `/screen/cancel` routes work through direct HTTP and
outbound forwarding. The existing execution engine, resource scheduling, permission policy,
artifact store, Error Catalog and unified privacy/redaction architecture retain their authority.

Native references: [Microsoft DPI contexts](https://learn.microsoft.com/en-us/windows/win32/hidpi/high-dpi-improvements-for-desktop-applications),
[Apple ScreenCaptureKit](https://developer.apple.com/documentation/screencapturekit),
[Tesseract TSV usage](https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html).
