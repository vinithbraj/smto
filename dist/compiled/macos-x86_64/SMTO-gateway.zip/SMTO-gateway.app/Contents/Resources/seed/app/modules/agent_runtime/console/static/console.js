const state = { snapshot: null };

const $ = (selector) => document.querySelector(selector);
const text = (selector, value) => {
  const node = $(selector);
  if (node) node.textContent = String(value ?? "");
};

function fmtPercent(value) {
  if (value === null || value === undefined) return "--";
  const number = Number(value || 0);
  return `${Math.round(number)}%`;
}

function fmtBytes(value) {
  if (value === null || value === undefined) return "--";
  const number = Number(value || 0);
  if (number >= 1024 ** 3) return `${(number / 1024 ** 3).toFixed(1)} GB`;
  if (number >= 1024 ** 2) return `${(number / 1024 ** 2).toFixed(1)} MB`;
  if (number >= 1024) return `${(number / 1024).toFixed(1)} KB`;
  return `${number} B`;
}

function fmtMs(value) {
  if (value === null || value === undefined) return "--";
  const number = Number(value || 0);
  if (number >= 1000) return `${(number / 1000).toFixed(1)}s`;
  return `${Math.round(number)}ms`;
}

async function api(path, options = {}) {
  const response = await window.SMTOErrors.fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
  if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
  return window.SMTOErrors.readJson(response);
}

function item(title, body, severity = "") {
  const node = document.createElement("article");
  node.className = "item";
  if (severity) node.dataset.severity = severity;
  const strong = document.createElement("strong");
  strong.textContent = title;
  const paragraph = document.createElement("p");
  paragraph.textContent = body;
  node.append(strong, paragraph);
  return node;
}

function fact(label, value) {
  const node = document.createElement("div");
  node.className = "fact";
  const strong = document.createElement("strong");
  strong.textContent = value;
  const span = document.createElement("span");
  span.className = "muted";
  span.textContent = label;
  node.append(strong, span);
  return node;
}

function chartContext(canvas) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  const styles = getComputedStyle(document.documentElement);
  const color = (token) => styles.getPropertyValue(token).trim();
  ctx.fillStyle = color("--code-bg");
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = color("--border");
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i += 1) {
    const y = (height / 4) * i;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  return { ctx, color, width, height };
}

function renderChart(snapshot) {
  const chart = chartContext($("#cpu-chart"));
  if (!chart) return;
  const { ctx, color, width, height } = chart;
  drawSeries(ctx, snapshot?.series?.cpu_percent || [], color("--accent"), width, height);
  drawSeries(ctx, snapshot?.series?.memory_percent || [], color("--success"), width, height);
  if (snapshot?.gpu?.available) {
    drawSeries(ctx, snapshot?.series?.gpu_percent || [], color("--warning"), width, height);
  }
  document.querySelectorAll(".gpu-device canvas").forEach((canvas) => {
    const gpuChart = chartContext(canvas);
    const history = snapshot?.gpu?.history || [];
    for (const [metric, token] of [["utilization_percent", "--accent"], ["memory_percent", "--success"]]) {
      const series = history.map((sample) => ({
        t: sample.t,
        value: sample.devices?.find((device) => device.id === canvas.dataset.gpuId)?.[metric],
      }));
      drawSeries(gpuChart.ctx, series, color(token), gpuChart.width, gpuChart.height);
    }
  });
}

function drawSeries(ctx, series, color, width, height) {
  const points = series.slice(-120);
  if (!points.length) return;
  const start = points[0].t;
  const duration = Math.max(1, points[points.length - 1].t - start);
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.beginPath();
  let connected = false;
  points.forEach((point) => {
    if (typeof point.value !== "number" || !Number.isFinite(point.value)) {
      connected = false;
      return;
    }
    const x = 2 + ((point.t - start) / duration) * (width - 4);
    const y = height - 2 - (Math.max(0, Math.min(100, point.value)) / 100) * (height - 4);
    if (!connected) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
    connected = true;
  });
  ctx.stroke();
}

function renderGpu(gpu = {}) {
  const devices = gpu.devices || [];
  text("#gpu", fmtPercent(gpu.utilization_percent));
  text("#gpu-memory", fmtPercent(gpu.memory_percent));
  text("#gpu-status", gpu.available
    ? `${devices.length} local GPU${devices.length === 1 ? "" : "s"} · device-wide readings`
    : gpu.message || "GPU telemetry unavailable.");
  $("#gpu-legend").hidden = !gpu.available;
  $("#cpu-chart").setAttribute("aria-label", gpu.available
    ? "CPU, memory and busiest GPU utilization chart, 0 to 100 percent"
    : "CPU and memory chart, 0 to 100 percent");
  const list = $("#gpu-list");
  list.replaceChildren();
  for (const device of devices) {
    const card = document.createElement("article");
    card.className = "gpu-device";
    const heading = document.createElement("h4");
    heading.textContent = `GPU ${device.index} · ${device.name}`;
    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 160;
    canvas.dataset.gpuId = device.id;
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", `${heading.textContent}: utilization ${fmtPercent(device.utilization_percent)}, VRAM ${fmtPercent(device.memory_percent)}. History from 0 to 100 percent.`);
    const legend = document.createElement("div");
    legend.className = "chart-legend";
    for (const [label, className] of [["GPU utilization", "legend-cpu"], ["VRAM", "legend-memory"], ["0–100%", "chart-scale"]]) {
      const entry = document.createElement("span");
      entry.className = className;
      entry.textContent = label;
      legend.append(entry);
    }
    const facts = document.createElement("div");
    facts.className = "facts";
    const reading = (value, unit) => value == null ? "--" : `${Math.round(value)} ${unit}`;
    facts.append(
      fact("GPU utilization", fmtPercent(device.utilization_percent)),
      fact("VRAM used", `${fmtBytes(device.memory_used_bytes)} / ${fmtBytes(device.memory_total_bytes)}`),
      fact("Temperature", reading(device.temperature_c, "°C")),
      fact("Power / limit", `${reading(device.power_watts, "W")} / ${reading(device.power_limit_watts, "W")}`),
    );
    card.append(heading, canvas, legend, facts);
    list.append(card);
  }
}

function render(snapshot) {
  state.snapshot = snapshot;
  const process = snapshot.process || {};
  const main = snapshot.main || {};
  const runtime = snapshot.runtime || {};
  text("#target-pid", `PID ${snapshot.sidecar?.target_pid || "--"}`);
  text("#main-status", main.status || "waiting");
  text("#cpu", fmtPercent(process.cpu_percent));
  text("#memory", fmtPercent(process.memory_percent));
  renderGpu(snapshot.gpu);
  text("#loop-lag", fmtMs(main.event_loop_lag_ms));
  text("#active-runs", runtime.active_run_count || 0);
  text("#slots", `${runtime.available_slots ?? "--"}/${runtime.parallel_run_limit ?? "--"}`);
  text("#heartbeat-age", `Heartbeat ${fmtMs(main.thread_heartbeat_age_ms)}`);
  text("#sample-count", `${snapshot.sidecar?.sample_count || 0} samples`);
  text("#request-count", `${(snapshot.active_requests || []).length} open`);

  const facts = $("#process-facts");
  if (facts) {
    facts.replaceChildren(
      fact("RSS", fmtBytes(process.rss_bytes)),
      fact("Threads", process.thread_count || 0),
      fact("FDs", process.fd_count ?? "--"),
      fact("Connections", process.connection_count ?? 0),
      fact("Host CPU", fmtPercent(process.host_cpu_percent)),
      fact("System memory", fmtPercent(process.system_memory_percent)),
      fact("Swap", fmtPercent(process.swap_percent)),
      fact("Load", (process.load_average || []).join(" / ") || "--"),
    );
  }

  const threads = $("#thread-list");
  if (threads) {
    threads.replaceChildren();
    const topThreads = process.top_threads || [];
    if (!topThreads.length) threads.append(item("No hot threads", "Thread CPU deltas are currently quiet."));
    for (const thread of topThreads) {
      threads.append(item(thread.name || `Thread ${thread.thread_id}`, `${thread.cpu_time_delta_seconds}s CPU delta`));
    }
  }

  const bottlenecks = $("#bottlenecks");
  if (bottlenecks) {
    bottlenecks.replaceChildren();
    for (const finding of snapshot.bottlenecks || []) {
      bottlenecks.append(item(finding.kind, `${finding.reason} ${finding.next_check || ""}`, finding.severity));
    }
  }

  const requests = $("#request-list");
  if (requests) {
    requests.replaceChildren();
    const active = snapshot.active_requests || [];
    if (!active.length) requests.append(item("No active requests", "The runtime has no open request records."));
    for (const request of active) {
      requests.append(
        item(
          request.request_id || "request",
          `${request.status || "unknown"} - ${request.current_stage || request.latest_event_type || "no stage"} - ${request.prompt_preview || ""}`,
        ),
      );
    }
  }

  const events = $("#event-list");
  if (events) {
    events.replaceChildren();
    for (const event of (snapshot.events || []).slice(-40).reverse()) {
      const payload = event.payload || {};
      events.append(item(event.kind || "event", payload.title || payload.path || payload.request_id || event.received_at || ""));
    }
  }

  const stack = snapshot.stack || {};
  if (stack.text) text("#stack-output", stack.text);
  else if (stack.message) text("#stack-output", stack.message);

  renderChart(snapshot);
  text("#status-line", `Updated ${new Date().toLocaleTimeString()} - sidecar uptime ${snapshot.sidecar?.uptime_seconds || 0}s`);
}

let pendingRead = null;
async function refresh(feedback = false) {
  const indicator = feedback ? window.SMTOBusy?.begin({host: $("#status-line"), label: "Loading Console…"}) : null;
  try {
    pendingRead ||= api("/api/console/snapshot").then(render).finally(() => { pendingRead = null; });
    await pendingRead;
  } catch (error) {
    window.SMTOErrors.present(document.querySelector("#status-line"), error);
  } finally { indicator?.finish(); }
}

async function captureStack() {
  const indicator = window.SMTOBusy?.begin({host: $("#stack-output"), label: "Capturing stacks…"});
  text("#status-line", "Capturing stacks...");
  try {
    const stack = await api("/api/console/stack", { method: "POST" });
    text("#stack-output", stack.text || stack.message || "No stack output.");
    await refresh();
  } catch (error) {
    window.SMTOErrors.present(document.querySelector("#status-line"), error);
  } finally { indicator?.finish(); }
}

$("#refresh-now")?.addEventListener("click", () => refresh(true));
$("#capture-stack")?.addEventListener("click", captureStack);

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => renderChart(state.snapshot));

refresh(true);
window.setInterval(() => refresh(false), 1000);
