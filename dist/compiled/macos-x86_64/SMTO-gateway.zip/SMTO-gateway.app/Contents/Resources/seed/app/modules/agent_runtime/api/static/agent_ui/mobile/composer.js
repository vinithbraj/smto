import { $, state, storage, scheduleDraft, runStatus, terminal, node, notice, api } from "./api.js?v=20261018-loading";
import "../prompt_recall.js?v=20261017-autocomplete";
import "../prompt_autocomplete.js?v=20261020-typing-idle";
import "./task_dependencies.js?v=20261021-run-after";
import { openSheet, closeSheet } from "./overlays.js?v=20261018-loading";
import "../composer_thinking.js?v=20261015-smto";
import {composerProfile} from "./composer_profile.js?v=20261018-loading";

import "../mention_palette.js?v=20261021-run-after";
import "../input_resources.js?v=20261021-run-after";
let completion;
export let composerResources;

const thinkingToggle = window.SMTOComposerThinking.create({
  button: $("#thinking-toggle"), reset: $("#thinking-reset"),
  quickButton: $("#thinking-quick-toggle"),
  budget: $("#thinking-budget"), budgetValue: $("#thinking-budget-value"),
  budgetHelp: $("#thinking-budget-help"),
  thinkingTokens: $("#thinking-budget-tokens"), outputBudget: $("#output-budget"),
  outputTokens: $("#output-budget-tokens"), outputReset: $("#output-budget-reset"),
  outputHelp: $("#output-budget-help"),
  profile: () => composerProfile.current(), ready: () => composerProfile.ready(),
  patch: changes => composerProfile.patch(changes), disabled: () => Boolean(state.steering),
});

let hooks, commands, commandLoading, sizeFrame = 0, chipsKey = "", sizedText, sizedWidth, sizedHeight;
const isCommand = () => $("#message").value.trimStart().startsWith("/");
async function commandController() {
  if (!commandLoading) commandLoading = import("./lazy/commands.js?v=20261019-resources").then(module => {
    commands = module.create(hooks); commands.update(); return commands;
  });
  return commandLoading;
}
const sendIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m-6 6 6-6 6 6"/></svg>';
const stopIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/></svg>';
function runView() {
  const status = runStatus(state.run), active = Boolean(state.requestId && status && !terminal(status));
  return {status, active, resuming: Boolean(state.requestId && state.replyPendingRequestId === state.requestId),
    graceful: active && state.run?.stop?.mode === "graceful" && !state.run.stop.terminalized_at,
    oauth: status === "waiting_user" && state.run?.oauth_authorization_request?.kind === "oauth"};
}
// Coalesce layout into one frame. Only the textarea owns overflow at the cap.
export function resizeComposer() {
  if (sizeFrame) return;
  sizeFrame = requestAnimationFrame(() => {
    sizeFrame = 0;
    const input = $("#message");
    if (input.value === sizedText && innerWidth === sizedWidth && innerHeight === sizedHeight) return;
    sizedText = input.value; sizedWidth = innerWidth; sizedHeight = innerHeight;
    const scroll = input.scrollTop;
    state.composerResizing = true;
    requestAnimationFrame(() => {
      state.composerResizing = false;
      window.dispatchEvent(new Event("mobile-composer-resized"));
    });
    input.style.height = "0px";
    const height = input.scrollHeight;
    input.style.height = `${height}px`;
    input.scrollTop = input.selectionEnd === input.value.length ? height : scroll;
    completion?.update();
  });
}
window.addEventListener("smto:font-scale", () => { sizedText = null; resizeComposer(); });
export function restoreDraft({preserve = false} = {}) {
  const saved = storage.get(`draft.${state.conversationId || "new"}`, "");
  if (!preserve) $("#message").value = typeof saved === "string" ? saved : saved?.schema_version === 2 && typeof saved.text === "string" ? saved.text : "";
  resizeComposer(); renderComposer();
}
export function renderPrimaryAction() {
  const {active, graceful, oauth, status} = runView();
  const text = $("#message").value.trim(), stopping = active && !text && status !== "paused";
  const waiting = oauth || status === "waiting_user_confirmation" || state.interaction;
  const deleting = window.SMTOConversationDeletion?.blocked(state.conversationId) && !isCommand() && !stopping;
  const label = deleting ? "Deleting conversation" : stopping ? graceful ? window.SMTOStopMessages?.force || "Force stop" : "Stop current task"
    : state.steering ? (state.steeringMode === "after_response" ? "Steer without interrupting" : "Steer current task") : active || state.lane?.queued_tasks?.length ? "Queue message" : "Send message";
  const send = $("#send");
  if (send.dataset.action !== (stopping ? "stop" : "send")) {
    send.dataset.action = stopping ? "stop" : "send";
    send.innerHTML = stopping ? stopIcon : sendIcon;
  }
  if (send.getAttribute("aria-label") !== label) send.setAttribute("aria-label", label);
  send.title = deleting ? label : state.loading ? "Loading conversation… You can keep typing." : state.composerProblem || label;
  send.disabled = deleting || composerResources?.isBusy() || state.loading || state.submitting || commands?.isBusy() ||
    (stopping ? Boolean(state.run?.cancel_requested && !graceful) :
      !text || (Boolean(waiting) && !isCommand()) ||
      ((!state.composerReady || state.composerProblem) && !state.steering && !isCommand()));
  // Hydration and submission never disable the editor or replace its value.
  $("#message").disabled = Boolean(oauth);
  $("#message").readOnly = Boolean(state.pendingSteer);
  completion?.update();
  $("#message").setAttribute("aria-busy", String(Boolean(state.pendingSteer)));
  $("#compose").toggleAttribute("data-steering", Boolean(state.pendingSteer));
  $("#steering-status").hidden = !state.pendingSteer;
}
function renderRunStrip() {
  const {active, graceful, oauth, status, resuming} = runView();
  const waiting = oauth || status === "waiting_user_confirmation" || state.interaction;
  if ((!active || waiting) && !state.pendingSteer) state.steering = false;
  $("#compose").hidden = Boolean(oauth);
  $("#run-controls").hidden = !active;
  const label = graceful ? `${window.SMTOStopMessages?.graceful || "Stopping gracefully…"} ${state.run.stop.grace_timeout}s`
    : state.run?.cancel_requested ? "Stopping…" : state.run?.pause_requested ? "Pausing…"
    : resuming ? "Resuming…"
    : {running: "Working…", paused: "Paused", waiting_user_confirmation: "Approval required", waiting_user: "Your input is needed", pending: "Starting…"}[status] || status.replaceAll("_", " ");
  if ($("#run-label").textContent !== label) $("#run-label").textContent = label;
  $("#pause").hidden = !active || !["running", "waiting_job", "waiting_event"].includes(status) || state.run?.cancel_requested;
  $("#pause").disabled = Boolean(state.run?.pause_requested);
  $("#resume").hidden = status !== "paused" || state.run?.cancel_requested;
  $("#resume").disabled = Boolean(state.controlBusy);
  $("#steer").hidden = !active || !["running", "paused", "waiting_job", "waiting_event"].includes(status) || Boolean(waiting);
  $("#steer").textContent = state.steering ? "Cancel steering" : "Steer";
  $("#steer").disabled = Boolean(state.pendingSteer && !state.pendingSteer.canCancel);
  $("#steer-gentle").hidden = $("#steer").hidden;
  $("#steer-gentle").disabled = Boolean(state.pendingSteer);
  $("#stop").hidden = !active;
  $("#stop").disabled = Boolean(state.run?.cancel_requested && !graceful);
  $("#stop").textContent = graceful ? window.SMTOStopMessages?.force || "Force stop" : "Stop";
  $("#compose-mode").hidden = !waiting;
  $("#compose-mode").textContent = waiting ? "Respond using the controls in this conversation" : "";
}
function renderQueueSummary() {
  const count = state.lane?.queued_tasks?.length || 0, blocked = state.lane?.block?.kind && state.lane.block.kind !== "none";
  $("#queue-bar").hidden = !count && !blocked;
  const label = `${count} queued${blocked ? " · Paused" : ""}`;
  if ($("#queue").textContent !== label) $("#queue").textContent = label;
  $("#status-strip").hidden = $("#run-controls").hidden && $("#queue-bar").hidden;
  const attention = count || blocked || state.interaction
    || ["paused", "paused_budget", "blocked", "waiting_user", "waiting_user_confirmation"].includes(runStatus(state.run));
  $("#options-badge").hidden = !attention;
  $("#options").setAttribute("aria-label", attention ? `Conversation options, ${count ? `${count} queued` : "task needs attention"}` : "Conversation options");
}
export function renderAttachmentStrip() {
  const dependency = window.SMTOTaskDependencies.selectedTaskId();
  const dependencyLabel = $("#depends-on-task").selectedOptions[0]?.textContent || dependency;
  const key = JSON.stringify([state.refs, dependency, dependencyLabel, state.steering, state.steeringMode, Boolean(state.pendingSteer), state.pendingSteer?.canCancel]);
  if (key === chipsKey) return;
  chipsKey = key;
  const chips = state.refs.map(ref => {
    const chip = node("button", `${ref.name || ref.context_id} ×`);
    chip.type = "button"; chip.setAttribute("aria-label", `Remove attachment ${ref.name || ref.context_id}`);
    chip.title = Number.isSafeInteger(ref.characters) ? `${ref.characters.toLocaleString()} characters` : chip.textContent;
    chip.onclick = () => { state.refs = state.refs.filter(item => item !== ref); renderAttachmentStrip(); };
    return chip;
  });
  if (dependency) {
    const chip = node("button", `Run After: ${dependencyLabel} ×`); chip.type = "button";
    chip.setAttribute("aria-label", `Remove task dependency: Run After: ${dependencyLabel}`); chip.dataset.taskDependency = "true";
    chip.classList.add("run-after-chip");
    chip.title = dependencyLabel;
    chip.onclick = () => { window.SMTOTaskDependencies.select("", state.conversationId); $("#message").focus(); };
    chips.push(chip);
  }
  if (state.steering) {
    const chip = node("button", state.steeringMode === "after_response" ? "Steer without interrupting ×" : "Steering ×"); chip.type = "button";
    chip.disabled = Boolean(state.pendingSteer && !state.pendingSteer.canCancel);
    chip.setAttribute("aria-label", "Cancel steering"); chip.onclick = cancelSteering;
    chips.push(chip);
  }
  $("#attachments").replaceChildren(...chips); $("#attachments").hidden = !chips.length;
}
// Reconciliation uses explicit state domains; ordinary input only updates the primary action.
export function renderComposer() {
  const immersive = window.SMTOImmersive?.active();
  $("#thinking-quick-toggle").hidden = !immersive;
  $("#add").setAttribute("aria-label", immersive ? "Add attachments" : "Attachments and prompt settings");
  window.SMTOImmersive?.composerProblem(!state.steering ? state.composerProblem : "");
  window.SMTOImmersive?.queue(state.lane);
  window.SMTOProseActivity?.renderToggle($("#activity-details-toggle"), state.conversationId);
  window.SMTOTaskDependencies.composer(state.lane, state.conversationId);
  renderRunStrip(); composerResources?.update();
  renderQueueSummary(); renderAttachmentStrip(); renderPrimaryAction();
  thinkingToggle.render();
  commands?.update(); resizeComposer();
}
window.addEventListener("smto:immersive", () => renderComposer());
async function cancelSteering() {
 const busyFeedback = window.SMTOBusy?.action("Cancelling instruction…");
 try {
  if (state.pendingSteer) {
    try { await state.pendingSteer.requestCancel(); }
    catch (error) { notice(error.message || "Couldn’t cancel this steer. Try again."); }
  } else state.steering = false;
  renderComposer();

 } finally { busyFeedback?.finish(); }
}
function viewportFallback() {
  const visual = window.visualViewport, focused = document.activeElement;
  const editing = focused?.matches("textarea,input:not([type=checkbox]):not([type=radio]),[contenteditable=true]");
  // Engines that resize the layout viewport need no JS adjustment. WebKit's
  // non-resizing keyboard is detected by the focused editor and a large mismatch.
  const fallback = editing && visual?.scale === 1 && window.innerHeight - visual.height > 120;
  const style = document.documentElement.style;
  if (fallback) {
    style.setProperty("--keyboard-height", `${visual.height}px`);
    style.setProperty("--keyboard-top", `${visual.offsetTop}px`);
  } else { style.removeProperty("--keyboard-height"); style.removeProperty("--keyboard-top"); }
}
export function initComposer(callbacks) {
  hooks = callbacks;
  window.SMTOPromptAutocomplete.configure({loadHistory: () => api("prompt-history")});
  composerResources = window.SMTOInputResources.create({input: $("#message"),
    conversationId: () => state.conversationId, scopeKey: () => `${state.conversationId}:${state.steering ? state.requestId : ""}`,
    disabled: () => state.submitting || Boolean(state.pendingSteer) || state.loading,
    inherited: () => state.steering ? state.run : {attachments: state.refs}, notify: notice,
    dependencies: {...window.SMTOTaskDependencies, available: () => !state.steering && !state.interaction},
    changed: () => { resizeComposer(); renderPrimaryAction(); }});
  window.addEventListener("smto:task-dependency", renderAttachmentStrip);
  completion = window.SMTOPromptAutocomplete.attach($("#message"), {disabled: () => composerResources?.isOpen()});
  $("#activity-details-toggle").onclick = () => {
    const prose = window.SMTOProseActivity;
    prose.setExpanded(state.conversationId, !prose.preference(state.conversationId));
    prose.renderToggle($("#activity-details-toggle"), state.conversationId);
  };
  $("#compose").addEventListener("submit", event => {
    event.preventDefault();
    if (state.pendingSteer) return;
    if (isCommand()) {
      const raw = $("#message").value;
      if (!state.loading) void commandController().then(controller => controller.execute(raw));
      return;
    }
    if (!$("#send").disabled) void ($("#send").dataset.action === "stop" ? hooks.control("cancel") : hooks.submit());
  });
  $("#message").addEventListener("input", () => {
    state.draftEdited = true;
    scheduleDraft($("#message").value);
    resizeComposer(); renderPrimaryAction();
    if (isCommand()) void commandController();
    commands?.update();
  });
  $("#message").addEventListener("keydown", event => {
    if (state.pendingSteer) { if (event.key !== "Tab") event.preventDefault(); return; }
    if (event.isComposing) return;
    if (event.key === "Home" && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
      event.preventDefault();
      const input = event.currentTarget;
      input.setSelectionRange(0, 0);
      input.scrollTop = 0;
      input.scrollLeft = 0;
      return;
    }
    if (isCommand() && ["Enter", "Tab", "ArrowUp", "ArrowDown", "Escape"].includes(event.key)) {
      if (commands?.keydown(event)) return;
      if (!commands) { event.preventDefault(); void commandController().then(controller => controller.keydown(event)); return; }
    }
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) { event.preventDefault(); $("#compose").requestSubmit(); }
  });
  $("#run-menu").onclick = () => {
    const body = openSheet("Task controls"); body.append($("#task-control-actions"));
  };
  for (const [id, action] of [["pause", "pause"], ["resume", "resume"], ["stop", "cancel"]])
    $("#" + id).onclick = async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try { await closeSheet(); void hooks.control(action);
 } finally { busyFeedback?.finish(); }
};
  $("#steer").onclick = async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try {
    if (state.steering || state.pendingSteer) await cancelSteering();
    else { state.steering = true; state.steeringMode = "interrupt"; }
    await closeSheet(); renderComposer();

 } finally { busyFeedback?.finish(); }
};
  $("#steer-gentle").onclick = async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try {
    if (state.pendingSteer) return;
    state.steering = true; state.steeringMode = "after_response";
    await closeSheet(); renderComposer();

 } finally { busyFeedback?.finish(); }
};
  $("#task-details").onclick = async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try { await closeSheet(); hooks.openTrace(state.requestId);
 } finally { busyFeedback?.finish(); }
};
  $("#depends-on-task").addEventListener("change", () => { renderAttachmentStrip(); void closeSheet(); });
  let viewportFrame = 0;
  const scheduleViewport = () => {
    if (!viewportFrame) viewportFrame = requestAnimationFrame(() => { viewportFrame = 0; viewportFallback(); resizeComposer(); });
  };
  window.visualViewport?.addEventListener("resize", scheduleViewport);
  window.visualViewport?.addEventListener("scroll", scheduleViewport);
  window.addEventListener("resize", scheduleViewport);
  document.addEventListener("focusin", scheduleViewport);
  document.addEventListener("focusout", scheduleViewport);
  window.addEventListener("mobile-composer-profile-changed", renderComposer);
  restoreDraft(); performance.mark("mobile-composer-usable");
}
