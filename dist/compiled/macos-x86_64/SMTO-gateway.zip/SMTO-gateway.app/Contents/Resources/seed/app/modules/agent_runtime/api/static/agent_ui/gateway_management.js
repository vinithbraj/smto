/* Mission Control owns Gateway management. Target selection stays in the composer. */
(() => {
  "use strict";

  const Core = window.SMTOAgentUi;
  const clip = (value, limit = 500) => String(value ?? "").slice(0, limit);
  const titleCase = value => value ? value[0].toUpperCase() + value.slice(1) : "Unknown";
  const connectionFields = ["scheme", "host", "port", "node", "terminal_cwd"];
  const node = (tag, className = "", text = "") => {
    const element = document.createElement(tag);
    element.className = className;
    element.textContent = text;
    return element;
  };

  // Both Settings entry points share the same validated, nullable Gateway capacity form.
  function capacityEditor(record, {onSave = () => {}, onLoad = () => {}} = {}) {
    const capacity = node("details", "gateway-capacity");
    capacity.append(node("summary", "", "Activity capacity"));
    const capacityBody = node("div", "gateway-capacity-fields"); capacity.append(capacityBody);
    let capacityLoaded = false;
    capacity.addEventListener("toggle", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating Gateway…", capacity);
        try {
      if (!capacity.open || capacityLoaded) return;
      try {
        const url = `/resource-scheduling/gateways/${encodeURIComponent(record.gateway_id)}`;
        const selected = await Core.apiJson(url);
        const form = node("form"), fields = {};
        for (const [key, title] of [["total","Max concurrent activities"],["disk_read_heavy","Disk read-heavy limit"],["disk_heavy","Disk-heavy limit"],
          ["cpu_heavy","CPU-heavy limit"],["gpu_heavy","GPU-heavy limit"],["network_heavy","Network-heavy limit"],["lightweight","Lightweight limit"],["unknown","Unknown limit"]]) {
          const label = node("label", "", title), input = node("input");
          input.type = "number"; input.min = "1"; input.max = "64"; input.step = "1";
          input.placeholder = "Auto"; input.value = selected[key] ?? ""; input.setAttribute("aria-label", title);
          fields[key] = input; label.append(input); form.append(label);
        }
        const save = node("button", "action-button", "Save capacity"); save.type = "submit";
        const feedback = node("p"); feedback.setAttribute("role", "status");
        form.append(save, feedback); capacityBody.replaceChildren(form); capacityLoaded = true;
        form.onsubmit = async event => {
        const busyFeedback = window.SMTOBusy?.action("Updating Gateway…", form);
        try {
          event.preventDefault();
          if (!form.reportValidity()) return;
          save.disabled = true;
          try { await Core.apiJson(url, {method:"PUT",body:Object.fromEntries(Object.entries(fields).map(([key,input]) => [key,input.value === "" ? null : Number(input.value)]))});
            feedback.textContent = "Saved. Running work continues; new dispatch uses these limits.";
            onSave();
          } catch (error) { window.SMTOErrors.present(feedback, error); }
          finally { save.disabled = false; }

        } finally { busyFeedback?.finish(); }
      };
        onLoad();
      } catch (error) { window.SMTOErrors.present(capacityBody, error); }

        } finally { busyFeedback?.finish(); }
      });
    return capacity;
  }

  function create({ onChange = () => {} } = {}) {
    const element = node("div", "gateway-management");
    const list = node("div", "gateway-management-list");
    const message = node("p", "gateway-management-message");
    message.setAttribute("role", "status");
    message.setAttribute("aria-live", "polite");
    const add = button("+ Add Gateway", "Add Gateway", "add", () => edit());
    const toolbar = node("div", "gateway-management-toolbar");
    toolbar.append(add, message);
    element.append(list, toolbar);
    let records = [];
    let dialog = null;
    let pending = false;
    let loading = null;
    let disposed = false;
    const busy = new Map();

    function announce(text, error = false) {
      message.textContent = clip(text);
      message.dataset.error = String(error);
    }

    function button(text, name, key, action) {
      const control = node("button", "gateway-button", text);
      control.type = "button";
      control.setAttribute("aria-label", name);
      control.dataset.gatewayAction = key;
      control.addEventListener("click", action);
      return control;
    }

    function restoreFocus(key) {
      const target = element.querySelector(`[data-gateway-action="${CSS.escape(key || "add")}"]`);
      (target && !target.disabled && !target.closest("[hidden]") ? target : add).focus();
    }

    function render() {
      const focused = element.contains(document.activeElement)
        ? document.activeElement?.dataset.gatewayAction : null;
      const expanded = new Set([...list.querySelectorAll("details[open]")].map(item => item.dataset.gatewayDetails));
      list.replaceChildren();
      for (const record of records) {
        const p = record.presentation || {};
        const m = record.management || {};
        const outbound = record.transport === "outbound" || record.source === "outbound";
        const card = node("article", "gateway-card");
        card.dataset.gatewayId = record.gateway_id;
        card.dataset.settingSearch = [record.label, record.host, record.node, record.platform,
          record.platform_label, record.status, p.status, record.source, record.transport,
          p.locality, record.source === "config" ? "startup configuration" : ""].join(" ").toLowerCase();
        const heading = node("div", "gateway-card-heading");
        const secure = Core.gatewayConnectionSecured(record);
        const name = node("div", "gateway-name");
        name.append(node("h3", "", clip(record.label, 120)));
        if (secure) name.append(Core.gatewayLockIcon());
        heading.append(name);
        const badges = node("div", "gateway-badges");
        const status = node("span", "gateway-status", titleCase(p.status || record.status));
        status.dataset.status = p.status || record.status;
        heading.append(status);
        if (secure)
          badges.append(node("span", "gateway-badge", "Secure"));
        else if (record.tls_trust_state === "identity_changed")
          badges.append(node("span", "gateway-badge", "Identity changed"));
        else if (record.tls_trust_state === "insecure_legacy")
          badges.append(node("span", "gateway-badge", "Insecure legacy"));
        if (p.is_default) {
          const badge = node("span", "gateway-badge", "Default");
          badge.title = "The default Gateway is currently determined by server configuration.";
          badges.append(badge);
        }
        card.append(heading);
        const locality = outbound ? "Outbound" : titleCase(p.locality);
        const subtitle = node("div", "gateway-card-subtitle");
        subtitle.append(node("p", "gateway-secondary", `${locality} · ${clip(record.platform_label || "Unknown", 80)}`));
        if (record.source === "config") {
          badges.append(node("span", "gateway-badge gateway-source", "Startup configuration"));
        }
        if (badges.childElementCount) subtitle.append(badges);
        card.append(subtitle);
        const metadata = node("div", "gateway-metadata");
        if (!outbound) metadata.append(node("p", "gateway-endpoint", clip(record.base_url, 320)));
        if (record.node) metadata.append(node("p", "gateway-secondary", `Node: ${clip(record.node, 160)}`));
        if (metadata.childElementCount) card.append(metadata);
        if (m.source_reason) card.append(node("p", "gateway-help", clip(m.source_reason)));
        if (m.reason) card.append(node("p", "gateway-reference-reason", clip(m.reason)));
        if (record.last_error) card.append(node("p", "gateway-last-error", `Last check: ${clip(record.last_error, 320)}`));

        const details = node("details", "gateway-details");
        details.dataset.gatewayDetails = record.gateway_id;
        details.open = expanded.has(record.gateway_id);
        details.append(node("summary", "", "Details"));
        const facts = node("dl", "gateway-facts");
        for (const [label, value] of [
          ["Platform", [record.platform_label, record.platform_version, record.architecture].filter(Boolean).join(" · ")],
          ["Shell", record.shell], ["Command profile", record.command_profile],
          ["Capabilities", (record.capability_tags || []).slice(0, 24).map(tag => clip(tag, 60)).join(" · ")],
          ["GPU", (record.capability_tags || []).includes("gpu_telemetry")
            ? "NVIDIA tools installed; device and configuration support is checked per operation." : ""],
          ["Working directory", record.terminal_cwd], ["Source", record.source],
          ["Last checked", record.last_checked_at], ["Last connected", record.last_connected_at],
          ["Last disconnected", record.last_disconnected_at],
        ]) {
          if (value) facts.append(node("dt", "", label), node("dd", "", clip(value, 1500)));
        }
        details.append(facts);
        const capacity = capacityEditor(record);
        details.append(capacity);
        card.append(details);
        const actions = node("div", "gateway-actions");
        const checking = busy.get(record.gateway_id) === "check";
        const check = button(checking ? "Checking…" : "Check", `Check ${record.label}`,
          `${record.gateway_id}:check`, () => checkHealth(record));
        check.disabled = busy.has(record.gateway_id);
        actions.append(check);
        if (m.can_edit_label) {
          const editButton = button("Edit", `Edit ${record.label}`, `${record.gateway_id}:edit`, () => edit(record));
          editButton.disabled = busy.has(record.gateway_id);
          actions.append(editButton);
          if (record.tls_identity_spki_sha256) {
            const reenroll = button("Forget trusted identity", `Forget trusted identity for ${record.label}`,
              `${record.gateway_id}:reenroll`, async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating Gateway…");
        try {
                try {
                  await Core.apiJson(`/gateways/${encodeURIComponent(record.gateway_id)}/identity`, { method: "DELETE" });
                  announce(`${record.label}: trusted identity forgotten. Check the intended machine before reconnecting.`);
                  await refresh();
                } catch (error) { announce(error.message); }

        } finally { busyFeedback?.finish(); }
      });
            actions.append(reenroll);
          }
          const action = record.enabled ? "Disable" : "Enable";
          const toggle = button(action, `${action} ${record.label}`, `${record.gateway_id}:toggle`, () => {
            if (record.enabled) confirm(record, "Disable");
            else void mutate(record, "enable", { enabled: true });
          });
          toggle.disabled = busy.has(record.gateway_id) || !(record.enabled ? m.can_disable : m.can_enable);
          if (toggle.disabled && m.reason) toggle.title = m.reason;
          actions.append(toggle);
        }
        if (record.source === "user" && !outbound) {
          const remove = button("Delete", `Delete ${record.label}`, `${record.gateway_id}:delete`, () => confirm(record, "Delete"));
          remove.classList.add("gateway-danger");
          remove.disabled = !m.can_delete || busy.has(record.gateway_id);
          if (!m.can_delete) remove.title = m.reason || "Delete is unavailable.";
          actions.append(remove);
        }
        card.append(actions);
        list.append(card);
      }
      if (!records.length) list.append(node("p", "gateway-empty", "No Gateways yet. Add a machine to make it available as an execution target."));
      onChange();
      if (focused && !dialog) restoreFocus(focused);
    }

    async function refresh({ force = false, feedback = false } = {}) {
      const indicator = feedback ? window.SMTOBusy?.begin({host: element, label: "Loading Gateways…"}) : null;
      try {
      pending = true;
      if (disposed || (dialog && !force) || (document.hidden && !force)) return;
      if (loading) return await loading;
      loading = (async () => {
        do {
          pending = false;
          try {
            const payload = await Core.apiJson("/gateway-management");
            records = payload.gateways || [];
            // A dialog may have opened while this request was in flight. Forms
            // are separate from list rendering and are never reconstructed here.
            if (!disposed) render();
          } catch (error) {
            // A stale registry response cannot establish a current secure connection.
            records = records.map(record => ({...record, tls_last_verified_at: ""}));
            if (!disposed) render();
            announce(`Could not refresh Gateways: ${clip(error.message, 350)}. Use Refresh to retry.`, true);
            break;
          }
        } while (pending && (!dialog || force) && !disposed);
      })();
      try { await loading; } finally { loading = null; }
      } finally { indicator?.finish(); }
    }

    function openDialog(title) {
      if (dialog) return null;
      const invokingKey = document.activeElement?.dataset.gatewayAction || "add";
      const modal = node("dialog", "gateway-dialog");
      const heading = node("h2", "", title);
      heading.id = "gateway-dialog-title";
      modal.setAttribute("aria-labelledby", heading.id);
      modal.addEventListener("keydown", event => {
        if (event.key !== "Tab") return;
        const controls = [...modal.querySelectorAll("button, input, select, [tabindex]")]
          .filter(control => !control.disabled && control.tabIndex >= 0 && control.getClientRects().length);
        const first = controls[0], last = controls.at(-1);
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      });
      if (document.body.classList.contains("mission-settings-body")) {
        const header = node("header"); header.append(heading); modal.append(header);
      } else modal.append(heading);
      document.body.append(modal);
      dialog = modal;
      modal.addEventListener("close", () => {
        modal.remove();
        dialog = null;
        restoreFocus(invokingKey);
        if (pending) void refresh();
      }, { once: true });
      return modal;
    }

    function edit(record = null) {
      const modal = openDialog(record ? `Edit ${record.label}` : "Add Gateway");
      if (!modal) return;
      const form = node("form", "gateway-form");
      const values = record || { label: "", scheme: "https", host: "", port: 8787, node: "", terminal_cwd: "", enabled: true };
      const m = record?.management || { can_edit_connection: true, can_enable: true, can_disable: true };
      if (m.reason) form.append(node("p", "gateway-reference-reason", clip(m.reason)));
      const fields = node("div", "gateway-form-fields");
      const controls = {};
      for (const [key, label, type, help] of [
        ["label", "Nickname", "text", "The name shown in the UI."],
        ["scheme", "Scheme", "select", ""],
        ["host", "Host", "text", "A hostname or IP address, without a scheme or path."],
        ["port", "Port", "number", ""],
        ["node", "Node", "text", "Optional Gateway runtime node identity."],
        ["terminal_cwd", "Terminal working directory", "text", "Optional starting directory on this Gateway. Leave blank to use its local work directory. Windows: C:\\Users\\Vinith. Linux: /home/vinith."],
        ["enabled", "Enabled", "checkbox", "Available for new Tasks."],
      ]) {
        const wrapper = node("div", `gateway-field gateway-field-${key}`);
        const labelElement = node("label", "", label);
        const control = node(type === "select" ? "select" : "input");
        control.id = `gateway-field-${key}`;
        control.name = key;
        labelElement.htmlFor = control.id;
        if (type === "select") {
          for (const scheme of ["https", "http"]) {
            const option = node("option", "", scheme);
            option.value = scheme;
            control.append(option);
          }
        } else control.type = type;
        if (type === "checkbox") {
          control.checked = Boolean(values[key]);
          control.className = "mission-switch";
          control.setAttribute("role", "switch");
        }
        else control.value = String(values[key] ?? "");
        control.required = ["label", "host", "port"].includes(key);
        if (type === "text") {
          control.maxLength = { label: 120, host: 255, node: 120, terminal_cwd: 2000 }[key];
          control.autocomplete = "off";
          control.spellcheck = false;
        }
        if (key === "port") { control.min = "1"; control.max = "65535"; control.step = "1"; }
        if (connectionFields.includes(key)) control.disabled = !m.can_edit_connection;
        if (key === "enabled") control.disabled = values.enabled ? !m.can_disable : !m.can_enable;
        control.addEventListener("input", () => control.setCustomValidity(""));
        if (type === "checkbox" && document.body.classList.contains("mission-settings-body")) wrapper.append(control, labelElement);
        else wrapper.append(labelElement, control);
        if (help) {
          const hint = node("p", "gateway-help", help);
          hint.id = `${control.id}-help`;
          control.setAttribute("aria-describedby", hint.id);
          wrapper.append(hint);
        }
        fields.append(wrapper);
        controls[key] = control;
      }
      const error = node("p", "gateway-form-error");
      error.setAttribute("role", "status");
      const actions = node("div", "gateway-dialog-actions");
      const cancel = button("Cancel", "Cancel", "cancel", () => modal.close());
      const save = node("button", "gateway-button gateway-primary", record ? "Save changes" : "Add Gateway");
      save.type = "submit";
      actions.append(cancel, save);
      form.append(fields, error, actions);
      modal.append(form);
      form.addEventListener("submit", async event => {
        const busyFeedback = window.SMTOBusy?.action("Updating Gateway…", form);
        try {
        event.preventDefault();
        if (save.disabled) return;
        for (const key of ["label", "host"]) {
          if (!controls[key].value.trim()) controls[key].setCustomValidity(`${key === "label" ? "Nickname" : "Host"} is required.`);
        }
        if (/:\/\/|[/?#]/.test(controls.label.value)) controls.label.setCustomValidity("Use a nickname, not a URL.");
        if (/[\s/@?#]/.test(controls.host.value.trim())) controls.host.setCustomValidity("Enter a hostname or IP address without a scheme, path, or credentials.");
        if (!form.reportValidity()) return;
        const body = {};
        for (const [key, control] of Object.entries(controls)) {
          if (control.disabled) continue;
          const value = key === "enabled" ? control.checked : key === "port" ? Number(control.value) : control.value.trim();
          if (!record || value !== record[key]) body[key] = value;
        }
        save.disabled = true;
        save.textContent = "Saving…";
        error.textContent = "";
        try {
          let result = await Core.apiJson(record ? `/gateways/${encodeURIComponent(record.gateway_id)}` : "/gateways", {
            method: record ? "PATCH" : "POST", body,
          });
          // Creation already probes. Recheck an edited endpoint or newly enabled target.
          if (record && (connectionFields.some(key => key in body) || body.enabled === true)) {
            try {
              result = await Core.apiJson(`/gateways/${encodeURIComponent(record.gateway_id)}/health`, { method: "POST" });
            } catch (_error) {
              announce("Gateway saved. The health check could not finish; use Check to retry.", true);
              modal.close();
              await refresh({ force: true });
              return;
            }
          }
          const gateway = result.gateway;
          announce(`${gateway.label} saved · ${titleCase(gateway.enabled ? gateway.status : "disabled")}.`);
          modal.close();
          await refresh({ force: true });
        } catch (failure) {
          error.textContent = clip(failure.message);
          await refresh({ force: true });
        } finally {
          save.disabled = false;
          save.textContent = record ? "Save changes" : "Add Gateway";
        }

        } finally { busyFeedback?.finish(); }
      });
      modal.showModal();
      controls.label.focus();
    }

    function confirm(record, action) {
      const modal = openDialog(`${action} "${record.label}"?`);
      if (!modal) return;
      modal.append(node("p", "gateway-confirm-copy", action === "Delete"
        ? "This removes the Gateway from this runtime."
        : "New Tasks will not be able to execute on this Gateway."));
      const error = node("p", "gateway-form-error");
      error.setAttribute("role", "status");
      const actions = node("div", "gateway-dialog-actions");
      const cancel = button("Cancel", "Cancel", "cancel", () => modal.close());
      const accept = button(action, `${action} Gateway`, "confirm", async () => {
        accept.disabled = true;
        const ok = await mutate(record, action.toLowerCase(), action === "Disable" ? { enabled: false } : null);
        if (ok) modal.close();
        else error.textContent = message.textContent;
        accept.disabled = false;
      });
      accept.classList.add("gateway-danger");
      actions.append(cancel, accept);
      modal.append(error, actions);
      modal.showModal();
      cancel.focus();
    }

    async function mutate(record, action, body) {
    const busyFeedback = window.SMTOBusy?.begin({host: element, label: "Updating Gateway…"});
    try {
      if (busy.has(record.gateway_id)) return false;
      busy.set(record.gateway_id, action);
      render();
      try {
        await Core.apiJson(`/gateways/${encodeURIComponent(record.gateway_id)}`, {
          method: action === "delete" ? "DELETE" : "PATCH", ...(body ? { body } : {}),
        });
        announce(`${record.label} ${action === "delete" ? "deleted" : action === "enable" ? "enabled" : "disabled"}.`);
        if (action === "enable") {
          try { await Core.apiJson(`/gateways/${encodeURIComponent(record.gateway_id)}/health`, { method: "POST" }); }
          catch (_error) { announce("Gateway enabled. Use Check to retry the health check.", true); }
        }
        return true;
      } catch (error) {
        announce(clip(error.message), true);
        return false;
      } finally {
        busy.delete(record.gateway_id);
        await refresh({ force: true });
      }

    } finally { busyFeedback?.finish(); }
  }

    async function checkHealth(record) {
    const busyFeedback = window.SMTOBusy?.begin({host: element, label: "Checking Gateway…"});
    try {
      if (busy.has(record.gateway_id)) return;
      busy.set(record.gateway_id, "check");
      render();
      try {
        const result = await Core.apiJson(`/gateways/${encodeURIComponent(record.gateway_id)}/health`, { method: "POST" });
        announce(`${record.label} · ${titleCase(result.gateway.status)}.`);
      } catch (error) {
        announce(`Check failed: ${clip(error.message, 350)}`, true);
      } finally {
        busy.delete(record.gateway_id);
        await refresh({ force: true });
      }

    } finally { busyFeedback?.finish(); }
  }

    const unsubscribe = window.SMTOUiUpdates.subscribe(
      ["gateways.changed", "gateway.health.changed", "tasks.changed", "runs.changed", "events.changed", "monitors.changed"],
      () => refresh(),
    );
    const visibility = () => { if (!document.hidden && pending) void refresh(); };
    document.addEventListener("visibilitychange", visibility);
    return {
      element, refresh,
      destroy() {
        disposed = true;
        unsubscribe();
        document.removeEventListener("visibilitychange", visibility);
        dialog?.close();
      },
    };
  }

  window.SMTOGatewayManagement = { create, capacityEditor };
})();
