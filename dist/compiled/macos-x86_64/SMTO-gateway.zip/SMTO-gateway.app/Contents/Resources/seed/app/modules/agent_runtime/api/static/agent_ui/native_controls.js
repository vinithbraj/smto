/* Shared native lifecycle and context controls. Snapshots never call the model. */
(() => {
  "use strict";
  const stateLabel = snapshot => {
    const activity = window.SMTORunActivity, state = activity.create();
    activity.setStatus(state, activity.userStatus(snapshot), {...snapshot, authoritative: true});
    return activity.resolve(state).label;
  };
  let hooks = {}, refs = [], lastRequest = "", lastStatus = "", lastConversation = "", refConversation = "";
  let refreshPromise = null, refreshPending = false, unsubscribe = null, initialized = false;
  let capacityPromise = null, capacityPending = false;
  let scopeRequest = "";
  let credentialInputRef = null, latestSnapshot = null;
  const acceptedChallenges = new Map();
  let refsRevision = 0;
  const pausingRequests = new Set();
  const stoppingRequests = new Set(), resumingRequests = new Set(), continuingRequests = new Set(), advancingRequests = new Set();
  const restartingRequests = new Set();
  let lifecycleRevision = 0, observedLifecycleRevision = -1;
  let resourcesLocked = false, pickerRevision = null;
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted"]);
  let foregroundTimer = null, foregroundKey = "";
  let foregroundAccepted = null;
  function renderForeground() {
    const box = root.querySelector(".native-foreground");
    const operation = latestSnapshot?.foreground_operation;
    clearInterval(foregroundTimer); foregroundTimer = null;
    if (!operation?.long_running || terminal.has(lastStatus) || latestSnapshot?.cancel_requested) {
      box.hidden = true; foregroundKey = ""; foregroundAccepted = null; box.replaceChildren(); return;
    }
    const identity = `${lastRequest}:${operation.operation_id}`;
    if (foregroundAccepted?.id === identity) operation.long_running_user_decision = foregroundAccepted.action;
    const key = `${lastRequest}:${operation.operation_id}:${operation.long_running_user_decision || ""}`;
    box.hidden = false;
    if (key !== foregroundKey) {
      foregroundKey = key; box.replaceChildren();
      const label = document.createElement("p"); label.className = "native-foreground-label"; box.append(label);
      const detail = document.createElement("small");
      detail.textContent = `Maximum foreground runtime: ${operation.configured_absolute_ceiling_seconds / 60} minutes. The command continues while you decide.`;
      box.append(detail);
      for (const [action, title] of [["continue", "Keep Running"], ["terminate", "Terminate"]]) {
        if (operation.long_running_user_decision === "terminate") continue;
        if (action === "continue" && operation.long_running_user_decision === "continue") continue;
        const button = document.createElement("button"); button.type = "button"; button.textContent = title;
        const request = lastRequest, operationId = operation.operation_id;
        button.addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating task…", button);
        try {
          button.disabled = true;
          try {
            await api(`/api/agent/native/${encodeURIComponent(request)}/operations/${encodeURIComponent(operationId)}/control`, {
              method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({action})});
            button.textContent = action === "continue" ? "Continuing" : "Terminating…";
            foregroundAccepted = {id: `${request}:${operationId}`, action};
            operation.long_running_user_decision = action;
            await refresh(); renderForeground();
          } catch (error) { button.disabled = false; status(error); }

        } finally { busyFeedback?.finish(); }
      });
        box.append(button);
      }
    }
    const tick = () => {
      const elapsed = Math.max(0, Math.floor(Date.now() / 1000 - operation.started_at));
      window.SMTONumberOdometer.render(box.querySelector(".native-foreground-label"),
        `${operation.long_running_user_decision === "terminate" ? "Terminating…" : operation.long_running_user_decision === "continue" ? "Running · user chose to continue" : "Still running"} · ${Math.floor(elapsed / 60)}m ${elapsed % 60}s${operation.privileged ? " · Privileged" : ""}`);
    };
    tick(); foregroundTimer = setInterval(tick, 1000);
  }
  const lifecycle = window.SMTOTaskLifecycle;
  const isCancelable = lifecycle.isCancelable;
  const taskViews = new Map();
  function renderTaskActions() {
    for (const [request, entry] of taskViews) {
      if (!entry.view.root.isConnected) { taskViews.delete(request); continue; }
      const presentation = entry.presentation();
      const snapshot = entry.snapshot || window.SMTOSelectedConversation?.execution(request);
      if (terminal.has(snapshot?.status)) stoppingRequests.delete(request);
      // A terminal trace can arrive before its native projection catches up.
      const status = presentation.settled && terminal.has(presentation.status)
        ? presentation.status : snapshot?.status || presentation.status;
      // Route messages by native execution state; an older completed trace can
      // still describe a live run waiting for user input or approval.
      entry.inlineSteer?.update({...snapshot, status: snapshot?.status || presentation.status,
        continued_by: snapshot?.continued_by || (presentation.continuedBy
          ? {request_id: presentation.continuedBy} : null),
      });
      if (terminal.has(status) || status === "paused" || snapshot?.cancel_requested || stoppingRequests.has(request)) pausingRequests.delete(request);
      if (snapshot) window.SMTOAgentChecks?.activities(entry.activities, snapshot, {
        actionContainer: entry.actionContainer,
        requestId: request, apiJson: api, refresh: async () => { await refresh(); await refreshTaskSnapshots(); },
        notify: message => hooks.notify?.(message), stop: () => void cancelCurrent(request),
      });
      entry.view.update({request_id: request, status, snapshot}, {
        settled: presentation.settled,
        stopping: stoppingRequests.has(request),
        pausing: pausingRequests.has(request),
        resuming: resumingRequests.has(request),
        continuing: continuingRequests.has(request),
        restarting: restartingRequests.has(request),
        advancing: advancingRequests.has(request),
      });
      hooks.renderGateways?.(entry.gateways, snapshot);
    }
  }
  function createTaskActions(request, presentation, {actionContainer = null, inlineSteer = null} = {}) {
    const view = lifecycle.create({requestId: request, dispatch: (action, id) => {
      const operation = action === "force_stop" ? cancelCurrent(id, {force: true}) : action === "cancel" ? cancelCurrent(id)
        : action === "continue_next" ? continueNextTask(id)
        : action === "stop_next" ? continueNextTask(id, {stop: true})
        : action === "pause" ? pauseCurrent(id)
        : action === "restart" ? continueTask(id, {restart: true})
        : action === "retry_task_contract" ? retryTaskContract(id) : action === "resume" ? resumeTask(id) : continueTask(id);
      void operation.catch(error => hooks.notify?.(error));
    }});
    const wrapper = document.createElement("div"), activities = document.createElement("div");
    const controls = document.createElement("div"); controls.className = "task-controls-row";
    const gateways = document.createElement("div");
    gateways.className = "conversation-gateways"; gateways.hidden = true;
    gateways.setAttribute("role", "group"); gateways.setAttribute("aria-label", "Conversation gateways");
    controls.append(gateways, view.root);
    activities.className = "task-foreground-activities"; wrapper.append(activities, controls);
    taskViews.set(request, {view, activities, gateways, presentation, actionContainer, inlineSteer, snapshot: null});
    return wrapper;
  }
  async function refreshTaskSnapshots(onlyRequest = "") {
    if (!onlyRequest && window.SMTOSelectedConversation) return window.SMTOSelectedConversation.refresh();
    const revision = lifecycleRevision;
    const results = await Promise.all([...taskViews].map(async ([request, entry]) => {
      if (!entry.view.root.isConnected) { taskViews.delete(request); return; }
      if (onlyRequest && request !== onlyRequest) return;
      if ((!onlyRequest && request === lastRequest) || entry.snapshot?.continued_by) return;
      try {
        const snapshot = await api(`/api/agent/native/${encodeURIComponent(request)}?view=compact`);
        if ((snapshot.state_revision || 0) < (entry.snapshot?.state_revision || 0)) return;
        if (revision !== lifecycleRevision || taskViews.get(request) !== entry || !entry.view.root.isConnected) return;
        entry.snapshot = snapshot;
        window.SMTOInlineSteer.observe(request, snapshot);
        hooks.onTaskState?.(snapshot, request);
      } catch (error) { return error.status === 404; }
    }));
    renderTaskActions();
    return results.every(result => result !== false) && revision === lifecycleRevision;
  }
  function renderStop(run = hooks.currentRun?.() || {request_id: lastRequest, status: lastStatus}) {
    const button = document.querySelector("#stop-button");
    if (!button) return;
    if (terminal.has(run.status)) stoppingRequests.delete(run.request_id);
    const stopping = isCancelable(run) && (stoppingRequests.has(run.request_id) || run.cancel_requested || run.snapshot?.cancel_requested);
    button.hidden = !isCancelable(run);
    const stopState = run.snapshot?.stop || run.stop || (run.request_id === lastRequest ? latestSnapshot?.stop : null);
    const graceful = stopState?.mode === "graceful" && !stopState.terminalized_at;
    button.disabled = Boolean(stopping && !graceful);
    button.querySelector("span").textContent = graceful ? (window.SMTOStopMessages?.force || "Force stop") : stopping ? "Stopping…" : "Stop";
    button.setAttribute("aria-label", graceful ? "Force stop" : stopping ? "Stopping current task" : "Stop current task");
    button.title = button.getAttribute("aria-label");
    renderTaskActions();
    const pause = document.querySelector("#pause-button");
    if (!pause) return;
    const snapshot = run.snapshot || (run.request_id === lastRequest ? latestSnapshot : null);
    if (terminal.has(run.status) || run.status === "paused" || stopping) pausingRequests.delete(run.request_id);
    const pausing = !stopping && (pausingRequests.has(run.request_id) || run.pause_requested || snapshot?.pause_requested);
    pause.hidden = !run.request_id || stopping || (!pausing && !["running", "waiting_job", "waiting_event"].includes(run.status));
    pause.disabled = Boolean(pausing);
    pause.querySelector("span").textContent = pausing ? "Pausing…" : "Pause";
    pause.setAttribute("aria-label", pausing ? "Pausing after current action" : "Pause after current action");
    pause.title = pause.getAttribute("aria-label");
  }
  async function pauseCurrent(request = hooks.currentRun?.().request_id || hooks.requestId?.() || lastRequest, commandContext = null) {
    const busyFeedback = window.SMTOBusy?.action("Pausing task…");
    try {
    if (!request || pausingRequests.has(request) || stoppingRequests.has(request)) return;
    pausingRequests.add(request);
    hooks.onPausing?.(request, true);
    renderStop();
    try {
      const result = await control("pause", commandContext ? {command_context: commandContext} : {}, request);
      await refresh();
      return result;
    } catch (error) {
      pausingRequests.delete(request);
      hooks.onPausing?.(request, false);
      throw error;
    } finally { renderStop(); }

    } finally { busyFeedback?.finish(); }
  }
  async function cancelCurrent(request = hooks.currentRun?.().request_id || hooks.requestId?.() || lastRequest, {confirmation = false, force = false, commandContext = null} = {}) {
    const busyFeedback = window.SMTOBusy?.action("Stopping task…");
    try {
    const saved = taskViews.get(request)?.snapshot || (request === lastRequest ? latestSnapshot : null);
    force = force || (saved?.stop?.mode === "graceful" && !saved.stop.terminalized_at);
    if (!request || (stoppingRequests.has(request) && !force)) return;
    stoppingRequests.add(request);
    hooks.onStopping?.(request, true);
    hooks.onCancel?.(request);
    renderStop();
    try {
      // The native route also handles prepared/legacy requests through the shared coordinator.
      const result = confirmation
        ? await api(`/api/agent/confirmation/${encodeURIComponent(request)}`, {
          method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({action: "deny", context: {}})})
        : await control("cancel", {...(force ? {mode: "instant"} : {}), ...(commandContext ? {command_context: commandContext} : {})}, request);
      if (terminal.has(result.status)) stoppingRequests.delete(request);
      // Queue reconciliation may already be reading the pre-Stop state. A
      // committed control needs a trailing read, even without an SSE event.
      if (window.SMTOSelectedConversation?.selected())
        await window.SMTOSelectedConversation.invalidate();
      else await refresh();
      return result;
    } catch (error) {
      stoppingRequests.delete(request);
      hooks.onStopping?.(request, false);
      status("Could not confirm the stop request. The task may still be running; retry Stop.");
      throw error;
    } finally { renderStop(); }

    } finally { busyFeedback?.finish(); }
  }
  const safeAttachments = value => (Array.isArray(value) ? value : []).slice(0, 16)
    .filter(item => item && typeof item.context_id === "string" && /^ctx_[\w-]{1,200}$/.test(item.context_id))
    .filter((item, index, items) => items.findIndex(other => other.context_id === item.context_id) === index)
    .map(item => ({context_id: item.context_id,
      name: typeof item.name === "string" ? item.name.slice(0, 512) : item.context_id,
      bytes: Number.isSafeInteger(item.bytes) && item.bytes >= 0 ? item.bytes : 0,
      ...(Number.isSafeInteger(item.characters) && item.characters >= 0 ? {characters: item.characters} : {}),
      media_type: typeof item.media_type === "string" ? item.media_type.slice(0, 128) : "application/octet-stream"}));
  const attachmentSnapshot = () => safeAttachments(refs);
  const contextScope = () => hooks.contextScope?.() || hooks.conversationId?.() || "";
  const root = document.createElement("section");
  root.className = "native-controls";
  root.setAttribute("aria-label", "Task progress and context");
  const icon = path => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}" /></svg>`;
  root.innerHTML = `
    <div class="native-toolbar">
      <div class="native-toolbar-primary" role="group" aria-label="Context and task actions">
        <button type="button" data-native="attach" title="Add files or retained context">
          ${icon("m8 12 6-6a3 3 0 0 1 4 4l-8 8a5 5 0 0 1-7-7l8-8")}
          <span>Add context</span>
        </button>
        <button type="button" data-native="compact" title="Compact context while retaining exact history">
          ${icon("M8 3v5H3m18 0h-5V3M3 16h5v5m8 0v-5h5")}
          <span>Compact context</span>
        </button>
        <span class="native-run-capacity" role="status" aria-live="polite" title="Run capacity is loading.">Run slots: —</span>
        <button type="button" data-native="steer" hidden>${icon("M12 5v14M5 12h14")}<span>Update task</span></button>
        <button type="button" data-native="steer-gentle" hidden title="Let the current response finish, then apply your update before the next action."><span>Steer without interrupting</span></button>
        <button type="button" data-native="permissions" hidden>Task permissions</button>
      </div>
      <div class="native-toolbar-secondary" role="group" aria-label="Conversation data">
        <button type="button" data-native="export" aria-label="Export conversation" title="Export conversation">
          ${icon("M12 3v12m-4-4 4 4 4-4M5 16v4h14v-4")}<span>Export</span>
        </button>
        <label class="native-retention">
          <select aria-label="Delete retained data" data-native="retention" title="Manage retained conversation data">
            <option value="">Retention</option>
            <option value="artifact_policy">Artifact retention settings</option>
            <option value="ui_chat">Delete UI chat</option>
            <option value="summaries">Delete summaries</option>
            <option value="artifacts">Delete artifacts</option>
            <option value="diagnostics">Delete diagnostics</option>
            <option value="receipts">Delete receipts</option>
            <option value="conversation">Delete conversation history</option>
            <option value="everything">Delete everything</option>
          </select>
          ${icon("m8 10 4 4 4-4")}
        </label>
      </div>
    </div>
    <div class="native-attachments"></div>
    <div class="native-state" role="status" aria-live="polite"></div>
    <div class="native-foreground" aria-label="Long-running operation" hidden></div>
    <p class="native-pause-note" hidden>Paused after the current action. Progress and results are preserved.</p>
    <ol class="native-tasks"></ol>`;
  const file = document.createElement("input");
  file.type = "file"; file.multiple = true; file.hidden = true;
  root.append(file);
  const status = (text) => {
    const node = root.querySelector(".native-state");
    if (text instanceof Error || text?.error_detail) window.SMTOErrors.present(node, text);
    else if (node.textContent !== text) node.textContent = text;
  };
  async function api(url, options = {}) {
    const response = await window.SMTOErrors.fetch(url, options);
    const data = await window.SMTOErrors.readJson(response);
    if (!response.ok) {
      if (data.detail?.error_kind === "eula_acceptance_required") window.dispatchEvent(new Event("smto:eula-required"));
      const error = window.SMTOErrors.fromPayload(data, response.status);
      error.status = response.status; throw error;
    }
    return data;
  }
  let policyRenderVersion = 0;
  async function renderContextPolicy() {
    const version = ++policyRenderVersion;
    if (!refs.length) return;
    const cid = hooks.conversationId?.();
    try {
      const catalog = await api(`/api/agent/context-read-policy${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`);
      if (version !== policyRenderVersion) return;
      const policy = hooks.isSteering?.() && latestSnapshot ? latestSnapshot.context_read_policy
        : window.SMTOAgentChecks?.contextPolicyForRequest(cid) || catalog.context_read_policy;
      for (const label of root.querySelectorAll("[data-context-read-label]")) {
        label.textContent = `Context read: ${window.SMTOAgentChecks.contextPolicyLabel(policy)}`;
      }
    } catch { /* Metadata stays usable if preferences are temporarily unavailable. */ }
  }
  window.addEventListener("context-policy-changed", () => void renderContextPolicy());
  function renderRefs() {
    const container = root.querySelector(".native-attachments"); container.replaceChildren();
    for (const item of refs) {
      const chip = document.createElement("button"); chip.type = "button";
      const removeMark = document.createElement("span"); removeMark.textContent = "×";
      removeMark.dataset.uiSymbol = "cross";
      chip.append(document.createTextNode(`${item.name || item.context_id} `), removeMark);
      chip.title = "Remove from next request";
      const size = document.createElement("small");
      size.textContent = Number.isSafeInteger(item.characters) ? `${item.characters.toLocaleString()} characters` : `${item.bytes.toLocaleString()} bytes`;
      const policy = document.createElement("small"); policy.dataset.contextReadLabel = "";
      chip.append(size, policy);
      chip.disabled = Boolean(hooks.isSteering?.());
      chip.onclick = () => { if (hooks.isSteering?.()) return; refs = refs.filter(r => r.context_id !== item.context_id); renderRefs(); };
      container.append(chip);
    }
    hooks.onContextRefsChanged?.(attachmentSnapshot());
    void renderContextPolicy();
  }
  function syncRefs() {
    const current = contextScope();
    if (current !== refConversation) { refsRevision++; refs = []; refConversation = current; renderRefs(); }
    refConversation = current;
  }
  function restoreAttachments(snapshot) {
    refsRevision++; refConversation = contextScope(); refs = safeAttachments(snapshot); renderRefs();
  }
  function syncResourceLock() {
    const locked = Boolean(hooks.isSteering?.());
    if (locked !== resourcesLocked) { resourcesLocked = locked; refsRevision++; renderRefs(); }
    root.querySelector('[data-native="attach"]').disabled = locked;
    const attach = document.querySelector("#attach-button");
    if (attach) attach.disabled = locked;
  }
  function remainingAttachmentSlots() { syncRefs(); return Math.max(0, 16 - refs.length); }
  function assertCanAttach() {
    syncResourceLock();
    if (resourcesLocked) throw window.SMTOErrors.error("ui_resources_locked");
    if (!remainingAttachmentSlots()) throw window.SMTOErrors.error("ui_context_source_limit");
  }
  function openFilePicker() {
    assertCanAttach();
    pickerRevision = refsRevision;
    file.click();
    return true;
  }
  async function linkSource(candidate) {
    const busyFeedback = window.SMTOBusy?.action("Attaching context…");
    try {
    assertCanAttach();
    const target = hooks.conversationId?.();
    if (!target) throw window.SMTOErrors.error("ui_context_conversation_required");
    const revision = refsRevision, scope = contextScope();
    const payload = {source_conversation_id: candidate.source_conversation_id,
      target_conversation_id: target, ...(candidate.context_id ? {context_id: candidate.context_id}
        : {source_run_id: candidate.source_run_id, reference: candidate.reference})};
    const metadata = await api("/api/agent/context/link", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)});
    if (revision !== refsRevision || scope !== contextScope() || target !== hooks.conversationId?.() || hooks.isSteering?.()) return false;
    if (!refs.some(item => item.context_id === metadata.context_id)) {
      assertCanAttach();
      refs = safeAttachments([...refs, metadata]); renderRefs();
    }
    return true;

    } finally { busyFeedback?.finish(); }
  }
  const attachContext = candidate => linkSource(candidate);
  const attachArtifact = candidate => linkSource({source_conversation_id: candidate.conversation_id,
    source_run_id: candidate.run_id, reference: candidate.reference});
  async function pickContext() {
    const busyFeedback = window.SMTOBusy?.action("Loading available context…");
    try {
    if (hooks.isSteering?.()) return;
    syncRefs();
    const dialog = document.createElement("dialog");
    dialog.className = "context-dialog";
    dialog.setAttribute("aria-labelledby", "context-dialog-title");
    dialog.setAttribute("aria-describedby", "context-dialog-description");
    dialog.innerHTML = `
      <form method="dialog">
        <header class="context-dialog-header">
          <div>
            <h2 id="context-dialog-title">Add context</h2>
            <p id="context-dialog-description">Give your next message more to work with.</p>
          </div>
          <button class="context-dialog-close" type="button" aria-label="Close add context" data-ui-symbol="cross">
            ${icon("m6 6 12 12M6 18 18 6")}
          </button>
        </header>
        <div class="context-dialog-body">
          <button class="context-upload" type="submit" value="upload" autofocus>
            <span class="context-upload-icon">${icon("M12 16V4m-4 4 4-4 4 4M4 16v4h16v-4")}</span>
            <span class="context-upload-copy">
              <strong>Upload file</strong>
              <span>Choose files from your device</span>
            </span>
            <span class="context-upload-arrow">${icon("m9 6 6 6-6 6")}</span>
          </button>
          <div class="context-dialog-divider"><span>or link an existing source</span></div>
          <section aria-labelledby="context-source-title">
            <h3 id="context-source-title">Link existing context</h3>
            <p class="context-source-description">Reuse a saved source from another conversation.</p>
            <div class="context-source-fields">
              <div class="context-field">
                <label for="context-conversation">Source conversation</label>
                <input id="context-conversation" name="conversation" placeholder="Conversation ID" autocomplete="off" spellcheck="false">
              </div>
              <div class="context-field">
                <label for="context-run">Artifact run</label>
                <input id="context-run" name="run" placeholder="Run ID" autocomplete="off" spellcheck="false" aria-describedby="context-run-help">
                <small id="context-run-help">Only needed for artifacts.</small>
              </div>
              <div class="context-field context-field-reference">
                <label for="context-reference">Artifact or context reference</label>
                <input id="context-reference" name="reference" placeholder="op_… or ctx_…" autocomplete="off" spellcheck="false" aria-describedby="context-reference-help">
                <small id="context-reference-help">Paste the reference for the source you want to attach.</small>
              </div>
            </div>
          </section>
        </div>
        <footer class="context-dialog-footer">
          <button class="context-dialog-cancel" type="submit" value="cancel">Cancel</button>
          <button class="context-dialog-link" type="submit" value="link">
            ${icon("M10 13a5 5 0 0 0 7 .5l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7-.5l-3 3a5 5 0 0 0 7 7l2-2")}
            <span>Link selected source</span>
          </button>
        </footer>
      </form>`;
    dialog.querySelector(".context-dialog-close").onclick = () => dialog.close("cancel");
    document.body.append(dialog);
    dialog.addEventListener("close", async () => {
      try {
        if (dialog.returnValue === "upload") openFilePicker();
        if (dialog.returnValue === "link") {
          const values = new FormData(dialog.querySelector("form"));
          const reference = String(values.get("reference") || "");
          const payload = {source_conversation_id: values.get("conversation"),
            ...(reference.startsWith("ctx_") ? {context_id: reference} : {source_run_id: values.get("run"), reference})};
          await linkSource(payload);
        }
      } catch (error) { status(error); }
      dialog.remove();
    });
    dialog.showModal();

    } finally { busyFeedback?.finish(); }
  }
  file.onchange = async () => {
        const busyFeedback = window.SMTOBusy?.begin({host: root, label: "Uploading files…"});
        try {
    syncRefs();
    const revision = pickerRevision ?? refsRevision, scope = contextScope();
    pickerRevision = null;
    try {
      for (const source of [...file.files]) {
        if (revision !== refsRevision || scope !== contextScope() || hooks.isSteering?.()) return;
        assertCanAttach();
        if (source.size > 64 * 1024 * 1024) throw window.SMTOErrors.error("ui_attachment_too_large");
        const metadata = await api(`/api/agent/context/upload?name=${encodeURIComponent(source.name)}`, {
          method: "POST", headers: {"Content-Type": source.type || "application/octet-stream"}, body: source});
        if (revision !== refsRevision || scope !== contextScope() || hooks.isSteering?.()) return;
        assertCanAttach();
        refs.push(...safeAttachments([metadata])); renderRefs();
      }
      renderRefs(); status("Context attached. Exact sources are retained; previews stay bounded.");
    } catch (error) { status(error); }
    finally { file.value = ""; }

        } finally { busyFeedback?.finish(); }
      };
  file.addEventListener("cancel", () => { pickerRevision = null; });
  async function control(action, extra = {}, request = hooks.requestId?.() || lastRequest) {
    if (!request) throw window.SMTOErrors.error("ui_run_required");
    const result = await api(`/api/agent/native/${encodeURIComponent(request)}/control`, {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({action, ...extra})});
    if (["pause", "resume", "cancel"].includes(action)) lifecycleRevision++;
    return result;
  }
  async function resumeTask(request, extra = null, commandContext = null) {
    const busyFeedback = window.SMTOBusy?.action("Resuming task…");
    try {
    if (!request || resumingRequests.has(request) || advancingRequests.has(request)) return;
    resumingRequests.add(request);
    renderTaskActions();
    try {
      hooks.onResuming?.(request);
      const result = await control("resume", {...extra, ...(commandContext ? {command_context: commandContext} : {})}, request);
      pausingRequests.delete(request);
      hooks.onResumed?.(result, request);
      await refresh();
      return result;
    } catch (error) {
      lifecycleRevision++;
      hooks.onResumeFailed?.(request);
      await refresh();
      throw error;
    } finally { resumingRequests.delete(request); renderTaskActions(); }

    } finally { busyFeedback?.finish(); }
  }
  function retryTaskContract(request, attemptId) {
    const snapshot = taskViews.get(request)?.snapshot || (request === lastRequest ? latestSnapshot : null);
    return resumeTask(request, {retry_task_contract: true,
      contract_attempt_id: attemptId || snapshot?.task_contract_retry_attempt_id});
  }
  async function continueNextTask(request, {stop = false} = {}) {
    const busyFeedback = window.SMTOBusy?.action("Continuing task…");
    try {
    const next = taskViews.get(request)?.snapshot?.continue_next;
    if (!next || advancingRequests.has(request) || resumingRequests.has(request)
      || restartingRequests.has(request) || stoppingRequests.has(request)) return;
    if (stop) stoppingRequests.add(request);
    advancingRequests.add(request); renderTaskActions();
    try {
      const result = await api(`/api/agent/native/${encodeURIComponent(request)}/continue-next`, {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({next_task_id: next.next_task_id, version: next.version,
          action: stop ? "stop" : "skip"})});
      lifecycleRevision++;
      await refresh();
      return result;
    } catch (error) {
      await refresh();
      throw error;
    } finally {
      advancingRequests.delete(request);
      if (stop) stoppingRequests.delete(request);
      renderTaskActions();
    }

    } finally { busyFeedback?.finish(); }
  }
  async function continueTask(request, {restart = false} = {}) {
    const busyFeedback = window.SMTOBusy?.action("Continuing task…");
    try {
    if (!request || continuingRequests.has(request) || restartingRequests.has(request)) return;
    const conversation = hooks.conversationId?.() || "";
    const pending = restart ? restartingRequests : continuingRequests;
    pending.add(request);
    renderTaskActions();
    try {
      const result = await api(`/api/agent/native/${encodeURIComponent(request)}/${restart ? "restart" : "continue"}`, {method: "POST"});
      hooks.onContinued?.(result, request, conversation);
      await refresh();
      return result;
    } finally { pending.delete(request); renderTaskActions(); }

    } finally { busyFeedback?.finish(); }
  }
  async function compactCurrent(requestId = hooks.requestId?.() || lastRequest, commandContext = null) {
    const busyFeedback = window.SMTOBusy?.action("Compacting context…");
    try {
    const state = await control("compact", commandContext ? {command_context: commandContext} : {}, requestId);
    hooks.contextUsage?.(state.context_usage);
    status("Context compacted; exact history retained.");
    await hooks.onCompacted?.(requestId);
    await refresh();
    return state;

    } finally { busyFeedback?.finish(); }
  }
  root.addEventListener("click", async event => {
    const action = event.target.closest("[data-native]")?.dataset.native;
    const feedback = action === "export" ? window.SMTOBusy?.begin({host: root, label: "Exporting conversation…"}) : null;
    try {
      if (action === "attach") await pickContext();
      else if (action === "compact") await compactCurrent();
      else if (action === "permissions") hooks.onPermissions?.(lastRequest);
      else if (action === "steer" || action === "steer-gentle") {
        hooks.onSteer?.(lastRequest, action === "steer-gentle" ? "after_response" : "interrupt");
      }
      else if (action === "export") {
        const id = hooks.conversationId?.(); if (!id) throw window.SMTOErrors.error("ui_conversation_required");
        const response = await window.SMTOErrors.fetch(`/api/agent/native-conversations/${encodeURIComponent(id)}/export?archive=true`);
        if (!response.ok) {
          const failure = await window.SMTOErrors.readJson(response).catch(() => ({}));
          throw window.SMTOErrors.fromPayload(failure, response.status);
        }
        const url = URL.createObjectURL(await response.blob());
        const a = document.createElement("a"); a.href = url; a.download = `conversation-${id}.zip`; a.click(); URL.revokeObjectURL(url);
      }
    } catch (error) { status(error); }
    finally { feedback?.finish(); }
  });
  root.querySelector('[data-native="retention"]').onchange = async event => {
        const busyFeedback = window.SMTOBusy?.action("Updating task…", root.querySelector('[data-native="retention"]'));
        try {
    const action = event.target.value; event.target.value = "";
    if (!action) return;
    if (action === 'artifact_policy') {
      const requestId = hooks.requestId?.() || lastRequest;
      if (!requestId) { status('Open a run to manage artifact retention.'); return; }
      window.dispatchEvent(new CustomEvent('smto:open-artifacts', {detail: {requestId}}));
      return;
    }
    const id = hooks.conversationId?.();
    if (!id || !confirm(`Delete ${action.replaceAll("_", " ")} for this conversation? Active or unreconciled work will be retained.`)) return;
    try { await api(`/api/agent/native-conversations/${encodeURIComponent(id)}?action=${action}`, {method: "DELETE"}); status("Retention action completed.");
      window.dispatchEvent(new CustomEvent('smto:artifacts-deleted', {detail: {conversationId: id}}));
    }
    catch (error) { status(error); }

        } finally { busyFeedback?.finish(); }
      };
  function refresh() {
    if (window.SMTOSelectedConversation) {
      if (window.SMTOSelectedConversation.selected()) return window.SMTOSelectedConversation.refresh();
      if (!hooks.requestId?.() || hooks.conversationId?.()) return Promise.resolve(true);
    }
    // Capacity has its own unavailable state; it does not establish task truth.
    void refreshCapacity();
    syncRefs();
    const conversation = hooks.conversationId?.() || "";
    const request = hooks.requestId?.() || "";
    if (conversation !== lastConversation || (request && request !== lastRequest) || (!request && scopeRequest && !conversation)) {
      lastConversation = conversation; lastRequest = request; lastStatus = ""; latestSnapshot = null;
      renderForeground();
      hooks.onCredentialState?.(null, request);
      root.querySelector(".native-tasks").replaceChildren(); status("");
      for (const action of ["steer", "steer-gentle", "permissions"]) root.querySelector(`[data-native="${action}"]`).hidden = true;
      root.querySelector(".native-pause-note").hidden = true;
    }
    scopeRequest = request;
    refreshPending = true;
    if (!refreshPromise) {
      refreshPromise = (async () => {
        let current;
        do {
          refreshPending = false;
          const native = await refreshSnapshot();
          const tasks = await refreshTaskSnapshots();
          current = native !== false && tasks !== false;
        } while (refreshPending);
        return current;
      })().finally(() => { refreshPromise = null; });
    }
    return refreshPromise;
  }
  function refreshCapacity() {
    if (document.hidden) return false;
    if (capacityPromise) { capacityPending = true; return capacityPromise; }
    const label = root.querySelector(".native-run-capacity");
    capacityPromise = (async () => {
      let current;
      do {
        capacityPending = false;
        try {
          const {capacity, available_slots: free, active_count: active, activities} = await api("/api/agent/run-capacity");
          if (!Number.isInteger(capacity) || capacity < 1 || !Number.isInteger(free) || free < 0 || free > capacity
            || !Number.isInteger(active) || active < 0) throw window.SMTOErrors.error("ui_capacity_invalid");
          label.textContent = `Global run slots: ${free}/${capacity} free${free === 0 ? " · full" : ""}`;
          if (activities) label.textContent += ` · Activities ${activities.active}/${activities.capacity} · Waiting ${activities.waiting}`;
          label.dataset.full = String(free === 0);
          label.title = `${active} of ${capacity} run slots occupied across the runtime. ` + (free === 0
            ? "Queued tasks wait for a free slot."
            : "Queued tasks also wait for earlier tasks in their conversation.");
          if (activities) label.title += " Activity slots by run: " + Object.entries(activities.runs).map(([run, count]) => `${run}: ${count}`).join(", ");
          current = true;
        } catch (_) {
          label.textContent = "Global run slots: unavailable";
          label.dataset.full = "false";
          label.title = "Could not refresh run capacity. Reconnecting will refresh the count.";
          current = false;
        }
      } while (capacityPending);
      return current;
    })().finally(() => { capacityPromise = null; });
    return capacityPromise;
  }
  async function refreshSnapshot(provided = null) {
    // Visible tabs reconcile snapshots through shared invalidations.
    if (document.hidden) return false;
    const revision = lifecycleRevision;
    const conversation = hooks.conversationId?.() || "";
    let latestState = provided;
    if (provided) { lastRequest = provided.request_id; lastConversation = conversation; }
    if (!lastRequest && conversation) {
      try {
        const latest = await api(`/api/agent/native-conversations/${encodeURIComponent(conversation)}/latest`);
        if (revision !== lifecycleRevision || (hooks.conversationId?.() || "") !== conversation || hooks.requestId?.()) return;
        lastRequest = latest.request_id || latest.run_id || "";
        if (latest.status) latestState = latest;
      } catch (error) { return error.status === 404; }
    }
    if (!lastRequest) return;
    const requested = lastRequest;
    try {
      // /latest already returns the full authoritative snapshot. Do not hydrate
      // the same run a second time just to resolve its request ID.
      const state = latestState || await api(`/api/agent/native/${encodeURIComponent(requested)}`);
      if ((state.state_revision || 0) < (taskViews.get(requested)?.snapshot?.state_revision || 0)) return;
      if (revision !== lifecycleRevision || lastRequest !== requested || (hooks.conversationId?.() || "") !== conversation) return;
      window.SMTOInlineSteer.observe(requested, state);
      if (!provided && state.continued_by?.request_id && hooks.onContinued) {
        const child = await api(`/api/agent/native/${encodeURIComponent(state.continued_by.request_id)}`);
        if (lastRequest !== requested || (hooks.conversationId?.() || "") !== conversation) return;
        hooks.onContinued({...child, request_id: state.continued_by.request_id}, requested, conversation);
        void refresh(); return;
      }
      const target = state.authority?.gateway_node || state.authority?.node || state.authority?.gateway_defaults?.node || "";
      const source = {prompt: "This prompt", conversation: "This conversation", global: "Global", default: "Product default"}[state.permission_source];
      const access = `Permissions: ${window.SMTOPermissionPolicy.names[state.user_permission_policy?.mode || state.authority?.approval_mode || "manual"]}${source ? " — " + source : ""} · ${target} · `;
      status(state.schema_version === 1 ? state.lifecycle?.display?.label || state.execution_status?.label || stateLabel(state)
        : `${access}${stateLabel(state)} · ${state.calls || 0} decisions · ${state.tool_calls || 0} tool executions${state.pending_wait ? " · " + (state.pending_wait.job_id || state.pending_wait.kind) : ""}`);
      root.querySelector('[data-native="steer"]').hidden = !["running", "waiting_job", "waiting_event", "paused", "paused_budget"].includes(state.status);
      root.querySelector('[data-native="steer-gentle"]').hidden = root.querySelector('[data-native="steer"]').hidden;
      root.querySelector('[data-native="permissions"]').hidden = terminal.has(state.status);
      root.querySelector(".native-pause-note").hidden = state.status !== "paused" || !state.manual_pause;
      const tasks = root.querySelector(".native-tasks"); tasks.replaceChildren();
      for (const task of state.task_board?.tasks || []) { const li = document.createElement("li"); li.textContent = `${task.description} — ${task.status.replaceAll("_", " ")}`; tasks.append(li); }
      hooks.contextUsage?.(state.context_usage);
      const previousStatus = lastStatus;
      const previousCancel = latestSnapshot?.cancel_requested;
      const previousPause = latestSnapshot?.pause_requested;
      const previousStop = JSON.stringify(latestSnapshot?.stop);
      const controlChanged = observedLifecycleRevision !== revision;
      observedLifecycleRevision = revision;
      const previousCredential = JSON.stringify(latestSnapshot?.oauth_authorization_request);
      const traceChanged = latestSnapshot?.trace_event_id !== state.trace_event_id
        || latestSnapshot?.trace_created_at !== state.trace_created_at;
      lastStatus = state.status;
      // Lifecycle, bounded target presentation and public descriptor; no grants/URLs.
      const descriptor = state.oauth_authorization_request;
      const requestValid = descriptor?.request_id === requested && descriptor.kind === "oauth";
      latestSnapshot = {run_id: state.run_id, status: state.status, calls: state.calls, tool_calls: state.tool_calls,
        state_revision: state.state_revision,
        stop: state.stop, stop_policy: state.stop_policy,
        context_read_policy: state.context_read_policy,
        unsafe_action_request: state.unsafe_action_request,
        resource_reconciliation_request: state.resource_reconciliation_request,
        foreground_operation: state.foreground_operation,
        trace_event_id: state.trace_event_id, trace_created_at: state.trace_created_at,
        lifecycle: state.lifecycle, resume_allowed: state.resume_allowed, compact_allowed: state.compact_allowed,
        task_contract_retry_attempt_id: state.task_contract_retry_attempt_id,
        continue_next: state.continue_next,
        stop_allowed: state.stop_allowed, queue_advance: state.queue_advance,
        pause_requested: Boolean(state.pause_requested), manual_pause: Boolean(state.manual_pause),
        target: window.SMTOTargetSelector.fromNative(state),
        cancel_requested: Boolean(state.cancel_requested), oauth_authorization_request: state.status === "waiting_user" && requestValid
          ? {...descriptor, request_id: requested} : null};
      const taskView = taskViews.get(requested);
      const currentOwner = Boolean(taskView?.presentation().current);
      const newlyMounted = Boolean(taskView && (!taskView.snapshot || (currentOwner && !taskView.currentOwner)));
      if (taskView) { taskView.snapshot = state; taskView.currentOwner = currentOwner; }
      hooks.onCredentialState?.(latestSnapshot, requested);
      renderStop();
      renderForeground();
      if (newlyMounted || controlChanged || traceChanged || previousStop !== JSON.stringify(state.stop) || previousStatus !== state.status || previousCancel !== latestSnapshot.cancel_requested || previousPause !== latestSnapshot.pause_requested || previousCredential !== JSON.stringify(latestSnapshot.oauth_authorization_request)) hooks.onState?.(state, lastRequest);
    } catch (error) { return error.status === 404; }
  }
  window.SMTONative = {
    refresh,
    async applyConversation(snapshot) {
      for (const [request, entry] of taskViews) {
        const run = snapshot.executions_by_request_id[request];
        if (run && (run.state_revision || 0) >= (entry.snapshot?.state_revision || 0)) {
          entry.snapshot = run; window.SMTOInlineSteer.observe(request, run);
        }
      }
      const current = snapshot.executions_by_request_id[snapshot.current_request_id];
      if (current) await refreshSnapshot(current);
      else {
        lastRequest = ""; lastStatus = ""; latestSnapshot = null;
        renderStop(); renderForeground();
        hooks.onCredentialState?.(null, "");
      }
      const capacity = snapshot.lane.global_capacity;
      const label = root.querySelector(".native-run-capacity");
      if (capacity && label) {
        label.textContent = `Global run slots: ${capacity.available_slots}/${capacity.capacity} free`;
        label.title = "Observed global run capacity";
        label.dataset.full = String(capacity.available_slots === 0);
      }
      renderTaskActions();
    },
    refreshTaskSnapshot: request => refreshTaskSnapshots(request),
    whenReady: () => refreshPromise,
    isCancelable, renderStop, cancelCurrent, createTaskActions, renderTaskActions, pauseCurrent,
    setSecurePrompts: () => {},
    safeAttachments, attachmentSnapshot, restoreAttachments, syncRefs,
    openFilePicker, attachContext, attachArtifact, remainingAttachmentSlots, syncResourceLock,
    current: () => JSON.parse(JSON.stringify({request_id: lastRequest, status: lastStatus, snapshot: latestSnapshot})),
    retryCompletion: (requestId, decisionId) => resumeTask(requestId, {retry_completion: true, decision_id: decisionId}),
    retryTaskContract, compactCurrent,
    resumeCurrent: (request, context) => resumeTask(request, null, context),
    async followup({requestId, amendment, submissionId, resources}) {
      const conversation = hooks.conversationId?.() || "";
      const result = await api(`/api/agent/native/${encodeURIComponent(requestId)}/follow-up`, {
        method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({amendment, submission_id: submissionId, resources}),
      });
      hooks.onContinued?.(result, requestId, conversation);
      void refresh().catch(() => {});
      return result;
    },
    async steer(amendment, requestId = lastRequest, submissionId = null, steeringMode = "interrupt", resources) {
      const result = await control("steer", {amendment, resources,
        steering_mode: steeringMode,
        ...(submissionId ? {submission_id: submissionId} : {})}, requestId);
      await refresh();
      status("Task update queued for the next decision.");
      return result;
    },
    cancelSteer: ({requestId, submissionId}) => control("cancel_steer", {submission_id: submissionId}, requestId),
    credentialContext: () => ({}),
    async prepareChat(text, {refreshState = true} = {}) {
      if (refreshState) await refresh();
      return {prompt: text};
    },
    refs: () => { syncRefs(); return refs.map(item => item.context_id); },
    init(options) {
      hooks = {...hooks, ...options};
      // Legacy callers may reinitialize with just a new conversation accessor.
      if (options.conversationId && !options.contextScope) hooks.contextScope = options.conversationId;
      const composer = document.querySelector("#composer");
      if (composer) composer.after(root);
      else document.body.append(root);
      const attach = document.querySelector("#attach-button");
      if (attach) { attach.disabled = false; attach.onclick = pickContext; }
      if (!initialized) {
        const stop = document.querySelector("#stop-button");
        if (stop) stop.addEventListener("click", () => { void cancelCurrent().catch(error => hooks.notify?.(error)); });
        const pause = document.querySelector("#pause-button");
        if (pause) pause.addEventListener("click", () => { void pauseCurrent().catch(error => hooks.notify?.(error)); });
        document.addEventListener("visibilitychange", () => { if (!document.hidden) window.SMTOUiUpdates.reconcile(); });
        initialized = true;
      }
      unsubscribe?.();
      if (!window.SMTOSelectedConversation)
        unsubscribe = window.SMTOUiUpdates.subscribe(["runs.changed", "tasks.changed", "runtime-controls.changed", "settings.changed"], refresh, {critical: true});
      void refresh();
    },
  };
})();
