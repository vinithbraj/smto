---
id: notifications
title: Notification Center
kind: manual
tags: [manual, notifications, reminders]
order: 24
---
# Notification Center

Open **Notifications** from the bell in the Agent header, Directory, or the Schedules navigation. /notifications brings together scheduled reminders, scheduled Agent outcomes, monitor alerts, durable task updates and system notices.

Search matches title and message without regard to case. **All** includes unread, read and dismissed records; the other filters show each status separately. History starts with the newest 100 records. **Load more** expands it in steps of 100, up to 500 retained records. Search and filters apply to the loaded set. Server retention still controls how long history remains available.

**Mark read**, **Mark all read** and **Dismiss** are explicit actions. Dismiss retains the record in the Dismissed filter. Opening the Center normally, following a source link, displaying an alert or letting an alert disappear does not mark a notification read. Opening a specific /notifications?notification=ID link focuses that item and marks it read if it was unread. Dismissed items remain dismissed.

**View schedule** opens Scheduler Manager. **Open conversation** is available when the existing public source context supplies a conversation ID. Notifications do not link to raw execution traces as their primary destination.

Messages display supported Markdown, including lists, emphasis, code, links and tables. Long messages start with a compact preview; **Show more** reveals the full message and **Show less** collapses it. Source links and notification actions stay in the card footer. Browser notifications and the small in-page alert use concise plain-text summaries; open the Center to read the formatted message.

## Delivery while smTO is open

Use **Enable browser notifications** in the Center to request browser permission. smTO never requests it automatically on page load.

| Browser state | New notification delivery |
| --- | --- |
| Granted | Native browser notification |
| Default / not enabled | Compact in-page notification |
| Denied / blocked | Compact in-page notification; no repeated permission prompt |
| Unsupported, or native construction fails | Compact in-page notification |

Browser permission and smTO's **Notifications enabled** preference in Mission Control are separate. The smTO preference is the master switch. When it is off, neither native nor in-page alerts are delivered; existing history remains visible. Existing store behavior retains suppressed arrivals as read records with a suppression flag.

The in-page alert appears at the upper right on Agent, Schedules, Notifications and Mission Control. It displays one small icon, title and short message, and disappears after 6.5 seconds. Hovering or focusing it keeps it available. A burst shows up to three individual alerts sequentially, then one summary for the remainder. A hidden or unfocused tab waits to display pending alerts until it is active. Reduced-motion preferences disable the slide animation.

Clicking an in-page or native notification opens the specific item in Notification Center. A native click focuses its existing smTO window where the browser permits.

Initial history establishes a delivery baseline. Old unread records do not produce alerts on first load or reload. Recently delivered IDs and timestamps are remembered locally for up to seven days, capped at 500; notification content is never stored there. Tabs coordinate using recent IDs, browser messages and an optional short browser lock. Native notifications also use a stable ID tag. Browsers without these coordination features provide best-effort deduplication.

Native browser notifications require an active smTO page. This implementation does not add Web Push or background delivery after every smTO tab is closed. Missed alerts remain in durable Notification Center history, subject to existing retention.

## Up next

The quiet right rail previews the next three **direct reminders**, ordered by the scheduler's saved next trigger. Eligible records have event_kind=scheduled, action_type=notification, status=active, and a valid next_run_at. Times use each reminder's configured timezone; hover for the full date, time and timezone. The rail moves below history on smaller screens.

Paused, cancelled, completed and unscheduled items are excluded. Conditional monitors and Agent schedules that notify upon completion are excluded because their notification time is not known in advance. Choose an item or **View schedules** to manage reminders in Scheduler Manager.

Notification changes and schedule changes refresh through the existing shared update stream. There is no additional polling channel, notification database or scheduler.
