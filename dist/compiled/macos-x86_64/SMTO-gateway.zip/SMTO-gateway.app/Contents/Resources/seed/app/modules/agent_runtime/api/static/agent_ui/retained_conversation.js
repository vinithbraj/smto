/* Read-only conversation presentation. Execution state stays with the live turn. */
const node = (tag, text = "", className = "") => {
  const element = document.createElement(tag); element.textContent = text; element.className = className;
  return element;
};

export function retainedConversation({host, conversationId, inspect, renderMarkdown, onAnswerArchived}) {
  const prose = window.SMTOProseActivity;
  const presentation = window.SMTOActivityPresentation;
  const markdown = renderMarkdown || ((body, text) => window.SMTOMarkdown.render(body, text));
  const narrations = new Map(), operations = new Map(), seen = new Set(), groups = [];
  let active = null, status = "running";
  function refresh() {
    const ended = ["completed", "answered", "failed", "cancelled", "interrupted", "partial"].includes(status);
    for (const [index, group] of groups.entries()) {
      const facts = [...group.facts.values()].filter(Boolean);
      const outcome = facts.includes("failure") ? "failure"
        : facts.includes("running") ? ended ? "incomplete" : "running"
          : facts.includes("pending") ? ended ? "incomplete" : "pending"
            : facts.includes("cancelled") ? "cancelled"
              : facts.includes("incomplete") ? "incomplete"
                : facts.length || group.closed ? "success"
                  : ended ? "incomplete" : "running";
      prose.setOutcome(group.view.indicator, prose.summaryOutcome(outcome, status, index === groups.length - 1));
    }
  }
  function working() {
    if (!active) {
      active = {view: prose.working(host, {conversationId}), facts: new Map()};
      groups.push(active);
    }
    return active;
  }
  function renderRow(row) {
    const view = presentation.describe(row.event, row.outcome);
    presentation.richLabel(row.button).textContent = view.rich;
    presentation.decorateLabel(row.button, row.event, row.outcome);
    window.SMTOActionIcons.update(row.typeIcon, view.icon);
    row.button.title = [view.capability, view.context].filter(Boolean).join(" · ");
    row.summary.textContent = view.summary || row.event.command_preview || row.event.detail.command
      || view.context || (row.event.summary === "Model-led operation progress." ? "" : row.event.summary) || "";
    row.summary.hidden = !row.summary.textContent || row.summary.textContent === view.rich;
    row.root.dataset.status = row.outcome || "";
    if (view.elapsed !== null) {
      if (!row.elapsed) { row.elapsed = node("span", "", "activity-recorded-timing"); row.button.after(row.elapsed); }
      row.elapsed.textContent = window.SMTOPerformanceTiming?.format(view.elapsed) || `${(view.elapsed / 1000).toFixed(2)} s`;
    }
  }
  function event(event) {
    event = presentation.operationEvent(event);
    const identity = event.id ?? event.event_id;
    const scope = event.request_id || conversationId;
    const eventKey = `${scope}:${identity}`;
    if (identity != null && seen.has(eventKey)) return;
    if (identity != null) seen.add(eventKey);
    const type = event.event_type || "", detail = event.detail || {};
    if (prose.answerBoundary(host, event, markdown, null, onAnswerArchived)) active = null;
    prose.observeMonitoring(host, event);
    if (type === "conversation.message") {
      if (prose.message(host, event, markdown)) active = null;
    } else if (type === "user.steered") {
      if (prose.steering(host, event)) active = null;
    } else if (type === "agent.progress.narration") {
      if (!detail.decision_id || !Number.isInteger(detail.sequence)) return;
      let entry = narrations.get(detail.decision_id);
      if (!entry) { entry = {sequence: 0, text: ""}; narrations.set(detail.decision_id, entry); }
      if (detail.sequence <= entry.sequence) return;
      entry.sequence = detail.sequence;
      if (detail.phase === "blocked") {
        if (entry.group) prose.withdraw(entry.group.view);
        entry.text = ""; entry.closed = true;
      } else if (detail.phase === "completed") entry.closed = true;
      else if (!entry.closed && detail.phase === "delta" && typeof detail.content === "string") {
        entry.text += detail.content;
        if (entry.text.trim() && !entry.group) {
          const block = node("div", "", "agent-progress-narration narration markdown");
          const promoted = prose.promoteWorking(active?.view, {decisionId: detail.decision_id, block, timestamp: event.timestamp});
          if (promoted) entry.group = active;
          else {
            entry.group = {view: prose.create({conversationId, decisionId: detail.decision_id, block, timestamp: event.timestamp}), facts: new Map()};
            groups.push(entry.group); host.append(entry.group.view.root);
          }
          active = entry.group;
        }
        if (entry.group) markdown(entry.group.view.block, entry.text);
      }
      if (entry.group) {
        entry.group.closed = entry.closed;
        const block = entry.group.view.block;
        block.dataset.decisionId = detail.decision_id;
        if (entry.closed && entry.text) {
          block.contextSourceText = entry.text;
          block.dataset.contextSourceComplete = "true";
        } else {
          delete block.contextSourceText;
          delete block.dataset.contextSourceComplete;
        }
      }
    } else if (type.startsWith("activity.supervision.")) {
      prose.monitoring(host, event); active = null;
    } else if (/^(execution\.command\.|invocation\.|task_contract\.|llm\.|model\.rejected$|activity\.|capability_|context\.|run\.steer_queued)/.test(type)
        && !["execution.command.stdout", "execution.command.stderr"].includes(type)) {
      const operationId = detail.operation_id || detail.action_id || detail.execution_id;
      const model = type.startsWith("llm.") || type === "model.rejected";
      // Capability notices have durable chronological identities even if they
      // reference the same operation. Tools join only explicit request-local IDs.
      const capability = type.startsWith("capability_");
      const key = `${scope}:${model ? `model:${detail.call_id || operationId || identity}`
        : capability ? `capability:${detail.capability_event_id || identity}` : `operation:${operationId || detail.activity_id || identity}`}`;
      const alias = !model && !capability && detail.activity_id ? `${scope}:activity:${detail.activity_id}` : null;
      const identities = [key, alias, ...(!model && !capability
        ? [detail.operation_id, detail.action_id, detail.execution_id].filter(Boolean).map(id => `${scope}:operation:${id}`) : [])].filter(Boolean);
      let row = identities.map(id => operations.get(id)).find(Boolean);
      const outcome = presentation.outcome(event, row?.outcome);
      if (model && !detail.call_id && !outcome && !row) return;
      if (!row) {
        const group = working(), view = presentation.createRow({button: true, kind: model ? "model" : "execution"});
        const root = view.item, button = view.title, indicator = view.icon;
        root.classList.add("retained-operation");
        indicator.classList.add("prose-activity-status"); indicator.setAttribute("role", "img");
        group.view.items.append(root);
        row = {...view, root, button, group, indicator, key};
        button.onclick = () => inspect(row.event, root, button);
      }
      for (const identity of identities) operations.set(identity, row);
      row.event = presentation.merge(row.event, event);
      if (detail.command) row.event.command_detail_url = event.detail_url;
      row.root.dataset.eventId = event.id;
      row.root.dataset.operationId = operationId || row.root.dataset.operationId || "";
      if (model && detail.call_id) row.root.dataset.callId = detail.call_id;
      row.outcome = outcome;
      row.indicator.hidden = !outcome;
      if (outcome) prose.setOutcome(row.indicator, outcome);
      row.group.facts.set(row.key, outcome);
      renderRow(row);
    }
    refresh();
  }
  return {event, update(value) { status = value; refresh(); }};
}
