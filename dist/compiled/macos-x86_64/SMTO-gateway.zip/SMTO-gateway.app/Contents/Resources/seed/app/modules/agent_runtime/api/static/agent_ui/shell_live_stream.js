/**
 * @file src/agent_runtime/api/static/agent_ui/shell_live_stream.js
 * @brief Observe retained command output in desktop and mobile disclosure panels.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Bind one viewer to a panel, resume its command cursor, project
 * lifecycle receipts and render a bounded transcript with explicit omission feedback.
 * Boundaries: Rows own panel composition; the server owns command execution, retained
 * output and redaction. Transport loss changes connection presentation, not command truth.
 * Lifecycle: Loaded on disclosure. Each visible, open viewer owns one SSE connection,
 * bounded reconnect attempts, a local status clock and a coalesced animation frame.
 * Closing/hiding suspends observation; DOM removal disposes the viewer. Page listeners
 * and the shared removal observer live for the loaded document's lifetime.
 * State: A module set tracks mounted viewers. Per-viewer cursors/generation reject
 * replay; job snapshots replace text and supersede launch-only lifecycle receipts.
 * Security: Request/operation bindings are checked before rendering inert text. Copy
 * fetches the existing server-projected output endpoint; observing never executes work.
 * Collaborators: app.js, activity_pages.js and the mobile lazy adapter mount this observer;
 * shell_stream.py serves scoped evidence; copy_feedback.js presents clipboard success.
 * Public surface: TRANSCRIPT_LIMIT bounds the preview to 256K code units;
 * mountShellInspector returns the panel's viewer with update/reconcile/suspend/dispose.
 * @see src/agent_runtime/api/static/agent_ui/activity_pages.js
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/lazy/shell_live_stream.js
 * @see src/agent_runtime/api/agent_ui_support/shell_stream.py
 * @see src/agent_runtime/api/static/agent_ui/copy_feedback.js
 */
import "./number_odometer.js?v=20261015-smto";
export const TRANSCRIPT_LIMIT = 256 * 1024;
const viewers = new Set();
/** Create inert output/status nodes; transcript content is never parsed as markup. */
const node = (tag, className, text = "") => {
  const element = document.createElement(tag);
  element.className = className; element.textContent = text;
  return element;
};
const labels = {starting: "Starting", queued: "Queued", running: "Running",
  running_background: "Running in background", waiting_for_input: "Waiting for terminal input",
  waiting_for_resource: "Waiting for resource · Not started",
  completed: "Completed", cancelled: "Cancelled", timed_out: "Timed out", failed_to_start: "Failed to start",
  outcome_unknown: "Outcome unknown", running_in_terminal: "Running in terminal · live output unavailable",
  stream_unavailable: "Retained output is no longer available"};
/** Clamp receipt age at zero for clock skew; this value describes presentation only. */
const seconds = timestamp => Math.max(0, Math.floor((Date.now() - Date.parse(timestamp)) / 1000));
/** Format elapsed seconds as minutes/seconds without imposing an hour rollover. */
const duration = value => `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;

/** Reconcile existing viewers when document visibility or ancestor disclosures change. */
function refreshViewers() { for (const viewer of viewers) viewer.reconcile(); }
document.addEventListener("visibilitychange", refreshViewers);
// A command nested inside a closed Activity/sequence disclosure is not being viewed.
document.addEventListener("toggle", refreshViewers, true);
window.addEventListener("pagehide", () => { for (const viewer of viewers) viewer.suspend(); });
window.addEventListener("pageshow", refreshViewers);
new MutationObserver(records => {
  if (records.some(record => record.removedNodes.length)) {
    for (const viewer of viewers) if (!viewer.disclosure.isConnected) viewer.dispose();
  }
}).observe(document.documentElement, {childList: true, subtree: true});

/** Reuse a panel's observer or bind scoped evidence to it; mounting grants no execution control. */
export function mountShellInspector({disclosure, panel, requestId, operationId, initialEvent}) {
  if (panel.shellViewer) return panel.shellViewer;
  const summary = node("p", "shell-live-summary");
  const status = node("span", "shell-live-status"), metadata = node("span", "shell-live-metadata");
  const clock = node("span", "shell-live-clock"), notice = node("p", "shell-live-notice");
  const loading = node("p", "shell-live-empty output-loading", "Loading output…");
  loading.setAttribute("role", "status");
  const transcript = node("pre", "shell-live-transcript"), actions = node("div", "shell-live-actions");
  const copy = node("button", "shell-live-copy", "Copy output"), jump = node("button", "shell-live-jump", "Jump to latest");
  const copied = window.SMTOCopyFeedback.bind(copy);
  const retry = node("button", "shell-live-retry", "Reconnect");
  for (const button of [copy, jump, retry]) button.type = "button";
  jump.hidden = true; retry.hidden = true; notice.hidden = true;
  transcript.tabIndex = 0; transcript.setAttribute("aria-label", "Command output");
  panel.classList.add("shell-live-panel"); panel.setAttribute("aria-live", "off");
  summary.append(status, metadata, clock);
  actions.append(copy, jump, retry); panel.append(summary, notice, loading, transcript, actions);
  let source = null, reconnectTimer = 0, clockTimer = 0, frame = 0, attempt = 0;
  let cursor = 0, generation = "", text = "", following = true, omitted = false;
  let disposed = false, ended = false, exhausted = false, transport = "not connected";
  let commandState = "starting", startedAt = null, lastOutputAt = null, endedAt = null, exitCode = null;
  let lifecycleId = 0;
  let jobOutputState = null;

  /** Observe only attached, visible panels whose complete disclosure ancestry is open. */
  function wanted() {
    if (disposed || !disclosure.isConnected || document.hidden || window.SMTOUiFind?.isRevealed(disclosure)) return false;
    for (let element = disclosure; element; element = element.parentElement) {
      if (element.hidden || (element.tagName === "DETAILS" && !element.open)) return false;
    }
    return true;
  }
  /** Project command receipts separately from connection state and local elapsed-time labels. */
  function renderStatus() {
    const exit = exitCode !== null ? ` · exit ${exitCode}` : "";
    status.textContent = `${labels[commandState] || "Outcome unknown"}${exit} · ${transport}`;
    const age = lastOutputAt ? seconds(lastOutputAt) : startedAt ? seconds(startedAt) : 0;
    const quiet = commandState === "running" ? lastOutputAt && age < 3 ? "Receiving output"
      : `No output for ${age}s` : "";
    const elapsed = startedAt && (!jobOutputState || jobOutputState === "pending" || endedAt) ? duration(endedAt
      ? Math.max(0, Math.floor((Date.parse(endedAt) - Date.parse(startedAt)) / 1000)) : seconds(startedAt)) : "";
    const outputStatus = jobOutputState === "pending" ? "Output available after job completion"
      : jobOutputState === "unavailable" ? "Captured output unavailable"
        : jobOutputState === "partial" ? "Captured output incomplete"
          : jobOutputState === "retained" ? text ? "Captured output" : "No output"
            : lastOutputAt ? `Last output ${age}s ago` : "No output received";
    window.SMTONumberOdometer.render(clock,
      [elapsed && `Elapsed ${elapsed}`, outputStatus, quiet].filter(Boolean).join(" · "));
    retry.hidden = !exhausted;
    const waiting = !ended && !exhausted;
    loading.hidden = Boolean(text);
    loading.classList.toggle("output-loading", waiting);
    const emptyMessage = waiting ? jobOutputState === "pending" ? "Waiting for job output…" : "Loading output…"
      : exhausted ? "Output connection lost. Reconnect to try again."
        : ["stream_unavailable", "outcome_unknown", "running_in_terminal"].includes(commandState)
          || jobOutputState === "unavailable" ? "Output is unavailable." : "No output.";
    if (loading.textContent !== emptyMessage) loading.textContent = emptyMessage;
    transcript.hidden = !text;
    panel.dataset.commandState = commandState; panel.dataset.transport = transport;
  }
  /** Paint the bounded transcript and omission marker, retaining the user's follow preference. */
  function render() {
    frame = 0;
    transcript.textContent = text;
    notice.hidden = !omitted;
    notice.textContent = "Earlier output omitted from this preview";
    renderStatus();
    if (following) transcript.scrollTop = transcript.scrollHeight;
    jump.hidden = following;
  }
  /** Batch receipt bursts into one pending paint instead of rendering every SSE frame. */
  function scheduleRender() { if (!frame) frame = requestAnimationFrame(render); }
  /** Release transport, backoff and clock ownership without discarding retained evidence. */
  function stop(message) {
    source?.close(); source = null;
    clearTimeout(reconnectTimer); reconnectTimer = 0;
    clearInterval(clockTimer); clockTimer = 0;
    transport = message; renderStatus();
  }
  /** Apply ordered command receipts until a job snapshot supplies the authoritative outcome. */
  function update(event) {
    const d = event?.detail || {}, type = event?.event_type || "";
    if (!type.startsWith("execution.command.")) return;
    if (jobOutputState) return; // The job receipt supersedes its launch-only command trace.
    if (Number(event?.id || 0) < lifecycleId) return;
    lifecycleId = Number(event?.id || 0);
    if (type.endsWith(".started")) {
      commandState = "running"; startedAt = event.timestamp;
      metadata.textContent = [d.gateway_node || d.gateway_label, d.cwd].filter(Boolean).join(" · ");
    }
    if (type.endsWith(".terminal_input_required")) commandState = "waiting_for_input";
    if (type.endsWith(".resource_wait")) commandState = "waiting_for_resource";
    if (type.endsWith(".resource_admitted")) commandState = "running";
    if (type.endsWith(".completed")) {
      exitCode = d.exit_code ?? null; endedAt = event.timestamp;
      commandState = d.terminal_detached && d.process_state === "running" ? "running_in_terminal"
        : ["cancelled", "timed_out", "failed_to_start", "outcome_unknown"].includes(d.process_state) ? d.process_state
          : d.executed === false ? "failed_to_start"
            : d.error_kind === "unknown_effect" || d.status === "outcome_unknown" ? "outcome_unknown"
              : d.process_state === "exited" || Number.isInteger(d.exit_code) ? "completed" : "outcome_unknown";
    }
    scheduleRender();
  }
  /** Back off a lost observation at most five times; never infer execution failure from it. */
  function fail() {
    stop("Live output connection lost · command state unchanged");
    if (!wanted() || ended) return;
    if (attempt >= 5) { exhausted = true; renderStatus(); return; }
    transport = "Reconnecting live output…"; renderStatus();
    reconnectTimer = setTimeout(() => { reconnectTimer = 0; connect(); }, Math.min(1000 * 2 ** attempt++, 15000));
  }
  /** Open scoped observation from the retained cursor only while this viewer needs evidence. */
  function connect() {
    if (!wanted() || source || reconnectTimer || ended || exhausted) return;
    transport = "connecting"; renderStatus();
    if (!clockTimer) clockTimer = setInterval(renderStatus, 1000);
    const params = new URLSearchParams({after_id: String(cursor)});
    if (generation) params.set("trace_created_at", generation);
    const url = `/api/agent/trace/${encodeURIComponent(requestId)}/commands/${encodeURIComponent(operationId)}/stream?${params}`;
    let current;
    try { current = new EventSource(url); } catch (_) { fail(); return; }
    source = current;
    /** Ignore obsolete/hidden transports; malformed or misbound frames use the retry path. */
    const listen = (name, handler) => current.addEventListener(name, event => {
      if (source !== current || !wanted()) return;
      try { handler(JSON.parse(event.data)); } catch (_) { fail(); }
    });
    current.addEventListener("open", () => {
      if (source !== current) return;
      transport = "stream connected"; renderStatus();
    });
    current.addEventListener("error", () => { if (source === current) fail(); });
    listen("shell.cursor", data => {
      if (data.request_id !== requestId || data.operation_id !== operationId) throw window.SMTOErrors.error("ui_state_stale");
      if (data.reset) {
        cursor = 0; text = ""; omitted = false; lifecycleId = 0;
        commandState = "starting"; startedAt = lastOutputAt = endedAt = exitCode = null;
        jobOutputState = null;
        scheduleRender();
      }
      generation = data.trace_created_at;
    });
    listen("shell.event", event => {
      if (event.request_id !== requestId || String(event.detail?.operation_id || event.detail?.action_id) !== operationId)
        throw window.SMTOErrors.error("ui_state_stale");
      const id = Number(event.id);
      if (!Number.isSafeInteger(id) || id <= 0) throw window.SMTOErrors.error("ui_state_stale");
      if (id <= cursor) return;
      cursor = id; attempt = 0;
      const d = event.detail || {}, type = event.event_type;
      if (["execution.command.stdout", "execution.command.stderr", "execution.command.error", "execution.command.cancelled", "execution.command.terminal_input_required"].includes(type) && typeof d.text === "string") {
        text += d.text;
        if (text.length > TRANSCRIPT_LIMIT) { text = text.slice(-TRANSCRIPT_LIMIT); omitted = true; }
        if (d.text && ["execution.command.stdout", "execution.command.stderr"].includes(type)) lastOutputAt = event.timestamp;
        scheduleRender();
      }
      update(event);
    });
    listen("shell.snapshot", data => {
      if (data.request_id !== requestId || data.operation_id !== operationId) throw window.SMTOErrors.error("ui_state_stale");
      // Replace instead of appending: reconnects replay the same retained receipt.
      text = String(data.text || "");
      omitted = Boolean(data.output_omitted) || text.length > TRANSCRIPT_LIMIT;
      text = text.slice(-TRANSCRIPT_LIMIT);
      jobOutputState = data.output_state;
      commandState = data.command_state;
      startedAt = data.started_at; endedAt = data.ended_at;
      lastOutputAt = data.last_output_at; exitCode = data.exit_code ?? null;
      attempt = 0; scheduleRender();
    });
    listen("heartbeat", data => {
      cursor = Math.max(cursor, Number(data.after_id) || 0); attempt = 0;
      transport = "stream connected"; renderStatus();
    });
    listen("shell.end", data => {
      cursor = Math.max(cursor, Number(data.after_id) || 0);
      commandState = data.capture_state || "outcome_unknown";
      startedAt = data.started_at || startedAt; lastOutputAt = data.last_output_at || lastOutputAt;
      endedAt = data.ended_at || endedAt; exitCode = data.exit_code ?? exitCode;
      ended = true; stop("capture ended"); scheduleRender();
    });
  }
  transcript.addEventListener("scroll", () => {
    following = transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 32;
    jump.hidden = following;
  }, {passive: true});
  jump.addEventListener("click", () => { following = true; render(); });
  copy.addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Copying shell output…", copy);
        try {
    try {
      const response = await (window.SMTOAuth?.fetch || window.fetch)(`/api/agent/trace/${encodeURIComponent(requestId)}/commands/${encodeURIComponent(operationId)}/copy`, {cache: "no-store"});
      if (!response.ok) throw new Error("Output unavailable");
      await navigator.clipboard.writeText(await response.text()); copied();
    }
    catch (_) { copy.textContent = "Could not copy output"; }

        } finally { busyFeedback?.finish(); }
      });
  retry.addEventListener("click", () => { attempt = 0; exhausted = false; connect(); });
  const viewer = {disclosure, update,
    /** Follow DOM/visibility ownership, preserving terminal capture without reopening it. */
    reconcile() {
      if (!disclosure.isConnected) { viewer.dispose(); return; }
      if (wanted()) {
        if (ended) { transport = "capture ended"; renderStatus(); }
        else connect();
      } else stop(document.hidden ? "suspended while hidden" : "closed by user");
    },
    /** Pause observation for pagehide while keeping cursor/text available on pageshow. */
    suspend() { stop("suspended while hidden"); },
    /** Permanently release a detached panel and cancel its pending paint. */
    dispose() { disposed = true; stop("closed"); cancelAnimationFrame(frame); viewers.delete(viewer); },
  };
  panel.shellViewer = viewer; viewers.add(viewer);
  if (initialEvent) update(initialEvent);
  viewer.reconcile();
  return viewer;
}
