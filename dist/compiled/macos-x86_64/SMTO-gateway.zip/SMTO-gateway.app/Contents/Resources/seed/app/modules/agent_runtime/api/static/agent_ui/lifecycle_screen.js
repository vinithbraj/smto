/* Startup and shutdown share the same full-page document. The modal cannot be dismissed. */
(() => {
  'use strict';
  const script = document.currentScript;
  const prefix = new URL(script.src).pathname.split('/agent-ui/static/')[0];
  let dialog, frame, previousInstance, pendingAction, timer, polling = false, requestUncertain = false;
  function accepted(action) {
    pendingAction = action;
    if (action) requestUncertain = false;
    previousInstance = action?.previous_instance_id || previousInstance;
    frame?.contentWindow?.postMessage({type: 'smto:restart-accepted', previous_instance_id: previousInstance}, location.origin);
  }
  function begin(action) {
    if (dialog) { if (action) accepted(action); return; }
    document.documentElement.dataset.shutdown = 'true';
    const dot = document.getElementById('connection-indicator');
    if (dot) { dot.dataset.state = 'restarting'; dot.title = 'Shutting down'; dot.setAttribute('aria-label', 'Shutting down'); }
    dialog = document.createElement('dialog');
    dialog.setAttribute('aria-label', 'Workspace shutdown and startup');
    dialog.style.cssText = 'position:fixed;inset:0;max-width:none;max-height:none;width:100%;height:100dvh;margin:0;padding:0;border:0;overflow:hidden;background:var(--bg,#fff)';
    dialog.addEventListener('cancel', event => event.preventDefault());
    frame = document.createElement('iframe'); frame.title = 'Workspace shutdown and startup';
    frame.style.cssText = 'display:block;border:0;width:100%;height:100%';
    frame.src = prefix + '/shutdown';
    frame.addEventListener('load', () => { accepted(pendingAction); if (requestUncertain) uncertain(); });
    dialog.append(frame); document.body.append(dialog); dialog.showModal();
    accepted(action);
  }
  function cancel() {
    dialog?.close(); dialog?.remove(); dialog = frame = null; pendingAction = null; requestUncertain = false;
    delete document.documentElement.dataset.shutdown;
    clearTimeout(timer); void poll();
  }
  function uncertain() {
    if (!dialog) return;
    requestUncertain = true;
    frame?.contentWindow?.postMessage({type: 'smto:restart-uncertain'}, location.origin);
  }
  window.addEventListener('message', event => {
    if (event.origin === location.origin && event.source === frame?.contentWindow
        && event.data?.type === 'smto:lifecycle-ready') location.reload();
  });
  async function poll() {
    if (polling || document.hidden || dialog) return;
    polling = true;
    try {
      const response = await (window.SMTOAuth?.fetch || window.fetch)(prefix + '/api/startup?view=summary', {cache: 'no-store', signal: AbortSignal.timeout(3000)});
      if (response.ok) {
        const state = await response.json();
        previousInstance = state.instance_id || previousInstance;
        if (state.lifecycle === 'shutdown' || state.status === 'initializing') begin();
      }
    } catch { /* Existing connection indicators own transient connection failures. */ }
    finally { polling = false; if (!dialog) timer = setTimeout(poll, 1000); }
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { clearTimeout(timer); void poll(); } });
  window.addEventListener('pageshow', () => { clearTimeout(timer); void poll(); });
  window.addEventListener('pagehide', () => clearTimeout(timer));
  window.SMTOLifecycle = {begin, accepted, cancel, uncertain};
})();
