---
id: architecture-request-lifecycle
title: Agent and request lifecycle
kind: architecture
tags: [architecture, tools]
order: 2
---
# Agent and request lifecycle

The API validates the request and attaches trusted gateway, conversation, credential and approval context. `RuntimeHost.handle_request` prepares the request; `AgentLoop.run` sends the current transcript and the currently advertised tool schemas to the model.

Request admission resolves the selected model before materializing the execution
configuration. The run saves its resolved override map, profile, version and output
reservation. Normal model decisions merge only explicit execution overrides;
Provider Default fields stay absent from the provider request. Task Contract,
recovery and summary calls retain their internal generation policies. See
[Model Configuration](../25-model-configuration.md) and
[saved inference identity](07-state.md).

Each accepted model call follows one sequence: validate envelope and arguments, check budget and scope, persist a dispatch claim, execute or perform a built-in control, persist the real result, append its observation to the same transcript, and ask the same model for the next decision. An invalid call returns an error observation for local correction. A dispatch whose external effect is unknown cannot be blindly replayed.

During native inference, the provider response arrives incrementally. smTO
privately assembles content and native tool-call fragments, then applies the same
complete-response validation. The existing trace SSE connection carries bounded,
content-free receipt events to the status strip. “Thinking · receiving…” means
provider data recently arrived; after three seconds without a receipt it returns
to “Thinking…”. Tool activity starts only after a validated invocation begins.

The compact **LLM stream activity** waveform beneath that status shows when
smTO receives streamed response data from the active model. Higher activity
represents more stream events arriving within the display interval. A flat line
means no model stream data was received during that interval. It does not represent
model reasoning quality, GPU utilization, task completion percentage or hidden
model thought.

The **Timeline** toggle beside **Trace / Tokens/s** shows or hides the Thinking and tool
activity chips. The graph and timing totals remain visible, and activity continues to be
recorded while the timeline is hidden. This preference is saved across reloads and browser
sessions, and is also available as **Show wavelet timeline** under **Settings → UI Preferences**.

While a response is running, the elapsed timer shows time spent on that response.
After completion, the conversation total appears separately and excludes time
between responses.

Each completed response shows its elapsed time followed by **tokens read | tokens
generated**, using totals across that request's model calls. These counts also
appear in saved conversations with the wavelet or footer hidden. Provider counts
take precedence; estimated counts use **≈**, and unavailable counts use **—**.
Generated tokens can include reasoning and tool-call output reported by the model.
Each total also shows its average rate in **tokens/s**, computed as tokens divided
by the summed model request time of finished calls with matching counts and timings.
These averages exclude tool execution, idle time and in-flight calls, include stopped
attempts with recorded usage and timing, and survive refresh and resume. Request time
includes transport and prefill; these are observed request rates rather than GPU
prefill or decode speeds. Estimated rates use **≈**; missing timings show **—**.

Every validated native SSE data event counts, including private tool-call fragments,
answer fragments and completion metadata. SSE comments, framing and the `[DONE]`
sentinel do not count. Only timestamps and counts enter the graph payload; text,
reasoning, tool names, arguments, credentials and partial JSON never do. Receipt
counts use 100 ms buckets and travel in the existing `llm.response.progress` channel
at most four times per second, plus a final flush. A pending timer flushes the last
burst even if the provider becomes silent. No zero-only server events are needed.

The LLM stream activity graph is a continuously moving rolling timeline. It remains
visible throughout the Agent session and shows actual model stream-data arrival as
activity and silence as a zero baseline. One page-owned ring retains 600 samples
(60 seconds at 100 ms per sample), refreshing at most ten times per second. New
samples enter at the right; old history leaves at the left. The browser advances
zero buckets during silence, including a disconnected trace stream. Background tabs
suspend painting and catch up to wall-clock time when visible again.

The timeline synchronizes to the server's existing `generated_at_ms` timestamp at
startup and when returning to the tab. It then advances using monotonic browser
elapsed time. Receipt timestamps and “receiving” freshness use that same clock, so
a different clock on a remote computer or phone cannot discard valid activity.
CPU/GPU measurement values never enter the LLM graph.

The graph does not reset between model calls. Tool execution and waiting periods
appear as flat sections because no LLM stream data is arriving. Completion leaves
the recent trace visible; a new task shares the same history, including the idle gap.
Only rolling-window expiry removes old activity. The compact status strip stays
mounted, with “Ready” when idle and the current outcome after completion.

The height uses a rolling logarithmic count scale with a minimum visible height for
a nonzero bucket; zero remains exactly zero. Cumulative counts replace earlier counts
for the same call and interval, so replay cannot add duplicate spikes. Different calls
in one interval contribute separately. Late receipts fill their original recent bucket.
Available retained trace activity restores recent history on reload; no extra telemetry
database or per-token persistence is used. The SVG is decorative, with one static
accessible description and no sample announcements.

In **Tokens/s**, the color selector offers **teal input / blue output** or
**purple input / red output**. The selected palette is saved for this browser tab,
survives reloads and stays the same when the page switches between day and night themes.
Both series use solid lines, matching translucent fills and a one-second rolling average,
with separate **Input** and **Output** readouts. Output includes reasoning and tool output.
The left axis scales input and the right axis scales output independently
to their peaks over the visible minute, keeping both graphs legible when their rates
differ greatly. Each axis is labeled and uses the color of its series.

Input prefers numerical provider telemetry. Live processing progress appears before
output starts and preserves the reported batch intervals and pauses. Final processing
durations can replace an earlier estimate, anchored at the first output receipt rather
than response completion. That timestamp alignment still includes transport latency.
Reported cached tokens are excluded from processing throughput. The input legend shows
**Measured**, **Est.**, or **Mixed** for the visible history; output arrival timing remains
estimated, with its total count calibrated to final provider usage. Both curves are
one-second averages: a subsecond burst can differ from the provider's average processing
speed over its shorter active interval.

A third, solid amber line labeled **ctx** shows context remaining over the same minute on a fixed
0–100% scale, with no separate percentage axis. It uses the same latest recorded usage and output
reservation as the context meter: it falls as the working context grows and can
rise after compaction. Between usage updates it holds the last known percentage;
unknown context stays blank. Switching conversations clears the plotted context
history so values from different conversations are not connected.

The OpenAI-compatible adapter reads llama.cpp `timings` / `prompt_progress`, Groq
`usage.prompt_time` (including streamed `x_groq.usage`), and Ollama evaluation diagnostics
when a compatible gateway forwards them. Standard cached-token details and DeepSeek
`prompt_cache_hit_tokens` are recognized. Only positively identified llama.cpp endpoints
receive the optional live-progress flags; explicit setup rejections remove unsupported
flags through the existing compatibility negotiation. Other endpoints need no extension
to retain the fallback graph. This does not add a native Ollama or Anthropic protocol.

Without processing timings, reported or estimated uncached input tokens are spread over
request transmission to first output, including reasoning. This remains labeled estimated:
provider waiting and transport are not pure processing time. vLLM TTFT and aggregate
server metrics are not relabeled as prompt-processing measurements. Native transport
excludes tokenizer preparation and local slot waiting from this fallback interval.
Missing usage retains the estimate; malformed optional diagnostics are ignored.
Corrections replace the old call's entire interval, including zero-token corrections,
and replay cannot duplicate or restore stale estimates. Calls with neither provider
progress nor observed streamed output have no invented input-rate curve.

In **Trace**, prompt processing and generation pauses remain flat. Non-streaming fallback stays
flat for the whole call, including its final complete response. The waveform also
continues during safe answer streaming, and has no role in dispatch, completion,
permissions, budgets, model configuration or timeout decisions.

The explicit completion control is `finish_task`: `answered` for information
and requested source-code artifacts, `completed` for completed action/data work, or
the existing incomplete statuses. No-tool answers need no evidence; tool-grounded
answers cite real operation receipts. Code-only artifacts are not executed.

The final answer can appear progressively while the model generates it. Once the exact
registered `finish_task` identity is established, a presentation-only extractor
decodes its top-level `message` string. The existing trace SSE connection carries
cumulative safe text through `llm.response.delta`; the status strip changes to
“Generating…”. Plain assistant content can stream only for internal calls advertising
no tools. The Agent always has `finish_task`; tool-enabled content stays private.
Eligible terminal prose receives credential checks and ordinary completion/output
validation through `terminal_normalization.py`; it can preserve a verified answer
without a formatting-only model turn. Ambiguous work or unresolved presentation
intent can still require explicit correction. Optional direct completion metadata
on a capability call is validated after its durable result exists. Neither path
fabricates an execution receipt. See
[completion normalization](27-completion-normalization.md).

Every preview passes a credential holdback guard using the existing protected values
and encoded variants before publication. Hidden reasoning, raw native arguments,
completion status/evidence metadata and executable decisions remain private. The
preview cannot authorize an operation or complete a task: the full native response,
argument schema and completion evidence must still validate normally. Accepted final
text replaces the same answer block. Rejection, cancellation or retry clears the
preview; reconnect/reload restores cumulative text without restarting inference.
Streaming follows the chat viewport only while the reader is near the bottom.

Streaming is automatic, with no preference or Behavior Effort setting. A provider
that explicitly rejects compatible streaming before generation can fall back once
to the ordinary transport, within the same reserved model decision. That capability
result is cached for the client’s endpoint/model. A broken or incomplete stream
stops the inference without a hidden retry. Cancellation is checked between received
lines; a blocked network read remains subject to the existing socket timeout.

`finish_task` carries the model's completion judgment. Deterministic checks reject missing or failed receipts, unfinished caller requirements, stale observations when current evidence is requested, and exact-value mismatches. They do not invent a new completion strategy.

`ask_user`, jobs, events, OAuth and budget pauses checkpoint the run. Resume continues that run with actual updates. Process waiting does not consume inference calls.

Whenever the model requires an ordinary reply to continue, it must call
`ask_user` alone. A top-level decision mixing that control with sibling tools is
rejected before any effect or receipt claim. Final communication uses `finish_task`;
OAuth authorization and protected-action approvals use their protocol controls.

A pending `ask_user` pauses parent inference even when explicitly scheduled as an
Activity. Already-declared independent graph branches and background jobs may
progress under existing dependency, resource and approval rules. Dependent branches
wait for the answer. The inline answer addresses the selected checkpoint once.
The parent `waiting_user` status describes the inference checkpoint; it does not
mean that every independent Activity has stopped.

If a user's reply determines the next action of this run, that question belongs in
`ask_user`, not `finish_task.message`. Terminal messages must remain truthful and
complete if the user never replies. Genuine external blockers and partial results
may end declaratively; optional future suggestions and quoted questions remain valid.
Before terminal acceptance, a narrow deterministic guard rejects explicit same-run
continuation requests. The existing protocol recovery allows one correction to
`ask_user` or a declarative `finish_task`, without replaying operations or consuming
the completion-evidence retry budget. Rejected prose is removed from the answer view.

Removable destination choices use this same checkpoint. For supported USB/removable
destination requests, unresolved targets consult current Gateway mount facts. An explicit
user path uses ordinary path validation without an ambiguity scan; a selected volume
binding retains identity revalidation. One eligible mount selects automatically; multiple
eligible mounts require an inline reply before writing. Filesystem type, free space
and enumeration order are not intent. The reply selects a persisted choice and the
Gateway revalidates its mount/device identity before the next ordinary decision.
Earlier artifacts and receipts remain intact. Missing or replaced destinations never
cause a fallback to another drive. Current automatic OS discovery supports Linux;
unsupported discovery returns unavailable rather than inventing a destination.

When the current run is `waiting_user` or `awaiting_clarification`, the main composer
temporarily says **Reply to me…**. Send answers that run through
`/api/agent/clarification/<request_id>`, preserving its task, Gateway, model and policy
snapshots. The clarification card uses the same action. Replies are not reusable task
drafts or queued prompts. Required choices use their option buttons. Authentication values
use ordinary replies; OAuth browser/device authorization has protocol controls. Approval waits use explicit Approve/Deny controls.
Typing “yes” in the composer does not grant approval.

Agent mode still creates independent ordinary tasks. Conversation mode still carries
conversational context. Active interactions continue the exact run in either mode;
answering a question never changes the selected mode.

The clarification projection includes the observed operation identity and, for a
promoted Activity, its Activity identity. Both reply endpoints share native input
validation under a SQLite writer transaction. Activity answers enter the existing
`activity_input` wake journal before HTTP acceptance; owned resume appends the answer
and its consumption marker in one checkpoint. It completes the Activity and clears
`waiting_activity_id` before continuing. Generic clarification does not append it again.
Direct answers retain their existing clarification context durably until consumption.
Direct checkpoint writes reject while another owner is active so that accepted text
cannot be overwritten. Duplicate, stopped, paused or replaced interactions reject
without starting inference. Legacy direct clients may omit operation identity; current
clients include it, and promoted Activity replies require it.

Reload reconstructs the same question from native state. Restart before input leaves
inference paused; restart after input acceptance consumes the persisted answer. Manual
Pause retains the interaction and defers consumption until Resume. Background job
completion reconciles receipts while the human wait remains active. No schema migration
is needed: existing checkpoints, contexts and wake events own these transitions. Outside an interaction wait,
the server-owned task queue and captured task configuration remain in use. Its
[admission rules](19-scheduling.md#top-level-tasks) determine which tasks can run.

Conversation and Advisory modes share history. Advisory exposes informational controls and cannot execute external tools. Agent mode uses the full authorized tool loop. The canonical execution mode ID is `agent`.

## Authentication questions and replies

`ask_user` uses one ordinary question and one reply for all missing information,
including usernames, passwords, tokens and client secrets. Ask for related values
together. The unchanged reply reaches the next normal Agent decision, which supplies
literal tool arguments. No helper inference, parser, password vault or hidden retry
is involved. An actual missing/rejected credential result remains an ordinary tool
result; it does not create a separate wait. OAuth browser/device authorization uses
`waiting_user` with `oauth_authorization_request`. Current OAuth expiry recovery lives in
`native/http_session_state.py`; pre-baseline credential-wait records are unsupported.

## Accepted monitoring snapshot

The global `disabled_agent_check_monitoring_enabled` preference is captured alongside the existing guard policy when a request, queued submission, conversation task or event is accepted. Request-owned prepared policy storage prevents a later Settings edit from changing accepted work. Public model/tool arguments cannot supply this authority. Native initialization, resume and continuation use the saved value; missing legacy values resolve OFF.

The snapshot only enables local diagnostic assessment of disabled checks. It does not add model turns, change the accepted tool catalog or trigger a scan/replay when Settings changes.

## Accepted Activity supervision and attention

Global and conversation supervision settings are captured at acceptance for requests,
prepared/queued submissions, tasks and scheduled events. Continuation and restart carry
the accepted snapshot. Later Settings edits affect future acceptance. Older runs and
prepared submissions receive the product defaults once; model arguments cannot supply
watchdog authority. The settings surface provides enablement, healthy cadence and the
attention threshold; the API validates the complete ordered policy. Health settings never
control the runtime-owned completion clock. Short managed commands return to their
attached Agent turn; only genuinely detached work uses continuation and health attention.

An observation worker can persist physical evidence and attention while the parent
Agent is running or waiting. It never mutates an in-flight model request. At the next
safe decision boundary, attention joins the existing continuation context. After the
normal Agent-turn lease is acquired, dispatch rechecks Stop, completion and recovery.
An attention-only continuation that no longer needs judgment returns to its durable
wait without calling the model. Acceptance of the decision consumes only matching
attention generations in the fenced checkpoint transaction.

An attention wake from a machine wait creates a durable, versioned recovery episode.
It retains the original predicate, selected identities, absolute deadline, resume note,
and run/epoch/amendment identity. Acknowledgement does not erase that wait. The episode
allows three decision attempts, including rejected decisions, decision-loop retries and
cached proposals; the allowance is saved before dispatch and included in model context.
Transport retries and existing permission, batch and execution limits keep their owners.

After reconciliation, cleared faults or exhausted allowances restore the saved wait
without another model call. Accepted recovery operations retain their identities and
receipts; pending operations continue under normal activity tracking. Completion and
expired deadlines are evaluated before attention and before restoration, using the
normal wake/receipt path. Restoration never restarts a timeout. Explicit replacement
waits supersede the saved predicate. User intervention, human checkpoints, Pause, Stop
and terminal states retain precedence. Running tasks receiving attention do not acquire
an artificial wait. SQLite and memory-backed stores use the same fenced lifecycle;
restart cannot replenish attempts. Legacy silence-only alarms are suppressed, and an
old resume note alone is never used to reconstruct a wait.

These bounds do not depend on optional repeated-read or no-progress guards, shell
command similarity, or prompt caching.

Terminal jobs continue through the existing receipt and completion mailbox. Attention
is nonterminal and does not create another completion channel. Human input, user
amendments, Stop and existing completion delivery retain their precedence.
