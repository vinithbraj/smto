/* Mobile projection of the existing target ID contract; no desktop menu code. */
  const MAX = 16;
  const fields = ["gateway_id", "gateway_label", "gateway_locality"];
  /** Translate registry locality into the existing user-facing location label. */
  const localityName = value => ({local: "Local", remote: "Remote", unknown: "Unknown location"})[value] || "Unknown location";
  /** Bound public metadata and remove control characters before DOM presentation. */
  const text = (value, limit) => typeof value === "string" ? value.replace(/[\x00-\x1f\x7f]/g, "").slice(0, limit) : "";
  /** Accept the bounded word-leading registry ID syntax used by selection requests. */
  const idValid = value => typeof value === "string" && /^[\w][\w.-]{0,159}$/.test(value);
  /** Represent an explicitly empty composer; this value is never a valid submission. */
  const empty = () => ({schema_version: 1, gateway_ids: [], primary_gateway_id: ""});
  /** Detach nested presentation and intent objects from their state owner. */
  const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
  /** Accept only legacy public presentation fields, including saved unavailable targets. */
  function safeSnapshot(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)
      || Object.keys(value).some(key => !fields.includes(key)) || !idValid(value.gateway_id)
      || typeof value.gateway_label !== "string" || value.gateway_label.length > 240
      || /[\x00-\x1f\x7f]/.test(value.gateway_label)
      || !["local", "remote", "unknown"].includes(value.gateway_locality)) return null;
    return Object.fromEntries(fields.map(key => [key, value[key]]));
  }
  /** Empty scope is a draft state only; the server contract requires 1..16 IDs. */
  function safeSelection(value, allowEmpty = false) {
    if (!value || value.schema_version !== 1 || Array.isArray(value)
      || Object.keys(value).some(key => !["schema_version", "gateway_ids", "primary_gateway_id"].includes(key))
      || !Array.isArray(value.gateway_ids) || value.gateway_ids.length > MAX
      || !value.gateway_ids.every(idValid) || new Set(value.gateway_ids).size !== value.gateway_ids.length
      || (value.gateway_ids.length ? !value.gateway_ids.includes(value.primary_gateway_id)
        : !allowEmpty || value.primary_gateway_id !== "")) return null;
    return {schema_version: 1, gateway_ids: [...value.gateway_ids], primary_gateway_id: value.primary_gateway_id};
  }
  /** Validate the complete persisted draft projection, rejecting unknown authority fields. */
  function safeDraft(value) {
    if (!value || value.schema_version !== 2 || Array.isArray(value)
      || Object.keys(value).some(key => !["schema_version", "gateway_selection", "gateways"].includes(key))) return null;
    const scope = safeSelection(value.gateway_selection, true);
    if (!scope || !Array.isArray(value.gateways) || value.gateways.length !== scope.gateway_ids.length) return null;
    const gateways = value.gateways.map(safeSnapshot);
    if (gateways.some((item, index) => !item || item.gateway_id !== scope.gateway_ids[index])) return null;
    return {schema_version: 2, gateway_selection: scope, gateways};
  }
  /** Project immutable native scope without retaining target transports or credentials. */
  function fromNative(state) {
    const authority = state?.authority;
    if (!authority) return null;
    const node = text(authority.gateway_node || authority.node || authority.gateway_defaults?.node, 160);
    const id = text(authority.gateway_id, 160);
    if (!id && !node) return null;
    const scope = safeSelection(authority.gateway_selection || state.gateway_selection);
    return {gateway_id: id, gateway_label: node || "Execution Gateway", gateway_locality: "unknown",
      ...(scope ? {gateway_selection: scope} : {})};
  }
  /** Shared desktop/mobile intent owner. All mutations copy scope and obey steering locks. */
  function createState({onChanged = () => {}, announce = () => {}, isSteering = () => false} = {}) {
    let scope = null, presentations = [], records = [], loaded = false, failed = false, defaultId = "";
    /** Find a selected identity in the most recently verified registry projection. */
    const find = id => records.find(item => item.gateway_id === id);
    /** Refresh a selected label while retaining saved presentation for deleted identities. */
    const display = id => {
      const record = find(id);
      return record ? {gateway_id: id, gateway_label: record.label, gateway_locality: record.locality}
        : presentations.find(item => item.gateway_id === id)
          || {gateway_id: id, gateway_label: "Unavailable Gateway", gateway_locality: "unknown"};
    };
    /** Return an independent ordered ID scope, including an empty draft when unset. */
    const gatewaySelection = () => copy(scope || empty());
    /** Expose primary presentation for existing single-Gateway callers. */
    const selection = () => scope?.primary_gateway_id ? {...display(scope.primary_gateway_id)} : null;
    /** Persist only ordered IDs and safe selected labels with a versioned envelope. */
    const draftSnapshot = () => ({schema_version: 2, gateway_selection: gatewaySelection(),
      gateways: (scope?.gateway_ids || []).map(id => ({...display(id)}))});
    /** Refresh saved labels before notifying the draft owner and accessible status region. */
    function changed(message = "", edited = true) {
      presentations = draftSnapshot().gateways;
      onChanged(edited);
      if (message) announce(message);
    }
    /** Validate every captured target without filtering offline or unavailable members. */
    function unavailable(snapshot = null) {
      const captured = snapshot ? (snapshot.gateway_selection || (snapshot.gateway_id
        ? {schema_version: 1, gateway_ids: [snapshot.gateway_id], primary_gateway_id: snapshot.gateway_id} : empty())) : gatewaySelection();
      if (!captured.gateway_ids?.length) return "Choose at least one execution Gateway.";
      if (!safeSelection(captured) || (snapshot?.gateway_id && snapshot.gateway_id !== captured.primary_gateway_id)) return "Invalid execution Gateway selection. Choose your Gateways again.";
      if (!loaded || failed) return "Execution targets could not be verified. Refresh targets before sending.";
      for (const id of captured.gateway_ids) {
        const record = find(id);
        if (!record) return `Target unavailable: ${display(id).gateway_label}. Choose an existing Gateway.`;
        if (record.status === "disabled") return `Target disabled: ${record.label}. Choose an enabled Gateway.`;
      }
      return "";
    }
    /** Replace future intent only with enabled known IDs and one selected primary. */
    function setGatewaySelection(value) {
      const next = safeSelection(value, true);
      if (isSteering() || !next || next.gateway_ids.some(id => !find(id) || find(id).status === "disabled")) return false;
      scope = next; changed(); return true;
    }
    /** Append one enabled Gateway, retaining order and the first selected primary. */
    function addGateway(id) {
      if (isSteering() || !find(id) || find(id).status === "disabled") return false;
      if (scope?.gateway_ids.includes(id)) { announce(`${find(id).label} is already selected.`); return true; }
      if (scope?.gateway_ids.length >= MAX) { announce("Select at most 16 Gateways."); return false; }
      scope = {schema_version: 1, gateway_ids: [...(scope?.gateway_ids || []), id], primary_gateway_id: scope?.primary_gateway_id || id};
      changed(`Added ${find(id).label}, ${localityName(find(id).locality).toLowerCase()}.${scope.gateway_ids.length === 1 ? " Primary Gateway." : ""}`);
      return true;
    }
    /** Remove intent and deterministically promote the first remaining primary. */
    function removeGateway(id) {
      if (isSteering() || !scope?.gateway_ids.includes(id)) return false;
      const name = display(id).gateway_label, primary = scope.primary_gateway_id === id;
      const ids = scope.gateway_ids.filter(value => value !== id);
      scope = {schema_version: 1, gateway_ids: ids, primary_gateway_id: primary ? ids[0] || "" : scope.primary_gateway_id};
      changed(`Removed ${name}.${primary && ids.length ? ` ${display(ids[0]).gateway_label} is now primary.` : ""}${!ids.length ? " Choose at least one execution Gateway." : ""}`);
      return true;
    }
    /** Change only the selected primary, preserving target order and membership. */
    function setPrimaryGateway(id) {
      if (isSteering() || !scope?.gateway_ids.includes(id) || !find(id) || find(id).status === "disabled") return false;
      scope = {...scope, primary_gateway_id: id}; changed(`${display(id).gateway_label} is now primary.`); return true;
    }
    /** Restoring saved intent preserves missing/disabled IDs; only user actions validate membership. */
    function restoreDraftState(value) {
      const saved = value == null ? null : safeDraft(value);
      scope = saved ? saved.gateway_selection : value == null ? null : empty();
      presentations = saved?.gateways || [];
      if (!scope && loaded) scope = find(defaultId)?.status !== "disabled" && find(defaultId)
        ? {schema_version: 1, gateway_ids: [defaultId], primary_gateway_id: defaultId} : empty();
      changed("", false);
    }
    /** Refresh labels and health in place; a changed default never replaces explicit intent. */
    function updateRecords(payload) {
      if (!Array.isArray(payload.gateways)) throw window.SMTOErrors.error("ui_response_invalid");
      const Core = window.SMTOAgentUi;
      records = payload.gateways.filter(raw => raw.presentation).map(raw => ({...raw.presentation,
        secure: Core?.gatewayConnectionSecured?.(raw) === true}))
        .filter(item => safeSnapshot({gateway_id: item.gateway_id, gateway_label: item.label, gateway_locality: item.locality}))
        .map(item => ({gateway_id: item.gateway_id, label: item.label, locality: item.locality,
          status: ["connected", "offline", "degraded", "disabled"].includes(item.status) ? item.status : "unknown",
          node: text(item.node, 160), platform_label: text(item.platform_label, 80), is_default: item.is_default === true, secure: item.secure}));
      loaded = true; failed = false; defaultId = payload.default_gateway_id;
      if (!scope) restoreDraftState(null);
      else changed("", false);
    }
    return {gatewayId: () => scope?.primary_gateway_id || "", gatewayIds: () => [...(scope?.gateway_ids || [])],
      gatewaySelection, selection, draftSnapshot, unavailable, setGatewaySelection, addGateway, removeGateway, setPrimaryGateway,
      setGateway: id => setGatewaySelection({schema_version: 1, gateway_ids: [id], primary_gateway_id: id}),
      submissionSnapshot() { const reason = unavailable(); if (reason) throw window.SMTOErrors.error("ui_composer_not_ready"); return {...selection(), gateway_selection: gatewaySelection()}; },
      restoreDraftState, updateRecords, recordsSnapshot: () => copy(records),
      markFailed() { failed = true; changed("", false); }, isLoaded: () => loaded, isFailed: () => failed,
      isInitialized: () => scope !== null};
  }

export {createState, safeSnapshot, safeSelection, safeDraft, fromNative};
