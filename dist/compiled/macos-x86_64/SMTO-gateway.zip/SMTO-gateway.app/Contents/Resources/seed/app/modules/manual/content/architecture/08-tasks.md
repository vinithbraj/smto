---
id: tasks
title: Tasks and recipes
kind: architecture
tags: [architecture, tools]
order: 8
---
# Tasks and recipes

A durable task persists a goal, status, attempts and checkpoints across API requests. `route_groups/task_service.py` owns task lifecycle and current-run projection. `route_groups/tasks.py` exposes task routes. Task execution re-enters the normal model-led runtime.

Composer submissions use the server-owned coordinator in
`route_groups/conversation_tasks.py`. Accepted tasks retain their selected model and
execution profile/map while queued; dispatch resolves Recommended for the actual
selected model. The running task then pins the resolved configuration and output
reservation. Resume and Continue task retain that inference identity even if global
settings change. Start a new task to use a changed
[Model Configuration](../25-model-configuration.md).

Closing the browser tab does not stop accepted queued work while the server is
running. Dependencies, available capacity and required user responses still control
progress. See [top-level task scheduling](19-scheduling.md#top-level-tasks).

The optional `manage_tasks` board belongs to one run and contains high-level outcomes, dependencies, active task, notes and observed result/job references. The model may revise it as evidence changes. The board is a strategy aid; it is not executable code or a separate completion contract.

Recipes persist a reviewed intent and parameters. Each invocation starts fresh execution against current state. A saved recipe does not silently replay old commands or promote old observations to current evidence.
