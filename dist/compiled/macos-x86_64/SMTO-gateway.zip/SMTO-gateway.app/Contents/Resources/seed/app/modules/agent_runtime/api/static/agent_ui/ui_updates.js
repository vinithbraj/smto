/**
 * @file src/agent_runtime/api/static/agent_ui/ui_updates.js
 * @brief Share desktop invalidations while tracking whether critical snapshots are current.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Coalesce topic notifications, fan out reads and distinguish transport
 * connection from completed authoritative reconciliation.
 * Boundaries: Events carry invalidation hints, never run state or permission decisions.
 * Subscribers own HTTP reads, navigation scope and DOM updates; mobile owns its own transport.
 * Lifecycle: Install once per page, open one update EventSource, reconcile on connection,
 * then batch events. Critical read failures have three bounded retries, not idle polling.
 * State: Page-local subscribers, dirty topics, timers and connection epoch. Disconnects
 * invalidate freshness; late promises cannot mark a newer epoch current. CLOSED streams
 * are replaced with backoff; CONNECTING streams retain the browser's native reconnect.
 * Security: Snapshot owners must revalidate server truth before enabling controls. IDs and
 * reasons on the update bus are diagnostics, not execution authority or private payloads.
 * Collaborators: update_stream.py publishes committed invalidations; conversation_snapshot.js delays
 * optional reads; native_controls.js and other subscribers determine critical read success.
 * Public surface: SMTOUiUpdates exposes subscribe/unsubscribe, state, freshness,
 * observeFreshness/unsubscribe and reconcile. Global listeners live for the page lifetime.
 * @see src/agent_runtime/api/agent_ui_support/update_stream.py
 * @see src/agent_runtime/api/static/agent_ui/conversation_snapshot.js
 * @see src/agent_runtime/api/static/agent_ui/native_controls.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/streaming.js
 */
(() => {
  "use strict";
  if (window.SMTOUiUpdates) return;

  const subscribers = new Set();
  const dirtyTopics = new Set();
  const freshnessSubscribers = new Set();
  let events = [], flushTimer = null, connection = "connecting";
  let freshness = "reconciling", epoch = 0, flushing = false;
  let retryTimer = null, retryAttempt = 0;
  let source = null, reconnectTimer = null, reconnectAttempt = 0;
  const retryDelays = [1000, 3000, 10000];
  /** Normalize a string/list into nonempty distinct topics, retaining first-seen order. */
  const normalize = topics => [...new Set((typeof topics === "string" ? [topics] : Array.isArray(topics) ? topics : [])
    .filter(topic => typeof topic === "string").map(topic => topic.trim()).filter(Boolean))];
  /** Report a subscriber failure locally without aborting delivery to other owners. */
  const report = error => console.error("Agent UI update subscriber failed:", error);

  /** Notify freshness observers; successful reconciliation also clears the read retry budget. */
  function setFreshness(value) {
    freshness = value;
    if (value === "current") clearRetry();
    for (const callback of freshnessSubscribers) {
      try { callback(value); } catch (error) { report(error); }
    }
  }
  /** Coalesce a burst into one 50 ms flush, leaving in-flight delivery to drain new topics. */
  function schedule() {
    if (!flushing && flushTimer === null) flushTimer = window.setTimeout(flush, 50);
  }
  /** Cancel only failed-read backoff and reset its allowance, leaving SSE recovery separate. */
  function clearRetry() {
    window.clearTimeout(retryTimer);
    retryTimer = null; retryAttempt = 0;
  }
  /** Schedule at most three stale-read retries while connected and visible. */
  function retryFailedRead() {
    // A transient snapshot failure must not latch until the next task event.
    // Retry only failed synchronization, with a finite budget and no idle poller.
    if (retryTimer !== null || connection !== "connected" || document.hidden
      || freshness !== "stale" || retryAttempt >= retryDelays.length) return;
    retryTimer = window.setTimeout(() => {
      retryTimer = null;
      if (connection === "connected" && !document.hidden && freshness === "stale") sync({retry: true});
    }, retryDelays[retryAttempt++]);
  }
  /** Request every subscriber's snapshot; only an explicit new sync resets failed-read backoff. */
  function sync({retry = false} = {}) {
    if (!retry) clearRetry();
    dirtyTopics.add("sync.required");
    if (connection === "connected") setFreshness("reconciling");
    schedule();
  }
  /** Deliver one detached topic batch and await critical owners before judging freshness.
   * Optional subscribers cannot block readiness. Epoch checks reject late read successes;
   * notifications arriving during awaits remain queued for the next flush.
   */
  async function flush() {
    flushTimer = null;
    flushing = true;
    const observedEpoch = epoch;
    const topics = [...dirtyTopics];
    const payload = {topics, events, syncRequired: dirtyTopics.has("sync.required")};
    dirtyTopics.clear();
    events = [];
    const required = [], optional = [];
    for (const subscriber of [...subscribers]) {
      if (!subscribers.has(subscriber)) continue;
      if (!payload.syncRequired && !topics.some(topic => subscriber.topics.has(topic))) continue;
      if (!subscriber.critical && window.SMTOReadPriority) {
        optional.push(subscriber);
        continue;
      }
      try {
        const result = Promise.resolve(subscriber.callback(payload));
        if (subscriber.critical) required.push(result.then(value => value !== false, error => {
          report(error); return false;
        }).then(current => {
          if (observedEpoch === epoch) subscriber.current = current;
          return current;
        }));
        else result.catch(report);
      } catch (error) {
        report(error);
        if (subscriber.critical) { subscriber.current = false; required.push(Promise.resolve(false)); }
      }
    }
    await Promise.all(required);
    for (const subscriber of optional) {
      void window.SMTOReadPriority.ready.then(() => {
        if (observedEpoch === epoch && subscribers.has(subscriber)) return subscriber.callback(payload);
      }).catch(report);
    }
    if (observedEpoch === epoch && connection === "connected" && required.length) {
      setFreshness([...subscribers].filter(subscriber => subscriber.critical).every(subscriber => subscriber.current)
        ? "current" : "stale");
    }
    flushing = false;
    if (dirtyTopics.size) schedule();
    else retryFailedRead();
  }

  window.SMTOUiUpdates = {
    /** Register topic ownership; critical subscribers joining an open stream trigger a sync.
     * Return an unsubscribe function. Critical callbacks resolve false/reject on stale reads.
     */
    subscribe(topics, callback, {critical = false} = {}) {
      const normalized = normalize(topics);
      if (!normalized.length || typeof callback !== "function") return () => {};
      const subscriber = {topics: new Set(normalized), callback, critical, current: false};
      subscribers.add(subscriber);
      // A snapshot owner may become ready after the connection's initial sync.
      if (critical && connection === "connected") sync();
      return () => subscribers.delete(subscriber);
    },
    /** Report transport state independently of snapshot freshness. */
    state: () => connection,
    /** Report aggregate critical-read freshness without issuing any reads. */
    freshness: () => freshness,
    /** Immediately report freshness and return removal of this page-local observer. */
    observeFreshness(callback) {
      freshnessSubscribers.add(callback); callback(freshness);
      return () => freshnessSubscribers.delete(callback);
    },
    reconcile: sync,
  };

  /** Cancel explicit CLOSED-stream replacement, preserving the reconnect attempt counter. */
  function clearReconnect() {
    window.clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  /** Replace only permanently closed visible/online streams; native reconnect owns CONNECTING. */
  function reconnectClosed() {
    // HTTP errors and invalid SSE responses can permanently close EventSource.
    // Leave CONNECTING sources to native reconnect (and its Last-Event-ID).
    if (reconnectTimer !== null || source.readyState !== 2 || document.hidden || navigator.onLine === false) return;
    reconnectTimer = window.setTimeout(() => {
      reconnectTimer = null;
      if (source.readyState === 2 && !document.hidden && navigator.onLine !== false) connect();
    }, retryDelays[Math.min(reconnectAttempt++, retryDelays.length - 1)]);
  }
  /** Advance the freshness epoch and invalidate critical reads without discarding subscribers. */
  function disconnected() {
    clearRetry();
    epoch++; connection = "reconnecting";
    for (const subscriber of subscribers) subscriber.current = false;
    setFreshness("stale");
  }
  window.addEventListener("offline", () => { clearReconnect(); disconnected(); });
  window.addEventListener("online", () => {
    if (source.readyState === 2) {
      clearReconnect(); reconnectAttempt = 0;
      if (!document.hidden) connect();
    }
    if (source.readyState === 1) connection = "connected";
    sync();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clearReconnect();
    else reconnectClosed();
  });
  /** Recover a stale offline hint on an open stream, then request fresh server snapshots. */
  function observeConnection() {
    // An offline hint can outlive the interruption without closing EventSource.
    // A frame on its open connection recovers transport, then rereads task truth.
    if (connection !== "connected" && source.readyState === 1) {
      connection = "connected";
      sync();
    }
  }
  /** Replace the single page transport and bind callbacks to that exact source identity.
   * Every open reconciles snapshots; frames from superseded sources cannot dirty this epoch.
   */
  function connect() {
    clearReconnect();
    source?.close();
    const current = new EventSource("/api/agent/updates/stream");
    source = current;
    current.addEventListener("open", () => {
      if (source !== current) return;
      clearReconnect(); reconnectAttempt = 0;
      connection = "connected";
      sync(); // Every connection establishes freshness through authoritative reads.
    });
    current.addEventListener("error", () => {
      if (source !== current) return;
      disconnected();
      reconnectClosed();
    });
    current.addEventListener("heartbeat", () => {
      if (source === current) observeConnection();
    });
    current.addEventListener("ui_update", message => {
      if (source !== current) return;
      let event;
      try { event = JSON.parse(message.data); } catch (error) {
        console.warn("Invalid Agent UI update:", error);
        return;
      }
      const topics = normalize(event?.topics);
      if (!topics.length) return;
      observeConnection();
      topics.forEach(topic => dirtyTopics.add(topic));
      events.push(event); // reason and ids are diagnostics, never application state.
      if (topics.includes("sync.required") && connection === "connected") setFreshness("reconciling");
      schedule();
    });
  }
  connect();
})();
