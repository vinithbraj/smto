/**
 * @file src/agent_runtime/api/static/agent_ui/plan_mode.js
 * @brief Render server-recognized Plan implementation actions.
 * @details
 * Responsibilities: Render context choices and durable approved-plan quotations.
 * Boundaries: Markdown never enters the client action payload.
 * Lifecycle: Reconcile consumption once at mount and fence late responses.
 * State: A WeakMap holds each card identity, busy state and submission ID.
 * Security: The server revalidates ownership, deletion and digest on every POST.
 * Collaborators: Desktop and mobile pass active-conversation hooks.
 * Public surface: SMTOPlanMode artifact, mount, quote, message and remember.
 * @see src/agent_runtime/api/agent_ui_support/plan_implementation.py
 */
(() => {
  "use strict";
  const states = new WeakMap();
  const quotes = new WeakMap(), plans = new Map(), reads = new Map();
  const introduction = "Implement the following plan:";
  /** Cache only the accepted plan, never the task's permission or context envelope. */
  function remember(task) {
    const plan = task?.context?.approved_plan;
    if (task?.task_id && typeof plan?.markdown === "string") {
      plans.set(task.task_id, plan);
      if (plans.size > 64) plans.delete(plans.keys().next().value);
    }
    return plan;
  }
  /** Copy the canonical Markdown, including code and blank lines, as a quotation. */
  function message(root) {
    const saved = quotes.get(root);
    const plan = saved && root.contains(saved.block) ? saved.plan : null;
    return plan ? introduction + "\n\n" + plan.markdown.split("\n").map(line => "> " + line).join("\n") : root.textContent;
  }
  /** Render a quote from a full message or hydrate a compact task once. */
  function quote(root, source, hooks) {
    const taskId = source?.task_id;
    const plan = source?.response_metrics?.approved_plan || remember(source) || plans.get(taskId)
      || quotes.get(root)?.plan;
    if (!plan?.markdown) {
      if (!source?.has_approved_plan || !taskId) return;
      if (!reads.has(taskId)) {
        const read = hooks.apiJson(`/api/agent/tasks/${encodeURIComponent(taskId)}`)
          .then(result => { const task = result.task || result; remember(task); return task; })
          .finally(() => reads.delete(taskId));
        reads.set(taskId, read);
      }
      void reads.get(taskId).then(task => {
        if (hooks.active()) quote(root, task, hooks);
      }).catch(() => { /* A later scoped refresh can retry a failed detail read. */ });
      return;
    }
    // History renders synchronously into detached fragments; only asynchronous
    // hydration needs the active-conversation fence above.
    const previous = quotes.get(root);
    if (previous && previous.plan.digest === plan.digest && root.contains(previous.block)) return;
    const heading = document.createElement("p"); heading.textContent = introduction;
    const block = document.createElement("blockquote"); block.className = "approved-plan-quote markdown";
    hooks.renderMarkdown(block, plan.markdown);
    root.classList.add("has-approved-plan");
    root.replaceChildren(heading, block);
    quotes.set(root, {plan, block});
    hooks.changed?.();
  }
  /** Resolve Plan metadata from supported live and retained trace projections. */
  function artifact(trace) {
    return trace?.response_metrics?.proposed_plan || trace?.native_profile?.proposed_plan || trace?.proposed_plan || null;
  }
  /** Mount one Plan card and reconcile any previously accepted implementation. */
  function mount(root, trace, hooks) {
    const plan = artifact(trace);
    if (!plan || !["answered", "completed"].includes(trace.status)) return false;
    const key = `${hooks.conversationId}:${hooks.requestId}:${plan.digest}`;
    let state = states.get(root);
    if (state?.key === key) {
      if (state.dismissed) root.replaceChildren();
      else if (!root.contains(state.card)) root.replaceChildren(state.card);
      return true;
    }
    const card = document.createElement("section"); card.className = "action-card plan-implementation";
    const title = document.createElement("h3"); title.textContent = "Implement this plan?";
    const group = document.createElement("div"); group.className = "action-buttons";
    group.setAttribute("role", "group"); group.setAttribute("aria-label", title.textContent);
    const status = document.createElement("p"); status.setAttribute("role", "status");
    state = {key, card, busy: false, consumed: false, dismissed: false, submissionId: null, contextMode: null};
    states.set(root, state);
    const url = `/api/agent/chats/${encodeURIComponent(hooks.conversationId)}/plans/${encodeURIComponent(hooks.requestId)}`;
    /** Fence asynchronous Plan responses to the active mounted card. */
    const alive = () => states.get(root) === state && hooks.active();
    /** Apply busy or consumed state to every implementation choice. */
    const disable = value => { for (const button of group.children) button.disabled = value; };
    /** Mark this Plan consumed and disable duplicate implementation actions. */
    const accepted = () => { state.consumed = true; disable(true); status.textContent = "Implementation accepted."; };
    /** Submit stable Plan identity and preserve it across uncertain transport retries. */
    async function implement(contextMode) {
    const busyFeedback = window.SMTOBusy?.action("Starting implementation…");
    try {
      if (state.busy || state.consumed || !alive()) return;
      // Keep identity and selected context through an uncertain network retry.
      if (state.submissionId && state.contextMode !== contextMode) return;
      state.contextMode = contextMode;
      state.submissionId ||= "planimpl_" + (globalThis.crypto?.randomUUID?.() || `${Date.now()}_${Math.random().toString(36).slice(2)}`);
      state.busy = true; disable(true); root.setAttribute("aria-busy", "true"); status.textContent = "Accepting implementation…";
      try {
        const result = await hooks.apiJson(url + "/implement", {method: "POST", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({client_submission_id: state.submissionId, context_mode: contextMode, expected_plan_digest: plan.digest})});
        remember(result.task);
        accepted();
        if (alive()) await hooks.accepted(result);
      } catch (error) {
        if (alive()) {
          status.textContent = error.message || String(error); hooks.notify(error);
          if (error.status && error.status < 500) { state.submissionId = null; state.contextMode = null; }
          if (error.status === 409) {
            try { const current = await hooks.apiJson(url); if (alive() && current.implementation) accepted(); }
            catch (_) { /* The original action error remains visible. */ }
          }
        }
      } finally {
        state.busy = false; root.removeAttribute("aria-busy");
        if (alive() && !state.consumed) {
          disable(false);
          if (state.submissionId) for (const b of group.children) b.disabled = b.dataset.context !== state.contextMode;
        }
      }

    } finally { busyFeedback?.finish(); }
  }
    for (const [label, mode] of [["Yes, implement this plan", "retain"], ["Yes, clear context and implement", "fresh"], ["No, stay in Plan mode", "stay"]]) {
      const button = document.createElement("button"); button.type = "button"; button.className = "action-button";
      button.textContent = label; button.dataset.context = mode;
      button.onclick = mode !== "stay" ? () => void implement(mode) : async () => {
        if (state.busy || !alive()) return;
        try { await hooks.stay(); state.dismissed = true; if (alive()) root.replaceChildren(); }
        catch (error) { if (alive()) hooks.notify(error); }
      };
      group.append(button);
    }
    card.append(title, group, status); root.replaceChildren(card);
    // One read on mounting reconciles consumed cards after reload. Existing trace
    // updates retain this card; there is no Plan polling loop.
    void hooks.apiJson(url).then(result => {
      if (alive() && result.implementation) accepted();
    }).catch(() => {
      // Native finalization can precede chat-turn publication. This optional
      // reconciliation read must not strand a live card on that brief 404.
      // The action always revalidates scope, deletion and consumption on POST.
    });
    return true;
  }
  window.SMTOPlanMode = {artifact, mount, quote, message, remember};
})();
