---
id: conversation-run-state
title: Conversation and run state
kind: architecture
tags: [architecture, tools]
order: 7
---
# Conversation and run state

Accepted tasks and native checkpoints retain `collaboration_mode` independently of
Agent Mode and Task Contract. Missing legacy values mean Default. Plan finalization
stores canonical Markdown with its SHA-256 digest, source identity and timestamp.
Clean answers and compact artifact metadata survive in trace/chat history. The
implementation action validates the source and atomically records card consumption,
composer transition and normal task admission. Fresh implementation copies approved
intent and preferences without transcript, receipts or a conversation handoff. These
are additive JSON fields in existing state/settings stores; no migration is required.

Conversations retain user and assistant turns and link the run journal. `RunStore`
owns dispatch claims, receipts, artifact links, jobs, wait events, amendments and
checkpoints in the Server's RAM authority. The shared journal avoids copying the
entire history into every run snapshot.

`current_run/memory_state.py:StateDraft` keeps transaction candidates private until
commit. `memory_store.py` publishes a successful draft into the original owner
containers, preserving the Activity references held by foreground workers. A
replacement copy can strand a completion waiter even after a terminal receipt is
stored. Failed transactions must leave those live objects unchanged. Immutable
hub snapshots remain detached; preserving worker references does not allow a
transaction to mutate published roots. See `test_memory_native_execution.py`
and `test_memory_run_store.py` for the publication and recovery contracts.

Ordinary `aor serve` and `create_app` acquire one fenced `ControllerRuntimeStateHub`
before opening any state repository. All 15 first-party domains restore together;
a partial domain graph cannot become ready. Immutable hash roots share unchanged
state across transactions and checkpoint snapshots. SQLite serves startup restore,
asynchronous recovery checkpoints and fenced administration. Normal requests,
misses and background execution cannot open or query Controller SQLite files.
The existing Gateway owns its separate execution state and is unchanged.

The runtime root defaults to `controller-runtime` beside the configured native-run
database. Root and repository-path locks reject competing Servers, overlapping
state paths and offline operations while the owner runs. HTTP worker counts other
than one are rejected. `aor run` and `aor chat` send requests to the running Server.

`checkpoints/manifest.json` selects the committed recovery
generation. One checkpoint is retained, with one temporary replacement while saving.
Verified publication retires the old checkpoint and canonical `.db` import sources;
those paths must not be used to inspect current state. Every domain in a selected
generation must restore before the hub can become ready or write a checkpoint.
There is no automatic rollback from a corrupt current generation.

`/healthz` includes `runtime_persistence` for the complete Controller graph. `durability` is `pending` until changes are checkpointed,
`current` when the last confirmed commit covers the sampled RAM revision, or
`degraded` after a checkpoint failure. `has_uncheckpointed_changes` explicitly
reports changes that can be lost on a crash. `uncheckpointed_revisions` counts
memory publications, not elapsed seconds or lost events. The last generation,
owner epochs, checkpoint age, failure type and dirty age help diagnose persistence
lag without reading SQLite or waiting for its writer. Availability can remain
healthy while persistence is degraded. Health reports availability and persistence separately; it is not a release certification.

The Controller has no application memory budget, reserved-memory threshold, or
memory-based task gate. The operating system controls memory allocation and
exhaustion. Existing memory-budget options in older YAML files and environment
variables are ignored. Health reports estimated state size and process RSS for
observation only; a separate worker samples RSS once per second. These numbers
do not delay or reject submissions. Actual allocation errors retain the normal
error handling and transaction rollback. Checkpointing, idempotent replay, Stop,
shutdown fences, and exclusive state ownership retain their existing behavior.

`runtime.controller_checkpoint_cpu_fraction` defaults to 0.25, overridden by
`AOR_CONTROLLER_CHECKPOINT_CPU_FRACTION`. The checkpoint worker yields between
rows after a 2 ms CPU quantum. This is cooperative pacing, not hard preemption of
a single large serializer call. Automatic saves start only after two seconds without
active task execution. HTTP traffic and ordinary RAM writes do not prevent idle
saving. Explicit manual saves and final shutdown saves can also use
`runtime.controller_checkpoint_boost_cpu_fraction` (default 1.0, environment
`AOR_CONTROLLER_CHECKPOINT_BOOST_CPU_FRACTION`). The CPU boost delay is configurable as
`runtime.controller_checkpoint_idle_seconds` / `AOR_CONTROLLER_CHECKPOINT_IDLE_SECONDS`.
Set boost equal to the base fraction to keep constant pacing. A boost below the
base does not reduce it. Activity is rechecked at each CPU quantum. Sleeping service
threads retain their shutdown reservations without preventing an idle boost.
Automatic snapshots have a 15-minute cooldown after each successful save finishes,
configured by `runtime.controller_checkpoint_cooldown_seconds` or
`AOR_CONTROLLER_CHECKPOINT_COOLDOWN_SECONDS` (default 900; 0 disables the cooldown).
Changes accumulate without moving the deadline. The first save after startup,
manual Save, and shutdown bypass it; already-committed cleanup can finish without
a new snapshot. Idle admission and serialization time can make recoverable state
older than the cooldown.
Retained cleanup items back off from 5 to 300 seconds after unchanged passes;
committed evidence wakes them early. Unchanged passes do not rewrite journals or
request saves. Maintenance telemetry distinguishes saving, cleanup, and waiting,
with elapsed phase time; waiting is not active work.
Failed attempts back off to at most 60 seconds;
shutdown requests an immediate final attempt. Dirty bytes, checkpoint bytes,
CPU/wall time, pacing and retry delay are exposed without probing disk on GET.

Every changed domain is serialized from the captured RAM snapshot into a fresh
SQLite file and matching JSON recovery base. The writer never patches saved records
using SQL deltas. Verified unchanged domains reuse immutable bytes without opening
SQLite; their baseline provenance is checked across process epochs. Genuine startup
repairs are saved, while unchanged restored records remain clean. Migrations or
incompatible loader transformations require a fresh dump of the affected domain.

A checkpoint remains a complete standalone generation, with checksums, SQLite
integrity checks and fsync barriers. Replacement files have independent inodes.
Health retains the legacy incremental counters for API compatibility, with zero
values; bytes encoded, reused, written, and elapsed time describe current save work.

Before READY, the Server seals preexisting SQLite handles, collects startup cycles
and freezes the surviving startup heap once. New request objects retain normal
garbage collection; startup cycles remain until the last embedded Server closes.
Their memory counts toward the admission budget. Disable this policy with
`runtime.controller_bootstrap_gc_freeze: false` or
`AOR_CONTROLLER_BOOTSTRAP_GC_FREEZE=0`. An embedding application that already
froze its own heap must start the Server before freezing, because otherwise the
SQL guard cannot inspect hidden old connections. GC thresholds stay unchanged.

A clean shutdown drains tracked background writers before a final checkpoint.
If a writer outlives the shutdown deadline, the old process retains its owner lock
until that writer exits and the final checkpoint attempt completes. A timeout or failure does not
confirm durability, and repeated shutdown calls do not change that result into
success. Startup restores the last committed generation; changes after it may
be lost. Snapshot coalescing retains required trace events even when many progress
updates share one checkpoint.

In-app `/restart` uses the same service teardown and final save before replacing
the process, including when a restart callback is injected. It bypasses the
automatic-save cooldown and waits for a fresh quiesced snapshot after any older
save in progress. Concurrent restart requests share one operation. If the final
save fails, the controller retains its RAM and exclusive ownership with new work
disabled; another restart request retries saving without repeating service stops
or gateway restarts. `/healthz.restart` reports `draining`, `saving`, `restarting`,
or `failed`, elapsed seconds, and a safe error message. The UI waits through
draining and saving before starting its reconnect timeout and offers a retry
when restart fails.

With the hub owner stopped, complete generations can be inspected or copied to
a new, nonexistent destination using:

```sh
PYTHONPATH=src .venv/bin/python -m agent_runtime.runtime_state.operator inspect /path/to/hub
PYTHONPATH=src .venv/bin/python -m agent_runtime.runtime_state.operator copy /path/to/hub /path/to/new-hub
```

The app keeps only the current checkpoint. `--generation previous` remains readable
for older offline manifests that still contain an explicit previous entry.
These commands verify checksums, acquire the owner lock and refuse an existing
copy destination. New complete generations also retain registered context and generated-artifact bodies.
Old generations without managed-file inventories remain metadata-only copies. Failures before manifest
publication leave no committed manifest. A final directory-fsync failure can leave
a complete visible copy whose durability is unconfirmed. Keep the source intact
and choose a fresh destination on retry.

Checkpointed state can lag live memory. After a restart the last complete
checkpoint supplies the saved permission policies, capability settings and Agent
Check overrides. Global, conversation and prompt Allow settings remain allowed;
Ask and Deny keep their usual behavior. Restarting does not add a confirmation.
An interrupted save can lose changes made after the last complete checkpoint.

Pending permission prompts keep their identities, and checkpointed one-time
permission approvals remain valid for the accepted operation until consumed or
invalidated by a policy/target change. Ordinary permission approvals have no
restart-specific or five-minute expiry. The separate unsafe-action challenges
retain their existing expiration rules. Current capability restrictions still
apply at dispatch. Invocation receipts and physical claims continue to prevent
replaying uncertain effects.

The RAM continuation worker processes indexed affected runs and deadlines.
When no work is ready it waits for publication or the next monotonic deadline;
it does not scan retained history every half second. Expired time waits and Stop
deadlines retain expiration facts across wall-clock rollback. Orphaned foreground
claims use bounded per-run backoff, retain their claims through unavailable
Gateway probes, and release only on matching physical completion evidence.
The default Server uses this worker; whole-system release evidence remains tracked
in the closure ledger.

Restart recovery reloads state and reconciles pending dispatches and real jobs. A claim without a receipt remains unknown. Pending approval and credential requests stay bound to their originating operation and scope. Deleting a conversation respects tombstones and retention rules.

Current tool calls, receipts and references use `operation_id`, `producer_operation_id` and `source_operation_id`. Modes are `conversation`, `agent` and `advisory`; old input aliases are unsupported. Each SQLite owner checks its supported version before schema creation or recovery. Fresh databases create complete schemas directly; unsupported old databases are preserved and rejected with backup/fresh-directory remediation. The shared settings/EULA database has one version identity, as does the shared current/native-run database. Current native runs own an explicit journal index and capsule metadata; loads never infer old journal ownership or reconstruct native messages from chat turns.

The public core classes are `RuntimeHost`, `AgentLoop`, `ToolCatalog`, `ExecutionEngine` and `RunStore`. `NativeModelClient`, `NativeExecutionConfig`, directory names and compatibility wire fields are intentionally retained; they do not represent a second runtime.

The API/session wrapper is `agent_runtime.api.runtime.engine.CompatibilityRuntime`. The direct tool executor alone is named `ExecutionEngine`.

## Saved model configuration

`effective_model` pins endpoint/model and internal client settings together with the
separate `execution_request_overrides`, `execution_configuration_profile`,
`execution_configuration_version` and `execution_output_reservation_tokens` fields.
`resume_context` carries the equivalent context keys, including
`llm_execution_request_overrides` and `llm_execution_configuration_profile`. Nested
maps are copied so a settings edit cannot mutate stored execution identity.

The saved client profile also pins `timeout_seconds`,
`no_actionable_output_timeout_seconds` and `constrained_recovery_timeout_seconds`.
Their `llm_` context keys travel through admission and resume. Missing historical
generation fields default to 90 and 30 seconds; later global changes affect new
tasks. This extends the existing checkpoint without a separate migration store.

Recommended profiles are resolved when the selected model is known, then saved as
concrete values. Resume and continuation preserve those values instead of recomputing
from current recommendations. Legacy snapshots acquire version-0 execution metadata
from their saved temperature/output settings and retain the `max_tokens` wire alias.
See [Model Configuration](../25-model-configuration.md) and `native/state.py`.

Durable Memory is separate profile-wide state in `agent_memory.db`, beside the run
database. Its skill owns global JSON keys, indexed tags and CAS revisions. Conversation
IDs are provenance only: ordinary deletion removes conversation KV but leaves Memory.
Runs pin only bounded relevant metadata; values require explicit `memory.get`.
See [Memory and context](22-context-memory.md#durable-cross-conversation-memory).

## Monitoring state

The accepted `disabled_agent_check_monitoring_enabled` boolean is persisted in native state and `resume_context` and carried into same-task continuations. A recovered run retains its accepted value even after global Settings changes. Legacy states without this field use OFF.

Passive reporting retains at most 128 recent observation identities in diagnostic state. Ordinary trace persistence deduplicates `agent_check_observation_id` across delivery/reload. No strike, pending approval, completion evidence, model message or execution journal is created by an observation.
