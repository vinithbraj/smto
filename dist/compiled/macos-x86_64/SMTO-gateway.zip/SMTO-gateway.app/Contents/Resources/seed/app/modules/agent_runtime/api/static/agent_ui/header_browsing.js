/* Keep the header pinned by default; optionally reclaim its row while reading. */
(() => {
  "use strict";
  const shell = document.querySelector(".app-shell");
  const header = shell?.querySelector(".app-header");
  const pin = header?.querySelector("#header-pin-toggle");
  const viewport = shell?.querySelector("#conversation-viewport");
  const empty = shell?.querySelector("#empty-state");
  if (!header || !pin || !viewport || !empty) return;

  const session = window.SMTOUiSession;
  let pinned = session?.get("header_pinned", true) ?? true;
  let scrollIntentUntil = 0, previousTop = viewport.scrollTop;
  function renderPinned() {
    pin.setAttribute("aria-pressed", String(pinned));
    pin.title = pinned ? "Unpin header to hide it while scrolling" : "Pin header to keep it visible";
    if (pinned && shell.classList.contains("header-auto-hide")) {
      const top = viewport.scrollTop, height = header.offsetHeight;
      shell.classList.remove("header-auto-hide");
      header.classList.remove("header-revealed");
      // Restoring the row shrinks the viewport; preserve the reading position.
      viewport.scrollTo({top: top + height, behavior: "instant"});
    }
    scrollIntentUntil = 0;
    previousTop = viewport.scrollTop;
  }
  pin.addEventListener("click", () => {
    pinned = !pinned;
    session?.set("header_pinned", pinned);
    renderPinned();
  });
  renderPinned();

  function scrollIntent(event) {
    if (event.type === "keydown" && (!["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(event.key)
      || event.target.closest('input, textarea, select, [contenteditable="true"]'))) return;
    scrollIntentUntil = performance.now() + 1000;
    previousTop = viewport.scrollTop;
  }
  function scrolled() {
    const top = viewport.scrollTop, moved = Math.abs(top - previousTop) > 1;
    previousTop = top;
    if (pinned || !moved || performance.now() > scrollIntentUntil || !empty.hidden) return;
    header.classList.remove("header-revealed");
    // Mouse focus should not pin the header after the user returns to reading.
    const focused = document.activeElement;
    if (header.contains(focused) && !focused.matches(":focus-visible")) focused.blur();
    if (shell.classList.contains("header-auto-hide")) return;
    const height = header.offsetHeight;
    if (top < height || viewport.scrollHeight - viewport.clientHeight < height) return;
    shell.classList.add("header-auto-hide");
    // The viewport grows upward. Offset its scroll position by the same amount
    // so the text being read stays at the same screen coordinates.
    viewport.scrollTo({top: top - height, behavior: "instant"});
    previousTop = viewport.scrollTop;
  }
  for (const type of ["wheel", "touchmove", "pointerdown", "keydown"]) {
    viewport.addEventListener(type, scrollIntent, {passive: true});
  }
  viewport.addEventListener("scroll", scrolled, {passive: true});
  header.addEventListener("pointerdown", event => {
    if (event.pointerType === "touch" && shell.classList.contains("header-auto-hide")) {
      header.classList.add("header-revealed");
    }
  });
  document.addEventListener("pointerdown", event => {
    if (!header.contains(event.target)) header.classList.remove("header-revealed");
  });
  new MutationObserver(() => {
    if (!empty.hidden) {
      shell.classList.remove("header-auto-hide");
      header.classList.remove("header-revealed");
      scrollIntentUntil = 0;
    }
    previousTop = viewport.scrollTop;
  }).observe(empty, {attributes: true, attributeFilter: ["hidden"]});
})();
