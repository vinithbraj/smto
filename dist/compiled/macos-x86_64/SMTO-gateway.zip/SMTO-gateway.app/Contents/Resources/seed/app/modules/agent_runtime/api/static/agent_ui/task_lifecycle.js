/* Task presentation only. Native snapshots and the existing action owners own execution. */
(() => {
  "use strict";
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted"]);
  const interaction = new Set(["waiting_user", "waiting_user_confirmation",
    "awaiting_clarification", "awaiting_confirmation", "awaiting_resource_reconciliation"]);
  const inputWait = new Set(["waiting_user", "awaiting_clarification"]);
  const incomplete = new Set(["partial", "blocked", "failed", "paused_budget", "cancelled", "interrupted"]);
  const statusOf = value => value?.user_visible_status || value?.outcome
    || value?.native_profile?.final_status || value?.response_metrics?.native_outcome || value?.status;
  function replyAccepted(payload, question = {}, {cursor = 0, generation = null} = {}) {
    const stream = new URL(payload.stream_url || "/", "http://localhost");
    return {requestId: payload.request_id, operationId: question.operation_id || null,
      question: question.question || "", generation, streamUrl: payload.stream_url,
      cursor: Math.max(cursor, Number(stream.searchParams.get("after_id")) || 0), pending: true};
  }
  /** Ignore the answered checkpoint, not the next interaction. No execution state is changed. */
  function observeReply(reply, value = {}) {
    if (!reply || reply.obsolete) return false;
    const requestId = value.request_id || value.run_id;
    if (requestId && requestId !== reply.requestId) return false;
    const generation = value.trace_created_at || value.trace?.created_at || value.stream?.generation
      || (!value.event_type && value.last_event_id != null && value.created_at);
    if (generation && reply.generation && generation !== reply.generation) {
      reply.pending = false;
      reply.obsolete = true;
      return false;
    }
    const event = value.event_type, detail = value.detail || {};
    const cursor = Number(event ? value.id : value.trace_event_id ?? value.last_event_id ?? value.trace?.last_event_id) || 0;
    if (cursor && (cursor < reply.cursor || event && cursor === reply.cursor)) return true;
    let status = statusOf(value);
    if (event) {
      if (["request.running", "run.resumed", "model.started", "task_contract.started"].includes(event)
          || event === "llm.request" && (detail.phase || value.stage) === "native_decision") status = "running";
      else if (event === "run.paused") status = "paused";
      else if (/^request\.(completed|suspended|failed|cancelled|interrupted)$/.test(event))
        status = detail.outcome || detail.status || event.split(".")[1];
      else if (event === "conversation.message" && detail.role === "assistant" && detail.kind === "clarification")
        status = "waiting_user";
      else return false;
    }
    if (inputWait.has(status)) {
      const question = value.clarification_request || value.trace?.clarification_request || value.pending_wait || detail;
      const operation = question.operation_id;
      const publishedQuestion = value.clarification_required || value.trace?.clarification_required;
      if (operation && operation !== reply.operationId
          && (reply.operationId || cursor > reply.cursor || publishedQuestion)) {
        reply.pending = false;
        reply.nextQuestion = true;
        return false;
      }
      // Legacy questions have no operation identity; a later, published question
      // is fresh evidence, unlike the empty summary between acceptance and resume.
      if (!reply.operationId && cursor >= reply.cursor && publishedQuestion) {
        reply.pending = false;
        reply.nextQuestion = true;
        return false;
      }
      if (!reply.pending && reply.nextQuestion && !operation
          && cursor > (reply.progressCursor || reply.cursor)) return false;
      return true;
    }
    if (status && !["queued", "pending"].includes(status)) {
      reply.pending = false;
      reply.progressCursor = Math.max(reply.progressCursor || 0, cursor);
    }
    return false;
  }
  function replyHandoff(value = {}) {
    const trace = value.trace || value;
    return inputWait.has(statusOf(value)) && ["running", "pending"].includes(trace.status)
      && trace.clarification_required === false && !trace.clarification_request;
  }
  function answeredQuestion(reply, value = {}) {
    if (!reply || reply.obsolete) return false;
    const question = value.clarification_request || value.trace?.clarification_request;
    if (!question) return false;
    return reply.operationId ? question.operation_id === reply.operationId
      : Boolean(!reply.nextQuestion && reply.question && question.question === reply.question);
  }
  function restoreReply(value = {}) {
    if (!replyHandoff(value)) return null;
    const trace = value.trace || value;
    // A native wait can also precede publication of the first question. Only
    // the reset metrics of a previously published response establish a resume.
    if (trace.response_metrics?.native_outcome !== "running") return null;
    return replyAccepted({request_id: value.request_id || value.run_id,
      stream_url: value.stream?.url || `/api/agent/stream/${value.request_id || value.run_id}`}, {}, {
      cursor: Number(value.trace_event_id || trace.last_event_id || value.stream?.after_id) || 0,
      generation: trace.created_at || value.trace_created_at || value.stream?.generation,
    });
  }
  const isCancelable = run => {
    if (!run?.request_id || !run.status || terminal.has(run.status)) return false;
    const snapshot = run.snapshot || run;
    // An accepted graceful Stop still permits escalation to an instant Stop.
    if (snapshot.stop?.mode === "graceful" && !snapshot.stop.terminalized_at) return true;
    // Resumable outcomes such as Partial may already be settled. Use the same
    // server authority as the task actions instead of inferring work from status.
    const allowed = snapshot.lifecycle?.actions?.stop ?? snapshot.stop_allowed;
    return typeof allowed === "boolean" ? allowed : true;
  };
  function obsoleteWaitNotice(text, status) {
    // These are the runtime's exact suspension messages, not generated answers.
    const waiting = /^Waiting for job \S+\.$/.test(text) ? "waiting_job"
      : /^Waiting for (time|event)\.$/.test(text) ? "waiting_event" : null;
    return Boolean(waiting && status !== waiting);
  }
  function actions(run, {settled = false, stopping = false, pausing = false, resuming = false, continuing = false, restarting = false, advancing = false} = {}) {
    if (!run?.request_id) return [];
    const snapshot = run.snapshot || run, status = run.status;
    if (snapshot.continued_by) return [];
    stopping = stopping || snapshot.cancel_requested;
    pausing = pausing || snapshot.pause_requested;
    const changingAttempt = resuming || continuing || restarting || advancing;
    const result = [];
    const authority = snapshot.lifecycle?.actions;
    if (authority) {
      const add = (allowed, action, label, busy = changingAttempt) => {
        if (allowed) result.push({action, label, busy});
      };
      add(!stopping && authority.retry && snapshot.task_contract_retry_attempt_id, "retry_task_contract", resuming ? "Retrying…" : "Retry");
      add(!stopping && (authority.resume || resuming), "resume", resuming ? "Resuming…" : "Resume");
      add(!stopping && snapshot.continue_next, "continue_next", advancing ? "Skipping…" : "Skip");
      const graceful = snapshot.stop?.mode === "graceful" && !snapshot.stop?.terminalized_at;
      add((authority.stop || graceful) && !resuming, graceful ? "force_stop" : snapshot.continue_next ? "stop_next" : "cancel",
        graceful ? "Force stop" : stopping ? "Stopping…" : "Stop", (stopping && !graceful) || changingAttempt);
      add(authority.pause && !stopping && !resuming, "pause", pausing ? "Pausing…" : "Pause", pausing || changingAttempt);
      add(authority.continue && !stopping, "continue", continuing ? "Continuing…" : "Continue task");
      add(authority.restart && !stopping, "restart", restarting ? "Restarting…" : "Restart task");
      return result;
    }
    const retryContract = status === "failed" && Boolean(snapshot.task_contract_retry_attempt_id);
    if (!stopping && retryContract) {
      result.push({action: "retry_task_contract", label: resuming ? "Retrying…" : "Retry", busy: changingAttempt});
    }
    // Interaction forms own their replies. Idle alone is never evidence of resumability.
    else if (!stopping && !interaction.has(status) && !["running", "completed", "answered", "cancelled"].includes(status)
      && (snapshot.resume_allowed === true || resuming)) {
      result.push({action: "resume", label: resuming ? "Resuming…" : "Resume", busy: changingAttempt});
    }
    if (!stopping && snapshot.continue_next
      && ["partial", "blocked", "paused", "paused_budget", "failed", "cancelled", "interrupted"].includes(status)) {
      result.push({action: "continue_next", label: advancing ? "Skipping…" : "Skip",
        busy: changingAttempt});
    }
    if (isCancelable(run) && (!settled || snapshot.stop_allowed) && !resuming) {
      const graceful = snapshot.stop?.mode === "graceful" && !snapshot.stop?.terminalized_at;
      result.push({action: graceful ? "force_stop" : snapshot.stop_allowed && snapshot.continue_next ? "stop_next" : "cancel",
        label: graceful ? (window.SMTOStopMessages?.force || "Force stop") : stopping ? "Stopping…" : "Stop",
        busy: Boolean((stopping && !graceful) || changingAttempt)});
    }
    if (!settled && !stopping && !resuming && ["running", "waiting_job", "waiting_event"].includes(status)) {
      result.push({action: "pause", label: pausing ? "Pausing…" : "Pause",
        busy: Boolean(pausing || changingAttempt)});
    }
    // Continue starts the runtime's existing child run; it is never relabelled Resume.
    if (["cancelled", "interrupted"].includes(status) && snapshot.continue_allowed !== false
      && !snapshot.continued_by && run.snapshot) {
      result.push({action: "continue", label: continuing ? "Continuing…" : "Continue task", busy: changingAttempt});
    }
    const restartAllowed = snapshot.restart_allowed === true || (snapshot.restart_allowed == null
      && ["cancelled", "interrupted"].includes(status) && snapshot.continue_allowed !== false);
    if (!stopping && restartAllowed && run.snapshot
      && ["cancelled", "interrupted", "partial", "blocked", "failed", "paused", "paused_budget"].includes(status)) {
      result.push({action: "restart", label: restarting ? "Restarting…" : "Restart task", busy: changingAttempt});
    }
    return result;
  }
  function create({requestId, dispatch, mobile = false}) {
    const root = document.createElement("div");
    root.className = "task-lifecycle-actions";
    root.dataset.requestId = requestId;
    root.hidden = true;
    root.setAttribute("role", "group");
    root.setAttribute("aria-label", "Task actions");
    const buttons = new Map();
    const note = document.createElement("p");
    note.className = "native-continuation-note";
    note.setAttribute("role", "status");
    note.id = `task-continuation-${requestId}`;
    let snapshotRevision = 0;
    function update(run, pending = {}) {
      const snapshot = run.snapshot || run;
      const revision = snapshot.state_revision ?? snapshot.lifecycle?.revision ?? 0;
      if (revision < snapshotRevision) return;
      snapshotRevision = revision;
      const controls = actions({...run, request_id: requestId}, pending);
      const children = [];
      for (const control of controls) {
        let button = buttons.get(control.action);
        if (!button) {
          button = document.createElement("button");
          button.type = "button";
          button.dataset.taskAction = control.action;
          if (!["cancel", "stop_next"].includes(control.action)) button.dataset.native = control.action;
          button.dataset.requestId = requestId;
          button.className = "stop-button activity-stop-button";
          const label = control.action === "force_stop" ? control.label : ["cancel", "stop_next"].includes(control.action) ? "Stop current task"
            : control.action === "retry_task_contract" ? "Retry task" : control.action === "continue_next" ? "Skip task"
            : control.action === "pause" ? "Pause task"
            : control.action === "restart" ? "Restart task" : control.action === "resume" ? "Resume task" : "Continue task";
          button.setAttribute("aria-label", label); button.title = label;
          if (control.action === "retry_task_contract") button.title = "Retry task contract generation with the same prompt";
          if (control.action === "continue_next") button.title = "Leave this task as it is and allow the next queued task to run";
          if (control.action === "stop_next") button.title = "Stop this task and allow the next queued task to run";
          if (control.action === "pause") button.title = "Pause after the current action finishes";
          if (!mobile) button.innerHTML = ["cancel", "stop_next"].includes(control.action)
            ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6h12v12H6Z" /></svg><span></span>'
            : control.action === "pause"
            ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h3v14H7zM14 5h3v14h-3z" /></svg><span></span>'
            : ["retry_task_contract", "restart"].includes(control.action)
            ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10a9 9 0 1 1 2.6 8.4M3 4v6h6" /></svg><span></span>'
            : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 10 7-10 7Z" /></svg><span></span>';
          button.addEventListener("click", () => { if (!button.disabled) dispatch(control.action, requestId); });
          buttons.set(control.action, button);
        }
        (mobile ? button : button.querySelector("span")).textContent = control.label;
        button.disabled = Boolean(control.busy);
        button.setAttribute("aria-busy", String(Boolean(control.busy)));
        if (["continue", "restart"].includes(control.action)) button.setAttribute("aria-describedby", note.id);
        children.push(button);
      }
      if (controls.some(control => ["continue", "restart"].includes(control.action))) {
        const snapshot = run.snapshot || run;
        const target = snapshot.authority?.gateway_node || snapshot.authority?.node || snapshot.authority?.gateway_defaults?.node || "";
        if (buttons.has("continue")) buttons.get("continue").title = target ? `Continue task on ${target}` : "Continue task";
        if (buttons.has("restart")) buttons.get("restart").title = target ? `Restart task from the beginning on ${target}` : "Restart task from the beginning";
        note.textContent = (run.status === "interrupted"
          ? "The previous stop could not confirm every external effect. The runtime will reconcile actual state before making new changes."
          : "Work completed in the previous attempt has been preserved.") + (target ? ` Target: ${target}.` : "")
          + " Restart begins a fresh attempt with the same task settings. Previous actions are not undone.";
        children.push(note);
      }
      // Keep focused buttons in place when a snapshot only updates their busy state.
      for (const child of [...root.children]) if (!children.includes(child)) child.remove();
      children.forEach((child, index) => {
        if (root.children[index] !== child) root.insertBefore(child, root.children[index] || null);
      });
      root.hidden = !controls.length;
    }
    return {root, update};
  }
  window.SMTOTaskLifecycle = {actions, create, isCancelable, obsoleteWaitNotice,
    incomplete, replyAccepted, observeReply, replyHandoff, answeredQuestion, restoreReply};
})();
