---
id: docker
title: Docker and Compose
kind: manual
tags: [docker, compose, containers, skills, gateway, safety]
order: 35
---
# Docker and Compose

Enable the optional **Docker** skill to inspect and manage the Docker Engine on the selected
Gateway. It provides 56 typed tools. Logs, image metadata, labels and Compose output are
untrusted data; they cannot authorize an action. Backend operations make no helper model calls.

## Set up the selected Gateway

The Gateway account must already have access to its local Docker socket. The default is
`unix:///var/run/docker.sock`. Set `GATEWAY_DOCKER_ENDPOINT` to an explicit local Unix socket
for a rootless Engine or Docker Desktop on macOS, then refresh Gateway capabilities.
`DOCKER_HOST`, `DOCKER_CONTEXT` and the controller's daemon are never used as fallbacks.
The current transport supports Unix sockets; Windows named pipes, remote TCP/TLS and SSH
Engines are unavailable and fail closed.

Core Engine operations require no additional Python library. For image builds, install
`python -m pip install -e '.[docker]'` on the Gateway. This extra supplies Docker's own
`.dockerignore` matcher. Compose requires a **system-installed Docker Compose v2 plugin**,
available through the Gateway's `docker` executable with an isolated Docker configuration.
User Docker configuration credentials and credential helpers are not imported.

Capabilities report `docker_engine`, `docker_registry`, `docker_build`, `docker_compose` and
`docker_build_cache` separately after checking prerequisites. Unsupported tools are unavailable.
API versions are
negotiated using `/version`, within the client-supported range 1.41–1.54 and the server's minimum
and maximum. No daemon discovery or network scanning occurs.

## Inspect and execute

Entry tools are `docker.status`, `docker.containers`, `docker.container`,
`docker.compose_projects`, and `docker.compose_ps`. Discover additional tools through the
`engine`, `containers.read`, `containers.write`, `images.read`, `images.write`, `volumes`,
`networks`, `build`, `compose.read`, `compose.write`, and `registry` sections.

Use complete IDs or unique exact names. An ID prefix is never sufficient for mutation.
Create/run requires a local image; pull it explicitly first. Exec takes an `argv` array,
optional working directory, user, environment and bounded `stdin_text`. It does not add a shell.
A nonzero exec exit code is returned as an observed exit code; inspect it before claiming success.

Logs default to 200 lines and 64 KiB, support tail, timestamps, since/until and Engine
stdout/stderr selection, and never follow indefinitely. Stats return one snapshot. Lists default
to 100 objects and permit at most 500. Tool output is capped at 256 KiB; oversized identity or
configuration results fail rather than silently losing their safety information. Engine JSON
and progress input are bounded at 8 MiB. Operations default to 60 seconds, with a maximum of
300 seconds. Cancellation closes local I/O and terminates Compose's local process group.
The daemon or container process may continue after disconnection; such mutations remain
**outcome unknown** unless a supported state check proves the desired state.

Container configuration exposes mounts, privilege, devices, namespaces, capabilities, root
filesystem mode, ports, environment, user and restart policy explicitly. Each mount requires
`read_only`; named volumes must already exist. Ports require an explicit host address. There
is no implicit Docker-socket mount. Host access and operations that execute existing container
code use the runtime's unsafe-action authorization. This never supplies OS privilege or bypasses
permission policy. Creation reports its exact mount exposure.

## Private credentials

Create accepted Parameter Store references with these types:

| Profile | Fields | Use |
| --- | --- | --- |
| `docker_registry` | `registry`, `username`, `token` | `registry_ref` on pull/push |
| `docker_secret` | `value` | `secret_env` maps environment keys to references |
| `docker_env_file` | absolute Gateway-local `path` | explicit Compose `env_file_refs` |

All profiles use `profile_version: 1`. Values are recovered from the accepted private revision
and sent only through the authenticated private Gateway envelope. Registry credentials are
bound to the image's explicit registry prefix. Push requires a registry profile and is external
publication. Metadata omits environment values; supplied secrets and inspected container
and resolved Compose environment values are removed from output. Secret-looking keys in literal
`env` or `build_args` are rejected. BuildKit secret mounts are not exposed; never put secrets in
build arguments, Dockerfiles or context files.

Build contexts must be absolute local directories. Dockerfiles must be inside the context.
Docker's ignore matcher honors `.dockerignore` and Dockerfile-specific ignore files. Contexts
are capped at 64 MiB and 10,000 included entries; symlinks and special files are rejected.
Build logs are reduced to structured progress, with arbitrary build output omitted.

## Compose project identity

Supply an absolute `working_dir`, explicit `files`, `project_name` and optional `profiles`.
The adapter never searches for a project file or inherits Compose environment selection.
Explicit private env-file references are supported; implicit `.env` loading is disabled.

Read `docker.compose_config` first. Its `revision` covers the exact project identity and full
resolved configuration, including private values. The public configuration omits environment
values, commands, labels and secret contents, while retaining host exposure fields.
Pass that revision as `expected_revision` to every Compose mutation. A changed revision is
rejected. The operation executes a private temporary copy of the resolved configuration,
then removes it. Service selectors must match the resolved project.

`compose_up` is detached and does not build unless `build=true`. `compose_down` defaults to
`remove_volumes=false`, `remove_images=none`, and `remove_orphans=false`. Volume removal has
its own destructive classification and authorization. `compose_rm` does not implicitly stop
containers or remove volumes. Compose logs cannot select stdout and stderr independently.

## Preview deletion

1. Call `docker.prune_preview` with explicit categories if needed. Defaults are stopped
   containers, dangling images and unused local networks. Volumes are excluded by default.
2. Review the exact candidate IDs/names. For volumes, use `docker.volume_prune_preview`.
3. Submit the returned `preview_token` and exactly the previewed categories to `docker.prune`,
   or use `docker.volume_prune`. `docker.volume_remove` also requires a volume preview token
   and selects one exact candidate.

Previews last five minutes and are single-use, bound to the Gateway's Engine, candidate revision
and categories. State drift requires a new preview. Deletions use individual exact IDs with
force disabled, never a broad Engine prune API. Image removal disables parent pruning. Attached
volumes, nonlocal volume drivers/options, built-in networks and used images are excluded.
Build cache is opt-in through the `build_cache` category and requires a system Buildx plugin.
Only immutable, reclaimable cache IDs are candidates. The adapter pins Buildx to the selected
local Engine's default builder, uses isolated configuration, checks each candidate revision,
and prunes one exact `id=` filter at a time with `inuse=false` and `mutable=false`. It verifies
absence after deletion. A missing plugin fails closed; no user-selected remote builder is used.

Docker offers no transactional compare-and-delete across clients. A concurrent external Docker
client can still change state between the final check and Engine deletion. Avoid concurrent
external administration during destructive cleanup. A lost destructive response is never retried.

## Unknown outcomes and errors

Every request is fenced durably by operation ID under `GATEWAY_DOCKER_STATE_ROOT` (default
`~/.smto/docker`). Reusing an ID cannot replay it, including after a Gateway restart.
Do not remove this journal to force a retry. Previews are volatile and expire on restart.

Start/stop can reconcile desired state; create/run use an operation label; removal checks exact
object absence. Pulls can reconcile an immutable requested digest. Mutable-tag pulls, pushes,
exec, restart and prune remain unknown after response loss. Compose up/down inspect the exact
project state but retain uncertainty about lifecycle completion. Inspect state and obtain a new
authorized request only when safe; no automatic mutation retry exists.

Errors carry stable Error IDs and specific causes, such as Engine availability, socket access,
API incompatibility, exact-object absence, invalid Compose configuration, missing registry
credentials, stale preview, cancellation, timeout and unknown effect. Follow the receipt's
remediation. No raw Docker command or arbitrary Engine endpoint tool is provided.
