import "../../context_carry_forward.js?v=20261015-smto";
import "./advanced.js";
import {composerProfile} from "../composer_profile.js?v=20261018-loading";
import {
  api,
  state,
  storage,
  node,
  button,
  applyAppearance,
} from "../api.js?v=20261018-loading";
import { openSheet, choose, mountControls } from "../overlays.js?v=20261018-loading";
import { appendContextActions } from "./context.js?v=20261018-loading";
import { loadTargets, targetChoices } from "../targets.js?v=20261018-loading";

let loading = null,
  loadedAt = 0;
const modes = [
  { value: "agent", label: "Agent" },
  { value: "plan", label: "Plan" },
  { value: "advisory", label: "Ask" },
];
const efforts = ["low", "medium", "high", "extra_high", "ultra"].map(
  (value) => ({
    value,
    label:
      { extra_high: "Extra High" }[value] ||
      value[0].toUpperCase() + value.slice(1),
  }),
);
async function ensureConfig() {
  if (state.config && Date.now() - (state.config.loadedAt || loadedAt) < 30000) return state.config;
  if (loading) return loading;
  loading = (async () => {
    const models = await api("model/config");
    state.config = {models: models.options || [], loadedAt: Date.now()};
    loadedAt = Date.now();
    return state.config;
  })();
  try {
    return await loading;
  } finally {
    loading = null;
  }
}
function saveChoice(key, value) {
  return composerProfile.patch({[key]: value});
}
export async function savePreference(key, value) {
  if (window.SMTOComposerProfile.fields.includes(key)) return composerProfile.patch({[key]: value});
  const feedback = window.SMTOBusy?.action("Saving preference…");
  try {
  state.settings = (
    await api("settings/preferences", {
      method: "PUT",
      body: { settings: { [key]: value } },
    })
  ).settings;
  } finally { feedback?.finish(); }
}
// Every prompt panel projects the same live profile and exposes retry in place.
function promptSheet(title, {back = null} = {}) {
  const update = () => {
    const profile = composerProfile.current();
    status.textContent = profile.loading ? "Loading conversation settings…"
      : profile.error || (profile.unsynced || profile.policyPending ? "Saving conversation settings…" : "");
    retry.hidden = !profile.error;
  };
  const body = openSheet(title, {back, returnFocus: document.getElementById("add"),
    onClose: () => window.removeEventListener("mobile-composer-profile-changed", update)});
  const feedback = node("div", null, "sheet-profile-feedback"), status = node("p"),
    retry = button("Retry settings", () => composerProfile.retry());
  status.setAttribute("role", "status");
  feedback.append(status, retry); body.append(feedback);
  window.addEventListener("mobile-composer-profile-changed", update); update();
  return body;
}
export async function open(hooks, feedback = null) {
  const back = () => void open(hooks), body = promptSheet("Prompt settings");
  const busyFeedback = feedback || window.SMTOBusy?.begin({host: body, label: "Loading prompt settings…"});
  feedback?.move(body); feedback?.update("Loading prompt settings…");
  try {
  appendContextActions(body, hooks, back);
  if (!composerProfile.ready()) {
    body.append(button("Load conversation settings", async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try { await composerProfile.retry(); await open(hooks);
 } finally { busyFeedback?.finish(); }
}, "choice"));
    return;
  }
  const loading = node("p", "Loading options…", "muted"); body.append(loading);
  let config;
  try { config = await ensureConfig(); await loadTargets(); }
  catch (error) {
    if (!body.isConnected) return;
    loading.textContent = error.message;
    body.append(button("Retry options", back, "choice")); return;
  }
  if (!body.isConnected) return;
  loading.remove();
  const selected = state.choices;
  const option = (label, key, choices) => {
    const value = choices.find(item => item.value === selected[key]);
    const control = button(`${label} · ${value?.label || `Unavailable: ${selected[key] || "Choose"}`}`,
      () => choose(label, choices, selected[key], value => saveChoice(key, value), back, {sheet: promptSheet}), "choice");
    control.disabled = state.steering; body.append(control);
  };
  const mode = window.SMTOComposerProfile.modeValue(selected);
  const modeButton = button(`Mode · ${modes.find(item => item.value === mode)?.label || "Conversation"}`,
    () => choose("Mode", modes, mode, value => composerProfile.selectMode(value), back, {sheet: promptSheet}), "choice");
  modeButton.disabled = state.steering; body.append(modeButton);
  option("Model", "llm_model", config.models);
  body.append(button("Thinking and output budgets", () => {
    const panel = promptSheet("Thinking and output", {back});
    mountControls(panel, document.getElementById("thinking-controls"));
  }, "choice"));
  option("Behavior effort", "behavior_effort", efforts);
  body.append(button("Execution targets", () => {
    const panel = promptSheet("Execution targets", {back}); targetChoices(panel);
  }, "choice"));
  body.append(button("Task dependency", () => {
    const panel = promptSheet("Task dependency", {back});
    mountControls(panel, document.getElementById("task-options"));
  }, "choice"));
  body.append(button("Advanced options", () => advancedOptions(hooks, back), "choice"));

  } finally { busyFeedback?.finish(); }
}
async function advancedOptions(hooks, parent) {
  const body = promptSheet("Advanced options", {back: parent}), selected = state.choices;
  const busyFeedback = window.SMTOBusy?.begin({host: body, label: "Loading advanced settings…"});
  try {
  const back = () => void advancedOptions(hooks, parent);
  body.append(window.SMTOContextCarryForward.create({
    value: selected.context_carry_forward,
    defaultValue: composerProfile.current().context_carry_forward_default,
    onChange: value => saveChoice("context_carry_forward", value),
  }));
  body.append(
    button(
      "Permissions",
      async () =>
        { const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try { return await ((await import("./policies.js?v=20261018-loading")).open("permissions", hooks, back)); } finally { busyFeedback?.finish(); } },
      "choice",
    ),
  );
  body.append(
    button(
      "Capabilities",
      async () =>
        { const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try { return await ((await import("./policies.js?v=20261018-loading")).open("capabilities", hooks, back)); } finally { busyFeedback?.finish(); } },
      "choice",
    ),
  );
  body.append(button("Agent checks", async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
    const {options} = await import("./completion_handling.js?v=20261018-loading");
    const checks = openSheet("Agent checks", {back}); options(checks, hooks);

 } finally { busyFeedback?.finish(); }
}, "choice"));
  const usage = state.run?.context_usage;
  if (usage)
    body.append(
      node(
        "p",
        usage.status === "exceeded" ? "Context exceeded"
          : `Context: ${usage.remaining_percent != null ? `${usage.remaining_percent}% available` : `${usage.used_tokens || usage.used_tokens_estimate || 0} tokens used`}`,
        usage.status === "exceeded" ? "error" : "muted",
      ),
    );
  const preferences = await api("settings/preferences");
  const cid = state.conversationId;
  const entries = Object.entries(window.SMTOComposerProfile.policyRoutes);
  const catalogs = await Promise.all(entries.map(([, route]) => api(`${route}${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`)));
  if (!body.isConnected || cid !== state.conversationId) return;
  for (const [[key, route], catalog] of entries.map((entry, i) => [entry, catalogs[i]])) {
    const name = {parallel_execution_policy: "Parallel execution", background_activity_policy: "Background activities",
      dependency_scheduling_policy: "Dependency scheduling", resource_scheduling_policy: "Resource-aware scheduling"}[key];
    const policy = composerProfile.policy(key) || catalog[key];
    const override = {parallel_execution_policy: "parallelPolicyForRequest", background_activity_policy: "backgroundPolicyForRequest",
      dependency_scheduling_policy: "dependencyPolicyForRequest", resource_scheduling_policy: "resourcePolicyForRequest"}[key];
    const prompt = window.SMTOAgentChecks?.[override]?.(cid);
    const label = node("label"), control = node("input"); control.type = "checkbox"; control.setAttribute("role", "switch");
    control.checked = (prompt || policy).enabled; control.className = "mission-switch";
    label.append(control, node("span", `${name} · ${prompt ? "Overridden for this prompt" : "Conversation"}`)); body.append(label);
    control.onchange = async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
      control.disabled = true;
      try { await composerProfile.setPolicy(key, {...policy, enabled: control.checked}); }
      catch (error) { hooks.notify?.(error.message); }
      finally { control.disabled = false; }

 } finally { busyFeedback?.finish(); }
};
  }
  if (!body.isConnected) return;
  state.settings = preferences.settings || state.settings;
  const capabilities = await api(`capabilities/effective${cid ? `?conversation_id=${encodeURIComponent(cid)}` : ""}`);
  if (!body.isConnected || cid !== state.conversationId) return;
  const automaticLabel = node("label"), automaticControl = node("input");
  automaticControl.type = "checkbox"; automaticControl.className = "mission-switch"; automaticControl.setAttribute("role", "switch");
  const defaultSelection = capabilities.selection || {schema_version: 1, mode: "automatic", always_skill_ids: [], always_tool_ids: []};
  automaticControl.checked = (state.choices.capability_selection || defaultSelection).mode === "automatic";
  automaticLabel.append(automaticControl, node("span", "Automatic Capability Selection · Next message"));
  body.append(automaticLabel, node("p", "On by default. Selects from permitted capabilities. Edit Auto, Always and Never in Capabilities.", "muted"));
  automaticControl.onchange = () => {
    state.choices.capability_selection = {...(state.choices.capability_selection || defaultSelection), mode: automaticControl.checked ? "automatic" : "manual"};
    window.dispatchEvent(new Event("capability-selection-draft-changed"));
  };
  let refreshIntegrity = () => {};
  const deliveryChoices = [
    {value: "adaptive", label: "Adaptive (recommended)"},
    {value: "compact", label: "Compact (legacy)"},
    {value: "full", label: "Full"},
  ];
  const delivery = button("", () => choose(
    "Tool result delivery", deliveryChoices, state.settings.tool_result_delivery_mode,
    async (value) => {
      await savePreference("tool_result_delivery_mode", value);
      refreshDelivery();
    }, back,
  ), "choice");
  /** Load and display the current tool-result delivery preference. */
  const refreshDelivery = () => {
    const selected = deliveryChoices.find(choice => choice.value === state.settings.tool_result_delivery_mode);
    delivery.textContent = `Tool result delivery · ${selected?.label || "Compact (legacy)"}`;
  };
  refreshDelivery();
  body.append(delivery, node("p", "Controls how much tool output the model sees; complete receipts remain available for inspection. Adaptive preserves critical facts with exact retrieval. Compact uses fixed legacy previews. Full may exhaust model context. Applies to newly accepted tasks only; queued, scheduled and resumed tasks keep their choice.", "muted"));
  for (const [key, title] of [
    ["generate_prose", "Progress updates"],
    ["task_contract_compilation_enabled", "Task Contract Compilation"],
    ["task_contract_integrity_guard_enabled", "Task Contract Integrity Guard · Conversation"],
  ]) {
    const label = node("label"),
      control = node("input");
    control.type = "checkbox";
    control.className = "mission-switch";
    control.setAttribute("role", "switch");
    control.checked = (window.SMTOComposerProfile.fields.includes(key) ? composerProfile.current()[key] : state.settings[key]) === true;
    const caption = node("span", title);
    label.append(control, caption);
    body.append(label);
    if (key === "task_contract_integrity_guard_enabled") {
      refreshIntegrity = () => {
        const view = window.SMTOAgentChecks?.integrityView(cid, composerProfile.current()) || {
          enabled: composerProfile.current().task_contract_integrity_guard_enabled ?? true,
          disabled: composerProfile.current().task_contract_compilation_enabled !== true,
          source: "Conversation default", help: "Applies when Task Contract Compilation is enabled.",
        };
        control.checked = view.enabled; control.disabled = view.disabled;
        caption.textContent = `Task Contract Integrity Guard · ${view.source}`;
        control.title = view.help;
      };
      refreshIntegrity();
    }
    control.onchange = async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
      control.disabled = true;
      try {
        await savePreference(key, control.checked);
        refreshIntegrity();
      } catch {
        control.checked = !control.checked;
      } finally {
        control.disabled = false;
        refreshIntegrity();
      }

 } finally { busyFeedback?.finish(); }
};
  }
  body.append(
    button(
      "Appearance",
      () => openAppearance(back),
      "choice",
    ),
  );
  body.append(
    node(
      "p",
      "Conversation options are saved for future messages on all devices. Active tasks keep their captured settings.",
      "muted",
    ),
  );

  } finally { busyFeedback?.finish(); }
}

export function openAppearance(back) {
  const editor = window.SMTOAppearance.createEditor({showFontPicker: false});
  const body = openSheet("Appearance", {back, onClose: () => editor.dispose()});
  const theme = node("div", null, "appearance-stepper");
  theme.setAttribute("role", "group"); theme.setAttribute("aria-label", "Theme");
  for (const [value, label] of [["system", "System"], ["light", "Light"], ["dark", "Dark"]]) {
    const choice = button(label, () => {
      storage.set("appearance", value);
      applyAppearance();
      for (const item of theme.children) item.setAttribute("aria-pressed", String(item === choice));
    });
    choice.setAttribute("aria-pressed", String(storage.get("appearance", "system") === value));
    theme.append(choice);
  }
  body.append(node("p", "Theme", "appearance-label"), theme, editor);
}
