/* Source-neutral history and a read-only projection of deterministic direct reminders. */
(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const delivery = window.SMTONotifications;
  const {element, icon} = delivery;
  const labels = {unread: "Unread", read: "Read", dismissed: "Dismissed"};
  const cards = new Map(), busy = new Set(), errors = new Map();
  const expanded = new Set();
  const messageObserver = new ResizeObserver(entries => {
    entries.forEach(entry => entry.target.updateExpansion());
  });
  const linkedId = new URL(window.location.href).searchParams.get("notification");
  const session = window.SMTOUiSession;
  let data = null, filter = session.get("notification_status", "all"), linkedHandled = false, resolvingLink = false;
  document.querySelectorAll("[data-filter]").forEach(node => node.setAttribute("aria-pressed", String(node.dataset.filter === filter)));
  let upcomingRequest = null, upcomingAgain = false, upcomingTimer = null;

  function dateLabel(value, timezone) {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return {short: "Time unavailable", full: ""};
    let zone = timezone || Intl.DateTimeFormat().resolvedOptions().timeZone;
    try { new Intl.DateTimeFormat(undefined, {timeZone: zone}).format(date); }
    catch (_error) { zone = "UTC"; }
    const opts = {timeZone: zone};
    const dayKey = time => new Intl.DateTimeFormat("en-CA", {...opts, year: "numeric", month: "2-digit", day: "2-digit"}).format(time);
    const today = new Date();
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
    const prefix = dayKey(date) === dayKey(today) ? "Today" : dayKey(date) === dayKey(tomorrow) ? "Tomorrow"
      : new Intl.DateTimeFormat(undefined, {...opts, month: "short", day: "numeric", ...(date.getFullYear() === today.getFullYear() ? {} : {year: "numeric"})}).format(date);
    return {
      short: prefix + " · " + new Intl.DateTimeFormat(undefined, {...opts, hour: "numeric", minute: "2-digit"}).format(date),
      full: new Intl.DateTimeFormat(undefined, {...opts, dateStyle: "full", timeStyle: "long"}).format(date) + " (" + zone + ")",
    };
  }
  function action(text, onClick, className = "") {
    const node = element("button", className, text);
    node.type = "button";
    node.addEventListener("click", onClick);
    return node;
  }
  async function change(item, status) {
    const busyFeedback = window.SMTOBusy?.begin({host: document.querySelector('#notification-list') || document.querySelector('main'), label: "Updating notification…"});
    try {
    const id = item.notification_id;
    if (busy.has(id)) return;
    busy.add(id); errors.delete(id); render();
    try {
      await delivery.updateStatus(id, status);
      $("notification-action-status").textContent = status === "read" ? "Notification marked read." : "Notification dismissed.";
    } catch (error) { errors.set(id, error); }
    finally { busy.delete(id); render(); }

    } finally { busyFeedback?.finish(); }
  }
  function row(item) {
    const card = element("article", "notification-row");
    card.dataset.notificationId = item.notification_id;
    card.dataset.status = item.status;
    card.tabIndex = -1;
    card.setAttribute("aria-label", item.title || "Notification");
    card.append(icon(item.level));
    const body = element("div", "notification-body"), heading = element("div", "notification-row-heading");
    heading.append(element("h2", "", item.title || "Notification"), element("span", "status-chip", labels[item.status] || item.status));
    const meta = element("div", "notification-meta"), time = element("time");
    const date = dateLabel(item.created_at);
    time.dateTime = item.created_at; time.textContent = date.short; time.title = date.full;
    meta.append(time);
    if (item.metadata?.notifications_suppressed) meta.append(element("span", "", "· Suppressed"));
    const preview = element("div", "notification-message");
    const message = element("div", "notification-markdown");
    preview.id = "notification-message-" + item.notification_id;
    window.SMTOMarkdown.render(message, item.message);
    preview.append(message);
    const toggle = action("Show more", () => {
      if (expanded.has(item.notification_id)) expanded.delete(item.notification_id);
      else expanded.add(item.notification_id);
      message.updateExpansion();
    }, "notification-expand");
    toggle.dataset.action = "expand";
    toggle.setAttribute("aria-controls", preview.id);
    toggle.hidden = true;
    message.updateExpansion = () => {
      const open = expanded.has(item.notification_id);
      preview.classList.toggle("is-expanded", open);
      toggle.textContent = open ? "Show less" : "Show more";
      toggle.setAttribute("aria-expanded", String(open));
      const height = parseFloat(getComputedStyle(preview).getPropertyValue("--preview-height"));
      toggle.hidden = message.scrollHeight <= height + 1;
    };
    // A keyboard user reaching a link below the preview must be able to see it.
    message.addEventListener("focusin", () => {
      expanded.add(item.notification_id);
      message.updateExpansion();
    });
    messageObserver.observe(message);
    body.append(heading, preview, toggle, meta);
    if (window.SMTOErrors.notificationText(item.error_detail)) {
      body.append(window.SMTOErrors.render(item.error_detail, {profile: "notification"}));
    }
    const actions = element("div", "notification-actions");
    // Links always lead to product surfaces; IDs are encoded, never treated as URLs.
    if (item.event_id) {
      const link = element("a", "", "View schedule");
      link.href = "/schedules";
      actions.append(link);
    }
    const conversation = item.metadata?.conversation_id;
    if (typeof conversation === "string" && conversation) {
      const link = element("a", "", "Open conversation");
      link.href = "/agent-ui?conversation=" + encodeURIComponent(conversation);
      actions.append(link);
    }
    if (item.status === "unread") {
      const read = action("Mark read", () => change(item, "read"));
      read.dataset.action = "read"; actions.append(read);
    }
    if (item.status !== "dismissed") {
      const dismiss = action("Dismiss", () => change(item, "dismissed"), "notification-dismiss");
      dismiss.dataset.action = "dismissed"; actions.append(dismiss);
    }
    actions.querySelectorAll("button").forEach(button => { button.disabled = busy.has(item.notification_id); });
    if (actions.children.length) body.append(actions);
    if (errors.has(item.notification_id)) {
      const error = element("div", "notification-error");
      window.SMTOErrors.present(error, errors.get(item.notification_id));
      error.setAttribute("role", "alert"); body.append(error);
    }
    card.append(body);
    return card;
  }
  function render() {
    if (!data) return;
    const query = $("notification-search").value.trim().toLocaleLowerCase();
    const items = data.notifications.filter(item => (filter === "all" || item.status === filter)
      && (item.title + "\n" + item.message).toLocaleLowerCase().includes(query))
      .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
    const focused = document.activeElement, focusedId = focused.closest("[data-notification-id]")?.dataset.notificationId;
    const focusedAction = focused.dataset.action;
    const list = $("notification-list"), ids = new Set(items.map(item => item.notification_id));
    for (const [id, cached] of cards) {
      if (!ids.has(id)) {
        messageObserver.unobserve(cached.node.querySelector(".notification-markdown"));
        cached.node.remove(); cards.delete(id);
      }
    }
    const retainedIds = new Set(data.notifications.map(item => item.notification_id));
    for (const id of expanded) if (!retainedIds.has(id)) expanded.delete(id);
    items.forEach((item, index) => {
      const id = item.notification_id;
      const signature = JSON.stringify([item, busy.has(id), errors.get(id)]);
      let cached = cards.get(id);
      if (!cached || cached.signature !== signature) {
        if (cached) messageObserver.unobserve(cached.node.querySelector(".notification-markdown"));
        const node = row(item);
        if (cached?.node.isConnected) cached.node.replaceWith(node);
        cached = {node, signature}; cards.set(id, cached);
      }
      if (list.children[index] !== cached.node) list.insertBefore(cached.node, list.children[index] || null);
    });
    if (focusedId && !focused.isConnected) {
      const card = cards.get(focusedId)?.node;
      const next = focusedAction && card?.querySelector('[data-action="' + focusedAction + '"]:not(:disabled)');
      (next || card || document.querySelector('[data-filter="' + filter + '"]')).focus({preventScroll: true});
    }
    const unread = data.counts?.unread || 0;
    $("mark-all-read").hidden = !unread;
    $("unread-count").textContent = unread ? String(unread) : "";
    document.querySelector('[data-filter="unread"]').setAttribute("aria-label", "Unread, " + unread + " notifications");
    $("notification-count").textContent = items.length + (items.length === 1 ? " notification" : " notifications")
      + (data.notifications.length >= delivery.limit() ? " · searching the latest " + data.notifications.length : "");
    $("notification-empty").hidden = items.length > 0;
    if (!items.length) {
      const title = query ? "No notifications match your search." : filter !== "all" ? "No " + filter + " notifications." : "No notifications yet";
      $("notification-empty").replaceChildren(icon("bell"), element("h2", "", title),
        element("p", "", query || filter !== "all" ? "Try another search or filter." : "Reminders, monitor alerts and task updates will appear here."));
    }
    const retained = ["unread", "read", "dismissed"].reduce((sum, status) => sum + (data.counts?.[status] || 0), 0);
    $("load-more-notifications").hidden = delivery.limit() >= 500 || data.notifications.length >= retained;
  }
  async function resolveLink() {
    if (!linkedId || linkedHandled || resolvingLink || !data) return;
    resolvingLink = true;
    try {
      let item = data.notifications.find(item => item.notification_id === linkedId);
      // Bounded expansion also supports links to older retained items without another API.
      while (!item && delivery.limit() < 500 && !$("load-more-notifications").hidden) {
        await delivery.loadMore();
        item = data.notifications.find(item => item.notification_id === linkedId);
      }
      linkedHandled = true;
      if (!item) {
        $("deep-link-note").textContent = "This notification is no longer available in recent history.";
        $("deep-link-note").hidden = false;
        return;
      }
      if (item.status === "unread") await change(item, "read");
      const card = cards.get(linkedId)?.node;
      card?.scrollIntoView({block: "center", behavior: "instant"});
      card?.focus({preventScroll: true});
      card?.classList.add("is-highlighted");
      window.setTimeout(() => card?.classList.remove("is-highlighted"), 2500);
    } finally { resolvingLink = false; }
  }
  function renderPermission(state) {
    const status = {
      granted: state.nativeFailed ? "Native delivery unavailable · using in-page alerts" : "Enabled",
      default: "Not enabled · using in-page alerts",
      denied: "Blocked by browser · using in-page alerts",
      unsupported: "Unavailable · using in-page alerts",
    }[state.permission];
    $("browser-permission-status").textContent = state.data && !state.enabled ? "Alerts are turned off" : status;
    $("enable-browser-notifications").hidden = state.permission !== "default" || !state.enabled;
    $("notifications-disabled").hidden = !state.data || state.data.enabled !== false;
  }
  async function loadUpcoming() {
    clearTimeout(upcomingTimer); upcomingTimer = null;
    if (upcomingRequest) { upcomingAgain = true; return upcomingRequest; }
    upcomingRequest = (async () => {
      do {
        upcomingAgain = false;
        try {
          const response = await window.SMTOErrors.fetch("/api/agent/events?run_limit=1", {cache: "no-store"});
          if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
          const result = await window.SMTOErrors.readJson(response);
          const items = (result.events || []).filter(event => event.event_kind === "scheduled"
            && event.action_type === "notification" && event.status === "active"
            && event.next_run_at && Number.isFinite(Date.parse(event.next_run_at)))
            .sort((a, b) => Date.parse(a.next_run_at) - Date.parse(b.next_run_at)).slice(0, 3);
          $("upcoming-list").replaceChildren(...items.map(event => {
            const entry = element("li"), link = element("a"), text = element("span", "upcoming-text");
            link.href = "/schedules";
            const time = element("time"), date = dateLabel(event.next_run_at, event.timezone);
            time.dateTime = event.next_run_at; time.textContent = date.short; link.title = date.full;
            text.append(element("strong", "", event.title || "Reminder"), time);
            link.append(icon("clock"), text); entry.append(link);
            return entry;
          }));
          $("upcoming-status").textContent = result.enabled === false ? "Scheduling is disabled" : "Nothing scheduled soon";
          $("upcoming-status").hidden = items.length > 0;
          $("retry-upcoming").hidden = true;
        } catch (_error) {
          $("upcoming-list").replaceChildren();
          $("upcoming-status").textContent = "Could not refresh reminders.";
          $("upcoming-status").hidden = false;
          $("retry-upcoming").hidden = false;
        }
      } while (upcomingAgain);
    })();
    try { await upcomingRequest; } finally { upcomingRequest = null; }
  }
  function invalidateUpcoming() {
    if (upcomingRequest) { upcomingAgain = true; return; }
    if (upcomingTimer === null) upcomingTimer = window.setTimeout(loadUpcoming, 80);
  }
  $("notification-search").addEventListener("input", render);
  document.querySelectorAll("[data-filter]").forEach(button => button.addEventListener("click", () => {
    filter = button.dataset.filter;
    session.set("notification_status", filter);
    document.querySelectorAll("[data-filter]").forEach(node => node.setAttribute("aria-pressed", String(node === button)));
    render();
  }));
  $("mark-all-read").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating notifications…", $("mark-all-read"));
        try {
    $("mark-all-read").disabled = true;
    try { await delivery.markAllRead(); $("notification-action-status").textContent = "All notifications marked read."; }
    catch (error) { window.SMTOErrors.present($("page-error").querySelector("span"), error); $("page-error").hidden = false; }
    finally { $("mark-all-read").disabled = false; }

        } finally { busyFeedback?.finish(); }
      });
  $("load-more-notifications").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating notifications…", $("load-more-notifications"));
        try {
    $("load-more-notifications").disabled = true;
    try { await delivery.loadMore(); } finally { $("load-more-notifications").disabled = false; }

        } finally { busyFeedback?.finish(); }
      });
  $("enable-browser-notifications").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating notifications…", $("enable-browser-notifications"));
        try {
    $("enable-browser-notifications").disabled = true;
    try { await delivery.requestPermission(); } finally { $("enable-browser-notifications").disabled = false; }

        } finally { busyFeedback?.finish(); }
      });
  $("retry-notifications").addEventListener("click", () => window.SMTOBusy.run({host: $("retry-notifications"), label: "Loading notifications…"}, () => delivery.refresh()));
  $("retry-upcoming").addEventListener("click", () => window.SMTOBusy.run({host: $("upcoming-list"), label: "Loading reminders…"}, () => loadUpcoming()));
  $("permission-icon").append(icon("bell"));
  const initialLoading = window.SMTOBusy?.begin({host: document.querySelector("main"), label: "Loading notifications…"});
  delivery.subscribe(state => {
    data = state.data;
    if (data || state.error) initialLoading?.finish();
    $("page-error").hidden = !state.error;
    $("page-error").querySelector("span").textContent = state.error;
    renderPermission(state); render();
    document.documentElement.classList.remove("app-booting");
    void resolveLink();
  });
  window.SMTOUiUpdates.subscribe(["events.changed", "settings.changed"], invalidateUpcoming);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) invalidateUpcoming(); });
  window.addEventListener("online", invalidateUpcoming);
  void loadUpcoming();
})();
