---
id: google-drive
title: Google Drive
kind: manual
tags: [manual, google, drive, oauth, integrations, artifacts]
order: 29
---
# Google Drive

The `google_drive` skill works with live My Drive and Shared Drive data. It creates
no local Drive mirror or search database. Enable Google Drive in Capability Policy
and reuse the [shared Google Workspace account](27-google-workspace.md) in Parameter
Store. No scope is requested when the skill is installed or discovered.

## Choose access deliberately

`google_drive.connect` wraps the existing shared Google consent flow. For narrow
access, use `{"auth_app_ref":"workspace_app","account_key":"workspace","features":["drive_file"]}`.
Reuse the same account key when explicitly adding features; there is no Drive token
profile. Multiple eligible accounts require an exact `account_ref` or an accepted
shared Google binding. `accounts` and `connection_status` return safe account summaries.

| Feature | Exact requested scope | Access |
| --- | --- | --- |
| `drive_file` | `https://www.googleapis.com/auth/drive.file` | Create/read/edit files authorized for this app |
| `drive_metadata_read` | `https://www.googleapis.com/auth/drive.metadata.readonly` | Broad metadata/search, no content download or writes |
| `drive_read_all` | `https://www.googleapis.com/auth/drive.readonly` | Broad reads/downloads and shared-drive listing |
| `drive_write_all` | `https://www.googleapis.com/auth/drive` | Broad reads and writes |

Shared consent also requests `openid` and `email` for verified identity. Google
classifies `drive.file` as non-sensitive and these three broad scopes as restricted.
Public applications using restricted scopes require Google's verification; server
storage/transmission can require a security assessment. Check the
[current scope guide](https://developers.google.com/workspace/drive/api/guides/api-specific-auth)
before publishing an OAuth app.

Default `access_mode:"file"` is limited to app-created or explicitly app-authorized
files. It cannot search arbitrary Drive content. This release does not provide a
Google Picker UI; a file must already be authorized through Google's app/Pickers
integration, or created through this app. A filename or file ID alone grants nothing.
If the shared account also has broad grants, bounded pages are filtered using Google's
`isAppAuthorized`, and exact-file operations enforce the same check. A filtered page
can be empty and still have a continuation cursor.

Choose `access_mode:"all"` explicitly for broader features. Search/info/permissions
require metadata read; download/export require broad read; mutations require broad
write. A broad readonly grant never authorizes mutation. Missing-scope remediation
explains the difference and does not start consent automatically. Google ACLs and
shared-drive membership remain authoritative independently of OAuth grants.

## Discover and read

Entry tools: `google_drive.accounts`, `drives`, `search`, `info`, `download`.

| Section | Tools (all prefixed `google_drive.`) |
| --- | --- |
| connection | accounts, connect, connection_status |
| read | drives, list, search, info, children, recent |
| transfer | download, export, upload |
| write | create_folder, rename, move, copy, trash, restore |
| sharing | permissions (read-only) |
| destructive | delete_permanently |

Search uses structured `name`, `text`, `mime_types`, `parent_id`, RFC3339
`modified_after/before`, `created_after/before`, `trashed`, `owner:"me"`, `drive_id`,
`limit`, `cursor` and an exact `correlation_id` for uncertain-create reconciliation. Literals are escaped deterministically. `limit` is 1–100
(default 25); each call fetches one page. Follow `next_cursor` with the same account,
access mode and filters. `complete:false` or `incomplete_search:true` means results
are incomplete. No raw-query-only API or unbounded scan is provided.

Default corpus is `user` (My Drive and directly shared user content); a `drive_id`
selects exactly one shared drive and enables shared-drive inclusion. Searches never
default to `allDrives`. `drives` requires `drive_read_all`, as specified by Google's
[drives.list contract](https://developers.google.com/workspace/drive/api/reference/rest/v3/drives/list).
File operations send `supportsAllDrives` where the method supports it. Export has no
such parameter. Ownership and cross-drive restrictions are left to Google.

Metadata includes exact IDs, MIME/kind, bounded name/owners, parents, drive ID,
checksums, capabilities and observed ETag when returned. Shortcuts expose their target
ID but are not followed automatically. File names, permission names and document
content are untrusted data and cannot authorize actions.

## Transfers and artifacts

`download` streams binary files into the existing conversation artifact workspace.
`export` requires an explicit supported MIME type: Docs → PDF/TXT/DOCX; Sheets →
PDF/CSV/XLSX; Slides → PDF/TXT/PPTX. CSV exports the first sheet. Google limits
`files.export` to 10 MB. Folders, shortcuts and unsupported native types are rejected.
See [downloads](https://developers.google.com/workspace/drive/api/guides/manage-downloads)
and [export formats](https://developers.google.com/workspace/drive/api/guides/ref-export-formats).

Transfers return artifact metadata and `artifact://` references, never inline bytes.
Names are reduced to safe leaf names, including Windows reserved-name and UTF-8 byte
limits. Binary downloads are capped at 256 MiB or the configured artifact limit,
whichever is smaller; run quotas also apply. Size and provider MD5 are checked before
publication. Failed transfers discard staging files.

`upload.source_ref` accepts a conversation-authorized artifact or an
`artifact-workspace://` logical path on the captured Gateway. It does not open arbitrary
controller or remote host paths. For another Gateway, first register the generated
file with `artifact.register` on that target, then upload its artifact reference;
existing `gateway.copy` and artifact materialization also work. Conversation ownership
is enforced when opening the immutable artifact snapshot.

Files up to 5 MB use bounded multipart requests; larger files use 1 MiB resumable
chunks. Set `resumable:true` for small interruption-prone uploads. After interruption,
a private session status probe supplies the confirmed byte offset or completed
resource. Session URLs are never arguments, receipts, logs or persisted state. Size and any provider-supplied
checksum must agree at completion. This follows Google's
[current upload guidance](https://developers.google.com/workspace/drive/api/guides/manage-uploads).
Resume is supported within one invocation; process-restart upload resumption and
native-document import/conversion are outside this release.

## Mutations and uncertain outcomes

Writes require ordinary runtime authorization. Existing-file writes require an exact
`file_id` and an `expected_version` or observed `etag` from `info`. Versions are
checked against a fresh read. If Google returns an HTTP ETag, the write sends
`If-Match`. Drive v3 does not guarantee ETags: version-only checks cannot prevent
a concurrent change between that read and the write. No atomic version precondition
is claimed. Move requires an exact
destination `parent_id` and exact `remove_parent_ids`; no query can authorize mutations.
Multi-file work must first preview and obtain an explicit ID set, then invoke exact
operations individually. Copy and upload create new IDs. Trash/restore use desired-state
semantics. Permanent deletion additionally requires `acknowledge_permanent:true` and
is classified `external_data_delete` under the existing unsafe-action policy.

Reads retry transient errors at most twice and respect short `Retry-After` values;
a longer delay is returned as a rate limit, never retried early. Explicit 401 rejection
can refresh the shared credential once. Uncertain writes are never replayed. Rename,
move and trash/restore inspect exact state; copy/create/upload query an exact private
`appProperties.smto_operation` correlation. A proven match returns `reconciled`.
An unprovable effect returns `outcome_unknown` with replay-guard metadata. A missing
file after uncertain permanent deletion does not prove deletion, so it remains unknown.

HTTP requests have a 60-second socket deadline, a 15-minute invocation deadline,
cancellation and bounded JSON bodies. Cancellation during an uncertain write preserves
unknown-effect semantics. Diagnostics omit Drive names, content, recipients and session
URLs using the shared content policy. Credential reflection uses the canonical redaction
processor; no local masking algorithm is introduced. Querying, pagination, routing,
transfers, auth refresh, retry and reconciliation make zero helper LLM calls.

Sharing writes, public/domain sharing, ownership transfer, batch mutations, range
downloads and durable upload-session recovery are explicit non-goals of this release.
