/** Opt-in prompt caching controls. All prompt previews contain section names only. */
const node = (tag, text = "") => { const value = document.createElement(tag); value.textContent = text; return value; };
const metric = (value, suffix = "") => Number.isFinite(value) ? `${value.toFixed(2)}${suffix}` : "Unknown";
function comparisonToken() {
  // Plain HTTP LAN origins lack randomUUID, but still support getRandomValues.
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return Array.from(crypto.getRandomValues(new Uint8Array(16)),
    byte => byte.toString(16).padStart(2, "0")).join("");
}
const reasons = {
  reordered: "Selected sections can extend the stable prefix. Backend cache reuse is unverified.",
  reordering_disabled: "Reordering is off; original order is preserved.",
  insufficient_selected_sections: "Select at least two movable sections in the same permitted region.",
  no_useful_permitted_permutation: "No useful movement is permitted by these selections and protected boundaries.",
  custom_template_or_protected_projection: "This custom template or protected projection stays indivisible.",
  protected_boundaries: "Selected sections cannot cross a protected boundary.",
};

export function create({getValue, onChange, beforeCompare, defaultPhase = "execution_task_context", managedInference = false}) {
  const element = node("div"); element.className = "prompt-caching-settings";
  const controls = node("div"), phases = node("div"), diagnostics = node("div"), notice = node("aside");
  element.append(controls, phases, diagnostics, notice);
  const status = node("p"); status.setAttribute("role", "status"); element.append(status);
  const api = (path, options = {}) => window.SMTOAgentUi.apiJson(`/prompt-cache${path}`, options);
  let data = null, disposed = false, timer = null, job = null, busy = false, selectedPhase = defaultPhase;
  let previewVersion = 0;
  const expanded = new Set();
  const value = () => ({version: 1, enabled: false, reorder: false, fragment_reuse: false, diagnostics: false, sections: {}, ...getValue()});
  function toggle(label, checked, disabled, update, id) {
    const row = node("label"); row.className = "mission-switch-row";
    const input = node("input"); input.type = "checkbox"; input.className = "mission-switch";
    input.setAttribute("role", "switch"); input.id = `prompt-cache-${id}`;
    input.checked = Boolean(checked); input.disabled = disabled;
    input.addEventListener("change", () => {
      update(input.checked); render(); document.getElementById(input.id)?.focus(); void preview();
    });
    row.append(input, node("span", label)); return row;
  }
  function change(key, checked) { onChange({...value(), [key]: checked}); }
  function render() {
    if (disposed) return;
    const focused = document.activeElement?.id;
    const policy = value();
    controls.replaceChildren();
    for (const [key, label] of [["enabled", "Prompt caching"], ["reorder", "Reorder prompt sections"],
      ["fragment_reuse", "Additional instruction-fragment reuse"], ["diagnostics", "Cache diagnostics"]]) {
      controls.append(toggle(label, policy[key], key !== "enabled" && !policy.enabled, checked => change(key, checked), key));
    }
    controls.append(node("p", "Off preserves the original prompt and execution path. Saved selections stay in place. Changes apply to the next logical model request; calls already started finish with their captured settings."));
    phases.replaceChildren();
    for (const phase of data?.phases || []) {
      const group = node("details"); group.open = expanded.has(phase.id);
      group.addEventListener("toggle", () => group.open ? expanded.add(phase.id) : expanded.delete(phase.id));
      group.append(node("summary", phase.label));
      for (const section of phase.sections) {
        if (section.locked) { group.append(node("p", `🔒 ${section.label} — fixed`)); continue; }
        group.append(toggle(`Allow ${section.label} reordering${section.conditional ? " (when present)" : ""}`,
          policy.sections?.[phase.id]?.[section.id], !policy.enabled || !policy.reorder,
          checked => onChange({...value(), sections: {...value().sections,
            [phase.id]: {...value().sections?.[phase.id], [section.id]: checked}}}), `${phase.id}-${section.id}`));
      }
      group.append(node("p", `Original: ${phase.original.join(" → ")}`), node("p", `Proposed: ${phase.proposed.join(" → ")}`),
        node("p", reasons[phase.reason] || phase.reason), node("p", phase.note));
      phases.append(group);
    }
    renderDiagnostics();
    if (focused?.startsWith("prompt-cache-")) document.getElementById(focused)?.focus();
  }
  function reportView(report) {
    const box = node("div");
    box.append(node("p", `${report.phase || "Model request"} · ${report.verdict || "Insufficient evidence"} · ${report.sample_count || 1} sample(s)`));
    for (const [key, label, unit] of [["input_tokens", "Observed input", " tokens"], ["cached_tokens", "Observed cached input", " tokens"],
      ["reuse_percent", "Provider reuse", "%"], ["construction_ms", "Construction", " ms"],
      ["fragment_render_ms", "Additional instruction rendering", " ms"],
      ["provider_input_ms", "Provider input processing", " ms"], ["scheduler_wait_ms", "Scheduler wait", " ms"],
      ["first_actionable_ms", "First actionable output", " ms"], ["total_ms", "Total request", " ms"]]) {
      box.append(node("p", `${label}: ${metric(report[key], unit)}`));
    }
    box.append(node("p", `Local fragment hits: ${metric(report.fragment_hits)}; misses: ${metric(report.fragment_misses)}. A provider cache hit alone does not establish improvement.`));
    const settings = node("details"); settings.append(node("summary", "Effective configuration and checks"),
      node("pre", JSON.stringify({revision: report.policy_revision, configuration: report.configuration,
        layouts: report.layouts, correctness_checks: report.correctness_checks,
        scope: report.scope, sources: report.sources, provider_evidence_scope: report.provider_evidence_scope}, null, 2)));
    box.append(settings); return box;
  }
  function renderDiagnostics() {
    if (disposed) return;
    const policy = value(); diagnostics.replaceChildren();
    diagnostics.append(node("p", "Runtime evidence uses observed values. Unknown values are not zero; synthetic request improvements do not prove whole-task improvements."));
    const label = node("label", "Comparison phase "); label.className = "mission-field-row";
    const select = node("select"); select.setAttribute("aria-label", "Comparison phase");
    for (const phase of data?.phases || []) { const option = node("option", phase.label); option.value = phase.id; select.append(option); }
    select.value = selectedPhase; select.disabled = !policy.enabled || !policy.diagnostics || busy;
    select.addEventListener("change", () => { selectedPhase = select.value; renderDiagnostics(); void refresh().catch(() => {}); }); label.append(select); diagnostics.append(label);
    diagnostics.append(node("p", `Target: ${data?.target?.model || "Unknown"} · ${data?.target?.base_url || data?.target?.endpoint || "configured endpoint"}. Capability selection retains configured helper routing. Engine configuration is unverified.`));
    diagnostics.append(node("p", `Budget: 2 warmup pairs + 20 measured pairs; normally 44 inference attempts, maximum 64 including retries; 15 minutes including waits. Output allowance: ${data?.output_token_allowance ?? "current phase configuration"} tokens per attempt. No generated operations are executed.`));
    const start = node("button", "Compare original vs enabled"); start.type = "button";
    start.disabled = !policy.enabled || !policy.diagnostics || busy || data?.default_phase !== selectedPhase || ["queued", "running"].includes(job?.status);
    start.addEventListener("click", async () => {
      busy = true; renderDiagnostics();
      try {
        await beforeCompare(); await refresh(false);
        if (disposed || !value().enabled || !value().diagnostics) return;
        job = await api("/comparisons", {method: "POST", body: {phase: selectedPhase,
          expected_revision: data.revision, idempotency_token: comparisonToken()}});
        status.textContent = "Synthetic comparison started."; poll();
      } catch (error) { status.textContent = error.message; }
      finally { busy = false; renderDiagnostics(); }
    });
    const refreshButton = node("button", "Refresh runtime evidence"); refreshButton.type = "button";
    refreshButton.addEventListener("click", () => void refresh()); diagnostics.append(start, refreshButton);
    if (data?.comparisons?.length) {
      const history = node("select"); history.setAttribute("aria-label", "Saved comparison results");
      for (const item of [...data.comparisons].reverse()) {
        const option = node("option", `${item.phase} · ${item.result?.verdict || item.status} · ${item.id.slice(0, 8)}`);
        option.value = item.id; history.append(option);
      }
      history.value = job?.id || "";
      history.addEventListener("change", () => { job = data.comparisons.find(item => item.id === history.value); renderDiagnostics(); });
      diagnostics.append(node("label", "Recent comparisons"), history);
    }
    if (job) {
      diagnostics.append(node("p", `${job.status}: ${job.completed_pairs} measured pairs; ${job.inference_attempts} inference attempts.`));
      const cancel = node("button", "Cancel comparison"); cancel.type = "button";
      cancel.disabled = !["queued", "running"].includes(job.status);
      cancel.addEventListener("click", async () => { try { job = await api(`/comparisons/${job.id}/cancel`, {method: "POST"}); renderDiagnostics(); } catch (error) { status.textContent = error.message; } });
      diagnostics.append(cancel);
      if (job.result) {
        diagnostics.append(node("p", `${job.result.verdict} — ${job.result.scope}`),
          node("p", `Paired median change: ${metric(job.result.paired_median_percent, "%")}; approximate 95% interval: ${job.result.confidence_interval_percent?.map(v => metric(v, "%")).join(" to ") || "Unknown"}.`),
          node("p", job.result.p95_scope));
        diagnostics.append(node("p", `${job.result.valid_pairs} valid pairs of ${job.result.attempted_pairs} attempted. Correctness regression: ${job.result.correctness_regression ? "Yes" : "Not observed"}; baseline failures: ${job.result.baseline_failure ? "Yes" : "Not observed"}; detected interference or configuration mismatch: ${job.result.contaminated ? "Yes" : "Not observed"}. Backend cache state and replica identity remain unknown unless reported.`));
        const table = node("table"); table.className = "activity-events-table";
        const head = node("tr"); for (const text of ["Component", "Original median / p95", "Enabled median / p95", "Difference"]) head.append(node("th", text)); table.append(head);
        for (const [key, item] of Object.entries(job.result.components || {})) {
          const row = node("tr"); for (const text of [key.replaceAll("_", " "),
            `${metric(item.original.median)} / ${metric(item.original.p95)} ms`, `${metric(item.enabled.median)} / ${metric(item.enabled.p95)} ms`,
            `${metric(item.absolute_change, " ms")} (${metric(item.percent_change, "%")})`]) row.append(node("td", text)); table.append(row);
        }
        const scroll = node("div"); scroll.className = "activity-events-scroll"; scroll.append(table); diagnostics.append(scroll);
        diagnostics.append(node("p", job.reason || ""));
      }
    }
    const observations = node("details"); observations.append(node("summary", "Recent model-call evidence"));
    for (const report of (data?.observations || []).slice(-8).reverse()) observations.append(reportView(report));
    diagnostics.append(observations);
  }
  async function preview() {
    const version = ++previewVersion;
    try { const response = await api("/preview", {method: "POST", body: value()});
      if (!disposed && version === previewVersion) { data = {...data, phases: response.phases}; render(); }
    } catch (error) { if (!disposed) status.textContent = error.message; }
  }
  async function refresh(draw = true) {
    try { const response = await api(`?phase=${encodeURIComponent(selectedPhase)}`); if (disposed) return;
      const previousError = data?.error; data = response;
      job = data.comparisons?.find(item => item.id === job?.id) || data.comparisons?.at(-1) || null;
      if (data.error) status.textContent = data.error;
      else if (previousError && status.textContent === previousError) status.textContent = "";
      if (draw) render();
    } catch (error) { if (!disposed) status.textContent = error.message; throw error; }
  }
  function poll() {
    clearTimeout(timer);
    if (disposed || !value().enabled || !value().diagnostics || !["queued", "running"].includes(job?.status)) return;
    timer = setTimeout(async () => { try { job = await api(`/comparisons/${job.id}`); if (!disposed) renderDiagnostics(); }
      catch (error) { if (!disposed) status.textContent = error.message; } poll(); }, 1500);
  }
  notice.append(node("strong", managedInference ? "Inference launch settings" : "⚠ Update inference engine"),
    node("p", managedInference
      ? "Enabling Prompt caching here also enables the advertised backend cache option in connected agent/helper profiles. Apply / Restart running instances to use changed launch settings. Turning this switch off keeps the saved backend options; edit them in the instance’s Performance or Advanced tab."
      : "Engine configuration is manual and independent. Installed configuration has not been verified."),
    node("p", "For supported vLLM versions: --enable-prefix-caching and --enable-prompt-tokens-details. For llama.cpp, check the installed binary’s --help for --cache-prompt and optional finite --cache-ram / --cache-idle-slots controls. Choose retention for your machine; no RAM allocation is prescribed."));
  for (const [label, href] of [["vLLM reference", "https://docs.vllm.ai/en/latest/cli/serve/"], ["llama.cpp reference", "https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md"]]) {
    const link = node("a", label); link.href = href; link.target = "_blank"; link.rel = "noopener noreferrer"; notice.append(link, document.createTextNode(" "));
  }
  render(); void refresh().catch(() => {});
  return {element, refresh: render, destroy() { disposed = true; clearTimeout(timer); }};
}
