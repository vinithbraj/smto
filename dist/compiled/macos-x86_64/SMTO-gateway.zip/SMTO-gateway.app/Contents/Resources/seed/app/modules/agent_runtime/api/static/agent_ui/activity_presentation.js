/* Read-only row presentation shared by live and retained activity. No transport or run authority. */
(() => {
  "use strict";
  const node = (tag, className = "", text = "") => {
    const element = document.createElement(tag); element.className = className; element.textContent = text;
    return element;
  };
  const labels = new WeakMap();
  const sectionGroups = new WeakMap(), sectionControls = new WeakMap();
  let sectionSequence = 0;
  // Keep the original disclosures mounted: their toggle events own lazy loading
  // and live stream suspension/resumption. Only their visible controls change.
  function attachSection(parent, disclosure, label, order = 1) {
    if (sectionControls.has(disclosure)) return sectionControls.get(disclosure);
    let group = sectionGroups.get(parent);
    if (!group) {
      const root = node("div", "activity-disclosures"), controls = node("div", "activity-section-controls");
      controls.setAttribute("role", "group"); controls.setAttribute("aria-label", "Activity sections");
      root.append(controls); parent.append(root);
      group = {root, controls, entries: []}; sectionGroups.set(parent, group);
    }
    const summary = disclosure.querySelector(":scope > summary");
    const button = node("button", `activity-section-toggle ${summary?.className || ""}`.trim(), label);
    button.type = "button";
    if (summary) { summary.hidden = true; summary.className = ""; }
    disclosure.classList.add("activity-section-disclosure");
    disclosure.id ||= `activity-section-${++sectionSequence}`;
    button.setAttribute("aria-controls", disclosure.id);
    const sync = () => button.setAttribute("aria-expanded", String(disclosure.open));
    button.addEventListener("click", () => { disclosure.open = !disclosure.open; sync(); });
    disclosure.addEventListener("toggle", sync); sync();
    const next = group.entries.find(entry => entry.order > order);
    group.controls.insertBefore(button, next?.button || null);
    group.root.insertBefore(disclosure, next?.disclosure || null);
    group.entries.push({button, disclosure, order}); group.entries.sort((a, b) => a.order - b.order);
    sectionControls.set(disclosure, button);
    return button;
  }
  const clean = value => typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 600) : "";
  // Scheduling and legacy tool events must survive even without an invocation
  // projection. Admission is a queued row, never proof of execution.
  function operationEvent(event = {}) {
    const d = event.detail || {}, type = event.event_type || "";
    if (!(d.operation_id || d.action_id || d.execution_id)) return event;
    let phase, status = d.status || d.state;
    if (["tool.accepted", "activity.created", "activity.runnable", "activity.started"].includes(type)) {
      phase = "queued"; status = "queued";
    } else if (["activity.waiting", "activity.resource_wait", "activity.queued"].includes(type)) {
      phase = "queued"; status = status || "queued";
    } else if (type === "tool.started") phase = "started";
    else if (/^tool\.(completed|failed|cancelled)$/.test(type)
        || /^activity\.(completed|failed|cancelled|interrupted|blocked_conflict|blocked_dependency|skipped|unknown)$/.test(type)) {
      phase = "completed";
      const terminal = type.split(".").at(-1);
      status = terminal === "completed" ? status || terminal : terminal;
      if (["rejected_policy", "blocked_conflict", "blocked_dependency"].includes(status)) status = "blocked";
    }
    if (!phase) return event;
    return {...event, source_event_type: type, event_type: `invocation.${phase}`, detail: {...d,
      capability_id: d.capability_id || d.tool_name?.replaceAll("__", ".") || d.tool?.replaceAll("__", "."), status}};
  }
  function merge(previous, event) {
    const detail = {...previous?.detail, ...event.detail,
      presentation: {...previous?.detail?.presentation, ...event.detail?.presentation}},
      version = previous?.detail?.detail_version;
    if (version === "completed" && detail.detail_version?.startsWith("pending")) detail.detail_version = version;
    return {...previous, ...event, detail,
      command_preview: event.command_preview || previous?.command_preview,
      command_detail_url: event.command_detail_url || previous?.command_detail_url};
  }
  function outcome(event, previous) {
    const d = event.detail || {}, type = event.event_type || "";
    if (["success", "failure", "cancelled"].includes(previous)
        && /\.(started|queued|request|progress|delta)$/.test(type)) return previous;
    const states = [d.status, d.state, d.job_state, d.process_state];
    if (states.some(s => ["outcome_unknown", "unknown_effect"].includes(s)) || d.effect_unknown) return "incomplete";
    if (/\.(failed|error|rejected|attempt_failed)$/.test(type)
        || states.some(s => ["failed", "error", "timed_out", "failed_to_start", "rejected"].includes(s))
        || Number.isInteger(d.exit_code) && d.exit_code !== 0) return "failure";
    if (/\.(cancelled|interrupted)$/.test(type) || states.some(s => ["cancelled", "interrupted", "stopped"].includes(s))) return "cancelled";
    if (states.some(s => ["running", "starting", "running_background", "waiting_job"].includes(s)) || d.terminal_detached) return "running";
    if (/\.(queued|pending|resource_wait|scheduler_wait\.started)$/.test(type)
        || states.some(s => ["pending", "queued", "pending_dependency", "runnable_waiting_capacity", "blocked_resource", "waiting_capacity"].includes(s))) return "pending";
    if (states.some(s => ["waiting_user", "waiting_approval", "waiting_event", "waiting_job", "awaiting_confirmation"].includes(s))) return "pending";
    const controllerSuccess = d.controller_operation && states.some(s => ["success", "completed"].includes(s));
    if (d.executed === false && !controllerSuccess || states.some(s => ["blocked", "not_executed", "partial", "incomplete", "unknown", "skipped"].includes(s))) return "incomplete";
    if (/\.(completed|response|accepted|succeeded)$/.test(type) || states.some(s => ["completed", "succeeded", "success"].includes(s)))
      return ["failure", "cancelled", "incomplete"].includes(previous) && (event.source_event_type || type) === "activity.completed" ? previous
        : previous === "failure" && type === "invocation.completed" ? previous : "success";
    if (/\.(started|request)$/.test(type)) return "running";
    return previous;
  }
  function describe(event = {}, state) {
    const d = event.detail || {}, p = d.presentation || {}, type = event.event_type || "";
    const capability = clean(d.capability_id || p.capability_id || d.tool_name).replaceAll("__", ".");
    const model = /^(llm|model)\./.test(type);
    const phase = state === "success" ? "completed" : state === "failure" ? "failed" : "running";
    const target = clean(p.compact_context || d.display_target);
    const specific = clean(p[`compact_${phase}_label`] || p[`${phase}_label`]);
    let rich = model ? "Thinking" : specific || clean(d.label) || capability || clean(event.title) || "Activity";
    const qualifier = state === "cancelled" ? "Stopped" : state === "incomplete"
      ? d.executed === false && !d.remote_effect_possible ? "Not executed" : "Outcome unknown or incomplete"
      : state === "pending" ? "Pending" : state === "failure" ? "Failed" : "";
    if (qualifier && (!specific || !["success", "failure"].includes(state))) rich += ` · ${qualifier}`;
    if (state === "failure" && d.executed === false && !d.remote_effect_possible) rich += " · Not executed";
    const selected = d.selected_skill_ids || d.requested_skill_ids;
    const summary = [selected?.join(" · "), d.dependency_tool_ids?.length ? `Required tools: ${d.dependency_tool_ids.join(", ")}` : "",
      d.unavailable_skill_ids?.length ? `Unavailable: ${d.unavailable_skill_ids.join(", ")}` : "",
      d.added_skill_ids?.length ? `Added: ${d.added_skill_ids.join(", ")}` : "",
      d.removed_skill_ids?.length ? `Removed: ${d.removed_skill_ids.join(", ")}` : ""].filter(Boolean).join(". ");
    const status = qualifier || ({success: "completed", failure: "failed", running: "running", pending: "pending"}[state] || "");
    const simple = model ? ["Model response", d.phase || event.stage, status].filter(Boolean).join(" · ")
      : capability ? [capability, target || specific, status].filter(Boolean).join(" · ") : rich;
    return {rich, simple, capability, target, summary,
      icon: window.SMTOActionIcons.resolve({...d, capability_id: capability}, model ? "thinking" : type.startsWith("capability_") ? "user" : "runtime"),
      context: clean(p.context_detail || p.trace_detail || p.detail),
      elapsed: Number.isFinite(d.elapsed_ms) ? d.elapsed_ms : Number.isFinite(d.wait_seconds) ? d.wait_seconds * 1000 : null};
  }
  function richLabel(element) {
    let rich = element.querySelector(":scope > .activity-label-rich");
    if (!rich) {
      rich = node("span", "activity-label-rich");
      for (const child of [...element.childNodes]) {
        if (child.nodeType !== 1 || !child.matches(".action-type-icon, [data-ui-symbol]")) rich.append(child);
      }
      element.append(rich);
    }
    return rich;
  }
  function decorateLabel(element, event, state) {
    const previous = labels.get(element);
    event = merge(previous, event);
    labels.set(element, event);
    richLabel(element);
    let simple = element.querySelector(":scope > .activity-label-event");
    if (!simple) { simple = node("span", "activity-label-event"); element.append(simple); }
    simple.textContent = describe(event, state ?? outcome(event)).simple;
  }
  function createRow({kind = "execution", title = "", summary = "", iconText = "", button = false} = {}) {
    const item = node("div", `work-item ${kind}-item`), icon = node("span", "work-icon", iconText);
    const typeIcon = window.SMTOActionIcons.create(kind), copy = node("div", "work-copy");
    const heading = node(button ? "button" : "strong", button ? "activity-event-toggle" : "", title);
    if (button) { heading.type = "button"; heading.setAttribute("aria-expanded", "false"); }
    const paragraph = node("p", "", summary); paragraph.hidden = !summary;
    copy.append(heading, paragraph); item.append(icon, typeIcon, copy);
    return {item, icon, typeIcon, copy, title: heading, summary: paragraph, output: null, outputSummary: null};
  }
  function applySettings(settings = {}) {
    // Only CSS changes: nodes, focus, disclosures, observers and scroll anchors survive.
    const value = String(settings.ui_activity_events_only === true);
    if (document.documentElement.dataset.activityEventsOnly === value) return;
    const viewports = new Set([document.scrollingElement, ...document.querySelectorAll(".conversation-viewport, #thread")]);
    const positions = [...viewports].filter(Boolean).map(element => [element, element.scrollTop, element.scrollLeft]);
    document.documentElement.dataset.activityEventsOnly = value;
    for (const [element, top, left] of positions) { element.scrollTop = top; element.scrollLeft = left; }
  }
  window.SMTOActivityPresentation = {createRow, richLabel, decorateLabel, describe, outcome, merge, applySettings, operationEvent, attachSection};
})();
