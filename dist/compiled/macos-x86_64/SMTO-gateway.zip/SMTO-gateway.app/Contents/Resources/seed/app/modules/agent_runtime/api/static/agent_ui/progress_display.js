/* User-only progress rendering. No transport, tools, or execution-state authority. */
(() => {
  "use strict";
  const bounded = (s, n = 240) => typeof s === "string" ? s.replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, n) : "";
  function receive(state, reports, requestId) {
    if (requestId && !state.displayRequestId) state.displayRequestId = requestId;
    state.displayReports ||= new Map();
    for (const report of reports || []) {
      if (report?.schema_version !== 1 || !Number.isSafeInteger(report.source_cursor)) continue;
      if (state.displayRequestId && report.request_id !== state.displayRequestId) continue;
      const key = report.operation_id || `@${report.provider_id}`;
      if (report.source_cursor <= (state.displayReports.get(key)?.source_cursor || 0)) continue;
      state.displayReports.set(key, report);
      while (state.displayReports.size > 128) state.displayReports.delete(state.displayReports.keys().next().value);
    }
  }
  const number = n => Number.isFinite(n) && n >= 0 ? n.toLocaleString(undefined, {maximumFractionDigits: 1}) : "";
  const withParts = (value, detailParts) => ({...value, detailParts,
    detail: detailParts.map(part => part.text).join(" · ")});
  function overlay(state, value, now) {
    if (!state || !["running", "pending"].includes(state.status) || state.stopping || state.pausing
        || ["waiting", "terminal", "stopping", "pausing", "resuming", "model_recovery"].includes(value.kind)) return value;
    const operation = value.actionId || value.operation_id;
    if (operation && operation === state.executionStatus?.operation_id
        && ["operation_completed", "outcome_unknown", "admitted"].includes(state.executionStatus.state)) return value;
    const reports = [...(state.displayReports?.values() || [])];
    const report = operation ? state.displayReports?.get(operation)
      : reports.filter(r => !r.operation_id && r.source_cursor >= (state.progressBoundary || 0))
        .sort((a, b) => b.source_cursor - a.source_cursor)[0];
    const parts = value.detailParts ? [...value.detailParts] : value.detail ? [{
      key: JSON.stringify(["base", operation || ""]), text: value.detail,
      transitionKey: value.detailTransitionKey,
    }] : [];
    const children = state.displayChildren;
    if (!operation && children?.scope === "known_child_operations") {
      const counts = ["active", "completed", "failed", "cancelled"].filter(k => Number.isSafeInteger(children[k]) && children[k] > 0)
        .map(k => `${children[k]} ${k}`);
      if (counts.length) {
        parts.push({key: "known-actions", text: `Known actions: ${counts.join(", ")}`});
        value = withParts(value, parts);
      }
    }
    if (!report || state.operations?.get(operation)?.terminal) return value;
    const details = [];
    if (report.availability === "available") {
      for (const metric of (report.measurements || []).slice(0, 8)) {
        if (!number(metric.completed)) continue;
        const total = Number.isFinite(metric.total) && metric.total >= metric.completed ? ` of ${number(metric.total)}` : "";
        const percent = total && metric.total > 0 ? ` (${number(100 * metric.completed / metric.total)}%)` : "";
        details.push(`${bounded(metric.label, 100)} ${number(metric.completed)}${total} ${bounded(metric.unit, 40)}${percent}`);
      }
      if (report.detail) details.push(bounded(report.detail, 500));
      if (report.output_excerpt) details.push(`Last output: ${bounded(report.output_excerpt)}`);
    } else if (report.availability === "error") details.push("Detailed progress unavailable");
    const at = Math.max(report.last_activity_at || 0, report.last_progress_at || 0, report.observed_at || 0);
    const age = Number.isFinite(at) ? Math.max(0, Math.floor(now / 1000 - at)) : null;
    if (age !== null && age >= 30) details.push(`Last update ${age}s ago`);
    if (report.incomplete) details.push("Some progress evidence unavailable");
    // Existing supervision/terminal copy retains priority and meaning.
    const existing = value.detail && !details.includes(value.detail) ? value.detail : "";
    const label = report.availability === "available" && report.label && (operation || value.kind === "preparing")
      ? bounded(report.label) : null;
    const text = details.join(" · ");
    return withParts({...value, ...(label ? {label,
      labelTransitionKey: [report.provider_id, operation || "", label]} : {})}, [
      ...(text ? [{key: JSON.stringify(["provider", report.provider_id, operation || ""]), text,
        transitionKey: [report.phase, report.availability, text]}] : []),
      ...(existing ? parts : []),
    ]);
  }
  window.SMTOProgressDisplay = {receive, overlay};
})();
