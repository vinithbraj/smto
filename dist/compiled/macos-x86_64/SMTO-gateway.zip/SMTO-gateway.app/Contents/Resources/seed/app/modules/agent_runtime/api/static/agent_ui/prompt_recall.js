/* Text-only recall over the existing, bounded server history. No storage or requests. */
(() => {
  "use strict";
  const normalize = text => text.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
  function search(history, query, limit = 20) {
    const needle = normalize(query);
    return [...new Set(history.filter(text => typeof text === "string" && text.trim()))].reverse()
      .map((text, recent) => {
        const value = normalize(text);
        const rank = !needle || value === needle ? 0 : value.startsWith(needle) ? 1 : value.includes(needle) ? 2 : 3;
        return {text, recent, rank};
      }).filter(item => item.rank < 3)
      .sort((a, b) => a.rank - b.rank || a.recent - b.recent).slice(0, limit).map(item => item.text);
  }
  function suggest(history, prefix) {
    if (prefix.replace(/\s/g, "").length < 3 || prefix.includes("\n")) return "";
    const needle = prefix.toLocaleLowerCase("en-US");
    return [...history].reverse().find(text => text.length > prefix.length
      && text.toLocaleLowerCase("en-US").startsWith(needle)) || "";
  }
  function create({input, button, ghost, hint, getHistory, setPrompt, resize, interactionWaiting, isSteering, resourcesOpen = () => false}) {
    let matches = [], selected = 0;
    const dialog = document.createElement("dialog");
    dialog.id = "prompt-recall";
    dialog.className = "prompt-recall";
    dialog.setAttribute("aria-labelledby", "prompt-recall-title");
    dialog.innerHTML = `<div class="prompt-recall-heading"><strong id="prompt-recall-title">Recall a prompt</strong>
      <button type="button" aria-label="Close Prompt Recall" data-ui-symbol="cross">×</button></div>
      <label class="sr-only" for="prompt-recall-search">Search previous prompts</label>
      <input id="prompt-recall-search" type="search" placeholder="Search previous prompts…" autocomplete="off"
        role="combobox" aria-autocomplete="list" aria-expanded="true" aria-controls="prompt-recall-results" />
      <div id="prompt-recall-results" role="listbox" aria-label="Previous prompts"></div>
      <p class="prompt-recall-empty" hidden>No matching prompts.</p>
      <p class="prompt-recall-help">↑/↓ to select · Enter to insert · Esc to close</p>`;
    document.body.append(dialog);
    const field = dialog.querySelector("input"), results = dialog.querySelector('[role="listbox"]');
    const unsafe = () => interactionWaiting() || isSteering();
    const history = () => getHistory().filter(text => typeof text === "string");
    const completion = window.SMTOPromptAutocomplete.create({input, ghost, hint,
      getHistory: history, setPrompt, resize, disabled: () => dialog.open || resourcesOpen()});
    const clearGhost = completion.clear;
    function update() {
      button.disabled = unsafe();
      if (button.disabled && dialog.open) dialog.close();
      completion.update();
      if (document.activeElement !== input) window.SMTOPromptAutocomplete.refresh();
    }
    function highlight() {
      [...results.children].forEach((option, index) => option.setAttribute("aria-selected", String(index === selected)));
      const option = results.children[selected];
      if (option) { field.setAttribute("aria-activedescendant", option.id); option.scrollIntoView({block: "nearest"}); }
      else field.removeAttribute("aria-activedescendant");
    }
    function render() {
      matches = search(history(), field.value); selected = 0; results.replaceChildren();
      matches.forEach((text, index) => {
        const option = document.createElement("div"); option.id = `prompt-recall-option-${index}`;
        option.setAttribute("role", "option"); option.textContent = text;
        option.addEventListener("mousedown", event => event.preventDefault());
        option.addEventListener("click", () => insert(index)); results.append(option);
      });
      dialog.querySelector(".prompt-recall-empty").hidden = matches.length > 0;
      highlight();
    }
    function insert(index) {
      if (unsafe() || !matches[index]) return;
      const text = matches[index]; dialog.close(); clearGhost(); setPrompt(text);
    }
    function open() {
      if (unsafe() || dialog.open) return;
      clearGhost(); field.value = ""; render(); dialog.showModal();
      button.setAttribute("aria-expanded", "true"); field.focus();
    }
    button.addEventListener("click", open);
    dialog.querySelector("button").addEventListener("click", () => dialog.close());
    dialog.addEventListener("close", () => {
      button.setAttribute("aria-expanded", "false"); field.value = ""; results.replaceChildren(); matches = [];
      input.focus();
    });
    dialog.addEventListener("click", event => { if (event.target === dialog && !event.target.closest(".prompt-recall-heading")) {
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
    } });
    field.addEventListener("input", render);
    dialog.addEventListener("keydown", event => {
      event.stopPropagation();
      if (event.isComposing) return;
      if (["ArrowDown", "ArrowUp"].includes(event.key)) {
        event.preventDefault(); selected = Math.max(0, Math.min(matches.length - 1, selected + (event.key === "ArrowDown" ? 1 : -1))); highlight();
      } else if (event.key === "Enter") { event.preventDefault(); insert(selected); }
      else if (event.key === "Escape") { event.preventDefault(); dialog.close(); }
    });
    document.addEventListener("keydown", event => {
      if (!event.isComposing && (event.ctrlKey || event.metaKey) && event.shiftKey && !event.altKey
        && event.key.toLowerCase() === "h" && !document.querySelector("dialog[open]")) { event.preventDefault(); open(); }
    });
    return {update, open, keydown: completion.keydown};
  }
  window.SMTOPromptRecall = {create, search, suggest};
})();
