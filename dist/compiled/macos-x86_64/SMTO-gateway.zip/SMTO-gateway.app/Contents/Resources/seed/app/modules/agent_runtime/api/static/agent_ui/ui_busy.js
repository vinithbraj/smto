/* User-action loading feedback. Transport, polling and Agent execution do not own it. */
(() => {
  "use strict";
  const active = new Set(), owners = new WeakMap(), regions = new WeakMap();
  let sequence = 0, observer;
  const element = value => typeof value === "string" ? document.querySelector(value) : value;

  function begin({host, label, key, replace = false, abortable = false, placement, region, announce = true} = {}) {
    host = element(host) || document.querySelector('dialog[open] form, .sheet-body, main') || document.body;
    region = element(region) || host;
    const bucket = owners.get(host) || new Map(); owners.set(host, bucket);
    key = key || Symbol("operation");
    if (replace) bucket.get(key)?.dispose();
    const controller = abortable ? new AbortController() : null;
    const status = document.createElement("span");
    status.dataset.uiFindIgnore = "";
    status.className = "smto-busy"; status.dataset.busyId = String(++sequence);
    if (announce) {
      status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
      status.setAttribute("aria-atomic", "true");
    }
    const ring = document.createElement("span"); ring.className = "smto-busy-ring";
    ring.setAttribute("aria-hidden", "true");
    const text = document.createElement("span"); text.className = "smto-busy-label";
    status.append(ring, text);
    let done = false, timer, wasConnected = host.isConnected;
    let dialog = host.closest("dialog"), wasOpen = Boolean(dialog?.open);
    const foldsFor = target => {
      const folds = new Map();
      for (let parent = target; parent; parent = parent.parentElement) {
        if (parent.matches("details")) folds.set(parent, parent.open);
      }
      return folds;
    };
    let folds = foldsFor(host);
    const closed = () => handle.dispose();
    const mount = () => {
      if (status.isConnected || !host.isConnected) return;
      const where = placement || (host.matches("button, a, input, select") ? "after" : "before");
      if (where === "append" || host === document.body) host.append(status);
      else if (where === "after") host.after(status);
      else host.before(status);
    };
    let tracked = regions.get(region) || {count: 0, previous: region.getAttribute("aria-busy")};
    tracked.count++; regions.set(region, tracked); region.setAttribute("aria-busy", "true");
    const releaseRegion = () => {
      if (--tracked.count === 0) {
        if (tracked.previous === null) region.removeAttribute("aria-busy");
        else region.setAttribute("aria-busy", tracked.previous);
        regions.delete(region);
      }
    };
    const release = abort => {
      if (done) return;
      done = true; clearTimeout(timer); active.delete(handle); status.remove();
      dialog?.removeEventListener("close", closed);
      if (bucket.get(key) === handle) bucket.delete(key);
      releaseRegion();
      if (abort) controller?.abort();
      if (!active.size) { observer?.disconnect(); observer = null; }
    };
    const handle = {
      id: status.dataset.busyId, signal: controller?.signal, status,
      get current() { return !done && bucket.get(key) === handle; },
      update(value) { if (!done && text.textContent !== value) text.textContent = value; },
      move(target) {
        target = element(target);
        if (done || !target || target === host) return;
        releaseRegion(); dialog?.removeEventListener("close", closed); status.remove();
        host = region = target; dialog = host.closest("dialog"); wasOpen = Boolean(dialog?.open);
        folds = foldsFor(host);
        tracked = regions.get(region) || {count: 0, previous: region.getAttribute("aria-busy")};
        tracked.count++; regions.set(region, tracked); region.setAttribute("aria-busy", "true");
        dialog?.addEventListener("close", closed); mount();
      },
      finish() { release(false); },
      dispose() { release(true); },
      check() {
        if (dialog?.open) wasOpen = true;
        else if (dialog && wasOpen) { handle.dispose(); return; }
        for (const [fold, wasExpanded] of folds) {
          if (fold.open) folds.set(fold, true);
          else if (wasExpanded) { handle.dispose(); return; }
        }
        if (host.isConnected) { wasConnected = true; mount(); }
        else if (wasConnected) handle.dispose();
      },
    };
    bucket.set(key, handle); active.add(handle); mount(); handle.update(label ?? "Working…");
    dialog?.addEventListener("close", closed);
    timer = setTimeout(() => { if (handle.current) status.classList.add("smto-busy-delayed"); }, 2000);
    if (!observer && document.documentElement) {
      observer = new MutationObserver(() => { for (const operation of active) operation.check(); });
      observer.observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ["open"]});
    }
    return handle;
  }
  async function run(options, action) {
    const operation = begin(options);
    try { return await action(operation); }
    finally { operation.finish(); }
  }
  // Bind at an action boundary, never at fetch: chained preparation shares this timer.
  function wrap(options, action) {
    return function (...args) {
      const settings = typeof options === "function" ? options.apply(this, args) : options;
      return settings ? run(settings, operation => action.apply(this, [...args, operation])) : action.apply(this, args);
    };
  }
  // A view owns its reads. Closing/replacing it invalidates even non-abortable results.
  function view(host) {
    let generation = 0, operation = null;
    const dispose = () => { generation++; operation?.dispose(); operation = null; };
    return {
      dispose,
      begin(label) {
        dispose(); const accepted = generation;
        operation = begin({host, label, key: "view", replace: true, abortable: true});
        const own = operation;
        return {signal: own.signal, update: value => own.update(value),
          get current() { return accepted === generation && own.current; },
          finish: () => own.finish(), dispose: () => { if (accepted === generation) dispose(); }};
      },
    };
  }
  function action(label, host = document.activeElement) {
    host = element(host);
    if (!host || host === document.body || !host.getClientRects().length) {
      host = document.querySelector('dialog[open] form, .sheet-body, main, [role="main"]') || document.body;
    }
    return begin({host, label});
  }
  window.addEventListener("pagehide", () => { for (const operation of [...active]) operation.dispose(); });
  window.SMTOBusy = Object.freeze({begin, run, wrap, view, action,
    yield: () => new Promise(resolve => setTimeout(resolve, 0))});
})();
