/**
 * @file src/agent_runtime/api/static/agent_ui/parameter_editor.js
 * @brief Control the shared JSON parameter editor and template-prefill workflow.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities:
 * - Load masked records and template metadata, manage edits/tabs and issue explicit
 *   save/reveal/delete requests.
 * Boundaries:
 * - Persistence, typed validation and masking remain server-owned. HTTP profile semantics
 *   and authentication remain in the existing HTTP layer.
 * Lifecycle:
 * - Page startup loads templates and entries; selection updates the form; choosing a template
 *   creates an unsaved JSON draft; user actions call existing API routes.
 * State:
 * - The page-local state owns dirty flags and temporarily revealed values; hiding or changing
 *   selection clears the raw value. UI session storage keeps only navigation preferences.
 * Security:
 * - Metadata is rendered as text. Locked values are omitted from saves, mask tokens cannot be
 *   persisted and only explicit reveal places stored values in the editable DOM.
 * Collaborators:
 * - route_groups/parameters.py serves templates and record operations; templates.py defines JSON
 *   prefills; the adjacent HTML/CSS/JS files share existing control IDs.
 * Public surface:
 * - The IIFE binds controls by existing element IDs; createNewParameter, collectParameterPayload
 *   and saveParameter coordinate prefills and explicit persistence.
 * @see src/agent_runtime/api/agent_ui_support/route_groups/parameters.py
 * @see src/agent_runtime/parameters/templates.py
 * @see src/manual/content/16-parameter-store-context-sql.md
 */
(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const state = {
    parameters: [], selectedParameterKey: "", parameterDetail: null,
    parameterContextBase: null, parameterRawValue: null, parameterValueRevealed: false,
    creatingParameter: false, activeTab: "overview", dirty: false, loading: false,
    saving: false, cleanFields: "", templates: [], httpTypes: [], httpEditor: null,
  };
  const layout = $(".parameter-editor-layout");
  const parameterList = $("#parameter-list");
  const parameterSearch = $("#parameter-search");
  const tagFilter = $("#tag-filter");
  const valueEditor = $("#parameter-value-json");
  const fields = [...$("#parameter-fields").querySelectorAll("input, textarea")];
  const tabs = [...document.querySelectorAll("[role=tab]")];
  const contextFields = {
    summary: $("#parameter-context-summary"),
    prompt_guidance: $("#parameter-context-prompt-guidance"),
    clarification_guidance: $("#parameter-context-clarification-guidance"),
    concepts: $("#parameter-context-concepts"),
    metrics: $("#parameter-context-metrics"),
    relationships: $("#parameter-context-relationships"),
  };
  const arrayFields = new Set(["concepts", "metrics", "relationships"]);

  /** @brief Create an empty version-one guidance draft without mutating any stored parameter. */
  function defaultParameterContext() {
    return { version: 1, user_provided_domain_context: {
      summary: "", prompt_guidance: "", clarification_guidance: "",
      concepts: [], metrics: [], relationships: [],
    } };
  }

  /** @brief Read an object-shaped user guidance section, falling back to an empty object. */
  function parameterDomainContext(context) {
    const domain = context?.user_provided_domain_context;
    return domain && typeof domain === "object" && !Array.isArray(domain) ? domain : {};
  }

  /** @brief Format the canonical mention for the selected record, or an empty string for an unsaved draft. */
  function reference(entry = state.parameterDetail) {
    return entry?.normalized_key ? `@${entry.normalized_key}` : "";
  }

  /** @brief Render plain-text status in the editor or browser region and apply its error styling. */
  function setStatus(message = "", error = false, browser = false) {
    const target = $(browser ? "#browser-status" : "#parameter-status");
    target.textContent = message;
    target.classList.toggle("error", error);
  }

  /** @brief Fetch uncached JSON and translate API failures into safe editor messages with HTTP status. */
  async function requestJson(url, options = {}) {
    const headers = { ...options.headers };
    if (options.body) headers["Content-Type"] = "application/json";
    const response = await window.SMTOErrors.fetch(url, { ...options, headers, cache: "no-store" });
    const payload = await window.SMTOErrors.readJson(response).catch(() => ({}));
    if (!response.ok) {
      throw window.SMTOErrors.fromPayload(payload, response.status);
    }
    return payload;
  }

  /** @brief Format a valid timestamp for local display; missing or invalid dates render empty. */
  function dateLabel(value) {
    const date = new Date(value);
    return value && !Number.isNaN(date.getTime())
      ? date.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : "";
  }

  /** @brief Synchronize control availability, busy state and save labels with selection, loading and reveal state. */
  function updateActions() {
    const disabled = state.loading || !state.parameterDetail;
    state.httpEditor?.setState({loading: disabled, dirty: state.dirty});
    for (const field of fields) field.disabled = disabled;
    valueEditor.disabled = disabled || !(state.creatingParameter || state.parameterValueRevealed);
    $("#new-parameter-button").disabled = state.loading;
    $("#save-button").disabled = disabled || !state.dirty;
    $("#save-button").textContent = state.saving ? "Saving…" : "Save";
    $("#save-button").setAttribute("aria-busy", String(state.saving));
    $("#dirty-indicator").textContent = state.saving ? "Saving…" : state.dirty ? "Unsaved" : "Saved";
    $("#dirty-indicator").classList.toggle("unsaved", state.dirty);
    $("#copy-reference-button").disabled = disabled || state.creatingParameter || Boolean(state.parameterDetail?.mention_conflict);
    $("#parameter-more-button").disabled = disabled || state.creatingParameter;
    $("#delete-parameter-button").disabled = disabled || state.creatingParameter;
    $("#reveal-parameter-button").disabled = disabled || state.creatingParameter || state.parameterValueRevealed;
    $("#hide-parameter-button").disabled = disabled;
    $("#format-json-button").disabled = disabled;
    $("#rename-parameter-button").disabled = disabled;
    $("#back-to-parameters").disabled = state.loading;
    for (const row of parameterList.querySelectorAll("button")) row.disabled = state.loading;
    $("#parameter-selected").setAttribute("aria-busy", String(state.loading));
  }

  /** @brief Update the loading fence and immediately recompute enabled actions. */
  function setLoading(loading) {
    state.loading = loading;
    updateActions();
  }

  /** @brief Serialize editable metadata fields for dirty detection without copying the value editor. */
  function metadataSnapshot() {
    return JSON.stringify(fields.filter((field) => field !== valueEditor).map((field) => (
      field.type === "checkbox" ? field.checked : field.value
    )));
  }

  /** @brief Compare revealed JSON with the loaded raw value; malformed edits remain dirty. */
  function valueChanged() {
    if (!state.parameterValueRevealed || state.creatingParameter) return false;
    try {
      return JSON.stringify(JSON.parse(valueEditor.value)) !== JSON.stringify(state.parameterRawValue);
    } catch (_error) {
      return true;
    }
  }

  /** @brief Detect draft, metadata and revealed-value changes and refresh action state. */
  function updateDirty() {
    state.dirty = Boolean(state.parameterDetail) && (
      state.creatingParameter || metadataSnapshot() !== state.cleanFields || valueChanged()
      || (!state.parameterValueRevealed && state.httpEditor?.isDirty())
    );
    updateActions();
  }

  /** @brief Switch visible panels and ARIA selection, optionally moving keyboard focus to the tab. */
  function setTab(name, focus = false) {
    state.activeTab = name;
    for (const tab of tabs) {
      const active = tab.dataset.tab === name;
      tab.setAttribute("aria-selected", String(active));
      tab.tabIndex = active ? 0 : -1;
      $("#" + tab.getAttribute("aria-controls")).hidden = !active;
      if (active && focus) tab.focus();
    }
  }

  /** @brief Open the field's tab and disclosure before moving focus to a validation error. */
  function focusField(field) {
    const panel = field.closest("[role=tabpanel]");
    if (panel) setTab(panel.id.replace("panel-", ""));
    const disclosure = field.closest("details");
    if (disclosure) disclosure.open = true;
    field.focus();
  }

  /** @brief Clear field validation markers and the value error region before another attempt. */
  function clearErrors() {
    for (const field of fields) field.removeAttribute("aria-invalid");
    $("#parameter-value-error").hidden = true;
    $("#parameter-value-error").textContent = "";
  }

  /** @brief Associate a validation message with its field for accessible error presentation. */
  function validationError(errorRef, field) {
    const error = window.SMTOErrors.error(errorRef);
    error.field = field;
    return error;
  }

  /** @brief Render the failure as text, mark its field invalid and expose that field for correction. */
  function showError(error, fallback) {
    const message = error.message || fallback;
    setStatus(message, true);
    window.SMTOErrors.present($("#parameter-status"), error, {profile: "compact"});
    if (error.field) {
      error.field.setAttribute("aria-invalid", "true");
      if (error.field === valueEditor) {
        $("#parameter-value-error").textContent = message;
        $("#parameter-value-error").hidden = false;
      }
      focusField(error.field);
    }
  }

  /** @brief Show the value editor only for a new draft or explicit reveal, then refresh actions. */
  function updateValueVisibility() {
    const http = Boolean(state.httpEditor);
    $("#parameter-http-editor").hidden = !http || state.parameterValueRevealed;
    $("#parameter-raw-summary").hidden = !http;
    $("#parameter-raw-advanced").hidden = http && state.creatingParameter;
    if (!http) $("#parameter-raw-advanced").open = true;
    const editing = state.creatingParameter || state.parameterValueRevealed;
    $("#parameter-value-locked").hidden = editing;
    $("#parameter-value-editor").hidden = !editing;
    $("#hide-parameter-button").hidden = state.creatingParameter;
    updateActions();
  }

  /** @brief Toggle the actions menu and keep its expanded accessibility state synchronized. */
  function setOverflow(open) {
    $("#parameter-more-actions").hidden = !open;
    $("#parameter-more-button").setAttribute("aria-expanded", String(open));
  }

  /** @brief Resolve a modal confirmation once it closes; cancellation returns false. */
  function confirmAction(title, description, action, destructive = false) {
    const dialog = $("#parameter-confirm-dialog");
    $("#parameter-confirm-title").textContent = title;
    $("#parameter-confirm-description").textContent = description;
    const accept = $("#parameter-confirm-accept");
    accept.textContent = action;
    accept.classList.toggle("destructive", destructive);
    dialog.returnValue = "cancel";
    return new Promise((resolve) => {
      dialog.addEventListener("close", () => resolve(dialog.returnValue === "confirm"), { once: true });
      dialog.showModal();
    });
  }

  /** @brief Permit navigation immediately for clean forms, otherwise request explicit discard of unsaved edits. */
  function discardAllowed() {
    return !state.dirty || window.confirm("Discard unsaved changes?");
  }

  /** @brief Create the accessible mention-conflict indicator without interpreting record text as HTML. */
  function conflictIcon() {
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("aria-hidden", "true");
    icon.classList.add("icon", "conflict-icon");
    // Fixed monochrome paths; parameter metadata is always assigned through textContent.
    icon.innerHTML = '<path d="m12 3 10 18H2L12 3Z M12 9v5 M12 17h.01" />';
    return icon;
  }

  /** @brief Filter the loaded parameter summaries using the current search and tag choices. */
  function filteredParameters() {
    const query = parameterSearch.value.trim().toLowerCase();
    return state.parameters.filter((entry) => {
      const metadata = [entry.key, entry.normalized_key, reference(entry), entry.description,
        ...(entry.aliases || []), ...(entry.tags || []), entry.context_json?.summary,
        entry.http_profile?.profile_type, entry.http_profile?.base_url,
        entry.http_profile?.profile_type ? "HTTP Connection" : "",
        parameterDomainContext(entry.context_json).summary];
      const matches = !query || metadata.some((value) => String(value || "").toLowerCase().includes(query));
      const scope = tagFilter.value;
      return matches && (!scope
        || (scope.startsWith("tag:") && (entry.tags || []).includes(scope.slice(4))));
    });
  }

  /** @brief Rebuild tag choices from loaded summaries while retaining a valid selected tag. */
  function renderTagFilter() {
    const previous = window.SMTOUiSession.get("editor_scope", "");
    tagFilter.replaceChildren(new Option("All parameters", ""));
    const tags = [...new Set(state.parameters.flatMap((entry) => entry.tags || []))].sort();
    if (tags.length) {
      const group = document.createElement("optgroup");
      group.label = "Tags";
      for (const tag of tags) group.append(new Option(tag, `tag:${tag}`));
      tagFilter.append(group);
    }
    tagFilter.value = [...tagFilter.options].some((option) => option.value === previous) ? previous : "";
  }

  /** @brief Render safe parameter rows, selection and empty/filter states using DOM text nodes. */
  function renderParameterList() {
    const parameters = filteredParameters();
    const total = state.parameters.length;
    $("#parameter-count").textContent = parameters.length === total
      ? `${total} parameter${total === 1 ? "" : "s"}` : `${parameters.length} of ${total} parameters`;
    parameterList.replaceChildren();
    for (const entry of parameters) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "parameter-row";
      row.dataset.key = entry.normalized_key;
      const active = !state.creatingParameter && entry.normalized_key === state.selectedParameterKey;
      row.classList.toggle("active", active);
      if (active) row.setAttribute("aria-current", "true");
      const heading = document.createElement("span");
      heading.className = "parameter-row-heading";
      const key = document.createElement("span");
      key.className = "parameter-row-key";
      key.textContent = reference(entry);
      key.title = key.textContent;
      heading.append(key);
      if (entry.mention_conflict) heading.append(conflictIcon());
      const description = document.createElement("span");
      description.className = "parameter-row-description";
      description.textContent = entry.description || "No description";
      description.title = entry.description || "";
      const meta = document.createElement("span");
      meta.className = "parameter-row-meta";
      const tags = entry.tags || [];
      meta.textContent = [entry.http_profile?.profile_type ? "HTTP Connection" : "", ...tags.slice(0, 2),
        ...(tags.length > 2 ? [`+${tags.length - 2}`] : [])].filter(Boolean).join(" · ");
      meta.title = tags.join(", ");
      row.append(heading, description, meta);
      if (entry.mention_conflict) {
        const warning = document.createElement("span");
        warning.className = "parameter-row-conflict";
        warning.textContent = "Reference unavailable";
        row.append(warning);
      }
      row.addEventListener("click", () => selectParameter(entry.normalized_key));
      parameterList.append(row);
    }
    if (!parameters.length) {
      const empty = document.createElement("div");
      empty.className = "parameter-empty";
      const title = document.createElement("h2");
      title.textContent = total ? "No matching parameters" : "No parameters yet";
      const description = document.createElement("p");
      description.textContent = total
        ? parameterSearch.value.trim() ? `No parameters match “${parameterSearch.value.trim()}”.` : "No parameters match these filters."
        : "Store reusable values here and reference them from Chat with @name.";
      const action = document.createElement("button");
      action.type = "button";
      action.textContent = total ? "Clear filters" : "Create parameter";
      action.addEventListener("click", total ? clearFilters : createNewParameter);
      empty.append(title, description, action);
      parameterList.append(empty);
    }
    updateActions();
  }

  /** @brief Reset search and tag controls, then refresh the parameter list. */
  function clearFilters() {
    parameterSearch.value = "";
    tagFilter.value = "";
    window.SMTOUiSession.set("editor_scope", "");
    renderParameterList();
    parameterSearch.focus();
  }

  /** @brief Populate the editor from a selected record or new draft and retain the full guidance base for later edits. */
  function applyParameterDetail(entry, context = null, creating = false, http = null) {
    state.httpEditor = null;
    $("#parameter-http-editor").replaceChildren();
    if (http) {
      state.httpEditor = window.SMTOHttpProfileEditor.create({
        profile: http.profile, connection: creating ? null : http,
        types: state.httpTypes, onChange: () => { setStatus(); updateDirty(); },
        onUpdated: refreshParameters,
      });
      $("#parameter-http-editor").append(state.httpEditor.element);
    }
    $("#parameter-raw-advanced").open = !http;
    $("#tab-value").textContent = http ? "HTTP Connection" : "Value";
    $("#parameter-prompt-help").textContent = http
      ? "Use @name in Chat to select this HTTP Connection. Credentials remain private; the HTTP skill uses its exact profile key."
      : "Referencing @name includes its values, context, and agent guidance directly in your prompt.";
    state.parameterDetail = entry;
    state.selectedParameterKey = creating ? "" : entry?.normalized_key || "";
    state.creatingParameter = creating;
    state.parameterValueRevealed = false;
    state.parameterRawValue = null;
    state.parameterContextBase = structuredClone(context || defaultParameterContext());
    $("#parameter-selected").hidden = !entry;
    $("#parameter-empty").hidden = Boolean(entry);
    $("#parameter-title").textContent = creating ? "New parameter" : reference(entry);
    $("#parameter-title").classList.toggle("new-parameter", creating);
    $("#parameter-description-display").textContent = creating
      ? "Your canonical @ reference is created from the key when you save." : entry?.description || "";
    $("#parameter-meta").textContent = entry && !creating ? [
      `Used ${entry.use_count || 0} time${entry.use_count === 1 ? "" : "s"}`,
      entry.last_used_at ? `Last used ${dateLabel(entry.last_used_at)}` : "Not used yet",
    ].join(" · ") : "";
    $("#parameter-dates").textContent = entry && !creating ? [
      entry.created_at ? `Created ${dateLabel(entry.created_at)}` : "",
      entry.updated_at ? `Updated ${dateLabel(entry.updated_at)}` : "",
    ].filter(Boolean).join(" · ") : "";
    $("#parameter-key").value = entry?.key || "";
    $("#parameter-description").value = entry?.description || "";
    $("#parameter-aliases").value = (entry?.aliases || []).join(", ");
    $("#parameter-tags").value = (entry?.tags || []).join(", ");
    // Only revealed values enter the editable DOM.
    valueEditor.value = creating ? "{}" : "";
    const domain = parameterDomainContext(state.parameterContextBase);
    for (const [name, field] of Object.entries(contextFields)) {
      field.value = arrayFields.has(name) ? JSON.stringify(domain[name] || [], null, 2) : String(domain[name] || "");
    }
    $("#parameter-advanced-context").open = false;
    $("#parameter-conflict").hidden = !entry?.mention_conflict;
    $("#parameter-conflict-message").textContent = entry?.mention_conflict
      ? entry.mention_error || "This key conflicts with a reserved @ namespace. Rename the parameter to use it from Chat." : "";
    $("#copy-reference-button").textContent = "Copy reference";
    setOverflow(false);
    clearErrors();
    setStatus();
    state.cleanFields = metadataSnapshot();
    state.dirty = creating;
    updateValueVisibility();
    renderParameterList();
  }

  /** @brief Reload masked summaries and update tag/list projections without revealing values. */
  async function refreshParameters() {
    const payload = await requestJson("/api/agent/parameters?limit=1000");
    state.parameters = Array.isArray(payload.entries) ? payload.entries : [];
    renderTagFilter();
    renderParameterList();
  }

  const entryIsHttp = entry => entry?.http_profile?.profile_type === "http_connection";
  async function httpDetail(entry) {
    if (!entryIsHttp(entry)) return null;
    try {
      return await requestJson(`/api/agent/http/connections/${encodeURIComponent(entry.normalized_key)}`);
    } catch (error) {
      // Malformed legacy values remain manageable through the existing explicit raw editor.
      if (error.status === 422) return null;
      throw error;
    }
  }

  /** @brief Load the selected record after checking unsaved changes; loading fences and safe errors remain visible. */
  async function selectParameter(key, feedback = null) {
    const busyFeedback = feedback || window.SMTOBusy?.begin({host: layout, label: "Loading parameter…", key: "parameter-read", replace: true});
    try {
    if (state.loading) return;
    if (key === state.selectedParameterKey && !state.creatingParameter) {
      layout.dataset.view = "editor";
      $("#parameter-title").focus();
      return;
    }
    if (!discardAllowed()) return;
    setLoading(true);
    setStatus("Loading parameter…", false, true);
    let loaded = false;
    try {
      const payload = await requestJson(`/api/agent/parameters/${encodeURIComponent(key)}`);
      const http = await httpDetail(payload.entry);
      applyParameterDetail(payload.entry, payload.context_json, false, http);
      layout.dataset.view = "editor";
      setTab(entryIsHttp(payload.entry) ? "value" : "overview");
      if (entryIsHttp(payload.entry) && !http) showError(window.SMTOErrors.error("ui_http_configuration_invalid"));
      setStatus("", false, true);
      loaded = true;
    } catch (error) {
      showError(error);
    } finally {
      setLoading(false);
    }
    if (loaded) $("#parameter-title").focus();

    } finally { busyFeedback?.finish(); }
  }

  /** @brief Start an unsaved draft from the selected detached template after the discard check; no save or connection occurs. */
  function createNewParameter() {
    if (state.loading || !discardAllowed()) return;
    const template = state.templates.find(item => item.id === $("#parameter-template").value);
    const http = template?.editor === "http_connection" ? {profile: template.value_json} : null;
    applyParameterDetail({ key: "" }, defaultParameterContext(), true, http);
    if (template) valueEditor.value = JSON.stringify(template.value_json, null, 2);
    layout.dataset.view = "editor";
    setTab("overview");
    $("#parameter-key").focus();
  }

  /** @brief Parse a field as the requested array or nonempty object, raising a field-bound validation error on failure. */
  function parseJson(field, label, array = false) {
    let value;
    try { value = JSON.parse(field.value); }
    catch (_error) { throw validationError("ui_json_invalid", field); }
    if (array ? !Array.isArray(value) : !value || typeof value !== "object" || Array.isArray(value) || !Object.keys(value).length) {
      throw validationError(array ? "ui_json_array_required" : "ui_json_object_required", field);
    }
    return value;
  }

  /** @brief Detect display-mask markers recursively so redacted previews cannot overwrite stored values. */
  function parameterValueContainsMask(value) {
    if (typeof value === "string") return value.includes("••••");
    if (Array.isArray(value)) return value.some(parameterValueContainsMask);
    if (value && typeof value === "object") {
      return Object.entries(value).some(([key, item]) => parameterValueContainsMask(key) || parameterValueContainsMask(item));
    }
    return false;
  }

  /** @brief Merge edited guidance into the full detail snapshot, preserving fields absent from bounded list summaries. */
  function buildParameterContextFromFields() {
    // Full detail is the base, not the bounded context summary returned in list entries.
    const base = structuredClone(state.parameterContextBase || defaultParameterContext());
    const domain = { ...parameterDomainContext(base) };
    for (const [name, field] of Object.entries(contextFields)) {
      domain[name] = arrayFields.has(name) ? parseJson(field, field.labels[0].innerText, true) : field.value;
    }
    return { ...base, user_provided_domain_context: domain };
  }

  /** @brief Validate editor fields and include raw value JSON only for a new or explicitly revealed record. */
  function collectParameterPayload() {
    const keyField = $("#parameter-key");
    if (!keyField.value.trim()) throw validationError("ui_parameter_key_required", keyField);
    /** @brief Split a comma-separated metadata input into trimmed nonempty entries. */
    const commaList = (id) => $(id).value.split(",").map((item) => item.trim()).filter(Boolean);
    const payload = {
      key: keyField.value.trim(), description: $("#parameter-description").value.trim(),
      aliases: commaList("#parameter-aliases"), tags: commaList("#parameter-tags"),
      context_json: buildParameterContextFromFields(),
    };
    if (state.httpEditor && !state.parameterValueRevealed) {
      if (state.creatingParameter || state.httpEditor.isDirty()) {
        payload.public_http_profile = state.httpEditor.read();
      }
      return payload;
    }
    if (state.creatingParameter) payload.sensitive = false;
    // Existing locked values are omitted unconditionally, regardless of their masked shape.
    if (state.creatingParameter || state.parameterValueRevealed) {
      payload.value_json = parseJson(valueEditor, "Value");
      if (parameterValueContainsMask(payload.value_json)) {
        throw validationError("ui_parameter_mask_rejected", valueEditor);
      }
    }
    return payload;
  }

  /** @brief Validate and persist the explicit draft/edit, then reload summaries and detail under the saving fence. */
  async function saveParameter() {
    const busyFeedback = window.SMTOBusy?.begin({host: layout, label: "Saving parameter…"});
    try {
    if (state.loading || !state.parameterDetail || !state.dirty) return;
    clearErrors();
    let body;
    try { body = collectParameterPayload(); }
    catch (error) { showError(error, "Check the parameter fields."); return; }
    state.saving = true;
    setLoading(true);
    setStatus();
    try {
      const url = state.creatingParameter ? "/api/agent/parameters"
        : `/api/agent/parameters/${encodeURIComponent(state.selectedParameterKey)}`;
      const payload = await requestJson(url, { method: state.creatingParameter ? "POST" : "PATCH", body: JSON.stringify(body) });
      // The server's normalized key is authoritative, including after rename.
      applyParameterDetail(payload.entry, body.context_json);
      setStatus("Saved");
      try {
        const http = await httpDetail(payload.entry);
        applyParameterDetail(payload.entry, body.context_json, false, http);
        setStatus("Saved");
        await refreshParameters();
      }
      catch (_error) { setStatus("Saved. The parameter list could not refresh. Reload to try again."); }
    } catch (error) {
      setLoading(false);
      if (error.status === 409 || error.status === 400) error.field = $("#parameter-key");
      showError(error, "Could not save the parameter.");
    } finally {
      state.saving = false;
      setLoading(false);
    }

    } finally { busyFeedback?.finish(); }
  }

  /** @brief Fetch raw value through the explicit reveal endpoint and hold it only in the current editor state. */
  async function revealParameterValue() {
    const busyFeedback = window.SMTOBusy?.begin({host: layout, label: "Loading parameter value…"});
    try {
    if (state.loading || state.creatingParameter || state.parameterValueRevealed) return;
    if (state.httpEditor?.isDirty()) {
      showError(window.SMTOErrors.error("ui_http_unsaved_changes"));
      return;
    }
    setLoading(true);
    let revealed = false;
    try {
      const payload = await requestJson(`/api/agent/parameters/${encodeURIComponent(state.selectedParameterKey)}/reveal`, { method: "POST" });
      // Reveal changes only value state; unsaved metadata/context edits stay intact.
      state.parameterRawValue = payload.value_json;
      state.parameterValueRevealed = true;
      valueEditor.value = JSON.stringify(payload.value_json, null, 2);
      updateValueVisibility();
      setStatus("Value revealed");
      revealed = true;
    } catch (error) { showError(error, "Could not reveal the value."); }
    finally { setLoading(false); }
    if (revealed) focusField(valueEditor);

    } finally { busyFeedback?.finish(); }
  }

  /** @brief Remove the revealed raw value from the editor and restore its locked projection. */
  function hideParameterValue() {
    if (state.loading || state.creatingParameter) return;
    if (valueChanged() && !window.confirm("Discard unsaved value changes and hide the value? Other edits will be kept.")) return;
    state.parameterRawValue = null;
    state.parameterValueRevealed = false;
    valueEditor.value = "";
    clearErrors();
    updateValueVisibility();
    updateDirty();
    setStatus("Value hidden");
    $("#reveal-parameter-button").focus();
  }

  /** @brief Confirm deletion of the selected record, call the API and refresh browser/editor state. */
  async function deleteParameter() {
    const busyFeedback = window.SMTOBusy?.begin({host: layout, label: "Deleting parameter…"});
    try {
    if (state.loading || !state.selectedParameterKey) return;
    setOverflow(false);
    const confirmed = await confirmAction(`Delete ${reference()}?`,
      (state.parameterDetail?.http_profile?.profile_type
        ? "This removes the saved connection and its saved credentials, and invalidates active sessions. Prompts that reference it will no longer resolve."
        : "This removes the stored parameter. Prompts that reference it will no longer resolve.")
      + (state.dirty ? " Your unsaved changes will also be discarded." : ""), "Delete", true);
    if (!confirmed) { $("#parameter-more-button").focus(); return; }
    setLoading(true);
    try {
      const oldIndex = state.parameters.findIndex((entry) => entry.normalized_key === state.selectedParameterKey);
      await requestJson(`/api/agent/parameters/${encodeURIComponent(state.selectedParameterKey)}`, { method: "DELETE" });
      state.parameters = state.parameters.filter((entry) => entry.normalized_key !== state.selectedParameterKey);
      const next = state.parameters[Math.min(oldIndex, state.parameters.length - 1)];
      applyParameterDetail(null);
      renderTagFilter();
      renderParameterList();
      layout.dataset.view = "browser";
      setLoading(false);
      if (next) await selectParameter(next.normalized_key);
      else $("#new-parameter-button").focus();
    } catch (error) { showError(error, "Could not delete the parameter."); }
    finally { setLoading(false); }

    } finally { busyFeedback?.finish(); }
  }

  parameterSearch.addEventListener("input", renderParameterList);
  tagFilter.addEventListener("change", () => {
    window.SMTOUiSession.set("editor_scope", tagFilter.value);
    renderParameterList();
  });
  for (const field of fields) {
    field.addEventListener("input", () => {
      field.removeAttribute("aria-invalid");
      if (field === valueEditor) $("#parameter-value-error").hidden = true;
      setStatus();
      updateDirty();
    });
  }
  for (const tab of tabs) {
    tab.addEventListener("click", () => setTab(tab.dataset.tab));
    tab.addEventListener("keydown", (event) => {
      const index = tabs.indexOf(tab);
      const next = event.key === "ArrowRight" ? (index + 1) % tabs.length
        : event.key === "ArrowLeft" ? (index + tabs.length - 1) % tabs.length
        : event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 : -1;
      if (next < 0) return;
      event.preventDefault();
      setTab(tabs[next].dataset.tab, true);
    });
  }
  $("#new-parameter-button").addEventListener("click", createNewParameter);
  $("#save-button").addEventListener("click", saveParameter);
  $("#reveal-parameter-button").addEventListener("click", revealParameterValue);
  $("#hide-parameter-button").addEventListener("click", hideParameterValue);
  $("#delete-parameter-button").addEventListener("click", deleteParameter);
  $("#parameter-more-button").addEventListener("click", () => setOverflow($("#parameter-more-actions").hidden));
  $("#rename-parameter-button").addEventListener("click", () => focusField($("#parameter-key")));
  $("#back-to-parameters").addEventListener("click", () => {
    // Returning to the browser keeps the draft; selecting another entry asks before discarding it.
    layout.dataset.view = "browser";
    const selected = [...parameterList.querySelectorAll(".parameter-row")].find((row) => row.dataset.key === state.selectedParameterKey);
    (selected || parameterSearch).focus();
  });
  $("#format-json-button").addEventListener("click", () => {
    clearErrors();
    try { valueEditor.value = JSON.stringify(parseJson(valueEditor, "Value"), null, 2); updateDirty(); setStatus("JSON formatted"); }
    catch (error) { showError(error, "Check the value JSON."); }
  });
  const referenceCopied = window.SMTOCopyFeedback.bind($("#copy-reference-button"));
  $("#copy-reference-button").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Copying parameter reference…", $("#copy-reference-button"));
        try {
    if (state.creatingParameter || state.parameterDetail?.mention_conflict) return;
    try {
      await navigator.clipboard.writeText(reference());
      referenceCopied();
      setStatus("Reference copied");
    } catch (_error) { showError(window.SMTOErrors.error("ui_clipboard_unavailable")); }

        } finally { busyFeedback?.finish(); }
      });
  document.addEventListener("click", (event) => {
    if (!event.target.closest(".parameter-overflow")) setOverflow(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("#parameter-more-actions").hidden) {
      setOverflow(false);
      $("#parameter-more-button").focus();
    }
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      if (!$("#parameter-confirm-dialog").open) saveParameter();
    }
  });
  window.addEventListener("beforeunload", (event) => {
    if (!state.dirty) return;
    event.preventDefault();
    event.returnValue = "";
  });

  /** @brief Load source-owned templates and masked parameter summaries, then initialize selection with visible loading/error feedback. */
  async function startup() {
    const busyFeedback = window.SMTOBusy?.begin({host: document.querySelector('#app-boot-screen .app-boot-card'), label: "Loading Parameters…", placement: "after"});
    try {
    setLoading(true);
    try {
      await refreshParameters();
      const templatePayload = await requestJson("/api/agent/parameters/templates");
      state.templates = templatePayload.templates;
      const auth = await requestJson("/api/agent/http/auth-types");
      state.httpTypes = auth.types;
      $("#parameter-template").replaceChildren(...state.templates.map(item => new Option(item.label, item.id)));
      setLoading(false);
      const startupParams = new URLSearchParams(window.location.search);
      const key = startupParams.get("key") || (!window.matchMedia("(max-width: 800px)").matches ? state.parameters[0]?.normalized_key : "");
      if (key) await selectParameter(key, busyFeedback);
    } catch (error) {
      setStatus("", true, true);
      window.SMTOErrors.present($("#browser-status"), error, {profile: "compact"});
      const retry = document.createElement("button");
      retry.textContent = "Retry";
      retry.type = "button";
      retry.addEventListener("click", () => { setStatus("", false, true); startup(); });
      $("#browser-status").append(retry);
    } finally {
      setLoading(false);
      document.documentElement.classList.remove("app-booting");
      document.documentElement.classList.add("app-booted");
      $("#app-boot-screen")?.remove();
    }

    } finally { busyFeedback?.finish(); }
  }
  startup();
})();
