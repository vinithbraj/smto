/* Shared SVG history geometry; callers own units, clocks, cadence and buffers. */
(() => {
  "use strict";
  function path(points, {end, windowMs, width = 48, height = 14, maximum = 100,
    gapMs = Infinity, bucketMs = 0, normalize = value => value / maximum}) {
    const start = end - windowMs, baseline = height - 1;
    let result = "", connected = false, previous = null;
    const x = t => 1 + (t - start) / windowMs * (width - 2);
    const point = (command, t, y) => ` ${command}${x(t).toFixed(2)},${y.toFixed(2)}`;
    for (const sample of points) {
      if (!sample || !Number.isFinite(sample.t) || sample.t < start || sample.t > end) continue;
      if (!Number.isFinite(sample.value)) { connected = false; continue; }
      if (previous !== null && (sample.t <= previous || sample.t - previous > gapMs)) connected = false;
      const value = Math.max(0, Math.min(1, normalize(sample.value)));
      if (bucketMs) {
        // Each pulse stays inside its observed bucket. Silent buckets remain flat.
        result += point(connected ? "L" : "M", sample.t, baseline);
        if (value > 0) result += point("L", sample.t + bucketMs / 2, baseline - value * (height - 2));
        result += point("L", Math.min(end, sample.t + bucketMs), baseline);
      } else {
        result += point(connected ? "L" : "M", sample.t, baseline - value * (height - 2));
      }
      connected = true; previous = sample.t;
    }
    return result.trim();
  }
  window.SMTORollingHistory = {path};
})();
