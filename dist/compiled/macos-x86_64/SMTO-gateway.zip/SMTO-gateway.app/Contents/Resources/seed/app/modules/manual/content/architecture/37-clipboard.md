---
id: clipboard
title: Current clipboard
kind: architecture
tags: [architecture, current, clipboard, gateway, skills]
order: 37
---
# Current clipboard

Enable **Clipboard** in Capabilities to explicitly inspect, read, replace or clear the current
clipboard on the selected Gateway. It starts disabled. Enabling it performs no clipboard read,
grants no execution permission and changes no existing saved capability selection. A remote
Gateway always owns the clipboard operation; the controller never supplies a fallback clipboard.

Discover `clipboard` for the `clipboard.inspect` and `clipboard.read_text` entry tools.
Discover the `clipboard.text`, `clipboard.files` or `clipboard.image` section for further tools.
The text section also contains `clipboard.clear`. Every content read requires an explicit tool
invocation. Discovery and readiness inspect prerequisites only; `inspect` reads format metadata
without retrieving text, file paths or image data. Estimates and change tokens are omitted when
unavailable. Other native formats, including HTML/RTF and serialized objects, are never decoded.

| Tool | Effect | Result |
| --- | --- | --- |
| `clipboard.inspect` | read | Format presence, backend, optional change token |
| `clipboard.read_text` | read | Exact Unicode text, counts, truncation flag and full-content digest |
| `clipboard.write_text` | write | Counts and digest; no echoed content |
| `clipboard.read_files` | read | Target-local paths without file-content reads |
| `clipboard.write_files` | write | Count of existing target-local paths copied |
| `clipboard.read_image` | read | PNG file in the current run artifact workspace, dimensions and integrity metadata |
| `clipboard.write_image` | write | Receipt for an existing target-local raster file |
| `clipboard.clear` | write | Empty clipboard receipt |

Writes and clear use the existing Permission policy and confirmation mechanism. Clipboard adds
no approval dialog, credential store, Parameter Store type, configuration switch or helper model.
Reads remain fresh observations in the normal execution loop. No history/watch tool or automatic
Memory/Working Context capture exists. Clipboard data is untrusted: its presence never authorizes
following instructions embedded in it or storing its contents in Memory.

## Format support and setup

The Gateway advertises `clipboard_text`, `clipboard_files`, and `clipboard_image` independently.
The image tag requires Pillow. Text support alone does not make file/image tools available.
The captured selected-Gateway capabilities remain authoritative on resume. Refresh Gateway
metadata after changing installed prerequisites or OS/session permissions.

| Gateway session | Text | Files | Image | Prerequisites |
| --- | --- | --- | --- | --- |
| Windows interactive input desktop | CF_UNICODETEXT | CF_HDROP | PNG and CF_DIB | Native Win32 APIs; Pillow for images |
| macOS logged-in console | UTF-8 plain text | Local file URLs | PNG/TIFF reads, PNG writes | Packaged AppKit/Quartz PyObjC bridges; Pillow |
| Linux X11 | UTF8_STRING / UTF-8 MIME | text/uri-list | image/png | Reachable X display, python-xlib and installed xclip; Pillow |
| Linux Wayland | UTF-8 MIME | text/uri-list | image/png | Reachable compositor socket and installed wl-copy/wl-paste; Pillow |
| Headless or missing backend | unavailable | unavailable | unavailable | Start Gateway in the interactive session; install prerequisites explicitly |

No packages are installed automatically. Wayland never falls back to the XWayland clipboard.
Compositor protocol and permission restrictions can still reject an operation after readiness;
readiness is a prerequisite check, not an access grant. Windows session zero is unavailable.
macOS uses the general pasteboard without Accessibility automation or arbitrary object reads.

Linux selection protocols require a process to serve copied data. The native `xclip` or `wl-copy`
selection owner may survive a successful write until another application replaces it. It serves
only that explicit write; no watcher, reader thread, clipboard database or history cache is started.

## Bounds and exactness

Text reads default to 4,096 characters. `max_characters` can request up to 65,536. The source has a
hard maximum of 65,536 characters and 256 KiB of UTF-8. Larger sources fail without partial data;
sources within that maximum return exact requested prefixes with `characters_returned`,
`characters_total`, `truncated` and the full-source SHA-256. No Unicode or newline normalization
occurs. An empty string remains a valid text format; absent text produces `clipboard_format_absent`.
Embedded NUL and invalid Unicode writes are rejected because native text formats cannot reliably
preserve them across supported systems.

File lists are limited to 128 paths, 4,096 UTF-8 bytes per path and 128 KiB total. Paths must use
the Gateway's native absolute syntax. Writes require existing paths on that Gateway; use the
existing file transfer operation first for controller files. There is no implicit path translation,
recursive traversal or download. Network/device paths, Windows alternate streams, and remote/non-file
URIs are rejected. Reading a file list does not require that its files still exist.

Images accept bounded PNG/JPEG/BMP/TIFF raster files and native allowlisted PNG/TIFF/DIB buffers.
Encoded input and output are at most 16 MiB and decoded images at most 16 million pixels. Windows
also bounds the compatibility DIB representation to 16 MiB. Conversion strips ancillary metadata.
No binary or base64 image payload enters tool result JSON. `read_image` requires an active run and
conversation, writes to its existing Gateway artifact workspace, and joins the normal artifact
collector. Explicit exported artifacts use ordinary artifact retention/deletion, not a private cache.
`write_image` takes an existing absolute Gateway-local file path; download/transfer/register steps
remain explicit tools.

## Races, cancellation and outcome truth

Windows returns the clipboard sequence number while holding its native clipboard lock; macOS
returns the pasteboard change count. `expected_change_id` rejects a mismatch before reading or
writing. Reads also check the token after acquiring content. macOS checks are observational, not
an atomic compare-and-swap against other applications. Linux omits a token; specifying one there
fails as stale. A token is neither a durable content identity nor proof that the current clipboard
still matches a previous receipt.

Operations have a five-second Gateway budget; direct transport waits at most ten seconds. Native
Windows/macOS calls run in disposable child processes so blocked pasteboard IPC can be killed and
reaped. Linux readers have bounded subprocess output and cancellation checks. Windows retries only
clipboard lock acquisition, five attempts with at most 200ms of backoff; mutations are never retried.
At most 32 operations are active and 4,096 identity-only tombstones remain for five minutes. Duplicate
or cancelled operation IDs cannot execute again. Cancellation cannot undo a completed clipboard write.

A lost response after a possible write returns `clipboard_outcome_unknown`, with incomplete evidence
and `remote_effect_possible`. No automatic write replay or hidden reconciliation content read occurs.
Inspect formats on the same Gateway, explicitly read content only if needed, then deliberately choose
a next action. All stable errors have Error Catalog IDs, safe details and remediation, including
absence, unsupported formats, size/path limits, stale tokens, permission/backend/session failure,
artifact/codec failures, cancellation, disconnection and uncertain effects.

## Privacy and source ownership

Exact explicit read results and execution arguments use the existing source result store and run
journal. They remain available to the current Agent operation and its explicit result retrieval;
Clipboard is not an ephemeral replacement for those source-owned evidence stores. Their normal
retention rules apply. No additional clipboard history or secret database is created.

Clipboard activity inspectors expose structural metadata only, regardless of optional credential
redaction settings. Once Clipboard appears in a request's diagnostic events, free-text diagnostic
payloads and model traces for that request are omitted to prevent later prompt copies from retaining
clipboard observations. This reduces diagnostic detail for that request. Canonical model execution,
source receipts and the user's requested final answer remain exact. Clipboard result payloads are
excluded from automatic turn-history copies and cross-conversation result handoffs; capsules omit
clipboard-derived assistant summaries. Automatic task/event notifications carry status only for
Clipboard requests. This is structural data minimization, not secret classification.

`agent_runtime/skills/clipboard/` owns registration, effect metadata and selected-target dispatch.
`gateway_core/clipboard_contract.py` owns the single bounded wire schema; `clipboard_service.py`
owns execution/cancellation and existing artifact paths; `clipboard_worker.py` bounds native IPC;
`platform_clipboard/` owns OS APIs. Existing Gateway routes, outbound forwarding, client, capability
snapshots, authorization, error catalog, artifacts and observability remain authoritative. All these
paths are deterministic and introduce **zero helper-model calls**.

Native references: [Win32 clipboard ownership](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setclipboarddata),
[Apple NSPasteboard](https://developer.apple.com/documentation/appkit/nspasteboard),
[wl-clipboard source and protocol constraints](https://github.com/bugaevc/wl-clipboard).
