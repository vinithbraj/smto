/**
 * @file src/agent_runtime/api/static/agent_ui/command_palette.js
 * @brief Invoke existing application commands and Agent tasks from a modal launcher.
 * @details
 * Responsibilities: Dialog lifecycle, keyboard invocation, visible scope and compact status.
 * Boundaries: The original composer, command registry and durable lane own all execution.
 * Lifecycle: Move the live composer dock into the dialog, then restore it on dismissal.
 * State: Only invocation preferences use the existing tab session; task IDs are projections.
 * Security: No global keyboard hook, clipboard read, context capture or prompt logging.
 * Collaborators: app.js supplies exact scope and canonical task observations; slash_commands.js
 *   continues to own discovery and dispatch on the same form and input elements.
 * Public surface: create binds UI hooks; project and normalizeShortcut are deterministic.
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/api/static/agent_ui/slash_commands.js
 */
(() => {
  "use strict";
  const waiting = new Set(["waiting_user", "awaiting_confirmation", "awaiting_clarification",
    "awaiting_resource_reconciliation", "paused", "paused_budget", "blocked"]);
  /** Project only acknowledged task/run states; no timers advance task progress. */
  function project(status) {
    if (waiting.has(status)) return {state: "waiting_interaction", text: "Open conversation to respond or continue"};
    if (status === "queued") return {state: "queued", text: "Queued"};
    if (["pending", "running", "waiting_job", "waiting_event"].includes(status)) return {state: "running", text: "Processing…"};
    if (["completed", "answered"].includes(status)) return {state: "completed", text: "Completed"};
    if (["cancelled", "removed"].includes(status)) return {state: "completed", text: "Stopped"};
    if (["failed", "interrupted", "partial"].includes(status)) return {state: "failed", text: {failed: "Failed", interrupted: "Interrupted", partial: "Partial result"}[status]};
    return {state: "idle", text: status ? String(status).replaceAll("_", " ") : "Ready"};
  }
  /** Accept modified letter bindings and reject known app/browser conflicts without hooks. */
  function normalizeShortcut(raw) {
    const aliases = {ctrl: "Control", control: "Control", cmd: "Meta", command: "Meta", meta: "Meta", alt: "Alt", shift: "Shift"};
    const parts = String(raw || "").split("+").map(value => value.trim().toLowerCase());
    const key = parts.pop(), modifiers = parts.map(value => aliases[value]);
    if (!/^[a-z]$/.test(key || "") || modifiers.some(value => !value)
      || new Set(modifiers).size !== modifiers.length || !modifiers.some(value => ["Control", "Meta"].includes(value))) return null;
    const normalized = ["Control", "Meta", "Alt", "Shift"].filter(value => modifiers.includes(value));
    // Includes existing New chat and prompt recall, browser navigation and editing shortcuts.
    if (!modifiers.includes("Alt") && "ntwlrpfhqosacvxzybjduie".includes(key)) return null;
    return [...normalized, key.toUpperCase()].join("+");
  }
  /** Compare the configured chord only; ordinary keystrokes are never recorded or transmitted. */
  function matchesShortcut(event, binding) {
    const parts = binding.split("+");
    return event.key.toUpperCase() === parts.at(-1)
      && event.ctrlKey === parts.includes("Control") && event.metaKey === parts.includes("Meta")
      && event.altKey === parts.includes("Alt") && event.shiftKey === parts.includes("Shift");
  }
  /** Own the modal surface while preserving DOM identity and all composer event handlers. */
  function create({composer, input, slash, getView, getContext, getProgress, newConversation,
    chooseConversation, openConversation, showToast}) {
    const dock = composer.closest("footer"), marker = document.createComment("composer dock home");
    dock.before(marker);
    const dialog = document.createElement("dialog"); dialog.id = "command-palette";
    dialog.className = "agent-dialog command-palette"; dialog.dataset.state = "closed";
    dialog.setAttribute("aria-labelledby", "command-palette-title");
    dialog.innerHTML = `<header class="agent-dialog-header palette-header"><h2 id="command-palette-title">SMTO Command Palette</h2>
      <button type="button" data-action="dismiss" aria-label="Dismiss command palette">Esc</button></header>
      <div class="palette-context"><span id="palette-conversation" aria-label="Palette conversation"></span>
      <button type="button" data-action="choose">Change conversation</button><button type="button" data-action="new">New conversation</button>
      <span id="palette-target" aria-label="Palette target Gateways"></span><button type="button" data-action="target">Change target</button>
      <span id="palette-command-scope" aria-label="Command run scope"></span></div>
      <p class="palette-hint">Use / for application commands, or type a task for the Agent.</p>
      <section class="palette-progress" aria-label="Task status"><p id="palette-status" role="status" aria-live="polite"></p>
      <p id="palette-task-target"></p><p id="palette-result"></p><button type="button" data-action="open">Open conversation</button></section>
      <details class="palette-settings"><summary>Invocation settings</summary>
      <label class="palette-shortcut-toggle"><input type="checkbox" id="palette-enabled"> Enable in-app shortcut</label>
      <label class="agent-dialog-field">In-app shortcut <input id="palette-binding" type="text" maxlength="64" spellcheck="false"></label>
      <label class="agent-dialog-field">Open in app <select id="palette-behavior"><option value="current">Current visible conversation</option><option value="new">New conversation</option></select></label>
      <button type="button" data-action="save">Save for this tab</button><p id="palette-settings-message" role="status"></p>
      <p>For a system-wide shortcut, bind <code>aor palette</code> in your OS settings. The OS owns its binding, enablement and conflicts.</p></details>`;
    dialog.querySelectorAll("button").forEach(button => button.classList.add("agent-dialog-button"));
    document.body.append(dialog);
    window.SMTOBranding?.bindText(dialog.querySelector("#command-palette-title"), "{name} Command Palette");
    const status = dialog.querySelector("#palette-status"), result = dialog.querySelector("#palette-result");
    const session = window.SMTOUiSession;
    const defaultBinding = /Mac|iPhone|iPad/.test(navigator.platform) ? "Meta+K" : "Control+K";
    let binding = normalizeShortcut(session.get("palette_shortcut", defaultBinding)) || defaultBinding;
    let previousFocus, captured, observed = null, submitting = false, commandResult = null;
    const launch = document.querySelector("#command-palette-toggle");
    /** Expose the effective binding for both keyboard users and assistive technology. */
    function bindingLabel() {
      launch.title = `Command palette (${binding})`; launch.setAttribute("aria-keyshortcuts", binding);
    }
    bindingLabel();
    /** Render exact scope and canonical status; never discover a task by recency. */
    function update() {
      if (!dialog.open) return;
      const context = getContext(), current = getView();
      const stale = captured && (captured.conversation_id !== current.conversation_id || captured.navigation !== current.navigation);
      dialog.querySelector("#palette-conversation").textContent = `Conversation: ${context.conversation}`;
      dialog.querySelector("#palette-target").textContent = `Target: ${context.target}${context.targetProblem ? ` · ${context.targetProblem}` : ""}`;
      dialog.querySelector("#palette-command-scope").textContent = `Command run: ${current.request_id || "None"}`;
      dialog.querySelector('[data-action="open"]').disabled = !observed?.conversation_id && !current.conversation_id;
      const progress = getProgress(observed);
      const projection = project(progress.status);
      dialog.querySelector("#palette-task-target").textContent = progress.target ? `Task target: ${progress.target}` : "";
      const state = stale ? "failed" : submitting ? "submitting" : commandResult ? commandResult.state
        : input.value.trim() ? slash.isCommand(input.value) ? "command_search" : "editing" : projection.state;
      dialog.dataset.state = state;
      status.textContent = stale ? "Conversation changed. Reopen the palette to review its scope."
        : submitting ? "Submitting…" : commandResult?.text || projection.text;
      result.textContent = commandResult ? "" : String(progress.result || "").slice(0, 600);
      if (progress.request_id) dialog.dataset.requestId = progress.request_id;
      else delete dialog.dataset.requestId;
    }
    /** Return the actual dock to its original position and restore the invoking focus. */
    function restore() {
      if (dock.previousSibling === marker) return;
      marker.after(dock); slash.discovery(false);
      dialog.dataset.state = "dismissed";
      if (previousFocus?.isConnected && !previousFocus.closest('[inert]')) previousFocus.focus({preventScroll: true});
    }
    /** Dismissal never cancels, resubmits or modifies an acknowledged task. */
    function close() { if (dialog.open) { dialog.close(); restore(); } }
    dialog.addEventListener("close", () => { if (!dialog.open) restore(); });
    function expandComposer() {
      if (composer.classList.contains("composer-compact")) composer.querySelector("#composer-size-toggle").click();
      input.focus({preventScroll: true});
    }
    /** Bind the visible conversation before showing the same composer inside the modal. */
    function open({launcher = false} = {}) {
      if (dialog.open) { input.focus(); return; }
      if (document.querySelector("dialog[open]")) return;
      previousFocus = document.activeElement;
      if (!launcher && session.get("palette_open_behavior", "current") === "new") newConversation();
      captured = {...getView()}; observed = captured.request_id ? {...captured} : null;
      commandResult = null; submitting = Boolean(captured.submitting); dialog.dataset.state = "opening";
      dialog.querySelector(".palette-settings").before(dock);
      dialog.showModal(); slash.discovery(true); update();
      if (!composer.hidden) expandComposer();
      else dialog.querySelector('[data-action="open"]').focus();
    }
    // The form's existing submission handler remains the only execution entrypoint.
    composer.addEventListener("submit", event => {
      if (!dialog.open) return;
      const current = getView();
      if (!window.SMTOCommandProtocol.sameView(captured, current)) {
        // A task accepted by this palette may advance to its exact request after acknowledgement.
        const ownRequest = observed?.task_id && getProgress(observed).request_id === current.request_id;
        if (!(ownRequest && captured.conversation_id === current.conversation_id && captured.navigation === current.navigation)) {
          event.preventDefault(); event.stopImmediatePropagation();
          showToast(window.SMTOErrors.error("ui_state_stale")); return;
        }
        captured = {...current};
      }
      commandResult = null;
    }, true);
    input.addEventListener("input", () => { commandResult = null; update(); });
    // Capture only while this document is focused; no OS keyboard-event source exists.
    document.addEventListener("keydown", event => {
      if (event.isComposing) return;
      if (dialog.open && event.key === "Escape") {
        // Leave nested modal/target-menu Escape behavior with its canonical owner.
        if (event.target.closest("dialog") !== dialog || event.target.closest(".target-menu")) return;
        event.preventDefault(); event.stopImmediatePropagation(); close(); return;
      }
      if (dialog.open && event.repeat && event.key === "Enter") { event.preventDefault(); event.stopImmediatePropagation(); return; }
      if (session.get("palette_shortcut_enabled", true) && matchesShortcut(event, binding)) {
        event.preventDefault(); event.stopImmediatePropagation(); if (!event.repeat) open();
      }
    }, true);
    launch.addEventListener("click", () => open());
    dialog.querySelector('[data-action="dismiss"]').onclick = close;
    dialog.querySelector('[data-action="open"]').onclick = () => {
      const scope = observed || getView(); close(); openConversation(scope);
    };
    dialog.querySelector('[data-action="choose"]').onclick = () => { close(); chooseConversation(); };
    dialog.querySelector('[data-action="new"]').onclick = () => { newConversation(); captured = {...getView()}; observed = null; commandResult = null; update(); input.focus(); };
    dialog.querySelector('[data-action="target"]').onclick = event => {
      event.stopPropagation(); // The outer shortcut button is outside the selector's click boundary.
      expandComposer();
      if (composer.querySelector("#composer-toolbar").hidden) composer.querySelector("#composer-controls-toggle").click();
      composer.querySelector("#target-selector button").click();
    };
    dialog.querySelector("#palette-enabled").checked = session.get("palette_shortcut_enabled", true);
    dialog.querySelector("#palette-binding").value = binding;
    dialog.querySelector("#palette-behavior").value = session.get("palette_open_behavior", "current");
    dialog.querySelector('[data-action="save"]').onclick = () => {
      const field = dialog.querySelector("#palette-binding"), normalized = normalizeShortcut(field.value);
      field.setAttribute("aria-invalid", String(!normalized));
      if (!normalized) {
        window.SMTOErrors.present(dialog.querySelector("#palette-settings-message"),
          window.SMTOErrors.error("palette_hotkey_conflict"), {profile: "toast"});
        return;
      }
      binding = normalized; field.value = normalized;
      session.set("palette_shortcut", normalized);
      session.set("palette_shortcut_enabled", dialog.querySelector("#palette-enabled").checked);
      session.set("palette_open_behavior", dialog.querySelector("#palette-behavior").value);
      bindingLabel(); dialog.querySelector("#palette-settings-message").textContent = "Saved for this tab. If your browser or OS intercepts the shortcut, choose another binding or use the palette button.";
    };
    return {open, close, update,
      submitting() { if (dialog.open) { submitting = true; commandResult = null; update(); } },
      accepted(response) {
        if (!dialog.open) return;
        observed = {conversation_id: response.conversation_id, task_id: response.task_id,
          request_id: response.current_request_id || null, status: response.status}; submitting = false;
        captured = {...getView(), conversation_id: response.conversation_id}; update();
      },
      failed(error) {
        if (!dialog.open) return;
        submitting = false; commandResult = {state: "failed", text: String(error?.message || error || "Submission failed")}; update();
      },
      async present(raw, response, scope, dispatch) {
        if (dialog.open) {
          submitting = false;
          commandResult = {state: response.status === "error" ? "failed" : "completed", text: response.message};
          update();
          // Canonical confirmations/panels and navigation must remain visible and operable.
          if (response.status !== "error" && response.client_action
            && !["stop_current_run", "pause_current_run", "resume_current_run", "compact_current_run"].includes(response.client_action.type)) close();
        }
        await dispatch(raw, response, scope);
      },
    };
  }
  window.SMTOCommandPalette = {create, project, normalizeShortcut, matchesShortcut};
})();
