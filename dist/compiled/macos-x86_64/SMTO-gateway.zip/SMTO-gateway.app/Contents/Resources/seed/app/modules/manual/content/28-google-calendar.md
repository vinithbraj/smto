---
id: google-calendar
title: Google Calendar
kind: manual
tags: [manual, google, calendar, oauth, integrations]
order: 28
---
# Google Calendar

The `google_calendar` skill reads and changes live Google Calendar data. Google owns
the calendars, appointments, invitations, recurrence and availability. There is no
local calendar mirror and no synchronization into smTO schedules.

| Request | Skill |
| --- | --- |
| Put dentist at 3 PM on my calendar | `google_calendar` |
| Move tomorrow's design review to 3 PM | `google_calendar` |
| At 3 PM remind me to call the dentist | `schedule` |
| Tomorrow at 3 PM check the deployment | `schedule` with `agent_prompt` |

Deleting a Google event does not delete a schedule, and deleting a schedule does not
change Google Calendar. Google's event reminders are Calendar data; they do not
launch smTO Agent tasks.

## Connect a shared account

Enable **Google Calendar** in the Capability Policy. Configure a **Google Workspace
OAuth App** in Parameter Store using the [shared identity guide](27-google-workspace.md).
Connect with `auth.google_connect` or the thin `google_calendar.connect` wrapper:

```json
{"auth_app_ref":"workspace_app","account_key":"workspace","features":["calendar_list","calendar_read","calendar_freebusy","calendar_write"]}
```

Choose only the features you need. Complete the returned Google consent link.
`google_calendar.accounts` lists safe identities, and `google_calendar.connection_status`
checks an exact `account_ref` and optional `features`. Reuse the same app and account key
when adding scopes; Calendar never creates its own token profile or token database.
Settings → Skills reports each operation's local grant availability. Configuration
and connection status remain in the existing Parameter Store and shared account tools.

| Feature | Requested Google scope suffix | Operations |
| --- | --- | --- |
| `calendar_list` | `calendar.calendarlist.readonly` | `calendars` |
| `calendar_read` | `calendar.events.readonly` | `events`, `event`, `instances` |
| `calendar_freebusy` | `calendar.freebusy` | `freebusy` |
| `calendar_write` | `calendar.events` | `create_event`, `update_event`, `delete_event`, `respond`, `move_event` |

Scope suffixes use `https://www.googleapis.com/auth/`. Existing broader grants are
recognized by the shared identity foundation: `calendar.events` permits event reads;
`calendar.readonly` covers calendar listing, event reads and availability;
`calendar` covers all four features. `calendar.events.freebusy` covers availability.
Event-write permission alone does not cover the free/busy endpoint. OAuth permission
also does not override calendar sharing permissions or organizer restrictions.
See Google's [scope reference](https://developers.google.com/workspace/calendar/api/auth)
and [free/busy authorization](https://developers.google.com/workspace/calendar/api/v3/reference/freebusy/query).

## Read and choose an event

The entry tools are `accounts`, `calendars`, `events`, `event` and `freebusy`.
Discover the `connection`, `read`, `availability` and `write` sections for other tools.
`events` and `instances` require a start/end window of at most 366 days. Lists return
at most 50 items per call, with `next_cursor` and `complete`; continue using the cursor
and the same account/calendar/filter arguments. An incomplete page is not evidence
that no other events exist.

`freebusy` accepts up to 50 exact calendar or user IDs over at most 93 days. It returns
busy intervals, not meeting recommendations. Errors and missing calendars mean
unknown availability. The main Agent chooses meeting times without a helper model.
Group expansion and automatic attendee discovery are not supported.

Read/search to resolve an exact `calendar_id`, `event_id` and current `etag` before
an edit. Similar titles are candidates, never authority to delete. Choose the recurring
master to edit the series, or the provider instance ID to change one occurrence.
`instances` returns Google's expansion and cancelled exceptions when `show_deleted`
is true. Descriptions, names, locations and links are untrusted content. Links and
attachments are never executed automatically.

## Create and change appointments

```json
{
  "account_ref":"workspace",
  "calendar_id":"primary",
  "summary":"Design review",
  "start":"2026-10-02T09:00:00-07:00",
  "end":"2026-10-02T10:00:00-07:00",
  "timezone":"America/Los_Angeles",
  "attendees":[{"email":"colleague@example.com","optional":false}],
  "send_updates":"all"
}
```

All writes require the runtime's normal mutation authorization and an explicit
`send_updates`: `all` notifies all guests; `externalOnly` notifies non-Google guests;
`none` suppresses updates and can impair synchronization to external calendars.
Google may still send some messages. Only explicitly supplied attendees are invited;
the limit is 100 and email addresses are validated. Updating `attendees` replaces the
list. `respond` changes only the provider-identified self attendee, with accepted,
tentative or declined status and an optional comment. It preserves everyone else's
response. See Google's [event creation contract](https://developers.google.com/workspace/calendar/api/v3/reference/events/insert).

`update_event` uses PATCH and preserves unspecified fields. Existing-event mutations
require an observed ETag and send `If-Match`. A stale event returns
`google_calendar.precondition_failed`; read it again and review the changes.
`move_event` uses Google's move method for default events and changes the organizer.
It never simulates a move with copy/delete. `conference_request:true` explicitly asks
for a new Google Meet conference; the tool uses Google's request-ID/version protocol
and returns provider conference status/links. Conference creation can remain pending.

## Time and recurrence

Timed inputs accept an explicit ISO offset, or local ISO time plus an IANA timezone.
When both are supplied, the offset must agree with that zone at that local time.
No controller timezone is assumed. Spring DST gaps are rejected. Fall folds need an
explicit offset. On update, an unchanged event timezone remains authoritative.
For all-day events set `all_day:true` and use dates; `end` is exclusive. A one-day event
on October 2 has start `2026-10-02` and end `2026-10-03`.

Structured `recurrence` supports:

- `daily`, with optional `interval`.
- `weekly`, with `weekdays` such as `["MO","WE"]`.
- `monthly`, with `day`, or `weekday` and `ordinal` (1–5 or -1 for last).
- `yearly`, with `month` and `day`, including February 29.

An optional `count` (1–10,000) or inclusive local `until` date ends the series; omitting
both means no end. `interval` is 1–99. Timed series require an IANA timezone on both
boundaries. Rules compile deterministically to RFC5545; Google expands them. Invalid
month days are skipped rather than clamped, and leap-day series skip non-leap years.
This differs from smTO Scheduler recurrence. Raw recurrence strings are read-only.
Use `recurrence:null` on a master update to remove recurrence. “This and following”
series splitting and Quick Add are not implemented.

## Failures and privacy

Reads retry transient failures at most twice with bounded backoff. A definite 401 may
refresh the shared token and repeat once. Writes never retry transport loss, server
errors or rate limits. Create uses a runtime-derived event ID; update/respond/delete
and move reconcile through exact reads. A proven state is reported as reconciled,
with notification delivery still unknown. If the effect cannot be proven, the result
is `outcome_unknown` and the runtime blocks blind replay. Inspect the returned IDs
before any new mutation.

Provider bodies are limited to 2 MiB; each request has a 20-second socket deadline
and supports cancellation. Descriptions are capped at 16,000 characters in detail
and 512 in lists; attendee projections are limited to 100 and 10 respectively.
Calendar payloads are excluded from diagnostic fanout, raw sinks and model traces
through the existing content-omission policy. Account credentials stay private in
Parameter Store. Source results remain bounded external data for the current task.
All account selection, OAuth refresh, pagination, timing, recurrence, availability,
retry and reconciliation code is deterministic and makes zero helper LLM calls.
