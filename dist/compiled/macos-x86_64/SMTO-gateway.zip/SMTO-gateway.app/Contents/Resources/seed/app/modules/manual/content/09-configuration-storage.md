---
id: configuration-storage
title: Configuration and storage
kind: manual
tags: [manual, settings, storage]
order: 19
---
# Configuration and storage

## Saving and storage cleanup

Deletion disappears from history once the server has durably accepted it. One
cleanup queue removes stored data after two seconds without task execution. New
execution pauses cleanup; large deletions take turns with smaller ones. The shared
indicator distinguishes queued, paused, cleaning, waiting for save, purging,
retrying, and complete states.

Saving persists prepared cleanup under the current retention rules. When tasks
are executing, the server saves without waiting for cleanup. A manual save also
requests a maintenance pass for expired artifacts and old unregistered files;
the save can finish while cleanup remains pending.

The server verifies the saved state before removing obsolete recovery copies and
managed files. Shared artifacts and evidence needed by unresolved work remain
protected. The yellow activity dot flashes while background maintenance is doing
work; pending cleanup alone does not make it flash.

Graceful shutdown drains local work, prepares eligible cleanup, saves, and finishes
file removal. It does not wait for unresolved remote jobs to finish. If cleanup
fails after saving, the server reports **Data saved; cleanup pending**, retains the
retry information, and exits. Cleanup resumes after restart. An unconfirmed save
continues to produce a separate warning.

Startup restores deletion protection before accepting work and resumes physical
cleanup afterward. Verified unchanged records are reused by the first save; real
startup repairs are still saved. Older recovery formats remain readable. Their
cleanup indexes are built during idle maintenance, so the first storage migration
can take longer than subsequent deletions.

## Auto-purge inactive conversations

Open **Settings → Auto-purge** to automatically delete old conversations. This
shared setting is **Off by default**. **Delete after inactivity (days)** defaults
to **1** (24 hours) and accepts positive whole numbers. You can set the duration
before turning Auto-purge on; both values save together across browser sessions.

New prompts, tasks, epochs, and substantive execution progress or completion reset
the timer for their conversation. Opening, viewing, searching, renaming, and
background heartbeats do not. Pinned conversations and conversations with queued,
running, paused, waiting, scheduled, monitored, or unresolved work are protected.
Unpinning uses the existing activity time rather than starting a new timer.

Enabling Auto-purge applies to existing history immediately. The server checks on
startup and every minute, even when no browser is open. Deletion is permanent;
stored data is removed through the background cleanup queue described above.
Turning Auto-purge off stops new deletions; already accepted deletions finish.

## Removable destination protection

**Settings → Removable destination protection → Protect removable destinations**
is **On by default for new installations**. Existing saved choices are preserved. The preference is
shared across tasks and browsers and persists after restart.

When enabled, recognized file writes and copy destinations are checked against
the selected USB or external drive. A source path such as “everything in
`/mnt/models`” does not select a destination. An explicit destination instruction,
accepted destination parameter, or confirmed drive choice can select one; multiple
eligible drives require a choice.

Directory inspection and dry-run copies do not require destination selection.
Arbitrary scripts and unsupported command syntax continue through ordinary
execution permissions; this optional check is not a filesystem sandbox. Disabling
it bypasses destination checks for subsequent operations. It does not replay
blocked commands, stop jobs, or change permissions or Resource locking settings.

## Appearance

**Settings → UI Preferences → Immersive mode by default** is on initially,
including fresh installations. New and existing conversations that follow
the default open in Immersive mode on desktop and mobile. An explicitly saved
off setting is preserved when upgrading. Use a conversation's **Immersive** switch to choose on or off for
that chat; later changes to the default preserve that choice. The default is
shared across devices, while conversation choices are saved in the current
browser and shared by its desktop and mobile interfaces.

Older saved on choices stay on. Older saved off values follow the new default,
because previous versions also saved off automatically without a user choice.

Open **Settings → UI Preferences** to change **Font**, **Font size**, or **High contrast**.
Desktop chat also has **More options → Appearance**; on mobile, open
**Agent options → Appearance**.

Opening the font picker automatically detects fonts available in your browser and
adds them to the dropdown. Detection checks a shared catalogue of macOS, Windows,
Linux, and common custom family names against text rendered on your device; it
does not list fonts from the smTO server. This works when accessing a remote
server and when the browser's font enumeration API is unavailable.

In browsers with Local Font Access, **Load system fonts** requests the full list
your browser exposes. This requires HTTPS or localhost and browser permission;
an existing grant loads the list automatically. Other browsers can only detect
known family names they can render. Browser privacy restrictions can hide fonts,
so automatic detection is not an exhaustive inventory. Safari in particular
[restricts user-installed font access](https://webkit.org/tracking-prevention/).

For another family, expand **Use another font**, enter the **Font family name**,
and choose **Use font**. Only the selected family is saved to the server. Detected
lists stay in the current page, and font files are not uploaded.
**System default** restores the device's default UI
font. A selected font uses a fallback on devices where it is unavailable; code
keeps its monospace font.

Use **A−** and **A+** to adjust all app text from 80% to 200% in 10% steps.
**Reset to 100%** restores the default text size without changing contrast.
High contrast strengthens text, borders, and keyboard focus in either Light or
Dark, and remains enabled when the theme changes. Defaults are 100% and normal
contrast. Existing theme selection and browser zoom continue to work.

Font, font size, and high contrast apply immediately and save across devices connected
to this application instance. If saving fails, the current page keeps the preview;
choose **Retry** (or **Retry save** in Settings) to save it. These preferences cover
the Agent UI and its management pages, including the dedicated mobile client.
The standalone Manual, diagnostic sidecar, and separate sites keep their own
appearance.

## Export / Import

After clicking **Export JSON**, a single status line shows the current export stage
and estimated time remaining. The estimate adapts to measured progress; new exports
may show **Estimating…**, and interrupted measurements show **Re-estimating…**.
Stage changes use your activity-update animation preference. Leaving Settings while
an export is running asks whether to stay or cancel; reloading or closing the tab
uses the browser's standard warning. **JSON ready · Download started** means the
complete backup has been handed to the browser's download manager.

Open **Settings → Export / Import** to download a JSON backup or restore one from
another app version. Export includes all 15 application stores: settings and runtime
configuration, Parameter Store values (including secrets), conversations and messages,
uploaded documents, generated artifacts, tasks, schedules, notifications, monitors,
recipes, prompt templates, conversation notes, Memory, execution cache, traces and
model-output history. The download contains plaintext credentials; store it securely.

Choose a JSON file to validate it and review the source version and record/file counts.
Validation does not change existing data. Check the replacement acknowledgement and
choose **Import on next restart**, then restart the app. Import replaces saved data;
it does not merge conversations. Until restart, **Cancel pending import** cancels the
replacement. Edits made after staging are replaced by the imported data. The current JSON size limit is 512 MiB.

The app rebuilds current database schemas before loading the records. Backup format
and collection versions are separate from SQLite schema versions. Older records can
omit newly added nullable/defaulted fields. Unknown versions, collections or fields,
invalid settings, duplicate records, broken database references, invalid paths, and
checksum mismatches reject the import before replacement. Changes that rename fields
or alter their meaning require an explicit compatibility adapter; the importer never
silently drops unfamiliar data or executes SQL from a backup.

Import applies before runtime stores and workers open. Temporary rollback material
and a write-ahead journal restore the originals if replacement fails or the process
stops midway. After verified replacement, the app removes that temporary material.

The running app uses RAM as its working state and retains one committed checkpoint
on disk. Automatic saves run after the two-second idle grace; explicit Save and
shutdown also flush changes. Saving builds one temporary replacement, verifies it,
publishes it atomically, and removes the old save. There is no retained previous
checkpoint or permanent repair copy. Each checkpoint includes SQLite and matching
logical JSON recovery data for the same revision; these rotate together.

Deletion is accepted durably before it disappears from history. The idle cleanup
queue removes disposable records from RAM in bounded, rotating batches. The save
worker dumps the affected RAM domains into fresh databases and logical recovery
files, then replaces the checkpoint. Unchanged domains reuse verified bytes. Deletion
never opens a database itself. Cleanup completes only after the old save and other
application-owned recovery copies are removed. Pending remote work retains its
required evidence and does not prevent startup.

Restored schedules are paused and unfinished tasks/runs are interrupted. Running
external jobs are retained as lost/unknown outcomes, without adopting source process
leases. Review connections and work before resuming. Destination database paths,
workspace root and listener address/port remain local. External workspace/Gateway
files, environment files, browser-only preferences/drafts and device identity keys
are outside this backup. A different computer may need fresh Gateway pairing and
license acceptance. Imported bootstrap configuration is saved in the settings store;
UI settings continue to override its runtime defaults.

If an old SQLite schema prevents startup, use the CLI from the app workspace:

```sh
aor backup-export backup.json
aor backup-import backup.json
aor backup-import backup.json --replace-existing
```

The first command reads stores without opening schema-enforcing store constructors
and refuses to overwrite an existing output file. Import without `--replace-existing`
only validates and previews. Both commands accept `--config PATH`. Restart the single
controller process to apply a staged restore; do not run another controller against
the same files during replacement.

For maintainers: `data_transfer/stores.py` owns the store inventory and the
`migrate_records` compatibility boundary. Keep wire versions stable for additive
database changes, and add explicit adapters and historical fixtures for semantic or
renaming changes. `test_data_transfer.py` covers the full inventory, old-schema
export, missing-column defaults, rejection without mutation, and interrupted restore.
The browser tests exercise Settings at desktop/mobile widths and both themes.

**Settings → Capabilities → Automatic Capability Selection** is on by default.
The same switch in composer **Options** changes the next prompt on desktop and
mobile. Automatic mode selects relevant permitted Skills before the Agent runs;
Manual mode exposes the complete permitted set using ordinary discovery. In the
Capabilities editor, **Auto** means eligible, **Always** means included in each
selection, and **Never** excludes the capability. These choices support prompt,
conversation, and global scopes. Selection does not grant credentials or approval.
The activity view shows the selection, changes after steering, unavailable Skills,
and any fallback to the accepted permitted set. Queued and scheduled work keeps
the configuration captured when accepted; changing the default affects future work.

**Agent Introspection, Memory and Shell are always selected in both Automatic and
Manual.** Their Skills and tools appear as **Built in · Always enabled** on desktop
and mobile, with no selection toggles. **Clear all** and **Exclude all others** retain
them. The server includes them even when Auto chooses no optional Skills or only Files,
so checking a repository does not require adding the word “shell” to the request.
Memory remains available for relevant recall and reusable lessons; an instruction not
to remember information still takes precedence over proactive learning.

**File read (`file.read`) is also included whenever permitted**, even when Automatic
selection omits the Files skill. Other Files tools still follow normal selection.
The Agent prefers bounded native reads for known files and `read_result` for omitted
output already captured by a previous call. Files/tool exclusions, workflow limits,
Advisory mode and Gateway availability continue to apply. Existing saved selections
remain unchanged until a new selection is accepted.

Selection does not bypass execution permissions, Shell executable exclusions, workflow
restrictions or Gateway prerequisites. Advisory mode permits local Memory but does not
execute Shell commands. After installing this change and restarting the server, submit
a new request. New requests normalize saved Memory/Shell exclusions away; Resume,
Continue and Restart without new intent retain the already accepted selection.
See [tool discovery](architecture/04-discovery.md) and
[durable Memory](architecture/22-context-memory.md#durable-cross-conversation-memory).

The active Python configuration is `src/agent_runtime/api/config.py:Settings`. Runtime updates accept the explicit fields in `AgentRuntimeControlsPayload`. Mission Control uses a curated registry with `schema_version: 2`; internal runtime fields do not automatically become settings. UI preferences are stored by `api/settings_store.py`.

**Settings → Security → Gate sudo** controls server-side sudo handling and is on
by default. When enabled, the server checks sudo syntax and uses managed local or
verified remote elevation. When disabled, sudo commands pass through unchanged,
including `sshpass`, sudo options, pipelines, redirects and command sequences.
The server bypasses its sudo-specific checks and automatic elevation. Use the
command's normal password input, stdin or terminal interaction in this mode;
the managed `sudo_password` and `sudo_username` fields are inactive. Ordinary
command permissions and the target operating system's authentication still apply.
Changes affect subsequent commands, including active and resumed tasks.

The [Model Configuration guide](25-model-configuration.md) covers profiles,
per-parameter controls, recommendations, provider errors and the runtime-controls API.

Mission Control → **Model Configuration** contains the endpoint URL, request timeout and configured context ceiling, a Configuration Profile selector, and request parameters grouped by generation, reasoning, penalties, diagnostics, vLLM sampling/token controls and provider scheduling. The served model's actual capacity and derived URLs remain runtime facts. A larger configured context ceiling cannot create capacity on the model server.

Inference-enabled controllers can bind a ready managed instance in
**Inference → Overview**. This uses the same model settings, with an instance
reference and verified launch generation. **Inference → Caching** also reuses
Settings' prompt-caching editor. Inference profiles, private secrets, jobs and logs
live in `inference/` beside the current-run database; model/runtime/build paths
remain separately configurable. See [Inference management](45-inference.md).

**Provider Defaults** omits all optional execution parameters. **smTO Recommended** is an Agent Optimized starting point for tool-using workloads; it uses confirmed provider/model capabilities and can leave fields omitted. **Custom** preserves individual choices. Each parameter has exactly two modes: **Use Provider Default** deletes its key; **User Configured** sends its exact value. Selecting User Configured prefills a suggested value for editing. Changing any parameter switches the global profile to Custom. The resolved-settings disclosure shows each configured or omitted field.

These settings affect normal agent execution: tool decisions, interpreting results, and final answers. Internal operations such as Task Contract generation, compiler retries, constrained recovery, and Task Summary use their own configuration. Endpoint and timeout remain transport settings with their existing scope. Changes apply to new tasks; active and resumed runs retain their saved execution settings.

The **Capability-selection timeout (seconds)** control sits beside the other model timeouts in Settings → Model Configuration → Connection. It defaults to 30 seconds and accepts 30–1,800 seconds. Increase it when automatic capability selection needs more time on a slow or busy model server. The model request and no-actionable-output timeouts still apply, with the earliest applicable limit winning. If selection fails, the task continues with its already permitted capabilities. Saved changes apply to new tasks; resumed tasks retain their accepted value, and tasks saved before this setting existed retain the former 30-second limit.

The recommended vLLM baseline is Temperature 0.6, Top P 0.95, Top K 20, Min P 0, Maximum completion tokens 8192, Presence/Frequency penalties 0, and Repetition penalty 1. It is a starting point, not a universal optimum. Model family, reasoning mode, quantization, template, server generation configuration, workload and latency goals matter. Recognized OpenAI models get a compatible subset; unknown capabilities stay at Provider Default. No additional provider probes or model calls select recommendations.

The backend persists `llm_execution_request_overrides` and `llm_execution_configuration_profile` in the existing runtime-control namespace. Key presence encodes User Configured; omission encodes Provider Default. Explicit zero, false, empty arrays and empty maps are preserved. For example, `{"temperature":0,"ignore_eos":false,"stop":[]}` sends all three values. Unknown fields, nulls and invalid types/ranges are rejected before persistence. Settings uses the existing serialized autosave and retains invalid edits for correction.

Execution request overrides are captured directly in the current override map and configuration profile. Internal client defaults do not become execution wire overrides. Resumed current runs retain their accepted execution configuration. Provider rejection does not delete settings or retry without them: choose Provider Default or a supported value for the named control.

Maximum completion tokens is a provider request limit for one execution call, not the whole task. Its explicit value also sets the execution context reservation. When omitted, smTO still reserves output space internally without sending a completion limit. Larger reservations leave less space for input/history. Task Contract and recovery output limits remain independent.

UI preferences use `PUT /api/agent/settings/preferences`; execution controls use `POST /api/agent/runtime-controls`. Unknown saved UI preference keys are ignored. Loading Settings does not write defaults back to the server. Browser conversation, model and chat-theme selections remain local; prompt history remains backend-owned.

**Settings → Advanced → Ramble guard** is enabled by default. It appends convergence
guidance at the end of agent instructions on every execution turn, after skill and
Task Contract guidance. The agent is guided to settle reasonably verified decisions,
avoid repeated reasoning and speculative alternatives, and proceed when requirements
are satisfied. New evidence, failed verification or an unmet requirement can reopen a
decision. Turn it off to omit this paragraph from new tasks.

The backend preference is `ramble_guard_enabled` (strict boolean). For example,
`PUT /api/agent/settings/preferences` with `{"settings":{"ramble_guard_enabled":false}}`
disables it. Prepared, queued and scheduled tasks capture their setting when accepted;
resumed and restarted tasks keep that value. Older tasks use the enabled default.

**Settings → Advanced → Context-efficient execution** is enabled by default.
It guides the agent to inspect scope, use bounded reads and batches, keep script
output compact, and save large intermediate data to files or results for exact
retrieval later. Turn it off to omit this guidance from new tasks. Both modes retain
the same Full Tool Results, verification, parallel execution and compaction behavior.

The backend preference is `context_efficient_execution_enabled` (strict boolean).
For example, `PUT /api/agent/settings/preferences` with
`{"settings":{"context_efficient_execution_enabled":false}}` disables it.
Prepared, queued and scheduled tasks capture the setting when accepted; active,
resumed and restarted tasks keep that value. New tasks in existing or forked
conversations use the current setting. Checkpoints and prepared requests from
before this setting existed use the enabled default.

**Settings → Advanced → Automatic Python correction** is enabled by default.
It repairs safe Python tool entrypoint shape mistakes before validation, with no
model call: simple top-level scripts can be wrapped in `main(inputs)` or
`transform(inputs)`, safe imports can move into the entrypoint, and exact redundant
entrypoint calls/guards can be removed. It does not invent returns, repair syntax
or runtime errors, or bypass safety and permissions. Unsupported source follows
the existing model-correction path. Turn it off to keep strict rejection of malformed
entrypoints (`python_entrypoint_required` for `python.run`).

The backend key is `python_entrypoint_auto_correction_enabled`, a strict boolean
in the existing preferences API. Prepared, queued, durable and scheduled tasks
capture it when accepted; active, continued and restarted tasks retain their
captured setting. Missing historical values default ON. This preference is
independent of Agent Checks and generic tool-argument normalization.

The Agent UI model dropdown discovers all models from the configured LLM endpoint's `/models` API. Select a model to use it for new requests; the server saves the exact choice with this conversation. Use Refresh models after changing the served models. The list also reloads when returning to the window. A configured `llm.default_model` is preferred if the endpoint exposes it; otherwise discovery selects the first available model. New configurations default to `auto`. Saved unavailable models remain visible and block Send until you choose a replacement. Existing runs retain their original model when resumed.

Database settings are `database_enabled`, `database_default_limit`, `database_max_rows` and corresponding `AOR_DATABASE_*` environment variables. Retired SQL-agent aliases are unsupported; configuration uses these current names. The workspace option is `workspace_cwd_guard_enabled` and explicit monitor drafting is `monitor_drafting_enabled`.

Mode IDs are `conversation`, `agent`, `advisory` (`standard` is a historical read alias). Approval mode is `manual` or `full_access`. Retired settings are filtered at the input boundary and are not active configuration knobs. The generated environment and route references show active source consumers.

Conversation, task, event, monitor, and parameter stores remain isolated by their configured paths. The current-run database stores journals, receipts, artifact scope links and jobs. Preserve credentials and provider stores during upgrades; do not treat generated test state as user data.

Reusable HTTP target configuration belongs to Parameter Store, not the Settings
preferences store. Create it with the HTTP Connection template and use `@name` in
Chat. Credentials remain inside the same sensitive Parameter record; cookies,
CSRF and OAuth session tokens remain volatile HTTP runtime state. Existing saved
profiles need no datastore migration. See [Parameters](16-parameter-store-context-sql.md).


Composer preferences are durable per conversation: mode, gateway selection, model, behavior
effort, summarization, Generate prose and Task Contract compilation/integrity. Desktop and
mobile share them. Global preferences initialize new conversations and do not rewrite existing
profiles. The four quick scheduling controls use existing conversation policy scopes; advanced
**This prompt** overrides apply once. Secure Prompts is retired. Settings → Redaction provides 20 independent switches, all on for new installations; see [policy lifetimes](architecture/31-redaction.md).

New Chat starts from current defaults. Settings changed before its first accepted task are
kept in memory and materialize when the task is accepted; an unsent page reload resets them.
Legacy conversations recover known choices from their latest accepted task. Missing or corrupt
execution selections require an explicit replacement. Forks inherit allowed convenience choices,
with fresh authority scopes; deleting a conversation removes its composer preferences.


## Fresh-state baseline

This release requires current, explicitly versioned state. An empty chat list does not establish that the other databases are current. Startup checks every configured runtime database before recovery. Unversioned databases with application tables, older schemas and newer unsupported schemas are rejected without migration or deletion.

Back up the complete old state directory. Start with a new empty directory using `AOR_AGENT_STATE_DIR`, and ensure any per-store path overrides also point to fresh files. Do not copy individual old databases into the new directory. Use a matching older runtime to access the backup. Current state created by this release supports normal restart, queue recovery and conversation continuation.

Fresh stores create their complete schema directly. The browser rebuilds tasks from the server queue and ignores retired local queue snapshots. Current settings, native journals, prepared policy snapshots, HTTP v3 profiles and Parameter Store Gmail authorization are written in their supported formats at creation. Missing accepted snapshots block execution; reads do not reconstruct them from old task history.

New installations seed portable product preferences: automatic day/night theme,
Ubuntu font (with system fallback), Roll activity updates, hidden wavelet timeline,
Task Skill context retrieval, Full tool results, Ask permissions with Gate sudo on,
and monitoring of disabled Agent Checks. All 31 Agent Checks, all 20 redaction
sources, and removable destination protection start on. Unsafe actions require
confirmation. Workspace CWD protection and tool resource locking also default on.
Users can disable individual protections in Settings and scope Agent Check overrides
to a conversation, prompt, or run.

Task concurrency defaults to two. Foreground, background and dependency activity
limits are 16; resource scheduling uses custom limits with eight total/per-Gateway
activities, 16 for heavy resource classes, eight lightweight/unknown and four
observations. Model transport timeout is 1,800 seconds; the no-actionable-output
timeout is 300 seconds. User edits persist across restarts, and accepted tasks keep
their captured settings. Installation presets do not replace saved preferences;
existing stores retain historical fallbacks for missing UI preferences. Missing
Agent Check, workspace guard, and tool-locking settings use the enabled product defaults.

The preset contains no personal name, Gateway address, credential, workspace path
or model tuning. The product name remains the default, context capacity stays on
Auto, thinking budget stays at 50%, and generation parameters use provider defaults.

## Monitor disabled Agent Checks

**Settings → Agent Checks → Monitor disabled Agent Checks** is stored as the strict boolean `disabled_agent_check_monitoring_enabled` in the existing Agent UI preferences namespace. Fresh installations seed it ON alongside the [Agent Checks preset](architecture/21-checks-authority.md#monitoring-disabled-checks). Existing installations keep their saved settings; missing settings and legacy saved work still resolve OFF. Individual check switches and the **Disable all** action remain independent.

ON enables local assessment and informational Activity notes with **Learn more** for disabled checks. It adds no model calls, approval prompts or enforcement. The accepted task/run snapshot owns the value through queueing, resume, restart and continuation; changing Settings applies to future accepted work.

### Tool result delivery

`tool_result_delivery_mode` accepts exactly `adaptive`, `compact` or `full`. Desktop
and mobile use the same server preference; public request context cannot override
accepted settings. New empty settings stores default to Full. Existing stores
migrate their saved boolean (true → Full, false/missing → Compact) once. See
[context and memory](/manual#doc=context-compaction-kv) for behavior and exact retrieval.

## Purge runtime data while preserving setup

Open **Settings → Storage → Preview purge**. The preview lists the controller and
all configured Gateways, estimated storage, active work, and unavailable targets.
Sign in as the installation owner and type **PURGE RUNTIME DATA** exactly to start.
Deletion is permanent. Active work stops, services restart, and progress survives
browser reloads and process restarts.

The purge preserves settings, parameters, secrets, permissions, accounts, licenses,
pairing, device identities, saved Memory, workflows and revisions, prompt templates,
schedule definitions and saved monitors. Managed documents and artifact bodies
referenced by retained definitions survive with their obsolete conversation links
detached. Workspace files, repositories, build outputs, installed runtimes, model
downloads, exported user backups and system logs are outside the purge.

All conversations, including pinned conversations, tasks, queues, runs, results,
traces, model-output captures, execution caches, notifications, observations, job
receipts and obsolete recovery generations are deleted. Unreferenced managed
uploads, generated artifacts, scratch and transfer staging are removed as well.
This bypasses normal retention eligibility. Enabled schedules and saved monitors
resume in fresh contexts when their required Gateways are ready; missed schedule
triggers are not replayed. New automation can create fresh runtime data immediately.

Unavailable Gateways remain pending; older versions without the maintenance
capability require an upgrade. Pending targets cannot execute work. Reconnection
retries their cleanup; **Retry pending targets** retries blocked targets after the
cause is resolved. A target is never marked successful while process termination,
storage ownership or retained setup is uncertain. Shared managed directories with
another instance's ownership evidence remain blocked rather than deleting that
instance's files.

### Offline recovery

Stop the selected service and its automatic restart manager first. Use the same
account, configuration, state-directory environment variables and instance selector
as normal startup. Offline recovery acts only on the local installation; server
recovery records Gateways for reconciliation after startup.

```sh
# Server source installation, from the repository root:
./startup.sh runtime-purge --dry-run
./startup.sh runtime-purge --confirm "PURGE RUNTIME DATA"
# Add --config /path/to/app-config.yaml when using an explicit configuration.

# Linux Gateway source installation:
./src/gateway_agent/startup.sh runtime-purge --instance example --dry-run
./src/gateway_agent/startup.sh runtime-purge --instance example --confirm "PURGE RUNTIME DATA"
# macOS uses src/gateway_macos/startup.sh with the same arguments.
```

Windows supports `src/gateway_windows/startup.ps1 runtime-purge -DryRun` and
`src/gateway_windows/startup.ps1 runtime-purge -Confirm "PURGE RUNTIME DATA"`, with
`-Instance`, `-Port` and `-TlsStateDir` selectors. Packaged Server and Gateway
executables accept `runtime-purge --dry-run` and
`runtime-purge --confirm "PURGE RUNTIME DATA"`. Gateway recovery also accepts
`--tls-state-dir` and `--port`. Restart the service after offline completion.

Recovery reads preserved collections independently of disposable history. If a
preserved collection is corrupt or missing, recovery stops and names it; it does
not substitute installation defaults. Current checkpoints include independently
readable native setup and Gateway policy data for this purpose. A damaged replay
cache is cleared only after holding exclusive authentication ownership for the
full replay window; pairing keys remain intact. Disk-write failures leave a
resumable journal. Free space or resolve the reported ownership problem, then run
the same command again. Once deletion starts, recovery only moves forward.

The controller API uses `/api/agent/runtime-purge/preview`, `/start`, `/status`,
`/{operation_id}` and `/{operation_id}/retry`. Start returns an operation ID with
HTTP 202. Gateway maintenance is owner-authenticated over HTTPS or the paired
outbound connection and is never exposed as a model tool.
