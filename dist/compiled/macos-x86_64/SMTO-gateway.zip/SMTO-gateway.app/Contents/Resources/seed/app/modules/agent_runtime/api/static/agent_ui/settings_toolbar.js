/* Responsive disclosure for the existing Settings actions; no duplicate controls. */
(() => {
  "use strict";
  const button = document.getElementById("settings-more-button");
  const panel = document.getElementById("settings-secondary-actions");
  if (!button || !panel) return;
  const host = button.parentElement;
  const narrow = matchMedia("(max-width: 980px)");
  let expanded = false;
  function render() {
    button.hidden = !narrow.matches;
    panel.hidden = narrow.matches && !expanded;
    button.setAttribute("aria-expanded", String(narrow.matches && expanded));
  }
  function close(returnFocus = false) {
    if (!expanded) return;
    expanded = false; render();
    if (returnFocus && narrow.matches) button.focus({preventScroll: true});
  }
  button.addEventListener("click", () => { expanded = !expanded; render(); });
  host.addEventListener("keydown", event => {
    if (event.key === "Escape" && expanded) {
      event.preventDefault(); event.stopPropagation(); close(true);
    }
  });
  document.addEventListener("pointerdown", event => {
    if (!host.contains(event.target)) close(panel.contains(document.activeElement));
  });
  host.addEventListener("focusout", event => {
    // relatedTarget is the next tab stop; activeElement can temporarily be body
    // while the browser is transferring focus between two menu controls.
    if (event.relatedTarget && !host.contains(event.relatedTarget)) close();
  });
  panel.addEventListener("click", event => {
    if (event.target.closest("a, button")) {
      // Close before the action runs, so a dialog or Find remembers the visible
      // More button as its return target instead of a now-hidden menu action.
      close(true);
    }
  }, {capture: true});
  narrow.addEventListener("change", () => {
    const focused = panel.contains(document.activeElement);
    expanded = false; render();
    if (narrow.matches && focused) button.focus({preventScroll: true});
  });
  render();
})();
