/* Server-owned continuation intent; this component never schedules a turn. */
(() => {
  "use strict";
  const expanded = new Map();
  function create({requestId, apiJson, actionContainer, host, notify = () => {}}) {
    const base = `/api/agent/native/${encodeURIComponent(requestId)}/follow-up-queue`;
    const panel = document.createElement("details");
    panel.className = "followup-queue run-detail-panel";
    const summary = document.createElement("summary"); summary.textContent = "Queued continuations";
    const status = document.createElement("p"); status.className = "muted"; status.setAttribute("role", "status");
    const list = document.createElement("ol");
    panel.append(summary, status, list); host.append(panel);
    const disclosure = window.SMTOConversationSnapshot.disclosureAction({actionContainer, panel, label: "Queue (0)"});
    disclosure.action.classList.add("followup-queue-action");
    let data = null, rootId = requestId, revision = null, disposed = false, superseded = false;
    let loading = null, again = false, renderedItems = "", lastStatus = "";
    let readFeedback = null;
    function render() {
      disclosure.action.textContent = `Queue (${data?.count || 0})`;
      disclosure.action.hidden = superseded;
      if (superseded) { panel.open = false; panel.hidden = true; return; }
      panel.hidden = !panel.open;
      status.textContent = data?.reason || (data?.count ? "Waiting for the current task to finish." : "No queued continuations.");
      const itemsKey = JSON.stringify(data?.items || []);
      if (itemsKey === renderedItems) return;
      renderedItems = itemsKey;
      list.replaceChildren();
      for (const item of data?.items || []) {
        const row = document.createElement("li"); row.dataset.queueItemId = item.item_id;
        const text = document.createElement("span"); text.textContent = item.prompt;
        const remove = document.createElement("button"); remove.type = "button";
        remove.className = "followup-queue-delete";
        remove.title = "Delete queued continuation"; remove.setAttribute("aria-label", "Delete queued continuation");
        remove.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7m4-7v7"/></svg>';
        remove.disabled = !item.can_delete;
        remove.onclick = async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating queued instruction…", remove);
        try {
          const ownedFocus = document.activeElement === remove;
          remove.disabled = true;
          try {
            accept(await apiJson(`${base}/${encodeURIComponent(item.item_id)}`, {method: "DELETE"}));
            if (ownedFocus && !disposed) (list.querySelector("button") || disclosure.action).focus({preventScroll: true});
          }
          catch (error) {
            notify(error.status === 409 ? "This continuation has already been scheduled." : "Couldn’t delete this continuation. Try again.");
            remove.disabled = false; await refresh();
          }

        } finally { busyFeedback?.finish(); }
      };
        const labels = [
          ...(item.resources?.context_refs || []).map(ref => ref.name),
          ...(item.resources?.gateways || []).map(gateway => gateway.label),
          ...(item.resources?.parameters || []).map(parameter => `@${parameter.key}`),
        ];
        if (labels.length) {
          const resources = document.createElement("small"); resources.textContent = labels.join(" · ");
          text.append(document.createElement("br"), resources);
        }
        row.append(text, remove); list.append(row);
      }
    }
    function accept(value) {
      if (disposed || (data && value.root_run_id === data.root_run_id && value.revision < data.revision)) return;
      rootId = value.root_run_id || rootId;
      data = value; revision = value.revision;
      render();
    }
    async function refresh(feedback = false) {
      const operation = feedback ? window.SMTOBusy?.begin({host: list, label: "Loading queued instructions…", key: "open", replace: true}) : null;
      if (operation) readFeedback = operation;
      try {
      if (disposed || superseded) return;
      if (loading) { again = true; return await loading; }
      loading = (async () => {
        do {
          again = false;
          try { accept(await apiJson(base)); }
          catch (_) { if (!disposed) status.textContent = "Couldn’t refresh the queue. Reopen to retry."; }
        } while (again && !disposed);
      })();
      try { await loading; } finally { loading = null; }
      } finally { operation?.finish(); }
    }
    const toggle = disclosure.action.onclick;
    disclosure.action.onclick = () => {
      toggle();
      if (panel.open) void refresh(true);
      else readFeedback?.dispose();
    };
    summary.addEventListener("click", event => {
      event.preventDefault(); disclosure.action.onclick();
    });
    panel.addEventListener("toggle", () => {
      if (disposed || superseded) return;
      expanded.set(rootId, panel.open);
      if (panel.open) void refresh();
      else readFeedback?.dispose();
    });
    return {
      async enqueue({amendment, submissionId, resources}) {
        const result = await apiJson(base, {method: "POST", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({amendment, submission_id: submissionId, resources})});
        accept(result);
        return result;
      },
      update(snapshot) {
        if (disposed) return;
        superseded = Boolean(snapshot?.continued_by);
        const info = snapshot?.followup_queue;
        const statusChanged = Boolean(snapshot?.status && snapshot.status !== lastStatus);
        lastStatus = snapshot?.status || lastStatus;
        if (info && (!data || info.root_run_id !== data.root_run_id || info.revision >= data.revision)) {
          rootId = info.root_run_id;
          if (info.revision !== revision) {
            data = {...data, ...info};
          }
          if (!superseded && expanded.get(rootId) && !panel.open) panel.open = true;
        }
        if (!superseded && panel.open && (statusChanged || info?.revision > revision)) void refresh();
        render();
      },
      dispose() { disposed = true; readFeedback?.dispose(); disclosure.dispose(); panel.remove(); },
    };
  }
  window.SMTOFollowupQueue = {create};
})();
