---
id: ui-pages-tour
title: UI Pages Tour
kind: manual
tags: [manual, ui]
order: 22
---
# UI Pages Tour

Choose **Plan** from the Mode picker in expanded composer Controls (mobile:
**Agent options**) to inspect and discuss changes before implementation. The picker
offers Agent, Plan, and Ask; Conversation is hidden from it and Settings. A completed
plan offers **Yes, implement this plan** in the same
chat, **Yes, clear context and implement** in a fresh chat, and **No, stay in Plan
mode** to request revisions. Both implementation choices switch to Agent mode.
Fresh implementation carries the approved plan and
preferences without the planning transcript. Task Contract remains a separate saved
preference: planning suppresses compilation and implementation restores it. Permission
grants do not permit writes while a task is in Plan.

`/agent-ui` is the conversational workspace. It exposes conversations, tasks, jobs, waits and attachments from persisted runtime state. Missing authentication values use ordinary `ask_user` and one normal reply. Literal values remain canonical task data; optional Redaction settings control consumer projections. OAuth authorization retains its protocol-specific interaction.

When an action is processing, its control or panel shows a short status immediately. A small circular indicator appears if it is still pending after two seconds and disappears when the action completes or fails. Reduced-motion mode keeps this indicator still. Closing a dialog dismisses its loading display; it does not cancel an already accepted save or Agent task. Agent execution keeps its own activity and progress display.

The header's Save to SQL button turns green when SQL confirms all data accepted before that click. Large saves can take several minutes; the button keeps checking and stays in its saving state. A temporary connection interruption while checking also keeps checking. Red indicates a rejected or unconfirmed save request, a reported write failure, or a server restart before confirmation; the tooltip explains which occurred. After a write failure, the button continues watching the server's automatic retry and also allows a manual retry. Later changes may need another save; green confirms the data covered by the completed click.

When stopping the server, keep its terminal open until it prints **SQL save complete. Safe to close this terminal.** Shutdown logs explain when background services are stopping and when SQL saving begins, with elapsed-time updates every five seconds. The final save waits for completion even when it exceeds the normal worker shutdown timeout. Avoid pressing Ctrl+C again or force-killing the server while it is saving. A failed or interrupted save prints a warning instead of claiming completion.

Expand an Agent activity row to inspect the input and output from that exact invocation, projected according to its redaction setting. Completed HTTP requests expose request headers/body, status, response headers/body and available timing/size metadata. Web Search exposes the returned sources; Web Read shows extracted content. Connection rows explain the target, Gateway and authentication state. Expanding a captured Shell row opens its retained and live output stream; collapsing it closes the viewer while the command continues. Running state, exit code and viewer connection state are shown separately. Copy output and Jump to latest operate locally and do not call the model. Python and job operations expose their available execution evidence.

For a Shell command running as a background job, the inspector reads the runtime's
retained job status. Output appears when the runtime retains the completed result;
the panel explains this while the job is running. Completion freezes elapsed time
at the recorded job duration and closes the observer. Missing or incomplete output
is labeled explicitly. Opening the inspector does not query the Gateway or restart
the job.

Inspection does not pause the Agent. Details become available as each invocation completes, before the task's final answer or Results document. Responses are rendered as data; retrieved HTML cannot execute. Credentials remain literal unless the owning Redaction source is enabled. Hidden reasoning, internal prompts and context-control contents are excluded from this inspector.

The inspector fetches details only when opened. Each section previews at most 64 KiB, with a 256 KiB content budget per invocation; truncation is marked explicitly. Binary content is represented by metadata. Existing HTTP artifact retention is preserved and its metadata remains inspectable. Normal reload/reconnect works while the backend retains the detail. Previews share the trace's in-memory lifetime, with at most 64 per request and 16 MiB across all requests. Evicted details or a server restart show “Execution details are no longer available.” Older Gateways can supply result evidence but cannot retroactively provide transmitted request details.

Use `/schedules` for the Scheduler Manager (also available from the Agent header calendar icon), `/directory` for available services, `/settings` for active configuration, `/parameter-editor` for Parameter Store profiles, protected values, and reusable agent guidance. Gmail's delivery/sync activity is provider diagnostics, separate from the model decision loop.

In Settings, use the magnifying glass (under **More** on narrow screens) or
**Ctrl+F / ⌘F** to search settings and Gateways. The same search matches labels,
setting keys, and help text, and highlights matching text. **Escape** closes
search and restores the full page and your expanded sections.

Linux controllers with integrated management also expose **Inference** at
`/inference` in desktop/mobile navigation and the directory. Its searchable tabs
cover Overview, Instances, Models, Environments & Builds, Hosts & GPUs, Caching,
Jobs & Logs, and Preferences. It shares the existing themes and settings editors.
See [Inference management](45-inference.md) for setup and the separate Save,
Validate and Apply / Restart actions. External-only artifacts omit this surface.

**Add to scheduler** in a task's bottom action row opens the same scheduling editor
as the calendar button beside its prompt. Choose when to run it, or edit its existing
schedule. Opening or saving a schedule does not execute the task immediately.

In Parameter Store, the template menu beside **New** offers **Blank**, **Server**,
**Proxmox Server**, **Credential**, **Git Repository**, Gmail profiles, and **HTTP Connection** auth starters. Choose a template and click
**New** to start an unsaved draft. Saving a profile does not enable a skill or connect
to its server. The [Proxmox guide](24-proxmox.md) covers enabling the optional skill
and using a saved server profile; [Parameter Store](16-parameter-store-context-sql.md)
explains typed credential privacy and ordinary parameter behavior.

Ordinary chat is sent to the model. Slash commands use the application control API, add no model-history turn, and remain available during execution according to each command’s state requirements. Type `/` to discover `/status`, `/new`, `/stop`, `/delete`, `/help`, `/pause`, `/resume`, `/compact`, `/history`, `/settings`, `/queue`, `/clearqueue`, `/trace`, and `/restart`. `/status` opens a closeable status panel or mobile sheet with exact or explicitly estimated context usage. `/delete` uses the normal safety confirmation and opens the nearest older surviving conversation, or New Chat. `/restart` restarts the backend and requests restarts for enabled gateways even while tasks are active; active work may be interrupted. Use the composer and run controls to submit work, attach context, and manage the current run. The task board displays model-authored high-level outcomes, while command cards show actual tool output. Normal chat does not open a browser terminal connection; backend Gateway PTYs remain available to explicit execution capabilities.

Conversation deletion uses one confirmation on desktop and mobile. It removes saved
turns, discards queued prompts, abandons conversation work and requests cancellation
of running operations. Work changing while the confirmation is open does not block
deletion. Already-started external operations may continue; their execution evidence
is retained, and independent schedules, monitors and tasks remain. Bulk deletion
requires another review if the set of selected conversations changes.
While the request is pending, the dialog shows **Deleting…**. **Close** dismisses
the desktop dialog without cancelling the submitted deletion.

Mission Control → **Model Configuration** offers Provider Defaults, smTO Recommended and Custom profiles. Each parameter exposes Provider Default or User Configured, with expandable behavior, recommendations and warnings. Search matches parameter names, canonical keys, provider tags and help. Open **Resolved settings** to see exactly which values will be configured or omitted. These generation choices affect normal agent execution; Task Contract generation and recovery keep their own configuration. See [Configuration and storage](09-configuration-storage.md) for persistence and resume behavior.

The [Model Configuration guide](25-model-configuration.md) explains profile changes,
provider compatibility and why saved runs keep earlier values. Endpoint and timeout
controls are now in the same section; they retain their existing transport scope.

Saved HTTP connections live in Parameter Store, with an HTTP Connection tab for
public configuration, credentials, selected-Gateway testing and session disconnect.
Settings no longer contains a separate HTTP Connections editor. Metadata, rename,
copy reference and delete use the normal Parameter controls; existing profiles
appear automatically. See the [HTTP guide](architecture/18-http.md).

## Workflows

**Save to workflow** beside a user prompt saves its exact text and execution
settings, including failed and text-only requests. Unsent drafts can also be saved.
Three independent switches optionally copy prior messages, attached inputs and
previous tool results. **More options → Workflows** opens the searchable library
with Edit, Run now, Schedule, History and Delete. Runs use fresh Agent reasoning;
schedules pin the saved revision. See [Workflows](44-workflow-recorder.md).


## Immersive composer and instruction resources

Chat opens in Immersive mode by default, including on fresh installations.
Use the conversation's **Immersive** switch to change that chat's view, or
**Settings → UI Preferences → Immersive mode by default** to change the shared default.
Saved choices are preserved.

**Settings → UI Preferences → Enter action for task replies** chooses what Enter
does in an active task's reply box: **Queue**, **Steer**, or **Steer without interruption**
(the default). Queue waits until the task finishes; Steer interrupts the current
response; Steer without interruption lets the response finish before applying
the update. The choice is saved across browser sessions and devices and updates
open reply boxes in Standard and Immersive views, including mobile Message details.
Shift+Enter adds a new line. The action buttons still select their named action,
and the main composer keeps its existing behavior. Enter continues a finished task;
if a submission is uncertain, Enter retries its original action even after the
default changes.

**Active runs** shows running and waiting work in both Standard and Immersive views.
This includes queued or starting runs, timed and scheduled waits, jobs, and waits
for resources, input, or approval. Finished, stopped, and paused runs are
hidden. Waiting runs keep their status and countdown; completed attempts of an
active task remain hidden.

Immersive mode keeps the brain toggle immediately before Send on desktop and mobile.
It uses the conversation's existing Thinking Default/On/Off setting; an accepted run
keeps its captured setting. Type `/` in the main composer to discover application
commands. Help, status, and command results stay available in Immersive mode.
`/trace` asks you to exit Immersive to view task details.

Type `@` in the main composer, **Steer this run**, or **Continue this conversation**
to select Gateways, files, saved context, artifacts, or Parameter Store references.
This also works inside mobile Message details and with **Queue**. Enter or Tab
selects the highlighted resource without submitting the instruction; Escape dismisses
suggestions. Removable chips beside the input show pending attachments and Gateways.
Each editor keeps its own selections.

A selected Gateway is added to the addressed run's available targets when the
instruction is applied. Its primary Gateway, existing working directories, and
permissions are preserved. Steering applies resources at the next safe processing
boundary; **Steer without interrupting** waits for the current response. Continuations
and queued continuations apply resources before the child's first model step.

Explicit parameter references are captured when the instruction is accepted. Retrying
an instruction or dispatching its queued continuation uses that captured value even
if the Parameter Store changes. New explicit references replace matching saved bindings;
unmentioned bindings carry forward. Unknown references and literal text retain their
existing behavior. Validation errors retain your draft and selections. Cancelling a
pending instruction applies none of its resource changes.
