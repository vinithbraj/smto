/* Presentation only. Canonical history/status and enablement always come from the API. */
(() => {
  "use strict";
  if (window.SMTONotifications) return;
  const RECENT_KEY = "smto.notifications.delivered.v1";
  const RECENT_LIMIT = 500, RECENT_TTL = 7 * 86400000, TOAST_MS = 6500;
  const listeners = new Set(), known = new Set(), pending = new Set(), recent = new Map();
  let snapshot = null, error = "", limit = 100, watermark = -Infinity;
  let request = null, again = false, refreshTimer = null, draining = false;
  let active = null, toastTimer = null, individualToasts = 0, nativeFailed = false;
  let enabled = false, channel = null;
  const host = document.createElement("div");
  host.className = "notification-toast-host";
  host.setAttribute("aria-live", "polite");
  host.setAttribute("aria-atomic", "true");
  document.body.append(host);

  function element(tag, className = "", text = "") {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
  }
  function icon(level = "info") {
    const shapes = {
      info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v1"/>',
      success: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
      warning: '<path d="m12 3 10 18H2L12 3Zm0 6v5m0 3v1"/>',
      error: '<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6m0-6-6 6"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    };
    const safeLevel = Object.hasOwn(shapes, level) ? level : "info";
    const node = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    node.setAttribute("viewBox", "0 0 24 24");
    node.setAttribute("aria-hidden", "true");
    node.classList.add("notification-icon", "notification-level-" + safeLevel);
    node.innerHTML = shapes[safeLevel]; // Fixed application SVGs, never notification content.
    return node;
  }
  const destination = id => id ? "/notifications?notification=" + encodeURIComponent(id) : "/notifications";
  const permission = () => typeof window.Notification !== "function" || !window.isSecureContext
    ? "unsupported" : window.Notification.permission;
  const visible = () => !document.hidden && document.hasFocus();
  const eligible = item => item?.status === "unread" && item.metadata?.notifications_suppressed !== true;
  const record = id => snapshot?.notifications.find(item => item.notification_id === id);

  function emit() {
    const unread = snapshot?.counts?.unread || 0;
    document.querySelectorAll(".notification-bell").forEach(bell => {
      bell.setAttribute("aria-label", unread ? "Notifications, " + unread + " unread notifications" : "Notifications");
      const badge = bell.querySelector(".notification-badge");
      if (badge) { badge.hidden = !unread; badge.textContent = unread > 99 ? "99+" : String(unread); }
    });
    for (const listener of listeners) listener({data: snapshot, error, permission: permission(), enabled, nativeFailed});
  }
  function pruneRecent() {
    const cutoff = Date.now() - RECENT_TTL;
    for (const [id, timestamp] of recent) if (timestamp < cutoff) recent.delete(id);
    if (recent.size > RECENT_LIMIT) {
      const ordered = [...recent].sort((a, b) => b[1] - a[1]);
      recent.clear();
      ordered.slice(0, RECENT_LIMIT).forEach(([id, timestamp]) => recent.set(id, timestamp));
    }
  }
  function readRecent() {
    try {
      const entries = JSON.parse(localStorage.getItem(RECENT_KEY) || "[]");
      if (Array.isArray(entries)) for (const pair of entries.slice(0, RECENT_LIMIT)) {
        if (Array.isArray(pair) && typeof pair[0] === "string" && Number.isFinite(pair[1])) {
          recent.set(pair[0], Math.max(pair[1], recent.get(pair[0]) || 0));
        }
      }
    } catch (_error) { /* Browser storage is optional. */ }
    pruneRecent();
  }
  function remember(ids) {
    readRecent();
    const timestamp = Date.now();
    ids.forEach(id => { recent.set(id, timestamp); pending.delete(id); });
    pruneRecent();
    try { localStorage.setItem(RECENT_KEY, JSON.stringify([...recent])); } catch (_error) {}
    channel?.postMessage({ids, timestamp});
  }
  try {
    channel = new BroadcastChannel("smto.notifications");
    channel.onmessage = ({data}) => {
      if (!Array.isArray(data?.ids) || !Number.isFinite(data.timestamp)) return;
      data.ids.slice(0, RECENT_LIMIT).filter(id => typeof id === "string").forEach(id => {
        recent.set(id, data.timestamp); pending.delete(id);
      });
      pruneRecent();
    };
  } catch (_error) { /* Storage events and stable native tags still coordinate. */ }
  window.addEventListener("storage", event => {
    if (event.key !== RECENT_KEY) return;
    readRecent();
    for (const id of pending) if (recent.has(id)) pending.delete(id);
  });

  function hideToast() {
    clearTimeout(toastTimer);
    host.replaceChildren();
    active = null;
  }
  function showToast(ids, summary = false) {
    const item = record(ids[0]);
    const link = element("a", "notification-toast");
    link.href = destination(summary ? "" : ids[0]);
    const content = element("span", "notification-toast-content");
    content.append(element("strong", "", summary ? ids.length + " more notifications" : item.title || "Notification"));
    content.append(element("span", "", summary ? "View them in Notification Center." :
      window.SMTOErrors.notificationText(item.error_detail) || window.SMTOMarkdown.toText(item.message)));
    link.append(icon(summary ? "bell" : item.level), content);
    active = ids;
    host.replaceChildren(link);
    // Hover or keyboard focus keeps the target available; neither changes read state.
    const arm = () => {
      clearTimeout(toastTimer);
      toastTimer = window.setTimeout(() => { hideToast(); void drain(); }, TOAST_MS);
    };
    link.addEventListener("mouseenter", () => clearTimeout(toastTimer));
    link.addEventListener("focus", () => clearTimeout(toastTimer));
    link.addEventListener("mouseleave", arm);
    link.addEventListener("blur", arm);
    arm();
  }
  async function withDeliveryLock(work) {
    // A short optional mutex closes ordinary read/write races. No leader or heartbeat.
    if (navigator.locks?.request) {
      let acquired = false;
      try {
        return await navigator.locks.request("smto.notification-delivery", () => {
          acquired = true;
          return work();
        });
      } catch (error) {
        if (acquired) throw error;
        // Some restricted contexts expose the API but reject lock requests.
      }
    }
    return work(); // Recent IDs, BroadcastChannel and native tag provide best-effort fallback.
  }
  async function drain() {
    if (draining || !enabled || error) return;
    draining = true;
    try {
      await withDeliveryLock(() => {
        if (!enabled || error) return;
        readRecent();
        for (const id of pending) {
          if (recent.has(id) || !eligible(record(id))) pending.delete(id);
        }
        if (!pending.size) { if (!active) individualToasts = 0; return; }
        if (permission() === "granted" && !nativeFailed) {
          for (const id of [...pending]) {
            const item = record(id);
            try {
              const native = new Notification(window.SMTOBranding.displayName(), {
                body: [item.title, window.SMTOErrors.notificationText(item.error_detail) || window.SMTOMarkdown.toText(item.message)].filter(Boolean).join("\n"), tag: "smto:" + id,
              });
              native.onclick = () => {
                window.focus();
                window.location.assign(destination(id));
                native.close();
              };
              native.onerror = () => {
                // Some browsers expose permission but cannot deliver through this constructor.
                nativeFailed = true;
                recent.delete(id);
                try { localStorage.setItem(RECENT_KEY, JSON.stringify([...recent])); } catch (_error) {}
                pending.add(id); emit(); void drain();
              };
              remember([id]);
            } catch (_error) { nativeFailed = true; emit(); break; }
          }
        }
        if (!pending.size || active || !visible()) return;
        // Three individual slide-ins per burst, then one compact overflow summary.
        const summary = individualToasts >= 3;
        const ids = summary ? [...pending] : [[...pending][0]];
        showToast(ids, summary);
        remember(ids);
        individualToasts = summary ? 0 : individualToasts + 1;
      });
    } finally { draining = false; }
  }

  async function refresh() {
    await window.SMTOReadPriority?.ready;
    clearTimeout(refreshTimer); refreshTimer = null;
    if (request) { again = true; return request; }
    request = (async () => {
      do {
        again = false;
        try {
          const response = await window.SMTOErrors.fetch("/api/agent/notifications?limit=" + limit + "&include_dismissed=true", {cache: "no-store"});
          if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
          const data = await window.SMTOErrors.readJson(response);
          const initial = snapshot === null;
          const items = Array.isArray(data.notifications) ? data.notifications : [];
          const previousWatermark = watermark;
          const arrivals = [];
          for (const item of items) {
            const id = item.notification_id, created = Date.parse(item.created_at);
            if (!id) continue;
            if (!initial && !known.has(id) && created >= previousWatermark && eligible(item)) arrivals.push(item);
            known.add(id);
            if (Number.isFinite(created)) watermark = Math.max(watermark, created);
          }
          while (known.size > 1000) known.delete(known.values().next().value);
          snapshot = {...data, notifications: items}; enabled = data.enabled !== false; error = "";
          if (!enabled) { pending.clear(); hideToast(); individualToasts = 0; }
          else {
            // Initial hydration (including reload) establishes a baseline without alerts.
            arrivals.sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at)).forEach(item => pending.add(item.notification_id));
            for (const id of pending) if (!eligible(record(id))) pending.delete(id);
            if (active && active.every(id => !eligible(record(id)))) hideToast();
          }
          emit();
          await drain();
        } catch (_error) {
          error = "Could not refresh notifications. Your history will return when the connection recovers.";
          emit();
        }
      } while (again);
    })();
    try { await request; } finally { request = null; }
  }
  function invalidate(update) {
    if (update?.topics?.includes("settings.changed") || update?.syncRequired) {
      enabled = false; hideToast(); // Wait for canonical product enablement.
    }
    if (request) { again = true; return; }
    if (refreshTimer === null) refreshTimer = window.setTimeout(refresh, 80);
  }
  async function updateStatus(id, status) {
    const response = await window.SMTOErrors.fetch("/api/agent/notifications/" + encodeURIComponent(id), {
      method: "PATCH", headers: {"Content-Type": "application/json"}, body: JSON.stringify({status}),
    });
    if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
    await refresh();
  }
  window.SMTONotifications = {
    subscribe(listener) { listeners.add(listener); emit(); return () => listeners.delete(listener); },
    refresh, updateStatus, icon, element, destination,
    async loadMore() { limit = Math.min(500, limit + 100); await refresh(); },
    limit: () => limit,
    async markAllRead() {
      const response = await window.SMTOErrors.fetch("/api/agent/notifications/mark-all-read", {method: "POST"});
      if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
      await refresh();
    },
    async requestPermission() {
      // Called only by the Notification Center's explicit Enable button.
      if (permission() === "default") {
        try { await Notification.requestPermission(); } catch (_error) { nativeFailed = true; }
      }
      emit(); void drain();
    },
  };
  window.SMTOUiUpdates.subscribe(["notifications.changed", "settings.changed"], invalidate);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) hideToast();
    else invalidate();
  });
  window.addEventListener("focus", () => { emit(); invalidate(); });
  window.addEventListener("online", invalidate);
  window.addEventListener("pagehide", hideToast);
  readRecent();
  void refresh();
})();
