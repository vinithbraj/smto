/* Task wall-clock proportions. One clock and one accessible details popup for all footers. */
(() => {
  "use strict";
  if (window.SMTOTaskTiming) return;
  const categories = [["waiting", "Waiting"], ["active", "Active"], ["thinking", "Thinking"],
    ["execution", "Execution"], ["overlap", "Thinking + execution"], ["unmeasured", "Unmeasured"]];
  // Stable ties retain the category order while larger durations lead every view.
  const orderedCategories = value => [...categories].sort(([a], [b]) =>
    (value?.durations_ms[b] || 0) - (value?.durations_ms[a] || 0));
  const finite = value => typeof value === "number" && Number.isFinite(value) && value >= 0;
  const views = new Set(), saved = new Map();
  let scope = null, timer = null, queued = false, popup = null, active = null, pinned = false;
  const duration = ms => {
    const seconds = Math.floor(ms / 1000);
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    const hours = Math.floor(seconds / 3600), minutes = Math.floor(seconds / 60) % 60;
    return hours < 24 ? `${hours}h ${minutes}m` : `${Math.floor(hours / 24)}d ${hours % 24}h ${minutes}m`;
  };
  function select(cid) {
    if (scope === cid) return;
    scope = cid; saved.clear(); close();
  }
  function remember(id, value) {
    if (!id || value?.version !== 1 || !finite(value.total_ms) || !finite(value.observed_at_ms)
        || !categories.every(([key]) => finite(value.durations_ms?.[key]))) return;
    const previous = saved.get(id);
    if (previous && previous.value.observed_at_ms >= value.observed_at_ms) return;
    saved.set(id, {value, received: performance.now()});
  }
  function observe(data, cid) {
    select(cid);
    for (const [id, value] of Object.entries(data.task_timings_by_id || {})) remember(id, value);
    for (const [id, task] of Object.entries(data.lane?.tasks_by_id || {})) remember(id, task.task_timing);
    window.dispatchEvent(new Event("task-timing-updated"));
  }
  function values(record) {
    if (!record) return null;
    const value = record.value, times = {...value.durations_ms};
    const delta = value.running && Object.hasOwn(times, value.current_category)
      ? Math.max(0, performance.now() - record.received) : 0;
    if (delta) times[value.current_category] += delta;
    return {...value, total_ms: value.total_ms + delta, durations_ms: times,
      incomplete: value.incomplete || times.unmeasured > 0};
  }
  function close() {
    if (active) {
      active.root.setAttribute("aria-expanded", "false");
      active.root.removeAttribute("aria-describedby");
    }
    if (popup) popup.hidden = true;
    active = null; pinned = false;
  }
  function details(view) {
    if (!popup) {
      popup = document.createElement("div"); popup.id = "task-timing-details";
      popup.className = "task-timing-details"; popup.setAttribute("role", "tooltip");
      document.body.append(popup);
    }
    popup.replaceChildren();
    const value = values(view.record);
    const heading = document.createElement("div"); heading.className = "task-timing-details-heading";
    heading.textContent = value ? `Total runtime · ${duration(value.total_ms)}` : "Task lifetime timing unavailable";
    popup.append(heading);
    if (value) for (const [key, label] of orderedCategories(value)) {
      if (key === "unmeasured" && !value.durations_ms[key]) continue;
      const row = document.createElement("div"); row.className = "task-timing-detail";
      row.dataset.category = key;
      const swatch = document.createElement("span"); swatch.className = `task-timing-swatch task-timing-${key}`;
      swatch.setAttribute("aria-hidden", "true");
      const name = document.createElement("span"); name.textContent = label;
      const amount = document.createElement("span");
      const ms = value.durations_ms[key], percent = value.total_ms ? ms / value.total_ms * 100 : 0;
      amount.textContent = `${ms > 0 && ms < 1000 ? "<1s" : duration(ms)} · ${percent.toFixed(1)}%`;
      row.append(swatch, name, amount); popup.append(row);
    }
    const note = document.createElement("p");
    note.textContent = "Full task lifetime, including queues, pauses and replies. Active is other runtime work. "
      + "Thinking includes model response generation. Simultaneous thinking and execution are counted once."
      + (value?.incomplete ? " Some timing records are missing." : "");
    popup.append(note); popup.hidden = false;
    const box = view.root.getBoundingClientRect(), bounds = popup.getBoundingClientRect();
    popup.style.left = `${Math.max(8, Math.min(box.right - bounds.width, innerWidth - bounds.width - 8))}px`;
    popup.style.top = `${Math.max(8, box.top >= bounds.height + 8 ? box.top - bounds.height - 6
      : Math.min(box.bottom + 6, innerHeight - bounds.height - 8))}px`;
    view.root.setAttribute("aria-expanded", "true"); view.root.setAttribute("aria-describedby", popup.id);
  }
  function show(view, pin = false) {
    if (active !== view) close();
    active = view; pinned ||= pin; details(view);
  }
  function tick() {
    clearTimeout(timer); timer = null;
    let running = false;
    for (const view of views) {
      if (!view.root.isConnected || view.root.closest("[hidden]")) continue;
      const value = values(view.record);
      view.paint(value); running ||= value?.running;
    }
    if (active) {
      if (!active.root.isConnected || active.root.closest("[hidden]") || document.hidden) close();
      else details(active);
    }
    if (running && !document.hidden) timer = setTimeout(tick, 1000);
  }
  function refresh() {
    if (queued) return;
    queued = true; queueMicrotask(() => { queued = false; tick(); });
  }
  function create(durationLabel) {
    const root = document.createElement("button"); root.type = "button";
    root.className = "task-timing-strip"; root.setAttribute("aria-expanded", "false");
    const track = document.createElement("span"); track.className = "task-timing-track";
    track.setAttribute("aria-hidden", "true"); root.append(track);
    const segments = new Map(categories.map(([key]) => {
      const span = document.createElement("span"); span.className = `task-timing-segment task-timing-${key}`;
      span.dataset.category = key; span.hidden = true; track.append(span); return [key, span];
    }));
    const view = {root, record: null,
      update(cid, id, value) {
        select(cid); remember(id, value); view.record = saved.get(id) || null; refresh();
      },
      paint(value) {
        const ordered = orderedCategories(value);
        let label = "Task runtime breakdown unavailable";
        if (value) {
          const text = `${duration(value.total_ms)}${value.incomplete ? " · partial" : ""}`;
          if (durationLabel.textContent !== text) durationLabel.textContent = text;
          durationLabel.title = "Full task lifetime, including queueing, pauses and waiting for replies.";
          label = `Task runtime ${duration(value.total_ms)}. ` + ordered
            .map(([key, name]) => `${name}: ${duration(value.durations_ms[key])}`).join(". ");
        }
        for (const [index, [key]] of ordered.entries()) {
          const span = segments.get(key);
          if (track.children[index] !== span) track.insertBefore(span, track.children[index]);
          const amount = value?.durations_ms[key] || 0;
          span.hidden = !amount;
          const width = value?.total_ms ? `${amount / value.total_ms * 100}%` : "0%";
          if (span.style.width !== width) span.style.width = width;
        }
        if (root.getAttribute("aria-label") !== label) root.setAttribute("aria-label", label);
      },
      destroy() { views.delete(view); if (active === view) close(); root.remove(); },
    };
    root.addEventListener("pointerenter", e => { if (e.pointerType !== "touch") show(view); });
    root.addEventListener("pointerleave", () => { if (active === view && !pinned && document.activeElement !== root) close(); });
    root.addEventListener("focus", () => show(view));
    root.addEventListener("blur", () => { if (active === view) close(); });
    root.addEventListener("click", e => {
      e.preventDefault(); e.stopPropagation();
      if (active === view && pinned) close(); else show(view, true);
    });
    root.addEventListener("keydown", e => {
      if (["Enter", " ", "Escape"].includes(e.key)) e.stopPropagation();
      if (e.key === "Escape") { e.preventDefault(); close(); }
    });
    views.add(view); return view;
  }
  document.addEventListener("pointerdown", e => {
    if (active && !active.root.contains(e.target) && !popup?.contains(e.target)) close();
  });
  document.addEventListener("visibilitychange", refresh);
  window.addEventListener("resize", () => { if (active) details(active); });
  window.addEventListener("scroll", () => { if (active) details(active); }, true);
  window.addEventListener("pagehide", () => { clearTimeout(timer); close(); });
  window.addEventListener("pageshow", refresh);
  window.SMTOTaskTiming = {create, observe, select, refresh, values, duration};
})();
