/**
 * @file src/agent_runtime/api/static/agent_ui/mobile/api.js
 * @brief Supply mobile presentation state, scoped draft persistence and JSON transport.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities: Share the mobile page's view state, inert DOM/error helpers and
 * read client; preserve unsent text and capability selections across navigation.
 * Boundaries: app.js owns navigation and submission. Server endpoints validate task,
 * permission and capability authority; local draft choices are only composer input.
 * Lifecycle: Module initialization loads the mobile error presenter and one page-lived
 * capability-draft listener. Input debounces storage writes; navigation/page callbacks
 * flush captured drafts and accepted submissions consume only matching text.
 * State: One mutable presentation object, one pending draft/timer and namespaced
 * localStorage. Pending text keeps its original conversation scope through navigation;
 * storage errors are tolerated and restored capability choices are shape-checked.
 * Security: Text uses textContent. Links permit HTTP(S); rendered images additionally
 * require existing same-origin file/artifact routes. JSON transport keeps same-origin
 * credentials; storage is browser-local persistence, not a secret or approval store.
 * Collaborators: errors.js owns transport/error rendering; conversation_snapshot.js
 * coalesces eligible reads; overlays.js loads on demand for notice details.
 * Public surface: state/storage, DOM and URL helpers, api, draft and appearance helpers.
 * Custom headers, cancellation signals and writes bypass shared read coalescing.
 * @see src/agent_runtime/api/static/agent_ui/mobile/app.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/errors.js
 * @see src/agent_runtime/api/static/agent_ui/conversation_snapshot.js
 * @see src/agent_runtime/api/static/agent_ui/mobile/overlays.js
 */
import "./errors.js?v=20261018-loading";
// Presentation state only. Tasks, permissions and execution are owned by the server.
const prefix = "smto.agentUi.mobile.";
export const storage = {
  /** Treat missing, null, malformed or inaccessible browser values as the caller's fallback. */
  get(key, fallback = null) {
    try {
      return JSON.parse(localStorage.getItem(prefix + key)) ?? fallback;
    } catch {
      return fallback;
    }
  },
  /** Persist JSON under the mobile namespace; null removes a value without failing the UI. */
  set(key, value) {
    try {
      value == null
        ? localStorage.removeItem(prefix + key)
        : localStorage.setItem(prefix + key, JSON.stringify(value));
    } catch {
      /* Storage can be unavailable. */
    }
  },
};
/** Mutable page projection; request/task authority remains with the server. */
export const state = {
  conversationId: null,
  requestId: null,
  generation: 0,
  navigation: null,
  run: null,
  lane: null,
  chat: null,
  submitting: false,
  loading: false,
  steering: false,
  refs: [],
  config: null,
  choices: {},
  following: true,
  settings: window.__SMTO_MOBILE_BOOT__ || {},
};
/** Resolve a selector in the page shell; callers own the selected element's lifetime. */
export const $ = (selector) => document.querySelector(selector);
/** Build an element with inert text so API/draft content never becomes HTML markup. */
export function node(tag, text, className = "") {
  const element = document.createElement(tag);
  if (text != null) element.textContent = String(text);
  if (className) element.className = className;
  return element;
}
/** Serialize clicks on this button while its action runs; cancellation stays silent. */
export function button(label, action, className = "") {
  const element = node("button", label, className);
  element.type = "button";
  element.addEventListener("click", async () => {
    if (element.disabled) return;
    element.disabled = true;
    try {
      await action(element);
    } catch (error) {
      if (error.name !== "AbortError") notice(error);
    } finally {
      element.disabled = false;
    }
  });
  return element;
}
/** Present a dismissible notice and optional sheet detail without replacing the page view. */
export function notice(message = "") {
  const host = $("#notice");
  if (!message) { host.hidden = true; host.replaceChildren(); return; }
  const rendered = window.SMTOErrors.render(message?.error_detail || message, {profile: "compact"});
  const summary = node("span", message?.error_detail || message?.error_ref ? rendered.textContent : message?.message || message);
  summary.id = "notice-summary";
  const details = button("Details", async () => {
    const feedback = window.SMTOBusy?.action("Loading notice…");
    try {
    const {openSheet} = await import("./overlays.js?v=20261018-loading");
    const body = openSheet("Notice");
    if (message?.error_detail || message?.error_ref) window.SMTOErrors.present(body, message, {profile: "full"});
    else body.append(node("p", message?.message || message));
    } finally { feedback?.finish(); }
  });
  const dismiss = button("Dismiss", () => { host.hidden = true; });
  host.replaceChildren(summary, details, dismiss); host.hidden = false;
  const sheet = $(".sheet-body");
  if (sheet) {
    let inline = sheet.querySelector("[data-sheet-notice]");
    if (!inline) { inline = node("p", null, "error"); inline.dataset.sheetNotice = ""; inline.setAttribute("role", "status"); sheet.prepend(inline); }
    if (message?.error_detail || message?.error_ref) window.SMTOErrors.present(inline, message);
    else inline.textContent = message?.message || message;
  }
}
window.addEventListener("smto:background-notice", ({detail}) => {
  // The standard notice lives above the composer and already provides Dismiss.
  if ($("#notice")?.hidden && detail?.message) notice(detail.message);
});
/** Update the shell's transport-status slot; an empty message hides it. */
export function connection(message = "") {
  $("#connection").textContent = message;
  $("#connection").hidden = !message;
}
/** Encode one route component; callers retain responsibility for the surrounding path. */
export const encode = (value) => encodeURIComponent(value);
/** Resolve a relative Agent endpoint without changing its query or field spelling. */
export function agentPath(path) {
  return `/api/agent/${path}`;
}
/** Coalesce plain GETs by resolved path; caller-bound reads and mutations retain isolation. */
export function api(path, options = {}) {
  return (!options.method || options.method === "GET") && !options.signal && !options.headers
    ? window.SMTOConversationSnapshot.coalesceRead(`mobile:${path.startsWith('/') ? path : agentPath(path)}`, () => readJson(path, options)) : readJson(path, options);
}
/** Fetch same-origin JSON with no cache; preserve Blob bodies and structured API errors. */
async function readJson(
  path,
  { method = "GET", body, signal, headers = {} } = {},
) {
  const response = await window.SMTOErrors.fetch(path.startsWith("/") ? path : agentPath(path), {
    method,
    cache: "no-store",
    credentials: "same-origin",
    signal,
    headers: {
      Accept: "application/json",
      ...(body !== undefined && !(body instanceof Blob)
        ? { "Content-Type": "application/json" }
        : {}),
      ...headers,
    },
    ...(body === undefined
      ? {}
      : { body: body instanceof Blob ? body : JSON.stringify(body) }),
  });
  let payload;
  try {
    payload = await window.SMTOErrors.readJson(response);
  } catch {
    payload = {};
  }
  if (!response.ok) {
    const detail = payload.detail;
    const error = window.SMTOErrors.fromPayload(payload, response.status);
    error.detail = detail;
    throw error;
  }
  return payload;
}
/** Recognize the terminal labels consumed by mobile conversation rendering. */
export const terminal = (status) =>
  ["completed", "answered", "failed", "cancelled", "interrupted"].includes(
    status,
  );
/** Prefer server-projected visible outcomes over lower-level effective/transport statuses. */
export const runStatus = (run) =>
  run?.user_visible_status ||
  run?.outcome ||
  run?.native_profile?.final_status ||
  run?.response_metrics?.native_outcome ||
  run?.effective_status ||
  run?.status ||
  "";
let draftTimer = 0, pendingDraft = null;
/** Capture the current conversation with input so a later navigation cannot retarget it. */
export function scheduleDraft(value) {
  pendingDraft = {value, scope: state.conversationId};
  clearTimeout(draftTimer);
  draftTimer = setTimeout(flushDraft, 250);
}
/** Cancel the debounce and persist its captured value/scope once, if input is pending. */
export function flushDraft() {
  clearTimeout(draftTimer); draftTimer = 0;
  if (!pendingDraft) return;
  const {value, scope} = pendingDraft; pendingDraft = null;
  writeDraft(value, scope);
}
/** Bound saved text to 24,000 code units; save current capability choices only for this scope. */
function writeDraft(value, scope) {
  const key = `draft.${scope || "new"}`;
  const text = value ? value.slice(0, 24000) : "";
  storage.set(key, text || null);
  if (scope === state.conversationId) storage.set(`capability-draft.${scope || "new"}`, {
    policy: state.choices.capability_policy || null, selection: state.choices.capability_selection || null,
  });
}
/** Restore cloned, shape-checked selection data into the composer, never execution authority. */
export function restoreCapabilityDraft(scope) {
  const saved = storage.get(`capability-draft.${scope || "new"}`);
  const selection = saved?.selection;
  if (selection && selection.schema_version === 1 && ["automatic", "manual"].includes(selection.mode)
      && ["always_skill_ids", "always_tool_ids"].every(key => Array.isArray(selection[key])
        && selection[key].length <= 128 && selection[key].every(id => typeof id === "string" && /^[a-z][a-z0-9_.]{0,255}$/.test(id)))) {
    state.choices.capability_selection = structuredClone(selection);
    if (saved.policy?.schema_version === 1) state.choices.capability_policy = structuredClone(saved.policy);
  }
}
window.addEventListener("capability-selection-draft-changed", () => writeDraft(document.querySelector("#message")?.value || "", state.conversationId));
/** Save lifecycle input now, preserving any older pending draft from a different conversation. */
export function saveDraft(value) {
  // A lifecycle flush supersedes pending input in this scope, never a destination draft.
  if (pendingDraft?.scope === state.conversationId) { clearTimeout(draftTimer); pendingDraft = null; }
  else flushDraft();
  writeDraft(value, state.conversationId);
}
/** Consume accepted text only when still equal; preserve edits typed during submission. */
export function consumeDraft(value, scope) {
  if (pendingDraft?.scope === scope && pendingDraft.value === value) {
    clearTimeout(draftTimer); pendingDraft = null;
  }
  const key = `draft.${scope || "new"}`, saved = storage.get(key);
  if (saved === value || saved?.text === value) storage.set(key, null);
  storage.set(`capability-draft.${scope || "new"}`, null);
}
/** Apply an explicit stored light/dark choice or return theme selection to system CSS. */
export function applyAppearance() {
  const choice = storage.get("appearance", "system");
  if (choice === "light" || choice === "dark")
    document.documentElement.dataset.theme = choice;
  else delete document.documentElement.dataset.theme;
  window.SMTOAppearance.apply(state.settings);
}
/** Reject non-web links and image sources outside the existing same-origin file routes. */
export function safeUrl(value, { image = false } = {}) {
  try {
    const url = new URL(value, location.origin);
    if (
      !["http:", "https:"].includes(url.protocol)
    )
      return null;
    // Render images only through existing same-origin artifact/file routes.
    if (
      image &&
      (url.origin !== location.origin ||
        !/^\/api\/agent\/(file|artifacts\/)/.test(url.pathname))
    )
      return null;
    return url.href;
  } catch {
    return null;
  }
}
