---
id: historical-v54-architecture-gmail-integration
title: Historical V54 - Gmail Integration Architecture
kind: legacy
tags: [architecture, gmail, mail, oauth, sync, cache, safety]
summary: How Gmail routes, services, stores, sync, capability planning, and confirmation gates fit into the SMTO runtime.
order: 11
---

> Historical reference. See the current V55 architecture guide before using this material.

# Gmail Integration Architecture

Gmail is an integration subsystem, not a replacement execution path. It keeps
the core SMTO boundary intact: the LLM proposes meaning, the runtime
validates typed contracts and safety, and a dedicated service touches the
external system.

```mermaid
flowchart TD
    UI[Agent UI Gmail drawer and Mail workspace] --> R[FastAPI Gmail routes]
    R --> S[GmailService]
    S --> DB[(agent_gmail.db)]
    S --> G[Google Gmail API]
    R --> C[gmail.agent capability]
    C --> L[LLM structured calls]
    C --> V[Runtime validation and confirmation]
    V --> S
    S --> SYNC[GmailSyncManager]
    SYNC --> DB
```

## Components

| Component | Responsibility |
| --- | --- |
| `route_groups/gmail.py` | Browser API routes, request payload models, HTTP error mapping, prompt helpers, and account-aware route calls. |
| `gmail/service.py` | OAuth, Gmail REST calls, local cache coordination, draft/send/mutation operations, prompt search helpers, and account resolution. |
| `gmail/store.py` | SQLite schema, account records, message metadata, labels, attachments, sender inventory, drafts, sync state, and events. |
| `gmail/sync.py` | Background polling, manual sync, cancellation, stale state recovery, and label backfill. |
| `capabilities/gmail.py` | LLM-owned Gmail intent selection, semantic matching, analysis reports, mutation previews, unsubscribe handling, and confirmation replay. |
| Agent UI static files | Gmail drawer, Mail workspace, account selector, labels, thread detail, composer, reminder popups, and queue/ledger panels. |

## Data Model

The Gmail store is local SQLite state. It stores:

- connected accounts and OAuth tokens;
- browser-safe account summaries;
- cached message metadata;
- cached labels and attachment summaries;
- normalized senders for sender search and reports;
- draft metadata;
- per-account sync state;
- bounded sync events.

`account_id` scopes cache rows and sync state. User-facing payloads can use
`account_ref`, which the service resolves against account id, email, display
name, nickname, and primary-account state.

## Request Flow

```mermaid
sequenceDiagram
    participant UI as Mail UI
    participant API as Gmail Routes
    participant Cap as gmail.agent
    participant Runtime
    participant Service as GmailService
    participant Google as Gmail API
    UI->>API: Prompt or selected-thread action
    API->>Cap: Structured Gmail request context
    Cap->>Runtime: Typed intent, selector, operation
    Runtime->>Runtime: Validate account, scope, risk, confirmation
    Runtime->>Service: Read, draft, preview, or confirmed mutation
    Service->>Google: Gmail REST call when needed
    Google-->>Service: Gmail response
    Service-->>API: Safe response payload
    API-->>UI: Result, preview, draft, or confirmation state
```

Read-only flows can answer from cache or bounded fetched thread context.
Mutation flows create previews and confirmation payloads before execution.
Sending a draft is a mutation.

## Sync Flow

The sync manager warms the local cache without making the cache trusted
authority. Gmail remains the source for message state. The cache exists to make
the UI responsive, support sender and label navigation, and bound model context.

Sync behavior:

- manual sync can target one account or all connected accounts;
- background sync runs only when enabled and connected accounts exist;
- sync state is per account;
- stale in-flight state is reset on backend startup;
- label backfill can be queued when a UI view needs metadata that is not warm;
- Pub/Sub helpers decode Gmail notifications when optional watch settings are
  configured.

## Safety And Confirmation

The capability treats broad email changes as high-impact because they alter
real mail state. The preview and confirmation payload should include enough
evidence for the user to understand the account, operation, selected messages,
batch size, and likely effect.

The LLM may classify, summarize, draft, and select likely matches. It does not
own:

- OAuth token storage;
- account trust;
- mutation approval;
- Gmail API execution;
- cache schema migration;
- final send authority.

Current runtime validation, account resolution, Gmail service errors, and user
approval remain authoritative even when a semantic match looks confident.

## Maintainer Notes

When adding Gmail behavior:

- keep request/response models strict with `extra="forbid"`;
- accept `account_ref` on new account-scoped routes and payloads;
- keep full message bodies bounded and selected-context only;
- prefer previews over direct mutations;
- include sync/cache state in user-facing status rather than hiding delays;
- update [Gmail Integration](../21-gmail-integration.md) and
  [System Surfaces And API Reference](../17-system-surfaces-api-reference.md)
  whenever routes or safety behavior change.
