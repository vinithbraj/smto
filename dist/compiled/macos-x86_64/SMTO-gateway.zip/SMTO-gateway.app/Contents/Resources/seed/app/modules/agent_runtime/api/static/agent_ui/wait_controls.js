/* Timed-wait controls shared by desktop and mobile. Countdown ticks keep this DOM mounted. */
(() => {
  "use strict";
  function create({requestId, submit, refresh, accept, notify, timeoutMs = 10000}) {
    const root = document.createElement("span");
    root.className = "wait-controls"; root.hidden = true;
    root.setAttribute("role", "group"); root.setAttribute("aria-label", "Adjust timed wait");
    const button = (text, label) => {
      const item = document.createElement("button"); item.type = "button";
      item.textContent = text; item.title = label; item.setAttribute("aria-label", label);
      return item;
    };
    const minus = button("−", "Subtract time"), plus = button("+", "Add time");
    const wake = button("Wake now", "Wake now");
    const amount = document.createElement("input");
    amount.type = "number"; amount.min = "1"; amount.step = "1"; amount.value = "1";
    amount.required = true; amount.inputMode = "numeric"; amount.setAttribute("aria-label", "Time adjustment amount");
    const unit = document.createElement("select"); unit.setAttribute("aria-label", "Time adjustment unit");
    for (const [value, label] of [[1, "seconds"], [60, "minutes"], [3600, "hours"]]) {
      const option = document.createElement("option"); option.value = value; option.textContent = label;
      unit.append(option);
    }
    unit.value = "60";
    const retry = button("Refresh wait", "Refresh wait before trying again"); retry.hidden = true;
    const message = document.createElement("span"); message.className = "wait-control-message";
    message.setAttribute("role", "status"); message.hidden = true;
    root.append(minus, amount, unit, plus, wake, retry, message);
    let state = null, busy = false, blocked = false;
    const eligible = () => state?.status === "waiting_event" && state.waitTiming?.kind === "time" && state.waitControl?.token
      && !state.stopping && !state.pausing && !state.resuming;
    function render() {
      root.hidden = !eligible();
      for (const item of [minus, plus, wake, amount, unit]) item.disabled = busy || blocked;
      root.setAttribute("aria-busy", String(busy));
      retry.hidden = !blocked; retry.disabled = busy;
    }
    async function request(operation) {
      const controller = new AbortController();
      let timer;
      try {
        return await Promise.race([
          Promise.resolve().then(() => operation(controller.signal)),
          new Promise((_, reject) => {
            timer = setTimeout(() => {
              reject(new Error("The wait request took too long. Refresh the wait before trying again."));
              controller.abort();
            }, timeoutMs);
          }),
        ]);
      } finally { clearTimeout(timer); }
    }
    function accepted(snapshot) {
      if (snapshot?.request_id !== requestId || !Number.isFinite(snapshot.state_revision))
        throw new Error("Could not confirm the current wait.");
      accept(snapshot);
    }
    async function reconcile() {
      blocked = true;
      try {
        accepted(await request(signal => refresh(requestId, signal)));
        blocked = false;
      } catch { /* An uncertain write must be reconciled before another adjustment. */ }
      message.textContent = blocked ? "Could not refresh this wait. Refresh before trying again." : "";
      message.hidden = !blocked;
      return !blocked;
    }
    async function send(action, sign = 0) {
    const busyFeedback = window.SMTOBusy?.begin({host: root, label: "Updating task wait…"});
    try {
      if (busy || blocked || !eligible()) return;
      let delta;
      if (action === "adjust") {
        delta = amount.valueAsNumber * Number(unit.value);
        amount.setCustomValidity(Number.isSafeInteger(amount.valueAsNumber) && amount.valueAsNumber > 0
          && Number.isSafeInteger(delta) ? "" : "Enter a positive whole number.");
        if (!amount.reportValidity()) return;
      }
      const payload = {action, expected_wait_token: state.waitControl.token,
        ...(action === "adjust" ? {delta_seconds: sign * delta} : {})};
      busy = true; message.textContent = "Updating wait…"; message.hidden = false; render();
      try {
        // The mutation returns the authoritative deadline and token. A busy or
        // stalled conversation read must not hold these controls disabled.
        accepted(await request(signal => submit(requestId, payload, signal)));
        blocked = false; message.textContent = ""; message.hidden = true;
      } catch (error) {
        // A failed POST may have committed. Read this run once; never replay it.
        try { notify(error); } finally { await reconcile(); }
      } finally {
        busy = false; render();
      }

    } finally { busyFeedback?.finish(); }
  }
    amount.addEventListener("input", () => amount.setCustomValidity(""));
    minus.addEventListener("click", () => void send("adjust", -1));
    plus.addEventListener("click", () => void send("adjust", 1));
    wake.addEventListener("click", () => void send("wake"));
    retry.addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Refreshing task wait…", retry);
        try {
      busy = true; render();
      try { await reconcile(); } finally { busy = false; render(); }

        } finally { busyFeedback?.finish(); }
      });
    return {root, update(value) { state = value; render(); }};
  }
  window.SMTOWaitControls = {create};
})();
