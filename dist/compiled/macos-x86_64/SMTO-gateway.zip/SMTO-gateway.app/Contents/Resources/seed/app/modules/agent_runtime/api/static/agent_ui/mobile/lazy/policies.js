import { api, state, node, button, encode } from "../api.js?v=20261018-loading";
import { openSheet } from "../overlays.js?v=20261018-loading";

export async function open(kind, hooks, back, editingScope = "prompt") {
  const title = kind === "permissions" ? "Permissions" : "Capabilities",
    body = openSheet(title, { back }),
    cid = state.conversationId,
    generation = state.generation;
  const busyFeedback = window.SMTOBusy?.begin({host: body, label: "Loading policy…"});
  try {
  const query = cid ? `?conversation_id=${encode(cid)}` : "";
  const effective = await api(`${kind}/effective${query}`);
  if (!body.isConnected || generation !== state.generation) return;
  const key =
    kind === "permissions" ? "permission_policy" : "capability_policy";
  const view = effective.at_scope?.[editingScope] || effective;
  const selected = structuredClone(
    (editingScope === "prompt" && state.choices[key]) || view.policy || {},
  );
  const selection = structuredClone((editingScope === "prompt" && state.choices.capability_selection) || view.selection ||
    {schema_version: 1, mode: "automatic", always_skill_ids: [], always_tool_ids: []});
  body.append(
    node("p", `Effective scope: ${effective.source || "inherited"}`, "muted"),
  );
  const scope = node("select");
  scope.setAttribute("aria-label", "Policy scope");
  for (const [value, label] of [
    ["prompt", "Next message"],
    ...(cid ? [["conversation", "This conversation"]] : []),
    ...(kind === "capabilities" ? [["global", "Global"]] : []),
  ]) {
    const option = node("option", label);
    option.value = value;
    scope.append(option);
  }
  body.append(scope);
  scope.value = editingScope;
  scope.onchange = () => open(kind, hooks, back, scope.value);
  if (kind === "permissions") {
    const choices = node("div");
    for (const [value, label] of [
      ["manual", "Ask before actions"],
      ["full_access", "Allow actions"],
      ["deny", "Deny actions"],
    ]) {
      const row = node("label"),
        input = node("input");
      input.type = "radio";
      input.name = "permission-mode";
      input.value = value;
      input.checked = selected.mode === value;
      input.onchange = () => {
        selected.mode = value;
      };
      row.append(input, node("span", label));
      choices.append(row);
    }
    body.append(choices);
    if (selected.mode === "custom")
      body.append(
        node(
          "p",
          "Custom rules are retained. Choose a preset only if you want to change it.",
          "muted",
        ),
      );
  } else {
    const automaticLabel = node("label"), automatic = node("input");
    automatic.type = "checkbox"; automatic.className = "mission-switch"; automatic.setAttribute("role", "switch");
    automatic.checked = selection.mode === "automatic";
    automaticLabel.append(automatic, node("span", "Automatic Capability Selection")); body.append(automaticLabel);
    body.append(node("p", "Auto: eligible · Always: included in each selection · Never: outside permitted capabilities.", "muted"));
    const modeControls = [];
    automatic.onchange = () => {
      selection.mode = automatic.checked ? "automatic" : "manual";
      for (const [manual, auto] of modeControls) { manual.hidden = automatic.checked; auto.hidden = !automatic.checked; }
    };
    const catalogQuery = new URLSearchParams();
    if (state.choices.gateway_id) catalogQuery.set("gateway_id", state.choices.gateway_id);
    if (cid) catalogQuery.set("conversation_id", cid);
    const catalog = await api(
      `capabilities/catalog${catalogQuery.size ? `?${catalogQuery}` : ""}`,
    );
    if (!body.isConnected || generation !== state.generation) return;
    selected.excluded_skill_ids ||= [];
    // Effective policy owns defaults; explicit saved selections stay explicit.
    selected.enabled_skill_ids ||= (catalog.skills || [])
      .filter((skill) => !selected.excluded_skill_ids.includes(skill.skill_id))
      .map((skill) => skill.skill_id);
    for (const skill of catalog.skills || []) {
      if (skill.always_enabled) {
        const row = node("div", null, "capability-policy-row"); row.dataset.rule = skill.skill_id;
        row.append(node("strong", skill.display_name || skill.skill_id),
          node("small", "Built in · Always enabled", "muted"));
        if (!skill.available) row.append(node("small", `Unavailable: ${skill.reason || "Not currently supported"}`, "muted"));
        body.append(row); continue;
      }
      const row = node("div", null, "capability-policy-row"),
        label = node("label"),
        enabled = node("input");
      row.dataset.rule = skill.skill_id;
      enabled.type = "checkbox";
      enabled.className = "mission-switch";
      enabled.setAttribute("role", "switch");
      enabled.checked = (selected.enabled_skill_ids.includes(skill.skill_id)
        || (selected.preferred_skill_ids || []).includes(skill.skill_id))
        && !selected.excluded_skill_ids.includes(skill.skill_id);
      label.append(enabled, node("span", skill.display_name || skill.skill_id));
      row.append(label);
      body.append(row);
      enabled.onchange = () => {
        selected.enabled_skill_ids = selected.enabled_skill_ids.filter(
          (id) => id !== skill.skill_id,
        );
        if (enabled.checked) selected.enabled_skill_ids.push(skill.skill_id);
        selected.excluded_skill_ids = selected.excluded_skill_ids.filter(
          (id) => id !== skill.skill_id,
        );
        if (!enabled.checked) selected.excluded_skill_ids.push(skill.skill_id);
        selected.preferred_skill_ids = (
          selected.preferred_skill_ids || []
        ).filter((id) => !selected.excluded_skill_ids.includes(id));
        if (!enabled.checked) {
          selection.always_skill_ids = selection.always_skill_ids.filter(id => id !== skill.skill_id);
          const owned = new Set((skill.tools || []).map(tool => tool.tool_id));
          selection.always_tool_ids = selection.always_tool_ids.filter(id => !owned.has(id));
          for (const key of ["enabled_tool_ids", "preferred_tool_ids"]) selected[key] = (selected[key] || []).filter(id => !owned.has(id));
        }
        renderRouting();
      };
      const routing = node("div", null, "capability-segments");
      routing.setAttribute("role", "group");
      routing.setAttribute("aria-label", `${skill.display_name || skill.skill_id} selection`);
      const renderRouting = () => {
        const value = enabled.checked ? selection.always_skill_ids.includes(skill.skill_id) ? "always" : "auto" : "never";
        for (const control of routing.children) control.setAttribute("aria-pressed", String(control.dataset.selection === value));
      };
      for (const [value, text] of [["auto", "Auto"], ["always", "Always"], ["never", "Never"]]) {
        const control = button(text, () => {
          enabled.checked = value !== "never"; enabled.onchange();
          selection.always_skill_ids = selection.always_skill_ids.filter(id => id !== skill.skill_id);
          if (value === "always") selection.always_skill_ids.push(skill.skill_id);
          renderRouting();
        });
        control.dataset.selection = value;
        control.setAttribute("aria-label", `${text} ${skill.display_name || skill.skill_id}`);
        routing.append(control);
      }
      renderRouting();
      enabled.hidden = automatic.checked; routing.hidden = !automatic.checked;
      modeControls.push([enabled, routing]); row.append(routing);
      if (!skill.available)
        row.append(
          node("p", skill.reason || "Currently unavailable", "muted"),
        );
    }
    if (catalog.runtime_controls?.length) {
      const controls = node("details", null, "muted runtime-controls");
      controls.append(
        node("summary", `Runtime controls (${catalog.runtime_controls.length}) · Read only`),
        node("p", "Managed automatically. These controls cannot be changed here."),
      );
      for (const control of catalog.runtime_controls) {
        const row = node("div");
        row.dataset.runtimeControl = control.tool_id;
        row.append(
          node("strong", control.tool_id),
          node("p", control.description),
          node("p", control.policy_note),
        );
        controls.append(row);
      }
      body.append(controls);
    }
  }
  body.append(
    node(
      "p",
      "Changes do not grant credentials or bypass runtime safety checks.",
      "muted",
    ),
  );
  body.append(
    button("Use inherited policy", async () => {
 const busyFeedback = window.SMTOBusy?.action("Saving policy…");
 try {
      if (kind === "capabilities" && scope.value !== "prompt") {
        await api(scope.value === "global" ? `capabilities/settings/global?expected_revision=${effective.scopes.global.revision}`
          : `chats/${encode(cid)}/capability-settings?expected_revision=${effective.scopes.conversation.revision}`,
          {method: "PUT", body: {policy: null, selection: null}});
      } else if (scope.value === "conversation")
        await api(
          `chats/${encode(cid)}/${kind === "permissions" ? "permission" : "capability"}-policy?expected_revision=${effective.scopes?.conversation?.revision || 0}`,
          { method: "DELETE" },
        );
      state.choices[key] = null;
      if (kind === "capabilities") {
        state.choices.capability_selection = null;
        window.dispatchEvent(new Event("capability-selection-draft-changed"));
      }
      await hooks.refresh();
      back();

 } finally { busyFeedback?.finish(); }
}),
  );
  body.append(
    button(
      "Apply",
      async () => {
 const busyFeedback = window.SMTOBusy?.action("Saving policy…");
 try {
        const policy = await api(`${kind}/validate`, {
          method: "POST",
          body: selected,
        });
        if (generation !== state.generation) return;
        if (kind === "capabilities") {
          await api("capabilities/effective", {method: "POST", body: {prompt_policy: policy, prompt_selection: selection}});
          if (scope.value !== "prompt") {
            await api(scope.value === "global" ? `capabilities/settings/global?expected_revision=${effective.scopes.global.revision}`
              : `chats/${encode(cid)}/capability-settings?expected_revision=${effective.scopes.conversation.revision}`,
              {method: "PUT", body: {policy, selection}});
            state.choices[key] = null; state.choices.capability_selection = null;
          } else { state.choices[key] = policy; state.choices.capability_selection = selection; }
          window.dispatchEvent(new Event("capability-selection-draft-changed"));
        } else if (scope.value === "conversation") {
          await api(
            `chats/${encode(cid)}/${kind === "permissions" ? "permission" : "capability"}-policy?expected_revision=${effective.scopes?.conversation?.revision || 0}`,
            { method: "PUT", body: policy },
          );
          state.choices[key] = null;
        } else state.choices[key] = policy;
        await hooks.refresh();
        back();

 } finally { busyFeedback?.finish(); }
},
      "primary",
    ),
  );

  } finally { busyFeedback?.finish(); }
}
