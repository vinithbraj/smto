---
id: tool-discovery
title: Tool discovery
kind: architecture
tags: [architecture, tools]
order: 4
---
# Tool discovery

`native/catalog.py` owns the `CORE` set and built-in control declarations.
Core candidates include Shell/Python, Files, HTTP, Web, Artifacts, Agent
Introspection, Agent KV, Memory put/get/search and schedule creation/inspection.
Being in `CORE` determines initial advertisement when permitted and available; it
does not make every candidate mandatory. Agent Introspection, Memory and Shell are
always selected for new requests in both Automatic and Manual. Their Skill/tool
exclusions are normalized away, and Auto cannot omit them from its accepted selection.
Memory and Shell still obey workflow restrictions and current availability. Advisory
mode permits local Memory but excludes external Shell execution. Only `agent.info`
is exempt from workflow fences, including in saved runs. Optional candidates require
capability selection and current availability. Controls cover task organization,
discovery, scoped context/results, jobs/events/activity waits, user interaction
and completion. Shell sequencing, dependency scheduling and parallel tool
families add declarations when their own conditions apply. The initial schema
set therefore depends on the run's configuration and prerequisites.

Automatic selection also retains `file.read` whenever the accepted tool ceiling
permits it. The model can read known files without selecting the whole Files skill;
other Files tools still require selection or discovery. File read obeys explicit
exclusions, workflow and Advisory restrictions, and Gateway availability.

For example, an Auto selection of Files for “check pending changes in this repository”
also includes Memory and Shell, allowing the Agent to run `git status`. Discovery cannot
widen the accepted authority ceiling. Existing runs retain their saved selection; use a new
request after updating to adopt the new always-selected Skills.

An empty `discover_tools` call lists registered skills and tools, including unavailable entries with reasons, without exposing every full schema. `{"skill_ids":["database"]}` adds that family's available schemas to subsequent model requests. Use the exact lowercase skill IDs returned by discovery; display titles are not IDs. Exact `capability_ids` can select individual tools. Unknown or forbidden entries fail atomically. Unavailable requests return prerequisite information without advertising an unusable schema. Discovery executes nothing and grants no authorization.

Canonical tool IDs contain a dot. The OpenAI-compatible function-name wire format uses `__`: `shell.command` is sent as `shell__command`. Receipts and documentation use canonical dotted IDs. Only the visible schemas may be called.

Use `skill_ids` for families such as `schedule`, `capability_ids` for exact tool IDs
such as `schedule.inspect`, and `section_ids` only for returned API section IDs.
Invalid selections return an actionable `retry` discovery call to the model. A
recognized, permitted family uses `skill_ids`; otherwise the retry lists the catalog.
The failed selection advertises no tools and does not execute an adapter. Recovery
never creates aliases or expands capability policy. Discovery failures establish no
facts about the requested data: an unavailable inspection cannot prove a zero count.

## Capability awareness, activation and grants

| Concept | Responsibility |
| --- | --- |
| Capability Manifest | What the Agent knows exists: installed, user-routable Skills and source-owned routing summaries. |
| Capability Policy / frozen ceiling | What this accepted run may expose, within its captured upstream restrictions. |
| Active projection | The Skills and tools selected for the current semantic request. |
| Tool discovery | Concrete schemas and entry tools from the active projection. |
| Capability grant | An explicit user decision that updates conversation capability settings and renews authority. |
| Permission Policy | Whether a concrete operation is allowed, requires approval, or is denied. |
| Credentials / authentication | Whether the provider or resource can actually be accessed. |
| Activity Trace | Durable events explaining each capability transition. |

Automatic mode places a versioned, digested Manifest in stable Task State. It contains
canonical Skill IDs, display names, selection modes and one-line summaries from the
registry. Dependency-only Skills are omitted. Building it does not inspect credentials,
probe providers or include tool schemas. The initial selector still uses the smaller
candidate catalog inside the accepted ceiling. Task Contract compilation continues to
provide that initial selection when enabled; no separate selector call is added.

During the request, the Agent can call `discover_tools(skill_ids=["docker"])` after,
for example, reading a Compose file. If Docker is inside the frozen ceiling, the runtime
commits a new selection epoch containing the prior active set plus Docker and its
permitted dependencies, rebinds the scoped catalog, then returns entry-tool discovery.
This uses no helper model and needs no user prompt. A later request for `database`
or `http` can grow the same projection. Already-active Skills produce an audited no-op.
At the next semantic user input, normal selection can contract the projection again.

Activation accepts at most eight exact canonical Skill IDs per discovery request.
Mixed requests are atomic: one blocked Skill prevents partial activation. Section IDs
and tool IDs discover only within the current projection; they cannot activate a Skill.
Discover newly needed Skills separately before selecting sections or exact tools.
Direct requests for dependency-only Skills fail. An inactive `explicit_only` Skill
requires a correlated user trigger. Manual mode retains its existing discovery behavior.

For a disabled Skill such as GitHub, the runtime first proves that a prospective grant
fits the captured upstream envelope, including dependencies. It returns
`activation.status="user_enable_required"` with a durable `grant_request_id`.
`native/authority_control.py` opens the waiting-user checkpoint in that same discovery
transaction and supplies the question and Allow/Deny choices. There is **no model call
between the requirement and the approval prompt**. `ask_user` handles ordinary input;
its model-visible schema has no grant field. Discovery itself never changes policy.
Hard restrictions produce a block with no grant prompt.

A structured answer includes `authority_request_id`, the displayed `operation_id`
and `authority_decision` (`allow` or `deny`). Existing clients may still submit
`capability_grant_request_id` and `capability_decision`; conflicting identities or
decisions fail closed. Text replies with that operation
identity use a small deterministic vocabulary: `yes`, `allow`, `allow for this
conversation`, `do it`, or `no`, `deny`, `don't allow`, `do not allow`, `not now`.
Case and terminal punctuation are normalized. An unclear answer grants nothing.
An answer cannot approve another question, a stale task, or an uncorrelated model claim.

Allow atomically merges the approved Skills into the effective conversation policy,
preserving inherited settings and unrelated exclusions, and creates a child continuation with a
new frozen ceiling. The parent's ceiling remains unchanged. The child inherits the
task, Task Contract, evidence and operation permissions, and starts with the parent's
active Skills plus the granted Skills. Approval is an authorization decision, so a bare
`yes` does not become the task objective or trigger a compiler/selector call. Conflicting
policy edits are preserved and reported; an identical concurrent enable can converge.
Deny resumes the existing run with a denial fact and suppresses repeated prompts for
the same Skill during that semantic request. Explicit-only triggers inside the ceiling
activate in the existing run without changing conversation settings.

Enabling GitHub does not sign in an account or approve a merge. A missing account still
reports authentication requirements; `github` operations with Permission Policy `deny`
remain denied after a grant. Grants persist as conversation eligibility, while a later
request such as “summarize this text” can select a small projection again.

Native checkpoints commit activation epochs, grants and capability events together.
Legacy required grants are opened before inference when the run resumes; an uncertain
discovery receipt is reconstructed from its committed activation record. Reload and
repeated delivery retain the same authority identity and do not emit a second prompt.
Grant policy updates and parent/child records share one transaction. Existing native
continuation workers repair task and UI projections after restart. Stop and stale
semantic-source checks prevent an old activation from overwriting newer authority.
Historical runs lacking captured grant provenance remain runnable but cannot acquire
new authority through this path. See [Activity](23-observability.md).

## Large API skills

For a skill with `entry_tool_ids`, discovering its `skill_id` advertises those
entries and returns root section metadata. The general catalog lists entry
metadata for that skill instead of every raw endpoint. For example:

```json
{"skill_ids":["proxmox"]}
```

This yields the four Proxmox domain tools plus root sections. Explore a source
API section with:

```json
{"section_ids":["proxmox.nodes.node.qemu.vmid.status"]}
```

The response contains direct tools and child metadata; it does not expand all
descendants. Discovering another raw slice replaces that large skill's prior raw
advertisements while retaining entry tools. Unknown section IDs return
`unknown_section`; an excluded skill remains inaccessible. Exact tool discovery
still respects the same policy. Existing small skills retain full-family discovery.

Proxmox is disabled by default. An accepted typed Proxmox `@parameter` can promote
its already-allowed entry tools into the initial request, but cannot change the
capability selection or approval requirements. See [Proxmox VE](19-proxmox.md).

Use the [generated Tool and Skill Reference](/manual#doc=generated-capabilities)
for the current registration list. A static count in this page would drift from
the registry and would not describe the schemas available to a particular run.

The served generated Tool and Skill Reference constructs the current source-owned registry without executing tools. Availability metadata describes prerequisites; credential requirements remain explicit and remote health is not inferred. `scripts/v55_final_catalog.py` remains a historical validation/schema-evidence utility, outside mandatory product-source documentation.

Email is enabled by product default, subject to explicit selections and exclusions.
An accepted `email_smtp` parameter promotes `email.accounts`, `email.connect`,
`email.connection_status`, `email.test_connection` and `email.send` only within the
accepted envelope. Sending remains a confirmed write. Configuration and authorization
prerequisites do not silently switch to Gmail or controller-local SMTP.

Desktop is disabled by default. Its three entry tools and applications/processes/windows
sections use the same bounded discovery contract. Each tool checks its exact captured Gateway
sub-capability; missing window support does not disable processes. See [Desktop](36-desktop.md).

Clipboard is disabled by default. Its inspect/read-text entry tools and text/files/image sections
use negotiated format tags on the selected Gateway. Enabling it never reads clipboard content.
See [Current clipboard](37-clipboard.md).

Screen is disabled by default. Its five explicit observation tools use independent negotiated
metadata/capture/OCR tags. Discovery and metadata-only context never capture pixels.
See [Screen capture, OCR and context](38-screen.md).

Browser is disabled by default. Its four entry tools and six sections use the same bounded
discovery contract. The selected Gateway advertises managed, explicit-CDP and file capabilities
independently. The status tool remains available to explain missing optional prerequisites.
See [Browser automation](39-browser.md).

Web Research is an optional guidance Skill sharing only `web.search` and `web.read`.
Its compact manifest/routing entry uses the existing selector; Browser remains a
separate activation/grant. See [Web Research](43-web-research.md).

Desktop UI is optional and sectioned. Discover `ui` for `status`, `snapshot`, `find` and
`focused_element`; semantic actions, input and waits are available through sections. Selected
Gateway tags distinguish accessibility, keyboard, pointer and drag support. See
[Desktop UI automation](40-desktop-ui.md).

GitHub is optional and disabled by default. Its five entry tools expose local accounts,
connection verification, repository resolution, issues and PR inspection; eleven sections
provide bounded access to provider operations. A typed `github_account` promotes only
already-permitted entries. See [GitHub](../32-github.md).
