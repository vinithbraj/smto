import "../thinking_animations.js?v=20261015-smto";
import "../activity_update_animations.js?v=20261020-activity-words";
import "../message_timestamps.js?v=20261015-smto";
import "../task_mode.js?v=20261015-smto";
const boundLiveActivity = (...args) => window.SMTOConversationSnapshot.boundActivity(...args);
import "../task_lifecycle.js?v=20261015-smto";
import "../smto_markdown.js?v=20261020-copy-source";
import "../conversation_immersive.js?v=20261021-immersive-queue";
import "../task_disclosure.js?v=20261021-task-timing";
import {fromNative as gatewayTarget} from "./target_state.js";
import "../conversation_navigator_core.js";
import "../plan_mode.js?v=20261018-loading";
import {closeSheet} from "./overlays.js?v=20261018-loading";
import {composerProfile} from "./composer_profile.js?v=20261018-loading";
import {targets} from "./targets.js?v=20261018-loading";
import "../schedule_time.js?v=20261015-smto";
import "../schedule_recurrence.js?v=20261015-smto";
import "../schedule_editor.js?v=20261018-loading";
import "../prompt_schedule.js?v=20261018-loading";
import "../manual_links.js";
import "../agent_checks.js?v=20261018-loading";
import "../saved_task_context.js?v=20261018-loading";
import "../prose_activity.js?v=20261020-continuity";
import "../stream_activity.js?v=20261015-smto";
import "../context_meter.js?v=20261015-smto";
import "../context_visualization.js?v=20261018-loading";
import "../response_tokens.js?v=20261015-smto";
import "../progress_display.js?v=20261020-activity-parts";
import "../run_activity.js?v=20261021-reliable-waits";
import "../wait_controls.js?v=20261018-loading";
import "../action_icons.js?v=20261015-smto";
import {
  $,
  state,
  node,
  button,
  terminal,
  encode,
  api,
  notice,
  runStatus,
} from "./api.js?v=20261018-loading";
import { markdown, copyButton } from "./markdown.js?v=20261018-loading";
const conversationStyle = document.createElement("link");
conversationStyle.rel = "stylesheet";
conversationStyle.href = new URL("./conversation.css?v=20261020-activity-words", import.meta.url).href;
document.head.append(conversationStyle);
window.SMTOThinkingAnimations.setPreference(state.settings.ui_thinking_animation);
window.SMTOActivityUpdates?.setPreference(state.settings.ui_activity_update_animation);
const actionIcons = window.SMTOActionIcons;
const activityPresentation = window.SMTOActivityPresentation;
const promptSchedules = window.SMTOPromptSchedule.create({notify: notice,
  executionSnapshot: () => targets().submissionSnapshot()});

function taskContractRecoveryNotice(detail, limit) {
  let notice = "Retrying task contract automatically";
  if (Number.isSafeInteger(limit) && limit > 0) notice += ` with ${limit.toLocaleString("en-US")} tokens`;
  const index = detail.auto_retry_index, retries = detail.configured_auto_retries;
  if (Number.isSafeInteger(index) && index > 0 && Number.isSafeInteger(retries) && retries >= index) {
    notice += ` · retry ${index} of ${retries}`;
  }
  return notice;
}

import "../followup_queue.js?v=20261019-resources";
import {} from "../inline_steer.js?v=20261021-reply-enter";

export const turns = new Map();
const submissions = new Map();
const taskDisclosure = window.SMTOTaskDisclosure.create({
  content: $("#messages"), viewport: $("#thread"), toolbar: $("#task-disclosure-toolbar"),
  gatewaysInFooter: true,
  conversationId: () => state.conversationId,
  defaultImmersive: () => state.settings.ui_immersive_default_enabled,
  defaultNavigator: () => state.settings.conversation_navigator_enabled,
  hasQueuedTasks: () => Boolean(state.lane?.queued_tasks?.length),
  getTask: id => state.lane?.tasks?.find(task => task.task_id === id),
  getTurn: root => {
    const turn = turns.get(root.dataset.requestId);
    return {prompt: turn?.prompt || root.querySelector(".user-message")?.textContent, attachments: turn?.attachments,
      hasConversationHistory: (turn?.trace?.response_metrics?.conversation_message_count ?? 1) > 0,
      taskId: root.dataset.taskId, creationSequence: Number(root.dataset.creationSequence),
      gatewayTarget: gatewayTarget(turn?.run),
      status: turn?.replyResume?.pending ? "resuming" : turn?.status || (root.dataset.taskId ? null : "pending"),
      currentActivity: turn && !turn.replyResume?.pending
        ? window.SMTORunActivity.resolve(turn.liveActivity) : null,
      sentAt: turn?.messageTimes?.sentAt(), durationMs: turn?.elapsedMs,
      userAuthored: turn?.userAuthored};
  },
  beforeToggle: () => { historyNavigation = true; state.following = false; }, changed: () => refreshNavigator(),
  openNavigator: () => openNavigator($("#options")), navigatorChanged: refreshNavigator,
  immersiveChanged: enabled => {
    if (enabled) { void closeSheet(); promptNavigator?.reset(); }
    refreshNavigator();
  },
});
// Mobile keeps the live controls in the options sheet, with visible action labels.
const displayToolbar = $("#task-disclosure-toolbar");
for (const action of displayToolbar.querySelectorAll(":scope > .task-disclosure-button")) {
  action.append(node("span", action.getAttribute("aria-label")));
  displayToolbar.append(action);
}
export function acceptImmersiveConversation(id) { taskDisclosure.accepted(id); }
export function refreshConversationPreferences() { taskDisclosure.sync(); }

function createActivityGroup(taskId = "") {
  const group = node("section", null, "activity-group");
  group.setAttribute("role", "group");
  group.setAttribute("aria-label", "Conversation activity");
  if (taskId) { group.dataset.taskId = taskId; group.dataset.activityId = `task:${taskId}`; }
  return group;
}

function setActivityGroupIdentity(group, taskId = "") {
  if (!group) return;
  if (taskId) { group.dataset.taskId = taskId; group.dataset.activityId = `task:${taskId}`; }
  else { delete group.dataset.taskId; delete group.dataset.activityId; }
}

function cleanupActivityGroup(group) {
  if (group?.classList?.contains("activity-group") && !group.querySelector(":scope > .turn")) group.remove();
}

function moveActivityGroupInto(parentTurn, turn) {
  if (!parentTurn?.root?.isConnected || !turn?.root?.isConnected || !turn.taskId || parentTurn.taskId !== turn.taskId) return false;
  parentTurn.continuedBy = turn.id;
  parentTurn.inlineSteer?.update({...parentTurn.run, status: parentTurn.status, continued_by: {request_id: turn.id}});
  const target = parentTurn.activityGroup || parentTurn.root.closest(".activity-group");
  const source = turn.activityGroup || turn.root.closest(".activity-group");
  if (!target || !source) return false;
  setActivityGroupIdentity(target, turn.taskId);
  if (target === source) return true;
  for (const root of [...source.querySelectorAll(":scope > .turn")]) {
    target.append(root);
    const member = turns.get(root.dataset.requestId);
    if (member) member.activityGroup = target;
  }
  cleanupActivityGroup(source);
  return true;
}

function reconcileTurnActivityGroup(turn) {
  if (!turn?.root?.isConnected) return;
  const group = turn.activityGroup || turn.root.closest(".activity-group");
  if (group) { turn.activityGroup = group; if (turn.taskId) setActivityGroupIdentity(group, turn.taskId); }
  if (!turn.parentRequestId || !turn.taskId) return;
  const parentTurn = turns.get(turn.parentRequestId);
  if (parentTurn) moveActivityGroupInto(parentTurn, turn);
}

function reconcileActivityChildren(parentTurn) {
  if (!parentTurn?.id || !parentTurn.taskId) return;
  for (const candidate of turns.values()) {
    if (candidate !== parentTurn && candidate.parentRequestId === parentTurn.id
        && candidate.taskId === parentTurn.taskId) moveActivityGroupInto(parentTurn, candidate);
  }
}

export function showSubmission(prompt, id, source, {fresh = true} = {}) {
  let root = submissions.get(id);
  if (!root?.isConnected) {
    root = node("article", null, "turn provisional-submission");
    root.dataset.submissionId = id;
    root.append(node("div", prompt, "user-message"), node("p", "Submitting…", "submission-status"));
    root.lastChild.setAttribute("role", "status");
    const group = createActivityGroup(); group.append(root);
    $("#messages").append(group); $("#welcome").hidden = true;
    submissions.set(id, root);
    if (fresh) taskDisclosure.submitted(root);
    scheduleActivityBoundaries();
  }
  root.querySelector(".submission-status").textContent = "Submitting…";
  window.SMTOTaskMode.render(root, source);
  return root;
}

export function acceptSubmission(id, response) {
  const root = submissions.get(id);
  if (!root?.isConnected) return;
  if (response.status === "queued" || response.task?.status === "queued") {
    failSubmission(id, true); return;
  }
  if (response.task?.created_at && !root.querySelector(".message-time-heading")) {
    const heading = node("div", "You", "message-time-heading");
    heading.append(window.SMTOMessageTimestamps.create(response.task.created_at).root);
    root.querySelector(".user-message").before(heading);
  }
  root.dataset.taskId = response.task_id;
  if (Number.isSafeInteger(response.task?.creation_sequence) && response.task.creation_sequence > 0)
    root.dataset.creationSequence = String(response.task.creation_sequence);
  window.SMTOTaskMode.render(root, response.task);
  setActivityGroupIdentity(root.closest(".activity-group"), response.task_id);
  root.querySelector(".submission-status").textContent = response.status === "queued" ? "Queued…" : "Starting…";
  scheduleActivityBoundaries();
}

export function removeDeletedSubmissions(deleted) {
  for (const [id, root] of submissions) if (deleted(root.dataset)) failSubmission(id, true);
}

export function reconcileSubmissions(lane) {
  for (const task of lane.queued_tasks || []) failSubmission(task.client_submission_id, true);
}

export function renderApprovedPlan(turn, source) {
  if (turn.prompt !== "Implement the plan.") return;
  window.SMTOPlanMode.quote(turn.user, source, {
    apiJson: api, renderMarkdown: markdown,
    active: () => !turn.disposed && turn.user.isConnected && turn.conversationId === state.conversationId,
    changed: () => {
      if (turn.root.querySelector(".approved-plan-copy")) return;
      const copy = copyButton(() => window.SMTOPlanMode.message(turn.user));
      copy.setAttribute("aria-label", "Copy message"); copy.classList.add("approved-plan-copy");
      turn.user.after(copy);
    },
  });
}

export function showPlanTask(task, {fresh = false} = {}) {
  if (!task || task.status === "queued" || task.conversation_id !== state.conversationId) return;
  let turn = [...turns.values()].find(item => item.taskId === task.task_id && !item.parentRequestId);
  if (!turn) {
    const root = showSubmission(task.prompt, task.client_submission_id, null, {fresh: false});
    acceptSubmission(task.client_submission_id, {task, task_id: task.task_id, status: task.status});
    if (["cancelled", "failed"].includes(task.status)) root.querySelector(".submission-status").textContent = task.status === "cancelled" ? "Cancelled" : "Failed";
    turn = {root, user: root.querySelector(".user-message"), prompt: task.prompt, conversationId: task.conversation_id};
  }
  renderApprovedPlan(turn, task);
  if (fresh) taskDisclosure.submitted(turn.root);
}

export function failSubmission(id, definite) {
  const root = submissions.get(id);
  if (definite && root) {
    const group = root.closest(".activity-group"); root.remove(); cleanupActivityGroup(group);
    submissions.delete(id); scheduleActivityBoundaries();
    $("#welcome").hidden = Boolean($("#messages").querySelector(".turn, .history-skeleton, .history-retry"));
  }
  else if (root) root.querySelector(".submission-status").textContent = "Couldn’t confirm submission · Retry";
}
let onAction = () => {}, retryContract,
  frame = 0;
let promptNavigator, navigatorLoading, historyNavigation = false;
async function loadNavigator() {
  if (!navigatorLoading) navigatorLoading = import("./lazy/conversation_navigator.js?v=20261020-navigator-toggle");
  try {
    promptNavigator = await navigatorLoading;
    promptNavigator.configure({navigate: navigateToConversationTurn});
    return promptNavigator;
  }
  catch (error) { navigatorLoading = null; throw error; }
}
async function openNavigator(returnFocus = $("#conversation-navigator")) {
 const busyFeedback = window.SMTOBusy?.action("Loading conversation navigation…");
 try {
  const cid = state.conversationId;
  try {
    const navigator = await loadNavigator();
    if (cid !== state.conversationId || !taskDisclosure.navigatorOptions().enabled) return;
    refreshNavigator();
    // The options controls return to hidden storage when the Navigator replaces the sheet.
    navigator.open(returnFocus);
  } catch {
    notice("Conversation navigation could not load. Try again.");
  }

 } finally { busyFeedback?.finish(); }
}
export function refreshNavigator() {
  const {enabled, allowShort} = taskDisclosure.navigatorOptions();
  if (!enabled || [...turns.values()].filter(turn => turn.userAuthored && !window.SMTOTaskDisclosure.isFiltered(turn.root)).length < (allowShort ? 1 : 3)) {
    promptNavigator?.reset();
    $("#conversation-navigator").hidden = true;
    return;
  }
  if (promptNavigator) {
    try { promptNavigator.sync(turns, {allowShort}); }
    catch (_) { promptNavigator.reset(); }
  }
  else {
    $("#conversation-navigator").hidden = false;
    $("#conversation-navigator").onclick = () => openNavigator();
  }
}
window.addEventListener("pagehide", () => promptNavigator?.reset());
window.addEventListener("pageshow", event => { if (event.persisted) refreshNavigator(); });
export function navigateToConversationTurn(messageId, {instant = false} = {}) {
  const turn = turns.get(messageId);
  if (!turn?.root.isConnected) return false;
  taskDisclosure.reveal(turn.root);
  historyNavigation = true;
  state.following = false;
  $("#latest").hidden = false;
  if (instant) {
    turn.root.scrollIntoView({block: "start", inline: "nearest", behavior: "instant"});
    return true;
  }
  return window.SMTOConversationNavigatorCore.scrollToTurn(turn.root);
}
export function initConversation(action, retry) {
  onAction = action;
  retryContract = retry;
  const thread = $("#thread");
  let observedHeight = thread.clientHeight, scrollIntent = false, intentTimer;
  for (const type of ["wheel", "touchmove"]) thread.addEventListener(type, () => {
    scrollIntent = true; clearTimeout(intentTimer);
    intentTimer = setTimeout(() => { scrollIntent = false; }, 180);
  }, {passive: true});
  new ResizeObserver(() => {
    observedHeight = thread.clientHeight;
    if (state.following && !scrollIntent) {
      follow();
      // The browser can finish caret scrolling after textarea autosize layout.
      requestAnimationFrame(() => { if (state.following && !scrollIntent) follow(); });
    }
  }).observe(thread);
  new ResizeObserver(() => { if (state.following && !scrollIntent) follow(); }).observe($("#messages"));
  window.addEventListener("mobile-composer-resized", () => { if (state.following && !scrollIntent) follow(); });
  $("#thread").addEventListener(
    "scroll",
    () => {
      const view = $("#thread");
      if (!scrollIntent && (state.composerResizing || view.clientHeight !== observedHeight)) return;
      state.following =
        !historyNavigation && view.scrollHeight - view.scrollTop - view.clientHeight < 96;
      $("#latest").hidden = state.following;
      promptNavigator?.refreshActive();
    },
    { passive: true },
  );
  $("#latest").onclick = () => {
    scrollIntent = false; clearTimeout(intentTimer);
    historyNavigation = false;
    state.following = true;
    follow();
  };
  for (const type of ["wheel", "touchstart", "pointerdown", "keydown"])
    $("#thread").addEventListener(type, () => { historyNavigation = false; }, {passive: true});
}
export function follow(force = false) {
  if (force) { historyNavigation = false; state.following = true; }
  if (state.following) {
    $("#thread").scrollTop = $("#thread").scrollHeight;
    $("#latest").hidden = true;
  } else $("#latest").hidden = false;
}
export function releaseTurn(turn) {
  turn.messageTimes?.destroy(); turn.disposed = true;
  turn.savedTaskContext?.dispose(); turn.historyController?.abort(); turn.historyLoader?.dispose();
  turn.executionInspector?.dispose(); turn.results._disclosureAction?.dispose(); turn.inlineSteer?.dispose();
  turn.checkObservations?.dispose();
  for (const op of turn.operations.values()) op.liveShell?.viewer?.dispose();
  const group = turn.activityGroup || turn.root.closest(".activity-group");
  turns.delete(turn.id); turn.root.remove(); cleanupActivityGroup(group);
  scheduleActivityBoundaries(); refreshNavigator();
}

export function clearConversation() {
  if (!state.conversationId) taskDisclosure.resetDraft();
  promptNavigator?.reset();
  $("#conversation-navigator").hidden = true;
  historyNavigation = false;
  for (const turn of turns.values()) {
    turn.messageTimes?.destroy();
    turn.disposed = true;
    turn.savedTaskContext?.dispose(); turn.historyController?.abort();
    turn.historyLoader?.dispose();
    turn.executionInspector?.dispose(); turn.results._disclosureAction?.dispose(); turn.inlineSteer?.dispose();
    turn.checkObservations?.dispose();
    for (const op of turn.operations.values()) op.liveShell?.viewer?.dispose();
  }
  turns.clear();
  submissions.clear();
  $("#messages").replaceChildren();
  taskDisclosure.sync();
  $("#welcome").hidden = false;
  state.following = true;
}
let activityBoundariesPending = false;
function scheduleActivityBoundaries() {
  if (activityBoundariesPending) return;
  activityBoundariesPending = true;
  queueMicrotask(() => {
    activityBoundariesPending = false;
    let previous = null;
    for (const group of $("#messages").querySelectorAll(".activity-group")) {
      group.classList.remove("activity-continuation-fragment");
      group.querySelectorAll(":scope > .turn").forEach((root, index) => {
        if (root.closest("[hidden]")) return;
        const current = root.dataset;
        const continuation = Boolean(previous && current.taskId
          && current.taskId === previous.taskId && current.parentRequestId === previous.requestId);
        root.classList.toggle("activity-continuation", continuation);
        if (continuation && index === 0) group.classList.add("activity-continuation-fragment");
        previous = current;
      });
    }
    window.SMTOTaskDeletionController?.decorate($("#messages"));
    taskDisclosure.sync();
    if (state.following) follow();
    refreshNavigator();
  });
}

export function setTurnActivityLineage(turn, payload = {}) {
  if (!turn) return;
  const taskId = payload.task_id, parentRequestId = payload.parent_request_id || payload.continuation?.parent_request_id;
  let changed = false;
  if (taskId && turn.taskId !== taskId) {
    if (turn.root.dataset.taskId !== taskId) delete turn.root.dataset.creationSequence;
    turn.taskId = turn.root.dataset.taskId = taskId; changed = true;
  }
  if (Number.isSafeInteger(payload.creation_sequence) && payload.creation_sequence > 0)
    turn.root.dataset.creationSequence = String(payload.creation_sequence);
  if (parentRequestId && turn.parentRequestId !== parentRequestId) {
    turn.parentRequestId = turn.root.dataset.parentRequestId = parentRequestId; changed = true;
  }
  window.SMTOTaskMode.render(turn.root, payload,
    state.lane?.tasks?.find(task => task.task_id === turn.taskId));
  if (changed) { reconcileTurnActivityGroup(turn); reconcileActivityChildren(turn); }
  scheduleActivityBoundaries();
}

export function turnFor(id, prompt = "", {attachments, userAuthored = Boolean(prompt || attachments?.length), taskId = "", parentRequestId = ""} = {}) {
  const task = state.lane?.tasks?.find(task => (task.current_request_id || task.latest_request_id) === id
    || taskId && task.task_id === taskId);
  const lineage = {task_id: taskId || task?.task_id, parent_request_id: parentRequestId};
  if (turns.has(id)) {
    const turn = turns.get(id); setTurnActivityLineage(turn, lineage); renderApprovedPlan(turn, task); return turn;
  }
  const provisional = submissions.get(task?.client_submission_id)
    || [...submissions.values()].find(root => taskId && root.dataset.taskId === taskId);
  const root = provisional?.isConnected ? provisional : node("article", null, "turn");
  if (provisional) { root.replaceChildren(); root.classList.remove("provisional-submission"); submissions.delete(root.dataset.submissionId); }
  let activityGroup = root.closest(".activity-group");
  if (!activityGroup) { activityGroup = createActivityGroup(lineage.task_id || ""); activityGroup.append(root); }
  root.dataset.requestId = id;
  if (userAuthored) root.dataset.conversationTurnId = id;
  const user = node("div", prompt, "user-message");
  user.hidden = !prompt;
  const activity = node("details", null, "activity"),
    summary = node("summary", "Working…"),
    timeline = node("div", null, "timeline");
  activity.append(summary, timeline);
  activity.dataset.activityConversation = state.conversationId || "";
  activity.open = window.SMTOProseActivity.preference(state.conversationId, false);
  const activityStatus = node("p", "", "task-activity-status");
  activityStatus.setAttribute("role", "status");
  activityStatus.setAttribute("aria-atomic", "true");
  activityStatus.hidden = true;
  const activityStatusLabel = node("span");
  const activityStatusDetail = node("span", "", "task-activity-detail");
  activityStatusDetail.setAttribute("aria-live", "off");
  const activityStatusCopy = node("span", "", "task-activity-copy");
  activityStatusCopy.append(activityStatusLabel, activityStatusDetail);
  activityStatus.append(window.SMTOThinkingAnimations.create(state.conversationId), activityStatusCopy);
  const answer = node("div", null, "answer"),
    actions = node("div", null, "turn-required-actions"),
    results = node("div");
  const controls = node("details", null, "turn-controls");
  const tokenUsage = node("div", null, "response-token-usage");
  tokenUsage.hidden = true;
  tokenUsage.setAttribute("aria-live", "off");
  controls.append(node("summary", "Task controls"));
  root.append(user, activity, activityStatus, answer, results, actions, controls, tokenUsage);
  if (!activityGroup.isConnected) $("#messages").append(activityGroup);
  $("#welcome").hidden = true;
  const turn = {
    id,
    conversationId: state.conversationId,
    prompt,
    attachments,
    userAuthored,
    root,
    user,
    activity,
    activityStatus,
    activityStatusLabel,
    activityStatusDetail,
    liveActivity: window.SMTORunActivity.create(),
    summary,
    timeline,
    answer,
    actions,
    controls,
    tokenUsage,
    results,
    status: "pending",
    cursor: 0,
    createdAt: "",
    seen: new Set(),
    operations: new Map(),
    narrations: new Map(),
    latest: "",
    text: "",
    previewCall: "",
    previewClosed: false,
    disposed: false,
    taskId: "", parentRequestId: "", activityGroup,
  };
  turn.messageTimes = window.SMTOMessageTimestamps.bind({user, answer, userAuthored: () => turn.userAuthored});
  if (userAuthored) window.SMTOWorkflows?.attach(turn, user);
  // Follow-ups share the task, but their message time belongs to their own request.
  if (!parentRequestId) turn.messageTimes.user(task?.created_at);
  renderApprovedPlan(turn, task);
  window.SMTOSavedTaskContext?.bind(turn, {conversationId: turn.conversationId,
    apiJson: (url, options = {}) => api(url, {...options,
      ...(typeof options.body === "string" ? {body: JSON.parse(options.body)} : {})})});
  turns.set(id, turn);
  setTurnActivityLineage(turn, lineage);
  reconcileActivityChildren(turn);
  scheduleActivityBoundaries();
  const responseActions = node("div", null, "response-actions");
  const copy = copyButton(() => turn.text || turn.latest, {icon: true}); copy.setAttribute("aria-label", "Copy response");
  const files = button("Files", async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try {
    const module = await import("./lazy/artifacts.js?v=20261020-copy-source"); module.attach(turn)?.open();

 } finally { busyFeedback?.finish(); }
});
  files.setAttribute("aria-label", "Files and artifacts");
  const more = button("", async opener => { const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try { return await ((await import("./lazy/message_details.js?v=20261018-loading")).open(turn, opener)); } finally { busyFeedback?.finish(); } }, "icon");
  more.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>';
  more.setAttribute("aria-label", "Message details"); more.setAttribute("aria-haspopup", "dialog");
  const detailStorage = node("div", null, "message-detail-storage");
  turn.detailActions = node("div", null, "message-detail-actions");
  turn.detailActions.append(files); detailStorage.append(turn.detailActions); root.append(detailStorage);
  responseActions.append(copy, more); turn.responseActions = responseActions;
  promptSchedules.attachTaskAction(responseActions, turn);
  window.SMTOWorkflows?.attach(turn, responseActions, {footer: true});
  answer.after(responseActions); responseActions.hidden = true;
  root.addEventListener("mobile-artifact-reference", () => {
    void import("./lazy/artifacts.js?v=20261020-copy-source").then(module => module.attach(turn)).catch(error => notice(error));
  });
  refreshNavigator();
  results._actionContainer = turn.detailActions;
  turn.executionInspector = window.SMTOConversationSnapshot.inspectControl({actionContainer: turn.detailActions,
    requestId: id, apiJson: api, ready: state.currentSnapshotReady});
  turn.historyLoader = window.SMTOConversationSnapshot.loadHistoryControl({actionContainer: responseActions,
    disclosure: activity, host: timeline, requestId: id, apiJson: api, conversationId: turn.conversationId,
    loadOnDemand: state.settings.ui_history_load_on_demand !== false,
    renderMarkdown: markdown, onAnswerArchived: answer => archiveTurnAnswer(turn, answer)});
  follow();
  return turn;
}
export function resetCursor(turn, createdAt) {
  if (!createdAt || turn.createdAt === createdAt) return;
  if (turn.createdAt) {
    turn.historyLoader?.reset();
    turn.seen.clear();
    turn.cursor = 0;
    turn.operations.clear();
    turn.policyRejections?.clear();
    turn.modelOutputs?.clear();
    turn.narrations.clear();
    turn.conversationQuestions?.clear();
    turn.activeProse = null;
    turn.activity.classList.remove("progress-timeline");
    turn.activity.open = window.SMTOProseActivity.preference(turn.conversationId, false);
    turn.timeline.replaceChildren();
    window.SMTOProseActivity.resetAnswers(turn.timeline);
    turn.archivedAnswers = null;
    turn.checkObservations?.dispose(); turn.checkObservations = null;
    turn.previewClosed = false;
    turn.previewCall = "";
    turn.retained = null;
  }
  turn.createdAt = createdAt;
}
function archiveTurnAnswer(turn, answer) {
  (turn.archivedAnswers ||= new Map()).set(answer.id, answer.text.trim());
  const currentId = turn.retained?.id || turn.trace?.response_metrics?.final_response?.decision_id;
  if (currentId === answer.id && turn.text.trim() === answer.text.trim()) {
    turn.messageTimes?.clear();
    turn.retained = null; turn.text = ""; scheduleAnswer(turn);
  }
}
function scheduleAnswer(turn) {
  turn.dirty = true;
  if (frame) return;
  frame = requestAnimationFrame(() => {
    frame = 0;
    for (const current of turns.values())
      if (current.dirty && !current.disposed) {
        current.dirty = false;
        markdown(current.answer, current.text);
      }
    follow();
  });
}
function clearPreview(turn) {
  if (turn.retained) return;
  turn.messageTimes?.clear();
  turn.text = "";
  turn.previewClosed = true;
  turn.answer.removeAttribute("aria-busy");
  scheduleAnswer(turn);
}
export function summaryFor(turn) {
  taskDisclosure.refresh();
  refreshProse(turn);
  if (!["running", "waiting_job", "waiting_event", "paused", "paused_budget"].includes(turn.status)) {
    turn.inlineSteer?.updateStatus(turn.status);
  }
  turn.activity.dataset.running = String(["pending", "running", "waiting_job", "waiting_event"].includes(turn.status));
  const resumedPause = turn.status !== "paused"
    && turn.text.trim() === "Paused after the current action. Progress and results are preserved.";
  const resumedNotice = ["pending", "running", "waiting_job", "waiting_event"].includes(turn.status)
    && turn.transientNotice && turn.text === turn.transientNotice;
  const expiredWait = !turn.trace?.response_metrics?.final_response && !turn.trace?.native_profile?.final_response
    && window.SMTOTaskLifecycle.obsoleteWaitNotice(turn.text, turn.status);
  if ((expiredWait || resumedPause || resumedNotice) && turn.retained?.text !== turn.text) {
    turn.text = "";
    scheduleAnswer(turn);
  }
  const start = Date.parse(turn.serverTiming?.started_at || turn.createdAt);
  const observed = Date.parse(turn.serverTiming?.server_now);
  const serverNow = Number.isFinite(observed) ? observed + performance.now() - turn.timingObservedAt : null;
  const elapsedMs = terminal(turn.status) ? turn.durationMs : serverNow != null && Number.isFinite(start) ? serverNow - start : null;
  turn.elapsedMs = elapsedMs == null ? null : Math.max(0, elapsedMs);
  const seconds = elapsedMs != null ? Math.max(0, Math.round(elapsedMs / 1000)) : null;
  const elapsed = seconds ? ` for ${seconds}s` : "";
  const label =
    {
      completed: "Worked",
      answered: "Worked",
      failed: "Failed",
      cancelled: "Stopped",
      interrupted: "Interrupted",
      partial: "Incomplete",
      blocked: "Blocked",
      paused: "Paused",
      paused_budget: "Paused at limit",
      awaiting_confirmation: "Approval required",
      awaiting_resource_reconciliation: "Historical baseline decision needed",
      awaiting_clarification: "Your input is needed",
      waiting_user_confirmation: "Approval required",
      waiting_user: "Your input is needed",
      waiting_job: "Waiting for job",
      waiting_event: "Waiting for event",
    }[turn.status] || "Working";
  const failures = [...turn.operations.values()].filter(
    (op) => op.failed,
  ).length;
  const preparing = turn.schedulerWaiting
    ? turn.schedulerQueue === "controller" ? "Waiting for controller capacity…" : "Waiting for model capacity…" : turn.preflight?.size
    ? turn.preflight.size > 1 ? "Preparing…" : turn.preflight.has("model") ? "Preparing model…" : "Validating target…" : "";
  const latest = ["running", "pending"].includes(turn.status) ? preparing || turn.latest : "";
  const summary = `${label}${elapsed}${failures ? ` · ${failures} error${failures === 1 ? "" : "s"}` : ""}`;
  turn.activityStatus.hidden = terminal(turn.status);
  turn.historyLoader?.update(turn.status);
  const activity = turn.liveActivity;
  activity.executionStatus = turn.executionStatus;
  window.SMTORunActivity.setStatus(activity, turn.status, {authoritative: true});
  if (turn.replyResume) activity.resuming = turn.replyResume.pending;
  const live = window.SMTORunActivity.resolve(activity);
  const liveLabel = terminal(turn.status) ? "" : live.label || latest || label;
  window.SMTORunActivity.renderStatus(turn.activityStatus, {...live, label: liveLabel}, turn.activityStatusLabel);
  window.SMTORunActivity.renderDetail(turn.activityStatusDetail, live, {animateNumbers: true});
  if (!turn.waitControls) {
    turn.waitControls = window.SMTOWaitControls.create({requestId: turn.id,
      submit: (id, payload, signal) => api(`/api/agent/native/${encode(id)}/wait/control`, {method: "POST", body: payload, signal}),
      refresh: (id, signal) => api(`/api/agent/native/${encode(id)}?view=compact`, {signal}),
      accept: snapshot => {
        if (snapshot.state_revision < Math.max(turn.nativeRevision || 0, turn.run?.state_revision || 0)) return;
        turn.run = {...turn.run, ...snapshot}; turn.status = runStatus(snapshot);
        window.SMTORunActivity.setStatus(turn.liveActivity, turn.status, {...snapshot, authoritative: true,
          ...(snapshot.state_revision > (turn.nativeRevision || 0) ? {trace_event_id: undefined} : {})});
        turn.nativeRevision = snapshot.state_revision;
        summaryFor(turn);
      }, notify: notice});
    turn.activityStatus.append(turn.waitControls.root);
  }
  turn.waitControls.update(activity);
  window.SMTONumberOdometer.render(turn.summary, terminal(turn.status) ? summary : "Activity", {live: !terminal(turn.status)});
  turn.activity.dataset.failed = String(
    turn.status === "failed" || failures > 0,
  );
}
function appendTimeline(turn, root, event) {
  const mainRail = root.matches(".prose-activity, .steering-milestone, .conversation-message");
  if (!root.parentElement && !mainRail
      && (!turn.activeProse || !turn.timeline.contains(turn.activeProse.root))) {
    turn.activeProse = window.SMTOProseActivity.working(turn.timeline,
      {conversationId: turn.conversationId});
    turn.activity.classList.add("progress-timeline");
    turn.activity.open = true;
  }
  const container = root.parentElement || (mainRail ? turn.timeline : turn.activeProse.items);
  const sequence = Number(event.id ?? event.index);
  if (Number.isFinite(sequence)) {
    const at = Date.parse(event.timestamp);
    const compare = row => {
      const previousAt = Number(row.dataset.traceAt);
      return Number.isFinite(previousAt) && Number.isFinite(at)
        ? previousAt - at || Number(row.dataset.traceSequence) - sequence
        : Number(row.dataset.traceSequence) - sequence;
    };
    if (root.dataset.traceSequence && compare(root) <= 0) return;
    root.dataset.traceSequence = String(sequence);
    root.dataset.traceAt = String(at);
    const next = [...container.children].find(row =>
      row !== root && compare(row) > 0);
    container.insertBefore(root, next || null);
  } else if (!root.isConnected) container.append(root);
}

function refreshProse(turn) {
  const entries = window.SMTOProseActivity.entries(turn.timeline, turn.narrations);
  for (const [index, entry] of entries.entries()) {
    const facts = [...turn.operations.values()].filter(op => entry.view.items.contains(op.root)).map(op => {
      const failed = op.failed || Number.isInteger(op.exitCode) && op.exitCode !== 0;
      return {running: op.root.dataset.running === "true", failed,
        succeeded: op.shell ? !failed && op.finished && (!op.shellState || op.shellState === "Completed") : op.outcome === "success"};
    });
    for (const model of turn.modelOutputs?.values() || []) {
      if (entry.view.items.contains(model.root)) facts.push({running: model.status === "running",
        failed: model.status === "failure", succeeded: model.status === "success", model: true});
    }
    window.SMTOProseActivity.update(entry.view, facts,
      {status: turn.status, closed: entry.closed, last: index === entries.length - 1});
  }
}

function operation(turn, event) {
  const type = event.event_type,
    id = event.detail?.invocation_id || event.detail?.operation_id || event.detail?.action_id || event.id;
  let op = turn.operations.get(id);
  event = activityPresentation.merge(op?.event, event);
  const d = event.detail || {};
  // A delayed preview cannot regress a terminal attempt or a newer checkpoint.
  if (op && ["task_contract.started", "task_contract.progress"].includes(type) && (op.finished || (
    Number((d.detail_version || "").split(":")[1] || 0) < Number((op.version || "").split(":")[1] || 0)
  ))) return;
  if (!op) {
    const root = node("div", null, "operation"),
      title = node("div", null, "operation-title"),
      preview = node("p", null, "operation-preview");
    root.append(title, preview);
    op = { root, title, preview };
    turn.operations.set(id, op);
  }
  op.event = event;
  appendTimeline(turn, op.root, event);
  op.shell ||= d.kind === "shell_command" || d.capability_id === "shell.command";
  op.failed =
    op.failed ||
    type.endsWith(".failed") || type === "task_contract.attempt_failed" ||
    type.endsWith(".error") ||
    ["failed", "error", "outcome_unknown"].includes(d.status) ||
    (!op.shell && typeof d.exit_code === "number" && d.exit_code !== 0);
  if (op.shell && type === "execution.command.completed") {
    op.failed = ["failed_to_start", "outcome_unknown", "timed_out"].includes(d.process_state)
      || d.executed === false || d.error_kind === "unknown_effect";
  }
  op.finished = op.finished || /\.(completed|failed|cancelled)$/.test(type)
    || ["task_contract.clarification_required", "task_contract.attempt_failed"].includes(type);
  op.root.dataset.failed = String(Boolean(op.failed));
  const p = d.presentation || {};
  const outcome = activityPresentation.outcome(event, op.outcome);
  if (!op.shell) {
    op.failed = outcome === "failure";
    op.finished = ["success", "failure", "cancelled", "incomplete"].includes(outcome);
    op.root.dataset.failed = String(op.failed);
  }
  const name = !op.shell ? activityPresentation.describe(event, outcome).rich :
    (op.failed ? p.compact_failed_label || p.failed_label
      : op.finished ? p.compact_completed_label || p.completed_label
      : p.compact_running_label || p.running_label) ||
    p.skill_label ||
    d.label ||
    d.capability_id ||
    d.tool_name ||
    (type.startsWith("execution.command") ? "Shell" : "Operation");
  // Retain number columns while status marks and action icons are redecorated.
  op.numberLabel ||= node("span");
  window.SMTONumberOdometer.render(op.numberLabel, `${op.failed ? "! " : ""}${name}${d.elapsed_ms != null ? ` · ${(d.elapsed_ms / 1000).toFixed(1)}s` : ""}${d.exit_code != null && d.exit_code !== 0 ? ` · exit ${d.exit_code}` : ""}`);
  op.title.replaceChildren(op.numberLabel);
  if (!op.failed && op.finished && (op.shell || outcome === "success")) {
    const mark = node("span", "✓"); mark.dataset.uiSymbol = "check";
    op.title.prepend(mark, document.createTextNode(" "));
  }
  if (op.shell) {
    if (d.execution_target) op.executionTarget = d.execution_target;
    if (d.transport_gateway) op.transportGateway = d.transport_gateway;
    if (d.privilege) op.privilege = d.privilege;
    if (d.exit_code != null) op.exitCode = d.exit_code;
    if (type === "execution.command.started" && !op.finished) op.shellState = "Running";
    if (type.endsWith(".failed") || type.endsWith(".error")) op.shellState = "Failed";
    if (type === "execution.command.terminal_input_required") op.shellState = "Waiting for terminal input";
    if (type === "execution.command.resource_wait") op.shellState = "Waiting for resource · Not started";
    if (type === "execution.command.resource_admitted") op.shellState = "Starting command";
    // Invocation results also settle commands when a stream/replay omits the
    // lower-level completion event. A background launch is still in progress.
    const shellResult = type === "execution.command.completed" || type === "invocation.completed"
      && !["running", "starting"].includes(d.process_state)
      && (d.process_state || Number.isInteger(d.exit_code));
    if (shellResult) op.shellState = d.terminal_detached ? "Running in terminal"
      : d.process_state === "timed_out" ? "Timed out" : d.process_state === "cancelled" ? "Cancelled"
        : d.process_state === "outcome_unknown" || d.error_kind === "unknown_effect" ? "Outcome unknown"
          : d.process_state === "failed_to_start" ? "Failed"
          : d.executed === false ? "Not run" : d.process_state === "exited" || Number.isInteger(d.exit_code)
            ? "Completed" : "Outcome unknown";
    const state = op.shellState || (op.finished ? op.failed ? "Failed" : "Completed" : "Running");
    const target = op.executionTarget;
    const location = target?.label ? ` · ${target.label}${target.kind === "ssh_remote" ? ` via ${op.transportGateway?.label || "Gateway"}` : ""}${op.privilege?.elevated ? " · Elevated" : ""}` : "";
    op.numberLabel.textContent = `Shell · ${state}${op.exitCode != null ? ` · exit ${op.exitCode}` : ""}${location}`;
    op.title.replaceChildren(op.numberLabel);
    const failed = ["Failed", "Timed out"].includes(state);
    if (failed || state === "Completed") {
      const success = !failed && (op.exitCode == null || Number(op.exitCode) === 0);
      const mark = node("span", success ? "✓" : "×", "command-outcome");
      mark.dataset.outcome = success ? "success" : "failure";
      mark.dataset.uiSymbol = success ? "check" : "cross";
      mark.setAttribute("role", "img");
      mark.setAttribute("aria-label", success ? "Command succeeded" : "Command failed");
      mark.title = success ? "Command succeeded" : "Command failed";
      op.title.prepend(mark, document.createTextNode(" "));
    }
  }
  op.root.dataset.running = String(!op.failed && (op.shell
    ? !op.finished && (op.shellState || "Running") === "Running"
      || op.shellState === "Running in terminal"
    : outcome === "running"));
  activityPresentation.decorateLabel(op.numberLabel, event, outcome);
  op.outcome = outcome;
  op.iconKind = actionIcons.resolve(d, op.iconKind || (op.shell ? "shell" : "runtime"));
  actionIcons.decorateLabel(op.title, op.iconKind);
  // Only public presentation and bounded output are displayed, never model reasoning/arguments.
  const preview =
    (d.kind === "task_contract" ? d.status_text : "") ||
    p.trace_detail ||
    p.summary ||
    d.command ||
    d.error_summary ||
    event.summary;
  if (preview) op.preview.textContent = String(preview).slice(0, 1400);
  if (op.liveShell || (type === "execution.command.started" && d.kind === "shell_command")) {
    if (!op.liveShell) {
      const disclosure = node("details", null, "trace-output shell-live"),
        heading = node("summary", "Tool output"), panel = node("div");
      disclosure.append(heading, panel);
      activityPresentation.attachSection(op.root, disclosure, "Tool output");
      const live = {disclosure, panel, initialEvent: event};
      op.liveShell = live;
      disclosure.addEventListener("toggle", async () => {
 const busyFeedback = window.SMTOBusy?.action("Loading task controls…");
 try {
        if (!disclosure.open || turn.disposed || live.viewer || live.loading) return;
        live.loading = true;
        const loading = node("p", "Loading output…", "output-loading");
        loading.setAttribute("role", "status");
        panel.replaceChildren(loading);
        try {
          const {mountShellInspector} = await import("./lazy/shell_live_stream.js?v=20261018-loading");
          if (!disclosure.open || turn.disposed || !disclosure.isConnected) return;
          panel.replaceChildren();
          live.viewer = mountShellInspector({disclosure, panel, requestId: turn.id,
            operationId: String(d.operation_id || d.action_id), initialEvent: live.initialEvent});
          live.viewer.update(live.latestEvent);
        } catch (_) { panel.textContent = "Could not load live output. Close and reopen to retry."; }
        finally { live.loading = false; }

 } finally { busyFeedback?.finish(); }
});
    }
    op.liveShell.latestEvent = event;
    op.liveShell.viewer?.update(event);
  }
  turn.latest =
    (op.failed
      ? p.failed_label
      : op.finished
        ? p.completed_label
        : p.running_label) ||
    p.skill_label ||
    name;
  if (d.detail_available && !op.detail) {
    op.detail = node("details", null, "trace-output");
    const heading = node("summary", d.kind === "task_contract" ? "Task contract" : "Tool output"),
      body = node("div");
    op.detail.append(heading, body);
    activityPresentation.attachSection(op.root, op.detail, op.liveShell ? "Details" : heading.textContent);
    op.load = async () => {
      if (!op.detail.open || turn.disposed) return;
      const version = op.version;
      if (!body.childNodes.length) {
        const loading = node("p", "Loading output…", "output-loading");
        loading.setAttribute("role", "status");
        body.append(loading);
      }
      try {
        const { loadDetail } = await import("./lazy/trace_details.js?v=20261018-loading");
        if (!turn.disposed) await loadDetail(body, turn.id, id, version, retryContract,
          () => !turn.disposed && version === op.version);
        if (version !== op.version) await op.load();
      } catch {
        body.replaceChildren(
          node(
            "p",
            "Couldn’t load output. Close and reopen to retry.",
            "muted",
          ),
        );
      }
    };
    op.detail.addEventListener("toggle", () => void op.load());
  }
  if (d.detail_available) {
    op.version = d.detail_version || "completed";
    if (op.detail.open) void op.load();
  }
}
function compaction(turn, event) {
  const d = event.detail || {};
  const mode = d.mode || (event.event_type === "context.manual_compacted" ? "manual" : "");
  const title = mode === "manual" ? "Context compacted manually" : "Context compacted";
  const valid = value => Number.isFinite(value) && value >= 0;
  const compact = value => value < 1000 ? String(value) : `${Number((value / 1000).toFixed(1))}k`;
  const exact = value => value.toLocaleString("en-US");
  const counts = valid(d.tokens_before) && valid(d.tokens_after)
    ? `${compact(d.tokens_before)} → ${compact(d.tokens_after)}` : "";
  const root = node("div", null, "operation context-compaction-row");
  const heading = node("div", ` ${title}${counts ? ` · ${counts}` : ""}`, "operation-title");
  const mark = node("span", "✓"); mark.dataset.uiSymbol = "check";
  heading.prepend(mark);
  actionIcons.decorateLabel(heading, "context");
  const trigger = {automatic: "Automatic", manual: "Manual", overflow_recovery: "Context-limit recovery"}[mode];
  heading.setAttribute("aria-label", [title, trigger, counts ? `${exact(d.tokens_before)} to ${exact(d.tokens_after)} tokens` : ""].filter(Boolean).join(" · "));
  root.append(heading);
  const disclosure = node("details", null, "context-compaction"), body = node("div");
  disclosure.append(node("summary", "Event details"), body);
  const facts = node("dl", null, "context-compaction-facts");
  const fact = (label, value) => facts.append(node("dt", label), node("dd", value));
  if (trigger) fact("Trigger", trigger);
  for (const [label, value, estimated] of [
    ["Before", d.tokens_before, d.tokens_before_estimated],
    ["After", d.tokens_after, d.tokens_after_estimated], ["Target", d.target_tokens],
  ]) if (valid(value)) fact(label, `${exact(value)} tokens${estimated === true ? " (estimated)" : ""}`);
  if (valid(d.history_turns_omitted)) fact("Older turns", `${exact(d.history_turns_omitted)} omitted from active context`);
  else if (valid(d.older_turns_omitted)) fact("Older turns", `${exact(d.older_turns_omitted)} omitted in total`);
  if (valid(d.tool_groups_pruned_now)) fact("Tool groups", `${exact(d.tool_groups_pruned_now)} pruned from active context`);
  else if (valid(d.tool_groups_pruned)) fact("Tool groups", `${exact(d.tool_groups_pruned)} pruned in total`);
  body.append(facts);
  if (d.exact_history_retained === true)
    body.append(node("p", "Exact conversation and execution history was retained. Older details remain available if needed."));
  activityPresentation.attachSection(root, disclosure, "Event details", 2);
  appendTimeline(turn, root, event);
}

function modelOutput(turn, event) {
  const detail = event.detail || {}, type = event.event_type;
  if (!detail.call_id || !["llm.request", "llm.response", "llm.error", "llm.cancelled"].includes(type)) return;
  turn.modelOutputs ||= new Map();
  let entry = turn.modelOutputs.get(detail.call_id);
  if (!entry) {
    const root = node("div", null, "model-output-step"), title = node("p", "Model output", "model-step");
    root.append(title);
    void import("../model_output_inspector.js?v=20261018-loading").then(() => {
      if (root.isConnected && !turn.disposed) window.SMTOModelOutput.attach(root, turn.id, detail.call_id);
    });
    entry = {root, title}; turn.modelOutputs.set(detail.call_id, entry);
    appendTimeline(turn, root, event);
  }
  const label = type === "llm.error" ? "Model output · Failed" : type === "llm.cancelled" ? "Model output · Stopped"
    : type === "llm.response" ? "Model output · Completed" : "Model output · Generating";
  entry.title.textContent = label;
  activityPresentation.decorateLabel(entry.title, event, activityPresentation.outcome(event));
  actionIcons.decorateLabel(entry.title, "thinking");
  entry.status = {"llm.error": "failure", "llm.cancelled": "incomplete", "llm.response": "success"}[type] || "running";
}

export function applyEvent(turn, event) {
  if (turn.disposed || (event.request_id && event.request_id !== turn.id)) return;
  const key = String(event.detail?.capability_event_id || event.detail?.agent_check_observation_id || event.event_id || event.id || "");
  turn.cursor = Math.max(turn.cursor, Number(event.id) || 0);
  if (key && turn.seen.has(key)) return;
  if (key) turn.seen.add(key);
  if (event.event_type === "task_context.source_available") {
    turn.savedTaskContext?.source(event.detail || {});
    return;
  }
  if (event.event_type === "task_context.context_submitted" || event.event_type === "run.failed") void turn.savedTaskContext?.refresh();
  const context = event.detail?.llm_context_usage || event.detail?.runtime_profile?.llm_context_usage;
  if (context) turn.contextUsage = context;
  if (event.detail?.token_usage || context) {
    turn.tokenTotals = window.SMTOResponseTokens.latest(turn.tokenTotals, event.detail.token_usage);
    turn.tokenUsage.hidden = !window.SMTOResponseTokens.render(turn.tokenUsage,
      {token_usage: turn.tokenTotals, llm_context_usage: turn.contextUsage});
  }
  turn.messageTimes?.event(event);
  turn.historyLoader?.event(event);
  const answeredWait = window.SMTOTaskLifecycle.observeReply(turn.replyResume, event);
  if (answeredWait && event.event_type !== "conversation.message") { summaryFor(turn); return; }
  event = activityPresentation.operationEvent(event);
  const d = event.detail || {},
    type = event.event_type || "";
  window.SMTOProseActivity.observeMonitoring(turn.timeline, event);
  const previousAnswer = turn.retained || (turn.trace?.response_metrics?.final_response
    ? {id: turn.trace.response_metrics.final_response.decision_id, text: turn.text, startedAt: turn.messageTimes?.startedAt()} : null);
  if (window.SMTOProseActivity.answerBoundary(turn.timeline, event, markdown, previousAnswer,
    answer => archiveTurnAnswer(turn, answer))) {
    turn.messageTimes?.clear();
    turn.retained = null; turn.transientNotice = null;
    clearPreview(turn);
    turn.activeProse = null;
    turn.activity.classList.add("progress-timeline"); turn.activity.open = true;
  }
  turn.liveActivity.executionStatus = turn.executionStatus;
  if (!answeredWait) window.SMTORunActivity.reduce(turn.liveActivity, event);
  turn.executionStatus = turn.liveActivity.executionStatus;
  modelOutput(turn, event);
  const rejection = window.SMTOProseActivity.policyRejection(event);
  if (rejection) {
    turn.policyRejections ||= new Map();
    const row = turn.policyRejections.get(rejection.key) || node("section", null, "model-step");
    turn.policyRejections.set(rejection.key, row);
    row.dataset.policyRejection = "true";
    row.replaceChildren(node("strong", rejection.title), node("p", rejection.summary));
    if (!row.isConnected) appendTimeline(turn, row, event);
    turn.latest = rejection.title;
  }
  if (type.startsWith("activity.supervision.")) {
    const group = window.SMTOProseActivity.monitoring(turn.timeline, event);
    if (group) turn.activeProse = group;
    turn.activity.classList.add("progress-timeline");
    turn.activity.open = true;
    boundLiveActivity(turn.timeline, [turn.operations, turn.narrations, turn.modelOutputs, turn.policyRejections]);
    summaryFor(turn);
    follow();
    return;
  }
  if (type === "conversation.message") {
    const message = window.SMTOProseActivity.message(turn.timeline, event, markdown);
    if (message) {
      appendTimeline(turn, message, event);
      turn.activeProse = null;
      turn.activity.classList.add("progress-timeline");
      turn.activity.open = true;
      if (d.role === "assistant") {
        (turn.conversationQuestions ||= new Set()).add(d.content.trim());
        for (const question of turn.actions.querySelectorAll(".clarification-question")) {
          question.hidden = turn.conversationQuestions.has(question.dataset.questionSource.trim());
        }
        if (turn.conversationQuestions.has(turn.text.trim())) { turn.text = ""; scheduleAnswer(turn); }
      }
    }
    boundLiveActivity(turn.timeline, [turn.operations, turn.narrations, turn.modelOutputs, turn.policyRejections]);
    return;
  }
  if (type === "user.steered") {
    const marker = window.SMTOProseActivity.steering(turn.timeline, event);
    if (marker) {
      appendTimeline(turn, marker, event);
      turn.activeProse = null;
    }
  }
  if (["run.steer_queued", "run.steer_cancelled"].includes(type)) {
    const label = node("p", type === "run.steer_cancelled" ? "Steer cancelled" : "Steering requested", "muted");
    actionIcons.decorateLabel(label, "user");
    appendTimeline(turn, label, event);
  } else if (["context.working_set_pruned", "context.manual_compacted"].includes(type)) {
    compaction(turn, event);
  } else if (
    type === "agent.progress.narration" &&
    d.decision_id &&
    Number.isInteger(d.sequence)
  ) {
    let entry = turn.narrations.get(d.decision_id);
    if (!entry) {
      entry = { sequence: 0, text: "", root: null };
      turn.narrations.set(d.decision_id, entry);
    }
    if (d.sequence > entry.sequence) {
      entry.sequence = d.sequence;
      if (d.phase === "blocked") {
        if (entry.view) {
          window.SMTOProseActivity.withdraw(entry.view);
          entry.view = null;
        }
        entry.root = null;
        entry.text = "";
        entry.closed = true;
        if (!turn.timeline.querySelector(".prose-activity, .conversation-message")) {
          turn.activity.classList.remove("progress-timeline");
          turn.activity.open = window.SMTOProseActivity.preference(turn.conversationId, false);
        }
      } else if (d.phase === "completed") entry.closed = true;
      else if (
        !entry.closed &&
        d.phase === "delta" &&
        typeof d.content === "string"
      ) {
        entry.text += d.content;
        if (!entry.root && entry.text.trim()) {
          entry.root = node("div", null, "narration");
          entry.root.dataset.decisionId = d.decision_id;
          entry.view = window.SMTOProseActivity.promoteWorking(turn.activeProse,
            {decisionId: d.decision_id, block: entry.root, timestamp: event.timestamp});
          if (!entry.view) {
            entry.view = window.SMTOProseActivity.create({conversationId: turn.conversationId,
              decisionId: d.decision_id, block: entry.root, timestamp: event.timestamp});
            const previous = turn.activeProse?.items || turn.timeline;
            const leading = [];
            // Adopt this decision's new model rows without taking completed
            // results away from the preceding activity.
            while (previous.lastElementChild?.matches(".model-output-step, .model-step")
                && !previous.lastElementChild.dataset.proseDecisionId
                && !previous.lastElementChild.dataset.supervision) {
              leading.unshift(previous.lastElementChild); previous.lastElementChild.remove();
            }
            if (!turn.activeProse) {
              leading.unshift(...window.SMTOProseActivity.leadingItems(turn.timeline));
            }
            entry.view.items.append(...leading);
          }
          for (const row of entry.view.items.children) row.dataset.proseDecisionId = d.decision_id;
          appendTimeline(turn, entry.view.root, event);
          turn.activeProse = entry.view;
          turn.activity.classList.add("progress-timeline");
          turn.activity.open = true;
        }
        if (entry.root) markdown(entry.root, entry.text);
      }
    }
  } else if (
    type === "agent.final_response.retained" &&
    d.decision_id &&
    Number.isInteger(d.sequence) &&
    typeof d.content === "string"
  ) {
    if (turn.retained?.id !== d.decision_id)
      turn.retained = { id: d.decision_id, sequence: 0, text: "" };
    if (d.sequence === turn.retained.sequence + 1) {
      turn.retained.sequence = d.sequence;
      turn.retained.text += d.content;
      if (turn.retained.text.trim()) turn.messageTimes?.retain(event);
      turn.retained.startedAt = turn.messageTimes?.startedAt() || d.started_at || event.timestamp;
      turn.text = turn.retained.text;
      turn.previewClosed = true;
      turn.answer.removeAttribute("aria-busy");
      scheduleAnswer(turn);
    }
  } else if (
    type.startsWith("invocation.") ||
    (["task_contract.started", "task_contract.progress", "task_contract.attempt_failed", "task_contract.failed", "task_contract.completed", "task_contract.clarification_required"].includes(type)
      && d.detail_available) ||
    /^execution\.command\.(started|completed|failed|error|cancelled|terminal_input_required)$/.test(type)
  ) {
    operation(turn, event);
    if (type === "invocation.started") clearPreview(turn);
  } else if (
    ["model.started", "request.running", "run.resumed"].includes(type) ||
    (type === "llm.request" && event.stage === "native_decision")
  ) {
    if (!turn.retained) {
      clearPreview(turn);
      turn.previewClosed = false;
      turn.previewCall = d.call_id || "";
    }
    turn.status = "running";
    turn.latest = type === "model.started" ? "Thinking…" : "";
    if (type === "model.started") {
      turn.thinking = node("p", "Thinking…", "model-step");
      activityPresentation.decorateLabel(turn.thinking, event, "running");
      actionIcons.decorateLabel(turn.thinking, "thinking");
      appendTimeline(turn, turn.thinking, event);
    }
  } else if (type === "model.finished" && turn.thinking) {
    turn.thinking.textContent = `Thinking${Number.isFinite(d.wait_seconds) ? ` · ${d.wait_seconds.toFixed(1)}s` : ""}`;
    activityPresentation.decorateLabel(turn.thinking, event, "success");
    actionIcons.decorateLabel(turn.thinking, "thinking");
  } else if (
    type === "llm.response.delta" &&
    d.user_facing_stream === true &&
    !turn.retained
  ) {
    if (d.invalidated && (!turn.previewCall || turn.previewCall === d.call_id))
      clearPreview(turn);
    else if (
      !turn.previewClosed &&
      !terminal(turn.status) &&
      (!turn.previewCall || turn.previewCall === d.call_id) &&
      typeof d.user_facing_text === "string"
    ) {
      turn.previewCall = d.call_id || turn.previewCall;
      turn.text = d.user_facing_text;
      if (turn.text.trim()) turn.messageTimes?.preview(event);
      turn.answer.setAttribute("aria-busy", "true");
      scheduleAnswer(turn);
    }
  } else if (
    [
      "llm.error",
      "model.rejected",
      "completion.rejected",
      "provider.response_rejected",
      "model.response_discarded_for_pause",
      "model.response_discarded_for_steering",
      "user.steered",
      "run.paused",
      "request.failed",
      "request.cancelled",
      "request.interrupted",
    ].includes(type)
  ) {
    if (type === "completion.rejected"
        && d.reason === "terminal_continuation_requires_ask_user") {
      turn.retained = null;
    }
    if (!d.final_content_preserved) clearPreview(turn);
  }
  if (type === "agent_check.observed") {
    turn.checkObservations = window.SMTOAgentChecks.observationGroup(turn.detailActions, turn.checkObservations, turn.results);
    const card = window.SMTOAgentChecks.observationCard(turn.checkObservations.items, d);
    appendTimeline(turn, card, event);
  }
  const researchNotice = window.SMTOProseActivity?.researchNotice(event);
  if (researchNotice) {
    const notice = node("p", researchNotice.title, "model-step research-status");
    notice.dataset.researchNotice = "true";
    notice.dataset.status = researchNotice.warning ? "blocked" : "completed";
    appendTimeline(turn, notice, event);
  }
  if (type.startsWith("capability_selection.")) {
    const title = d.label || event.title || (type.endsWith("started") ? "Selecting capabilities" : "Capabilities updated");
    const selected = d.selected_skill_ids || [];
    const summary = [title,
      title.endsWith(` · ${selected.join(", ")}`) ? "" : selected.join(" · "),
      d.dependency_tool_ids?.length ? `Required tools: ${d.dependency_tool_ids.join(", ")}` : "",
      d.unavailable_skill_ids?.length ? `Unavailable: ${d.unavailable_skill_ids.join(", ")}` : "",
      d.added_skill_ids?.length ? `Added: ${d.added_skill_ids.join(", ")}` : "",
      d.removed_skill_ids?.length ? `Removed: ${d.removed_skill_ids.join(", ")}` : ""].filter(Boolean).join(". ");
    const notice = node("p", summary, "model-step capability-selection-status");
    activityPresentation.decorateLabel(notice, {...event, detail: {...d, label: summary}}, activityPresentation.outcome(event));
    actionIcons.decorateLabel(notice, "user");
    appendTimeline(turn, notice, event);
  }
  if (type.startsWith("capability_") && !type.startsWith("capability_selection.")) {
    const summary = [event.title || "Capability update", d.requested_skill_ids?.join(" · "),
      d.reason?.replaceAll("_", " ")].filter(Boolean).join(". ");
    const notice = node("p", summary, "model-step capability-lifecycle-status");
    activityPresentation.decorateLabel(notice, {...event, detail: {...d, label: summary}}, activityPresentation.outcome(event));
    actionIcons.decorateLabel(notice, "user");
    appendTimeline(turn, notice, event);
  }
  if (["task_contract.started", "task_contract.recovery_started", "task_contract.completed",
    "task_contract.failed", "task_contract.clarification_required"].includes(type)) {
    let notice = "Generating task contract";
    if (type === "task_contract.recovery_started" || (type === "task_contract.started" && d.auto_retry_index)) {
      const limit = type === "task_contract.recovery_started" ? d.next_max_tokens : d.effective_max_tokens;
      notice = taskContractRecoveryNotice(d, limit);
    } else if (type === "task_contract.completed") notice = "Task contract generated";
    else if (type === "task_contract.clarification_required") notice = "Task contract needs clarification";
    else if (type === "task_contract.failed") notice = d.auto_recovery
      && d.auto_retry_index === d.configured_auto_retries
      && d.transport_started !== false
      && !["cancelled", "stale_source_revision", "interrupted_compilation", "recovery_deadline"].includes(d.reason)
      ? "Task contract automatic recovery exhausted" : "Task contract generation failed";
    turn.contractProgress ||= node("p", null, "model-step");
    turn.contractProgress.textContent = notice;
    actionIcons.decorateLabel(turn.contractProgress, "file");
    appendTimeline(turn, turn.contractProgress, event);
    turn.latest = notice;
  }
  if (type.startsWith("request.preflight_")) {
    turn.preflight ||= new Set();
    if (type === "request.preflight_model_started") turn.preflight.add("model");
    if (type === "request.preflight_gateway_started") turn.preflight.add("gateway");
    if (type === "request.preflight_model_completed") turn.preflight.delete("model");
    if (type === "request.preflight_gateway_completed") turn.preflight.delete("gateway");
    if (["request.preflight_completed", "request.preflight_failed"].includes(type)) turn.preflight.clear();
  }
  if (type === "llm.scheduler_wait.started") {
    turn.schedulerWaiting = true;
    turn.schedulerQueue = d.queue === "agent_turn" ? "controller" : "model";
  }
  if (type === "llm.scheduler_wait.completed") turn.schedulerWaiting = false;
  if (["llm.request", "tool.started"].includes(type)) { turn.schedulerWaiting = false; turn.preflight?.clear(); }
  if (type === "llm.request" && event.stage === "native_decision") turn.latest = "Thinking…";
  if (type === "model.started") turn.contractProgress?.remove();
  if (type === "run.paused") turn.status = "paused";
  if (/^request\.(completed|failed|cancelled|interrupted)$/.test(type)) {
    turn.previewClosed = true;
  }
  boundLiveActivity(turn.timeline, [turn.operations, turn.narrations, turn.modelOutputs, turn.policyRejections]);
  if (turn.activeProse && !turn.timeline.contains(turn.activeProse.root)) turn.activeProse = null;
  summaryFor(turn);
  follow();
}
export function applyTrace(turn, trace, { historical = false } = {}) {
  setTurnActivityLineage(turn, trace);
  turn.replyResume ||= window.SMTOTaskLifecycle.restoreReply(trace);
  if (window.SMTOTaskLifecycle.observeReply(turn.replyResume, trace)) {
    summaryFor(turn); onAction(turn, turn.trace || {});
    return;
  }
  if (typeof trace.prompt === "string" && (turn.prompt !== trace.prompt || turn.attachments !== trace.attachments
      || turn.userAuthored !== Boolean(trace.prompt || trace.attachments?.length))) {
    turn.prompt = trace.prompt;
    turn.attachments = trace.attachments;
    turn.userAuthored = Boolean(trace.prompt || trace.attachments?.length);
    turn.user.textContent = trace.prompt;
    turn.user.hidden = !turn.userAuthored;
    if (turn.userAuthored) turn.root.dataset.conversationTurnId = turn.id;
    else delete turn.root.dataset.conversationTurnId;
    turn.refreshSchedule?.();
    turn.refreshWorkflow?.();
    refreshNavigator();
  }
  renderApprovedPlan(turn, trace);
  resetCursor(turn, trace.created_at);
  turn.messageTimes?.restore(trace);
  turn.status = runStatus(trace) || turn.status;
  const events = trace.events?.length ? trace.events : trace.visualization_snapshot?.events || [];
  for (const event of events) applyEvent(turn, event);
  turn.status = runStatus(trace) || turn.status;
  turn.historyMissing = !turn.historyLoaded && !events.length;
  if (turn.historyMissing && (trace.response_metrics?.conversation_message_count || trace.clarification_required)) turn.activity.open = true;
  // A summary's high-water mark does not mean those events were delivered.
  // Advancing past it can skip a fast continuation after an authority reply.
  if (Array.isArray(trace.events))
    turn.cursor = Math.max(turn.cursor, Number(trace.last_event_id || 0));
  turn.trace = trace;
  turn.tokenTotals = window.SMTOResponseTokens.latest(turn.tokenTotals, trace.response_metrics?.token_usage);
  turn.contextUsage = trace.native_profile?.llm_context_usage || trace.response_metrics?.llm_context_usage || turn.contextUsage;
  turn.tokenUsage.hidden = !window.SMTOResponseTokens.render(turn.tokenUsage,
    {...trace.response_metrics, llm_context_usage: turn.contextUsage,
      ...(turn.tokenTotals ? {token_usage: turn.tokenTotals} : {})});
  const serverTiming = trace.request_runtime_timing || trace.runtime_timing || trace.timing;
  if (serverTiming && serverTiming.server_now !== turn.serverTiming?.server_now) {
    turn.serverTiming = serverTiming; turn.timingObservedAt = performance.now();
    const serverNow = Date.parse(serverTiming.server_now);
    if (Number.isFinite(serverNow)) window.SMTOStreamActivity.syncClock(turn.liveActivity.streamActivity, serverNow);
  }
  window.SMTOErrors?.mount(turn.root, trace.error_detail);
  if (terminal(turn.status)) turn.durationMs = trace.response_metrics?.duration_ms ?? serverTiming?.duration_ms ?? null;
  else turn.durationMs = null;
  if (terminal(turn.status)) {
    turn.previewClosed = true;
    turn.answer.removeAttribute("aria-busy");
  }
  const archived = turn.archivedAnswers?.get(trace.response_metrics?.final_response?.decision_id);
  if ((trace.final_response || terminal(turn.status)) && archived !== String(trace.final_response || "").trim()) {
    turn.text =
      trace.final_response ||
      turn.retained?.text ||
      (trace.error
        ? typeof trace.error === "string"
          ? trace.error
          : trace.error.message || "This task failed."
        : ["cancelled", "interrupted"].includes(turn.status)
          ? "Run stopped."
          : "");
    if (turn.conversationQuestions?.has(turn.text.trim()) && !terminal(turn.status)) turn.text = "";
    const outcome = trace.response_metrics?.native_outcome || runStatus(trace);
    const retained = trace.response_metrics?.final_response || trace.native_profile?.final_response
      || turn.retained?.text === turn.text;
    if (!retained && ["partial", "blocked", "failed", "paused_budget"].includes(outcome)) {
      turn.transientNotice = turn.text;
    } else if (retained || turn.transientNotice !== turn.text) turn.transientNotice = null;
    scheduleAnswer(turn);
  }
  if (trace.display_document)
    void import("./lazy/trace_details.js?v=20261018-loading")
      .then((module) => {
        if (!turn.disposed)
          module.renderResults(turn.results, trace.display_document, turn.text);
      })
      .catch(() => {
        if (!turn.disposed)
          turn.results.replaceChildren(
            node("p", "Result details are temporarily unavailable.", "muted"),
          );
      });
  summaryFor(turn);
  onAction(turn, trace);
  follow();
}
export async function renderActions(turn, trace, run, hooks) {
  if (!turn.inlineSteer) {
    turn.inlineSteer = window.SMTOInlineSteer.create({requestId: turn.id, conversationId: () => turn.conversationId,
      getEnterAction: () => state.settings.ui_task_reply_enter_action,
      queue: window.SMTOFollowupQueue.create({requestId: turn.id, actionContainer: turn.detailActions,
        host: turn.controls, notify: notice, apiJson: (url, options = {}) => api(url, {...options,
          ...(typeof options.body === "string" ? {body: JSON.parse(options.body)} : {})})}),
      submit: hooks.steer, cancel: hooks.cancelSteer, followup: hooks.followup, reconcile: hooks.refresh, notify: notice,
      onAccepted: async ({mode}) => {
        if (mode === "queue") return;
        await closeSheet(); requestAnimationFrame(() => { if (!turn.disposed) follow(true); });
      },
    });
    // Optional steering/continuation lives in Message details. Required replies stay in turn.actions.
    turn.controls.append(turn.inlineSteer.root);
  }
  const head = state.lane?.tasks?.find(task => task.task_id === turn.taskId)?.latest_request_id;
  const continuedBy = turn.continuedBy || (head && head !== turn.id ? head : null);
  turn.inlineSteer.update({...run,
    ...(continuedBy ? {continued_by: {request_id: continuedBy}} : {}),
    status: run?.status || turn.status,
  });
  turn.artifacts?.update(run?.artifact_summary);
  if (turn.responseActions) turn.responseActions.hidden = !turn.executionInspector && !turn.answer.textContent && !run?.artifact_summary?.count
    && !(turn.userAuthored && promptSchedules.eligible(turn.prompt));
  if (run && (run.activity_batches?.length || run.resource_metrics || run.foreground_operation)) {
    const {activities} = await import("./lazy/activities.js?v=20261018-loading");
    if (turn.disposed || turn.run !== run) return;
    if (!turn.activities) { turn.activities = node("div", "", "task-foreground-activities"); turn.controls.append(turn.activities); }
    activities(turn.activities, run, {requestId: turn.id,
      apiJson: (url, options = {}) => api(url.replace("/api/agent/", ""), {
        ...options, ...(options.body ? {body: JSON.parse(options.body)} : {})}),
      refresh: () => hooks.refresh(), notify: message => hooks.notify?.(message),
      stop: () => void hooks.control("cancel", {}, turn.id)});
  }
  if (!turn.lifecycle) {
    turn.lifecycle = window.SMTOTaskLifecycle.create({requestId: turn.id, mobile: true,
      dispatch: (action, id) => void hooks.control(action, {}, id)});
    turn.controls.append(turn.lifecycle.root);
  }
  turn.lifecycle.update({request_id: turn.id,
    status: terminal(turn.status) ? turn.status : run?.status || turn.status, snapshot: run}, {
    stopping: ["cancel", "stop_next"].includes(turn.lifecyclePending),
    pausing: turn.lifecyclePending === "pause",
    resuming: turn.lifecyclePending === "resume",
    continuing: turn.lifecyclePending === "continue",
    restarting: turn.lifecyclePending === "restart",
    advancing: ["continue_next", "stop_next"].includes(turn.lifecyclePending),
    settled: terminal(turn.status) || (["partial", "blocked"].includes(turn.status) && terminal(trace?.status)),
  });
  turn.controls.hidden = turn.lifecycle.root.hidden && (!turn.inlineSteer || turn.inlineSteer.root.hidden);
  if (window.SMTOPlanMode.mount(turn.actions, trace, {
    conversationId: turn.conversationId, requestId: turn.id,
    apiJson: (url, options = {}) => api(url, {...options, ...(options.body ? {body: JSON.parse(options.body)} : {})}),
    active: () => !turn.disposed && turn.root.isConnected && state.conversationId === turn.conversationId,
    notify: notice, stay: async () => {
      await composerProfile.selectMode("plan");
      if (composerProfile.current().error) throw new Error(composerProfile.current().error);
    },
    accepted: async result => {
      await hooks.openConversation(result.conversation_id);
      if (state.conversationId === result.conversation_id) showPlanTask(result.task, {fresh: true});
    },
  })) return;
  const feedback =
    trace?.response_metrics?.final_response ||
    trace?.native_profile?.final_response;
  const waiting =
    trace?.clarification_required ||
    trace?.confirmation_required ||
    run?.oauth_authorization_request ||
    run?.unsafe_action_request ||
    run?.resource_reconciliation_request ||
    feedback?.feedback ||
    run?.foreground_operation?.long_running;
  const key = JSON.stringify([
    run?.status,
    trace?.clarification_required,
    trace?.clarification_request,
    trace?.confirmation_required,
    trace?.confirmation_actions,
    run?.oauth_authorization_request,
    run?.unsafe_action_request,
    run?.resource_reconciliation_request,
    run?.cancel_requested,
    feedback,
    run?.foreground_operation,
  ]);
  if (turn.actions.getAttribute("aria-busy") === "true") return;
  if (turn.actionKey === key) return;
  turn.actionKey = key;
  if (!waiting) {
    turn.actions.replaceChildren();
    return;
  }
  const module = await import("./lazy/interactions.js?v=20261018-loading");
  if (!turn.disposed && turn.actionKey === key)
    module.render(turn.actions, turn.id, trace, run, {...hooks, conversationQuestions: turn.conversationQuestions});
}
setInterval(() => {
  if (!document.hidden)
    for (const turn of turns.values())
      if (!terminal(turn.status)) summaryFor(turn);
}, 1000);
