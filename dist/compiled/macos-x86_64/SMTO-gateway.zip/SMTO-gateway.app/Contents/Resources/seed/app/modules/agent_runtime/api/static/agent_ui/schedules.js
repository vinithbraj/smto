/* A control surface over durable events. All schedule arithmetic belongs to the server. */
(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const session = window.SMTOUiSession;
  $("schedule-filter").value = session.get("schedule_status", "all");
  $("schedule-sort").value = session.get("schedule_sort", "next");
  const {dateText, browserZone} = window.SMTOScheduleTime;
  const {recurrenceText} = window.SMTOScheduleRecurrence;
  // Membership contract shared with events/selection.py and the list API default.
  const RECENT_RUN_SUMMARY_LIMIT = 5, SELECTION_LIMIT = 1000;
  const openStatuses = new Set(["queued", "running", "awaiting_confirmation", "awaiting_clarification", "paused", "paused_budget", "waiting_job", "waiting_event", "waiting_user", "blocked"]);
  const labels = {partial: "Partial", interrupted: "Interrupted", paused_budget: "Paused · budget", waiting_job: "Waiting for job", waiting_event: "Waiting for event", waiting_user: "Waiting for input", blocked: "Blocked", active: "Active", paused: "Paused", cancelled: "Cancelled", completed: "Completed", deleted: "Deleted", queued: "Queued", running: "Running", failed: "Failed", skipped: "Skipped", awaiting_confirmation: "Waiting for approval", awaiting_clarification: "Waiting for input"};
  const state = {events: [], runs: {}, activeRuns: {}, enabled: false, loaded: false, timezone: "UTC", expanded: new Set(), history: new Map(), busy: new Set(), errors: new Map(), cards: new Map(), selecting: false, allMatching: false, selected: new Set(), excluded: new Set()};
  let refreshPromise = null, refreshAgain = false, refreshTimer = null;
  let lifecycle = null, confirming = false;
  let bulkSelection = null, bulkPreview = null, bulkBusy = false, bulkStale = false, previewGeneration = 0;
  const editor = window.SMTOScheduleEditor.create({onSaved: refresh, enabled: () => state.enabled});
  const openEditor = event => editor.open(event);
  const updateSave = () => editor.updateSave();
  const focusReturns = new Map();
  const historyRequests = new Map(), historyDirty = new Set();

  function element(tag, className = "", text = "") {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  function button(text, onClick, className = "", name = text) {
    const node = element("button", className, text);
    node.type = "button";
    node.setAttribute("aria-label", name);
    node.addEventListener("click", onClick);
    return node;
  }
  const chip = status => element("span", `status-chip status-${status}`, labels[status] || "Unknown");
  function legalRunChip(run) {
    if (run.terminal_reason_code !== "eula_acceptance_required") return chip(run.status);
    const result = element("a", "status-chip", "Action required · Accept updated terms");
    result.href = "/settings#settings-section-legal";
    return result;
  }

  function message(id, text) { $(id).textContent = text; $(id).hidden = !text; }
  async function api(path, method = "GET", body) {
    const response = await window.SMTOErrors.fetch(`/api/agent/events${path}`, {method, headers: {"Content-Type": "application/json"}, ...(body === undefined ? {} : {body: JSON.stringify(body)})});
    let data;
    try { data = await response.json(); } catch (_error) { throw window.SMTOErrors.error("ui_response_invalid"); }
    if (!response.ok) {
      if (data.detail?.error_kind === "eula_acceptance_required") window.dispatchEvent(new Event("smto:eula-required"));
      const detail = Array.isArray(data.detail) ? data.detail.map(item => `${(item.loc || []).slice(1).join(" · ")}: ${item.msg}`).join("\n") : data.detail;
      const error = window.SMTOErrors.fromPayload(data, response.status);
      error.status = response.status; error.code = detail?.code;
      throw error;
    }
    return data;
  }
  const pathFor = event => `/${encodeURIComponent(event.event_id)}`;
  const isSelected = id => state.allMatching ? !state.excluded.has(id) : state.selected.has(id);
  function matchingEvents() {
    const search = $("schedule-search").value.trim().toLowerCase(), filter = $("schedule-filter").value;
    return state.events.filter(event => (!search || [event.title, event.prompt, event.notification_message].some(text => String(text || "").toLowerCase().includes(search))) && (filter === "all" || (filter === "failed" ? (state.runs[event.event_id] || []).slice(0, RECENT_RUN_SUMMARY_LIMIT).some(run => run.status === "failed") : event.status === filter)));
  }
  const selectedCount = () => state.allMatching ? matchingEvents().filter(event => isSelected(event.event_id)).length : state.selected.size;
  const selectionDescriptor = () => state.allMatching
    ? {all_matching: true, query: $("schedule-search").value.trim(), status: $("schedule-filter").value, excluded_ids: [...state.excluded]}
    : {event_ids: [...state.selected]};
  function cancelSelection() {
    state.selecting = false; state.allMatching = false; state.selected.clear(); state.excluded.clear();
    render();
  }
  function setSelected(ids, checked) {
    const current = state.allMatching ? state.excluded : state.selected, next = new Set(current);
    for (const id of ids) {
      if (state.allMatching ? !checked : checked) next.add(id); else next.delete(id);
    }
    if (next.size > SELECTION_LIMIT) {
      $("action-status").textContent = state.allMatching ? "You can exclude up to 1000 schedules. Narrow the search or status filter." : "Use Select all matching for a larger selection.";
      return false;
    }
    if (state.allMatching) state.excluded = next; else state.selected = next;
    return true;
  }
  function selectionChanged(visible) {
    $("schedule-select").hidden = state.selecting;
    $("schedule-select").disabled = !state.enabled;
    $("schedule-selection").hidden = !state.selecting || !state.enabled;
    const count = `${selectedCount()} selected`;
    if ($("schedule-selected-count").textContent !== count) $("schedule-selected-count").textContent = count;
    const shown = $("schedule-select-shown");
    shown.checked = Boolean(visible.length) && visible.every(event => isSelected(event.event_id));
    shown.indeterminate = !shown.checked && visible.some(event => isSelected(event.event_id));
    shown.disabled = !visible.length || !state.enabled;
    $("schedule-select-shown-label").textContent = `Select all ${visible.length} shown`;
    const all = $("schedule-select-matching");
    all.textContent = state.allMatching ? `All ${visible.length} matching selected` : `Select all ${visible.length} matching`;
    all.disabled = state.allMatching || !visible.length || !state.enabled;
    $("schedule-delete-selected").disabled = !state.enabled || selectedCount() === 0;
  }
  function nextFact(event) {
    const fact = element("dl", "run-fact");
    fact.append(element("dt", "", event.status === "paused" ? "Saved scheduled occurrence" : "Next run"));
    const value = element("dd");
    if (["cancelled", "completed", "deleted"].includes(event.status)) value.textContent = "No future run";
    else if (!event.next_run_at || !Number.isFinite(Date.parse(event.next_run_at))) {
      value.append(element("span", "schedule-warning", "Next trigger unavailable. Review this schedule."));
    } else {
      value.textContent = dateText(event.next_run_at);
      if (event.status === "paused") value.append(element("span", "schedule-warning", Date.parse(event.next_run_at) < Date.now() ? "Scheduled occurrence passed while paused" : "Paused · will not run automatically"));
      if (event.status === "paused") value.append(element("span", "hint", event.schedule_type === "calendar" ? "Resume selects the next calendar occurrence." : event.schedule_type === "once" ? "A past one-shot may need a new date before Resume." : "Resume keeps the saved due time and may run soon if overdue."));
    }
    fact.append(value);
    return fact;
  }
  const runTime = run => run.completed_at || run.started_at || run.created_at;
  function lastFact(event, runs) {
    const fact = element("dl", "run-fact");
    fact.append(element("dt", "", "Last run"));
    const value = element("dd");
    if (!runs.length) value.textContent = "Never run";
    else { value.append(element("div", "", dateText(runTime(runs[0]))), legalRunChip(runs[0])); }
    fact.append(value);
    return fact;
  }
  function conversationLink(event) {
    const id = event.source_conversation_id || event.context?.conversation_id;
    if (typeof id !== "string" || !id) return null;
    const link = element("a", "", "Open task");
    link.href = `/agent-ui?conversation=${encodeURIComponent(id)}`;
    return link;
  }
  function runLink(run, label = "Open run") {
    if (!run?.execution_conversation_id) return null;
    const link = element("a", "", label);
    link.href = `/agent-ui?conversation=${encodeURIComponent(run.execution_conversation_id)}`;
    return link;
  }
  function renderHistory(event, panel) {
    panel.replaceChildren(element("h3", "", "Recent runs"));
    const history = state.history.get(event.event_id);
    if (history?.loading) panel.append(element("p", "hint", "Loading history…"));
    if (history?.error) panel.append(element("p", "error-text", history.error), button("Retry history", () => loadHistory(event.event_id)));
    const runs = history?.runs || state.runs[event.event_id] || [];
    if (!runs.length && !history?.loading) panel.append(element("p", "hint", "No runs yet."));
    const list = element("ol", "run-history");
    for (const run of runs) {
      const row = element("li"), heading = element("div", "run-heading");
      heading.append(element("span", "", dateText(runTime(run))), legalRunChip(run));
      row.append(heading);
      const link = runLink(run);
      if (link) row.append(link);
      const times = [["Scheduled", run.scheduled_for], ["Started", run.started_at], ["Completed", run.completed_at]].filter(([, value]) => value).map(([name, value]) => `${name} ${dateText(value)}`).join(" · ");
      if (times) row.append(element("p", "run-times", times));
      if (run.final_response_preview) row.append(element("p", "run-preview", run.final_response_preview));
      if (run.error_preview) row.append(element("p", "run-preview error-text", run.error_preview));
      list.append(row);
    }
    panel.append(list);
    if (history?.nextOffset != null) panel.append(button("Older runs", () => loadHistory(event.event_id, history.nextOffset)));
    if (history?.offset) panel.append(button("Latest runs", () => loadHistory(event.event_id)));
    // Public scope is read-only. It must never be used as a mutation payload.
    const scope = event.context || {}, summary = element("div", "execution-summary");
    summary.append(element("strong", "", "Execution"));
    const facts = [scope.gateway_node && `Gateway: ${scope.gateway_node}`, scope.llm_model && `Model: ${scope.llm_model}`, scope.native_permission_policy?.mode && `Permissions: ${scope.native_permission_policy.mode}`, scope.context_refs?.length && `Context sources: ${scope.context_refs.length}`].filter(Boolean);
    for (const fact of facts) summary.append(element("p", "", fact));
    summary.append(element("p", "", "Routine edits preserve this schedule’s saved execution scope."));
    panel.append(summary);
  }
  function renderCard(event) {
    const id = event.event_id, runs = state.runs[id] || [], active = state.activeRuns[id] || runs.find(run => openStatuses.has(run.status));
    const card = element("article", "schedule-card");
    card.dataset.eventId = id;
    const main = element("div", "card-main"), identity = element("div", "card-identity"), heading = element("div", "card-heading");
    if (state.selecting) {
      const box = element("input", "schedule-checkbox"); box.type = "checkbox"; box.checked = isSelected(id);
      box.setAttribute("aria-label", `Select ${event.title || "Untitled schedule"}`); box.dataset.action = "select";
      box.addEventListener("keydown", key => { if (key.key === "Enter") { key.preventDefault(); box.click(); } });
      box.addEventListener("change", () => { if (!setSelected([id], box.checked)) box.checked = isSelected(id); render(); });
      heading.append(box);
      card.classList.toggle("is-selected", isSelected(id));
    }
    heading.append(element("h2", "", event.title || "Untitled schedule"), chip(event.status));
    identity.append(heading, element("p", "recurrence-line", recurrenceText(event)), element("p", "schedule-meta", `${event.action_type === "notification" ? "Reminder" : "Agent task"} · ${event.timezone === browserZone() ? "Local time" : `Series timezone: ${event.timezone}`}`));
    main.append(identity, nextFact(event), lastFact(event, runs));
    card.append(main);
    const footer = element("div", "card-footer"), actions = element("div", "card-actions");
    function action(label, handler, key) {
      const control = button(label, handler, "", `${label} ${event.title}`);
      control.dataset.action = key;
      control.disabled = state.busy.has(id) || !state.enabled;
      return control;
    }
    const run = action(active ? "Already running" : "Run now", () => mutate(event, "trigger"), "trigger");
    run.setAttribute("aria-label", `Run ${event.title} now`);
    run.disabled ||= Boolean(active);
    actions.append(run, action("Edit", () => openEditor(event), "edit"));
    if (["active", "paused"].includes(event.status)) actions.append(action(event.status === "active" ? "Pause" : "Resume", () => mutate(event, "status", {status: event.status === "active" ? "paused" : "active"}), "status"));
    const remove = action("Delete", () => openLifecycle(event, "delete"), "delete");
    remove.className = "destructive";
    actions.append(remove);
    if (["active", "paused"].includes(event.status)) {
      const more = element("details", "overflow-actions"), toggle = element("summary", "", "⋯");
      toggle.setAttribute("aria-label", `More actions for ${event.title}`);
      more.append(toggle);
      const menu = element("div", "overflow-panel");
      const cancel = action("Cancel schedule", () => openLifecycle(event, "cancel"), "cancel");
      cancel.className = "destructive";
      menu.append(cancel); more.append(menu); actions.append(more);
      more.addEventListener("keydown", event => { if (event.key === "Escape") { more.open = false; toggle.focus(); } });
    }
    actions.hidden = state.selecting;
    const expanded = state.expanded.has(id), panel = element("section", "history-panel");
    panel.id = `history-${id}`;
    panel.hidden = !expanded;
    const historyToggle = button(expanded ? "Hide recent runs ↑" : "Recent runs ↓", () => {
      if (state.expanded.has(id)) state.expanded.delete(id); else state.expanded.add(id);
      render();
      if (state.expanded.has(id) && !state.history.has(id)) loadHistory(id);
    }, "history-toggle", `Recent runs for ${event.title}`);
    historyToggle.dataset.action = "history";
    historyToggle.setAttribute("aria-expanded", String(expanded));
    historyToggle.setAttribute("aria-controls", panel.id);
    footer.append(actions, historyToggle);
    const sourceLink = conversationLink(event);
    if (sourceLink) actions.append(sourceLink);
    if (!active) {
      const latestLink = runLink(runs[0], "Open latest run");
      if (latestLink) actions.append(latestLink);
    }
    card.append(footer);
    if (active) {
      const current = element("div", "current-run");
      current.append(element("strong", "", "Current run"), chip(active.status));
      const link = runLink(active, "Open current run");
      if (link) current.append(link);
      current.append(element("span", "hint", "Pausing, cancelling or deleting the schedule does not stop this run."));
      card.append(current);
    }
    if (state.errors.has(id)) card.append(element("p", "error-text card-error", state.errors.get(id)));
    if (state.busy.has(id)) { card.setAttribute("aria-busy", "true"); card.append(element("p", "hint card-error", "Updating…")); }
    if (expanded) renderHistory(event, panel);
    card.append(panel);
    return card;
  }
  function render() {
    const filter = $("schedule-filter").value, sort = $("schedule-sort").value;
    $("new-schedule").disabled = !state.enabled;
    $("confirm-lifecycle").disabled = confirming || !state.enabled;
    $("schedule-controls").hidden = state.loaded && !state.enabled;
    $("filter-note").hidden = filter !== "failed" || !state.enabled;
    const visible = matchingEvents();
    selectionChanged(visible); updateBulkControls();
    const nextKey = event => {
      const time = Date.parse(event.next_run_at);
      return ["active", "paused"].includes(event.status) && Number.isFinite(time) ? time : Infinity;
    };
    visible.sort((a, b) => {
      if (sort === "name") return a.title.localeCompare(b.title) || a.event_id.localeCompare(b.event_id);
      if (sort === "updated") return (Date.parse(b.updated_at) || 0) - (Date.parse(a.updated_at) || 0) || a.title.localeCompare(b.title);
      const rank = event => nextKey(event) === Infinity ? 2 : event.status === "active" ? 0 : 1;
      return rank(a) - rank(b) || (nextKey(a) - nextKey(b) || 0) || a.title.localeCompare(b.title);
    });
    $("schedule-count").textContent = !state.loaded ? "Loading schedules…" : !state.enabled ? "Scheduling is disabled" : `${visible.length} ${visible.length === 1 ? "schedule" : "schedules"}${visible.length !== state.events.length ? ` of ${state.events.length}` : ""}`;
    const activeElement = document.activeElement, focusedId = activeElement?.closest(".schedule-card")?.dataset.eventId, focusedAction = activeElement?.dataset.action;
    const list = $("schedule-list"), ids = new Set(visible.map(event => event.event_id));
    for (const child of [...list.children]) if (!ids.has(child.dataset.eventId) || !state.enabled) child.remove();
    if (state.enabled) visible.forEach((event, index) => {
      const id = event.event_id, signature = JSON.stringify([event, state.runs[id], state.activeRuns[id], state.expanded.has(id), state.history.get(id), state.busy.has(id), state.errors.get(id), state.selecting, isSelected(id)]);
      let cached = state.cards.get(id);
      if (!cached || cached.signature !== signature) {
        const node = renderCard(event);
        if (cached?.node.isConnected) cached.node.replaceWith(node);
        cached = {node, signature}; state.cards.set(id, cached);
      }
      if (list.children[index] !== cached.node) list.insertBefore(cached.node, list.children[index] || null);
    });
    if (focusedId && focusedAction && !activeElement.isConnected) state.cards.get(focusedId)?.node.querySelector(`[data-action="${focusedAction}"]`)?.focus({preventScroll: true});
    const empty = $("empty-state");
    empty.hidden = !state.loaded || (state.enabled && visible.length > 0);
    if (!empty.hidden) {
      empty.replaceChildren(element("span", "empty-symbol", "◷"));
      const disabled = !state.enabled, filtered = state.events.length > 0;
      empty.append(element("h2", "", disabled ? "Schedules are disabled" : filtered ? "No matching schedules" : "No schedules yet"), element("p", "", disabled ? "Enable scheduled events in Mission Control to create or run schedules." : filtered ? "Try a different search or status filter." : "Create a recurring Agent task or a reminder. I can take it from here."));
      if (disabled) { const link = element("a", "", "Open Mission Control"); link.href = "/settings"; empty.append(link); }
      else if (filtered) empty.append(button("Clear search and filter", () => { $("schedule-search").value = ""; $("schedule-filter").value = "all"; session.set("schedule_status", "all"); cancelSelection(); }));
      else empty.append(button("New Schedule", () => openEditor(), "primary"));
    }
    updateSave();
  }
  async function loadHistory(id, offset = 0, feedback = true) {
    const indicator = feedback ? window.SMTOBusy?.begin({host: $("schedule-list"), label: "Loading history…"}) : null;
    try {
    if (historyRequests.has(id)) { historyDirty.add(id); return await historyRequests.get(id); }
    const work = (async () => {
      do {
        historyDirty.delete(id);
        const cached = state.history.get(id);
        state.history.set(id, {...cached, loading: true, error: ""}); render();
        try {
          const data = await api(`/${encodeURIComponent(id)}/runs?limit=30&offset=${offset}`);
          state.history.set(id, {runs: data.runs, loading: false, offset: data.offset, nextOffset: data.next_offset});
        } catch (error) { state.history.set(id, {...cached, loading: false, error: error.message}); }
        render();
      } while (historyDirty.has(id) && state.expanded.has(id));
    })();
    historyRequests.set(id, work);
    try { await work; } finally { historyRequests.delete(id); }
    } finally { indicator?.finish(); }
  }
  async function refresh({feedback = false} = {}) {
    const indicator = feedback ? window.SMTOBusy?.begin({host: $("schedule-list"), label: "Loading schedules…"}) : null;
    try {
    if (refreshPromise) { refreshAgain = true; return await refreshPromise; }
    refreshPromise = (async () => {
      do {
        refreshAgain = false;
        try {
          const data = await api(`?run_limit=${RECENT_RUN_SUMMARY_LIMIT}`);
          state.events = (data.events || []).filter(event => event.event_kind === "scheduled" && event.status !== "deleted");
          state.runs = data.runs || {}; state.activeRuns = data.active_runs || {}; state.enabled = data.enabled !== false; state.loaded = true;
          state.timezone = data.timezone || "UTC";
          const managed = new Set(state.events.map(event => event.event_id));
          for (const id of state.selected) if (!managed.has(id)) state.selected.delete(id);
          for (const id of state.excluded) if (!managed.has(id)) state.excluded.delete(id);
          for (const id of state.cards.keys()) if (!managed.has(id)) state.cards.delete(id);
          if (!state.enabled) { state.selecting = false; state.allMatching = false; state.selected.clear(); state.excluded.clear(); }
          $("local-time-note").textContent = `Times shown in ${browserZone()}`;
          $("page-error").hidden = true;
          render();
          // Only expanded histories get a deeper read; the summary always uses the same 5 runs.
          await Promise.all([...state.expanded].filter(id => state.enabled && state.events.some(event => event.event_id === id)).map(id => loadHistory(id, state.history.get(id)?.offset || 0, false)));
        } catch (error) {
          $("page-error").querySelector("span").textContent = `Could not refresh schedules. ${error.message}`;
          $("page-error").hidden = false;
          if (!state.loaded) $("schedule-count").textContent = "Schedules unavailable";
        }
      } while (refreshAgain);
    })();
    try { await refreshPromise; } finally { refreshPromise = null; }
    } finally { indicator?.finish(); }
  }
  function invalidate() {
    if (refreshTimer !== null) return;
    refreshTimer = setTimeout(() => { refreshTimer = null; if (!document.hidden) refresh(); }, 100);
  }
  async function mutate(event, operation, patch) {
    const busyFeedback = window.SMTOBusy?.begin({host: document.querySelector('#schedule-list'), label: "Updating schedule…"});
    try {
    if (state.busy.has(event.event_id) || !state.enabled) return;
    state.busy.add(event.event_id); state.errors.delete(event.event_id); render();
    try {
      await api(pathFor(event) + (operation === "status" ? "/manager" : `/${operation}`), operation === "status" ? "PATCH" : "POST", patch);
      $("action-status").textContent = operation === "trigger" ? `Started a run for ${event.title}. The normal trigger is unchanged.` : `Updated ${event.title}.`;
      await refresh();
    } catch (error) { state.errors.set(event.event_id, error.message); await refresh(); }
    finally { state.busy.delete(event.event_id); render(); }

    } finally { busyFeedback?.finish(); }
  }
  function showDialog(id) { focusReturns.set(id, document.activeElement); $(id).showModal(); }
  function closeDialog(id) { $(id).close(); }
  for (const id of ["lifecycle-dialog", "bulk-delete-dialog"]) {
    $(id).addEventListener("keydown", event => {
      if (event.key !== "Tab") return;
      const controls = [...$(id).querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href]')].filter(node => node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    });
    $(id).addEventListener("close", () => {
      const target = focusReturns.get(id);
      if (id === "bulk-delete-dialog") previewGeneration++;
      if (target?.isConnected && target.getClientRects().length && !target.disabled) target.focus({preventScroll: true});
      else if (state.enabled) $(state.selecting ? "schedule-selection-cancel" : "schedule-select").focus({preventScroll: true});
      else $("schedule-count").focus({preventScroll: true});
    });
    $(id).addEventListener("cancel", event => { if (id === "lifecycle-dialog" ? confirming : bulkBusy) event.preventDefault(); });
  }
  document.querySelectorAll("#lifecycle-dialog [data-close], #bulk-delete-dialog [data-close]").forEach(control => control.addEventListener("click", () => {
    if (control.dataset.close === "lifecycle-dialog" ? !confirming : !bulkBusy) closeDialog(control.dataset.close);
  }));
  function openLifecycle(event, operation) {
    lifecycle = {event, operation}; message("lifecycle-error", "");
    $("lifecycle-title").textContent = `${operation === "delete" ? "Delete" : "Cancel"} “${event.title}”?`;
    $("lifecycle-description").textContent = operation === "delete" ? "This removes the schedule from normal management and stops future scheduled triggers. Past run history remains retained under the existing history policy. An already-started run is not cancelled." : "Future scheduled triggers will stop. The schedule and its run history remain. This is not a temporary pause, and an already-started run is not cancelled.";
    $("confirm-lifecycle").textContent = operation === "delete" ? "Delete schedule" : "Cancel schedule";
    showDialog("lifecycle-dialog");
  }
  $("confirm-lifecycle").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating schedules…", $("confirm-lifecycle"));
        try {
    if (confirming || !lifecycle || !state.enabled) return;
    const {event, operation} = lifecycle;
    confirming = true; $("confirm-lifecycle").disabled = true; $("confirm-lifecycle").textContent = "Updating…";
    try {
      await api(pathFor(event) + (operation === "cancel" ? "/cancel" : ""), operation === "delete" ? "DELETE" : "POST");
      await refresh(); closeDialog("lifecycle-dialog");
    } catch (error) { message("lifecycle-error", error.message); }
    finally { confirming = false; $("confirm-lifecycle").disabled = false; $("confirm-lifecycle").textContent = operation === "delete" ? "Delete schedule" : "Cancel schedule"; }

        } finally { busyFeedback?.finish(); }
      });
  function updateBulkControls() {
    $("bulk-delete-confirm").disabled = bulkBusy || bulkStale || !bulkPreview?.candidate_count || !state.enabled;
    $("bulk-delete-keep").disabled = bulkBusy;
    $("bulk-delete-review").disabled = bulkBusy || !state.enabled;
  }
  async function reviewBulkDelete() {
    const busyFeedback = window.SMTOBusy?.begin({host: document.querySelector('#bulk-delete-dialog form') || document.querySelector('#bulk-delete-dialog'), label: "Reviewing selected schedules…"});
    try {
    const version = ++previewGeneration;
    bulkPreview = null; bulkStale = false; message("bulk-delete-error", "");
    $("bulk-delete-review").hidden = true;
    $("bulk-delete-title").textContent = "Review schedule deletion";
    $("bulk-delete-description").textContent = "Loading deletion preview…";
    $("bulk-delete-confirm").textContent = "Delete schedules";
    updateBulkControls();
    try {
      const preview = await api("/manager/delete-preview", "POST", bulkSelection);
      if (version !== previewGeneration || !$("bulk-delete-dialog").open) return;
      bulkPreview = preview;
      const count = preview.candidate_count, noun = count === 1 ? "schedule" : "schedules", active = preview.active_run_count;
      $("bulk-delete-title").textContent = `Delete ${count} ${noun}?`;
      $("bulk-delete-description").replaceChildren(
        element("p", "", `${count} ${noun} will be removed from Schedule Manager and will no longer trigger future runs.`),
        element("p", "", "Past run history is retained."),
        element("p", "", `${active} already-started ${active === 1 ? "run" : "runs"} will continue.`)
      );
      $("bulk-delete-confirm").textContent = `Delete ${count} ${noun}`;
    } catch (error) {
      if (version !== previewGeneration || !$("bulk-delete-dialog").open) return;
      $("bulk-delete-description").textContent = "The deletion preview could not be loaded.";
      message("bulk-delete-error", error.message); $("bulk-delete-review").hidden = false;
    }
    updateBulkControls();

    } finally { busyFeedback?.finish(); }
  }
  $("schedule-delete-selected").addEventListener("click", () => {
    if (!state.enabled || !selectedCount() || $("bulk-delete-dialog").open) return;
    bulkSelection = selectionDescriptor(); showDialog("bulk-delete-dialog"); void reviewBulkDelete();
  });
  $("bulk-delete-review").addEventListener("click", () => { void reviewBulkDelete(); $("bulk-delete-keep").focus(); });
  $("bulk-delete-confirm").addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating schedules…", $("bulk-delete-confirm"));
        try {
    if (bulkBusy || bulkStale || !bulkPreview?.candidate_count || !state.enabled) return;
    bulkBusy = true; updateBulkControls();
    try {
      const result = await api("/manager/bulk-delete", "POST", {selection: bulkSelection, selection_digest: bulkPreview.selection_digest});
      cancelSelection(); await refresh(); closeDialog("bulk-delete-dialog");
      $("action-status").textContent = `${result.deleted_count} ${result.deleted_count === 1 ? "schedule" : "schedules"} deleted`;
    } catch (error) {
      message("bulk-delete-error", error.code === "selection_changed" ? `Selection changed. ${error.message}` : error.message);
      if (error.status === 409) { bulkStale = true; $("bulk-delete-review").hidden = false; }
    } finally { bulkBusy = false; updateBulkControls(); }

        } finally { busyFeedback?.finish(); }
      });
  $("schedule-select").addEventListener("click", () => { if (!state.enabled) return; state.selecting = true; render(); $("schedule-select-shown").focus(); });
  $("schedule-selection-cancel").addEventListener("click", () => { cancelSelection(); $("schedule-select").focus(); });
  $("schedule-select-shown").addEventListener("change", event => { setSelected(matchingEvents().map(event => event.event_id), event.target.checked); render(); });
  $("schedule-select-matching").addEventListener("click", () => { state.allMatching = true; state.selected.clear(); state.excluded.clear(); render(); });
  $("new-schedule").addEventListener("click", () => openEditor());
  $("retry-load").addEventListener("click", () => refresh({feedback: true}));
  $("schedule-search").addEventListener("input", cancelSelection);
  $("schedule-filter").addEventListener("change", () => { session.set("schedule_status", $("schedule-filter").value); cancelSelection(); });
  // Sort changes display order only, preserving explicit IDs and all-matching exclusions.
  $("schedule-sort").addEventListener("change", () => { session.set("schedule_sort", $("schedule-sort").value); render(); });

  window.SMTOUiUpdates?.subscribe(["events.changed", "tasks.changed", "settings.changed"], invalidate);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) invalidate(); });
  window.addEventListener("online", invalidate);
  let focusedLink = false;
  function focusDeepLink() {
    if (focusedLink) return;
    const id = new URLSearchParams(location.search).get("event");
    const event = state.events.find(event => event.event_id === id);
    if (!event) return;
    focusedLink = true;
    const card = state.cards.get(id)?.node;
    if (card) { card.tabIndex = -1; card.classList.add("is-highlighted"); card.scrollIntoView({block: "center"}); card.focus({preventScroll: true}); setTimeout(() => card.classList.remove("is-highlighted"), 4000); }
  }
  refresh({feedback: true}).then(focusDeepLink).finally(() => document.documentElement.classList.remove("app-booting"));
})();
