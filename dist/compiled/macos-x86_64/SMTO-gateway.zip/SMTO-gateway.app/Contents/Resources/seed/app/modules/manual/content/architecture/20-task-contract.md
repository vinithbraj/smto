---
id: task-contract-compiler
title: Task Contract Compiler
kind: architecture
tags: [architecture, current, task-contract-compiler]
order: 20
---
# Task Contract Compiler

The compiler is an optional request-understanding step inside the existing run owner.
`task_contract_compilation_enabled` defaults to false when no setting is supplied. The
mode is bound to run state so a resumed run keeps its accepted interpretation mode.

Plan collaboration is separate from Task Contract. A Plan task retains the requested
compiler preference but suppresses effective compilation, including queued preparation.
Implementing an approved plan selects Default collaboration and compiles canonical
server-owned plan Markdown instead of the visible “Implement the plan.” instruction.
Inline generation, source identity, acceptance and queued preparation all use that
same source. The approved plan is never a Task Contract or task-board checklist.

For an accepted source revision, the compiler transforms only the current user input
into a structured task contract: request objective, obligations/constraints, explicit
references and terminal-output requirements. Its model request contains compiler
instructions and the current input with optional MODEL_INPUT projection. Conversation history, previous contracts,
handoffs, runtime facts, parameter bindings and Context metadata are excluded.

The execution model receives the contract in place of that user input, together with
normal bounded conversation history, resource bindings and execution context. References
such as “the same repository” or an attachment name are preserved for the executor to
resolve. Historical user messages remain available even when they repeat the current
prompt. An amendment is compiled independently; earlier compiled inputs and completed
work remain execution context, with later changes taking precedence. ContextStore owns
resource identities and grants. The execution task board remains separate from the
user-request contract.

Answers to executor `ask_user` questions also remain verbatim user messages alongside
their compiled revisions. Passwords and other exact execution inputs must survive even
when the compiler describes their purpose without copying the value. This uses question
and answer positions in the existing journal, including continued and steered replies;
it does not classify passwords or create a separate credential store. Optional
MODEL_INPUT redaction still applies at the consumer boundary. The compiler must also
preserve explicitly supplied authentication literals and must not invent credentials.

The implementation reserves the generating attempt before model transport. It records
accepted/valid revisions, clarification, stale revisions, failures and cancellation.
Changed input can invalidate a revision. A failed compilation has an explicit failed
path; it is not an assurance that execution continues with the raw prompt. Inspect the
compiler activity and state before deciding whether to resubmit or clarify.

`task_contract_models.py` defines the generation schema and optional offline fidelity
diagnostics. The compiler acceptance path does not call `validate_contract` or enforce
that model. `task_contract_fields.py` reads tolerant bookkeeping views without rewriting
the saved compiler output. `task_contract_projection.py` supplies the accepted intent
to executor requests while preserving the durable human journal.

Compiler responses may include prose alongside the submission tool call. The transport
and compiler discard that assistant text before retaining accepted output; only the
submission's JSON object becomes the task contract. Streaming previews likewise show
only contract arguments. Exactly one `smto__submit_task_contract` call with complete
JSON arguments and a completed tool response is still required. Text-only responses,
multiple calls, malformed JSON and truncated responses remain failures. This tolerance
applies only to Task Contract compilation, not other bounded internal tool requests.

Source owners: `native/task_contract.py`, `task_contract_models.py`,
`task_contract_fields.py` and the request-lifecycle route group. Compilation does not
authorize tools, grant credentials or prove that the requested result has been achieved.

## Task Contract Integrity Guard

Compiler acceptance remains permissive: `validate_contract()` stays an optional offline
diagnostic and `TaskContract.model_validate()` is not called during acceptance. Accepted
revisions retain `schema_validation = "skipped"`. The separate, deterministic Integrity
Guard checks only provenance-sensitive authority before installing a complete, consumer-projected
compiler result. It does not inspect streaming fragments, repair output, or invoke a model.

**Settings → Task Contracts → Task Contract Integrity Guard** defaults ON for new tasks.
Task Contract Compilation retains its existing OFF default; the guard has no effect when
compilation is disabled. Desktop **Prompt Options** and mobile **Agent options** provide
an independent override for the next task. “Inherited from Settings” uses the server's
current default at admission; “Overridden for this prompt” sends an explicit boolean.
Changing the prompt toggle does not write Settings. “Use Settings default” removes the
override. Disabling compilation temporarily preserves the prompt choice.

The server freezes the effective boolean `task_contract_integrity_guard_enabled` when a
request is prepared or a task/schedule is admitted. Prepared requests use a separate
`native_prepared_task_contract_integrity` snapshot. Durable queued tasks, scheduled
occurrences, resume, restart, continuation and manual compiler retry retain the saved
choice. Later Settings changes and draft edits cannot alter it. Saved tasks or prepared
requests without this field retain historical OFF behavior. Prompt drafts are scoped by
conversation and cleared after successful submission, following existing option lifecycle.
Guard OFF preserves historical permissive acceptance.

The guard applies these narrow rules:

- Explicit source `@parameter` tokens must appear with the same spelling in generated
  string leaves; generated parameter tokens must have source provenance. The shared
  mention lexer excludes emails, escaped mentions, code literals and reserved resource
  namespaces. No Parameter Store bindings or private values are loaded or compared.
- High-risk paths are inspected only in `scope.roots` and `scope.targets`, including
  recognizable serialized structures. POSIX absolute paths, Windows drive paths, UNC,
  `file://` URIs, home-rooted paths and traversal segments require explicit source paths.
  Ordinary relative filenames and paths in descriptive fields remain unrestricted by
  this guard.
- Exact explicit paths pass. POSIX, drive and UNC roots also permit syntactic descendants
  with segment boundaries. Traversal requires the exact source spelling; it never creates
  descendant authority. Windows separators may be normalized, but case is preserved.

Only the accepted current compiler source establishes provenance, including for amendments.
A guessed concrete path fails even if it happens to match a hidden Parameter Store binding.
There is no filesystem lookup, Git query, network access, schema/fidelity check, coverage
check, graph validation or semantic judgment. Passing is not runtime authorization or
complete sandboxing; existing execution permission and containment checks still apply.

Rejected attempts display **Integrity check failed**, retain bounded findings with optional ACTIVITY projection and
start no execution for that revision. They never enter automatic Task Contract recovery,
even when recovery is enabled. **Retry contract generation** remains an explicit user
operation and reruns the guard with the captured mode and frozen input. A new task can
choose a different setting. Passed, failed and skipped integrity metadata is separate
from schema-validation metadata.

V1 uses conservative tokenization rather than shell parsing. Quoted source paths can
contain spaces; environment variables, shell substitutions, symlinks, home expansion and
URI decoding are not provenance sources. Home and file URI forms require exact matches.
The scan bounds nodes (16,384), text (512 KiB per scan), source candidates (512), findings
(32) and diagnostic strings (256 characters). Scope is scanned before unrelated extensions.
Excess extension data does not itself reject a contract; partial scans report
`scan_complete = false` and do not claim an unobserved reference was omitted. Protected
violations already found still fail. This is a narrow provenance check, not complete
contract validation.

## Output allowance and automatic recovery

Settings → Task Contracts owns the existing compilation toggle and these runtime controls:

| Key | Default | Explicit bounds | Meaning |
| --- | --- | --- | --- |
| `task_contract_max_tokens` | `min(llm_max_tokens, 8192)` | 1,024–65,536 | Initial compiler output allowance |
| `task_contract_auto_recovery_enabled` | Off | Boolean | Retry failed contract-generation attempts |
| `task_contract_auto_recovery_retries` | 3 | 3–10 | Additional attempts after the initial call |
| `task_contract_auto_recovery_increment_tokens` | 1,024 | 256–8,192, multiples of 256 | Linear increase per retry |

These controls set model output allowance, not input context, schema size, character
limits, or the thinking-token budget. Unsaved installations preserve their old effective
allowance: a 4,096 global ceiling derives 4,096; a 16,384 ceiling derives 8,192. Legacy
ceilings below the new explicit minimum remain usable. The old zero sentinel resolves to
the native client's 4,096 default. Recovery stays off until explicitly enabled.

The settings owner validates the complete policy under its runtime-control lock and
persists one coupled patch in the existing settings namespace. Required headroom is
`base + retries * increment` when recovery is enabled, otherwise `base`. Saving policy
changes raises `llm_max_tokens` to at least this value, without lowering a larger value.
A direct conflicting legacy `llm_max_tokens` API reduction returns HTTP 422; sequences
exceeding 65,536 are rejected. Autosave reconciles server-derived compiler values;
the internal ceiling is not a separate Model Configuration editor.

Settings apply to new tasks. Admission, prepared requests, queued tasks and scheduled
execution capture the complete output policy and general ceiling together. Native run
state and resume context preserve the accepted policy through restarts and continuations.
Old runs without these fields use their saved LLM ceiling, the legacy 8,192 default cap,
and recovery disabled. No migration of saved runs is required.

The `llm_max_tokens` ceiling above is the internal client allowance retained for
compiler/recovery compatibility. [Model Configuration](../25-model-configuration.md)
separately controls optional `max_completion_tokens` for normal agent execution.
Saving compiler headroom does not create that execution override, and changing the
execution limit, sampling or thinking controls does not change compiler policy.
Provider Default may omit the execution limit while reserving internal output space.

Each generation cycle freezes compiler messages, source digest, prompt revision and tool
schema once. Retryable failed generation attempts admit automatic recovery, including wrong
tool calls, malformed JSON, incomplete responses, provider/transport errors and output
truncation. Retry `n` requests `base + n * increment` tokens. For example,
4,096 → 5,120 → 6,144 → 7,168 is one initial call and three additional retries.
Model, prompt, schema, temperature and thinking profile stay fixed. Every failure counts
against the same retry limit; changing failure types does not reset it. Clarification,
cancellations, stale sources and local failures before generation (such as unavailable
input or insufficient context/output capacity) do not start or extend recovery. Integrity
violations and internal guard failures also never start automatic recovery.

The request-local `task_contract_output_budget` ContextVar supplies generation limits;
the shared client is never mutated. Preflight reserves the same phase-specific output
allowance sent in the provider payload. That reservation participates in cache identity
and working-set sizing, including existing constrained Agent recovery. If compiler input
plus the next allowance cannot fit the model context window, recovery stops before the
provider call. Provider output ceilings may be lower than the public setting maximum;
provider rejection is retried within the saved retry limit and retained with its original reason.

Every compiler call has a durable reserved attempt before transport. Attempts retain
revision identity, attempt identity, retry index, configured and effective limits,
completion state and bounded visible failure evidence. A preflight-rejected allowance
is recorded with `transport_started=false` and does not increment `task_contract_calls`.
Retries are attempts of the same contract revision, not new semantic revisions.
`task_contract.attempt_failed` is nonterminal; `task_contract.recovery_started` and the
next `task_contract.started` show progress and limits. Only terminal failure emits
`task_contract.failed`. Accepted and failed attempts remain inspectable on desktop/mobile.

Each transport contributes to `task_contract_calls`, total model calls and accumulated
Task Contract usage. Each compiler attempt gets a separate one-call inference budget;
executor decision allowance remains untouched. No Agent or Gateway tool execution starts
until a contract is accepted. Failed partial output remains bounded and sanitized; private
provider reasoning is excluded and raw compiler input is not copied into attempt records.

Between retries the owner checks cancellation, amendments/source digest, pause and wall
budget. An interrupted `generating` or `recovery_pending` checkpoint fails conservatively
as `interrupted_compilation` on re-entry; it never invisibly resends a provider request.
This also applies when paused between attempts. The existing **Retry contract generation**
control explicitly reopens the same accepted task, retaining its frozen input and saved
policy. Frozen inputs from the older context-enriched compiler are rebuilt from the saved
current user input on explicit retry; they are never replayed into the prompt-only compiler.
Each manual admission starts one fresh, bounded recovery cycle. Settings edits
do not alter that saved cycle; submit a new task to use a changed policy.

## Thinking during Task Contract generation

Settings → Task Contracts also exposes `task_contract_thinking_mode` and
`task_contract_thinking_budget_tokens`. They apply only to compilation, including its
automatic retries. They do not change the agent's subsequent decisions, responses or
general recovery configuration, or other tasks using the same client.

Normal execution has its own **Thinking** control in
[Model Configuration](../25-model-configuration.md#thinking-effort-and-budget).
Both use `chat_template_kwargs.enable_thinking` for an explicit On/Off choice, but
the execution override never replaces the compiler's saved thinking policy.
For example, execution Thinking Off and Task Contract thinking On send `false` for
normal decisions and `true` for contract generation, including its retries. Their
thinking budgets are also independent, even when calls share the same model client.

| Mode | Provider request |
| --- | --- |
| Provider default | No thinking override |
| Off (`disabled`, default for new tasks) | `chat_template_kwargs.enable_thinking=false` |
| On (`enabled`) | `chat_template_kwargs.enable_thinking=true` |
| Bounded budget (`budget`) | Thinking enabled, plus `thinking_token_budget` |

The explicit modes require an endpoint that supports those controls. Capability support
is not inferred from model names, aliases or provider branding. A rejected control is
reported as a provider failure; the runtime never silently retries without the policy.
The general `llm_recovery_thinking=auto` compatibility setting now means provider defaults
for every model. Existing explicitly configured general `budget`, `disabled` and
`unchanged` modes retain their behavior.

The thinking budget defaults to 1,024, accepts 128–32,768 in increments of 128, and is
used only in Bounded budget mode. In that mode it must be smaller than the initial
Task Contract output allowance. Retries increase the output allowance as before and
leave the thinking budget fixed. With a reasoning model, hidden thinking can consume
the output allowance before any contract text or tool call appears; raising the output
limit is not the only remedy.

Thinking policy is snapshotted alongside output policy at admission, including queued,
prepared and scheduled tasks, and survives manual retries, restart and continuation.
Legacy tasks with no thinking policy use Provider default. The request-local
`task_contract_thinking` ContextVar is set for the compiler call and reset in `finally`
on success, failure, cancellation or interruption. The shared client and global settings
are never modified. Attempt inspection and history retain the selected policy.

Failure messages identify exhausted retries and recovery stopped before exhaustion.
Output-limit messages also distinguish disabled recovery. These messages derive recovery
status from the saved attempt's policy. They never assume that recovery is disabled when
older metadata is missing. No-visible-output failures also
suggest reviewing thinking settings instead of repeatedly increasing the output limit.


## Streaming compiler output

Native Task Contract calls request SSE streaming when the endpoint supports it. The
existing activity inspector on desktop and mobile refreshes **Generated output (partial)**
while the compiler is still running. Previews expose completed JSON values and nested
container members; unfinished strings are withheld until complete structured projection is
possible. Private reasoning and provider extensions are never shown. The complete response
must still pass the existing protocol checks before contract acceptance or any execution.

Sanitized previews are bounded to 192 KiB and checkpointed at most twice per second.
`task_contract.progress` carries only attempt identity and a monotonically increasing
`detail_version`. An open inspector fetches the latest checkpoint without polling or
closing the disclosure; a closed inspector makes no preview requests. Reconnects use
the retained checkpoint and never start another inference. Terminal events replace the
preview with the accepted contract or retained failure evidence. Older or late progress
cannot overwrite a newer checkpoint or a terminal attempt. Cancellation closes the
publisher before state is finalized, and each retry keeps its own preview and identity.

A confirmed streaming rejection before an SSE response opens may fall back to the existing
single-response transport with exactly the same output/thinking policy. An interrupted or
malformed open stream never triggers an invisible resend. Output-limit recovery remains
unchanged. Streaming improves visibility and time to first visible contract content; it
does not reduce the requested output budget or guarantee faster model generation.
