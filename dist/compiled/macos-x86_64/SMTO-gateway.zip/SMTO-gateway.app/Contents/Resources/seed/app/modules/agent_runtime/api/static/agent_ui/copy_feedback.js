/* Shared, transient feedback for successful user-initiated clipboard writes. */
(() => {
  "use strict";
  function bind(button) {
    const original = [...button.childNodes], title = button.getAttribute("title");
    const iconOnly = Boolean(button.querySelector("svg")) && !button.textContent.trim();
    let timer;
    function reset() {
      clearTimeout(timer);
      if (!button.hasAttribute("data-copied")) return;
      button.replaceChildren(...original);
      if (title === null) button.removeAttribute("title");
      else button.title = title;
      delete button.dataset.copied;
    }
    button.addEventListener("click", reset, {capture: true});
    return () => {
      clearTimeout(timer);
      button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" style="width:14px;height:14px;vertical-align:middle" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>';
      if (!iconOnly) button.append(document.createTextNode(" Copied"));
      button.dataset.copied = "true";
      button.title = "Copied";
      timer = setTimeout(reset, 1500);
    };
  }
  window.SMTOCopyFeedback = {bind};
})();
