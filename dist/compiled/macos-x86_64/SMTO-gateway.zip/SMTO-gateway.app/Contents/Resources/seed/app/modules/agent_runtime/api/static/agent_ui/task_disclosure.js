/* Browser-local task presentation shared by desktop and mobile. No execution authority. */
(() => {
  "use strict";
  if (window.SMTOTaskDisclosure) return;
  const prefix = "smto.agentUi.taskDisclosure.v1.";
  const cache = new Map(), controllers = new Set(), unavailable = new Set();
  let sequence = 0;
  // Keep the storage namespace; v2 distinguishes inheritance from explicit on/off.
  const empty = () => ({version: 2, collapsed: false, activeOnly: false, immersive: null, navigator: null, overrides: Object.create(null)});
  function read(cid) {
    let value = cache.get(cid) || empty();
    if (!cid || unavailable.has(cid)) return value;
    try {
      const raw = cid && localStorage.getItem(prefix + cid);
      const saved = raw ? JSON.parse(raw) : null;
      value = empty();
      if ([1, 2].includes(saved?.version) && typeof saved.collapsed === "boolean"
          && saved.overrides && typeof saved.overrides === "object" && !Array.isArray(saved.overrides)) {
        value.collapsed = saved.collapsed;
        value.activeOnly = saved.activeOnly === true;
        // v1 wrote false even when the user had never chosen an Immersive state.
        value.immersive = saved.version === 2 && typeof saved.immersive === "boolean"
          ? saved.immersive : saved.immersive === true ? true : null;
        value.navigator = typeof saved.navigator === "boolean" ? saved.navigator : null;
        for (const [key, collapsed] of Object.entries(saved.overrides))
          if (/^(task|request|submission):.+/.test(key) && typeof collapsed === "boolean") value.overrides[key] = collapsed;
      }
    } catch (_) { /* Keep this page's choices when browser storage is unavailable. */ }
    cache.set(cid, value);
    return value;
  }
  function save(cid, value) {
    cache.set(cid, value);
    if (cid) try { localStorage.setItem(prefix + cid, JSON.stringify(value)); unavailable.delete(cid); }
    catch (_) { unavailable.add(cid); }
  }
  function forget(cid, keys) {
    if (!cid) return;
    if (keys) {
      const value = read(cid);
      if (!keys.some(key => Object.hasOwn(value.overrides, key))) return;
      for (const key of keys) delete value.overrides[key];
      save(cid, value);
    } else {
      cache.delete(cid);
      try { localStorage.removeItem(prefix + cid); unavailable.delete(cid); }
      catch (_) { unavailable.add(cid); }
    }
    for (const controller of controllers) controller.reload(cid);
  }
  const paths = {
    toggle: '<path d="m9 5 7 7-7 7"/>',
    collapse: '<path d="m6 3 6 6 6-6M6 21l6-6 6 6"/>',
    expand: '<path d="m6 9 6-6 6 6m-12 6 6 6 6-6"/>',
  };
  function button(kind, label) {
    const root = document.createElement("button"); root.type = "button";
    root.className = "task-disclosure-button";
    root.title = label; root.setAttribute("aria-label", label);
    root.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${paths[kind]}</svg>`;
    return root;
  }
  const labels = {pending: "Starting", queued: "Queued", running: "Running", resuming: "Resuming", completed: "Completed", answered: "Completed",
    failed: "Failed", cancelled: "Stopped", interrupted: "Interrupted", paused: "Paused", paused_budget: "Paused · budget reached",
    waiting_user: "Needs input", awaiting_clarification: "Needs input", awaiting_confirmation: "Needs approval",
    waiting_approval: "Needs approval", waiting_user_confirmation: "Needs approval", awaiting_resource_reconciliation: "Needs recovery decision",
    waiting_job: "Waiting for job", waiting_event: "Waiting for event", waiting_resource: "Waiting for resource",
    blocked: "Blocked", partial: "Partial · resumable"};
  // Accepted work stays active while starting or waiting; manual pauses and
  // terminal outcomes are separate. Unknown states never invent activity.
  const activeStatuses = new Set(["pending", "queued", "running", "resuming", "waiting_job", "waiting_event",
    "waiting_resource", "waiting_user", "waiting_approval", "waiting_user_confirmation",
    "awaiting_clarification", "awaiting_confirmation", "awaiting_resource_reconciliation"]);
  function queryLabel(prompt, attachments = []) {
    if (prompt?.trim()) return prompt.trim();
    if (!Array.isArray(attachments)) attachments = [];
    if (attachments.length > 1) return `Files · ${attachments.length} attachments`;
    if (attachments.length === 1) {
      const file = attachments[0], name = file.filename || file.name || "";
      const image = /^image\//.test(file.mime_type || file.content_type || file.type || "")
        || /\.(png|jpe?g|gif|webp|heic|avif|svg)$/i.test(name);
      return `${image ? "Image" : "File"}${name ? ` · ${name}` : ""}`;
    }
    return "User prompt";
  }
  function anchorFor(root) {
    const group = root?.closest(".activity-group");
    return group?.dataset.taskCollapsed === "true"
      ? document.getElementById(group.dataset.disclosureAnchor) || group : root;
  }
  const isFiltered = root => Boolean(root?.closest('[data-run-filtered="true"]'));
  const validNumber = value => Number.isSafeInteger(value) && value > 0;
  function gatewaysFor(task, turn) {
    // Reuse the expanded task's labels, including historical and unavailable targets.
    const chips = [...turn.root.querySelectorAll('.conversation-gateways [data-run-gateway-id]')];
    if (chips.length) return chips.map(chip => ({id: chip.dataset.runGatewayId,
      label: chip.firstElementChild?.textContent || chip.dataset.runGatewayId}));
    const target = turn.gatewayTarget || task?.context || task;
    const scope = target?.gateway_selection || task?.context?.gateway_selection;
    const primary = target?.gateway_id || scope?.primary_gateway_id || task?.gateway_id;
    const ids = scope?.gateway_ids || (primary ? [primary] : []);
    return ids.map(id => ({id, label: id === primary ? target?.gateway_label || id : id}));
  }
  function create({content, viewport, toolbar, conversationId, getTurn, getTask = () => null, hasQueuedTasks = () => false,
    beforeToggle = () => {}, changed = () => {}, openNavigator = null, navigatorChanged = () => {}, immersiveChanged = () => {},
    defaultNavigator = () => false, defaultImmersive = () => false, gatewaysInFooter = false}) {
    const groups = new Map(), newSubmissions = new WeakSet();
    const findExpanded = new Set();
    let cid, preferences = empty(), pending = false, rendering = false, navigatorState;
    function scope() {
      const next = conversationId() || "";
      if (cid !== next) { findExpanded.clear(); cid = next; preferences = read(cid); window.SMTOTaskTiming?.select(cid); }
    }
    const isImmersive = () => preferences.immersive ?? (defaultImmersive() === true);
    const navigatorOptions = () => ({enabled: preferences.navigator ?? (defaultNavigator() === true),
      allowShort: preferences.navigator === true});
    const collapsed = key => !isImmersive() && !findExpanded.has(key) && (preferences.overrides[key] ?? preferences.collapsed);
    const collapseAll = button("collapse", "Collapse all tasks"), expandAll = button("expand", "Expand all tasks");
    const filter = document.createElement("label"); filter.className = "task-active-filter";
    const activeOnly = document.createElement("input"); activeOnly.type = "checkbox";
    activeOnly.className = "mission-switch"; activeOnly.setAttribute("role", "switch");
    const filterText = document.createElement("span"); filterText.className = "task-display-label";
    filterText.textContent = "Active runs";
    filter.title = "Show running and waiting runs";
    filter.append(activeOnly, filterText);
    const displayToggles = document.createElement("div"); displayToggles.className = "task-display-toggles";
    displayToggles.append(filter);
    const navigatorToggle = document.createElement("input"); navigatorToggle.type = "checkbox";
    navigatorToggle.className = "mission-switch"; navigatorToggle.setAttribute("role", "switch");
    if (openNavigator) {
      const label = document.createElement("label"); label.className = "task-navigator-toggle";
      const labelText = document.createElement("span"); labelText.className = "task-display-label";
      labelText.textContent = label.title = "Navigator";
      label.append(navigatorToggle, labelText); displayToggles.append(label);
      navigatorToggle.onchange = async () => {
        const busyFeedback = window.SMTOBusy?.action("Saving display preference…", navigatorToggle);
        try {
        const enabled = navigatorToggle.checked;
        change(() => { preferences.navigator = enabled; }, null, true, false);
        if (!enabled) return;
        const pending = openNavigator(navigatorToggle);
        if (!pending?.then) return;
        // Only lazy loading needs a disabled control.
        navigatorToggle.disabled = true;
        try { await pending; }
        finally { navigatorToggle.disabled = false; }

        } finally { busyFeedback?.finish(); }
      };
    }
    const immersiveLabel = document.createElement("label"); immersiveLabel.className = "task-immersive-toggle";
    const immersiveToggle = document.createElement("input"); immersiveToggle.type = "checkbox";
    immersiveToggle.className = "mission-switch"; immersiveToggle.setAttribute("role", "switch");
    const immersiveText = document.createElement("span"); immersiveText.className = "task-display-label";
    immersiveText.textContent = immersiveLabel.title = "Immersive";
    immersiveLabel.append(immersiveToggle, immersiveText); displayToggles.append(immersiveLabel);
    const immersive = window.SMTOImmersive?.create({content, viewport, toggle: immersiveToggle, conversationId,
      getTurn: root => { const turn = getTurn(root); return {...turn, status: turn?.status || getTask(turn?.taskId)?.status}; },
      exit: () => change(() => { preferences.immersive = false; }, null, true, false), changed: immersiveChanged});
    const emptyState = document.createElement("div"); emptyState.className = "task-active-empty"; emptyState.hidden = true;
    const emptyLabel = document.createElement("p"); emptyLabel.textContent = "No active runs";
    emptyLabel.setAttribute("role", "status");
    emptyState.append(emptyLabel);
    toolbar.classList.add("task-disclosure-toolbar"); toolbar.setAttribute("role", "group");
    toolbar.setAttribute("aria-label", "Task display"); toolbar.append(collapseAll, expandAll, displayToggles);
    if (viewport.id === "conversation-viewport") {
      const fitDisplayToggles = () => {
        // Measure the labelled controls even while compact or hidden, so widening restores them.
        // Both layouts are resolved before paint; no intermediate state is displayed.
        toolbar.classList.remove("task-display-compact", "task-display-hidden");
        const bounds = content.getBoundingClientRect();
        if (!bounds.width) return;
        const textRight = bounds.right - parseFloat(getComputedStyle(content).paddingRight);
        const compact = displayToggles.getBoundingClientRect().left < textRight + 8;
        toolbar.classList.toggle("task-display-compact", compact);
        toolbar.classList.toggle("task-display-hidden",
          compact && displayToggles.getBoundingClientRect().left < textRight + 8);
      };
      const displayResize = new ResizeObserver(fitDisplayToggles);
      displayResize.observe(viewport);
      displayResize.observe(content);
      displayResize.observe(toolbar);
      // Hidden labels retain their natural width, including font-scale changes.
      for (const label of displayToggles.querySelectorAll(".task-display-label")) displayResize.observe(label);
    }
    const resize = new ResizeObserver(entries => {
      for (const {target} of entries) measure(target);
    });
    function measure(preview) {
      const overflow = preview.clientHeight > 0 && preview.scrollHeight > preview.clientHeight + 1;
      preview.classList.toggle("task-query-overflow", overflow);
    }
    function mount(group) {
      const header = document.createElement("div"); header.className = "task-disclosure-header";
      header.id = `task-disclosure-${++sequence}`;
      const number = document.createElement("span"); number.className = "task-activity-number"; number.hidden = true;
      number.setAttribute("role", "img");
      const toggle = button("toggle", "Collapse task"); toggle.classList.add("task-disclosure-toggle");
      const summary = document.createElement("div"); summary.className = "task-disclosure-summary";
      const mode = document.createElement("div"); mode.className = "task-mode-banner task-disclosure-mode";
      const gateways = document.createElement("div"); gateways.className = "task-disclosure-gateways"; gateways.hidden = true;
      gateways.setAttribute("role", "group"); gateways.setAttribute("aria-label", "Target gateways");
      const modeLabel = document.createElement("span"); modeLabel.className = "task-disclosure-mode-label"; modeLabel.hidden = true;
      const separator = document.createElement("span"); separator.className = "task-disclosure-separator";
      separator.textContent = "|"; separator.setAttribute("aria-hidden", "true"); separator.hidden = true;
      const preview = document.createElement("span"); preview.className = "task-disclosure-query";
      const status = document.createElement("span"); status.className = "task-disclosure-status";
      status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
      const timing = document.createElement("div"); timing.className = "task-disclosure-timing"; timing.hidden = true;
      const clock = window.SMTOMessageTimestamps?.create(null);
      const timeSeparator = document.createElement("span"); timeSeparator.textContent = "·";
      timeSeparator.setAttribute("aria-hidden", "true");
      const duration = document.createElement("span"); duration.className = "task-disclosure-duration";
      const timingHeading = document.createElement("div"); timingHeading.className = "task-disclosure-clock-row";
      if (clock) timingHeading.append(clock.root);
      timingHeading.append(timeSeparator, duration); timing.append(timingHeading); group.append(timing);
      const strip = window.SMTOTaskTiming?.create(duration);
      if (strip) timing.append(strip.root);
      mode.append(modeLabel, separator, status);
      summary.append(mode);
      if (gatewaysInFooter) timing.prepend(gateways); else summary.append(gateways);
      header.append(number, toggle, summary, preview); group.prepend(header); resize.observe(preview);
      const record = {header, number, toggle, mode, modeLabel, separator, gateways, preview, status, timing, clock, timeSeparator, duration, strip,
        key: "", cid, collapsed: false};
      toggle.addEventListener("click", () => change(() => {
        preferences.overrides[record.key] = !collapsed(record.key);
        findExpanded.delete(record.key);
      }, header));
      groups.set(group, record);
      return record;
    }
    function sync() {
      if (rendering) return;
      rendering = true;
      scope();
      const immersiveEnabled = isImmersive();
      immersiveToggle.checked = immersiveEnabled;
      const navigation = navigatorOptions();
      navigatorToggle.checked = navigation.enabled;
      const nextNavigatorState = JSON.stringify([cid, navigation.enabled, navigation.allowShort, immersiveEnabled]);
      if (navigatorState !== nextNavigatorState) {
        navigatorState = nextNavigatorState;
        // Clients may still be initializing when create() first synchronizes.
        queueMicrotask(navigatorChanged);
      }
      toolbar.setAttribute("aria-label", immersiveEnabled ? "Conversation view" : "Task display");
      immersive?.setEnabled(immersiveEnabled);
      const activeFilter = preferences.activeOnly;
      // Capture surviving runs before filtering changes their geometry, including
      // live completion and resume updates that do not go through change().
      const filtering = activeFilter || content.dataset.activeRunsOnly === "true";
      const top = viewport.getBoundingClientRect().top;
      const anchors = filtering ? [...new Set([...content.querySelectorAll(".turn")].filter(root => !isFiltered(root)).map(anchorFor))]
        .filter(node => node?.getClientRects().length && node.getBoundingClientRect().bottom > top)
        .map(node => ({node, top: node.getBoundingClientRect().top})) : [];
      let visibilityChanged = (content.dataset.activeRunsOnly === "true") !== activeFilter;
      content.dataset.activeRunsOnly = String(activeFilter);
      activeOnly.checked = preferences.activeOnly;
      // Keep the notice ahead of history and live tasks so it cannot break
      // the adjacent-sibling rules that space and separate activity groups.
      if (content.firstElementChild !== emptyState) content.prepend(emptyState);
      for (const [group, record] of groups) {
        if (content.contains(group) && group.querySelector(":scope > .turn")) continue;
        // Immersive timing moves inside a turn. When a continuation is adopted
        // into another group, that row survives the old group unless removed here.
        resize.unobserve(record.preview);
        record.strip?.destroy();
        record.header.remove(); record.timing.remove(); groups.delete(group);
      }
      const all = [], tasks = new Map();
      let dirty = false;
      for (const group of content.querySelectorAll(".activity-group")) {
        const articles = [...group.querySelectorAll(":scope > .turn")];
        if (!articles.length) continue;
        const records = articles.map(root => ({...getTurn(root), root}));
        const first = records[0], taskId = group.dataset.taskId || first.taskId;
        const record = groups.get(group) || mount(group);
        const key = taskId ? `task:${taskId}` : first.root.dataset.requestId ? `request:${first.root.dataset.requestId}`
          : `submission:${first.root.dataset.submissionId || record.header.id}`;
        // Binding a provisional request or a durable task must retain the user's choice.
        if (record.key && (record.key !== key || record.cid !== cid)
            && (record.cid === cid || !record.cid) && !Object.hasOwn(preferences.overrides, key)) {
          preferences.overrides[key] = record.storedCollapsed ?? record.collapsed; dirty = true;
          delete preferences.overrides[record.key];
        }
        if (newSubmissions.has(articles[0])) {
          preferences.overrides[key] = false; newSubmissions.delete(articles[0]); dirty = true;
        }
        Object.assign(record, {key, cid, collapsed: collapsed(key), storedCollapsed: preferences.overrides[key] ?? preferences.collapsed});
        const item = {group, articles, records, record, taskId}; all.push(item);
        if (!tasks.has(key)) tasks.set(key, []);
        tasks.get(key).push(item);
      }
      if (dirty) save(cid, preferences);
      toolbar.hidden = false;
      let previousKey = null, leader;
      let visibleRuns = 0;
      for (const item of all) {
        const {group, articles, record, taskId} = item, members = tasks.get(record.key);
        const records = members.flatMap(member => member.records);
        const task = getTask(taskId);
        const taskNumber = validNumber(task?.creation_sequence) ? task.creation_sequence
          : records.find(turn => validNumber(turn.creationSequence))?.creationSequence;
        record.number.hidden = !taskId || !validNumber(taskNumber);
        if (!record.number.hidden) {
          const label = String(taskNumber);
          if (record.number.textContent !== label) {
            record.number.textContent = label;
            record.number.setAttribute("aria-label", `Task ${label}`);
            record.number.style.setProperty("--task-number-digits", String(label.length));
          }
          // Keep authoritative numbering when a task leaves the bounded lane snapshot.
          for (const turn of records) if (turn.root.dataset.creationSequence !== label)
            turn.root.dataset.creationSequence = label;
        }
        const headId = task?.current_request_id || task?.latest_request_id;
        const head = headId ? records.find(turn => turn.root.dataset.requestId === headId) : records.at(-1);
        const status = task?.status === "queued" ? "queued" : head?.status || task?.user_visible_status || task?.status;
        // A task can contain completed attempts and an active continuation.
        // Filter each request independently; task status must not revive old runs.
        for (const turn of item.records) {
          const filtered = activeFilter && !activeStatuses.has(turn.status);
          if ((turn.root.dataset.runFiltered === "true") !== filtered) visibilityChanged = true;
          if (filtered && turn.root.contains(document.activeElement)) activeOnly.focus({preventScroll: true});
          turn.root.dataset.runFiltered = String(filtered);
          if (!filtered) visibleRuns++;
        }
        const filtered = articles.every(article => article.dataset.runFiltered === "true");
        if ((group.dataset.runFiltered === "true") !== filtered) visibilityChanged = true;
        if (filtered && group.contains(document.activeElement)) activeOnly.focus({preventScroll: true});
        group.dataset.runFiltered = String(filtered);
        group.inert = filtered;
        const displayed = activeFilter ? records.filter(turn => activeStatuses.has(turn.status)) : records;
        const original = displayed.find(turn => turn.userAuthored !== false && turn.prompt) || displayed[0] || records[0];
        const mode = original.root.querySelector(":scope > .task-mode-banner");
        record.modeLabel.hidden = record.separator.hidden = !mode;
        if (record.modeLabel.textContent !== (mode?.textContent || "")) record.modeLabel.textContent = mode?.textContent || "";
        record.mode.dataset.mode = mode?.dataset.mode || "";
        const gateways = record.collapsed ? gatewaysFor(task, head || original) : [];
        const gatewaySignature = JSON.stringify(gateways);
        if (record.gatewaySignature !== gatewaySignature) {
          record.gateways.replaceChildren(...gateways.map(({id, label}) => {
            const tag = document.createElement("span"); tag.className = "task-disclosure-gateway";
            tag.textContent = label; tag.dataset.gatewayId = id;
            tag.title = `Target gateway: ${label} (${id})`;
            return tag;
          }));
          record.gatewaySignature = gatewaySignature;
        }
        record.gateways.hidden = !gateways.length;
        const prompt = preferences.activeOnly ? original.prompt || task?.prompt : task?.prompt || original.prompt;
        const preview = queryLabel(prompt, original.attachments);
        if (record.collapsed && record.previewSource !== preview) {
          // Reuse the shared plain-text renderer and cache by source; live status
          // updates should not parse the same prompt again or change its stored text.
          const plain = prompt?.trim() && window.SMTOMarkdown
            ? window.SMTOMarkdown.toText(preview, {limit: Infinity}) : preview;
          record.preview.textContent = plain.replace(/\s+/g, " ").trim();
          record.previewSource = preview;
        }
        const displayStatus = activeFilter && !filtered
          ? (displayed.includes(head) ? head : displayed.at(-1))?.status : status;
        const label = labels[displayStatus] || "Status unavailable";
        if (record.status.textContent !== label) record.status.textContent = label;
        record.status.dataset.status = displayStatus || "unknown";
        const duplicate = !filtered && previousKey === record.key;
        if (!filtered && !duplicate) leader = record.header;
        record.header.hidden = duplicate;
        group.dataset.disclosureAnchor = filtered ? record.header.id : leader.id;
        group.dataset.taskCollapsed = String(record.collapsed);
        group.classList.toggle("task-disclosure-fragment", duplicate && record.collapsed);
        record.preview.hidden = !record.collapsed;
        record.clock?.update(task?.created_at || original.sentAt);
        const durations = records.map(turn => turn.durationMs)
          .filter(value => typeof value === "number" && Number.isFinite(value) && value >= 0);
        const requestIds = new Set(records.map(turn => turn.root.dataset.requestId).filter(Boolean));
        const partial = durations.length !== records.length || (headId && !requestIds.has(headId))
          || records.some(turn => turn.root.dataset.parentRequestId && !requestIds.has(turn.root.dataset.parentRequestId));
        const seconds = Math.floor(durations.reduce((total, value) => total + value, 0) / 1000);
        const elapsed = seconds >= 60 ? `${Math.floor(seconds / 60)}m ${seconds % 60}s` : `${seconds}s`;
        const durationLabel = durations.length ? `${elapsed} · partial` : "Runtime unavailable";
        if (record.duration.textContent !== durationLabel) record.duration.textContent = durationLabel;
        record.duration.title = "Recorded response time only. Full task lifetime timing is unavailable."
          + (partial ? " Some response times are unavailable." : "");
        record.strip?.update(cid, taskId, task?.task_timing);
        const hasClock = record.clock && !record.clock.root.hidden;
        record.timeSeparator.hidden = !hasClock;
        record.toggle.setAttribute("aria-expanded", String(!record.collapsed));
        record.toggle.title = record.collapsed ? "Expand task" : "Collapse task";
        record.toggle.setAttribute("aria-label", record.toggle.title);
        const bodies = members.flatMap(member => member.articles);
        for (const article of bodies) article.id ||= `task-body-${++sequence}`;
        record.toggle.setAttribute("aria-controls", bodies.map(article => article.id).join(" "));
        for (const article of articles) {
          if (!filtered && record.collapsed && article.contains(document.activeElement)) leader.querySelector("button").focus({preventScroll: true});
          article.inert = record.collapsed || article.dataset.runFiltered === "true";
        }
        measure(record.preview);
        if (!filtered) previousKey = record.key;
      }
      for (const members of tasks.values()) {
        const owner = [...members].reverse().find(({group}) => group.dataset.runFiltered !== "true"
          && !group.classList.contains("task-disclosure-fragment"));
        for (const member of members) member.record.timing.hidden = member !== owner;
        if (!owner) continue;
        // Always follow content and controls, including the immersive controls.
        if (owner.group.lastElementChild !== owner.record.timing) owner.group.append(owner.record.timing);
      }
      window.SMTOTaskTiming?.refresh();
      const showEmpty = activeFilter && visibleRuns === 0 && !hasQueuedTasks();
      emptyState.hidden = !showEmpty;
      if (visibilityChanged) {
        const saved = anchors.find(({node}) => node.isConnected && !isFiltered(node) && node.getClientRects().length);
        if (saved) viewport.scrollBy({top: saved.node.getBoundingClientRect().top - saved.top, behavior: "instant"});
        viewport.dispatchEvent(new Event("task-disclosure-change"));
        // Defer until create() has returned; clients may still be initializing.
        queueMicrotask(changed);
      }
      rendering = false;
      immersive?.refresh();
    }
    function refresh() {
      if (pending) return;
      pending = true;
      queueMicrotask(() => { pending = false; sync(); });
    }
    function change(update, preferredAnchor, persist = true, hold = true) {
      scope(); preferences = read(cid);
      if (hold) beforeToggle();
      const top = viewport.getBoundingClientRect().top;
      const visible = [...content.querySelectorAll(".activity-group")]
        .find(node => node.getBoundingClientRect().bottom > top);
      const anchor = preferredAnchor || document.getElementById(visible?.dataset.disclosureAnchor);
      const y = anchor ? Math.max(top, anchor.getBoundingClientRect().top) : 0;
      const wasFiltered = content.dataset.activeRunsOnly === "true";
      update(); if (persist) save(cid, preferences); sync();
      if (wasFiltered === preferences.activeOnly && anchor?.isConnected && !isFiltered(anchor) && anchor.getClientRects().length)
        viewport.scrollBy({top: anchor.getBoundingClientRect().top - y, behavior: "instant"});
      viewport.dispatchEvent(new Event("task-disclosure-change"));
      changed();
    }
    collapseAll.onclick = () => change(() => { findExpanded.clear(); preferences.collapsed = true; preferences.overrides = Object.create(null); });
    expandAll.onclick = () => change(() => { findExpanded.clear(); preferences.collapsed = false; preferences.overrides = Object.create(null); });
    activeOnly.onchange = () => change(() => { preferences.activeOnly = activeOnly.checked; });
    immersiveToggle.onchange = () => change(() => { preferences.immersive = immersiveToggle.checked; }, null, true, false);
    const controller = {refresh, sync,
      isImmersive, navigatorOptions,
      accepted(next) {
        scope();
        if (!cid && next) {
          const saved = read(next);
          for (const key of ["immersive", "navigator"]) {
            if (typeof preferences[key] === "boolean") saved[key] = preferences[key];
          }
          save(next, saved);
          cache.delete("");
        }
      },
      resetDraft() { cache.delete(""); if (!cid) preferences = empty(); },
      submitted(root) { newSubmissions.add(root); sync(); },
      reveal(root) {
        sync(); const record = groups.get(root?.closest(".activity-group"));
        if (record && (record.collapsed || isFiltered(root))) change(() => {
          if (isFiltered(root)) preferences.activeOnly = false;
          preferences.overrides[record.key] = false;
        }, record.header);
      },
      reload(changedCid) {
        scope();
        if (changedCid !== undefined && changedCid !== cid) return;
        change(() => {}, null, false);
      },
    };
    // Find expands mounted task bodies without writing disclosure preferences or filters.
    window.SMTOUiFind?.registerReveal({root: content, selector: '.activity-group > .turn',
      reveal(article) {
        sync(); const record = groups.get(article.closest('.activity-group'));
        if (!record?.collapsed || isFiltered(article)) return null;
        const key = record.key, owner = cid;
        findExpanded.add(key); sync();
        return () => { if (cid === owner && findExpanded.delete(key)) sync(); };
      },
    });
    controllers.add(controller); sync();
    return controller;
  }
  window.addEventListener("storage", event => {
    if (event.key === null || event.key.startsWith(prefix)) {
      if (event.key) { cache.delete(event.key.slice(prefix.length)); unavailable.delete(event.key.slice(prefix.length)); }
      else { cache.clear(); unavailable.clear(); }
      for (const controller of controllers) controller.reload(event.key?.slice(prefix.length));
    }
  });
  window.addEventListener("pageshow", event => { if (event.persisted) for (const controller of controllers) controller.reload(); });
  window.addEventListener("task-timing-updated", () => { for (const controller of controllers) controller.refresh(); });
  window.SMTOTaskDisclosure = {create, anchorFor, isFiltered, forget};
})();
