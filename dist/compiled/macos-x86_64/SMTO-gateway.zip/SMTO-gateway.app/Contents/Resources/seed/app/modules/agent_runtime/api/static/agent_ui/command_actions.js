/* Fixed action boundary. Application behavior is supplied by canonical UI owners. */
(() => {
  "use strict";
  window.SMTOCommandActions = {create({conversation, input, statusPanel, operations,
    getView, showToast, onResult, beforeRestart, setConnection}) {
    const protocol = window.SMTOCommandProtocol;
    let helpDialog;
    function help(commands) {
      helpDialog?.remove();
      helpDialog = document.createElement("dialog"); helpDialog.className = "command-help";
      helpDialog.setAttribute("aria-label", "Application commands");
      const heading = document.createElement("h2"); heading.textContent = "Application commands";
      const close = document.createElement("button"); close.textContent = "Close"; close.type = "button";
      close.onclick = () => helpDialog.close(); helpDialog.append(heading, close);
      for (const command of commands) {
        const row = document.createElement("p"), title = document.createElement("strong");
        title.textContent = command.command;
        const aliases = command.aliases?.length ? ` (${command.aliases.map(a => "/" + a).join(", ")})` : "";
        row.append(title, document.createTextNode(`${aliases} — ${command.description}`));
        const reason = protocol.availability(command, getView());
        if (reason) { const note = document.createElement("small"); note.textContent = reason; row.append(note); }
        helpDialog.append(row);
      }
      helpDialog.addEventListener("close", () => input.focus({preventScroll: true}));
      document.body.append(helpDialog); helpDialog.showModal();
    }
    function render(raw, result, article) {
      article.replaceChildren();
      const title = document.createElement("strong");
      title.textContent = raw;
      const message = document.createElement("p");
      message.textContent = result.message;
      article.append(title, message);
      if (result.details?.backend) {
        const backend = document.createElement("p");
        backend.textContent = `Backend: ${result.details.backend.status}`;
        article.append(backend);
      }
      if (result.details?.gateways?.length) {
        const list = document.createElement("ul");
        for (const gateway of result.details.gateways) {
          const row = document.createElement("li");
          const symbol = gateway.status === "restarting" ? "✓" : gateway.status === "skipped" ? "–" : "✗";
          const mark = document.createElement("span"); mark.textContent = symbol;
          mark.dataset.uiSymbol = symbol === "✓" ? "check" : symbol === "✗" ? "cross" : "";
          row.append(mark, document.createTextNode(` ${gateway.label || gateway.node} — ${gateway.status}${gateway.reason ? `: ${gateway.reason}` : ""}`));
          list.append(row);
        }
        article.append(list);
      }
      if (result.details?.commands?.length) {
        const available = document.createElement("p");
        available.textContent = `Available commands: ${result.details.commands.map((c) => c.command).join(", ")}`;
        article.append(available);
      }
      onResult();
    }

    async function recover(action, article) {
    const busyFeedback = window.SMTOBusy?.begin({host: article, label: "Recovering request…"});
    try {
      beforeRestart();
      setConnection("restarting", "Restarting…");
      window.SMTOLifecycle.begin(action);

    } finally { busyFeedback?.finish(); }
  }


    const handlers = {
      ...operations,
      show_runtime_status: action => statusPanel.open(action.status),
      show_help: action => help(action.commands || []),
    };
    async function present(raw, result, captured) {
      if (!protocol.sameView(captured, getView())) return;
      if (result.presentation === "restart_recovery") {
        const article = document.createElement("article"); article.className = "command-result";
        article.setAttribute("role", "status"); conversation.append(article); render(raw, result, article);
        if (result.client_action?.type === "await_backend_restart") await recover(result.client_action, article);
        return;
      }
      if (result.message) showToast(result.message);
      if (result.status === "error" || !result.client_action) return;
      const action = result.client_action, handler = handlers[action.type];
      if (!Object.hasOwn(handlers, action.type) || typeof handler !== "function") throw window.SMTOErrors.error("ui_command_unavailable");
      if (action.conversation_id && action.conversation_id !== captured.conversation_id
        || action.request_id && action.request_id !== captured.request_id)
        throw window.SMTOErrors.error("ui_state_stale");
      await handler(action);
    }
    return {present, close: () => { statusPanel.close({focus: false}); helpDialog?.close(); }};
  }};
})();
