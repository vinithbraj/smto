---
id: desktop-ui
title: Desktop UI automation
kind: architecture
tags: [architecture, tools, gateway, desktop, ui]
order: 40
---
# Desktop UI automation

The optional `ui` skill inspects and operates native accessibility controls on the selected
Gateway. Enable **Desktop UI** in capability controls, then discover `ui`. Existing saved
capability selections are preserved. `ui.status` reports availability independently of enablement;
headless Gateways remain usable for other skills.

Use accessibility semantics first: find a button and invoke it, set an ordinary field value,
select a row, or set a checkbox to a desired state. The normal Agent reasons about the request;
matching, traversal, waiting and input dispatch are deterministic. No helper model or agent runs.

## Ownership and discovery

| Owner | Responsibility |
| --- | --- |
| `desktop` | Application/process lifecycle and top-level window geometry/focus |
| `screen` | Display geometry, screenshots, OCR and screen context |
| `clipboard` | Explicit clipboard reads and writes |
| `browser` | Managed or explicitly attached browser page DOM; prefer this for page controls |
| `ui` | Native accessibility elements and explicit bounded keyboard/pointer fallback |

Entry tools are `ui.status`, `ui.snapshot`, `ui.find`, and `ui.focused_element`.
Four sections expose the rest of the surface:

| Section | Operations (prefix each with `ui.`) |
| --- | --- |
| `ui.inspect` | `status`, `snapshot`, `find`, `element`, `focused_element` |
| `ui.semantic_actions` | `focus`, `invoke`, `set_value`, `select`, `toggle`, `expand_collapse`, `scroll` |
| `ui.input` | `key_press`, `type_text`, `pointer_move`, `pointer_click`, `drag` |
| `ui.wait` | `wait_for` |

All tools use the existing skill contract, capability policy, permission policy, execution
receipts and cancellation. Read operations include waits; every other operation is an external
write with ordinary confirmation metadata. A control can submit, delete or charge money;
its name is not proof of safety. No additional approval dialog or model classifier exists.

## Native prerequisites and limitations

| Platform | Semantic adapter | Input | Prerequisites and verification |
| --- | --- | --- | --- |
| Windows | UI Automation through `comtypes` and native UIA patterns | Win32 input, physical pixels | Interactive logged-in user; session 0 unavailable. UIPI and UAC/Secure Desktop remain authoritative. Adapter fixtures are portable; real Windows smoke must run on Windows before release validation. |
| macOS | Accessibility attributes/actions through PyObjC | Permission-gated Quartz output, native points | System Settings → Privacy & Security → Accessibility for the Gateway host. Probes never prompt. Semantic operations need neither Screen Recording nor Input Monitoring. Real macOS smoke must run on macOS before release validation. |
| Linux X11 | AT-SPI through PyGObject | XTEST output plus semantic text insertion | Graphical session, session accessibility bus, AT-SPI typelib and Python `gi`; XTEST is probed separately. Distribution packages commonly include `python3-gi`, `gir1.2-atspi-2.0`, and `at-spi2-core`. The Gateway interpreter must be able to import them. |
| Linux Wayland | AT-SPI where available | No keyboard/pointer fallback | No XWayland or compositor-policy bypass. AT-SPI windows can have UI-owned signed IDs where Desktop lacks native window support. |

Windows/macOS adapters are implemented but remain unverified on real hardware until their
platform smoke runs are recorded. Native support also depends on the target application's
accessible interfaces; unsupported actions return `ui.action_unsupported`.

The Gateway advertises `ui_status` even when native access is unavailable. Other tags are
`ui_accessibility`, `ui_keyboard`, `ui_pointer`, and `ui_drag`; they are reported only after
current prerequisites are checked. Configured tags cannot invent support. Saved run capability
snapshots retain existing semantics, and the Gateway rechecks current session/permission support
on every operation, including calls after resume.

Linux dependencies remain optional so a headless installation does not require GTK/GI build
libraries. The `ui-linux` Python extra installs PyGObject when the native GI development
prerequisites are present; distribution-provided GI packages must match the Gateway interpreter.
GTK3 is required only for the included purpose-built smoke fixture, not for the UI service.

## Elements, locators and references

`snapshot` defaults to the active window. An exact `scope.window_id` from Desktop selects
that window without focusing it. `scope.application_id` restricts the selected window and
`scope.ancestor_ref` restricts descendants to an observed element. It does not launch an app.

Elements contain a normalized role/control type, name, label, automation ID, bounded value
summary, states, bounds, supported actions and opaque `ref`. They include `ui_revision`,
`window_id`, and `application_id`. Native object handles are private.

Locators use literal `role`, `name`, `label`, `automation_id`, `control_type`, ordinary `value`,
and `state` predicates. Matching is exact by default; `exact=false` means case-insensitive
substring matching. No regex, platform query language, code, or model ranking is accepted.
For example:

```json
{"scope":{"window_id":"<desktop window ID>"},"locator":{"role":"textbox","label":"Project Name"}}
```

`find` returns all matches within its bound; a mutation requires exactly one match. An
incomplete traversal cannot prove a locator unique and therefore cannot authorize that mutation.
An exact reference can identify an already observed control in a larger tree.

References are random server-side IDs scoped to the Gateway service instance, desktop/window
and native element lifetime, conversation, run, and structural tree revision. They expire after
60 seconds. Changing structure, replacing a native object, closing/recreating a window, changing
Gateway/owner, or restarting the Gateway invalidates the ref. Every use reobserves the bounded
tree and compares the retained native identity. Ordinary value/state changes preserve identity.
`ui.element_stale` requires a new snapshot/find and deliberate choice of a new reference.
The service never substitutes a similar label or first match.

## Actions and input

Use `ui.invoke` for a primary semantic action. `set_value` replaces ordinary editable text.
`toggle` and `select` accept boolean `desired`; `expand_collapse` accepts `expanded` or
`collapsed`. Already satisfied desired states do not send another native action.
`scroll` uses native scroll/value interfaces, with a bounded direction and amount.

Keyboard input requires an exact already-focused non-secure target; use `ui.focus` explicitly
first. `key_press` accepts one key with up to four distinct modifiers (`CTRL`, `ALT`, `SHIFT`,
`META`). Keys include letters, digits, navigation keys, `SPACE`, and `F1`–`F12`.
macOS letter/digit chords currently use ANSI virtual-key positions. `type_text` inserts
ordinary text without reading or overwriting the clipboard.

Pointer tools are explicit fallback. `pointer_click` accepts either a current element ref
(clickable center calculated from current bounds) or a point. Points must declare:

| Space | Meaning |
| --- | --- |
| `screen_physical` | Global physical desktop pixels on Windows/X11; negative monitor origins are valid |
| `screen_logical` | Display-local logical offsets plus a Screen `display_id`; translated with that display's scale and origin |
| `window_client` | Client-local pixels plus exact Desktop `window_id`, on Windows/X11 |

macOS accepts logical points with a display ID; ambiguous global physical pixels on mixed-scale
displays and client coordinates without a proven client mapping are rejected. Returned AX bounds
are global native points. UI reuses Screen's display metadata without capturing pixels.
Drag duration is 100–5000 ms and 2–100 steps. Cancellation always attempts to release held
buttons and modifiers; native OS focus and permission policies still apply.

## Secure fields and external text

Secure fields return the fixed `<secure>` marker. Native secure status is checked before
requesting any backing value; secret-value locators never match. Ordinary `set_value`,
`type_text`, and `key_press` reject secure fields. No `set_secret` tool is exposed because
this transport has no private post-model Parameter Store binding. Use the existing `ask_user`
checkpoint to have the user enter credentials directly in the application, then confirm
completion. Never ask for passwords in chat.

Names, values, labels and dialog text are untrusted external data. Tool results retain their
data role and `content_trust=untrusted_external_data`; app text cannot become runtime policy
or system/developer instructions. Exact ordinary arguments and observations remain in normal
execution/result evidence, but activity diagnostics, model debug traces and portable handoff
omit UI payloads even when optional redaction is disabled. Secure backing values never enter
that evidence. UI content is not automatically copied into Memory or Working Context.

There is no keyboard capture, event recorder, continuous accessibility stream, screenshot,
background screen surveillance, clipboard paste implementation, shell script, or native-code
injection surface in this skill.

## Bounds, cancellation and unknown outcomes

Snapshot output is capped at 500 elements and depth 32; defaults are 200 elements and depth 8.
Names/labels/value summaries are capped at 512 characters; ordinary input text at 4096.
The native scan is capped at 2000 nodes/depth 32; wire results at 2 MiB. Resource budgets
are clamped, unknown fields are rejected, and omitted nodes report `truncated=true` with
`returned_nodes` and the observed `match_count` where applicable.

Timeouts are 1–60000 ms. `wait_for` polls inside one Gateway call, at 50–1000 ms intervals,
for appearance/disappearance or boolean states. A stale ref always fails; use a locator to
wait for disappearance. No Agent turns or helper inference are used by polling.

One native operation owns the input gate at a time. A deadline bounds the caller even if a
provider is blocked. The gate stays occupied until that provider actually returns, preventing
overlapping input after a timeout. Cancellation checks occur between native calls; an individual
OS call cannot always be interrupted. There is no forced termination of the target application.

After input dispatch begins, a cancellation, native failure, or lost response returns an
uncertain outcome (`executed=null`, `effect_unknown=true`, `remote_effect_possible=true`).
Never replay invoke, type, key, click or drag automatically. Inspect `snapshot`/`element`
explicitly and reconcile. Desired-state actions may be retried only after fresh observations.
Normal runtime journals block repeated unresolved mutations; the Gateway also rejects reused
execution IDs within its bounded recent-ID cache. This cache is not durable replay authority.

## Transport, errors and source ownership

Authenticated `POST /ui/operation` carries a closed operation/arguments envelope plus runtime
node, conversation, run and execution identities. `POST /ui/cancel` targets the same Gateway.
Inbound and outbound forwarding share schemas, sanitized errors, exact node checks and one-shot
dispatch. No controller-local fallback exists.

Canonical Error Catalog aliases cover `ui.accessibility_unavailable`, permission/session/adapter
failures, missing/ambiguous/stale/hidden/disabled elements, unsupported actions, forbidden secure
reads or secret binding, keyboard/pointer/coordinate errors, timeout/cancel, missing target
capability, uncertain outcome, invalid requests/responses, transport loss, busy and duplicate IDs.
Each has catalog remediation; native exception text is never returned.

`skills/ui` owns catalog declarations and selected-Gateway dispatch. `gateway_core/ui/contract.py`
owns schemas; `service.py` owns refs, waits and execution state; `adapter.py` owns normalized
traversal/geometry; `linux.py`, `macos.py`, and `windows.py` own native APIs. Shared Gateway,
authorization, cancellation, Error Catalog and content policy remain authoritative.
