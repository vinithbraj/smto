/* Presentation dictionary for rejected actions. Never changes validation or retries.
 * Resolve from persisted reason/error fields so live and historical traces agree.
 */
(() => {
  "use strict";
  const catalog = {
    missing_message: {
      reason_short: "Final response missing",
      reason_long: "This completion attempt did not include the required user-facing answer or explanation. A non-empty final response is needed before the task can finish.",
    },
    missing_cwd: {
      reason_short: "Working directory missing",
      reason_long: "The tool call did not provide a working directory in the required location (arguments.cwd). The runtime could not accept the call without knowing where to run it.",
    },
    unexpected_cwd: {
      reason_short: "Working directory placement rejected",
      reason_long: "The validator did not accept the working directory at {field}. For Shell Sequence, use one shared cwd at the top level; any cwd values inside steps must agree with it.",
    },
    missing_argument: {
      reason_short: "Required field missing",
      reason_long: "The tool call omitted {field}, a required field. It must be supplied before the call can be accepted.",
    },
    unexpected_argument: {
      reason_short: "Unexpected field",
      reason_long: "The tool call supplied {field}, which is not allowed at that location. The field must be removed or placed where the tool accepts it.",
    },
    http_body_representation_conflict: {
      reason_short: "Conflicting HTTP body representation",
      reason_long: "The body_mode selector disagrees with the supplied body field. smTO cannot choose between those meanings safely. Choose one body representation and retry.",
    },
    too_few_items: {
      reason_short: "Required list items missing",
      reason_long: "The tool call supplied {actual} items in {field}, but at least {expected} are required.",
    },
    too_many_items: {
      reason_short: "Too many list items",
      reason_long: "The tool call supplied {actual} items in {field}, but at most {expected} are allowed.",
    },
    invalid_argument_type: {
      reason_short: "Wrong field type",
      reason_long: "The tool call supplied the wrong kind of value for {field}. This field must be a JSON {expected}.",
    },
    tool_argument_validation: {
      reason_short: "Invalid tool arguments",
      reason_long: "The tool call did not meet the tool's input requirements. Its arguments must be corrected before it can be accepted.",
    },
    invalid_arguments_json: {
      reason_short: "Malformed tool arguments",
      reason_long: "The model returned tool arguments that could not be read as valid JSON. The runtime could not interpret the requested action.",
    },
    native_protocol_error: {
      reason_short: "Invalid response format",
      reason_long: "The model response did not follow the required tool-call format, so The runtime could not accept the proposed action.",
    },
    native_stream_error: {
      reason_short: "Model response was interrupted",
      reason_long: "The incomplete model decision was discarded. No operation from that incomplete response was executed.",
    },
    model_output_truncated: {
      reason_short: "Model response cut off",
      reason_long: "The model response ended before a complete action was available. The runtime could not safely interpret the unfinished response.",
    },
    unavailable_tool: {
      reason_short: "Tool unavailable",
      reason_long: "The model requested a tool that is not available for this task.",
    },
    output_contract_missing: {
      reason_short: "Response requirement missing",
      reason_long: "The model did not declare whether this task requires a final user-facing response. That requirement must be established before completion can be accepted.",
    },
    invalid_output_contract: {
      reason_short: "Invalid response requirement",
      reason_long: "The model supplied an invalid final-response requirement. The declaration must specify whether a response is required or no response is needed.",
    },
    frozen_output_contract: {
      reason_short: "Response requirement changed",
      reason_long: "The model tried to change the final-response requirement after it was established. Only a change in the user's request can revise that requirement.",
    },
    output_status_mismatch: {
      reason_short: "Completion status does not match",
      reason_long: "The proposed completion status does not match the task's response or evidence requirements.",
    },
    unrequested_recap: {
      reason_short: "Unrequested summary",
      reason_long: "The completion included a recap even though summaries are disabled and this task does not require a final response.",
    },
    finish_task_required: {
      reason_short: "Completion declaration missing",
      reason_long: "The model did not provide the required finish_task declaration. The runtime needs an explicit completion status and any required evidence or response.",
    },
    non_completion_tool: {
      reason_short: "Completion declaration expected",
      reason_long: "The model requested another tool while the runtime was waiting for a corrected completion declaration.",
    },
    reused_completion_call_id: {
      reason_short: "Completion identifier reused",
      reason_long: "The model reused a previous completion call identifier. The corrected completion must use a new identifier.",
    },
    invalid_completion: {
      reason_short: "Completion requirements not met",
      reason_long: "The proposed completion did not meet the task's requirements for status, evidence, or a final response.",
    },
    invalid_direct_completion: {
      reason_short: "Invalid direct completion",
      reason_long: "The model attached invalid completion information to a tool call. The runtime could not use it to finish the task after that tool result.",
    },
    unavailable_direct_completion: {
      reason_short: "Direct completion unavailable",
      reason_long: "This tool call cannot also finish the task. The runtime requires a separate completion declaration.",
    },
    completion_protocol_failed: {
      reason_short: "Completion could not be finalized",
      reason_long: "The model did not produce an acceptable completion declaration within the allowed correction attempts.",
    },
    missing_evidence: {
      reason_short: "Completion evidence missing",
      reason_long: "The completion did not include sufficient recorded results to verify that the requested work was done.",
    },
    missing_mutation_evidence: {
      reason_short: "Requested change not verified",
      reason_long: "The cited results do not verify the requested change. Read-only observations or a successful exit status alone may not prove that the change occurred.",
    },
    out_of_scope_evidence: {
      reason_short: "Evidence outside this task",
      reason_long: "The completion cites a result that is missing or does not belong to the permitted task evidence.",
    },
    incomplete_evidence: {
      reason_short: "Evidence incomplete",
      reason_long: "A cited result is incomplete, so it cannot yet verify the proposed completion.",
    },
    incomplete_observation: {
      reason_short: "Result needs further inspection",
      reason_long: "The final result was clipped or not fully observed. The relevant result must be inspected before completion can be accepted.",
    },
    stale_evidence: {
      reason_short: "Evidence out of date",
      reason_long: "A cited result is stale or has been superseded. Completion requires evidence that reflects the current state.",
    },
    self_assertion_evidence: {
      reason_short: "Claim is not verified evidence",
      reason_long: "The completion relies on an assertion rather than an observed result that verifies the requested outcome.",
    },
    check_mismatch: {
      reason_short: "Verification check failed",
      reason_long: "An observed result does not match the value required by a completion check.",
    },
    unobserved_check_value: {
      reason_short: "Check value not observed",
      reason_long: "A completion check refers to a value that was not present in the observed tool result.",
    },
    unsatisfied_prerequisite: {
      reason_short: "Prerequisite not satisfied",
      reason_long: "A required prerequisite remains unresolved, so the task cannot yet be marked complete.",
    },
    ambiguous_external_effect: {
      reason_short: "Action outcome uncertain",
      reason_long: "An external action may have taken effect, but its outcome has not been confirmed. Completion requires verification of what happened.",
    },
    open_requirement: {
      reason_short: "Requested outcome not verified",
      reason_long: "At least one requested outcome has not yet been observed in the recorded results.",
    },
    required_operation_unsuccessful: {
      reason_short: "Required operation unsuccessful",
      reason_long: "A required operation has not succeeded, so the task cannot be marked successfully completed.",
    },
    capability_verifier_unmet: {
      reason_short: "Required checks not satisfied",
      reason_long: "The runtime's verification checks have not confirmed all required outcomes for this task.",
    },
    pending_work: {
      reason_short: "Work or approval still pending",
      reason_long: "The task still has pending work or an unresolved approval. It cannot finish until those are resolved.",
    },
    superseded_intent: {
      reason_short: "Task request changed",
      reason_long: "The user's request changed during execution. This completion attempt refers to an earlier version of the task.",
    },
    run_stopping: {
      reason_short: "Task is stopping",
      reason_long: "Cancellation is pending, so the runtime cannot accept this completion attempt.",
    },
    run_not_running: {
      reason_short: "Task no longer running",
      reason_long: "This task is no longer in a running state, so the runtime cannot accept this completion attempt.",
    },
    ineligible_direct_result: {
      reason_short: "Final tool result not eligible",
      reason_long: "Direct completion requires a fresh, executed result from an eligible tool. The proposed final result does not meet that requirement.",
    },
    evidence_bundle_limit: {
      reason_short: "Too much completion evidence",
      reason_long: "The completion evidence exceeds the runtime's allowed size or item count.",
    },
    invalid_status_fields: {
      reason_short: "Completion fields do not match status",
      reason_long: "The supplied completion fields are inconsistent with the proposed task status.",
    },
    unsupported_failed_status: {
      reason_short: "Failure status not supported",
      reason_long: "The recorded task state does not support the proposed failed status.",
    },
    invalid_job_receipt: {
      reason_short: "Invalid job result",
      reason_long: "The completion cites a missing or invalid final job result.",
    },
    invalid_sequence_evidence: {
      reason_short: "Invalid sequence evidence",
      reason_long: "The completion cites Shell Sequence evidence that could not be validated.",
    },
    unexecuted_evidence: {
      reason_short: "Cited action did not execute",
      reason_long: "The completion relies on an action that did not execute. It cannot verify that the requested work was done.",
    },
    running_evidence: {
      reason_short: "Cited action still running",
      reason_long: "The completion relies on an action that is still running. Its final result is needed before completion can be verified.",
    },
    unsuccessful_evidence: {
      reason_short: "Cited result does not prove success",
      reason_long: "The completion cites an unsuccessful result that cannot verify the requested outcome.",
    },
    neutral_write_evidence: {
      reason_short: "Write success not confirmed",
      reason_long: "The cited write operation finished without confirming success. Its result cannot verify that the requested change occurred.",
    },
    unknown: {
      reason_short: "Action requirements not met",
      reason_long: "The runtime rejected this action without recording a descriptive reason.",
    },
  };
  for (const [alias, code] of Object.entries({
    evidence_required: "missing_evidence", missing_output_contract: "output_contract_missing",
    native_stream_incomplete: "native_stream_error", stale_current_evidence: "stale_evidence",
    success_status_mismatch: "output_status_mismatch", invalid_completion_declaration: "invalid_completion",
  })) catalog[alias] = catalog[code];
  for (const entry of Object.values(catalog)) Object.freeze(entry);
  Object.freeze(catalog);

  const clean = value => typeof value === "string"
    ? value.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f]/g, " ").slice(0, 2000).trim() : "";
  const isCode = value => /^[a-z][a-z0-9_]*$/.test(value);
  const known = value => Object.hasOwn(catalog, value);
  const generic = new Set(["unknown", "invalid_completion", "invalid_completion_declaration",
    "tool_argument_validation", "native_protocol_error"]);
  // Old trace records may lack the server's centralized error_detail projection.
  // Only stable causal codes select these fallback headings, never provider prose.
  const modelFailureTitles = Object.freeze({
    llm_request_timeout: "Model request timed out",
    llm_connection_refused: "Model server connection was refused",
    llm_connection_reset: "Model server connection was reset",
    llm_connection_closed: "Model server connection closed",
    llm_dns_resolution_failed: "Model endpoint name could not be resolved",
    llm_endpoint_unreachable: "Model endpoint is unreachable",
    llm_transport_error: "Model response was interrupted",
    llm_stream_malformed_event: "Model stream was malformed",
    llm_stream_invalid_utf8: "Model stream contained invalid data",
    llm_stream_event_size_limit: "Model stream exceeded a transport safety limit",
    llm_stream_total_size_limit: "Model stream exceeded a transport safety limit",
    llm_stream_protocol_error: "Model stream was malformed",
    llm_stream_interrupted: "Model response was interrupted",
  });
  function describe(detail = {}) {
    const error = clean(detail.error), reason = clean(detail.reason), kind = clean(detail.error_kind);
    const cause = clean(detail.provider_diagnostic?.category);
    const interrupted = ["native_stream_error", "native_stream_incomplete"].includes(kind)
      || ["native_stream_error", "native_stream_incomplete"].includes(reason);
    if (interrupted || Object.hasOwn(modelFailureTitles, cause) || Object.hasOwn(modelFailureTitles, kind)) {
      const code = Object.hasOwn(modelFailureTitles, cause) ? cause
        : Object.hasOwn(modelFailureTitles, kind) ? kind : "llm_stream_interrupted";
      const projected = detail.error_detail;
      return {reason_code: code, reason_short: clean(projected?.title) || modelFailureTitles[code],
        reason_long: [clean(projected?.likely_cause), clean(projected?.fix_hint)].filter(Boolean).join(" ")
          || catalog.native_stream_error.reason_long,
        model_failure: true, specificity: code === "llm_stream_interrupted" ? 1 : 2};
    }
    const diagnostic = [error, reason].find(value => value && !isCode(value)) || "";
    const codes = [reason, error, kind].filter(value => isCode(value));
    let code = codes.find(value => known(value) && !generic.has(value))
      || codes.find(known) || "unknown";
    let fields = {}, match;
    // Older snapshots retain the validator message but not its structured facts.
    if ((match = /^(Missing|Unexpected) (arguments(?:\.[\w-]+|\[\d+\])*)$/.exec(diagnostic))) {
      fields.field = match[2];
      code = match[1] === "Missing"
        ? (fields.field === "arguments.cwd" ? "missing_cwd" : "missing_argument")
        : (/\.cwd$/.test(fields.field) ? "unexpected_cwd" : "unexpected_argument");
    } else if ((match = /^(arguments\S*) requires (minItems|maxItems)=(\d+); got (\d+) items$/.exec(diagnostic))) {
      fields = {field: match[1], expected: match[3], actual: match[4]};
      code = match[2] === "minItems" ? "too_few_items" : "too_many_items";
    } else if ((match = /^(arguments\S*) must be (object|array|string|boolean|integer|number|null)$/.exec(diagnostic))) {
      fields = {field: match[1], expected: match[2]}; code = "invalid_argument_type";
    }
    const entry = catalog[code];
    let long = (window.SMTOBranding?.text(entry.reason_long) ?? entry.reason_long).replace(/\{(\w+)\}/g, (_, key) => fields[key] || "the specified field");
    if (code === "unknown") long = diagnostic || (codes.length
      ? `The runtime rejected this action with reason “${codes[0]}”. No descriptive explanation was recorded.`
      : long);
    else if (diagnostic) long += ` Details: ${diagnostic}`;
    return {reason_code: code, reason_short: entry.reason_short, reason_long: long,
      specificity: generic.has(code) ? 0 : 1};
  }
  window.SMTORejectionReasons = {catalog, describe};
})();
