---
id: historical-v54-gmail-integration
title: Historical V54 - Gmail Integration
kind: legacy
tags: [gmail, mail, email, oauth, integration, multi-account, sync, drafts, reminders, safety]
summary: How to connect Gmail, keep a local metadata cache, use multi-account mail workflows, draft or send messages, create reminders, and review confirmation-gated mutations.
order: 21
---

> Historical reference. See the current V55 architecture guide before using this material.

# Gmail Integration

The Gmail integration turns SMTO into a local mail workspace without
changing the core runtime boundary. The model can interpret mail intent and
draft safe structured actions. The runtime validates those actions, resolves the
selected Gmail account, checks scope and confirmation state, and then the Gmail
service calls Google APIs with locally stored OAuth tokens.

Use Gmail when email work benefits from the same SMTO operating model as
shell work: visible state, local caches, bounded model context, explicit account
selection, editable drafts, preview-first mutation, and retained evidence.

```mermaid
flowchart LR
    U[User] --> UI[Agent UI Mail workspace]
    UI --> API[Gmail API routes]
    API --> S[Gmail service]
    S --> C[Local metadata cache]
    S --> G[Google Gmail API]
    UI --> A[gmail.agent capability]
    A --> V[Runtime validation and confirmation]
    V --> S
```

## What It Can Do

The current integration supports:

- direct Gmail OAuth from the Agent UI;
- optional broker-mode OAuth when a shared broker service is configured;
- up to 10 connected accounts, each addressable by `account_ref`;
- a local SQLite metadata cache for accounts, labels, messages, attachments,
  senders, drafts, and sync state;
- manual and background sync with per-account state and sync event history;
- label, sender, search, selected-message, selected-thread, and current-draft
  workflows;
- prompt search over cached metadata plus bounded thread/body context;
- semantic sender and topic matching with LLM review when simple Gmail queries
  are not enough;
- editable compose drafts, reply drafts, transient draft variants, rewrites, and
  explicit send actions;
- thread summaries, extraction, selected-thread questions, and Gmail-derived
  reminder drafts;
- unsubscribe previews based on Gmail/List-Unsubscribe metadata;
- confirmation-gated batch mutations such as trash, archive, spam, read/unread,
  star/unstar, add label, and remove label;
- account disconnect and local data removal.

Gmail is an advanced integration. It handles personal or business mail, so keep
it behind normal runtime review habits: connect only accounts you control, keep
OAuth credentials private, and review every mutation before approving it.

## Setup

Open the Agent UI and use the Mail or Gmail controls. If Gmail is enabled, the
settings/status panel reports configuration, callback URL, connected accounts,
sync state, cache counts, labels, and any missing OAuth configuration.

Configuration can come from environment variables, backend settings, or the
Gmail OAuth settings panel:

| Setting | Purpose |
| --- | --- |
| `AOR_GMAIL_ENABLED` | Enables or disables the integration. Default is enabled. |
| `AOR_GMAIL_AUTH_MODE` | `direct` for local OAuth or `broker` for broker-assisted auth. |
| `AOR_GMAIL_CLIENT_ID` | Google OAuth client id for direct auth. |
| `AOR_GMAIL_CLIENT_SECRET` | Google OAuth client secret for direct auth. |
| `AOR_GMAIL_REDIRECT_URI` | Explicit callback URL when automatic base-url detection is not enough. |
| `AOR_GMAIL_OAUTH_BROKER_URL` | Broker base URL when auth mode is `broker`. |
| `AOR_AGENT_GMAIL_DB_PATH` | Override for the local Gmail SQLite store. |
| `AOR_GMAIL_AUTH_SECRET_PATH` | Path for persisted editable OAuth app credentials. |
| `AOR_GMAIL_BACKGROUND_SYNC_ENABLED` | Enables background cache sync. |
| `AOR_GMAIL_POLL_INTERVAL_SECONDS` | Background polling interval, clamped by runtime settings. |
| `AOR_GMAIL_PAGE_SIZE` | Gmail page size used by sync and list operations. |
| `AOR_GMAIL_SYNC_RECENT_MESSAGE_LIMIT` | Bounded recent-message sync target. |
| `AOR_GMAIL_WATCH_LABEL_IDS` | Optional comma-separated label ids to watch. |
| `AOR_GMAIL_PUBSUB_TOPIC_NAME` | Optional Pub/Sub topic for Gmail watch workflows. |
| `AOR_GMAIL_PUBSUB_SUBSCRIPTION_NAME` | Optional Pub/Sub subscription for notification pull. |
| `AOR_GMAIL_PUBSUB_CREDENTIALS_PATH` | Optional Google credentials file for Pub/Sub. |

For local development, add OAuth credentials through the UI or environment
instead of committing them. If the callback URL is wrong, set
`AOR_GMAIL_REDIRECT_URI` to the exact public or local callback:

```text
https://127.0.0.1:8011/api/agent/gmail/oauth/callback
```

Use HTTPS when the Agent UI is running with SSL enabled. Google OAuth redirect
URIs must match the scheme, host, port, and path.

## Accounts And Account References

SMTO can keep multiple Gmail accounts connected. Each account has:

- `account_id`, normally derived from the email address;
- email, display name, nickname, and primary-account flag;
- granted scopes and token health;
- per-account sync state and cache rows.

Most Gmail request payloads and query parameters accept `account_ref`. It may
be the account id, email address, or nickname. If no account is specified, the
runtime uses the primary connected account when one exists.

The Gmail capability also reads account context from the Mail workspace. If a
user says "use my work mailbox" and that wording matches a connected account
nickname or address, the runtime resolves that account before it searches or
mutates messages.

## Sync And Local Cache

Gmail list and prompt-search flows use a local metadata cache first where
possible. The cache stores message headers, sender identity, labels, snippets,
attachment metadata, draft metadata, and sync bookkeeping. Full message body
text is fetched on demand for selected threads or bounded semantic review.

The sync manager can:

- start a manual full or delta sync;
- stop a running sync cooperatively;
- record sync events;
- recover stale in-flight sync state after backend restart;
- backfill label-scoped message caches when the UI asks for a view that is not
  warm yet;
- run per-account background polling when enabled.

Useful routes:

| Route | Purpose |
| --- | --- |
| `GET /api/agent/gmail/accounts` | Connected account summaries and primary account. |
| `GET /api/agent/gmail/status` | Configuration, account, sync, labels, and cache status. |
| `POST /api/agent/gmail/sync` | Start sync, optionally with `force_full` and `account_ref`. |
| `POST /api/agent/gmail/sync/stop` | Request sync cancellation. |
| `GET /api/agent/gmail/sync/events` | Recent per-account sync events. |
| `GET /api/agent/gmail/labels` | Gmail labels, optionally refreshed from Google. |
| `GET /api/agent/gmail/messages` | Cached or Google-backed message lists. |
| `GET /api/agent/gmail/senders` | Sender inventory from cached metadata. |
| `GET /api/agent/gmail/threads/{thread_id}` | On-demand selected thread detail. |

The cache is local operational state. Do not commit `agent_gmail.db` if it
contains real account metadata.

## Mail Workspace

The Agent UI exposes Gmail in two connected forms:

- the Gmail drawer for setup, account management, prompt search, selected
  messages, and thread actions;
- the Mail workspace for a larger mailbox layout with accounts, labels, sender
  filters, message list, selected thread, composer, queue, and ledger helpers.

Common workflows:

```text
Find security alerts from the last 30 days.
```

```text
Draft a short reply to the selected thread saying I will review it tomorrow.
```

```text
Show newsletters that look safe to unsubscribe from.
```

```text
Create a reminder from this email.
```

Read-only searches and summaries can answer directly. Drafts remain editable.
Sends, trash, archive, label changes, spam marking, read/unread changes, and
batch unsubscribe actions require explicit confirmation unless a separate
runtime control has already approved the exact visible confirmation prompt.

## Drafts, Sends, And Reminders

Draft routes keep editing and sending separate:

| Route | Purpose |
| --- | --- |
| `POST /api/agent/gmail/drafts` | Create a new editable compose draft. |
| `PATCH /api/agent/gmail/drafts/{draft_id}` | Update a compose draft. |
| `POST /api/agent/gmail/drafts/reply` | Create an editable reply draft. |
| `PATCH /api/agent/gmail/drafts/{draft_id}/reply` | Update a reply draft. |
| `POST /api/agent/gmail/replies/suggest` | Ask the configured LLM for editable reply text. |
| `POST /api/agent/gmail/messages/suggest` | Ask the configured LLM for editable new-message text. |
| `POST /api/agent/gmail/compose/variants` | Generate transient compose or reply variants. |
| `POST /api/agent/gmail/drafts/{draft_id}/send` | Send a saved Gmail draft. |
| `POST /api/agent/gmail/replies/send` | Send a reply from visible editable text. |
| `POST /api/agent/gmail/messages/send` | Send a new message from visible editable text. |
| `POST /api/agent/gmail/reminders/draft` | Extract an editable reminder proposal from a thread. |
| `POST /api/agent/gmail/reminders` | Save a Gmail-derived reminder as an SMTO event. |

The model should not invent recipients, commitments, dates, attachments, or
facts. It receives bounded visible thread context and explicit user
instructions, then returns editable content.

## Safety Boundaries

Gmail follows the same trust pattern as the rest of SMTO:

| Actor | Owns |
| --- | --- |
| LLM | Intent interpretation, semantic matching, draft text, summaries, and variant suggestions. |
| Runtime | Account resolution, typed payload validation, confirmation state, trace evidence, and policy. |
| Gmail service | OAuth tokens, local cache, Google API calls, sync, and message mutation. |
| User | Account connection, final approval, edited draft text, and send/mutation decisions. |

Mutation operations are preview-first. The runtime can show matched messages,
unsubscribe methods, candidate counts, batch progress, rollback guidance, and
confirmation details before any mutation is applied.

Typical confirmation-gated operations:

- `send_draft`;
- `trash`;
- `archive`;
- `mark_spam`;
- `mark_read`;
- `mark_unread`;
- `star` and `unstar`;
- `add_label` and `remove_label`;
- `unsubscribe`;
- broad or batch cleanups.

The Gmail capability may use semantic matching for requests such as "marketing
emails" or "messages that likely need a reply." Semantic matching is evidence,
not authority. Current cache contents, selected account, Gmail query results,
runtime policy, and user approval still decide what happens.

## Troubleshooting

If Gmail does not connect:

- open the Gmail status panel and check missing configuration;
- verify the callback URL exactly matches the OAuth app redirect URI;
- verify `AOR_GMAIL_AUTH_MODE` is `direct` or `broker`;
- verify the browser is using HTTPS when SSL is enabled;
- reconnect the account if token health is expired or missing.

If mail does not appear:

- run `POST /api/agent/gmail/sync` from the UI sync button;
- check `/api/agent/gmail/sync/events`;
- confirm the selected `account_ref`;
- refresh labels;
- search with a smaller label or sender scope.

If an action is blocked:

- read the confirmation card and matched message list;
- confirm the account and selected thread/message ids;
- review the trace details for validation or Gmail API errors;
- approve only if the preview is the operation you intended.

Related docs:

- [System Surfaces And API Reference](17-system-surfaces-api-reference.md)
- [Modes, Approvals, And Clarifications](04-modes-approvals-clarifications.md)
- [Configuration And Storage](09-configuration-storage.md)
- [Gmail Integration Architecture](architecture/11-gmail-integration.md)
