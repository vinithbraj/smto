---
id: architecture-overview
title: Architecture overview
kind: architecture
tags: [architecture, tools]
order: 1
---
# Architecture overview

smTO is a model-led agent runtime for durable tool execution and automation.

```mermaid
flowchart TD
    USER --> MODEL
    MODEL --> T[TOOL CALL]
    T --> E[EXECUTION ENGINE]
    E --> R[REAL RESULT + RECEIPT]
    R --> MODEL
```

The model interprets the request, selects tools and arguments, interprets observations, corrects errors, and judges whether the goal is satisfied. smTO validates schemas, scope, authorization and exact evidence; executes operations; persists receipts; and projects state to the UI. No domain adapter owns a reasoning model.

```text
Long operation → durable job → wait without inference → automatic resume → the model
Complex task → optional model task board → the same tool/result loop
```

Ordinary chat enters this runtime. Optional Task Contract Compilation first prepares
accepted task intent inside the same run owner. Explicit monitor, schedule, parameter
and email product actions may use bounded drafting helpers. A configured monitor may
use an explicit condition judge on observations; it does not choose the agent's strategy.

Dependency direction is AgentLoop → ToolCatalog / ExecutionEngine → registered adapter → service/provider/gateway/OS. Providers must not import the agent loop. API services own their stores explicitly.

The source-owned registry includes execution, Files, Web, HTTP / REST, Gmail,
Database, Monitors, Schedules, Parameters, Artifacts, Agent Introspection and Agent KV,
plus Visualization guidance over existing tools. The
[generated Tool and Skill Reference](/manual#doc=generated-capabilities) enumerates
current registrations. HTTP / REST requests execute from the selected Gateway,
with private authentication managed by the configured credential flow.

See the source map, tool contract, and How to add a Skill guides in this manual.
