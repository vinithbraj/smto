---
id: source-documentation
title: Source and documentation architecture
kind: architecture
tags: [architecture, current, source-documentation]
order: 29
---
# Source and documentation architecture

Current behavior is defined by source, then exercising tests and configuration schemas.
Current canonical guidance explains it; file/symbol contracts document ownership nearby;
generated references enumerate the current structure. Historical reports remain evidence
of the version and measurements they recorded.

Tier A maintained implementation requires a full semantic file contract and significant
symbol docs. Tier B operational launch/install/developer tooling uses a concise header
covering use, inputs, effects and cleanup. Tier C tests, validation/benchmarks/history,
dependencies and generated indexes are excluded from mandatory product coverage.
Production artifact and execution-cache packages remain Tier A.

The Source Module Catalog covers all maintained languages, including CSS/HTML and
platform launchers. Subsystem pages expose ownership, boundaries, lifecycle, state,
security and collaborators. Static imports are relationships, not a proven call graph.
Compatibility/retired modules remain visible. Generated environment references publish
names and owners only, never live values or secret defaults.

Use the [source map](16-source-map.md) to find owners, then the generated references for
exhaustive paths. Before review, run
`.venv/bin/python scripts/source_documentation_audit.py --check`. New scripts require a
scope decision; new current documentation requires classification. Missing contracts and
broken repository relationships fail the audit. Semantic review is still required.

While the annotation rollout remains incomplete, CI adds
`--baseline docs/engineering/source-documentation-baseline.json` to reject new source
documentation gaps against reviewed existing debt. This does not change the full
coverage verdict. Current links and document/source classifications must still pass;
the uploaded report distinguishes existing debt from new and resolved findings.

See the [source standard](../../../../docs/engineering/source-documentation-standard.md)
and [authority guide](../../../../docs/engineering/documentation-authority.md).

## Contributor workflow

1. Start from the [source map](16-source-map.md#maintainer-route-through-a-request)
   and the relevant subsystem chapter. Read the actual registration/call site;
   static imports alone miss CLI, worker, platform and optional-skill entry points.
2. For a skill, follow [skill authoring](../../../../docs/skill-authoring.md): keep
   its definition in `skills/<skill_id>/skill.py`, registration in the existing
   catalog, and execution behind the capability adapter. Discovery and permission
   are separate. Keep generated capability data in package-data declarations.
3. Characterize a changed wire or effect boundary before moving it. Preserve
   Pydantic class/route docstrings because frameworks consume them; put semantic
   `## @brief` comments before declarations/decorators instead. Keep route order,
   public names, defaults and absent/false/zero field distinctions intact.
4. Extend the canonical `src/error_catalog/error_msg.json` and existing error
   helpers for error identities. Credential projection belongs to
   `src/agent_runtime/redaction.py`; do not log private request envelopes.
5. Add meaningful source contracts and update the subsystem manual. New documents
   need classification in `docs/engineering/documentation-inventory.json` and
   navigation in `docs/document-inventory.md`. Keep dated measurements historical.
6. Run focused tests with disposable state and scripted providers. After actual
   documentation repairs, remove only their resolved baseline entries, retaining
   review evidence. Never regenerate the baseline to accept new omissions.

With the existing compatible environment, start with:

```bash
PYTHONPATH=src:tests .venv/bin/python -m pytest -q tests/test_source_documentation_contract.py tests/test_documentation_links.py
.venv/bin/python scripts/source_documentation_audit.py --check --baseline docs/engineering/source-documentation-baseline.json --report-dir artifacts/code-health/docs-after
.venv/bin/python scripts/source_documentation_audit.py --prefix src/gateway_core/models.py --check
git diff --check
```

Select the prefix and tests for the files actually changed. The full strict audit
without `--baseline` remains failing until old Tier-A debt is repaired; a passing
regression gate does not imply full coverage. Audit output and local benchmark
samples belong under ignored `artifacts/`. No live provider, service restart or
browser campaign is necessary for source-comment edits. When executable UI or
runtime code changes, exercise its actual DOM, wire, authority and recovery seams.

The [October 9 cleanup report](../../../../docs/engineering/codebase-quality-cleanup-report.md)
records one bounded wave, including before/after evidence and deferred extractions.
