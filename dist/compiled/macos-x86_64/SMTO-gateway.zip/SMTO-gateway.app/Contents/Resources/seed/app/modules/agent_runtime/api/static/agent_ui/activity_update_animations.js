/* Optional text transitions for the shared single-line activity status.
 * Update existing nodes immediately; motion never delays or queues status truth. */
(() => {
  "use strict";
  const enter = transform => [{opacity: 0, transform}, {opacity: 1, transform: "none"}];
  const styles = new Map([
    ["roll", null],
    ["swipe-down", enter("translateY(-12px)")],
    ["swipe-up", enter("translateY(12px)")],
    ["slide-left", enter("translateX(14px)")],
    ["slide-right", enter("translateX(-14px)")],
    ["fade", [{opacity: 0}, {opacity: 1}]],
    ["zoom-in", enter("scale(.94)")],
    ["zoom-out", enter("scale(1.06)")],
    ["flip", enter("perspective(240px) rotateX(-45deg)")],
    ["blur", [{opacity: 0, filter: "blur(3px)"}, {opacity: 1, filter: "blur(0)"}]],
    ["bounce", [
      {opacity: 0, transform: "translateY(-12px)", offset: 0},
      {opacity: 1, transform: "translateY(2px)", offset: .7},
      {opacity: 1, transform: "none", offset: 1},
    ]],
  ]);
  const views = new WeakMap(), segments = new WeakMap(), active = new Set();
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  let preference = "roll";

  function stop(view) {
    if (!view) return;
    for (const animation of view.animations) {
      animation.onfinish = animation.oncancel = null;
      animation.cancel();
    }
    view.animations = [];
    view.outgoing?.remove();
    view.outgoing = null;
    active.delete(view);
  }

  function cancelActive() {
    for (const view of active) stop(view);
  }

  function snapshot(copy, value) {
    const old = copy.cloneNode(true);
    // A clock tick can refresh this snapshot while the preceding transition is
    // still running. Its outgoing row must not become part of the next one.
    old.querySelectorAll(".activity-update-outgoing").forEach(child => child.remove());
    old.classList.add("activity-update-outgoing");
    old.setAttribute("aria-hidden", "true");
    old.inert = true;
    old.removeAttribute("id");
    old.querySelectorAll("[id]").forEach(child => child.removeAttribute("id"));
    // Callers render detail text just after update; retain the new value now
    // so the next transition includes the complete preceding sentence.
    const detail = old.querySelector(".task-activity-detail");
    if (detail) detail.textContent = value.detail || "";
    return old;
  }

  function animate(view, child, frames, duration) {
    const animation = child.animate(frames, {
      duration, easing: "cubic-bezier(.2,.7,.2,1)", fill: "both",
    });
    animation.id = `activity-update-${preference}`;
    active.add(view);
    view.animations.push(animation);
    animation.onfinish = () => {
      if (view.animations.every(item => item.playState === "finished")) stop(view);
    };
    animation.oncancel = () => stop(view);
  }

  function setPreference(value) {
    const next = value === "none" || styles.has(value) ? value : "roll";
    if (next !== preference) cancelActive();
    preference = next;
    document.documentElement.dataset.activityUpdateAnimation = next;
  }

  function disposeSegment(node) {
    for (const token of segments.get(node)?.tokens || []) stop(token);
    segments.delete(node);
  }

  // Match words, not spaces: repeated separators must not displace unchanged
  // words. Trim the common ends so ordinary count/clock ticks have a tiny diff.
  function wordMatches(before, after) {
    const matches = [];
    let start = 0, oldEnd = before.length, newEnd = after.length;
    while (start < oldEnd && start < newEnd && before[start].text === after[start].text) {
      matches.push([start, start]); start++;
    }
    while (oldEnd > start && newEnd > start && before[oldEnd - 1].text === after[newEnd - 1].text) {
      oldEnd--; newEnd--;
    }
    const lengths = Array.from({length: oldEnd - start + 1},
      () => new Uint32Array(newEnd - start + 1));
    for (let i = oldEnd - 1; i >= start; i--) {
      for (let j = newEnd - 1; j >= start; j--) {
        lengths[i - start][j - start] = before[i].text === after[j].text
          ? 1 + lengths[i - start + 1][j - start + 1]
          : Math.max(lengths[i - start + 1][j - start], lengths[i - start][j - start + 1]);
      }
    }
    let i = start, j = start;
    while (i < oldEnd && j < newEnd) {
      if (before[i].text === after[j].text) { matches.push([i++, j++]); }
      else if (lengths[i - start + 1][j - start] >= lengths[i - start][j - start + 1]) i++;
      else j++;
    }
    while (oldEnd < before.length) matches.push([oldEnd++, newEnd++]);
    return matches;
  }

  function createToken() {
    const node = document.createElement("span"), current = document.createElement("span");
    node.className = "activity-update-token";
    current.className = "activity-update-word";
    node.append(current);
    return {node, current, space: document.createTextNode(""), text: "", animations: []};
  }

  function animateToken(token, previousText) {
    if (!token.current.animate) return;
    const rolling = preference === "roll", distance = token.node.getBoundingClientRect().height;
    const duration = rolling || preference === "bounce" ? 320 : 240;
    if (rolling && previousText) {
      const outgoing = document.createElement("span");
      outgoing.className = "activity-update-outgoing";
      outgoing.dataset.previousText = previousText;
      outgoing.setAttribute("aria-hidden", "true");
      outgoing.inert = true;
      token.node.append(outgoing);
      token.outgoing = outgoing;
      animate(token, outgoing, [
        {transform: "translateY(0)"}, {transform: `translateY(${distance}px)`},
      ], duration);
    }
    animate(token, token.current, rolling ? [
      {transform: `translateY(-${distance}px)`}, {transform: "translateY(0)"},
    ] : styles.get(preference), duration);
  }

  // Each word owns its motion. Outgoing text is purely visual, so textContent
  // and accessibility expose only live data, even during overlapping updates.
  function updateSegment(node, {text = "", transitionKey = text, kind,
    initial = true, animateNumbers = false}) {
    let view = segments.get(node);
    if (view && view.current.parentNode !== node) {
      disposeSegment(node);
      view = null;
    }
    const previous = view && {key: view.key};
    if (!view) {
      const current = document.createElement("span");
      current.className = "activity-update-current";
      node.classList.add("activity-update-segment");
      node.replaceChildren(current);
      view = {current, tokens: [], trailing: document.createTextNode("")};
      segments.set(node, view);
    }
    const key = JSON.stringify(transitionKey), changed = previous?.key !== key;
    const motion = !["idle", "terminal"].includes(kind) && preference !== "none"
      && !reducedMotion.matches && !document.hidden && node.isConnected
      && node.getClientRects().length > 0;
    view.key = key;
    const words = [];
    let end = 0;
    for (const match of text.matchAll(/\S+/gu)) {
      words.push({text: match[0], space: text.slice(end, match.index)});
      end = match.index + match[0].length;
    }
    const trailing = text.slice(end);
    if (view.trailing.data !== trailing) view.trailing.data = trailing;
    const tokens = [], before = view.tokens;
    let oldIndex = 0, newIndex = 0;
    // Pair replacements between matching anchors; extra new words enter and
    // deleted words disappear immediately, without animating their neighbors.
    for (const [oldMatch, newMatch] of [...wordMatches(before, words), [before.length, words.length]]) {
      while (newIndex < newMatch) {
        tokens.push(oldIndex < oldMatch ? before[oldIndex++] : createToken());
        newIndex++;
      }
      while (oldIndex < oldMatch) {
        const token = before[oldIndex++];
        stop(token); token.node.remove(); token.space.remove();
      }
      if (oldMatch < before.length) {
        tokens.push(before[oldMatch]); oldIndex++; newIndex++;
      }
    }
    const transitions = [], ordered = [];
    tokens.forEach((token, index) => {
      const word = words[index], previousText = token.text;
      const replaced = previousText !== word.text;
      if (replaced || !motion) stop(token);
      if (token.space.data !== word.space) token.space.data = word.space;
      token.text = word.text;
      if (animateNumbers && window.SMTONumberOdometer) {
        // Stable wait keys retain digit-only countdown motion. A word transition
        // owns the entire token, so it must never also start an odometer roll.
        window.SMTONumberOdometer.render(token.current, word.text,
          {live: motion && !changed && !token.animations.length});
      } else if (token.current.textContent !== word.text) token.current.textContent = word.text;
      if (replaced && changed && motion && (previous || !initial)) transitions.push([token, previousText]);
      ordered.push(token.space, token.node);
    });
    ordered.push(view.trailing);
    ordered.forEach((child, index) => {
      if (view.current.childNodes[index] !== child)
        view.current.insertBefore(child, view.current.childNodes[index] || null);
    });
    view.tokens = tokens;
    for (const [token, previousText] of transitions) animateToken(token, previousText);
  }

  function update(copy, value) {
    if (!copy?.matches(".task-activity-copy")) return;
    const detail = value.detail || "";
    const key = JSON.stringify([value.label, value.detailTransitionKey ?? detail,
      value.activeCount > 1 ? value.activeCount : 0, value.actionId || ""]);
    const previous = views.get(copy);
    if (previous?.key === key) {
      // Clock text is live data within the same wait. Keep it current without
      // starting (or restarting) a whole-status transition.
      if (previous.detail !== detail) {
        previous.detail = detail;
        previous.snapshot = snapshot(copy, value);
      }
      return;
    }
    stop(previous);
    const view = {key, detail, animations: [], snapshot: snapshot(copy, value)};
    views.set(copy, view);
    // Initial rendering and hidden/finished statuses don't need entrance motion.
    if (!previous || !value.label || ["idle", "terminal"].includes(value.kind)
        || preference === "none" || reducedMotion.matches || document.hidden
        || !copy.isConnected || !copy.getClientRects().length) return;
    // The existing overflow-hidden flex row clips moving text without changing
    // its dimensions, icons, focus, accessible content or surrounding scroll.
    const children = [...copy.children];
    const rolling = preference === "roll";
    const distance = rolling ? copy.getBoundingClientRect().height : 0;
    const duration = rolling || preference === "bounce" ? 320 : 240;
    if (rolling && copy.animate) {
      view.outgoing = previous.snapshot;
      copy.append(view.outgoing);
      animate(view, view.outgoing, [
        {transform: "translateY(0)"}, {transform: `translateY(${distance}px)`},
      ], duration);
    }
    for (const child of children) {
      if (child.hidden || !child.animate) continue;
      animate(view, child, rolling ? [
        {transform: `translateY(-${distance}px)`}, {transform: "translateY(0)"},
      ] : styles.get(preference), duration);
    }
  }

  reducedMotion.addEventListener("change", () => {
    if (reducedMotion.matches) cancelActive();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) cancelActive();
  });
  setPreference(document.documentElement.dataset.activityUpdateAnimation
    || window.__SMTO_MOBILE_BOOT__?.ui_activity_update_animation);
  window.SMTOActivityUpdates = {setPreference, update, updateSegment, disposeSegment};
})();
