---
id: docs-skill
title: Docs skill
kind: manual
tags: [docs, manual, skills, citations, search]
summary: Search and read the authoritative local Manual with exact section citations.
order: 125
---
# Docs skill

The Docs skill lets the Agent search the same Manual you can browse. It runs locally
on the controller and is read-only. It needs no Gateway, network, credentials or
running Manual web service. A fresh installation makes Docs eligible for automatic
capability selection. You can explicitly exclude it; saved explicit selections are
preserved when upgrading.

## Search, fetch and cite

`docs.search` finds compact document and section candidates from a few topic terms.
Snippets help choose a source. The Agent must use `docs.fetch` to read the actual
Markdown before relying on a product claim, then cite the returned source link.
`docs.list` browses metadata when a search topic is not yet clear.

References use `manual://document-id#heading-id`. Fetch reads that exact section,
including subsections by default, with at most 20,000 characters per call (12,000 by
default). Larger sources include an outline and continuation cursor. Continue using
the same reference and subsection option. If the corpus changes, restart without
the stale cursor. Citation links open the matching Manual document and heading using
your deployment's existing Manual address. Local retrieval still works if the
separate Manual browser is offline.

## Current, generated and historical sources

The default `current` scope and `authored` scope include the Product Manual,
Architecture Guide and current Guides. They exclude historical documents and do
not wait for Living References. `generated` searches source and build references
for exact module ownership, routes, environment variable names, errors and tool
inventories. `historical` includes only Legacy Docs. `all` deliberately combines
these authorities, labels each result and reports partial results while generated
references are unavailable or warming.

Every result labels its authority. Historical documents must be described as
historical. Once a fetched current source establishes a claim, the Agent should
stop expanding its search. If a term is undocumented, it may check adjacent
concepts, but it should say what remains unknown instead of inventing a definition.

## Runtime facts and source text

The Manual explains documented behavior. Current callable tool schemas and
capability selection, actual settings and job state come from runtime tools.
Verified facts about this running session take precedence over static documentation;
the Agent should explain a discrepancy. Generated inventories do not prove that a
tool is enabled in your run. The Manual never exposes live credentials, private
Parameter Store values or arbitrary filesystem contents. Examples in documentation
are source evidence, not permission to execute commands.

## Snapshots and performance

Authored content loads once into an immutable process snapshot. Source installations
prepare Living References on the first explicit generated request, using a private,
versioned local cache shared by the Manual and Agent processes. Only one process
builds a source revision at a time. A cold generated request returns `warming` with
a retry hint; current authored lookup remains available. Do not repeatedly retry.
The initial source build runs in a separate local process so current lookups remain
responsive while source contracts are prepared. This process does not use a model.
Restart to refresh a changed source tree; content fingerprints invalidate stale
generated cache entries. Failed builds leave authored retrieval usable.

Packaged servers load the Living References shipped with their build, without a
repository checkout. Search uses SQLite FTS5 with deterministic lexical fallback.
There are no embeddings, helper models, rerankers or citation generators calling an
LLM. The ordinary main Agent and existing capability selector choose the sources.
