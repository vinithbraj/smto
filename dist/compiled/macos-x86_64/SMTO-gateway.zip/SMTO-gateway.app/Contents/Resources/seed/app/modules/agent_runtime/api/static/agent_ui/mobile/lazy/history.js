/**
@file src/agent_runtime/api/static/agent_ui/mobile/lazy/history.js
@brief Render mobile history with server-owned activity and independent current selection.
@ingroup ProductInterfaces
@details
Responsibilities: Load searchable summary pages, render one Running indicator per active conversation, and expose metadata/delete actions.
Boundaries: APIs own run truth and atomic abandonment; aria-current only identifies the open conversation.
Lifecycle: Opening loads current summaries; shared invalidations debounce 180ms; response generations reject stale loads and disconnected sheets.
State: Cursor, timers and version live only for the open sheet; refresh restores focused controls by conversation key.
Security: Text-node rendering prevents title/preview HTML injection; deletion uses reviewed server digests.
Collaborators: mobile/app.js delivers update topics and navigation hooks; api.js owns requests; overlays.js owns sheet lifetime.
Public surface: open and deletion present history/actions; hooks.historyRefresh schedules an authoritative reload.
@see src/agent_runtime/api/static/agent_ui/mobile/app.js
@see src/agent_runtime/api/static/agent_ui/mobile/mobile.css
*/
import { api, state, node, button, encode, storage, notice } from "../api.js?v=20261018-loading";
import { conversations } from "../../deletion_progress.js?v=20261018-immersive-default";
import { openSheet, mountControls } from "../overlays.js?v=20261018-loading";
const deletionState = () => window.SMTOConversationDeletion;
const blocked = id => deletionState()?.blocked(id) || false;

/** Open a fresh history sheet and bind its generation-guarded activity refresh hook. */
export async function open(hooks, feedback = null) {
  const views = new Map();
  const body = openSheet("Conversation history", { drawer: true,
    returnFocus: document.getElementById("history"),
    onClose: () => window.removeEventListener("smto:conversation-deletion", updateDeletion) });
  feedback?.move(body); feedback?.update("Loading history…");
  mountControls(body, document.getElementById("mobile-brand"));
  body.append(button("＋ New chat", hooks.newChat, "choice"));
  const search = node("input");
  search.type = "search";
  search.placeholder = "Search chats";
  search.setAttribute("aria-label", "Search chats");
  body.append(search);
  const list = node("div");
  body.append(list);
  function updateRow({chat, row, title, menu, heading}) {
    const id = chat.conversation_id;
    if (deletionState()?.isDeleted(id)) { row.remove(); views.delete(id); return; }
    const deleting = deletionState()?.isDeleting(id) || false;
    row.dataset.deleting = String(deleting);
    row.dataset.deletionState = deleting ? deletionState().state(id) : '';
    row.dataset.runActive = String(!deleting && chat.has_active_run === true);
    title.disabled = menu.disabled = deleting;
    heading.querySelector(".history-run-state")?.remove();
    if (deleting || chat.has_active_run) {
      const badge = node("small", null, `history-run-state${deleting ? " history-delete-state" : ""}`);
      badge.title = deleting ? deletionState().detail(id) : `${chat.active_run_count} active run${chat.active_run_count === 1 ? "" : "s"}`;
      const dot = node("span", null, "history-run-dot"); dot.setAttribute("aria-hidden", "true");
      badge.append(dot, deleting ? deletionState().label(id) : "Running"); heading.append(badge);
    }
  }
  function updateDeletion() {
    for (const view of views.values()) updateRow(view);
    if (!list.children.length) list.append(node("p", "No conversations found.", "muted"));
  }
  window.addEventListener("smto:conversation-deletion", updateDeletion);
  let cursor = null,
    version = 0,
    timer;
  const more = button("Load more", () => load(true));
  more.hidden = true;
  body.append(more);
  const nav = node("nav");
  for (const [title, path] of [
    ["Settings", "/settings"],
    ["Schedules", "/schedules"],
    ["Workflows", "/workflows"],
    ["Notifications", "/notifications"],
    ["Desktop view", "/agent-ui?ui=desktop"],
  ]) {
    const a = node("a", title);
    a.href = path;
    nav.append(a);
    if (path === "/settings") {
      const additional = document.getElementById("optional-surface-navigation");
      if (additional) nav.append(additional.content.cloneNode(true));
    }
  }
  body.append(nav);
  /** Fetch one summary page; reject stale responses and restore focused row controls. */
  async function load(append = false, quiet = false) {
  const busyFeedback = quiet ? null : window.SMTOBusy?.begin({host: list, label: "Loading history…", key: "history", replace: true});
  try {
    const attempt = ++version,
      params = new URLSearchParams({ limit: "40", query: search.value });
    if (append && cursor) params.set("cursor", cursor);
    more.disabled = true;
    try {
      const payload = await api(`chats?${params}`);
      if (attempt !== version || !body.isConnected) return;
      conversations.ingest(payload.chats);
      const focusKey = list.contains(document.activeElement) ? document.activeElement.dataset.focusKey : null;
      if (!append) { list.replaceChildren(); views.clear(); }
      cursor = payload.next_cursor;
      for (const chat of payload.chats || []) {
        if (deletionState()?.isDeleted(chat.conversation_id)) continue;
        const row = node("div", null, "row history-row");
        row.dataset.conversationId = chat.conversation_id;
        row.dataset.runActive = String(chat.has_active_run === true);
        const title = button(
          "",
          () => { if (!blocked(chat.conversation_id)) return hooks.openConversation(chat.conversation_id); },
        );
        const heading = node("span", null, "history-item-heading");
        const name = node("span", `${chat.pinned ? "★ " : ""}${chat.title || "Untitled conversation"}`, "history-item-title");
        name.title = chat.title || "Untitled conversation";
        heading.append(name);
        title.append(heading);
        title.setAttribute(
          "aria-current",
          String(chat.conversation_id === state.conversationId),
        );
        title.dataset.focusKey = `open:${chat.conversation_id}`;
        if (storage.get(`draft.${chat.conversation_id}`))
          title.append(node("small", " · Draft", "muted"));
        const menu = button("⋯", () => actions(chat, hooks));
        menu.dataset.focusKey = `menu:${chat.conversation_id}`;
        menu.setAttribute(
          "aria-label",
          `Actions for ${chat.title || "conversation"}`,
        );
        row.append(title, menu);
        const view = {chat, row, title, menu, heading};
        views.set(chat.conversation_id, view); updateRow(view);
        list.append(row);
      }
      if (!list.children.length)
        list.append(node("p", "No conversations found.", "muted"));
      more.hidden = !cursor;
      if (focusKey) [...list.querySelectorAll("[data-focus-key]")].find(el => el.dataset.focusKey === focusKey)?.focus({preventScroll: true});
    } catch (error) {
      if (body.isConnected) {
        list.append(
          node("p", error.message, "error"),
          button("Retry", () => load(false)),
        );
      }
    } finally {
      more.disabled = false;
    }

  } finally { busyFeedback?.finish(); }
}
  search.oninput = () => {
    version++;
    clearTimeout(timer);
    timer = setTimeout(() => void load(), 220);
  };
  hooks.historyRefresh = () => {
    if (!body.isConnected) return;
    version++;
    clearTimeout(timer);
    timer = setTimeout(() => { if (body.isConnected) void load(false, true); }, 180);
  };
  await load(false, Boolean(feedback));
}
/** Present rename, pin and protected deletion actions for one selected conversation. */
function actions(chat, hooks) {
  if (blocked(chat.conversation_id)) return;
  const back = () => void open(hooks),
    body = openSheet("Conversation actions", { back });
  body.append(node("p", chat.title || "Untitled conversation"));
  const input = node("input");
  input.value = chat.title || "";
  input.maxLength = 160;
  input.setAttribute("aria-label", "Conversation title");
  body.append(input);
  body.append(
    button(
      "Rename",
      async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating conversation…");
 try {
        await api(`chats/${encode(chat.conversation_id)}`, {
          method: "PATCH",
          body: { title: input.value.trim() },
        });
        back();

 } finally { busyFeedback?.finish(); }
},
      "choice",
    ),
  );
  body.append(
    button(
      chat.pinned ? "Unpin" : "Pin",
      async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating conversation…");
 try {
        await api(`chats/${encode(chat.conversation_id)}`, {
          method: "PATCH",
          body: { pinned: !chat.pinned },
        });
        back();

 } finally { busyFeedback?.finish(); }
},
      "choice",
    ),
  );
  body.append(
    button("Delete conversation", () => deletion(chat, hooks), "choice"),
  );
}
/** Confirm deletion of the reviewed conversation, including its current and queued work. */
export async function deletion(chat, hooks) {
  if (blocked(chat.conversation_id)) { notice("This conversation is already being deleted."); return; }
  const selection = { conversation_ids: [chat.conversation_id] };
  const feedback = await import("../../deletion_progress.js?v=20261018-immersive-default");
  let progress, preview;
  const back = () => actions(chat, hooks),
    body = openSheet("Delete conversation?", { back, onClose: () => progress?.close() });
  const busyFeedback = window.SMTOBusy?.begin({host: body, label: "Reviewing conversation deletion…"});
  try {
  progress = feedback.create(body);
  progress.start("Reviewing conversation…");
  try {
    preview = await api("chats/delete-preview", { method: "POST", body: selection });
  } catch (error) {
    progress.fail("Could not review deletion · Try again");
    if (body.isConnected) body.append(button("Review again", () => deletion(chat, hooks)));
    throw error;
  }
  if (!body.isConnected) return;
  progress.hide();
  body.append(
    node(
      "p",
      `${chat.title || "This conversation"} and its saved turns will be removed. This cannot be undone.`,
    ),
  );
  body.append(node("p", "Deleting discards queued prompts and prevents further work in this conversation. Cancellation of running operations will be requested; already-started external operations may continue, and unresolved effects may remain unknown. The conversation disappears as soon as deletion is accepted. Stored data is cleared in the background when no tasks are active; the cleanup indicator shows progress. Only information needed to reconcile unfinished operations or serve other owners is retained. Saved Memory, pinned procedures, independent schedules, monitors and tasks remain."));
  if (preview.blocked_count) {
    for (const blocked of preview.blocked || [])
      body.append(
        node(
          "p",
          (blocked.blockers || []).map((b) => b.label).join(" "),
          "error",
        ),
      );
    body.append(
      node(
        "p",
        "This conversation has active or unresolved work that will be abandoned.",
      ),
    );
    body.append(
      button("Open conversation", () =>
        hooks.openConversation(chat.conversation_id),
      ),
    );
  }
  if (preview.queued_tasks_to_discard) {
    body.append(node("p", `${preview.queued_tasks_to_discard} queued prompts that have not started will be discarded.`));
  }
  const confirm = button(
    "Confirm deletion",
    async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating conversation…");
 try {
      if (blocked(chat.conversation_id)) return;
      // The shared button helper disables the control before invoking this action.
      // It owns duplicate-click protection; disabled here is not a reason to abort.
      confirm.textContent = "Queuing…";
      confirm.setAttribute("aria-busy", "true");
      progress.start("Requesting deletion…", {persist: true});
      const settle = feedback.conversations.begin([chat.conversation_id]);
      let committed;
      try {
        const result = await api("chats/bulk-delete", {
          method: "POST",
          body: {
            selection,
            selection_digest: preview.selection_digest,
            safety_digest: preview.safety_digest,
            discard_queued_chat_tasks: true,
            abandon_unresolved_work: true,
          },
        });
        committed = result;
        settle(result);
        confirm.remove();
        progress.update(result.accepted_count ? "Pending delete · You can continue working" : "Deletion confirmed · Updating conversation list…");
        progress.detach();
        if (result.accepted_count) progress.finish(result);
        storage.set(`draft.${chat.conversation_id}`, null);
        if (state.conversationId === chat.conversation_id)
          await hooks.openConversation(blocked(result.fallback_conversation_id) ? null : result.fallback_conversation_id || null, {fallbackOnMissing: true});
        else if (body.isConnected) await open(hooks);
        progress.finish(result);
      } catch (error) {
        if (!committed) settle();
        if (committed) { progress.finish(committed, {refreshFailed: true}); throw error; }
        progress.fail(error.status === 409 ? "Conversation changed · Review deletion again" : "Deletion was not confirmed · Try again");
        if (error.status === 409) {
          body.append(
            node("p", "The conversation changed. Review deletion again."),
            button("Review again", () => deletion(chat, hooks)),
          );
          confirm.remove();
        } else {
          confirm.disabled = false;
          confirm.textContent = "Confirm deletion";
          confirm.setAttribute("aria-busy", "false");
          throw error;
        }
      }

 } finally { busyFeedback?.finish(); }
},
    "primary",
  );
  confirm.disabled = !(preview.force_deletable_count ?? preview.candidate_count);
  body.append(progress.element, confirm);

  } finally { busyFeedback?.finish(); }
}
