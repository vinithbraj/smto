---
id: errors-diagnostics
title: Errors and diagnostics
authority: current
kind: manual
summary: Find an error by its stable ID and follow the remedy for the actual failing component.
tags: [errors, diagnostics, settings]
order: 27
---

# Errors and diagnostics

An SMTO error shows a readable ID such as `SMTO-LLM-0001`. Use **Explain this error** to open its permanent Manual page, or search the [Error Catalog](/manual#doc=generated-error-catalog) by ID, GUID, slug or older error name. Each page explains what happened, how to diagnose it, what can be fixed, how to verify the change and what to avoid.

The Error ID identifies the kind of failure. The occurrence ID identifies this particular observation. Keep both when reporting a persistent problem, together with safe task and operation references. Technical details may be shortened and private values removed; exact execution receipts remain the source for completed work.

The main error card shows what was observed and the next useful check. When the
occurrence retained a safe fact, such as a timeout or token count, the card includes
it. A possible cause is a lead to investigate, not a finding. The Manual explains
the error type; it cannot know facts that were never recorded for your occurrence.

For example, a **120-second model request timeout** means a connection or read wait
reached its limit. It does not prove the model crashed or that the whole request
lasted exactly 120 seconds. Check provider health first. A suggested longer wait is
a diagnostic test, and a changed task setting applies to a new task.

Follow the control named by the error. A model request timeout, a foreground command timeout and a Task Contract output limit belong to different controls. A setting link opens and focuses its control without changing it. When a setting says **new task**, changing it does not alter the saved value used by Resume.

For **Full tool results** capacity failures, a tool can finish successfully before its complete result makes the next model request too large. Keep that result. Use smaller output, or start a new task with Adaptive or Compact selected under **Mission Control → Advanced → Tool result delivery**. Increasing maximum completion tokens reserves more space for output and leaves less space for input. Do not replay completed work to repair this failure.

A lost connection or missing acknowledgement can leave a mutation's outcome unknown. Inspect the authoritative remote state and the retained receipts before repeating the operation. The diagnostic itself does not authorize retry, acceptance of a changed host identity or weaker permissions.

For an **HTTP 403**, check the account, resource access and service policy before
changing credentials. The status proves that access was denied; it does not by
itself identify an expired password or a disabled response format.

If withdrawing a steering instruction is **unconfirmed**, check that instruction's
saved status before sending a replacement. An instruction already claimed or
applied cannot be withdrawn by repeating Cancel.

If the **Gateway becomes reachable again**, check the original operation or job
receipt too: a restored connection does not settle what the earlier work did. If a
**download wait expires**, inspect that download's existing status and artifact
before clicking Download again. It may still be running or may already have finished.

Every error includes simple steps explaining what to do, why it helps, what success looks like, and what to do if it still fails. Open **Show steps** on a compact error card for the full explanation. **Technical details** contains the instructions and diagnostic information for someone maintaining the installation.

Use **Copy error details** to keep the error reference for the person helping you. This copies the error name and references, not your task content or technical logs. If your browser blocks automatic copying, select and copy the text shown instead. If you manage the installation yourself, **Explain this error** opens its troubleshooting page.

Some errors have no confirmed quick fix. Their steps explain how to check what happened and get help. If an action may already have happened, check its result before trying it again. A restart or a wait is recommended only when the particular problem supports it. Retired Error IDs remain searchable so historical traces keep their meaning.

## Informational Agent Check observations

**Settings → Agent Checks → Monitor disabled Agent Checks** shows when a disabled check detects a condition it would normally handle. Fresh installations start with monitoring ON; existing installations retain their setting, and missing legacy values resolve OFF. Changes apply to newly accepted work. Individual switches still control enforcement.

The Activity note says the Agent continued because the check is disabled. **Learn more** opens the relevant Error Catalog page when the detector has a catalog reference, otherwise the [Agent Checks explanation](/manual#doc=checks-authority). It is informational, not a failed execution or a request for approval. Monitoring neither blocks the run nor makes additional model calls, and it does not change the truth recorded in execution receipts.
