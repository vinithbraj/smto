/* Present the mode saved with each task, independently of the current composer. */
(() => {
  "use strict";
  function modeOf(source) {
    if (!source) return null;
    const collaboration = source.collaboration_mode ?? source.context?.collaboration_mode
      ?? source.composer_values?.collaboration_mode ?? source.native_profile?.collaboration_mode
      ?? source.response_metrics?.collaboration_mode;
    if (collaboration === "plan") return "plan";
    const agent = source.agent_mode ?? source.composer_values?.agent_mode;
    return {agent: "agent", conversation: "agent", advisory: "ask"}[agent] || null;
  }
  function render(root, ...sources) {
    const mode = sources.map(modeOf).find(Boolean);
    if (!root || !mode) return;
    let banner = root.querySelector(":scope > .task-mode-banner");
    if (!banner) {
      banner = document.createElement("div");
      banner.className = "task-mode-banner";
      root.prepend(banner);
    }
    banner.dataset.mode = mode;
    banner.textContent = {agent: "Agent", ask: "Ask", plan: "Plan"}[mode];
  }
  window.SMTOTaskMode = {render};
})();
