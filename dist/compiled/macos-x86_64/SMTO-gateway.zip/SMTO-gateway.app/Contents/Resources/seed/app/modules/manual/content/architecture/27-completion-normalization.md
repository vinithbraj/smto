---
id: completion-normalization
title: Completion and normalization boundaries
kind: architecture
tags: [architecture, current, completion-normalization]
order: 27
---
# Completion and normalization boundaries

The model proposes completion. `native/completion.py` verifies the request's required
evidence and checks; output/final-response contracts determine what must be delivered.
A successful tool result alone is not permission to stop when other obligations remain.

Completion authority also enforces the user-input control boundary. A required
unresolved human interaction blocks successful completion, including Direct Completion.
Only model-authored terminal text is inspected for explicit continuation intent;
tool output, fenced code and obvious quotations are not interpreted as requests.
The reason `terminal_continuation_requires_ask_user` records rejected completion.
The next ordinary decision retains the full tool set allowed by capability and skill
policy. The shared internal decision-control envelope supplies the rejection reason,
evidence and guidance in every context mode. Advertisement, provider tool choice,
single dispatch and batch admission never impose a completion-only restriction.
Execution does not count as another completion rejection. Repeated invalid completions
use the configured no-progress bound; there is no special two-strike termination.
The runtime never manufactures an ASK or an executable action from ambiguous prose.

Completion candidates are advisory. New accepted work invalidates old candidates;
steering and evidence revisions also invalidate their acceptance. Deterministic
normalization can accept valid metadata and evidence without rewriting the answer.
Otherwise the next ordinary task decision chooses what to do, with no dedicated
wording-repair model call. Permissions, approvals, lifecycle waits, evidence checks
and recorded operation identities keep their existing authority.

The guard runs before Summary OFF can remove a message. Direct Completion markers
carry status/evidence, not final prose; their requested-answer stage uses the same
guard. Optional retrospective summaries also reject continuation wording before
publication, preserving the already-accepted terminal outcome without another call.
Question marks, rhetorical headings and optional suggestions for future requests do
not by themselves imply waiting. The lexical fallback is deliberately conservative
and is not a general natural-language intent classifier.

Direct completion carries model-declared terminal intent alongside an action, using the
retained `__smto_completion` compatibility field. The runtime removes that metadata
from business arguments while preserving the assistant journal. It validates completion
only after durable capability results exist. Accumulated evidence can refer to prior
receipts; it does not erase unfinished work or requested chat output.

`terminal_normalization.py` handles guarded text-only final responses. It checks pending
work, approvals/jobs/task-board state and unresolved mutations through ordinary
completion authority. It is unrelated to the target-host terminal process manager.
Explicit declarations and response-pending recovery retain their established paths.

`schema_correction.py` performs transactional argument normalization. Its shared container
decoder uses the tool's current argument schema: a string at a field explicitly typed as
an object or array can be decoded once as JSON. This works for new tools without adding
tool-specific rules, including nested properties, array items, tuple items, typed maps,
nullable container types, and local JSON Pointer references. Declared string fields and
untyped data remain unchanged. Ambiguous/composed schemas, pattern-based properties,
remote references, and reference siblings that add constraints are left to validation.
Schema traversal is bounded to 64 levels; it never retrieves external schemas.

Decoding requires complete JSON with unique object keys and finite numbers. It never
repairs quotes, brackets, command text, or recursively unwraps a string at the same field.
Registered tool/path corrections (such as shared Shell sequence cwd and timeout rules)
run after decoding. A candidate is accepted only after the entire result passes strict
validation against the supplied schema; any unresolved failure retains the original call.
The raw model journal stays unchanged, while corrections are recorded as value-free paths
under `schema.decode_json_container` and executable receipts use the normalized arguments.

Shell command arguments and Shell sequence steps also omit `sudo_password` and
`sudo_username` when their value is JSON `null` and the current schema declares them
as optional strings. These exact-path rules treat null as no credential supplied;
they preserve supplied strings (including empty strings), leave other invalid values
to validation, and never traverse opaque input data. Shell parallel and scheduled
command children use the same command rules. Required or nullable credential schemas
retain their original values. Corrections remain transactional and value-free.

`core/schema_containers.py` supplies the schema traversal shared with structural validation.
The catalog still checks unambiguous container types when `schema.strict_validation` is
disabled, so an undecodable `steps` string is rejected before Activity effect inspection.
Other strict constraints remain governed by that setting. Normalized arguments still
undergo ordinary validation and authorization. Neither normalization system grants new
execution authority or rewrites an external result to make it successful.
