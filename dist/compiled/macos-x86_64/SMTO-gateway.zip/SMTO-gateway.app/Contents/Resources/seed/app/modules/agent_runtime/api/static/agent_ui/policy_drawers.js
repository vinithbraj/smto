/* One horizontal policy accordion; labels retain access to the full editors. */
(() => {
  "use strict";
  const items = [...document.querySelectorAll(".policy-disclosure")].map(trigger => ({
    trigger,
    drawer: trigger.closest(".policy-drawer"),
    panel: document.getElementById(trigger.getAttribute("aria-controls")),
  }));
  const elements = items.flatMap(({drawer, panel}) => [drawer, panel]);
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  let active = null, animations = [], revision = 0;

  function measure(element) {
    const style = getComputedStyle(element);
    return {width: `${element.getBoundingClientRect().width}px`,
      opacity: element.hidden ? "0" : style.opacity,
      marginInlineStart: element.hidden ? "0px" : style.marginInlineStart};
  }
  function show(next, animate = true) {
    const before = elements.map(measure);
    const current = ++revision;
    for (const animation of animations) animation.cancel();
    animations = [];
    active = next;
    let focusTarget = null;
    for (const item of items) {
      const expanded = item === active, hidden = active !== null && !expanded;
      if (item.trigger.getAttribute("aria-expanded") === "true" && !expanded) {
        item.panel.dispatchEvent(new Event("policy-collapse"));
      }
      if ((hidden && item.drawer.contains(document.activeElement))
        || (!expanded && item.panel.contains(document.activeElement))) {
        focusTarget = (active || item).trigger;
      }
      item.trigger.setAttribute("aria-expanded", String(expanded));
      item.trigger.textContent = expanded ? "▾" : "▸";
      item.drawer.hidden = item.drawer.inert = hidden;
      item.panel.hidden = item.panel.inert = !expanded;
      item.drawer.style.marginInlineStart = active || item === items[0] ? "0px" : "4px";
    }
    focusTarget?.focus();
    const after = elements.map(element => ({...measure(element), hidden: element.hidden}));
    if (!animate || reducedMotion.matches) {
      elements.forEach(element => element.classList.remove("policy-sliding"));
      return;
    }
    elements.forEach((element, index) => {
      if (before[index].width === "0px" && after[index].hidden) return;
      element.hidden = false;
      element.classList.add("policy-sliding");
      const {hidden, ...target} = after[index];
      animations.push(element.animate([before[index], target], {
        duration: 280, easing: "cubic-bezier(.2, .8, .2, 1)", fill: "both",
      }));
    });
    Promise.all(animations.map(animation => animation.finished.catch(() => {}))).then(() => {
      if (revision !== current) return;
      elements.forEach((element, index) => {
        element.hidden = after[index].hidden;
        element.classList.remove("policy-sliding");
      });
      for (const animation of animations) animation.cancel();
      animations = [];
    });
  }
  for (const item of items) {
    item.trigger.addEventListener("click", () => show(active === item ? null : item));
  }
  // Widths are measured for each transition; resizing settles into responsive CSS.
  window.addEventListener("resize", () => show(active, false));
  reducedMotion.addEventListener("change", () => show(active, false));
})();
