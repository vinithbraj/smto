---
id: model-configuration
title: Model Configuration
authority: current
kind: manual
tags: [manual, settings, model, inference, provider, compatibility]
order: 26
---
# Model Configuration

Open **Mission Control → Model Configuration** to tune normal agent execution:
choosing tools, interpreting their results and producing final answers. The section
also contains the LLM endpoint URL, request timeout and context ceiling. Select the model through the
existing model selector in Chat.

Generation overrides apply to new agent tasks. Task Contract generation and its
retries, constrained generation recovery, Task Summary and other internal model
operations keep their own configuration. Endpoint and timeout are transport settings
and retain their existing scope.

## Managed and external model connections

On Linux source controllers and `smto-server-inference`, open **Inference → Overview**
to connect a ready managed instance to the agent or helper role with
**Use this connection**. The controller resolves its verified serving endpoint and
launch generation; no URL copying is needed. The Model Configuration editor in
Inference and the existing Settings entry point edit the same configuration.

External endpoints remain supported in both controller variants. The
`smto-server-external` artifact contains no inference management, and runtime
settings cannot enable it. Linux `install.sh` includes management automatically;
the `--inference=both|enabled|disabled` switch belongs to the compiled builder.
See [Inference management](45-inference.md) for installation and first setup.

Generation preferences and launch profiles are separate. Saving an instance
profile does not restart its process; **Validate** and **Apply / Restart** are
explicit actions. A managed restart drains affected requests, verifies the new
launch, and attempts the previous successful snapshot if it fails. Stop and task
cancellation take precedence over automatic resume.

## Startup model check

The **Startup model check** panel shows one advisory check of the model configuration
captured when the controller started. It makes at most one generation HTTP request,
with a 120-second overall deadline and a 2,048-token output ceiling. Invalid local
configuration can fail before any request. The check executes no real tools and has
no automatic retry. Provider usage may be billed. Normal task validation still applies.

Passed, failed, or inconclusive results describe that startup attempt only. Opening
Settings, selecting a model, saving settings, submitting a task, steering, resuming,
and continuing do not run it again. Results do not expire or gate model requests.
There are no Recheck or deep-test buttons. **Copy diagnostic report** exports the
sanitized report. Chat and mobile do not display a recurring model-check indicator.

`aor doctor --server-url https://controller:8011 --json` reads the startup report
without triggering a check. Without `--server-url`, doctor validates bootstrap
configuration only, without contacting the model or opening runtime storage. The
`--deep` option has been removed. To observe a new startup check, restart the controller
through the normal shutdown/startup procedure; normal tasks immediately use applicable
saved settings and report their own provider errors without needing a new check.

The old inference ticket, quarantine, and manual reconciliation system is removed.
Model concurrency is controlled through **Resource locking** as described below.
The controller **Parallel run limit**, tool/resource scheduling, Stop, Pause, and
bounded response recovery remain in force. Steering cancels obsolete model work
and continues automatically; it does not require a ticket or Resume click.

## Concurrent model calls

In **Resource locking**, **Limit concurrent model calls** is enabled by default.
**Maximum concurrent calls per endpoint** defaults to **1** and accepts positive
whole numbers. Increase it when the model server can efficiently serve several
requests at once. Each endpoint has its own capacity; different models or API keys
using the same endpoint share that capacity. The **Parallel run limit** still
limits overall concurrency.

Calls exceeding endpoint capacity show **Waiting for model capacity…**. Calls
waiting for the overall controller limit show **Waiting for controller capacity…**.
Model capacity applies to agent decisions, capability selection, task contracts,
structured drafts, monitor judgements, recovery, and the startup model check. Discovery and tools
do not occupy a model slot. Capacity waiting is separate from generation timing.

Changes apply immediately. Increasing the limit or disabling it wakes waiting
calls. Decreasing it allows active calls to finish before admitting more. Disabling
preserves the saved number, and re-enabling accounts for calls already running.
**Enable tool resource locking** is independent and defaults on. Users can turn it off.
New policies enable every tool family; individual switches can exclude families.
Existing saved family selections keep their meaning.

Stop and steering remain responsive. Capacity is released after the local request
and its cleanup finish; the model server controls whether remote computation has
stopped. Requests from other controllers or external clients are not counted.

## Model timing controls

### Timing values

The three timing controls use the same runtime-control persistence and Settings
autosave as the endpoint. Values are seconds and remain finite:

| Control / runtime key | Default | Range | Meaning |
| --- | ---: | ---: | --- |
| Model request / stream-read timeout / `llm_timeout_seconds` | 120 | 1–1800 | Maximum normal HTTP/stream read wait. Streaming reads bound an idle/blocking read, not the whole response or task. |
| No-actionable-output timeout / `llm_no_actionable_output_timeout_seconds` | 90 | 30–1800 | Generation guard while the model is active but has produced almost no actionable answer or tool-call content (at most 32 meaningful characters). It is independent of the network timeout. |
| Constrained-recovery timeout / `llm_constrained_recovery_timeout_seconds` | 30 | 30–1800 | Whole-generation deadline for the existing bounded recovery inference after certain generation pathologies. It also caps recovery reads and the no-action guard. |

For configured request, no-action and recovery values `T`, `N`, `R`, recovery uses
`min(T, R)` for transport, `min(N, R)` for the no-action guard, and `R` for its
generation deadline. The earliest applicable limit wins. Normal inference gains no
whole-generation deadline. These controls are local runtime limits, never extra
provider request-body fields.

Changes apply to new tasks. Task acceptance captures the controls and `effective_model`
pins the client values; active tasks, resumes and continuations retain that triple.
Historical runs without the generation guard fields use 90 seconds for no-action
and 30 seconds for recovery, preserving their original behavior. Bootstrap config
uses the corresponding `llm` fields without the `llm_` prefix; environment overrides
are `AOR_LLM_NO_ACTIONABLE_OUTPUT_TIMEOUT_SECONDS` and
`AOR_LLM_CONSTRAINED_RECOVERY_TIMEOUT_SECONDS`.

A larger timeout can accommodate a slow model; it cannot prevent a server reset,
crash, remote close, malformed stream, invalid UTF-8 or transport-size violation.
An interrupted model response is discarded and no operation from that incomplete
response executes. There is no automatic regeneration after a stream interruption.
Activity headings identify the recorded cause, such as **Model request timed out**
or **Model server connection was reset**. **Action Rejected** remains for actual
action/schema/policy rejections. Timing details show the configured/effective limits,
event counts, first-event latency, largest event gap, idle time and failure stage
without copying model payloads or hidden reasoning.

## Choose a profile

Open **Mission Control → Model Configuration** to choose how the AI responds to
new tasks. A model is the AI software; a provider is the program or online service
running it. A profile is a group of settings you can choose together.

| Profile | What it does |
| --- | --- |
| Provider Defaults | Lets your AI provider choose the optional settings. |
| smTO Recommended | Uses SMTO's suggested starting settings where your model supports them. |
| Custom | Keeps the individual settings you choose. Editing a setting selects Custom automatically. |

New installations start with Provider Defaults. Choosing that profile again clears
your individual overrides, meaning settings you chose instead of the provider's
values. Recommended replaces them with SMTO's current suggestions. Custom keeps
the current choices. Changes save automatically. Older saved custom settings are
kept under Custom.

Open **Configured preferences and endpoint support** to see which saved settings
your AI connection can use. An endpoint is the connection address of the AI service.
A setting that is not supported stays saved but is shown as omitted, meaning it
is not sent to that service. Some settings can be translated to a supported form.
Recommended is worked out for the model selected for each new task. Changing the
model does not erase your Custom choices.

## Set an individual parameter

A parameter is one setting, such as answer length or how much extra reasoning
the AI can use. Each setting has a toggle:

- **Off — Provider Default:** let the provider decide. The value editor is hidden.
- **On — User Configured:** save your chosen value. The editor opens with a suggested
  starting value, which you can change. The value is used where supported; unsupported
  options may be translated or left out of the request.

Turning a toggle off is different from entering `0` or `false`. Those are explicit
values. An empty list or object, where valid, is also a value rather than a request
to use the default. The Recommended profile uses the same two toggle states.

Open **Help** beside a setting to learn what it changes and which providers support
it. **About profiles** explains the three profiles. Search can find settings by
their displayed name, technical request name, provider, or help text. If a value
is invalid, SMTO leaves it visible for correction and keeps the last saved value.

You can leave advanced settings at their defaults. These are the groups shown:

| Group | What it affects | Examples shown in settings |
| --- | --- | --- |
| Generation | How varied and long the answer can be | Temperature, Top P, Maximum completion tokens, Seed, Stop sequences |
| Reasoning and output style | Extra reasoning and answer detail | Thinking, Preserve thinking, Reasoning effort, Thinking token budget, Verbosity |
| Penalties | How the model treats repeated words | Presence, Frequency, Repetition penalties |
| Log probabilities and diagnostics | Detailed numbers used to study model output | Log probabilities, Top log probabilities, Prompt log probabilities, Requested logprob token IDs, Logit bias |
| Extended sampling | Advanced ways of choosing the next piece of text | Top K, Min P, Beam search, Length penalty |
| Stopping and token controls | When the answer ends and which text pieces are allowed | Stop token IDs, Include stop string, Ignore EOS, Minimum tokens, Allowed token IDs, Bad words, Skip special tokens, Spaces between special tokens |
| Provider scheduling | How a supporting provider handles the request | Service tier, Request priority, Watermarking |
| Advanced endpoint extensions | Extra options offered by some AI services | Repetition detection |

A **token** is a small piece of text used to measure how much the AI reads or
produces. Token counts are not the same as word counts. You do not need to adjust
each of these controls to try a first task.

## Automatic budget increases

The **Automatic budget increases** section in Model Configuration enables both
thinking and output growth by default. When a known local thinking allowance is
reached, smTO first reserves an increase and keeps the same response streaming.
Reasoning and partial tool arguments already received remain part of that response.
Incomplete answers and tool calls authorize no operations.

| Control | Runtime key | Default |
|---|---|---:|
| Automatically increase thinking budget | `llm_budget_growth_thinking_enabled` | On |
| Automatically increase output budget | `llm_budget_growth_output_enabled` | On |
| Maximum consecutive increases | `llm_budget_growth_max_increases` | 3 |
| Thinking increase per step (percentage points) | `llm_budget_growth_thinking_increment_percent` | 5 |
| Output increase per step (tokens) | `llm_budget_growth_output_increment_tokens` | 1000 |

The nonnegative increase limit is shared by both budgets and applies to consecutive
increases without an accepted model response; zero disables increases. Thinking
increments accept 1–100 percentage points and output increments accept positive
whole token counts. For a 32,768-token limit and 5% thinking, thinking exhaustion
raises the share to 10% while retaining
32,768 output tokens. Output truncation raises the limit to 33,768 tokens while
retaining the thinking percentage. Thinking tokens are recalculated from these two
values. Each reserved increase consumes one attempt. Accepting a complete model
response resets the count to zero, restoring the allowance (three by default) while
keeping the increased budgets. Failed or discarded responses do not reset the count.

After a confirmed provider token-limit stop, identified vLLM and llama.cpp chat
endpoints can be asked to continue a nonempty assistant text prefix. llama.cpp's
explicit reasoning-content prefill is also supported; reasoning-only vLLM prefixes
and unfinished native tool calls are not reconstructed by guessing template syntax.
The continuation uses the original request and retained prefix, with only the unused
part of the enlarged output allowance available for new tokens. It is a new HTTP
request and counts as another model call. This is message continuation, not a promise
of an engine checkpoint, identical sampler state, or a KV-cache hit.

Unsupported backends, rejected prefill parameters, changed request authority, and
prefixes that cannot fit fall back explicitly to a fresh pending decision. Incomplete
or corrupted streams do not establish a resumable checkpoint. Private prefixes are
bounded and kept only in memory for the pending decision; a service restart retains
numeric budgets but cannot resume that private generation. Activity distinguishes
continuation from a fresh retry. Completed operations are never replayed for either.

Thinking growth never turns on disabled thinking or overrides a separate provider
thinking-token ceiling. Reported reasoning counts are preferred; visible reasoning
can otherwise be estimated. Hidden reasoning that the provider neither streams nor
counts cannot be measured. Output growth requires a configured or explicitly reported
numeric provider limit. **Provider Defaults** with an unknown limit skips output growth;
the internal context reservation is not treated as a provider limit.

Growth stops at the configured count, 100% thinking, or context capacity. The full
output increment must fit after ordinary context measurement and eligible history
compaction. Existing recovery, including Prevent brain freeze when enabled, then
runs. If the provider rejects a higher output limit, the last usable limit is restored
and further output growth is disabled until the baseline is reset. The attempted
increase still counts. Timeouts, repetition, invalid JSON and transport failures use their existing
recovery directly. Stop and overall run limits always apply. Task Contract and other
internal inference budgets are independent.

Effective budgets and any unfinished increase streak survive prompts, pause/resume,
task restart and service restart in that conversation. Composer readouts show the
effective values; their help text identifies configured values and remaining
increases. Manual budget edits, Default resets and model changes reset the allowance for future work.
Already accepted work retains its captured baseline and cannot spend the new
allowance. New chats and forks start without inherited increases. Main configuration
values are never rewritten by automatic growth.

Growth-policy changes apply at the next decision and subsequent live growth checks
without resetting the used count. They do not rewrite dispatched provider options.
Bootstrap YAML uses the same names without `llm_` under `llm`; environment names
are the uppercase runtime keys prefixed by `AOR_`, for example
`AOR_LLM_BUDGET_GROWTH_MAX_INCREASES=5`.

## Thinking, effort and budget

Some AI models can spend extra work on reasoning before answering. These controls
ask a supporting model how to handle that work. A **token budget** is an allowance
measured in small pieces of text, not money or a promise of a better answer.

**Thinking** is under **Reasoning and output style**. Leave its override toggle off
to use the provider's default. To choose yourself, turn the toggle on and select
On or Off. Choosing Off explicitly asks the provider to disable thinking; turning
the override off leaves the choice to the provider.

**Reasoning effort** asks for a supported level such as low, medium, or high.
**Thinking token budget** sets an allowance for reasoning output. These controls
need support from the model and its service. Recommended leaves Thinking at
Provider Default. Normal thinking settings apply to new tasks. The separate
**Task Contracts** settings control the optional step that records what a task
is meant to achieve.

**Preserve thinking** asks a supported model to retain earlier reasoning already
included in the request. It does not turn thinking on or change what SMTO stores.
Off asks for the provider's usual filtering, which may still keep reasoning from
the current exchange. Unsupported providers may ignore this setting.

### Settings for a stuck or incomplete response

**Recovery thinking** controls ordinary retries after an AI response fails. Choose
Provider default, On, Off, or a limited 256-token allowance. Existing `unchanged`
settings remain supported. It is separate from normal Thinking and Task Contract
thinking. Changes apply at the next AI decision, including in a paused task that
continues later. A response already being generated keeps its current setting.

**Prevent brain freeze** is optional and starts off. It can try a stuck or incomplete
AI decision once more with thinking turned off. It is used after automatic allowance
increases are used up or cannot be used. This can apply when the thinking allowance
is exceeded, the response stalls or repeats, or the answer is cut short. An incomplete
or rejected tool request does not run an action.

That retry uses the normal output allowance instead of the ordinary 1,024-token
recovery limit. It temporarily takes priority over Recovery thinking. Normal thinking
settings return for the next regular decision. It never turns on thinking when
normal Thinking was off, and a new user instruction does not inherit this temporary
setting. Permissions, Stop, and the task's limits still apply.

If the retry fails, or the AI service cannot turn thinking off as required, the task
stops instead of repeatedly retrying. The activity history shows the retry and the
return to normal settings. These live controls do not rewrite your saved normal
settings; the thinking percentage stays tied to the task.

### How the allowance is measured

SMTO uses reasoning counts from the provider when available. Otherwise, it estimates
text arriving from the model. The **Thinking budget (%)** is measured against the
task's maximum output allowance, or SMTO's reserved allowance if the provider chooses
the maximum. If the provider only sends a complete response, SMTO can check the
allowance only after that response arrives. It cannot measure private reasoning
that the provider neither sends nor counts.

For developers, the estimate uses one token per three UTF-16 code units, a measure
of text length. It is marked as an estimate in diagnostic records. Network chunks
are not counted as tokens.

### Technical names for these settings

These names are useful when checking requests sent to a model service. You can
use the settings screen without editing them directly.

| Setting | Request field |
| --- | --- |
| Thinking | `chat_template_kwargs.enable_thinking`: `true` or `false` |
| Preserve thinking | `chat_template_kwargs.preserve_thinking`: `true` or `false` |
| Reasoning effort | `reasoning_effort`, such as `low`, `medium` or `high` |
| Thinking token budget | `thinking_token_budget`, a token allowance |

SMTO sends these choices independently. Some services handle them differently.
For example, vLLM can use reasoning effort to choose thinking behavior when no
explicit Thinking value is given; an explicit Thinking value takes priority there.
Provider details are in [vLLM's thinking guide](https://docs.vllm.ai/en/latest/features/reasoning_outputs/#automatic-enable_thinking-activation)
and this [Qwen3.6 model template](https://huggingface.co/palmfuture/Qwen3.6-35B-A3B-GPTQ-Int4/blob/main/chat_template.jinja).
Thinking and Preserve thinking stay separate from Task Contract generation and retries.

## vLLM launch defaults and request controls

vLLM launch options configure the server. Model Configuration exposes supported
per-request overrides: the sampling values supplied through
`--override-generation-config` and the two thinking booleans supplied through
`--default-chat-template-kwargs` can also be set for individual execution requests.
Provider Default leaves these choices to the server/model configuration.

`--enable-auto-tool-choice`, `--tool-call-parser` and `--reasoning-parser` are server
launch settings. smTO already supplies the request's tool definitions and
tool choice through its native execution protocol. GPU layout, memory, batching,
context capacity and CUDA compilation settings also stay on the server. Select an
already served model through Chat's existing model selector. See the
[reference script review](../../../docs/model-configuration-v246-report.md#reference-script-review)
for every option from the supplied vLLM launch script.

## Recommended starting values

The shared starting profile for compatible endpoints, including vLLM and llama.cpp:

| Parameter | Value |
| --- | ---: |
| Temperature | 0.6 |
| Top P | 0.95 |
| Top K | 20 |
| Min P | 0.0 |
| Maximum completion tokens | 8192 |
| Presence penalty | 0.0 |
| Frequency penalty | 0.0 |
| Repetition penalty | 1.0 |

These values aim to retain useful sampling diversity and enough output capacity while
avoiding penalties that can damage JSON, code, paths and identifiers. They are a
starting point, not a universal optimum. Model family, reasoning mode, quantization,
chat template, server generation configuration, task and latency goals all matter.

Known first-party OpenAI reasoning models receive Maximum completion tokens 8192 and
Reasoning effort medium, with sampling fields omitted. Known first-party sampling
models retain their existing compatible subset. Other endpoints receive the shared
starting profile, adapted from observed request acceptance/rejection. Settings does
not generate probe completions or infer support from a model-name substring.

Other parameters stay at Provider Default. Seed can help controlled comparisons but
cannot guarantee identical output. Stops, token restrictions and strong penalties can
break tool arguments; diagnostics add overhead rather than improve reasoning. Review
the relevant help and the model's own guidance before changing them.

## Output limit and context space

**Maximum completion tokens** (`max_completion_tokens`) is the optional provider limit
for one normal execution call, including reasoning where the provider counts it. It
is not a task-wide token
budget. An explicit limit also reserves that amount of space in smTO's execution
context budget, leaving less room for input and history.

Under **Thinking and recovery**, **Thinking budget (%)** (`llm_reasoning_budget_percent`)
sets the share of Maximum completion tokens that the execution prompt asks the model
to use at most for reasoning. It accepts whole percentages from 0 to 100, defaults to
50%, and autosaves. The displayed allowance is rounded down: 25% of 8192 permits
2048 reasoning tokens; 50% of 100000 permits 50000. The remainder is intended for the
answer or complete tool calls. 0% asks for no reasoning; 100% leaves no reserved
answer share. The prompt encourages earlier decisions whenever possible.

With automatic thinking increases and Prevent brain freeze both off, this is a soft instruction, not an enforced provider thinking limit, a provider
request parameter, or a reason to abort generation. Explicitly disabled thinking
is respected. With Maximum completion tokens at Provider Default, the prompt gives
brief-reasoning guidance without a numeric allowance; internal output reservations
are not treated as configured provider limits. Task Contract compilation and recovery
retain their separate policies. Changes apply to new tasks; queued, resumed and
continued tasks retain their saved percentage. Historical tasks without this setting
use 50%. Bootstrap configuration is `llm.reasoning_budget_percent`; its environment
override is `AOR_LLM_REASONING_BUDGET_PERCENT`.

For a conversation, turn **Thinking: On** in the prompt and adjust the adjacent
**Budget** slider. Its live percentage readout ranges from 0% to 100%. The selection
is saved for new prompts in that conversation on desktop and mobile. Turning thinking
off disables the slider and keeps its value. **Default** restores both thinking and
budget to Model Configuration settings. Running and queued tasks retain their captured
budget. This slider uses the same allowance described above; it does not increase the
model's total response limit.

The **Output limit** slider beneath Thinking sets that total response-token limit,
including thinking, for new prompts in the conversation. It remains available when
Thinking is off and has its own **Default** reset. Both sliders show token counts:
50% thinking with an 8,192-token output limit allows up to 4,096 thinking tokens.
The thinking count updates as either slider moves and shows zero when Thinking is
off. If Model Configuration leaves the limit to the provider, the readouts show
**Auto** until you choose a numeric output limit. Provider and context capacity still
apply to that limit.

Both slider defaults follow the current values in Model Configuration. Moving a
slider overrides its value for the conversation; changing main settings leaves that
override intact. **Default** clears the override and resumes following main settings,
including subsequent changes while the prompt is open.

Provider Default omits the wire limit, but smTO still reserves output space
internally. That reservation is capacity planning; it does not force the provider to
use the same output limit. If protected input plus reservation cannot fit, the runtime
reports the context problem. Lower the configured execution limit, reduce input, or
select a model with enough context for the task.

[Task Contract output/thinking settings](architecture/20-task-contract.md) and
constrained recovery use their own internal limits. Raising an execution override does
not raise the compiler allowance; changing compiler policy does not configure the
execution provider limit. See [context budgeting](architecture/22-context-memory.md).

## Saved tasks, schedules and migration

Accepted Custom choices are captured for queued tasks. Recommended resolves after the
selected model is known. Once the run starts, the resolved map, profile, version and
output reservation are saved as part of its inference identity. Global changes do not
retune active runs, resumed runs or continuation attempts of the same task. Submit a
new task to use new settings.

Schedules created in Scheduler Manager capture their execution configuration when
created. Agent-created schedules retain the creating run's captured configuration.
Older events without captured settings resolve configuration when they fire. Editing
global settings does not retune a schedule that already has a saved configuration.
See [Scheduler Manager](22-schedules.md).

Explicit saved `llm_request_temperature` and positive `llm_max_tokens`, and explicit
startup/environment values, migrate once to the execution map. Code defaults do not
become overrides. An existing canonical map, including `{}`, takes precedence over
legacy migration on restart. Historical runs preserve their old emitted values and
output wire alias when resumed.

## Provider rejection and troubleshooting

A support description indicates portability, not guaranteed endpoint support. An
explicit pre-inference rejection of optional fields may trigger bounded negotiation:
stream usage is dropped before streaming itself; output limits can use either
`max_completion_tokens` or `max_tokens`; unsupported sampling extensions are omitted.
Saved preferences stay unchanged. Diagnostics and the resolved Settings panel distinguish
configured values from effective fields. Support observations expire for new tasks;
active and resumed tasks retain their learned wire adaptations.

Authentication, context errors and invalid schemas are not optional-feature evidence.
An interrupted response is never transparently replaced by another inference.

An explicit model name or alias works even when `/models` is unavailable. Auto needs
model discovery. The backend must expose modern structured tools and tool results for
Agent mode; ordinary assistant text is never parsed into executable actions. Configure
the serving model's tool template/parser on the backend. A text-only endpoint may be
used where the Conversation path does not need tools.

Context window **0 = Auto** uses known active serving capacity or the existing 60,768
token fallback. A positive value sets an operator ceiling. Training/config metadata is
advisory. Output reservations remain in force even if the provider's output field is
omitted. Token-count endpoints are optional: vLLM's chat tokenizer is retained; known
llama.cpp servers can supply active `/props` capacity and count complete chat inputs
through `/v1/chat/completions/input_tokens`, including tools and negotiated template
options. Older servers can use `/apply-template` plus `/tokenize` for plain text;
tool-bearing requests retain an estimate if the complete chat counter is unavailable.
vLLM receives documented `/tokenize` fields, including `chat_template_kwargs`; requests
with completion-only options whose tokenization parity is unknown retain estimates.
OpenAI Chat Completions does not use llama.cpp/vLLM utility routes or convert requests
to the Responses token-count endpoint. Successful prompt usage calibrates local
estimates with a safety margin. Missing, malformed or timed-out counters do not make
the engine unusable; a transient counter outage gets one retry at the overflow boundary.
Estimate-based capacity failures are labeled separately from provider rejections.

See the [backend contract and smoke harness](../../../docs/openai-compatible-backends.md).

## API and source ownership

`GET /api/agent/settings/registry` returns registry version 2 and the server-owned
parameter metadata. Runtime controls are read with `GET /api/agent/runtime-controls`
and updated with `POST /api/agent/runtime-controls`. For example:

```json
{
  "llm_execution_configuration_profile": "custom",
  "llm_execution_request_overrides": {
    "temperature": 0,
    "enable_thinking": false,
    "preserve_thinking": false,
    "ignore_eos": false,
    "stop": []
  }
}
```

The map replaces the saved execution map; omission of a key means Provider Default.
A map-only update selects Custom. To clear all overrides, post
`{"llm_execution_configuration_profile":"provider_default"}`. No per-parameter mode
flags are stored. Unknown/protocol-owned keys, nulls, nonfinite values, invalid types
and out-of-range values are rejected. The backend retains the existing runtime-control
namespace and persistence API.

The saved `enable_thinking` and `preserve_thinking` booleans map only to the matching
keys in `chat_template_kwargs` in the provider request. Both are merged when set;
explicit false values survive. Generic
`chat_template_kwargs` objects remain excluded from the settings API. The registry's
`wire_key` identifies the nested provider field, and Settings search matches it.

The catalog, schemas, migration and recommendation rules live in
`src/agent_runtime/llm/model_configuration.py`. The normal decision scope enters in
`native/model_decision.py`; the only wire merge is in `llm/native_tool_client.py`.
Internal generation policy remains in `llm/generation.py`. The
[engineering report](../../../docs/model-configuration-v246-report.md) records the
provider schema review, exclusions and targeted validation.

## Local AI Runtimes

Enable the optional **Local AI Runtimes** (`local_ai`) skill to inspect or manage a
model server through the selected Gateway. Runtime management uses deterministic
process and HTTP operations and makes **zero helper model calls**. Starting a
server does not change SMTO's inference endpoint.

Create a **Local AI Runtime** Parameter from the Parameter Store template, save it,
and accept its reference in the task. The profile's `gateway_id` is the Gateway's
configured logical node name; the signed Gateway transport additionally pins the
selected registered Gateway identity. All paths belong to that Gateway. For example:

```json
{
  "profile_type": "local_ai_runtime",
  "profile_version": 1,
  "label": "Local GGUF",
  "gateway_id": "localhost",
  "provider": "llamacpp",
  "executable": "/opt/llama.cpp/build/bin/llama-server",
  "model_path": "/srv/models/model.gguf",
  "model_alias": "local-model",
  "host": "127.0.0.1",
  "port": 8000,
  "gpu_devices": [0, 1, 2],
  "extra_options": {"ctx_size": 32768, "n_gpu_layers": 99},
  "startup_timeout": 120
}
```

Use an absolute executable path for a provider installed in a virtual or Conda
environment. There is no shell command, arbitrary environment map, or unrestricted
flag list. Unsupported fields and installed-provider flags are rejected. Managed
vLLM and llama.cpp require existing local model artifacts and run in offline mode;
starting does not authorize downloading weights or executing remote model code.

1. `local_ai.status` reports detected provider features on the selected Gateway.
2. `local_ai.profiles` lists accepted references and their exact profile revisions.
3. `local_ai.start` takes `profile_ref` and `profile_revision`.
4. Inspect `runtime_id`, ownership and readiness. A timeout can leave a process
   **starting**; inspect that exact runtime before another operation.
5. `local_ai.logs` accepts the runtime ID, an absolute byte offset, `max_bytes`
   (up to 65,536), and optional `tail_lines` (for example 200). Logs are redacted
   before entering a bounded memory ring; offsets refer to the redacted stream.
6. Stop or restart only exact SMTO-owned runtime IDs. Restart retains the
   original profile, model, port and credentials.

The shared Gateway runtime switch, `GATEWAY_ENABLE_LLM_RUNTIME`, controls both the
existing operator `/llm` API and the typed `local_ai_runtime` capability. The legacy
command API remains operator plumbing; it is not exposed as an Agent skill tool.

### Providers and models

| Provider | Supported management |
| --- | --- |
| vLLM | Detected POSIX executable: start, stop, restart, readiness, logs, models, bounded metrics |
| llama.cpp | Detected POSIX `llama-server`: the same lifecycle; metrics require the server option |
| Ollama | Owned POSIX `ollama serve` lifecycle; installed/loaded/served inventory, explicit pull and removal, optional model details |
| LM Studio | Endpoint health and OpenAI-compatible model inventory; detection of `lms` does not grant lifecycle ownership |
| Generic compatible | Endpoint health and model inventory; no invented launcher or stop API |

`local_ai.models` distinguishes the profile's model identifier and artifact path
from served aliases. Ollama adds installed and loaded inventory; pass `model` for
bounded format/family/quantization metadata. SMTO's configured model is shown
separately in activation previews. `model_id` does not load an Ollama model.

Ollama downloads and deletion require explicit operations and user authorization.
Pull uses the provider's configured registry, holds network/disk admission during
the request, and returns bounded progress. Cancellation closes the pull stream;
partial artifacts or provider-side continuation can remain. Inspect inventory and
digests before retrying an uncertain download. Never automatically delete weights.

### Bind addresses and private keys

Managed servers default to `127.0.0.1`. IPv4 and IPv6 wildcard addresses count as
external exposure. Non-loopback startup requires all of: an accepted profile with
`external_bind_confirmed: true`, the Gateway operator setting
`GATEWAY_LOCAL_AI_ALLOW_EXTERNAL_BIND=true`, a private API key, and the existing
unsafe-action authorization. Native Ollama has no equivalent local server API-key
control, so managed external Ollama binding is unavailable here. No firewall or
reverse-proxy configuration is changed.

vLLM's native API key does not protect every endpoint. Use an operator-managed
trusted network boundary or reverse proxy for external deployments; see
[vLLM security guidance](https://docs.vllm.ai/en/latest/usage/security/).

Store authentication in a **Local AI API key** Parameter (`local_ai_secret`) and
set `api_key_ref` to its accepted reference. Accept both references in the task.
Values travel only in the private authenticated Gateway envelope and in provider
environment/header fields. They do not appear in argv, profile inventory, runtime
manifests or tool results. Profile and log validation does not echo private values.

### Explicit endpoint activation and restore

After startup, request `local_ai.activation_preview` with the exact accepted profile
revision and served model alias. The preview includes the current configuration,
candidate URL/model, observed inventory, configuration revision and restore data.
It expires after ten minutes. `local_ai.activate_for_smto` takes that exact
`preview_id`, checks the profile, inventories and canonical configuration again,
and applies through Model Configuration. `local_ai.restore_smto_endpoint`
takes the resulting `activation_id` and restores the previous endpoint only if
nothing has changed since activation. An intervening configuration change makes
an older preview or restore stale, even if the URL was changed back.

A remote Gateway's loopback is not the controller's loopback. Set an explicit
`controller_base_url` reachable from SMTO, such as an operator-managed tunnel,
for remote activation. This feature does not create tunnels or expose ports.
Activation retains the existing global inference credential: an authenticated
candidate must use the matching accepted private key. Configure other credentials
through the existing model configuration owner before making a new preview.
The conventional `EMPTY` inference-key placeholder is treated as unauthenticated.

Validation checks bounded model inventory from both the selected Gateway and the
controller. It does not generate a completion or certify a model's tool template.
The existing provider-neutral inference backend still owns chat/tool compatibility.
New tasks use the changed configuration; active, resumed and queued tasks retain
their existing captured inference configuration. No external server is terminated.

### Recovery and resource ownership

Startup holds GPU, CPU and disk-read scheduler claims through the bounded readiness
window. Pull holds network and disk claims. Long-lived server identity and selected
GPU devices remain runtime observations after those task claims are released, so a
server does not deadlock the Activity scheduler. These are admission tokens, not GPU
memory reservations. The Gateway additionally serializes heavy local AI operations.

Mutation IDs and launch intents are persisted before effects. A repeated exact
operation ID returns its saved receipt; a changed request cannot reuse the ID.
After a lost response, inspect runtime/profile/port identity, model inventory, or
canonical endpoint configuration as appropriate. Do not blindly replay mutations.

Graceful Gateway restart is refused while managed servers or uncertain owners
remain. After abrupt Gateway replacement, surviving identities are inspectable as
`unknown`; this version does not adopt PIDs or signal them automatically. Proven
inactive identities become `exited`. Logs are memory-bounded and do not survive
Gateway replacement. History is bounded to 256 runtime records and 1,024 mutation
receipts; reaching the bounds fails closed and needs operator maintenance.
