---
id: redaction
title: Optional redaction and literal execution
kind: architecture
tags: [architecture, current, redaction, authentication]
order: 31
---
# Optional redaction and literal execution

`agent_runtime/redaction.py` owns optional credential classification and masking
for runtime consumer projections. Optional redaction cannot authorize, reject, retry, repair, or
change an operation. Canonical messages, arguments, HTTP profiles, files, receipts,
working context, cache evidence and resume data retain literal values.

Settings → Redaction exposes 20 independent switches. New installations start with
every switch on. Existing saved choices and accepted run snapshots are preserved;
missing preferences in older stores retain their historical off fallback.
The persisted key is `redaction_<source>_enabled`. Enable all and Disable all use
the existing settings autosave without confirmation.

| Source | Consumer | Policy lifetime |
| --- | --- | --- |
| logs | Runtime/Gateway log output | Live |
| urls | Display URL helpers | Live |
| model_input | Ordinary model input | Run snapshot |
| model_output | Final answers and answer streaming | Run snapshot |
| tool_input | Model-facing invocation previews | Run snapshot |
| tool_output | Generic result previews | Run snapshot |
| http | HTTP/Proxmox receipt previews | Run snapshot |
| files | File result previews | Run snapshot |
| activity | Activity/inspector snapshots | Live |
| events | Event callbacks | Live |
| traces | Debug and model traces | Live |
| parameters | Parameter inspection and accepted-reference model context | Live |
| audit | Audit details | Live |
| schedules | Schedule inspection | Live |
| notifications | Notification projection | Live |
| handoffs | Handoff context/history projection | Run snapshot |
| working_context | Working-context model projection | Run snapshot |
| errors | Display error diagnostics | Live |
| privilege | Privileged result previews | Run snapshot |
| database | Database result previews | Run snapshot |

New runs freeze the ten run sources in `redaction_policy`. Queue, continuation and
restart carry that snapshot. Diagnostic sources read the existing UI settings store.
Gateway calls carry a validated, stripped policy envelope; it is never a domain tool
argument. A missing policy means all off. Values must be actual booleans.

Off returns the original object or stream fragment immediately. It does not discover
secrets, traverse/copy data, compile patterns, parse URLs, buffer or reserialize text.
Size limits, structural reasoning exclusions and transport framing remain separate.

Public error diagnostics have a separate mandatory boundary in
`error_catalog/redaction.py`: bounded, cycle-safe sanitization applies even when
optional error projection is off. `error_catalog/compatibility.py` also marks catalog
variables declared nonpublic. OAuth callback logging in `native/http_oauth.py`
always strips callback query strings before applying optional log projection.
These boundaries protect diagnostic and protocol output; they do not replace
authoritative operation arguments or receipts. Recipe capture uses the central
processor to detect values that cannot be retained in reusable workflow definitions.

On produces detached projections. Sensitive fields are exact names, not substrings
such as `key` inside `monkey`. Known materials carry provenance and one of field-only,
exact-scalar, substring or encoded-substring matching. Sensitive-record metadata
masks that record's projection without promoting every scalar into global secrets.
Matching is longest-first with an opaque `[redacted]` marker; projection is idempotent.
The processor recognizes credential assignments, authentication headers, private keys,
URL userinfo and sensitive query fields. Streaming uses bounded holdback and consumes
long credential tokens without retaining their body. An oversized uninterrupted URL
may be represented by one marker. No redaction path calls an LLM.

## Authentication

Literal credentials are accepted in ordinary chat and tool arguments. Missing values
use ordinary `ask_user` interaction. HTTP v3 profiles store values inside `auth`:
`username`/`password`, `token`, API-key `value`, literal session login fields and
header-rule `value`. OAuth accepts literal client/access/refresh tokens. TLS accepts
PEM values or Gateway paths; proxy authentication uses literal username/password.
Sudo uses `sudo_password` and optional `sudo_username`. Values can appear in logs,
model content and UI when their owning switch is off.

Secure Prompts, its Agent Check, ingress/egress blockers and volatile password vault
are retired. Current guard/configuration boundaries reject unsupported fields. HTTP profiles require v3 literal values; private credential maps and slot references are unsupported. Pre-baseline credential waits are not converted. Already-redacted values cannot be reconstructed.

OAuth browser/device interaction remains a protocol feature using `waiting_user`.
State, PKCE, callback identity, expiry and single-use code handling remain enforced.
TLS verification, Gateway identity, capability/permission policy, resource limits,
origin rules and execution truth remain owned by their existing subsystems.

## Source map and contributor rule

- `redaction.py`: policy, provenance, matching, streams and logging adapters.
- `native/redaction_policy.py`: admission and resume snapshots.
- `native/consumer_projection.py`: model/UI source selection.
- `observability/projection.py`: independent size bounds and sink projection.
- `gateway_core/runtime_policy.py`: transport policy envelope.
- `gateway_core/http_profiles.py`: strict current literal-profile validation.
- `native/http_session_state.py`: OAuth interaction and HTTP session lifecycle.
- `api/agent_ui_support/route_groups/settings.py`: settings registry.
- `api/static/agent_ui/settings.js`: switches and bulk controls.

New code must not implement credential masking locally. Add a new `RedactionSource`
only when a genuinely new first-class projection sink cannot map to an existing
source, and use the canonical processor. Never persist a projected value as canonical
execution, recovery or completion evidence.

Credential-interaction cleanup does not change the twenty independent Redaction
sources or the user's choices. Literal authentication input is ordinary text.
Configured consumers may project it through the existing central processor, while
canonical arguments, execution values and raw receipts remain authoritative.
`http.connect.auth_values` overrides only advertised authentication leaves on a copy
of a saved profile; it does not save the reply to Parameter Store.

When **Model input** redaction is enabled, matched values supplied in chat—including
credentials—may be hidden from the Agent model on new runs. Authentication tasks
that require the Agent to reuse a value from the conversation may therefore require
Model input redaction to remain **off**. The choice remains yours; no special input
form or automatic bypass is introduced.

Proxmox accepts invocation-local `auth_values` for `username`/`password`. Database
accepts `user`/`password`; host/port/dbname remain configured profile identity. Both
use ordinary `ask_user` and never automatically save transient authentication.

Clipboard, Screen, Browser and UI tools omit transient device payloads from diagnostics and portable
history independently of credential redaction switches. Diagnostics identify these tools from
structured invocation metadata, not filenames, command text, documentation or tool catalogs.
For example, reading `auth/browser.py` does not activate device-content filtering. Actual device
tool use still filters subsequent diagnostics that could repeat the observed content, while exact
source receipts remain unchanged; see [Current clipboard](37-clipboard.md).
This does not add a redaction setting or secret classifier.

Google Workspace and legacy Gmail OAuth authority have an unconditional structural
privacy boundary in `auth/privacy.py`, independent of these optional redaction switches.
The `google_oauth_app` / `google_account` families join the existing protected OAuth
families: accepted references and public Parameter projections contain only safe identity
and scope metadata. Shared browser callbacks suppress access-log query strings, and
provider errors expose catalog codes rather than token response bodies. Handshake state,
ID tokens and PKCE verifiers remain private ephemeral runtime data. No new redaction
switch, vault or masking engine is introduced.
