/** Conversation thinking shortcut; accepted tasks keep their captured choice. */
(() => {
  "use strict";
  function create({button, quickButton, reset, budget, budgetValue, budgetHelp, thinkingTokens,
    outputBudget, outputTokens, outputReset, outputHelp,
    profile, ready, patch, disabled = () => false}) {
    const tokens = value => `${value.toLocaleString()} tokens`;
    let adjusting = false, adjustingOutput = false, outputLimit = null;
    let rangeOwner, rangeMax = 32768;
    const showCounts = () => {
      const count = profile().thinking_enabled === false ? 0
        : outputLimit == null ? null : Math.floor(outputLimit * Number(budget.value) / 100);
      window.SMTONumberOdometer.render(thinkingTokens, count == null ? "Auto" : tokens(count));
      thinkingTokens.title = count == null ? "Set an output limit to calculate thinking tokens."
        : "Thinking allowance within the total output limit.";
      window.SMTONumberOdometer.render(outputTokens, outputLimit == null ? "Auto" : tokens(outputLimit));
      budget.setAttribute("aria-valuetext", `${budget.value}% of the response token limit${count == null ? "" : `, ${tokens(count)}`}`);
    };
    const showBudget = value => {
      budget.value = String(value);
      window.SMTONumberOdometer.render(budgetValue, `${value}%`);
      budget.setAttribute("aria-valuetext", `${value}% of the response token limit`);
      budget.style.setProperty("--thinking-budget-fill", `${value}%`);
      showCounts();
    };
    const showOutput = value => {
      outputLimit = value;
      // Provider Default has no numeric value; do not imply an 8,192-token default.
      const position = value ?? Number(outputBudget.min);
      outputBudget.value = String(position);
      outputBudget.style.setProperty("--thinking-budget-fill", `${100 * (position - Number(outputBudget.min)) / (Number(outputBudget.max) - Number(outputBudget.min) || 1)}%`);
      outputBudget.setAttribute("aria-valuetext", value == null ? "Provider default; move to set a token limit" : `${tokens(value)} total, including thinking`);
      outputBudget.closest(".output-budget").dataset.inherited = String(value == null);
      showCounts();
    };
    // Preview while dragging; persist once on release or a keyboard step.
    budget.addEventListener("input", () => {
      if (budget.disabled) return;
      adjusting = true;
      showBudget(Number(budget.value));
    });
    budget.addEventListener("change", () => {
      adjusting = false;
      if (!budget.disabled) void patch({llm_reasoning_budget_percent: Number(budget.value)});
    });
    outputBudget.addEventListener("input", () => {
      if (outputBudget.disabled) return;
      adjustingOutput = true;
      showOutput(Number(outputBudget.value));
    });
    outputBudget.addEventListener("change", () => {
      adjustingOutput = false;
      if (!outputBudget.disabled) void patch({max_completion_tokens: Number(outputBudget.value)});
    });
    outputReset.addEventListener("click", () => {
      void patch({max_completion_tokens: null});
      outputBudget.focus();
    });
    quickButton.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 18V5m3 8a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4M17.6 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.6 1.5M18 5.1a4 4 0 0 1 2.5 5.8M18 18a4 4 0 0 0 2-7.5m0 7A4 4 0 1 1 12 18a4 4 0 1 1-8-.5M6 18a4 4 0 0 1-2-7.5m2-5.4a4 4 0 0 0-2.5 5.8"/></svg>';
    for (const toggle of [button, quickButton]) {
      toggle.addEventListener("click", () => {
        // Default has no explicit choice; the first click opts in to thinking.
        void patch({thinking_enabled: profile().thinking_enabled !== true});
      });
    }
    reset.addEventListener("click", () => {
      void patch({thinking_enabled: null, llm_reasoning_budget_percent: null});
      button.focus();
    });
    return {
      render() {
        const settings = profile();
        const value = settings.thinking_enabled;
        const inherited = typeof value !== "boolean";
        button.textContent = `Thinking: ${inherited ? "Default" : value ? "On" : "Off"}`;
        quickButton.setAttribute("aria-label", button.textContent);
        const title = disabled()
          ? "Thinking for the current task is fixed. Exit steering to change it for new tasks."
          : `${inherited ? "Uses Model Configuration settings." : `Thinking is ${value ? "on" : "off"}.`} Click to turn thinking ${value === true ? "off" : "on"} for new tasks in this conversation.`;
        for (const toggle of [button, quickButton]) {
          toggle.setAttribute("aria-pressed", inherited ? "mixed" : String(value));
          toggle.title = title;
          toggle.disabled = !ready() || disabled();
        }
        budget.disabled = button.disabled || value !== true;
        budget.closest(".thinking-budget").dataset.disabled = String(budget.disabled);
        if (!adjusting || budget.disabled) {
          adjusting = false;
          showBudget(settings.budget_growth?.effective_thinking_percent ?? settings.llm_reasoning_budget_percent ?? settings.thinking_budget_default ?? 50);
        }
        outputBudget.disabled = button.disabled;
        outputBudget.closest(".output-budget").dataset.disabled = String(outputBudget.disabled);
        if (rangeOwner !== settings.conversation_id) {
          rangeOwner = settings.conversation_id;
          rangeMax = 32768;
        }
        const minimum = settings.output_token_min ?? 1;
        const limit = settings.budget_growth?.effective_output_tokens ?? settings.max_completion_tokens ?? settings.output_token_default ?? null;
        rangeMax = Math.max(rangeMax, settings.output_token_default || 0, limit || 0, minimum + 1);
        outputBudget.min = String(minimum);
        outputBudget.max = String(rangeMax);
        if (!adjustingOutput || outputBudget.disabled) {
          adjustingOutput = false;
          showOutput(limit);
        }
        const growth = settings.budget_growth;
        const grown = growth && (growth.increases_used || growth.effective_thinking_percent !== growth.configured_thinking_percent
          || growth.effective_output_tokens !== growth.configured_output_tokens);
        outputReset.hidden = settings.max_completion_tokens == null && !grown;
        outputReset.disabled = button.disabled;
        outputHelp.textContent = disabled()
          ? "The current task keeps its captured output limit. Exit steering to change it for new tasks."
          : "Total tokens per response, including thinking. Increasing this limit also increases the thinking allowance. Must fit alongside the prompt in the model context. Applies to new prompts.";
        outputBudget.closest(".output-budget").title = outputHelp.textContent;
        budgetHelp.textContent = disabled()
          ? "The current task keeps its captured thinking budget. Exit steering to change it for new tasks."
          : value !== true ? "Turn Thinking on to adjust the budget for new prompts."
          : "Share of the response token limit available for thinking. Higher values allow more thinking; lower values leave more room for answers and tool calls. Applies to new prompts. Requires a configured response token limit.";
        budget.closest(".thinking-budget").title = budgetHelp.textContent;
        if (grown) {
          const status = ` Automatic increases: ${growth.increases_used} used in a row, ${growth.increases_remaining} remaining. Configured: ${growth.configured_thinking_percent}% thinking, ${growth.configured_output_tokens == null ? "provider default output" : tokens(growth.configured_output_tokens)}. An accepted model response resets the count and keeps increased budgets. Editing a budget or choosing Default resets the allowance.`;
          outputHelp.textContent += status;
          budgetHelp.textContent += status;
          outputBudget.closest(".output-budget").title = outputHelp.textContent;
          budget.closest(".thinking-budget").title = budgetHelp.textContent;
        }
        reset.hidden = inherited && settings.llm_reasoning_budget_percent == null && !grown;
        reset.disabled = button.disabled;
      },
    };
  }
  window.SMTOComposerThinking = {create};
})();
