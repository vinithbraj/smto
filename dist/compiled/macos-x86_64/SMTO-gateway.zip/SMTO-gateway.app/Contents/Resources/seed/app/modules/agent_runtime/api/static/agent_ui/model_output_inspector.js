/* A cheap collapsed disclosure; the transcript viewer loads only when opened. */
(() => {
  function attach(parent, requestId, callId) {
    const disclosure = document.createElement("details"), summary = document.createElement("summary");
    const panel = document.createElement("div");
    disclosure.className = "event-output trace-output model-output-inspector shell-live";
    summary.textContent = "Model output";
    disclosure.append(summary, panel);
    window.SMTOActivityPresentation.attachSection(parent, disclosure, "Model output");
    let loading = false;
    disclosure.addEventListener("toggle", async () => {
        const busyFeedback = window.SMTOBusy?.action("Loading model output…", disclosure);
        try {
      if (!disclosure.open || panel.modelViewer || loading) return;
      loading = true; panel.textContent = busyFeedback ? "" : "Loading model output…";
      try {
        const {mountModelOutput} = await import("/agent-ui/static/model_output_viewer.js?v=20261018-loading");
        if (!disclosure.isConnected || !disclosure.open) return;
        panel.replaceChildren();
        mountModelOutput({disclosure, panel, requestId, callId});
      } catch (_) { panel.textContent = "Could not load inspector. Close and reopen to retry."; }
      finally { loading = false; }

        } finally { busyFeedback?.finish(); }
      });
    return disclosure;
  }
  window.SMTOModelOutput = {attach};
})();
