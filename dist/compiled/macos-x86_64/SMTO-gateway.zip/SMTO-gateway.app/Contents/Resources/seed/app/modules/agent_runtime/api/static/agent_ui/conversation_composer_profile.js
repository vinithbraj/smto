/**
 * @file src/agent_runtime/api/static/agent_ui/conversation_composer_profile.js
 * @brief Synchronize desktop/mobile future composer preferences with server profiles.
 * @details
 * Responsibilities: Guard navigation, save fields, reconcile conflicts and accepted submissions.
 * Boundaries: Accepted run authority and scheduling persistence stay with existing server owners.
 * Lifecycle: New drafts initialize from defaults; opened chats load; edits autosave; acceptance binds.
 * State: One active in-memory profile, revision, unsynced fields and pending policy writes.
 * Security: Allowlisted preference fields and gateway IDs only; no secrets or browser-wide choices.
 * Collaborators: Desktop app, mobile adapter, conversation profile and existing policy APIs.
 * Public surface: SMTOComposerProfile.create and its navigation/edit/submission methods.
 * @see docs/engineering/conversation-composer.md
 */
(() => {
  "use strict";
  const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const fields = ["agent_mode", "collaboration_mode", "gateway_id", "gateway_selection", "gateway_label_hint", "llm_model", "thinking_enabled", "llm_reasoning_budget_percent", "max_completion_tokens", "behavior_effort",
    "context_carry_forward", "generate_prose", "task_contract_compilation_enabled", "task_contract_integrity_guard_enabled"];
  const policyRoutes = {parallel_execution_policy: "parallel-execution", background_activity_policy: "background-activities",
    dependency_scheduling_policy: "dependency-scheduling", resource_scheduling_policy: "resource-scheduling"};
  // Plan keeps conversation continuity for questions and revisions. Execution
  // still uses the existing server-owned collaboration guard and task modes.
  const modeValue = profile => profile.collaboration_mode === "plan" ? "plan" : profile.agent_mode;
  const modeChanges = mode => mode === "plan"
    ? {agent_mode: "conversation", collaboration_mode: "plan"}
    : {agent_mode: mode, collaboration_mode: "default"};
  function create({apiJson, changed = () => {}, notify = () => {}, onMissing = null}) {
    let active = null;
    const url = cid => `/api/agent/chats/${encodeURIComponent(cid)}/composer-profile`;
    const emit = session => { if (active === session) changed(current()); };
    const current = () => active ? {...copy(active.profile || {}), conversation_id: active.cid,
      budget_growth: ["llm_model", "thinking_enabled", "llm_reasoning_budget_percent", "max_completion_tokens"].some(key => key in active.dirty)
        ? null : copy(active.budgetGrowth ?? null),
      context_carry_forward_default: copy(active.carryForwardDefault || {mode: "all"}),
      thinking_budget_default: active.thinkingBudgetDefault ?? 50,
      output_token_default: active.outputTokenDefault ?? null, output_token_min: active.outputTokenMin ?? 1,
      loading: active.loading, error: active.error || active.policyError, policyPending: active.policyPending || 0, unsynced: Boolean(active.cid && Object.keys(active.dirty).length)} : {loading: true};
    function merge(session, profile) {
      if ((session.profile?.revision || 0) > profile.revision) return;
      session.base = copy(profile);
      session.profile = {...copy(profile), ...copy(session.dirty)};
    }
    function budgetDefaults(session, result) {
      session.carryForwardDefault = result.context_carry_forward_default || {mode: "all"};
      session.budgetGrowth = result.budget_growth ?? null;
      session.thinkingBudgetDefault = result.thinking_budget_default;
      session.outputTokenDefault = result.output_token_default;
      session.outputTokenMin = result.output_token_min;
    }
    async function activate(cid = null) {
      const session = active = {cid, profile: null, dirty: {}, policies: {}, policyPending: 0, policyError: "", policyFailed: {}, refreshVersion: 0, policyWrites: Promise.resolve(), pending: Promise.resolve(), loading: true, error: "", epoch: 0};
      emit(session);
      try {
        const result = await apiJson(cid ? url(cid) : "/api/agent/composer-defaults");
        if (session !== active) return false;
        session.profile = result.profile; session.base = copy(result.profile);
        budgetDefaults(session, result);
        session.policies = result.conversation_policy_defaults || {};
        session.loading = false; emit(session); return true;
      } catch (error) {
        session.error = error.message; session.loading = false; emit(session);
        if (error.status === 404 && active === session && onMissing) onMissing();
        throw error;
      }
    }
    async function save(session, changes, epoch) {
      if (!session.cid) return;
      for (let attempt = 0; attempt < 2; attempt++) {
        if (epoch !== session.epoch) return;
        try {
          const result = await apiJson(url(session.cid), {method: "PATCH", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({expected_revision: session.profile.revision, changes})});
          if (epoch !== session.epoch) return;
          for (const [key, value] of Object.entries(changes)) {
            if (JSON.stringify(session.dirty[key]) === JSON.stringify(value)) delete session.dirty[key];
          }
          merge(session, result.profile); budgetDefaults(session, result);
          session.error = ""; emit(session); return;
        } catch (error) {
          if (epoch !== session.epoch) return;
          if (error.status === 409 && attempt === 0) {
            try {
              const fresh = await apiJson(url(session.cid));
              if (epoch !== session.epoch) return;
              merge(session, fresh.profile); continue;
            } catch (refreshError) { error = refreshError; }
          }
          if (error.status === 404 && active === session && onMissing) { onMissing(); return; }
          session.error = `${error.message} Your choice is unsynced. Retry or send to save it with the task.`;
          emit(session); if (active === session) notify(session.error); return;
        }
      }
    }
    function patch(changes) {
      if (changes.agent_mode === "advisory") changes = {...changes, collaboration_mode: "default"};
      const session = active;
      if (!session?.profile || session.loading) return Promise.resolve();
      if (Object.keys(changes).some(key => !fields.includes(key))) throw window.SMTOErrors.error("ui_composer_field_invalid");
      Object.assign(session.profile, copy(changes));
      Object.assign(session.dirty, copy(changes));
      emit(session);
      const epoch = session.epoch;
      const feedback = session.cid ? window.SMTOBusy?.begin({host: document.querySelector("#composer-profile-status") || document.activeElement, label: "Saving conversation settings…", key: "composer-settings", replace: true}) : null;
      session.pending = session.pending.catch(() => {}).then(() => save(session, changes, epoch)).finally(() => feedback?.finish());
      return session.pending;
    }
    async function refresh() {
      const session = active;
      if (!session || session.loading || !session.profile) return;
      await session.pending;
      const cid = session.cid, epoch = session.epoch, version = ++session.refreshVersion;
      try {
        const fresh = await apiJson(cid ? url(cid) : "/api/agent/composer-defaults");
        if (epoch !== session.epoch || version !== session.refreshVersion
            || (cid && fresh.profile.revision < session.profile.revision)) return;
        // An unsent draft keeps its edits; only the inherited budgets follow
        // live main settings. Null overrides remain null in submissions.
        if (cid) merge(session, fresh.profile);
        budgetDefaults(session, fresh);
        if (cid && !session.policyPending && !session.policyError) session.policies = fresh.conversation_policy_defaults || session.policies;
        emit(session);
      } catch (error) {
        if (error.status === 404 && active === session) { if (onMissing) onMissing(); else await activate(null); }
      }
    }
    function submission() {
      if (!active?.profile || active.loading || active.policyPending || active.policyError || !active.profile.gateway_id || !active.profile.llm_model)
        throw window.SMTOErrors.error("ui_composer_not_ready");
      const carry = active.profile.context_carry_forward || active.carryForwardDefault || {mode: "all"};
      return {context_carry_forward: {mode: carry.mode, ...(carry.mode === "rolling" ? {window_size: carry.window_size} : {})},
        composer_values: Object.fromEntries(fields.map(key => [key, copy(active.profile[key])])),
        collaboration_mode: active.profile.collaboration_mode || "default",
        composer_profile_revision: active.profile.revision,
        composer_policy_values: copy(active.policies),
        composer_profile_base: Object.fromEntries(fields.map(key => [key, copy(active.base[key])])),
        ...(!active.cid ? {conversation_policy_defaults: copy(active.policies)} : {})};
    }
    function accepted(response, submitted = null) {
      if (!active || !response.composer_profile) return;
      const session = active;
      // In-flight responses/retries from before acceptance cannot roll it back.
      session.epoch++;
      const later = {};
      for (const [key, value] of Object.entries(session.dirty)) {
        if (submitted && JSON.stringify(value) !== JSON.stringify(submitted.composer_values?.[key])) later[key] = value;
      }
      const laterPolicies = Object.fromEntries(Object.entries(session.policies).filter(([key, value]) =>
        submitted && JSON.stringify(value) !== JSON.stringify(submitted.composer_policy_values?.[key])));
      session.cid = response.conversation_id; session.dirty = later;
      merge(session, response.composer_profile); session.error = ""; emit(session);
      void refresh();
      if (Object.keys(later).length) void patch(later);
      for (const [key, policy] of Object.entries(laterPolicies)) void setPolicy(key, policy).catch(error => notify(error.message));
    }
    function setPolicy(key, policy) {
      if (!policyRoutes[key] || !active?.profile) return Promise.resolve();
      const session = active;
      session.policies[key] = copy(policy);
      if (!session.cid) { emit(session); return Promise.resolve(); }
      session.policyPending++; session.refreshVersion++; emit(session);
      const write = async () => {
        try {
          await apiJson(`/api/agent/${policyRoutes[key]}`, {method: "PUT", headers: {"Content-Type": "application/json"},
            body: JSON.stringify({scope: "conversation", conversation_id: session.cid, policy})});
          delete session.policyFailed[key];
        } catch (error) {
          session.policyFailed[key] = error.message;
          throw error;
        } finally {
          session.policyPending--; session.refreshVersion++;
          session.policyError = Object.keys(session.policyFailed).length ? "Conversation policy is unsynced. Retry settings before sending." : "";
          emit(session);
        }
      };
      session.policyWrites = session.policyWrites.catch(() => {}).then(write);
      return session.policyWrites;
    }
    const retry = async () => {
      if (!active?.profile) return activate(active?.cid);
      const session = active;
      for (const key of Object.keys(session.policyFailed)) {
        if (active !== session) return;
        await setPolicy(key, session.policies[key]);
      }
      if (active === session && Object.keys(session.dirty).length) return patch(copy(session.dirty));
    };
    return {activate, current, patch, refresh, retry, submission, accepted, setPolicy,
      selectMode: mode => patch(modeChanges(mode)),
      policy: key => copy(active?.policies[key]),
      ready: () => Boolean(active?.profile && !active.loading), flush: () => Promise.all([active?.pending, active?.policyWrites])};
  }
  window.SMTOComposerProfile = {create, fields, policyRoutes, modeValue};
})();
