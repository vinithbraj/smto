---
id: ui-surfaces
title: Desktop and mobile UI ownership
kind: architecture
tags: [architecture, current, ui-surfaces]
order: 26
---
# Desktop and mobile UI ownership

## Browser source and lifetime map

Paths below are relative to `src/agent_runtime/api/static/agent_ui/`. HTML asset
order and mobile import edges are the authority; source file size is not a reason
to introduce a new loader or merge controllers.

| Surface | Entry and collaborators | Lifetime and cleanup contract |
| --- | --- | --- |
| Desktop composition | `index.html` loads base `app.css`, feature styles including `dialog_surfaces.css`, globals and deferred controllers; `app.js` composes them | Feature globals load before `app.js`; keep DOM IDs, script order and cache IDs stable. Feature CSS can override earlier base rules. |
| Desktop updates | `ui_updates.js` exposes `SMTOUiUpdates`; `app.js` subscribes to run/task/chat/settings topics | One shared update EventSource per page; `connect` closes its predecessor. Subscribers return disposal functions. Critical reads, not an open transport, establish freshness. The connection epoch rejects stale read completions. |
| Desktop request trace | `app.js:connectTrace`, `closeTrace`, `resumeInteractionTrace` | A mounted turn owns its source, cursor and reconnect timer. Identity/DOM checks reject stale callbacks; close the old source before continuation attachment. Replayed terminal events cannot close a newly resumed attempt. |
| Mobile composition | `mobile/index.html` loads shared small globals and `mobile/app.js` as a module; composer/API/overlay imports and lazy conversation/panels remain separate | Navigation's AbortController fences obsolete fetches. Sheets and history/options/context/queue panels load on demand; mobile does not load desktop `app.js`. |
| Mobile streams | `mobile/streaming.js:createStreams` | Create once per page. A map owns per-turn traces alongside one page update source. Stop/hide/pagehide close transports and timers; reconciliation checks owner identity after every awaited callback/read before painting or cleanup. Global visibility/network listeners retain page lifetime. |
| Mobile API and drafts | `mobile/api.js`; `mobile/app.js` supplies navigation/submission callbacks | Plain GETs share the existing snapshot read coalescer; signalled/custom-header reads and writes remain independent. A pending draft retains its conversation at input time; accepted submission consumes matching text while preserving newer edits. Local selections grant no execution authority. |
| Shared command output | `shell_live_stream.js`; `mobile/lazy/shell_live_stream.js` forwards the same export | One observer per mounted panel, active only while visible and expanded. Disconnects retain command truth; closing suspends streams/retries/clocks, and removal disposes the viewer and pending paint. The mobile adapter preserves lazy loading. |
| Receipt waveform | `stream_activity.js`; `rolling_history.js`; `ui_session_state.js` | Caller-owned 600-bucket history retains observations while hidden. The optional desktop renderer paints at 100 ms only when visible/enabled; pagehide clears its timer. It opens no stream or HTTP request. |
| Composer state | `conversation_composer_profile.js`, `draft_cache.js`, mobile profile/composer adapters | Draft selection is independent of accepted task scope. Settings refresh cannot retarget running work. Server profiles own saved preferences. |
| Error presentation | Desktop `error_presenter.js`; mobile `errors.js` | Both expose `SMTOErrors`, but each page loads its own implementation. Lookup caches are bounded; mounting changes only the error slot, preserving answer/action controls. |

The error presenters have preserved differences: desktop notifications and
dependency-repair toasts include remediation text; mobile notification summaries
and toasts omit it. Mobile can lazily import `manual_links.js` to repair a help URL;
desktop uses the already available helper or fallback. Both render reconciliation
cautions. Similar source blocks do not justify changing these visible behaviors.

### Reconnect and rendering boundaries

Desktop invalidations coalesce over 50 ms. Critical subscribers must finish their
authoritative reads before freshness becomes current; failed reads have three
backoff attempts. Optional subscribers can wait for `SMTOReadPriority`, owned
by `conversation_snapshot.js`, without holding critical readiness. An EventSource
in CONNECTING retains native browser reconnect and its cursor; only CLOSED sources
are explicitly replaced, with visibility and network checks.

Mobile uses separate ownership: an update cursor survives replacement, while each
displayed turn has its own trace cursor and retry timer. A trace failure or terminal
frame refreshes task truth before reconnecting or loading a final trace summary.
Trace backoff caps at 15 seconds; update-stream replacement uses a 3-second delay.
Reconciliation fences its captured owner after refresh, summary fetch and snapshot
application. A replacement may have the same run ID or even reuse the same turn
object; neither permits an older completion to close its stream or clear connection
status. Valid settled owners still release their trace normally.
This is not the desktop subscriber/freshness protocol, so sharing those controllers
would require new lifecycle characterization rather than a mechanical deduplication.

Waveform and foreground elapsed-time timers are local presentation work. The
waveform keeps cumulative per-call receipts idempotent, distributes corrected input
intervals over their original times, and retains a context-level anchor. Collapsing
or hiding the plot pauses painting without dropping receipt history. Neither these
timers nor an SSE disconnect establishes execution completion or permission to retry.

## Current interaction surfaces

Inference-enabled Linux controllers add `/inference` to desktop/mobile navigation
and the directory. `src/controller_inference/static/` composes shared portal forms
with the existing controller appearance, model-configuration and prompt-caching
editors. All eight sections use authenticated operations and bookmarked tabs.
Saved drafts, running launch snapshots and observations remain distinct; Save
does not restart an engine. API revisions and durable lifecycle operations
arbitrate manual/agent changes. External-only builds omit the page and navigation.
See [Inference management](../45-inference.md) for the workflows.

Both composers expose Agent, Plan, and Ask in one mode picker; Conversation is
hidden from selectable modes and Settings. Implementation switches to Agent.
Shared composer profiles own
`collaboration_mode`; desktop Controls and mobile Agent options render it. Accepted
plan metadata renders “Implement this plan?” with retained-context implementation,
fresh-context implementation, and stay-in-Plan choices. Only submission identity,
context choice and expected digest reach the API; browsers never supply approved
Markdown. Compact native metadata and existing trace/history reads restore the card
and answer after reload or a completion/publication race. One card read reconciles
consumption, without another polling loop. Ordinary structured questions render
accessible choices, a recommendation and an optional Other answer.

Captured Shell rows provide an on-demand live output disclosure on both surfaces.
Opening it creates one read-only per-command SSE; closing it, hiding its parent activity,
hiding the tab or disposing the conversation closes the observer. Reopening catches up
from retained evidence without an LLM call or additional shell/Gateway/SSH execution.
The normal conversation trace carries lifecycle metadata rather than the Shell transcript.
Output is projected through server-side redaction before delivery according to the current
TRACES setting. Browser connection loss does not establish command completion or failure.

Desktop and mobile keep their own row composition and styles. Mobile imports its lazy
Shell adapter only on expansion; both use a small surface-neutral observer, without
loading the desktop controller. The transcript is inert text, batched for rendering and
bounded to the latest 256K code units with an explicit omission notice. Copy reads
a finite retained-output snapshot from the scoped server endpoint, independently
of the bounded browser tail and under the server's projection policy. Scrolling away from the tail pauses following until the user
chooses Jump to latest. Local timing updates do not issue network requests.

The desktop Agent UI composes a workspace plus settings, policies/Agent Checks, Gateway
Management, schedules, notifications, parameters and directory surfaces. Conversation
navigation chooses and resumes server-owned conversations; run visualization projects
activity and trace data. Activity inspection exposes sanitized detail. Browser state
owns presentation and interaction, not execution authority.

The minimized desktop prompt remains editable with visible Send and Maximize buttons.
Clicking, tapping or focusing the text field keeps it minimized; Maximize opens the full
composer and its controls. Both sizes share the same draft, submission path and selected
settings. Enter sends or queues the prompt. Shift+Enter inserts a newline, increments a
numbered list item, or continues a bullet or checkbox with its indentation. Shift+Enter
on an empty list item removes its marker to end the list; fenced code stays plain text.

The [command palette](41-command-palette.md) places that same live desktop composer
inside a modal dialog. Ctrl/Cmd+K invokes the visible conversation; `aor palette`
opens the browser in a new conversation. Command discovery, targets, admission,
attachments and task observations keep their existing owners. No native global
keyboard hook or second Agent client is installed.

The dedicated mobile page has its own `mobile/app.js` composition, API client,
conversation rendering, composer, streaming, overlays and responsive stylesheet.
Context, policy, history, queue, navigation and detail panels load through dedicated
lazy modules. Both surfaces use server APIs and shared durable conversation/run state;
the mobile page does not instantiate the full desktop controller.

Inline follow-ups retain one durable task identity across separate request attempts.
History responses project optional `task_id` and `parent_request_id` from bound task
attempts in one batch; native snapshots reuse their existing task/continuation state.
Chat turns remain request-keyed and require no lineage columns or migration.

Both clients compact a turn boundary only when its immediately preceding mounted
turn is its direct parent and both carry the same nonempty task ID. This is a derived
DOM presentation state. Desktop recomputes it on history mount and eviction without
moving articles between pages; interleaved tasks and missing parents keep ordinary
boundaries. Answers, traces, artifacts, timing and controls remain request-scoped.
Real follow-up prompts remain visible and navigable, and the newest eligible request
owns the inline editor. Mobile keeps that editor outside collapsed Task controls.

## Conversation history activity

The history rail and mobile history show **Running** when any run owned by that
conversation projects `running`, `waiting_job` or `waiting_event`. The latter two
are durable machine waits serviced by the existing continuation worker. Queued,
human-input/approval waits, paused, partial, blocked, interrupted and terminal
states do not qualify. One indicator represents the conversation; a tooltip gives
the active run count. Multiple conversations can show Running simultaneously.

Selection remains independent: desktop `data-active` and mobile `aria-current`
identify the open conversation; `data-run-active` represents server activity.
`conversation_activity.py` projects existing ledger ownership and compact native,
trace and task status through `user_visible_status`. Both chat summary APIs expose
`has_active_run` and `active_run_count`. The Running filter uses that same projection
locally and before server-search counts/pagination. Other filters retain their
existing latest-request meaning. Activity never changes conversation timestamps.

Shared `runs.changed`, `tasks.changed`, `chats.changed` and `sync.required` events
invalidate summaries using a 180ms history debounce. No polling or additional SSE
connection is introduced. Refreshes preserve focus; desktop activity stays on the
existing metadata line and participates in both virtual-row render signatures.
Ordinary history omits activity fields if projection fails and logs the failure;
Running-filter requests keep their normal error boundary because membership is unknown.

The shared broker is process-local. Initial loads and reconnect reconciliation
recover durable state, but this does not promise immediate cross-process delivery.

Agent Checks ordinary fields use `chat-field-control` and native selects inside
`chat-select-shell`, created by `agent_checks.js` and styled by `agent_checks.css`.
`app.css` owns the desktop `--ui-control-*` aliases (34px minimum height, 8px radius,
13px type); `mobile/mobile.css` supplies its existing 12px radius and touch sizing.
Narrow fields use at least 44px height and 16px type. Select chevrons are decorative;
forced colors restores the native arrow, and opened option menus remain browser-owned.
The chat page does not import auxiliary `shared.css`. Composer, permission, capability,
clarification and OAuth authorization components retain their own visual contracts.
The queued-prompt textarea and unsafe-action administrator-password input also opt
into the field skin while their controllers retain editing and credential lifetimes.
Policy scopes, prompt drafts, validation and API persistence remain controller/server
responsibilities; field classes carry presentation only.

Credentials are ordinary literal inputs. Server state owns profiles; consumer visibility follows [Redaction](31-redaction.md). Reconnecting event streams refreshes projections without duplicating execution.

The manual and diagnostic console are separate pages/services, with their own browsing
or sampling state. They do not schedule Agent work. Source owners are under
`api/static/agent_ui/`, `api/static/agent_ui/mobile/`, `manual/` and `console/`.

Mission Control's [Model Configuration](../25-model-configuration.md) component renders
its profile, parameter schema, help and recommendation metadata from the settings
registry. Shared switches encode parameter presence beside inline value editors;
responsive columns and collapsed help keep the controls compact. An off switch
omits its field, including when an explicit zero or false would have been valid.
`model_configuration.js` owns field presentation and local errors;
`settings.js` owns the existing serialized autosave. The backend owns validation,
profile resolution and persistence. The same Settings page supports desktop and
mobile widths; it does not add a second model selector or browser-owned inference
policy. Server-rejected edits remain available for correction.


## Conversation composer settings

Mode, gateways, model and task options remain conversation preferences. Secure Prompts is retired. Settings → Redaction exposes independent sources, all on for new installations; execution-related sources are captured at run admission.

Quick scheduling switches save conversation defaults through their existing policy engines.
Advanced Agent Checks still offers **This prompt** overrides, including Integrity Guard.
**Use conversation default** clears the temporary integrity override. Disabling compilation
preserves the integrity preference. Successful submission consumes prompt overrides.

`api/agent_ui_support/composer_profile.py` and `conversation_composer_profile.js` own the
backend and shared browser lifecycle. Mobile supplies a small adapter without loading the
desktop application. Profile GET/PATCH endpoints are under
`/api/agent/chats/{conversation_id}/composer-profile`; `/api/agent/composer-defaults`
initializes the unsent new-chat draft. See [Configuration and storage](../09-configuration-storage.md).

## HTTP Parameter editor

`parameter_editor.js` owns selection and metadata. `http_profile_editor.js` edits literal auth/TLS/session/proxy fields and provides Gateway test/disconnect actions. Profile JSON follows PARAMETERS projection. Templates do not call a model or provider.

The desktop inline answer and mobile “Your answer” control both send ordinary text,
including credential-shaped values, without parsing or replacing it. Draft and
recall retention follow their ordinary settings. Unsafe confirmation has only
approval/cancel controls. OAuth is rendered by `oauth_prompt.js` on desktop and
`mobile/lazy/interactions.js` on mobile, using `oauth_authorization_request`; browser
links and device codes are protocol controls, with no generic credential-entry form.

## Agent Check monitoring

**Settings → Agent Checks → Monitor disabled Agent Checks** is an independent switch, seeded ON for fresh installations and persisted by the existing preferences API. Existing installations retain their setting; missing legacy values resolve OFF. It applies to future accepted work; **Disable all** does not change it. An unsuccessful save restores the previous switch value.

Desktop and mobile render disabled-check observations as informational Activity entries with **Learn more**, opening deployment-aware Manual documentation in a new tab. They carry no approval, retry, pause or resume controls. Both surfaces retain each distinct capability lifecycle event and deduplicate only replay of the same durable event ID.
