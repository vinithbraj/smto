/** Inline recovery uses the same disclosure, typography and controls as Agent checks.
 * The Gateway owns eligibility and the revision-bound decision. No modal or local
 * process guesses: one choice either starts a durable watch or terminates/reset claims.
 */
(() => {
  const displayCopy = value => window.SMTOBranding?.text(value) ?? value;
  const mounted = new WeakMap();
  function node(tag, text, className) {
    const element = document.createElement(tag);
    if (text) element.textContent = text;
    if (className) element.className = className;
    return element;
  }
  function render(root, policy, hooks) {
    const request = policy?.resource_reconciliation_request;
    let state = mounted.get(root);
    if (state?.requestId !== hooks.requestId) state = null;
    if (!state) {
      state = {requestId: hooks.requestId, busy: false};
      mounted.set(root, state);
    }
    state.request = request; state.hooks = hooks;
    if (!request) { state.card?.remove(); state.card = null; }
    const notices = policy?.resource_recovery_notices || [];
    if (notices.length) {
      const notice = state.notice || node('p', '', 'agent-check-relaxed resource-repair-notice');
      state.notice = notice;
      const message = notices.length === 1 ? notices[0].message
        : `${notices.length} abandoned job claims were automatically cleared. Continuing.`;
      if (notice.textContent !== message) notice.textContent = message;
      notice.setAttribute('role', 'status');
      root.append(notice);
    } else state.notice?.remove();
    if (!request) return;
    if (!state.card) {
      const card = node('details', '', 'action-card agent-check-strike resource-reconciliation');
      card.open = true;
      const title = node('summary'), message = node('p'), facts = node('p');
      const actions = node('div', '', 'action-buttons actions');
      const status = node('p'); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
      state.buttons = [];
      for (const [id, label] of [['wait', 'Wait until the job state changes'],
        ['reset', 'Resolve forcefully by terminating job']]) {
        const button = node('button', label, 'action-button'); button.type = 'button';
        button.dataset.recoveryAction = id;
        button.onclick = () => submit(state, id, root);
        state.buttons.push(button); actions.append(button);
      }
      card.append(title, message, facts, actions, status);
      Object.assign(state, {card, title, message, facts, status});
    }
    state.title.textContent = request.title || 'Job recovery';
    state.message.textContent = request.message;
    state.facts.textContent = `Your command has not started. Blocking job: ${request.blocker_status || 'unknown'}.`;
    if (!state.busy) state.status.textContent = request.watching
      ? displayCopy('Waiting for the job state to change. smTO will continue automatically when the claim is released.')
      : request.resume_allowed === false ? 'This task has ended. You can still release its blocking job claims.' : '';
    updateButtons(state);
    root.append(state.card);
  }
  function updateButtons(state) {
    for (const button of state.buttons) {
      const action = state.request?.actions?.find(item => item.id === button.dataset.recoveryAction);
      button.disabled = state.busy || !action || action.enabled === false
        || button.dataset.recoveryAction === 'wait' && state.request?.watching;
    }
  }
  async function submit(state, action, root) {
    const busyFeedback = window.SMTOBusy?.begin({host: root, label: "Updating task resources…"});
    try {
    if (state.busy || !state.request) return;
    const request = state.request, hooks = state.hooks;
    state.busy = true; updateButtons(state);
    state.status.textContent = action === 'reset' ? 'Terminating the blocking job and restoring its claims…'
      : 'Waiting for the job state to change…';
    const fresh = () => root.isConnected && mounted.get(root) === state;
    try {
      const result = await hooks.apiJson(`/api/agent/native/${encodeURIComponent(hooks.requestId)}/resource-reconciliation`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({action, decision_id: request.decision_id, blocker_revision: request.blocker_revision,
          ...(action === 'reset' ? {reset_confirmed: true} : {})}),
      });
      if (!fresh()) return;
      if (result.recovery_refreshed) {
        state.status.textContent = result.reset_completed ? 'Blocking job claims restored.' : 'Job state updated.';
      } else await hooks.onAccepted?.({...result, resumed: true});
      await hooks.reload?.(hooks.requestId);
    } catch (error) {
      if (!fresh()) return;
      window.SMTOErrors.present(state.status, error);
      if (error.status === 409) await hooks.reload?.(hooks.requestId);
    } finally {
      state.busy = false;
      if (fresh() && state.card) updateButtons(state);
    }

    } finally { busyFeedback?.finish(); }
  }
  window.SMTOResourceReconciliation = {render};
})();
