/* Decorative thinking indicators. SVG, motion and the shared UI preference live here;
 * execution/status truth remains with the existing desktop and mobile renderers. */
(() => {
  "use strict";
  if (window.SMTOThinkingAnimations) return;

  const cuboidOrigins = [];
  const variants = [
    {id: "rubiks-cube", label: "Rubik’s cube", viewBox: "-18 -18 36 36", setup: animateRubiks,
      svg: '<g class="ta-rubiks" data-phase="solved"></g>'},
    {id: "rubiks-cube-monochrome", label: "Rubik’s cube (monochrome)",
      viewBox: "-18 -18 36 36", setup: animateRubiks,
      svg: '<g class="ta-rubiks" data-phase="solved"></g>'},
    {id: "cuboid", label: "Original cuboid", viewBox: "-18 -18 36 36", setup: animateCuboid, svg: (() => {
      const blocks = [];
      // Restore the original tumbling 2 × 2 × 2 matrix, rear/lower blocks first.
      for (let z = 0; z < 2; z++) for (let x = 0; x < 2; x++) for (let y = 0; y < 2; y++) {
        const left = (x - y) * 5.5, top = (x + y - 1) * 2.75 + (0.5 - z) * 6;
        cuboidOrigins.push({left, top});
        blocks.push(`<g transform="translate(${left} ${top})"><g class="thinking-voxel"
          style="--voxel-delay:${blocks.length * 32}ms">
          <path class="voxel-top" d="M0-5 5-2.5 0 0-5-2.5Z"/>
          <path class="voxel-left" d="M-5-2.5 0 0v6l-5-2.5Z"/>
          <path class="voxel-right" d="M0 0 5-2.5v6L0 6Z"/>
        </g></g>`);
      }
      return blocks.join("");
    })()},
    {id: "cube-face", label: "Curious cube", svg: `
      <g class="ta-float">
        <path class="ta-tint" d="m16 3 12 7v14l-12 7L4 24V10Z"/>
        <path d="m4 10 12 7 12-7M16 17v14M16 3v14"/>
        <g class="ta-blink"><path d="M8 16v3m4-1v3"/></g>
        <path d="m8 23 4 2"/>
        <path class="ta-signal" d="m21 19 3-2m-3 7 3-2"/>
      </g>`},
    {id: "robot-face", label: "Robot daydream", svg: `
      <path d="M16 8V5M5 16H3v6h2m24-6h2v6h-2"/>
      <circle class="ta-pulse ta-solid" cx="16" cy="3" r="1.6"/>
      <rect class="ta-tint" x="5" y="8" width="24" height="22" rx="7"/>
      <g class="ta-glance"><g class="ta-blink">
        <path d="M11 15v3m10-3v3" stroke-width="2.6"/>
      </g></g>
      <path d="M11 24h12"/>
      <path class="ta-signal" d="M13 22v4m4-4v4m4-4v4"/>
    `},
    {id: "robot-emoji", label: "Robot emoji 🤖", svg: `
      <g class="ta-float">
        <path d="M17 8V4" stroke="#75828c"/>
        <circle class="ta-pulse" cx="17" cy="3" r="2" fill="#f35b57" stroke="#b5363d"/>
        <rect x="1" y="14" width="4" height="10" rx="2" fill="#ef625c" stroke="#b5363d"/>
        <rect x="29" y="14" width="4" height="10" rx="2" fill="#ef625c" stroke="#b5363d"/>
        <rect x="4" y="8" width="26" height="23" rx="4" fill="#cbd6dc" stroke="#75828c"/>
        <path d="M7 11h20" stroke="#f7fafc"/>
        <g class="ta-blink"><circle cx="10" cy="17" r="4" fill="#fff" stroke="#75828c"/>
          <circle cx="24" cy="17" r="4" fill="#fff" stroke="#75828c"/>
          <g class="ta-glance" fill="#354957" stroke="none"><circle cx="10" cy="17" r="2"/>
            <circle cx="24" cy="17" r="2"/></g></g>
        <path d="m17 20-2 3h4Z" fill="#f35b57" stroke="#b5363d"/>
        <rect x="10" y="25" width="14" height="4" rx="1" fill="#fff" stroke="#75828c"/>
        <path d="M14 25v4m6-4v4" stroke="#75828c"/>
      </g>`},
    {id: "cube-robot", label: "Cube buddy", svg: cubeRobotSvg()},
    {id: "robot-boy", label: "Milo (robot boy)", svg: roundRobotSvg()},
    {id: "robot-girl", label: "Mimi (robot girl)", svg: roundRobotSvg({girl: true})},
    {id: "cube-robot-boy", label: "Cubie (cube boy)", svg: cubeRobotSvg({
      character: "ta-robot-cubie", tiles: ["#d3eaf9", "#d8f1eb", "#e3f2fb"],
      accessory: `<g transform="translate(13.6 28)">${robotBowSvg()}</g>`,
    })},
    {id: "cube-robot-girl", label: "Coco (cube girl)", svg: cubeRobotSvg({
      character: "ta-robot-coco", tiles: ["#ffe4d7", "#f9dfec", "#f7e7fc"], girl: true,
      accessory: `<g transform="translate(23.5 7)"><g class="ta-robot-bow">${robotBowSvg()}</g></g>`,
    })},
    {id: "robot-sprout", label: "Sprout bot", svg: roundRobotSvg({sprout: true})},
    {id: "robot-patchwork", label: "Patchwork bot", svg: cubeRobotSvg({
      character: "ta-robot-patchwork", tiles: ["#ffe5b8", "#d7eee0", "#f4d9ed", "#d6e9ff"], assemble: true,
    })},
    {id: "brain", label: "Synaptic brain", svg: `
      <g class="ta-breathe">
        <path class="ta-tint" d="M17 7c-2-6-9-4-9 0-5 0-7 7-3 10-4 5 0 11 5 10 1 5 7 4 7 0Zm0 0c2-6 9-4 9 0 5 0 7 7 3 10 4 5 0 11-5 10-1 5-7 4-7 0Z"/>
        <path d="M8 7v5l4 2m-7 3h5l2 4m-2 6 3-3m13-17v5l-4 2m7 3h-5l-2 4m2 6-3-3"/>
        <circle class="ta-signal ta-solid" cx="12" cy="14" r="1.7"/>
        <circle class="ta-signal ta-solid" style="--ta-delay:-.8s" cx="22" cy="21" r="1.7"/>
      </g>`},
    {id: "neurons", label: "Neural sparks", svg: `
      <path class="ta-flow" d="m5 6 12 11L29 5M4 25l13-8 12 11M17 2v30"/>
      <g class="ta-pulse"><circle class="ta-tint" cx="17" cy="17" r="5"/>
        <circle class="ta-solid" cx="17" cy="17" r="1.8"/></g>
      <g class="ta-signal"><circle class="ta-solid" cx="5" cy="6" r="2"/>
        <circle class="ta-solid" cx="29" cy="28" r="2"/></g>
      <g class="ta-signal" style="--ta-delay:-1s"><circle class="ta-solid" cx="29" cy="5" r="2"/>
        <circle class="ta-solid" cx="4" cy="25" r="2"/></g>
    `},
    {id: "orbit", label: "Orbiting ideas", svg: `
      <ellipse class="ta-muted" cx="17" cy="17" rx="14" ry="7" transform="rotate(-35 17 17)"/>
      <ellipse class="ta-muted" cx="17" cy="17" rx="14" ry="7" transform="rotate(35 17 17)"/>
      <path class="ta-breathe ta-tint" d="m17 11 6 6-6 6-6-6Z"/>
      <g class="ta-orbit"><circle class="ta-solid" cx="5" cy="12" r="2.3"/></g>
      <g class="ta-orbit ta-reverse"><circle class="ta-solid" cx="27" cy="25" r="1.7"/></g>
    `},
    {id: "puzzle", label: "Connecting pieces", svg: `
      <path class="ta-piece ta-tint" style="--ta-x:-3px;--ta-y:-3px" d="M5 5h11v4c4-2 4 5 0 3v4h-4c2-4-5-4-3 0H5Z"/>
      <path class="ta-piece ta-tint" style="--ta-x:3px;--ta-y:-3px;--ta-delay:-.3s" d="M18 5h11v11h-4c2-4-5-4-3 0h-4v-4c4 2 4-5 0-3Z"/>
      <path class="ta-piece ta-tint" style="--ta-x:-3px;--ta-y:3px;--ta-delay:-.6s" d="M5 18h4c-2-4 5-4 3 0h4v4c-4-2-4 5 0 3v4H5Z"/>
      <path class="ta-piece ta-tint" style="--ta-x:3px;--ta-y:3px;--ta-delay:-.9s" d="M18 18h4c-2-4 5-4 3 0h4v11H18v-4c-4 2-4-5 0-3Z"/>
    `},
    {id: "reasoning-tree", label: "Branching thoughts", svg: `
      <path class="ta-flow" d="M17 7v7H7v10m10-10h10v10M17 14v14"/>
      <circle class="ta-tint ta-pulse" cx="17" cy="5" r="3"/>
      <circle class="ta-tint ta-signal" cx="7" cy="27" r="3"/>
      <circle class="ta-tint ta-signal" style="--ta-delay:-.6s" cx="17" cy="29" r="3"/>
      <circle class="ta-tint ta-signal" style="--ta-delay:-1.2s" cx="27" cy="27" r="3"/>
    `},
    {id: "focus", label: "Finding the pattern", svg: `
      <g class="ta-tilt"><circle class="ta-tint" cx="14" cy="14" r="10"/>
        <path d="m22 22 8 8m-7-10 8 8"/>
        <g class="ta-muted"><path d="M10 10h.1M18 10h.1M10 18h.1M18 18h.1" stroke-width="3"/></g>
        <path class="ta-scan" d="M8 14h12"/>
        <circle class="ta-signal ta-solid" cx="14" cy="14" r="1.6"/>
      </g>`},
    {id: "lightbulb", label: "An idea forming", svg: `
      <path class="ta-tint ta-breathe" d="M10 22C0 12 8 5 17 5s17 7 7 17l-2 4H12Z"/>
      <path d="M13 29h8m-6 3h4M14 25v-9l3 3 3-3v9"/>
      <g class="ta-signal"><path d="M17 1v1M3 5l2 2m24-2-2 2M1 16h3m26 0h3"/></g>
    `},
    {id: "voxel-cube", label: "Building an answer", svg: (() => {
      const blocks = [];
      for (let z = 0; z < 2; z++) for (let x = 0; x < 2; x++) for (let y = 0; y < 2; y++) {
        const left = 17 + (x - y) * 6, top = 15 + (x + y - 1) * 3 + (0.5 - z) * 7;
        blocks.push(`<g transform="translate(${left} ${top})"><g class="ta-voxel"
          style="--ta-x:${(x - y) * 4}px;--ta-y:${z ? -5 : 5}px;--ta-delay:${blocks.length * -0.09}s">
          <path class="ta-voxel-top" d="M0-5 5-2.5 0 0-5-2.5Z"/>
          <path class="ta-voxel-left" d="M-5-2.5 0 0v6l-5-2.5Z"/>
          <path class="ta-voxel-right" d="M0 0 5-2.5v6L0 6Z"/>
        </g></g>`);
      }
      return blocks.join("");
    })()},
  ];
  // Fixed character artwork shares the same face and motion so every robot stays
  // legible at indicator size and inherits the shared pause/reduced-motion rules.
  /** Build the shared blinking face with optional eyelash geometry. */
  function robotFaceSvg(girl = false) {
    return `<g class="ta-buddy-face">
      <g class="ta-buddy-look"><g class="ta-buddy-eyes">
        <rect x="7.5" y="17.3" width="3.8" height="5.1" rx="1.9"/>
        <rect x="16.1" y="17.3" width="3.8" height="5.1" rx="1.9"/>
        ${girl ? '<path class="ta-robot-lashes" d="m7.9 18.5-1.1-1.2m12.7 1.2 1.1-1.2"/>' : ""}
        <g class="ta-buddy-shine"><circle cx="8.6" cy="18.5" r=".65"/>
          <circle cx="17.2" cy="18.5" r=".65"/></g>
      </g></g>
      <g class="ta-buddy-blush"><ellipse cx="6.9" cy="23.7" rx="1.6" ry=".9"/>
        <ellipse cx="20.2" cy="23.7" rx="1.6" ry=".9"/></g>
      <path class="ta-buddy-smile" d="M11.8 24.7q1.8 2.2 3.6 0"/>
    </g>`;
  }
  /** Return the shared fixed SVG bow accessory for robot characters. */
  function robotBowSvg() {
    return `<g class="ta-robot-accessory">
      <path d="M0 0c-5-4-5-3-4.5 0C-5 3-5 4 0 0c5-4 5-3 4.5 0C5 3 5 4 0 0Z"/>
      <rect x="-1" y="-1.2" width="2" height="2.4" rx=".7"/>
    </g>`;
  }
  /** Return decorative thought particles shared by robot animations. */
  function robotThoughtsSvg() {
    return `<g class="ta-buddy-thoughts">
      <rect class="ta-buddy-thought" x="25.4" y="6.1" width="1.5" height="1.5" rx=".45"/>
      <rect class="ta-buddy-thought" style="--ta-delay:.3s" x="28" y="3.9" width="2" height="2" rx=".6"/>
      <path class="ta-buddy-thought ta-buddy-spark" style="--ta-delay:.6s" d="M30.8 0v3.2M29.2 1.6h3.2"/>
    </g>`;
  }
  /** Build fixed cube-robot geometry with optional accessories and assembly motion. */
  function cubeRobotSvg({character = "", tiles = ["#e4efff", "#d8eafb", "#e8e5ff"],
    accessory = "", girl = false, assemble = false} = {}) {
    const blocks = [];
    // An almost front-on 3 × 3 × 3 cube, with exposed cubies painted back to front.
    for (let depth = 2; depth >= 0; depth--) for (let row = 0; row < 3; row++) {
      for (let column = 0; column < 3; column++) {
        if (depth && row && column !== 2) continue;
        const left = 3.6 + column * 6.4 + depth * 2.3;
        const top = 11 + row * 6.4 - depth * 1.55;
        const motion = assemble ? " ta-robot-assemble" : depth > 0 && row === 0 ? " ta-buddy-lift" : "";
        blocks.push(`<g transform="translate(${left} ${top})"><g class="ta-buddy-block${motion}"
          style="--ta-delay:${(column + depth) * .12}s;--ta-x:${(column - 1) * 1.1 + depth * .3}px;--ta-y:${(row - 1) * 1.1 - depth * .3}px">
          ${row === 0 ? '<path class="ta-buddy-top" d="M.14-.08 2.38-1.41H8.48L6.26-.08Z"/>' : ""}
          ${column === 2 ? '<path class="ta-buddy-side" d="m6.54 .14 2.02-1.41v6.06L6.54 6.26Z"/>' : ""}
          ${depth === 0 ? `<rect class="ta-buddy-front" x=".14" y=".14" width="6.12" height="6.12"
            rx=".65" style="--ta-buddy-tile:${tiles[(column + row) % tiles.length]}"/>` : ""}
        </g></g>`);
      }
    }
    return `<g class="${character}"><g class="ta-buddy-head">
      ${blocks.join("")}
      <path class="ta-buddy-antenna" d="M16.2 7.2V4.8"/>
      <g class="ta-buddy-beacon">
        <path class="ta-buddy-top" d="m14.7 3.1 1.1-.7h3l-1.1.7Z"/>
        <path class="ta-buddy-side" d="m17.7 3.1 1.1-.7v2.5l-1.1.7Z"/>
        <rect class="ta-buddy-light" x="14.7" y="3.1" width="3" height="2.5" rx=".65"/>
      </g>
      ${robotFaceSvg(girl)}${accessory}
    </g>${robotThoughtsSvg()}</g>`;
  }
  /** Build a rounded robot character with optional bow or sprout details. */
  function roundRobotSvg({girl = false, sprout = false} = {}) {
    return `<g class="${sprout ? "ta-robot-sprout" : girl ? "ta-robot-mimi" : "ta-robot-milo"}">
      <g class="ta-robot-bob">
        ${sprout ? `<g class="ta-robot-shell">
          <rect class="ta-robot-ear" x="10.8" y="29.8" width="4.4" height="2.8" rx="1.2"/>
          <rect class="ta-robot-ear" x="18.8" y="29.8" width="4.4" height="2.8" rx="1.2"/>
          <rect x="11" y="22" width="12" height="8.8" rx="3"/>
          <rect x="7.7" y="23.4" width="3.3" height="5.2" rx="1.6"/>
          <g class="ta-robot-wave"><rect x="23.2" y="20.8" width="3.5" height="6.5" rx="1.7"/></g>
          <path class="ta-robot-heart" d="M17 28.7c-6-3.1-2.8-6.1 0-3.5 2.8-2.6 6 .4 0 3.5Z"/>
        </g>` : ""}
        <g transform="${sprout ? "translate(2 -2) scale(.88)" : "translate(0 0)"}">
          <g class="ta-robot-head">
            <g class="ta-robot-shell">
              <rect class="ta-robot-ear" x="1.5" y="16.3" width="4.5" height="7" rx="2"/>
              <rect class="ta-robot-ear" x="28" y="16.3" width="4.5" height="7" rx="2"/>
              <path class="ta-robot-stem" d="M17 10V5.5"/>
              ${sprout ? `<g class="ta-robot-leaves"><path d="M17 7C9 7 9 2 9 2s8-1 8 5Z"/>
                <path d="M17 6c0-6 7-6 7-6s1 6-7 6Z"/></g>`
                : '<circle class="ta-robot-light" cx="17" cy="4" r="2.1"/>'}
              <rect x="4.5" y="9.5" width="25" height="20" rx="7.5"/>
              <rect class="ta-robot-screen" x="7" y="13.1" width="20" height="13" rx="5"/>
            </g>
            <g transform="translate(3.3 -1.3)">${robotFaceSvg(girl)}</g>
            ${girl ? `<g transform="translate(24.7 10)"><g class="ta-robot-bow">${robotBowSvg()}</g></g>
              <path class="ta-robot-heart" d="M17 29c-3.8-1.8-1.7-3.6 0-2 1.7-1.6 3.8.2 0 2Z"/>`
              : sprout ? "" : `<g transform="translate(17 28.1) scale(.75)">${robotBowSvg()}</g>`}
          </g>
        </g>
      </g>${robotThoughtsSvg()}
    </g>`;
  }
  const byId = new Map(variants.map(variant => [variant.id, variant]));
  const defaultId = "rubiks-cube-monochrome";
  const bootPreference = document.documentElement.dataset.thinkingAnimation
    || window.__SMTO_MOBILE_BOOT__?.ui_thinking_animation;
  let selected = byId.has(bootPreference) ? bootPreference : defaultId;

  // Observe mounted cubes only; detached history and offscreen indicators do no work.
  const rubikMotions = new Map(), rubikStates = new WeakMap(), rubikObserved = new Set();
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  let rubikFrame = 0, rubikTime = 0;
  const rubikVisibility = new IntersectionObserver(entries => {
    for (const {target, isIntersecting} of entries) {
      const advance = rubikStates.get(target);
      if (isIntersecting && rubikObserved.has(target) && advance) rubikMotions.set(target, advance);
      else rubikMotions.delete(target);
    }
    if (!rubikMotions.size) pauseRubiks();
    else scheduleRubiks();
  });
  function watchRubiks(icon) {
    if (icon.classList.contains("header-thinking-animation")
        || !icon.isConnected || !rubikStates.has(icon) || rubikObserved.has(icon)) return;
    rubikObserved.add(icon);
    rubikVisibility.observe(icon);
  }
  function unwatchRubiks(icon) {
    rubikVisibility.unobserve(icon);
    rubikObserved.delete(icon);
    rubikMotions.delete(icon);
    if (!rubikMotions.size) pauseRubiks();
  }
  new MutationObserver(records => {
    let removed = false;
    for (const record of records) {
      if (record.target.closest?.(".ta-rubiks")) continue; // Ignore our own frame geometry.
      removed ||= record.removedNodes.length > 0;
      for (const node of record.addedNodes) {
        if (node.nodeType !== 1 || node.namespaceURI !== "http://www.w3.org/1999/xhtml") continue;
        if (node.matches(".thinking-animation")) watchRubiks(node);
        node.querySelectorAll(".thinking-animation").forEach(watchRubiks);
      }
    }
    if (removed) for (const icon of rubikObserved) if (!icon.isConnected) unwatchRubiks(icon);
  }).observe(document.documentElement, {childList: true, subtree: true});
  function scheduleRubiks() {
    if (!rubikFrame && rubikMotions.size && !document.hidden && !reducedMotion.matches) {
      rubikFrame = requestAnimationFrame(tickRubiks);
    }
  }
  function pauseRubiks() {
    cancelAnimationFrame(rubikFrame);
    rubikFrame = rubikTime = 0;
  }
  function tickRubiks(now) {
    rubikFrame = 0;
    const delta = rubikTime ? Math.min(now - rubikTime, 50) : 0;
    rubikTime = now;
    for (const [icon, advance] of rubikMotions) {
      if (!icon.isConnected || !rubikStates.has(icon)
          || icon.classList.contains("header-thinking-animation")
          || !icon.getClientRects().length) rubikMotions.delete(icon);
      else advance(delta);
    }
    if (!rubikMotions.size) rubikTime = 0;
    scheduleRubiks();
  }
  function rotateCube(point, axis, angle, exact = false) {
    const result = [...point], a = (axis + 1) % 3, b = (axis + 2) % 3;
    const cosine = exact ? 0 : Math.cos(angle);
    const sine = exact ? Math.sign(angle) : Math.sin(angle);
    result[a] = point[a] * cosine - point[b] * sine;
    result[b] = point[a] * sine + point[b] * cosine;
    return result;
  }
  function animateRubiks(icon) {
    const drawing = icon.querySelector(".ta-rubiks"), cubies = [];
    // Colorful pastels and lavender-gray seams give the cube a soft, illustrated feel.
    const colors = [["#f6a05f", "#f27e96"], ["#fff1dc", "#f8cf52"], ["#70c998", "#73a9ed"]]
      .map((pair, axis) => pair.map((color, side) => `var(--ta-rubik-face-${axis * 2 + side}, ${color})`));
    for (let x = -1; x <= 1; x++) for (let y = -1; y <= 1; y++) for (let z = -1; z <= 1; z++) {
      if (!x && !y && !z) continue;
      const position = [x, y, z], faces = [];
      for (let axis = 0; axis < 3; axis++) for (const side of [-1, 1]) {
        const normal = [0, 0, 0]; normal[axis] = side;
        const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([a, b]) => {
          const point = [...position];
          point[axis] += side * .48;
          point[(axis + 1) % 3] += a * .48;
          point[(axis + 2) % 3] += b * .48;
          return point;
        });
        faces.push({normal, corners, color: position[axis] === side
          ? colors[axis][(side + 1) / 2] : "var(--ta-rubik-core, #78758a)"});
      }
      cubies.push({position, faces});
    }
    const camera = point => rotateCube(rotateCube(point, 1, -.58), 0, .48);
    let moves = [], elapsed = 0, rest = 700;
    function scramble() {
      const sequence = [];
      let previousAxis = Math.floor(Math.random() * 3);
      for (let i = 0, count = 4 + Math.floor(Math.random() * 4); i < count; i++) {
        const axis = (previousAxis + 1 + Math.floor(Math.random() * 2)) % 3;
        sequence.push({axis, layer: Math.random() < .5 ? -1 : 1, direction: Math.random() < .5 ? -1 : 1});
        previousAxis = axis;
      }
      // Inverting real quarter turns guarantees a solved cube, with new moves each cycle.
      moves = sequence.map(move => ({...move, phase: "scrambling", duration: 380 + Math.random() * 160}));
      moves.push(...sequence.reverse().map(move => ({...move, direction: -move.direction,
        phase: "solving", duration: 320 + Math.random() * 140})));
    }
    function render(move = null, angle = 0) {
      const surfaces = [];
      for (const cubie of cubies) {
        const turning = move && cubie.position[move.axis] === move.layer;
        const transform = point => camera(turning ? rotateCube(point, move.axis, angle) : point);
        for (const face of cubie.faces) {
          if (transform(face.normal)[2] <= .015) continue;
          const points = face.corners.map(transform);
          surfaces.push({depth: points.reduce((sum, point) => sum + point[2], 0),
            path: points.map(([x, y], i) => `${i ? "L" : "M"}${(x * 6.3).toFixed(2)} ${(-y * 6.3).toFixed(2)}`).join("") + "Z",
            color: face.color});
        }
      }
      surfaces.sort((a, b) => a.depth - b.depth);
      // Geometry and colors are local constants; no user content enters this SVG.
      drawing.innerHTML = surfaces.map(face => `<path d="${face.path}" fill="${face.color}"/>`).join("");
    }
    function advance(delta) {
      if (rest > 0) { rest -= delta; return; }
      if (!moves.length) scramble();
      const move = moves[0];
      elapsed = Math.min(elapsed + delta, move.duration);
      const progress = elapsed / move.duration;
      const eased = progress * progress * (3 - 2 * progress);
      drawing.dataset.phase = move.phase;
      render(move, eased * move.direction * Math.PI / 2);
      if (progress < 1) return;
      for (const cubie of cubies) {
        if (cubie.position[move.axis] !== move.layer) continue;
        const turn = point => rotateCube(point, move.axis, move.direction, true);
        cubie.position = turn(cubie.position);
        for (const face of cubie.faces) {
          face.normal = turn(face.normal);
          face.corners = face.corners.map(turn);
        }
      }
      moves.shift(); elapsed = 0; rest = moves.length ? 90 : 950;
      if (!moves.length) drawing.dataset.phase = "solved";
      render();
    }
    render();
    rubikStates.set(icon, advance);
    watchRubiks(icon);
  }

  function animateCuboid(icon) {
    icon.querySelectorAll(".thinking-voxel").forEach((voxel, index) => {
      const {left, top} = cuboidOrigins[index];
      const tumble = () => {
        const angle = Math.random() * Math.PI * 2, radius = 7 + Math.random() * 3;
        const direction = Math.random() < 0.5 ? -1 : 1;
        voxel.style.setProperty("--voxel-x", `${(Math.cos(angle) * radius - left).toFixed(2)}px`);
        voxel.style.setProperty("--voxel-y", `${(Math.sin(angle) * radius - top - 0.5).toFixed(2)}px`);
        voxel.style.setProperty("--voxel-twist", `${(direction * (100 + Math.random() * 140)).toFixed(2)}deg`);
        voxel.style.setProperty("--voxel-return-x", `${(Math.random() * 3 - 1.5).toFixed(2)}px`);
        voxel.style.setProperty("--voxel-lift", `${(-3 - Math.random() * 2.5).toFixed(2)}px`);
        voxel.style.setProperty("--voxel-tilt", `${(direction * (8 + Math.random() * 10)).toFixed(2)}deg`);
      };
      tumble();
      voxel.addEventListener("animationiteration", event => {
        if (event.animationName === "thinking-cuboid-rebuild") tumble();
      });
    });
  }
  function update(icon) {
    const variant = byId.get(selected);
    if (icon.dataset.thinkingAnimation === variant.id) return;
    unwatchRubiks(icon);
    rubikStates.delete(icon);
    icon.dataset.thinkingAnimation = variant.id;
    icon.title = variant.label;
    // Only the fixed, UI-owned SVG catalogue above is rendered as markup.
    icon.innerHTML = `<svg viewBox="${variant.viewBox || "0 0 34 34"}" aria-hidden="true" focusable="false">${variant.svg}</svg>`;
    variant.setup?.(icon);
  }
  function create() {
    const icon = document.createElement("span");
    icon.className = "thinking-animation";
    icon.setAttribute("aria-hidden", "true");
    update(icon);
    return icon;
  }
  function activate() {
    document.querySelectorAll(".thinking-animation").forEach(icon => update(icon));
  }
  function setPreference(id) {
    const next = byId.has(id) ? id : defaultId;
    document.documentElement.dataset.thinkingAnimation = next;
    if (selected === next) return;
    selected = next;
    activate();
  }

  const style = document.createElement("style");
  style.id = "thinking-animation-styles";
  style.textContent = `
    .thinking-animation { display:none; flex:0 0 22px; width:22px; height:22px;
      color:var(--trace-text, var(--text-secondary, var(--muted, currentColor))); }
    .task-activity-status[data-thinking="true"] > .thinking-animation,
    .run-activity[data-kind="thinking"] .thinking-animation,
    .thinking-animation.thinking-animation-preview,
    .thinking-animation.header-thinking-animation { display:inline-flex; vertical-align:middle; }
    .header-thinking-animation { opacity:1; filter:grayscale(0);
      transition:opacity 180ms ease, filter 180ms ease; }
    /* Keep a faint silhouette in the header while the active indicator is in the conversation. */
    body:has(.task-activity-status[data-thinking="true"]:not([hidden]),
      .run-activity[data-kind="thinking"]:not([hidden])) .header-thinking-animation {
      opacity:.3; filter:grayscale(1); pointer-events:none; }
    .thinking-animation > svg { width:100%; height:100%; fill:none; stroke:currentColor;
      stroke-width:1.65; stroke-linecap:round; stroke-linejoin:round; overflow:visible; }
    .thinking-animation .ta-tint { fill:color-mix(in srgb, currentColor 12%, transparent); }
    .thinking-animation .ta-solid { fill:currentColor; stroke:none; }
    .thinking-animation .ta-muted { opacity:.45; }
    .thinking-animation .ta-rubiks path { stroke:var(--ta-rubik-core, #78758a); stroke-width:.55; stroke-linejoin:round; }
    .thinking-animation[data-thinking-animation="rubiks-cube-monochrome"] {
      color:var(--text, currentColor);
      --ta-rubik-core:var(--bg, var(--surface, #fff));
      --ta-rubik-face-0:color-mix(in srgb, currentColor 30%, var(--ta-rubik-core));
      --ta-rubik-face-1:color-mix(in srgb, currentColor 75%, var(--ta-rubik-core));
      --ta-rubik-face-2:color-mix(in srgb, currentColor 60%, var(--ta-rubik-core));
      --ta-rubik-face-3:currentColor;
      --ta-rubik-face-4:color-mix(in srgb, currentColor 90%, var(--ta-rubik-core));
      --ta-rubik-face-5:color-mix(in srgb, currentColor 45%, var(--ta-rubik-core));
    }
    .thinking-animation :is(.ta-float,.ta-blink,.ta-glance,.ta-pulse,.ta-breathe,.ta-piece,.ta-tilt,.ta-voxel) {
      transform-box:fill-box; transform-origin:center; }
    .thinking-animation .ta-float { animation:of-thinking-float 3.2s ease-in-out infinite; }
    .thinking-animation .ta-blink { animation:of-thinking-blink 3.8s ease-in-out infinite; }
    .thinking-animation .ta-glance { animation:of-thinking-glance 4s ease-in-out infinite; }
    .thinking-animation .ta-pulse { animation:of-thinking-pulse 2s ease-in-out infinite; }
    .thinking-animation .ta-breathe { animation:of-thinking-breathe 2.8s ease-in-out infinite; }
    .thinking-animation .ta-signal { animation:of-thinking-signal 2.4s ease-in-out var(--ta-delay,0s) infinite; }
    .thinking-animation .ta-flow { stroke-dasharray:4 3; animation:of-thinking-flow 2.4s linear infinite; }
    .thinking-animation .ta-orbit { transform-origin:17px 17px; animation:of-thinking-orbit 4s linear infinite; }
    .thinking-animation .ta-reverse { animation-direction:reverse; animation-duration:5.5s; }
    .thinking-animation .ta-piece { animation:of-thinking-piece 3.6s ease-in-out var(--ta-delay,0s) infinite; }
    .thinking-animation .ta-tilt { animation:of-thinking-tilt 3.8s ease-in-out infinite; }
    .thinking-animation .ta-scan { animation:of-thinking-scan 2.2s ease-in-out infinite; }
    .thinking-animation .ta-voxel { animation:of-thinking-rebuild 3.2s ease-in-out var(--ta-delay,0s) infinite; }
    .thinking-animation .ta-voxel path { stroke:var(--bg,var(--surface,#fff)); stroke-width:.6; }
    .thinking-animation .ta-voxel-top { fill:currentColor; }
    .thinking-animation .ta-voxel-left { fill:color-mix(in srgb,currentColor 50%,var(--bg,#fff)); }
    .thinking-animation .ta-voxel-right { fill:color-mix(in srgb,currentColor 78%,var(--bg,#fff)); }
    .thinking-animation .ta-buddy-head { transform-origin:17px 18px;
      animation:of-thinking-buddy-ponder var(--ta-robot-duration,6s) ease-in-out infinite; }
    .thinking-animation :is(.ta-buddy-block,.ta-buddy-beacon) { stroke:var(--ta-robot-outline,#7c88b2); stroke-width:.38; }
    .thinking-animation .ta-buddy-front { fill:var(--ta-buddy-tile); }
    .thinking-animation .ta-buddy-top { fill:var(--ta-robot-top,#f2f6ff); }
    .thinking-animation .ta-buddy-side { fill:var(--ta-robot-side,#b9c5eb); }
    .thinking-animation .ta-buddy-lift { animation:of-thinking-buddy-lift var(--ta-robot-duration,6s) ease-in-out var(--ta-delay) infinite; }
    .thinking-animation .ta-buddy-antenna { stroke:var(--ta-robot-outline,#7c88b2); stroke-width:1.1; }
    .thinking-animation .ta-buddy-light { fill:var(--ta-robot-accent,#a3e4d4); }
    .thinking-animation .ta-buddy-face { fill:#36446a; stroke:none; }
    .thinking-animation .ta-buddy-look { animation:of-thinking-buddy-look var(--ta-robot-duration,6s) ease-in-out infinite; }
    .thinking-animation .ta-buddy-eyes { transform-box:fill-box; transform-origin:center;
      animation:of-thinking-buddy-blink var(--ta-robot-duration,6s) ease-in-out infinite; }
    .thinking-animation .ta-buddy-shine { fill:#fff; }
    .thinking-animation .ta-buddy-blush { fill:#f3a5bb; }
    .thinking-animation .ta-buddy-smile { fill:none; stroke:#36446a; stroke-width:1.15; }
    .thinking-animation .ta-buddy-thought { fill:#c2b9ed; stroke:#8d81ba; stroke-width:.4; opacity:.65;
      animation:of-thinking-buddy-thought var(--ta-robot-duration,6s) ease-in-out var(--ta-delay,0s) infinite; }
    .thinking-animation .ta-buddy-spark { fill:none; stroke:#a99bd9; stroke-width:1.1; }
    .thinking-animation .ta-robot-milo { --ta-robot-shell:#d7eeeb; --ta-robot-ear:#b0d9d6;
      --ta-robot-outline:#6f979b; --ta-robot-accent:#f4bc85; --ta-robot-duration:5.6s; }
    .thinking-animation .ta-robot-mimi { --ta-robot-shell:#e9e0fa; --ta-robot-ear:#cec0eb;
      --ta-robot-outline:#9583b1; --ta-robot-accent:#efabc9; --ta-robot-duration:6.6s; }
    .thinking-animation .ta-robot-cubie { --ta-robot-top:#eefbf7; --ta-robot-side:#b1cbdc;
      --ta-robot-outline:#728aab; --ta-robot-accent:#f8c77b; --ta-robot-duration:5.6s; }
    .thinking-animation .ta-robot-coco { --ta-robot-top:#fff3f7; --ta-robot-side:#ddbeda;
      --ta-robot-outline:#a88caf; --ta-robot-accent:#f0aac9; --ta-robot-duration:6.6s; }
    .thinking-animation .ta-robot-sprout { --ta-robot-shell:#e4f0ce; --ta-robot-ear:#bfd99e;
      --ta-robot-outline:#829569; --ta-robot-accent:#8fbc80; --ta-robot-duration:7s; }
    .thinking-animation .ta-robot-patchwork { --ta-robot-top:#fff6df; --ta-robot-side:#c9c9e8;
      --ta-robot-outline:#9694ae; --ta-robot-accent:#e7b3d2; --ta-robot-duration:7s; }
    .thinking-animation .ta-robot-shell { fill:var(--ta-robot-shell); stroke:var(--ta-robot-outline); stroke-width:.65; }
    .thinking-animation .ta-robot-ear { fill:var(--ta-robot-ear); }
    .thinking-animation .ta-robot-screen { fill:#f6faff; stroke-width:.4; }
    .thinking-animation .ta-robot-stem { fill:none; stroke-width:1.1; }
    .thinking-animation :is(.ta-robot-light,.ta-robot-accessory) { fill:var(--ta-robot-accent);
      stroke:var(--ta-robot-outline); stroke-width:.5; }
    .thinking-animation .ta-robot-heart { fill:var(--ta-robot-accent); stroke:none; }
    .thinking-animation .ta-robot-lashes { fill:none; stroke:#36446a; stroke-width:.8; }
    .thinking-animation .ta-robot-head { transform-origin:17px 20px;
      animation:of-thinking-buddy-ponder var(--ta-robot-duration) ease-in-out infinite; }
    .thinking-animation .ta-robot-bob { animation:of-thinking-robot-bob 3s ease-in-out infinite; }
    .thinking-animation .ta-robot-bow { animation:of-thinking-robot-bow 3.3s ease-in-out infinite; }
    .thinking-animation .ta-robot-leaves { fill:var(--ta-robot-accent); transform-origin:17px 7px;
      animation:of-thinking-robot-leaves 3.5s ease-in-out infinite; }
    .thinking-animation .ta-robot-wave { transform-origin:24.7px 25.8px;
      animation:of-thinking-robot-wave 7s ease-in-out infinite; }
    .thinking-animation .ta-robot-assemble { transform-box:fill-box; transform-origin:center;
      animation:of-thinking-robot-assemble var(--ta-robot-duration) ease-in-out var(--ta-delay) infinite; }
    .thinking-animation .thinking-voxel { transform-box:fill-box; transform-origin:center;
      animation:thinking-cuboid-rebuild 2.8s ease-in-out var(--voxel-delay) infinite; }
    .thinking-animation .thinking-voxel path { stroke:var(--bg,var(--surface,#fff)); stroke-width:.6; }
    .thinking-animation .voxel-top { fill:currentColor; }
    .thinking-animation .voxel-left { fill:color-mix(in srgb,currentColor 55%,var(--bg,#fff)); }
    .thinking-animation .voxel-right { fill:color-mix(in srgb,currentColor 80%,var(--bg,#fff)); }
    @keyframes thinking-cuboid-rebuild {
      0%,12%,88%,100% { transform:translate(0,0) rotate(0deg) scale(1); }
      40% { transform:translate(var(--voxel-x),var(--voxel-y)) rotate(var(--voxel-twist)) scale(.84); }
      62% { transform:translate(var(--voxel-return-x),var(--voxel-lift)) rotate(var(--voxel-tilt)) scale(.94);
        animation-timing-function:cubic-bezier(.45,0,.8,.65); }
      78% { transform:translate(0,1px) rotate(0deg) scale(1.04,.94); }
    }
    @keyframes of-thinking-float { 0%,100% { transform:translateY(1px) rotate(-3deg); }
      50% { transform:translateY(-1px) rotate(3deg); } }
    @keyframes of-thinking-blink { 0%,40%,46%,100% { transform:scaleY(1); } 43% { transform:scaleY(.12); } }
    @keyframes of-thinking-glance { 0%,20%,100% { transform:translateX(0); }
      35%,48% { transform:translateX(-2px); } 65%,78% { transform:translateX(2px); } }
    @keyframes of-thinking-pulse { 0%,100% { transform:scale(.88); opacity:.65; } 50% { transform:scale(1.08); opacity:1; } }
    @keyframes of-thinking-breathe { 0%,100% { transform:scale(.94); } 50% { transform:scale(1.03); } }
    @keyframes of-thinking-signal { 0%,100% { opacity:.3; } 35%,60% { opacity:1; } }
    @keyframes of-thinking-flow { to { stroke-dashoffset:-28; } }
    @keyframes of-thinking-orbit { to { transform:rotate(360deg); } }
    @keyframes of-thinking-piece { 0%,15%,85%,100% { transform:translate(0,0); }
      45%,55% { transform:translate(var(--ta-x),var(--ta-y)); } }
    @keyframes of-thinking-tilt { 0%,100% { transform:rotate(-6deg); } 50% { transform:rotate(6deg); } }
    @keyframes of-thinking-scan { 0%,100% { transform:translateY(-4px); opacity:.4; }
      50% { transform:translateY(4px); opacity:1; } }
    @keyframes of-thinking-rebuild { 0%,15%,85%,100% { transform:translate(0,0) scale(1); }
      45%,55% { transform:translate(var(--ta-x),var(--ta-y)) scale(.8); } }
    @keyframes of-thinking-buddy-ponder {
      0%,100% { transform:translateY(.3px) rotate(-2deg); }
      30%,45% { transform:translateY(-.7px) rotate(5deg); }
      72% { transform:translateY(-.2px) rotate(-3deg); }
    }
    @keyframes of-thinking-buddy-look { 0%,20%,60%,100% { transform:translate(0,0); }
      30%,46% { transform:translate(1px,-.8px); } }
    @keyframes of-thinking-buddy-blink { 0%,14%,18%,60%,64%,68%,100% { transform:scaleY(1); }
      16%,62%,66% { transform:scaleY(.08); } }
    @keyframes of-thinking-buddy-lift { 0%,22%,55%,100% { transform:translateY(0); }
      32%,42% { transform:translateY(-.65px); } }
    @keyframes of-thinking-buddy-thought { 0%,18%,70%,100% { opacity:0; transform:translateY(1px); }
      30%,48% { opacity:1; transform:translateY(0); }
      60% { opacity:0; transform:translateY(-1px); } }
    @keyframes of-thinking-robot-bob { 0%,100% { transform:translateY(.2px); }
      50% { transform:translateY(-.5px); } }
    @keyframes of-thinking-robot-bow { 0%,100% { transform:rotate(-5deg); } 50% { transform:rotate(5deg); } }
    @keyframes of-thinking-robot-leaves { 0%,100% { transform:rotate(-8deg); } 50% { transform:rotate(10deg); } }
    @keyframes of-thinking-robot-wave { 0%,20%,65%,100% { transform:rotate(0deg); }
      30%,50% { transform:rotate(25deg); } 40% { transform:rotate(-15deg); } }
    @keyframes of-thinking-robot-assemble { 0%,15%,70%,100% { transform:translate(0,0) scale(1); }
      35%,45% { transform:translate(var(--ta-x),var(--ta-y)) scale(.96); }
      58% { transform:translate(0,.2px) scale(1); } }
    html[data-thinking-paused="true"] .thinking-animation * { animation-play-state:paused !important; }
    .header-thinking-animation * { animation:none !important; }
    @media (prefers-reduced-motion:reduce) {
      .thinking-animation * { animation:none !important; }
      .header-thinking-animation { transition:none; }
    }
  `;
  document.head.append(style);
  const visibility = () => {
    document.documentElement.dataset.thinkingPaused = String(document.hidden);
    if (document.hidden) pauseRubiks();
    else scheduleRubiks();
  };
  document.addEventListener("visibilitychange", visibility);
  reducedMotion.addEventListener("change", () => {
    if (reducedMotion.matches) pauseRubiks();
    else scheduleRubiks();
  });
  visibility();
  setPreference(selected);
  activate();
  window.SMTOThinkingAnimations = Object.freeze({create, update, activate, setPreference,
    variants: Object.freeze(variants.map(({id, label}) => Object.freeze({id, label})))});
})();
