/* Chat-only presentation. Existing turn nodes and controllers retain all authority. */
(() => {
  "use strict";
  let current, composerProblem = "", queue = null;
  const proseSelector = ".prose-activity:not(.monitoring-activity):not([data-fallback-prose])";
  const proseBlock = ":is(.narration, .agent-progress-narration)";
  const labels = {pending: "Working…", running: "Working…", resuming: "Working…", queued: "Queued",
    waiting_job: "Working…", waiting_event: "Waiting…", waiting_resource: "Waiting…", paused: "Paused", paused_budget: "Paused · budget reached",
    waiting_user: "Your reply is needed", awaiting_clarification: "Your reply is needed",
    awaiting_confirmation: "Approval needed", waiting_approval: "Approval needed", waiting_user_confirmation: "Approval needed",
    awaiting_resource_reconciliation: "A recovery decision is needed", blocked: "This response is blocked",
    failed: "This response failed", cancelled: "Stopped", interrupted: "Interrupted", partial: "Response paused",
    completed: "Completed", answered: "Completed"};
  function create({content, viewport, toggle, getTurn, conversationId, exit, changed}) {
    let enabled = false, frame = 0, revision = 0;
    const records = new Map();
    const accessibleLabels = new Map();
    const copyEntries = new Map();
    const copySelector = `.user-message, .assistant-answer, .answer, .conversation-message-body, .clarification-question, ${proseSelector} > ${proseBlock}`;
    const copyFeedback = document.createElement("span"); copyFeedback.className = "sr-only";
    copyFeedback.setAttribute("role", "status"); document.body.append(copyFeedback);
    const theme = document.createElement("button"); theme.type = "button";
    theme.className = "immersive-theme-toggle";
    theme.setAttribute("role", "switch"); theme.setAttribute("aria-label", "Night theme");
    const systemTheme = matchMedia("(prefers-color-scheme: dark)");
    const isDark = () => document.documentElement.dataset.theme === "dark"
      || (!document.documentElement.dataset.theme && systemTheme.matches);
    function renderTheme() {
      const dark = isDark();
      theme.setAttribute("aria-checked", String(dark));
      theme.title = dark ? "Switch to day theme" : "Switch to night theme";
      theme.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${dark
        ? '<path d="M20.5 13.5A8.5 8.5 0 0 1 10.5 3.5a8.5 8.5 0 1 0 10 10Z"/>'
        : '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>'}</svg><span>${dark ? "Night" : "Day"}</span>`;
    }
    theme.onclick = () => {
      const value = isDark() ? "light" : "dark";
      if (content.id === "messages") {
        try { localStorage.setItem("smto.agentUi.mobile.appearance", JSON.stringify(value)); } catch (_) {}
        document.documentElement.dataset.theme = value;
      } else window.SMTOAgentUi.setThemeOverride(value);
      renderTheme();
    };
    (content.id === "messages" ? document.querySelector("#mobile-app .header-actions")
      : toggle.closest(".task-display-toggles"))?.append(theme);
    new MutationObserver(renderTheme).observe(document.documentElement, {attributes: true, attributeFilter: ["data-theme"]});
    systemTheme.addEventListener("change", renderTheme);
    renderTheme();
    function clearCopyEntry(node, button) {
      button.remove(); node.classList.remove("immersive-copy-entry"); copyEntries.delete(node);
    }
    function entryText(node) {
      const source = window.SMTOMarkdown?.source(node);
      if (source !== undefined) return source;
      if (node.matches(".user-message.has-approved-plan")) return window.SMTOPlanMode.message(node);
      const text = node.cloneNode(true);
      text.querySelectorAll("button, [hidden], .sr-only").forEach(control => control.remove());
      return text.textContent;
    }
    function syncCopyEntries() {
      for (const [node, button] of copyEntries) if (!content.contains(node)) clearCopyEntry(node, button);
      for (const node of content.querySelectorAll(copySelector)) {
        if (!node.textContent.trim()) {
          if (copyEntries.has(node)) clearCopyEntry(node, copyEntries.get(node));
          continue;
        }
        let button = copyEntries.get(node);
        if (!button) {
          button = document.createElement("button"); button.type = "button";
          button.className = "immersive-copy-button";
          button.title = "Copy text"; button.setAttribute("aria-label", "Copy text");
          button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>';
          const copied = window.SMTOCopyFeedback.bind(button);
          button.onclick = async event => {
            event.preventDefault(); event.stopPropagation();
            copyFeedback.textContent = "";
            // Read at click time: streamed/re-rendered entries retain their current source.
            const text = entryText(node);
            try {
              try {
                if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
                await navigator.clipboard.writeText(text);
              } catch (_) {
                const active = document.activeElement, input = document.createElement("textarea");
                const selection = getSelection();
                const ranges = Array.from({length: selection.rangeCount}, (_, i) => selection.getRangeAt(i).cloneRange());
                input.value = text; input.style.cssText = "position:fixed;opacity:0;pointer-events:none";
                document.body.append(input); input.select();
                try { if (!document.execCommand("copy")) throw new Error("Clipboard unavailable"); }
                finally {
                  input.remove(); active?.focus({preventScroll: true});
                  selection.removeAllRanges(); ranges.forEach(range => selection.addRange(range));
                }
              }
              copied(); copyFeedback.textContent = "Text copied";
            } catch (_) { copyFeedback.textContent = "Could not copy text. Please try again."; }
          };
          copyEntries.set(node, button);
        }
        node.classList.add("immersive-copy-entry");
        if (button.parentNode !== node) node.append(button);
      }
    }
    let clockRevision = 0;
    const clockLayouts = new WeakMap(), observedWidths = new WeakMap();
    const clockSelector = ".message-time-heading, .conversation-message-heading, .prose-activity > .message-timestamp";
    function invalidateClocks() { clockRevision++; refresh(); }
    const clockResize = new ResizeObserver(entries => {
      // Streaming and composer growth change height, not the space beside clocks.
      const changed = entries.map(({target, contentRect}) => {
        const previous = observedWidths.get(target);
        observedWidths.set(target, contentRect.width);
        return previous !== contentRect.width;
      });
      if (changed.some(Boolean)) invalidateClocks();
    });
    window.addEventListener("smto:font-scale", invalidateClocks);
    document.fonts?.addEventListener("loadingdone", invalidateClocks);
    function layoutClocks() {
      const pending = [];
      for (const node of content.querySelectorAll(clockSelector)) {
        if (node.closest("[hidden]")) continue;
        const key = `${clockRevision}:${node.textContent}`;
        const previous = clockLayouts.get(node);
        if (previous?.key === key && previous.parent === node.parentElement) continue;
        pending.push({node, key});
      }
      if (!pending.length) return;
      // Measure the complete, unwrapped label in its actual margin position.
      // Batch writes and reads; unchanged clocks need no layout during streaming.
      for (const {node} of pending) node.dataset.immersiveClockMargin = "";
      const boundary = viewport.getBoundingClientRect();
      const left = Math.max(0, boundary.left + viewport.clientLeft) + 6;
      const right = Math.min(innerWidth, boundary.left + viewport.clientLeft + viewport.clientWidth) - 6;
      const measured = pending.map(item => ({...item, box: item.node.getBoundingClientRect()}));
      for (const {node, key, box} of measured) {
        if (!box.width || box.left < left || box.right > right) delete node.dataset.immersiveClockMargin;
        if (box.width) clockLayouts.set(node, {key, parent: node.parentElement});
      }
    }
    const queued = document.createElement("section"); queued.className = "immersive-queue";
    queued.setAttribute("aria-label", "Queued messages");
    let queueKey = "";
    const problem = document.createElement("div"); problem.className = "immersive-composer-problem"; problem.hidden = true;
    const explanation = document.createElement("span"); explanation.setAttribute("role", "status");
    const configure = document.createElement("button"); configure.type = "button";
    configure.textContent = "Exit Immersive to configure"; configure.onclick = exit;
    problem.append(explanation, configure);
    const composer = document.querySelector("#composer, #compose");
    const input = composer?.querySelector("#prompt-input, #message");
    let describedBy = null;
    composer?.before(problem);
    const observer = new MutationObserver(refresh);
    function observe() {
      if (enabled) observer.observe(content, {subtree: true, childList: true,
        attributes: true, attributeFilter: ["hidden", "open"]});
    }
    function restore(record) {
      for (const [group, anchor] of record.prose) restoreProse(group, anchor);
      for (const [node, anchor] of record.moved) {
        if (anchor.parentNode) anchor.replaceWith(node);
      }
      for (const [node, open] of record.disclosures) node.open = open;
      for (const button of record.history) button.textContent = button.disabled ? "Loading history…" : "Load history";
      record.attachments.remove(); record.status.remove(); record.controls.remove();
    }
    function restoreProse(group, {blockAnchor, clockAnchor}) {
      // A withdrawn block can be replaced by later prose while immersed. Restore
      // the renderer's current node, never resurrect the replaced text.
      const block = group.querySelector(`:scope > ${proseBlock}`);
      if (blockAnchor.parentNode && block) blockAnchor.replaceWith(block);
      else blockAnchor.remove();
      const clock = group.querySelector(":scope > .message-timestamp");
      if (clockAnchor?.parentNode && clock) clockAnchor.replaceWith(clock);
      else clockAnchor?.remove();
    }
    function move(record, node, target = record.controls) {
      if (!node || record.moved.has(node)) return;
      const anchor = document.createComment("immersive control"); node.before(anchor);
      record.moved.set(node, anchor); target.append(node);
    }
    function sync() {
      frame = 0;
      if (!enabled) return;
      observer.disconnect();
      for (const [selector, label] of [[".inline-steer", "Response controls"], [".activity-pages", "Earlier replies"], [".native-controls", "Attachments"]]) {
        for (const node of document.querySelectorAll(selector)) {
          if (!accessibleLabels.has(node)) accessibleLabels.set(node, node.getAttribute("aria-label"));
          node.setAttribute("aria-label", label);
        }
      }
      for (const node of accessibleLabels.keys()) if (!node.isConnected) accessibleLabels.delete(node);
      for (const [root, record] of records) if (!content.contains(root)) {
        restore(record); records.delete(root);
      }
      for (const root of content.querySelectorAll(".turn")) {
        let record = records.get(root);
        if (!record) {
          const status = document.createElement("p"); status.className = "immersive-status task-activity-status";
          status.setAttribute("role", "status"); status.setAttribute("aria-atomic", "true");
          const copy = document.createElement("span"); copy.className = "task-activity-copy";
          const statusText = document.createElement("span"); copy.append(statusText);
          const waitDetail = document.createElement("span"); waitDetail.className = "task-activity-detail";
          waitDetail.setAttribute("aria-live", "off");
          waitDetail.hidden = true; copy.append(waitDetail);
          status.append(window.SMTOThinkingAnimations.create(), copy);
          const controls = document.createElement("div"); controls.className = "immersive-controls";
          const replies = document.createElement("div"); replies.className = "immersive-replies";
          const replyActions = document.createElement("div"); replyActions.className = "immersive-reply-actions";
          replies.append(replyActions);
          root.append(status, controls);
          const attachments = document.createElement("div"); attachments.className = "immersive-message-attachments";
          (root.querySelector(".user-message-row, .user-message") || root.firstChild)?.after(attachments);
          record = {status, statusText, waitDetail, controls, replies, replyActions, attachments, attachmentKey: "", history: new Set(), moved: new Map(), disclosures: new Map(), prose: new Map()}; records.set(root, record);
        }
        // A provisional mobile turn can be hydrated in place by replacing its children.
        if (!root.contains(record.controls)) root.append(record.status, record.controls);
        if (!root.contains(record.attachments)) (root.querySelector(".user-message-row, .user-message") || root.firstChild)?.after(record.attachments);
        const presentation = getTurn(root) || {};
        const names = (Array.isArray(presentation.attachments) ? presentation.attachments : [])
          .map(item => item.filename || item.name || "Attachment");
        const attachmentKey = JSON.stringify(names);
        if (record.attachmentKey !== attachmentKey) {
          record.attachments.replaceChildren(...names.map(name => {
            const item = document.createElement("span"); item.textContent = name; return item;
          }));
          record.attachmentKey = attachmentKey;
        }
        // Keep prose on its original timeline, outside the hidden disclosure
        // summary, so Markdown links and clocks work without toggling execution details.
        for (const [group, anchor] of record.prose) if (!root.contains(group)) {
          restoreProse(group, anchor); record.prose.delete(group); record.disclosures.delete(group);
        }
        for (const group of root.querySelectorAll(proseSelector)) {
          const block = group.querySelector(`:scope > summary > ${proseBlock}`);
          if (block) {
            const blockAnchor = document.createComment("immersive prose"); block.before(blockAnchor);
            const clock = group.querySelector(":scope > summary > .message-timestamp");
            const clockAnchor = clock ? document.createComment("immersive prose clock") : null;
            if (clock) { clock.before(clockAnchor); group.append(clock); }
            record.prose.set(group, {blockAnchor, clockAnchor}); group.append(block);
          }
          if (!record.disclosures.has(group)) record.disclosures.set(group, group.open);
          group.open = true;
        }
        // Reveal conversation content while technical children remain hidden.
        for (const disclosure of root.querySelectorAll(".work-disclosure, details.activity")) {
          if (!record.disclosures.has(disclosure)) record.disclosures.set(disclosure, disclosure.open);
          if (disclosure.querySelector(`.conversation-message, ${proseSelector}`)) disclosure.open = true;
        }
        // Mobile normally stores these in a hidden message-details sheet. Move the live
        // nodes instead of copying them, so drafts, retries and request bindings survive.
        if (content.id === "messages") {
          const controls = root.querySelector(".turn-controls");
          if (controls) {
            if (!record.disclosures.has(controls)) record.disclosures.set(controls, controls.open);
            move(record, controls); controls.open = true;
          }
        }
        move(record, root.querySelector(".task-lifecycle-actions"));
        // Historical exchanges are lazy in both clients. Reuse their explicit loader;
        // entering Immersive never starts a scan of a run's entire event history.
        const history = root.querySelector(".run-history-action");
        record.replyActions.dataset.hasHistory = String(Boolean(history && presentation.hasConversationHistory));
        if (history && presentation.hasConversationHistory) {
          const notice = history.nextElementSibling;
          if (notice?.getAttribute("role") === "status") move(record, notice);
          move(record, history, record.replyActions); record.history.add(history);
          const label = history.disabled ? "Loading replies…" : "Load earlier replies";
          if (history.textContent !== label) history.textContent = label;
        }
        // Reuse the queue's live disclosure and deletion controls in both clients.
        // Moving the panel leaves its expanded state and request ownership intact.
        const queueAction = root.querySelector(".followup-queue-action");
        move(record, queueAction, record.replyActions);
        if (queueAction && record.replyActions.lastElementChild !== queueAction) record.replyActions.append(queueAction);
        move(record, root.querySelector(".followup-queue"), record.replies);
        if (record.controls.lastElementChild !== record.replies) record.controls.append(record.replies);
        const status = presentation.status;
        const hasAnswer = [...root.querySelectorAll('.assistant-answer, .answer, .conversation-message[aria-label="Agent answer"]')]
          .some(node => !node.hidden && node.textContent.trim());
        const activity = presentation.currentActivity || {
          label: labels[status] || "", detail: "",
          kind: ["pending", "running", "resuming"].includes(status) ? "thinking" : "waiting",
          iconKind: "runtime",
        };
        const text = presentation.submissionFeedback || (root.querySelector(":scope > .submission-status")
          || ["completed", "answered"].includes(status) && hasAnswer ? "" : activity.label);
        const value = {...activity, label: text, detail: text ? activity.detail : ""};
        record.waitDetail.hidden = !value.detail;
        record.status.hidden = !text && record.waitDetail.hidden;
        // Share status truth, text transitions and server-synchronized wait clocks
        // with the standard view. Clock ticks do not restart the status animation.
        window.SMTORunActivity.renderStatus(record.status, value, record.statusText);
        window.SMTORunActivity.renderDetail(record.waitDetail, value);
      }
      renderProblem();
      renderQueue();
      syncCopyEntries();
      layoutClocks();
      observe();
    }
    function renderQueue() {
      if (!enabled) { queued.remove(); queueKey = ""; return; }
      const lane = queue?.conversation_id === conversationId() ? queue : null;
      const items = lane?.queued_tasks || [];
      const key = JSON.stringify(items.map(task => [task.task_id, task.prompt, task.created_at, task.queue_block?.kind]));
      if (key !== queueKey) {
        queued.replaceChildren(...items.map(task => {
          const row = document.createElement("div"); row.dataset.taskId = task.task_id;
          const prompt = document.createElement("div"); prompt.className = "user-message"; prompt.textContent = task.prompt;
          const clock = window.SMTOMessageTimestamps?.create(task.created_at);
          if (clock) {
            const heading = document.createElement("div"); heading.className = "message-time-heading";
            const label = document.createElement("span"); label.textContent = "You";
            heading.hidden = clock.root.hidden; heading.append(label, clock.root); row.append(heading);
          }
          const status = document.createElement("p"); status.className = "immersive-status"; status.setAttribute("role", "status");
          status.textContent = task.queue_block?.kind && task.queue_block.kind !== "none" ? "Queued · waiting" : "Queued";
          row.append(prompt, status); return row;
        }));
        queueKey = key;
      }
      if (items.length && content.lastElementChild !== queued) content.append(queued);
      if (!items.length) queued.remove();
    }
    function refresh() { if (enabled && !frame) frame = requestAnimationFrame(sync); }
    function renderProblem() {
      if (explanation.textContent !== composerProblem) explanation.textContent = composerProblem;
      problem.hidden = !enabled || !composerProblem;
    }
    function setEnabled(value) {
      if (enabled === value) return;
      const generation = ++revision;
      const atBottom = viewport.scrollHeight - viewport.clientHeight - viewport.scrollTop < 48;
      const top = viewport.getBoundingClientRect().top;
      const anchor = [...content.querySelectorAll(`.user-message, .conversation-message, .assistant-answer, .answer, ${proseBlock}`)]
        .find(node => node.getClientRects().length && node.getBoundingClientRect().bottom > top);
      const offset = anchor?.getBoundingClientRect().top;
      const focused = document.activeElement;
      enabled = value;
      document.documentElement.dataset.immersive = String(enabled);
      if (input && enabled) {
        describedBy = input.getAttribute("aria-describedby");
        input.setAttribute("aria-describedby", (describedBy || "").split(/\s+/)
          .filter(id => !["composer-help", "composer-browsing-hint", "composer-profile-status"].includes(id)).join(" "));
      } else if (input) {
        if (describedBy === null) input.removeAttribute("aria-describedby");
        else input.setAttribute("aria-describedby", describedBy);
      }
      observer.disconnect(); cancelAnimationFrame(frame); frame = 0;
      clockResize.disconnect();
      if (enabled) {
        clockRevision++;
        clockResize.observe(viewport); clockResize.observe(content);
        sync();
      }
      else {
        for (const [node, button] of copyEntries) clearCopyEntry(node, button);
        copyFeedback.textContent = "";
        for (const node of content.querySelectorAll("[data-immersive-clock-margin]")) delete node.dataset.immersiveClockMargin;
        for (const record of records.values()) restore(record);
        records.clear();
        for (const [node, label] of accessibleLabels) {
          if (label === null) node.removeAttribute("aria-label"); else node.setAttribute("aria-label", label);
        }
        accessibleLabels.clear(); renderProblem(); renderQueue();
      }
      queueMicrotask(() => {
        if (generation !== revision) return;
        changed(enabled);
        void window.SMTOSelectedConversation?.invalidate({reapply: true});
        window.dispatchEvent(new CustomEvent("smto:immersive", {detail: {enabled}}));
      });
      requestAnimationFrame(() => {
        if (generation !== revision) return;
        if (atBottom) viewport.scrollTo({top: viewport.scrollHeight, behavior: "instant"});
        else if (anchor?.isConnected && anchor.getClientRects().length)
          viewport.scrollBy({top: anchor.getBoundingClientRect().top - offset, behavior: "instant"});
        if (focused && (!focused.isConnected || !focused.getClientRects().length)) toggle.focus({preventScroll: true});
        else if (focused && document.activeElement !== focused) focused.focus({preventScroll: true});
      });
    }
    current = {setEnabled, refresh, renderProblem};
    return current;
  }
  window.SMTOImmersive = {create,
    active: () => document.documentElement.dataset.immersive === "true",
    refresh: () => current?.refresh(),
    queue(lane) { queue = lane; current?.refresh(); },
    composerProblem(text) { composerProblem = text || ""; current?.renderProblem(); },
  };
})();
