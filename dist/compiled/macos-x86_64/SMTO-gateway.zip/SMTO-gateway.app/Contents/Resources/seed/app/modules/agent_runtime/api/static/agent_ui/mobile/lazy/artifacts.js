import "./advanced.js";
import "../../smto_markdown.js?v=20261020-copy-source";
import "../../artifacts.js?v=20261018-loading";
import {trackArtifactSources} from "../markdown.js?v=20261018-loading";
import {api, state} from "../api.js?v=20261018-loading";
export function attach(turn) {
  if (turn.disposed) return;
  trackArtifactSources(turn.root);
  if (!turn.artifacts) turn.artifacts = window.SMTOArtifacts.attach(turn.root, turn.id,
    turn.conversationId || state.conversationId, (url, options = {}) => api(url, options));
  window.SMTOArtifacts.hydrate(turn.root);
  turn.artifacts.update(turn.run?.artifact_summary);
  return turn.artifacts;
}
