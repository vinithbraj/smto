/* Existing scoped policy entry point, now backed by the complete guard registry. */
(() => {
  "use strict";
  function feedback(turn, trace, hooks) {
    window.SMTOAgentChecks.render(turn.actionArea, trace, {...hooks,
      actionRoot: turn.runActions || turn.meta, panelRoot: turn.agentChecksArea,
      requestId: turn.requestId, reload: rid => hooks.reload(rid, turn)});
  }
  function conversation({apiJson, conversationId, requestId = () => null, notify, composerSettings = null, onDraftChanged = () => {}}) {
    const root = document.querySelector("#completion-handling .completion-handling-panel");
    let draft = {}, mounted = null, cid, rid;
    function refresh() {
      if (!root) return;
      const next = conversationId();
      if (mounted && next === cid && requestId() === rid) return mounted.refresh();
      cid = next; rid = requestId(); root.replaceChildren();
      mounted = window.SMTOAgentChecks.panel(root, {apiJson, conversationId: cid,
        requestId: rid, draft, notify, composerSettings, onDraftChanged, initialScope: "prompt", allowPrompt: true});
    }
    refresh();
    return {refresh, requestAccepted: () => { window.SMTOAgentChecks.clearStopDraft(cid); draft = {}; mounted = null; return refresh(); },
      policyForRequest: () => ({...draft}), draftSnapshot: () => ({...draft}),
      restoreDraftState: saved => {
        draft = typeof saved === "boolean" ? {"completion.strict_final_response_structure": saved}
          : saved && typeof saved === "object" && !Array.isArray(saved) ? {...saved} : {};
        mounted = null; refresh();
      }};
  }
  window.SMTOCompletionHandling = {feedback, conversation};
})();
