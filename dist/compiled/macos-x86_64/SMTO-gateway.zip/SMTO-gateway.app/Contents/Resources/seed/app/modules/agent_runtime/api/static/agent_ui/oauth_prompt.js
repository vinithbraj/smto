/* OAuth interaction is protocol state; ordinary credentials use the composer. */
(() => {
  "use strict";
  function mount({container, onStop}) {
    container.hidden = true;
    container.classList.add("oauth-authorization-prompt");
    let identity = "";
    return {update(descriptor, {waiting = false, cancelRequested = false} = {}) {
      const next = waiting ? JSON.stringify([descriptor, cancelRequested]) : "";
      if (next === identity) return;
      identity = next;
      container.replaceChildren();
      container.hidden = !waiting;
      if (!waiting) return;
      const title = document.createElement("p");
      title.textContent = "Complete OAuth authorization to continue.";
      container.append(title);
      const url = descriptor.authorization_url || descriptor.verification_uri;
      if (url) {
        try {
          const parsed = new URL(url, window.location.href);
          if (["https:", "http:"].includes(parsed.protocol)) {
            const link = document.createElement("a");
            link.href = parsed.href; link.target = "_blank"; link.rel = "noopener noreferrer";
            link.textContent = "Open authorization page"; container.append(link);
          }
        } catch (_) { /* Invalid provider link is displayed as unavailable. */ }
      }
      if (descriptor.user_code) {
        const code = document.createElement("p"); code.textContent = `Device code: ${descriptor.user_code}`;
        container.append(code);
        const copy = document.createElement("button"); copy.type = "button";
        copy.textContent = "Copy device code";
        const copied = window.SMTOCopyFeedback.bind(copy);
        copy.onclick = async () => {
        const busyFeedback = window.SMTOBusy?.action("Copying authorization link…", copy);
        try {
          try { await navigator.clipboard.writeText(descriptor.user_code); copied(); }
          catch (_) { copy.textContent = "Select the device code to copy"; }

        } finally { busyFeedback?.finish(); }
      };
        container.append(copy);
      }
      const stop = document.createElement("button"); stop.type = "button";
      stop.textContent = cancelRequested ? "Stopping…" : "Stop"; stop.disabled = cancelRequested;
      stop.onclick = () => onStop(descriptor.request_id); container.append(stop);
    }};
  }
  window.SMTOOAuthPrompt = {mount};
})();
