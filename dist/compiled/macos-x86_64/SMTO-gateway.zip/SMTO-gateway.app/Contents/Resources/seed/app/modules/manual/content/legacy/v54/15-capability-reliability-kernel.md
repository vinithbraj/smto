---
id: historical-v54-capability-reliability-kernel
title: Historical V54 - Capability Reliability Kernel
kind: legacy
tags: [reliability, weak-models, operator, recovery, verification]
summary: How SMTO records, repairs, verifies, and reports weak-model runtime failures.
order: 15
---

> Historical reference. See the current V55 architecture guide before using this material.

# Capability Reliability Kernel

The Reliability page shows how the operator recovered from weak-model failures:
bad JSON, bad plans, wrong cwd values, command errors, Python tracebacks, failed
verification, dropped final answers, and approval-envelope violations.

Smaller-model support is one reason this kernel exists. SMTO does not
assume a smaller model will always plan like a larger model; it records the
failure mode, applies bounded recovery, preserves approval envelopes, verifies
outcomes, and turns the result into evidence that an operator can inspect.

Request fidelity is anchored by an LLM-authored immutable goal contract and an
obligation-indexed evidence ledger. The runtime verifies generic coverage and
effect integrity, while the LLM remains responsible for interpreting the
request and choosing tools. A run is eligible for learning only after the
whole-request fulfillment review accepts the evidence.

Open:

```text
/reliability
```

## What The Page Shows

| Area | Meaning |
| --- | --- |
| Summary | Total reliability events, runs, failures, recoveries, verifications, and model profiles. |
| Runtime controls | Reliability mode, verifier enforcement, probe budget, repair budget, weak-model action cap, and approval-envelope budget. |
| Models | Per-model weakness and recovery counters. |
| Failure taxonomy | Which failure classes the current model or fleet is producing most often. |
| Recent runs | Request-level recovery timelines. |
| Timeline | Failure detected, recovery chosen, plan compiled, envelope used, verifier result, and final outcome. |
| Evals | Deterministic weak-model simulation runs. |

## Runtime Modes

| Mode | Behavior |
| --- | --- |
| `aggressive` | Optional heavier profile. Compiles plans, records all events, and spends larger bounded recovery budgets. |
| `standard` | Records and verifies with more conservative recovery defaults. |
| `off` | Leaves existing operator safety in place but disables Reliability Kernel event recording and decisions. |

The Agent UI's separate validation profile controls review frequency. **Fast
guarded** skips per-action proof reviews for speed but still enforces the final
whole-request fulfillment review and permits one bounded recovery attempt.
**Relaxed** records extra review signals without blocking, while **Enforced**
checks both each action and the final outcome. These profiles do not change the
selected `auto`, `streaming`, or `full_plan` workflow shape.

## Approval Envelopes

When a mutating plan asks for confirmation, SMTO records the approved
goal, gateway, cwd values, risk ceiling, and mutation budget.

Execution repair may continue automatically only when the repaired plan stays
inside that envelope. If it changes cwd, escalates risk, or uses too much
mutation budget, the run pauses for confirmation again.

## Reports

Select a run and use:

- `JSON` for machine-readable support evidence;
- `Markdown` for a customer-facing recovery report.

Reports include the timeline, failure taxonomy, recovery choices, verification
status, and approval-envelope state.

## Evals

Use `Run` in the Evals pane to execute deterministic weak-model cases. These do
not require a live LLM. They cover malformed structured output, placeholders,
wrong cwd, command failures, Python failures, stale verification, final-answer
loss, repeated repair loops, and ambiguous stdout.

The target score for safe tasks is at least 90 percent recovered or safely
blocked.

Gmail-specific reliability should follow the same pattern: preserve account
scope, selected messages, preview evidence, Gmail API errors, and confirmation
envelope state so a failed mail action can be explained without hiding whether
anything was sent or changed.
