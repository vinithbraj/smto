/* Global Settings access to the shared capability and permission editors. */
(() => {
  "use strict";

  function mount(container, {kind, onChange = () => {}, onSave = () => {}}) {
    const permissions = kind === "permission_policy";
    const name = permissions ? "Permissions" : "Capabilities";
    const row = document.createElement("article");
    row.className = "mission-setting-row mission-policy-settings";
    row.dataset.settingSearch = permissions
      ? "permissions approval ask allow deny custom skills tools shell commands global defaults"
      : "capabilities skills tools shell executables auto always never global defaults";
    const copy = document.createElement("div"); copy.className = "mission-setting-copy";
    const heading = document.createElement(permissions ? "label" : "span"); heading.className = "mission-setting-label";
    heading.textContent = permissions ? "Default permissions" : "Skills and tools";
    const description = document.createElement("p"); description.className = "mission-setting-description";
    description.textContent = permissions
      ? "Presets save immediately. Use the editor for custom approval rules and resetting to the product default."
      : "Review the capability catalog and configure Auto, Always and Never, individual tools, and shell executable rules. Execution permissions still apply.";
    const status = document.createElement("p"); status.className = "mission-setting-description";
    status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
    status.textContent = "Loading global defaults…";
    const chips = document.createElement("div"); chips.className = "capability-chips"; chips.hidden = true;
    copy.append(heading, description, status, chips);
    const controls = document.createElement("div"); controls.className = "mission-setting-control mission-policy-actions";
    const scopeLabel = document.createElement("label"); scopeLabel.hidden = true;
    const scopeSelect = document.createElement("select");
    scopeSelect.setAttribute("aria-label", `${name} scope`);
    scopeSelect.append(new Option("Global", "global")); scopeLabel.append(scopeSelect);
    const button = document.createElement("button"); button.type = "button";
    button.id = `settings-edit-${permissions ? "permissions" : "capabilities"}`;
    button.textContent = `Edit ${name.toLowerCase()}`;
    const presetSelect = document.createElement("select");
    presetSelect.id = "settings-permission-preset";
    presetSelect.setAttribute("aria-label", "Default permissions");
    const quickButton = document.createElement("button"); quickButton.type = "button";
    quickButton.setAttribute("aria-label", "Quick capability selection");
    if (permissions) {
      for (const [value, label] of Object.entries(window.SMTOPermissionPolicy.names)) {
        presetSelect.append(new Option(label, value));
      }
      controls.append(presetSelect);
    } else controls.append(quickButton);
    if (permissions) heading.htmlFor = presetSelect.id;
    controls.append(button, scopeLabel); row.append(copy, controls); container.append(row);

    const setStatus = (message, error = false) => {
      status.textContent = message; status.dataset.state = error ? "error" : "saved";
      onChange();
    };
    const apiJson = async (url, options) => {
      const result = await window.SMTOAgentUi.apiJson(url.replace(/^\/api\/agent/, ""), options);
      if (url.includes("/effective")) setStatus("Editing global defaults for all conversations.");
      return result;
    };
    const editor = (permissions ? window.SMTOPermissionPolicy : window.SMTOCapabilityPolicy).create({
      apiJson, mode: () => "agent", globalOnly: true, button, chips, scopeSelect, presetSelect, quickButton,
      notify: message => setStatus(message, true),
      onDraftChanged: () => { setStatus(`${name} saved globally.`); onSave(); },
    });
    void editor.loadDefaults();
    return editor;
  }

  window.SMTOPolicySettings = {mount};
})();
