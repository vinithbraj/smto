/* Live global policy; controls never infer effects or own execution admission. */
(() => {
  "use strict";
  function mount(sections, nav, {setStatus, onChange = () => {}}) {
    const node = (tag, text, className) => {
      const el = document.createElement(tag);
      if (text) el.textContent = text;
      if (className) el.className = className;
      return el;
    };
    const section = node("details", "", "mission-settings-section");
    section.id = "settings-section-resource-locking";
    section.dataset.sectionSearch = "resource locking model calls endpoint capacity concurrency shell files memory kv python docker gpu local ai network web conflicts serialization";
    const summary = node("summary", "", "mission-settings-section-summary");
    summary.append(node("h2", "Resource locking")); section.append(summary);
    const body = node("div", "", "mission-section-body"); section.append(body); sections.append(section);
    const link = node("a", "Resource locking"); link.href = "#" + section.id; nav.append(link);
    const api = (options) => window.SMTOAgentUi.apiJson("/resource-locking", options);
    let catalog, generation = 0, saving = false, refreshPending = false, additionalOpen = false;
    const feedback = node("p"); feedback.setAttribute("role", "status");
    async function save(policy) {
    const busyFeedback = window.SMTOBusy?.action("Saving resource policy…");
    try {
      const focusLabel = document.activeElement?.getAttribute("aria-label");
      saving = true; ++generation;
      body.querySelectorAll("input").forEach(input => { input.disabled = true; });
      try {
        catalog = await api({method: "PUT", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({policy, expected_revision: catalog.policy.revision})});
        feedback.textContent = "Resource locking settings saved.";
        setStatus(feedback.textContent, "saved");
      } catch (error) {
        feedback.textContent = error.message;
        setStatus(error.message, "error");
        try { catalog = await api(); } catch (_) { /* Retain last acknowledged policy. */ }
      } finally {
        saving = false; render();
        if (focusLabel) body.querySelector(`[aria-label="${CSS.escape(focusLabel)}"]`)?.focus();
      }

    } finally { busyFeedback?.finish(); }
  }
    function render() {
      body.replaceChildren();
      body.append(node("p", "Control concurrent model calls and shared tool resources independently. Changes affect running and queued tasks.", "mission-section-copy"));
      const policy = catalog.policy;
      function toggle(root, label, checked, change, description = "") {
        const row = node("label", "", "mission-toggle-row resource-locking-row");
        row.dataset.settingSearch = label.toLowerCase();
        const input = node("input", "", "mission-switch"); input.type = "checkbox";
        input.setAttribute("role", "switch"); input.setAttribute("aria-label", label); input.checked = checked;
        input.onchange = () => change(input.checked); row.append(input, node("span", label));
        if (description) row.append(node("small", description));
        root.append(row);
      }
      body.append(node("h3", "Model calls"));
      toggle(body, "Limit concurrent model calls", policy.families.model !== false,
        enabled => void save({...policy, families: {...policy.families, model: enabled}}));
      const limitRow = node("label", "", "mission-field-row resource-locking-row");
      limitRow.dataset.settingSearch = "maximum concurrent calls per endpoint model capacity";
      const limitCopy = node("span", "", "mission-setting-copy");
      const limitDescription = node("small", "Calls above this limit wait for model capacity. Each endpoint has its own limit; the Parallel run limit still applies overall. Lowering the limit lets active calls finish.", "mission-setting-description");
      limitDescription.id = "resource-locking-model-limit-description";
      limitCopy.append(node("span", "Maximum concurrent calls per endpoint"), limitDescription);
      limitRow.append(limitCopy);
      const limit = node("input"); limit.type = "number"; limit.min = "1"; limit.step = "1";
      limit.setAttribute("aria-label", "Maximum concurrent calls per endpoint");
      limit.setAttribute("aria-describedby", limitDescription.id);
      limit.value = String(policy.model_call_limit ?? 1);
      limit.disabled = policy.families.model === false;
      limit.onchange = () => {
        const value = Number(limit.value);
        if (!limit.value.trim() || !Number.isInteger(value) || value < 1) {
          limit.setCustomValidity("Enter a positive whole number."); limit.reportValidity();
          feedback.textContent = "Enter a positive whole number.";
          return;
        }
        limit.setCustomValidity("");
        void save({...policy, model_call_limit: value});
      };
      limit.oninput = () => limit.setCustomValidity("");
      limitRow.append(limit); body.append(limitRow);
      body.append(node("h3", "Tool resources"));
      toggle(body, "Enable tool resource locking", policy.enabled, enabled => void save({...policy, enabled}),
        policy.enabled ? "Only selected families participate. Disabled families remain unrestricted." :
        "Tool resource locking is off. Your selections below are saved for when it is enabled.");
      const additional = node("details", "", "resource-locking-additional"); additional.append(node("summary", "Additional tool families"));
      additional.open = additionalOpen;
      additional.ontoggle = () => { if (additional.isConnected) additionalOpen = additional.open; };
      const primaryList = node("div", "", "mission-toggle-list");
      const additionalList = node("div", "", "mission-toggle-list");
      primaryList.setAttribute("role", "group"); primaryList.setAttribute("aria-label", "Primary tool families");
      additionalList.setAttribute("role", "group"); additionalList.setAttribute("aria-label", "Additional tool families");
      additional.append(additionalList);
      for (const family of catalog.families) {
        if (family.id === "model") continue;
        toggle(family.primary ? primaryList : additionalList, family.label,
          policy.families[family.id] ?? Boolean(policy.families["*"]),
          enabled => void save({...policy, families: {...policy.families, [family.id]: enabled}}));
      }
      body.append(primaryList, additional);
      const pending = (catalog.gateways || []).filter(g => g.state !== "applied");
      if (pending.length) {
        const status = node("p"); status.setAttribute("role", "status");
        status.textContent = pending.map(g => `${g.label}: ${g.state === "upgrade_required" ? "Gateway upgrade required" : "waiting to synchronize"}`).join("; ");
        body.append(status);
      }
      body.append(feedback); onChange();
    }
    async function refresh() {
      if (saving || body.contains(document.activeElement)) { refreshPending = true; return; }
      refreshPending = false;
      const revision = ++generation;
      try {
        const value = await api();
        if (revision !== generation || saving) return;
        catalog = value; render();
      } catch (error) { feedback.textContent = error.message; body.append(feedback); }
    }
    window.SMTOUiUpdates?.subscribe(["settings.changed"], () => void refresh());
    body.addEventListener("focusout", () => setTimeout(() => { if (refreshPending) void refresh(); }, 0));
    window.addEventListener("focus", () => void refresh());
    if (window.SMTOBusy) void window.SMTOBusy.run({host: body, label: "Loading resource policy…"}, refresh);
    else void refresh();
  }
  window.SMTOResourceLockingSettings = {mount};
})();
