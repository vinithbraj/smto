---
id: google-workspace
title: Shared Google Workspace identity
kind: manual
tags: [manual, auth, google, gmail, calendar, drive]
order: 27
---
# Shared Google Workspace identity

One **Google Workspace Account** in Parameter Store can authorize Gmail,
[Google Calendar](28-google-calendar.md) and [Google Drive](29-google-drive.md). Its `google_account` record owns the private access/refresh
tokens, verified Google subject and email, expiry and granted scopes. There is no
second credential database. Existing `gmail_oauth_app` and `gmail_account` records
remain supported; opening or using them never migrates them.

## Configure and connect

Enable **Authentication** in Capability Policy. In **Parameter Store → New**, choose
**Google Workspace OAuth App**, supply your own registered Google client ID, and
save the parameter as `workspace_app`. No Workspace scopes are selected by default.
Use the Value JSON editor to set `requested_features`, or name features when connecting.
Leave `requested_scopes` empty to derive them; if populated, it must exactly match
the selected feature scopes. This field cannot authorize arbitrary scope expansion.

```json
{
  "profile_type": "google_oauth_app",
  "profile_version": 1,
  "service": "google_workspace",
  "client_type": "desktop",
  "client_id": "YOUR_REGISTERED_CLIENT_ID",
  "client_secret": "",
  "authorization_uri": "https://accounts.google.com/o/oauth2/v2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "redirect_uri": "",
  "requested_features": ["calendar_read"],
  "requested_scopes": []
}
```

Desktop clients generate a temporary `127.0.0.1` loopback listener on the controller.
Do not save its random port. Supply Google's desktop client secret if your registered
client requires it. Desktop clients cannot keep that value confidential from their owner.
For a remote controller, use a registered **web** client, its client secret, and the
exact HTTPS callback `https://YOUR_CONTROLLER/api/agent/google/oauth/callback`.
HTTP callbacks are allowed only for literal loopback development addresses.

Ask to connect with `auth.google_connect`:

```json
{"auth_app_ref":"workspace_app","account_key":"workspace","features":["calendar_read"]}
```

The result contains an authorization link and the requested scope classifications.
Open it and complete Google consent within ten minutes. `auth.google_accounts` lists
safe connected identities; `auth.google_status` inspects a chosen account and optional
required features. Connection grants access only to features actually granted by Google.
A successful authorization may still lack a feature if consent was partial.

Add Drive file access later with the **same key**:

```json
{"auth_app_ref":"workspace_app","account_key":"workspace","features":["drive_file"]}
```

Web clients use Google's incremental grant option. Google does **not** support incremental
authorization for installed applications, so desktop upgrades request renewed consent
for the prior grants plus the selected new features. Both update the existing record.
The application never assumes an unreturned permission was granted. New authorization
requires a returned scope list; refresh responses may omit it and retain the prior grant.

The first connection explicitly requests consent and offline access so a refresh token
can be issued. Web upgrades retain an existing refresh token when Google omits a new one;
if none exists, consent is requested again. Desktop upgrades explicitly request consent.
No-key creation derives a stable key from the verified subject. If accounts already exist
for the app, select the intended key before reconnecting. Creating another profile for
that identity requires an explicitly different key.

## Feature permissions

Every suffix below is prefixed with `https://www.googleapis.com/auth/`.
All new connections also request `openid email` to verify the stable Google identity.
They do not request the unrelated OIDC `profile` scope.

| Feature | Requested scope suffix | Classification |
| --- | --- | --- |
| `gmail_read` | `gmail.readonly` | Restricted |
| `gmail_modify` | `gmail.modify` | Restricted |
| `gmail_send` | `gmail.send` | Sensitive |
| `calendar_list` | `calendar.calendarlist.readonly` | Check Google Cloud Console |
| `calendar_read` | `calendar.events.readonly` | Sensitive |
| `calendar_freebusy` | `calendar.freebusy` | Check Google Cloud Console |
| `calendar_write` | `calendar.events` | Sensitive |
| `drive_file` | `drive.file` | Non-sensitive |
| `drive_metadata_read` | `drive.metadata.readonly` | Restricted |
| `drive_read_all` | `drive.readonly` | Restricted |
| `drive_write_all` | `drive` | Restricted |
| `gmail_drafts` | `gmail.compose` | Restricted |
| `gmail_drafts_read` | `gmail.readonly` | Restricted |
| `gmail_labels` / `gmail_labels_read` | `gmail.labels` | Non-sensitive |
| `gmail_settings` | `gmail.settings.basic` | Restricted |
| `gmail_settings_read` | `gmail.readonly` | Restricted |

`drive_file` covers files created by or specifically shared with the application; it
is not a Drive-wide search grant. `calendar_read` covers events; listing calendar
subscriptions additionally requires `calendar_list`. `calendar_freebusy` covers the
user's availability, not event details. `calendar_write` edits events, not calendar
ACLs or calendar management. Requesting `gmail_modify` inherently permits sends and
reads under Google's scope definition; requesting `gmail_read` never adds modification.

The scope engine recognizes documented broader grants for availability without
requesting them automatically. For example, an existing `gmail.modify` grant satisfies
Gmail reads and sends, and `drive` satisfies file/read/metadata operations. A read-only
Drive grant never satisfies file writes. Calendar event editing alone does not satisfy
the separate free/busy endpoint. Gmail draft-send requires `gmail.compose` or
`gmail.modify`; `gmail.send` alone supports direct message sending.

Sensitive scopes can require Google application verification. Restricted scopes can
also require a security assessment. Google’s Calendar scope reference does not publish
per-scope sensitivity classifications for calendar listing/free-busy; results explicitly
say `console-defined` for those two scopes. Review their current sensitivity indicators
in your Google Cloud project's Data Access screen before publishing.

Scope definitions and OAuth behavior were checked against the official
[OAuth overview](https://developers.google.com/identity/protocols/oauth2),
[desktop OAuth guidance](https://developers.google.com/identity/protocols/oauth2/native-app),
[Calendar scopes](https://developers.google.com/workspace/calendar/api/auth),
[Drive scopes](https://developers.google.com/workspace/drive/api/guides/api-specific-auth),
[Gmail scopes](https://developers.google.com/workspace/gmail/api/auth/scopes), and
[sensitive-scope guidance](https://developers.google.com/identity/protocols/oauth2/production-readiness/sensitive-scope-verification)
on September 30–October 1, 2026. Google's
[scope directory](https://developers.google.com/identity/protocols/oauth2/scopes)
identifies Cloud Console as the authority for sensitivity indicators.

## Identity, privacy and Gmail reuse

Google's signed ID token establishes the subject (`sub`) and verified email. Signature,
issuer, audience, timestamps, nonce and authorized party are checked. A changed email
with the same subject is allowed; a changed subject cannot replace an existing key.
Access tokens, refresh tokens, client secrets, authorization codes, ID tokens and PKCE
verifiers are never tool results or ordinary context. ID tokens and handshakes are not
saved. Only account token bundles and app secrets persist in Parameter Store.
These privacy boundaries apply even when optional redaction switches are off.

Enable Gmail and use `@workspace` with the existing `gmail.*` tools. Search requires
Gmail read access, message/label-state mutation requires modification, and direct sending
requires send access. Compose drafts, label administration and filters have their own
narrow requirements. Reply/forward also require read access to the original message.
Missing permission produces `google.scope_upgrade_required` with the exact account and
missing features. Reconnect that account; the runtime never silently substitutes another.
A send-only account cannot reconcile an uncertain send through a Sent search; the existing
unknown-effect protection still prevents automatic resending.

Resolution uses an explicit key, then an accepted eligible account binding, then a single
configured eligible account. Multiple eligible accounts require selection. An explicitly
selected account with missing access fails on that account, even if another is available.
Accepted references pin identity while refresh resolves current Parameter Store authority.
Renaming/deleting/replacing the account invalidates its old reference.

Refresh updates the same token bundle through Parameter Store revision checks. Concurrent
requests in one controller process share a bounded lock across service and store instances.
Cross-process writes are fenced against account and app revisions; they do not provide
a distributed refresh lease. Run one controller process for a given Parameter Store.
A revoked refresh grant returns `google.reauthorization_required` and records that status.

Calendar and Drive domain adapters request a
feature from the shared provider and use the same account; they need no credential
file, account database, Gmail dependency, or helper model. Google SMTP's generic Auth
profiles remain a separate existing contract; this feature does not silently convert them.

For a trusted domain adapter, resolve the accepted binding before obtaining a token:

```python
from agent_runtime.auth.google import provider_for

provider = provider_for(parameter_store)
selected = provider.profiles.account(
    account_ref, context, required_features=["calendar_read"]
)
private_record = provider.authorized_account(
    selected.normalized_key, required_features=["calendar_read"]
)
# Pass private_record.value_json["access_token"] only to the trusted provider client.
# Return provider.profiles.summary(private_record) when exposing account metadata.
```

This private execution boundary must never serialize the record into tool results,
Working Context, Memory or logs. Repeat the feature check when obtaining refreshed
authority because Google can return a reduced grant.
