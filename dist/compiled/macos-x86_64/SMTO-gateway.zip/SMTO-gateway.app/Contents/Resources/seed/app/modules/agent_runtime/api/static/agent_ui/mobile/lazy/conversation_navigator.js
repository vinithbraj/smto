import {} from "../../conversation_navigator_core.js";
import { $ } from "../api.js?v=20261018-loading";
import { openSheet, closeSheet } from "../overlays.js?v=20261018-loading";

const core = window.SMTOConversationNavigatorCore;
let entries = [], active = 0, tracker, list;
let navigateToConversationTurn = () => {};
export function configure({navigate}) {
  navigateToConversationTurn = navigate;
}
export function reset() {
  tracker?.dispose(); tracker = null;
  entries = []; active = 0;
  if (list) { list.dispose(); list = null; void closeSheet(); }
  $("#conversation-navigator").hidden = true;
}
export function refreshActive() { tracker?.refresh(); }
export function sync(turns, {allowShort = false} = {}) {
  const next = core.deriveEntries(Array.from(turns.values(), turn => ({
    messageId: turn.id, role: "user", hidden: !turn.userAuthored || window.SMTOTaskDisclosure.isFiltered(turn.root),
    prompt: turn.prompt, attachments: turn.attachments, anchor: window.SMTOTaskDisclosure.anchorFor(turn.root),
  })), entries);
  if (next.length === entries.length && next.every((entry, i) => entry === entries[i])) return;
  const previousId = entries[active]?.messageId;
  tracker?.dispose();
  if (list) { list.dispose(); list = null; void closeSheet(); }
  entries = next;
  active = Math.max(0, entries.findIndex(entry => entry.messageId === previousId));
  if (entries.length < (allowShort ? 1 : core.MIN_TURNS)) { reset(); return; }
  $("#conversation-navigator").hidden = false;
  $("#conversation-navigator").onclick = () => open();
  tracker = core.createTracker({entries, viewport: $("#thread"), content: $("#messages"),
    changed(index) { active = index; list?.update(index); }, resized() { list?.resize(); }});
}
export function open(returnFocus = null) {
  if (!entries.length) return;
  const body = openSheet("Conversation Navigator", {returnFocus, onClose: () => {
    list?.dispose(); list = null;
  }});
  list = core.createPromptList({entries, activeIndex: active, rowHeight: 48,
    async select(index) {
      const entry = entries[index];
      await closeSheet();
      if (entry?.anchor.isConnected) navigateToConversationTurn(entry.messageId);
    },
  });
  body.append(list.root);
  list.open();
  list.root.focus({preventScroll: true});
}
