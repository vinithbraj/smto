/**
 * @file src/agent_runtime/api/static/agent_ui/manual_links.js
 * @brief Resolve stable Manual document links for local and public deployments.
 * @details
 * Responsibilities: Share the deployment-aware Manual URL policy across all browser shells.
 * Boundaries: Navigation only; does not load documents or change application state.
 * Lifecycle: Loaded before shared UI and mobile presentation components.
 * State: No persistence or mutable shared configuration.
 * Security: URL and fragment construction encode document identifiers as data.
 * Collaborators: agent_ui_shared and error_presenter project links through this helper.
 * Public surface: SMTOManualLinks.manualUrl.
 * @see src/agent_runtime/api/static/agent_ui/agent_ui_shared.js
 */
(() => {
  "use strict";
  const compactText = (value, fallback = "") => String(value ?? "").replace(/\s+/g, " ").trim() || fallback;
  const publicManualOrigin = "https://manual.smtorch.com";

  function isLocalServiceHostname(hostname) {
    const host = compactText(hostname).toLowerCase().replace(/^\[|\]$/g, "");
    return (
      !host ||
      host === "localhost" ||
      host === "::1" ||
      host === "0.0.0.0" ||
      host === "::" ||
      host.endsWith(".local") ||
      /^127\./.test(host) ||
      /^10\./.test(host) ||
      /^192\.168\./.test(host) ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host)
    );
  }

  function formatServiceHostname(hostname) {
    return hostname.includes(":") && !hostname.startsWith("[") ? `[${hostname}]` : hostname;
  }

  function manualUrl(docId = "manual-home", port = "8013", headingId = "") {
    const hostname = window.location.hostname || "127.0.0.1";
    const targetHost = hostname === "0.0.0.0" || hostname === "::" ? "127.0.0.1" : hostname;
    const safePort = compactText(port, "8013");
    const safeDoc = compactText(docId, "manual-home");
    const url = isLocalServiceHostname(targetHost)
      ? new URL(`http://${formatServiceHostname(targetHost)}:${safePort}/manual`)
      : new URL("/manual", publicManualOrigin);
    url.hash = `doc=${encodeURIComponent(safeDoc)}`;
    if (headingId) url.hash += `&heading=${encodeURIComponent(headingId)}`;
    return url.toString();
  }

  window.SMTOManualLinks = Object.freeze({manualUrl});
})();
