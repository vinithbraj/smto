/* Ephemeral application chrome. Run/task invalidation drives reads; time ticks locally. */
(() => {
  "use strict";
  window.SMTOCommandStatus = {create({input, host, getView, notify}) {
    let panel = null, data = null, timer = null, unsubscribe = null, pending = null;
    let collapsed = false, scope = null, revision = 0, refreshing = false, dirty = false;
    let summary, details, toggle;
    const protocol = window.SMTOCommandProtocol;
    function close({focus = true} = {}) {
      revision++; clearInterval(timer); clearTimeout(pending); unsubscribe?.();
      panel?.remove(); panel = null; data = null; scope = null; dirty = false;
      if (focus) input.focus({preventScroll: true});
    }
    function render() {
      if (!panel || !data) return;
      const text = protocol.statusText(data);
      window.SMTONumberOdometer.render(summary, text.summary);
      const rows = [[text.timingLabel, text.elapsed], ["Phase", text.phase],
        ["Context remaining", text.remaining], ["Context used", text.used],
        ["Measurement", text.measurement], ...text.tokenRows, ...text.memoryRows,
        ["Queued prompts", data.queue?.queued_count ?? 0]];
      rows.forEach(([label, value], index) => {
        let term = details.children[index * 2], description = details.children[index * 2 + 1];
        if (!term) {
          term = document.createElement("dt"); description = document.createElement("dd");
          details.append(term, description);
        }
        const sameLabel = term.textContent === label;
        if (!sameLabel) term.textContent = label;
        window.SMTONumberOdometer.render(description, value, {live: sameLabel});
      });
      while (details.children.length > rows.length * 2) details.lastElementChild.remove();
      details.hidden = collapsed;
      panel.dataset.collapsed = String(collapsed);
      toggle.hidden = collapsed;
      toggle.setAttribute("aria-expanded", String(!collapsed));
      if (collapsed) {
        summary.setAttribute("role", "button");
        summary.tabIndex = 0;
        summary.setAttribute("aria-expanded", "false");
        summary.setAttribute("aria-controls", details.id);
        summary.setAttribute("aria-label", `Expand runtime status: ${text.summary}`);
        summary.title = "Expand runtime status";
      } else {
        for (const attribute of ["role", "tabindex", "aria-expanded", "aria-controls", "aria-label", "title"]) summary.removeAttribute(attribute);
      }
    }
    function setCollapsed(value) {
      collapsed = value; render();
      (collapsed ? summary : toggle).focus({preventScroll: true});
    }
    async function refresh() {
      if (!panel) return;
      if (refreshing) { dirty = true; return; }
      if ((getView().conversation_id || null) !== (scope.conversation_id || null)) { close({focus: false}); return; }
      refreshing = true; const version = revision;
      try {
        const response = await window.SMTOErrors.fetch("/api/agent/commands/execute", {method: "POST",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({command: "/status", context: protocol.context(getView(), "desktop")})});
        const result = await window.SMTOErrors.readJson(response);
        if (panel && version === revision) {
          if (!response.ok || result.status === "error") throw window.SMTOErrors.fromPayload(result, response.status);
          data = result.client_action.status; render();
        }
      } catch (_error) { if (panel && version === revision) summary.textContent = "Status unavailable. Try /status again."; }
      finally { refreshing = false; if (dirty) { dirty = false; schedule(); } }
    }
    function schedule() { clearTimeout(pending); pending = setTimeout(refresh, 150); }
    function open(status) {
      data = status; scope = {conversation_id: status.conversation_id};
      if (!panel) {
        panel = document.createElement("section"); panel.id = "command-runtime-status";
        panel.className = "command-status"; panel.setAttribute("aria-label", "Runtime status"); panel.tabIndex = -1;
        const header = document.createElement("div"); header.className = "command-status-header";
        summary = document.createElement("strong");
        toggle = document.createElement("button"); toggle.type = "button";
        toggle.className = "composer-icon command-status-toggle";
        toggle.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 16h16"/></svg>';
        toggle.setAttribute("aria-label", "Collapse runtime status"); toggle.title = "Collapse runtime status";
        toggle.onclick = event => { event.stopPropagation(); setCollapsed(true); };
        const dismiss = document.createElement("button"); dismiss.type = "button";
        dismiss.setAttribute("aria-label", "Close runtime status"); dismiss.textContent = "×";
        dismiss.dataset.uiSymbol = "cross"; dismiss.onclick = () => close();
        details = document.createElement("dl"); details.id = "command-runtime-status-details";
        header.append(summary, toggle, dismiss); panel.append(header, details);
        host.insertBefore(panel, input.closest("form"));
        panel.addEventListener("click", event => {
          if (collapsed && !event.target.closest("button")) setCollapsed(false);
        });
        panel.addEventListener("keydown", event => {
          if (event.key === "Escape") { event.preventDefault(); close(); }
          else if (collapsed && ["Enter", " "].includes(event.key) && [panel, summary].includes(event.target)) {
            event.preventDefault(); setCollapsed(false);
          }
        });
        unsubscribe = window.SMTOUiUpdates.subscribe(["runs.changed", "tasks.changed", "chats.changed"], schedule);
        timer = setInterval(() => { if (data?.timing?.ticking) render(); }, 1000);
      }
      render(); panel.focus({preventScroll: true});
    }
    window.addEventListener("pagehide", () => close({focus: false}));
    return {open, close};
  }};
})();
