---
id: historical-v54-architecture-request-lifecycle
title: Historical V54 - Request Lifecycle
kind: legacy
tags: [architecture, lifecycle, requests]
summary: How a user prompt moves through clarification, planning, approval, execution, observation, and final rendering.
order: 2
---

> Historical reference. See the current V55 architecture guide before using this material.

# Request Lifecycle

A request begins as plain text and ends as either a conversational answer, a
paused interaction, or verified local work. Integration requests use this same
lifecycle while returning non-streaming JSON envelopes for external systems.

```mermaid
flowchart TD
    A[Prompt intake] --> B[Context assembly]
    B --> C{Clarification needed?}
    C -->|ask user| D[clarification_required]
    C -->|auto-resolved| F
    D --> E[Resume with answer]
    E --> F
    F --> Q[Compile immutable goal contract]
    Q --> R{LR-T hit?}
    R -->|yes, learned tasks| G[Operator planning]
    R -->|no| T{Single report?}
    T -->|yes| U[Compile one report action]
    U --> V[Validate and execute report]
    V -->|goal complete| N[Final formatting]
    V -->|needs more work or none valid| G
    T -->|no| G
    G --> H[Plan validation]
    H --> I{Approval needed?}
    I -->|yes| J[confirmation_required]
    J --> K[Resume trusted plan]
    I -->|no| L[Execute]
    K --> L
    L --> M[Observation review]
    M -->|repair| G
    M -->|clarify| D
    M -->|candidate complete| W[Whole-request fulfillment review]
    W -->|missing outcome| G
    W -->|satisfied| N[Final formatting]
    N --> O[DisplayDocument and trace]
```

## Important Pause States

| State | Meaning |
| --- | --- |
| `clarification_required` | The runtime needs one more user answer |
| `confirmation_required` | A validated plan needs approval before execution |
| stopped | The user or runtime ended the request before completion |
| completed | The final response and artifacts are ready |

## Context Assembly


The composer Run button creates a durable task with `start_now: true` and
`source: chat`. When the runtime is idle, the backend starts the oldest queued
task immediately and the UI attaches to that request stream. When another
request, durable task, approval, or clarification is active, the same button
changes to Queue and the new task waits behind older queued work. That task
preserves conversation id, selected model, agent mode, gateway/routing
metadata, settings context, terminal context when active, and request-scoped
auto-approve intent.

When a queued durable task starts while the UI is open, the UI fetches the
saved trace first, replays retained events, and then streams with `after_id`
set to the latest retained trace event. If background auto-approval continues
the task on a child request, the UI follows the task's current request id and
renders the child trace or final result.

The Integration Execution API submits prompts through the same request handler
and waits on trace events until completion, failure, cancellation,
confirmation, clarification, or timeout. It does not open the Agent UI SSE
stream, and persisted runtime controls remain the source of truth.

Gmail requests attach account and selected-mail context before capability
planning. The same lifecycle then decides whether the request is read-only,
draft-only, reminder creation, or mutation. Sends, trash/archive, label
changes, spam marking, read/unread changes, and unsubscribe actions pause at
confirmation before the Gmail service calls Google APIs.


LR-T can then reuse a validated learned total-task structure when the prompt
shape, classification, model family, workflow mode, and registry contract hash
match closely enough. A hit skips decomposition only, and it is rejected if it
does not cover the current goal contract. Planning, validation, approval,
execution, and observation continue normally.

If a newly generated decomposition contains valid semantic tasks but omits the
machine-readable obligation links, the runtime preserves those tasks and asks
a compact structured LLM alignment reviewer to supply only task-to-obligation
mappings and dependencies. It does not regenerate the decomposition or infer
semantic mappings with tool-specific code.

Clarification mode is carried as `agent_clarification_mode` and can be
`auto_pilot`, `balanced`, or `pedantic`. Legacy clarification-strategy input is
normalized into that mode.

Before the UI sees a clarification card, the typed resolver can continue with
selected entities and assumptions when confidence is high enough. That context
feeds the next SQL/operator/capability step, but does not bypass validation or
approval.

## Why The Flow Loops

Execution can reveal that a command failed, a result was empty, or a user choice is still missing. The observation stage can repair, ask, or finalize based on evidence rather than assumptions.

## Stepwise Operator Loop

When a request needs tools and is not already atomic, the runtime decomposes it
into small task frames. The operator plans only the current task, execution
records fresh evidence, and the next operator call receives that evidence
through the streaming task context and input bindings. A goal ledger tracks
each obligation as pending, evidence available, or verified. Receding-horizon
planning receives that ledger so it focuses on unfinished outcomes instead of
repeating already completed work.

A successful action is not by itself whole-request success. Before the final
answer, the fulfillment reviewer compares the ledger and bounded execution
evidence with the immutable contract. Missing outcomes can trigger one bounded,
validated continuation; otherwise the request is reported as incomplete rather
than being described as completed. Learned structures are written only after
the contract is satisfied.

For repeated streaming steps, LR Direct can reuse an exact prior command or
Python replay shape. LR-EX can reuse a semantically equivalent payload-aware
shape after a structured LLM judge accepts the candidate and maps current prior
outputs safely.

Gmail semantic matching is similar in spirit but integration-scoped: it may
select likely messages or senders from bounded cache/thread context, while
current account resolution, typed payload validation, and confirmation policy
still decide what can run.
