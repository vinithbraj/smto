/* Settings sections reuse the scoped policy APIs; capacity controls never own admission. */
(() => {
  "use strict";
  function mount(sections, nav, {setStatus, onChange = () => {}}) {
    const initialRead = (host, label, read) => window.SMTOBusy ? window.SMTOBusy.run({host, label}, read) : read();
    window.SMTOResourceLockingSettings.mount(sections, nav, {setStatus, onChange});
    const section = document.createElement("details");
    section.id = "settings-section-completion"; section.className = "mission-settings-section";
    section.dataset.sectionSearch = "agent checks runtime guards disable all execution lifecycle stop instant graceful timeout";
    const summary = document.createElement("summary"); summary.className = "mission-settings-section-summary";
    const title = document.createElement("h2"); title.textContent = "Agent Checks"; summary.append(title); section.append(summary);
    const body = document.createElement("div"); body.className = "mission-section-body"; section.append(body);
    const link = document.createElement("a"); link.href = "#settings-section-completion"; link.textContent = "Agent Checks";
    nav.append(link); sections.append(section);
    const apiJson = (url, options) => window.SMTOAgentUi.apiJson(url.replace("/api/agent", ""), options);
    const execution = document.querySelector("#settings-section-execution .mission-section-body");
    const lifecycle = document.createElement("div"); execution?.append(lifecycle);
    async function refreshLifecycle() {
      try {
        const catalog = await apiJson("/api/agent/stop-policy");
        lifecycle.replaceChildren();
        window.SMTOAgentChecks.lifecycleControls(lifecycle, catalog, {scope: "global", apiJson,
          refresh: refreshLifecycle, notify: message => setStatus(message, "error")});
        onChange();
      } catch (error) { setStatus(error.message, "error"); }
    }
    void initialRead(lifecycle, "Loading lifecycle settings…", refreshLifecycle);
    const asyncSection = document.createElement("details");
    asyncSection.id = "settings-section-asynchronous-execution"; asyncSection.className = "mission-settings-section";
    asyncSection.dataset.sectionSearch = "asynchronous task execution parallel foreground batches conflict serialize reject concurrent activities";
    const asyncSummary = document.createElement("summary"); asyncSummary.className = "mission-settings-section-summary";
    const asyncTitle = document.createElement("h2"); asyncTitle.textContent = "Asynchronous task execution";
    asyncSummary.append(asyncTitle); asyncSection.append(asyncSummary);
    const parallel = document.createElement("div"); parallel.className = "mission-section-body";
    asyncSection.append(parallel); sections.append(asyncSection);
    const asyncLink = document.createElement("a"); asyncLink.href = "#settings-section-asynchronous-execution";
    asyncLink.textContent = "Asynchronous task execution"; nav.append(asyncLink);
    const capacitySection = document.createElement("details");
    capacitySection.id = "settings-section-scheduler-capacity";
    capacitySection.className = "mission-settings-section";
    capacitySection.dataset.sectionSearch = "scheduler capacity global run gateway activity limits parallel background dependency cpu disk read network gpu lightweight unknown fairness auto custom";
    const capacitySummary = document.createElement("summary");
    capacitySummary.className = "mission-settings-section-summary";
    const capacityTitle = document.createElement("h2"); capacityTitle.textContent = "Scheduler capacity";
    capacitySummary.append(capacityTitle); capacitySection.append(capacitySummary);
    const capacityBody = document.createElement("div"); capacityBody.className = "mission-section-body";
    const capacityCopy = document.createElement("p"); capacityCopy.className = "mission-section-copy";
    capacityCopy.textContent = "Set activity ceilings and resource budgets. Resource budgets apply only to enabled Resource locking families; general activity ceilings remain active. Global policy defaults apply to new tasks; Gateway overrides and global activity slots apply to new admissions across tasks. Running work continues. Enable scheduling features in ";
    const featuresLink = document.createElement("a"); featuresLink.href = "#settings-section-asynchronous-execution";
    featuresLink.textContent = "Asynchronous task execution"; capacityCopy.append(featuresLink, ".");
    const capacityDefaults = document.createElement("div"); capacityDefaults.className = "scheduler-capacity-defaults";
    capacityBody.append(capacityCopy, capacityDefaults); capacitySection.append(capacityBody); sections.append(capacitySection);
    const capacityLink = document.createElement("a"); capacityLink.href = "#settings-section-scheduler-capacity";
    capacityLink.textContent = "Scheduler capacity"; nav.append(capacityLink);
    let parallelVersion = 0;
    let schedulerWrites = 0;
    const schedulerApi = async (url, options) => {
      const writing = options?.method === "PUT";
      // Invalidate reads that began before this save. An update-stream refresh
      // must not replace disabled fields with an older, editable policy while
      // the write is still committing.
      if (writing) { ++parallelVersion; ++schedulerWrites; }
      try {
        const result = await apiJson(url, options);
        if (writing) setStatus("Scheduler settings saved.", "saved");
        return result;
      } finally {
        if (writing) --schedulerWrites;
      }
    };
    async function refreshParallel({external = false} = {}) {
      if (schedulerWrites) return;
      if (external && (parallel.contains(document.activeElement) || capacityDefaults.contains(document.activeElement))) return;
      const version = ++parallelVersion;
      try {
        const [catalog, background, dependency, resource] = await Promise.all([apiJson("/api/agent/parallel-execution"), apiJson("/api/agent/background-activities"), apiJson("/api/agent/dependency-scheduling"), apiJson("/api/agent/resource-scheduling")]);
        if (version !== parallelVersion || !asyncSection.isConnected) return;
        parallel.replaceChildren(); capacityDefaults.replaceChildren();
        window.SMTOAgentChecks.parallelControls(parallel, catalog, {scope: "global", showGroupTitle: false, capacityRoot: capacityDefaults, apiJson: schedulerApi,
          refresh: refreshParallel, notify: message => setStatus(message, "error")});
        window.SMTOAgentChecks.backgroundControls(parallel, background, {scope: "global", capacityRoot: capacityDefaults, apiJson: schedulerApi,
          refresh: refreshParallel, notify: message => setStatus(message, "error")});
        window.SMTOAgentChecks.dependencyControls(parallel, dependency, {scope: "global", capacityRoot: capacityDefaults, apiJson: schedulerApi,
          refresh: refreshParallel, notify: message => setStatus(message, "error")});
        window.SMTOAgentChecks.resourceControls(capacityDefaults, resource, {scope: "global", toggleRoot: parallel, expanded: true, apiJson: schedulerApi,
          refresh: refreshParallel, notify: message => setStatus(message, "error")});
        for (const row of capacityDefaults.querySelectorAll(".agent-check-row"))
          row.dataset.settingSearch += " " + row.textContent.toLowerCase();
        onChange();
      } catch (error) { setStatus(error.message, "error"); }
    }
    void initialRead(parallel, "Loading execution settings…", refreshParallel);

    const gateways = document.createElement("article"); gateways.className = "agent-check-row scheduler-gateway-capacity";
    gateways.dataset.settingSearch = "gateway overrides capacity auto cpu disk read gpu network lightweight unknown";
    const gatewaysTitle = document.createElement("h4"); gatewaysTitle.textContent = "Gateway overrides";
    const gatewaysCopy = document.createElement("p");
    gatewaysCopy.textContent = "Choose a Gateway to override its shared total and resource limits. Leave a field blank for Auto. Higher activity ceilings still apply.";
    const gatewayLabel = document.createElement("label"); gatewayLabel.textContent = "Gateway for capacity overrides";
    const gatewaySelect = document.createElement("select"); gatewaySelect.setAttribute("aria-label", "Gateway for capacity overrides");
    gatewayLabel.append(gatewaySelect);
    const gatewayForm = document.createElement("div");
    gateways.append(gatewaysTitle, gatewaysCopy, gatewayLabel, gatewayForm); capacityBody.append(gateways);
    let gatewayRecords = [], gatewayVersion = 0;
    function showGatewayCapacity() {
      gatewayForm.replaceChildren();
      const record = gatewayRecords.find(item => item.gateway_id === gatewaySelect.value);
      if (!record) return;
      const editor = window.SMTOGatewayManagement.capacityEditor(record, {
        onSave: () => setStatus("Gateway capacity saved.", "saved"),
        onLoad: () => {
          gateways.dataset.settingSearch = "gateway overrides capacity " + gateways.textContent.toLowerCase();
          onChange();
        },
      });
      gatewayForm.append(editor); editor.open = true;
    }
    gatewaySelect.onchange = showGatewayCapacity;
    async function refreshGatewayCapacity() {
      const version = ++gatewayVersion;
      try {
        const response = await apiJson("/api/agent/gateway-management");
        if (version !== gatewayVersion || !capacitySection.isConnected) return;
        const selected = gatewaySelect.value;
        gatewayRecords = response.gateways || [];
        gatewaySelect.replaceChildren();
        for (const record of gatewayRecords) {
          const option = document.createElement("option"); option.value = record.gateway_id;
          option.textContent = record.label || record.gateway_id; gatewaySelect.append(option);
        }
        gatewaySelect.disabled = !gatewayRecords.length;
        if (gatewayRecords.some(record => record.gateway_id === selected)) gatewaySelect.value = selected;
        showGatewayCapacity();
        if (!gatewayRecords.length) gatewayForm.textContent = "Add a Gateway in Settings → Gateways to configure its capacity.";
        onChange();
      } catch (error) { window.SMTOErrors.present(gatewayForm, error); setStatus(error.message, "error"); }
    }
    void initialRead(gatewayForm, "Loading Gateway capacity…", refreshGatewayCapacity);
    window.SMTOUiUpdates?.subscribe(["gateways.changed"], () => void refreshGatewayCapacity());

    const contextSection = document.createElement("details");
    contextSection.id = "settings-section-context"; contextSection.className = "mission-settings-section";
    contextSection.dataset.sectionSearch = "context attachments read full characters maximum limit";
    const contextSummary = document.createElement("summary"); contextSummary.className = "mission-settings-section-summary";
    const contextTitle = document.createElement("h2"); contextTitle.textContent = "Context & Attachments";
    contextSummary.append(contextTitle); contextSection.append(contextSummary);
    const contextBody = document.createElement("div"); contextBody.className = "mission-section-body";
    contextSection.append(contextBody); sections.append(contextSection);
    const contextLink = document.createElement("a"); contextLink.href = "#settings-section-context";
    contextLink.textContent = "Context & Attachments"; nav.append(contextLink);
    let contextVersion = 0;
    async function refreshContext() {
      const version = ++contextVersion;
      try {
        const catalog = await apiJson("/api/agent/context-read-policy");
        if (version !== contextVersion) return;
        contextBody.replaceChildren();
        window.SMTOAgentChecks.contextControls(contextBody, catalog, {scope: "global", apiJson,
          refresh: refreshContext, notify: message => setStatus(message, "error")});
        onChange();
      } catch (error) { setStatus(error.message, "error"); }
    }
    void initialRead(contextBody, "Loading context settings…", refreshContext);
    const monitoring = document.createElement("article");
    monitoring.className = "agent-check-row agent-check-monitoring-setting";
    monitoring.dataset.settingSearch = "monitor disabled agent checks informational activity diagnostics";
    const monitoringRow = document.createElement("label"); monitoringRow.className = "mission-toggle-row";
    const monitoringToggle = document.createElement("input");
    monitoringToggle.className = "mission-switch";
    monitoringToggle.type = "checkbox"; monitoringToggle.setAttribute("role", "switch");
    monitoringToggle.setAttribute("aria-label", "Monitor disabled Agent Checks");
    monitoringToggle.checked = false; monitoringToggle.disabled = true;
    const monitoringLabel = document.createElement("strong");
    monitoringLabel.textContent = "Monitor disabled Agent Checks";
    const monitoringCopy = document.createElement("small");
    monitoringCopy.id = "agent-check-monitoring-description";
    monitoringToggle.setAttribute("aria-describedby", monitoringCopy.id);
    monitoringCopy.textContent = "Detect when a disabled check would have intervened and record an informational Activity note without blocking the run. Adds no model calls. Applies to new tasks.";
    monitoringRow.append(monitoringToggle, monitoringLabel, monitoringCopy);
    monitoring.append(monitoringRow); body.append(monitoring);
    async function refreshMonitoring() {
      const result = await apiJson("/api/agent/settings/preferences");
      monitoringToggle.checked = result.settings?.disabled_agent_check_monitoring_enabled === true;
      monitoringToggle.disabled = false;
    }
    monitoringToggle.onchange = async () => {
        const busyFeedback = window.SMTOBusy?.action("Saving execution settings…", monitoringToggle);
        try {
      const selected = monitoringToggle.checked;
      monitoringToggle.disabled = true;
      try {
        await apiJson("/api/agent/settings/preferences", {method: "PUT",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({settings: {disabled_agent_check_monitoring_enabled: selected}})});
        setStatus("Agent Check monitoring saved.", "saved");
      } catch (error) { monitoringToggle.checked = !selected; setStatus(error.message, "error"); }
      finally { monitoringToggle.disabled = false; }

        } finally { busyFeedback?.finish(); }
      };
    void initialRead(monitoring, "Loading monitoring settings…", refreshMonitoring).catch(error => setStatus(error.message, "error"));
    const bulkActions = document.createElement("div"); bulkActions.className = "agent-check-bulk-actions";
    const disableAll = document.createElement("button");
    disableAll.type = "button"; disableAll.className = "action-button";
    disableAll.textContent = "Disable all"; disableAll.disabled = true;
    const bulkCopy = document.createElement("p");
    bulkCopy.textContent = "Turn off all Agent Checks globally for future tasks. Conversation and prompt overrides still apply.";
    const bulkStatus = document.createElement("p"); bulkStatus.setAttribute("role", "status");
    const checkControls = document.createElement("fieldset");
    checkControls.className = "agent-check-settings-controls";
    checkControls.setAttribute("aria-label", "Agent Checks settings");
    bulkActions.append(disableAll, bulkCopy, bulkStatus);
    body.append(bulkActions, checkControls);
    let disablingAll = false;
    /** Keep the bulk action unavailable while saving or when every global check is off. */
    function updateDisableAll() {
      disableAll.disabled = disablingAll || !checkControls.querySelector('[role="switch"]:checked');
    }
    const mounted = window.SMTOAgentChecks.panel(checkControls, {initialScope: "global", showLifecycle: false, showContext: false, showParallel: false, apiJson,
      notify: message => setStatus(message, "error"), onRendered: () => {
        if (!disablingAll) bulkStatus.replaceChildren();
        updateDisableAll(); onChange();
      }});
    disableAll.onclick = async () => {
        const busyFeedback = window.SMTOBusy?.action("Saving execution settings…", disableAll);
        try {
      if (disableAll.disabled) return;
      disablingAll = true; checkControls.disabled = true; updateDisableAll();
      bulkStatus.textContent = "Disabling all Agent Checks…";
      try {
        await apiJson("/api/agent/runtime-guards/disable-all", {method: "POST"});
        await mounted.refresh();
        bulkStatus.textContent = "All Agent Checks disabled globally.";
        setStatus("Agent Checks saved.", "saved");
      } catch (error) {
        window.SMTOErrors.present(bulkStatus, error);
        setStatus(error.message, "error");
      } finally {
        disablingAll = false; checkControls.disabled = false; updateDisableAll();
      }

        } finally { busyFeedback?.finish(); }
      };
    window.SMTOUiUpdates?.subscribe(["settings.changed"], () => { mounted.refresh(); void refreshLifecycle(); void refreshContext(); void refreshParallel({external: true}); void refreshMonitoring().catch(error => setStatus(error.message, "error")); });
  }
  window.SMTOCompletionSettings = {mount};
})();
