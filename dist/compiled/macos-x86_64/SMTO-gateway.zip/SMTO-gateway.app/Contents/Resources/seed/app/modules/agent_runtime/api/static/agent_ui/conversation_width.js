/* Restore each conversation's local reading width before paint. New chats start narrow and unpinned. */
(() => {
  "use strict";
  // Reset legacy preferences: pinning now opts into the expansive layout.
  const prefix = "smto.agentUi.conversationWidth.v2:";
  const root = document.documentElement;
  const memory = new Map();
  const url = new URL(location.href);
  let conversationId = url.searchParams.get("conversation");
  if (!conversationId && url.searchParams.get("palette") !== "1") {
    try { conversationId = localStorage.getItem("smto.agentUi.conversationId"); } catch (_) {}
  }
  let pinned = preference(conversationId);
  let pin;

  function preference(id) {
    if (!id) return false;
    if (memory.has(id)) return memory.get(id);
    try { return localStorage.getItem(prefix + id) === "true"; }
    catch (_) { return false; }
  }

  function persist() {
    if (!conversationId) return;
    memory.set(conversationId, pinned);
    try { localStorage.setItem(prefix + conversationId, String(pinned)); } catch (_) {}
  }

  function activate(id) {
    if (id && id === conversationId) return;
    conversationId = id || null;
    pinned = preference(conversationId);
    render();
  }

  function accepted(id) {
    // Keep a width explicitly chosen in the new-chat composer once it gains an ID.
    if (!conversationId && id) {
      conversationId = id;
      persist();
    } else activate(id);
  }

  function render() {
    root.dataset.conversationWidth = pinned ? "expansive" : "fixed";
    if (!pin) return;
    pin.setAttribute("aria-pressed", String(pinned));
    pin.title = pinned ? "Unpin to use narrow width" : "Pin to expand with the window";
  }

  render();
  function bind() {
    pin = document.querySelector("#conversation-width-toggle");
    if (!pin) return;
    pin.addEventListener("click", () => {
      pinned = !pinned;
      persist();
      render();
    });
    render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", bind, {once: true});
  else bind();
  window.addEventListener("pageshow", event => {
    if (!event.persisted || !conversationId) return;
    pinned = preference(conversationId);
    render();
  });
  window.addEventListener("storage", event => {
    if (event.key !== null && !event.key.startsWith(prefix)) return;
    if (event.key === null) memory.clear();
    else memory.delete(event.key.slice(prefix.length));
    if (conversationId && (event.key === null || event.key === prefix + conversationId)) {
      pinned = preference(conversationId);
      render();
    }
  });
  window.SMTOConversationWidth = Object.freeze({activate, accepted});
})();
