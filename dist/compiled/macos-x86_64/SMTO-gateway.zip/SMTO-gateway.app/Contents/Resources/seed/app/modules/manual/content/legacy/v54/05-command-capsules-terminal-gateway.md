---
id: historical-v54-command-capsules-terminal-gateway
title: Historical V54 - Command Capsules, Terminal, And Gateway
kind: legacy
tags: [commands, terminal, gateway, execution]
summary: How command output is shown, when the terminal is used, and how gateway boundaries protect execution.
order: 5
---

> Historical reference. See the current V55 architecture guide before using this material.

# Command Capsules, Terminal, And Gateway

Command capsules are the UI representation of executed operator actions. They
keep stdout, stderr, exit code, command metadata, and verification evidence
close to the final answer.

External integrations such as Gmail use the same approval and evidence posture
but do not execute through the shell gateway. Gmail routes through the local
Gmail service after typed payload validation, account resolution, and any
required confirmation. Shell gateway boundaries and Gmail service boundaries
are separate execution boundaries with the same runtime rule: model-authored
intent is checked before anything touches the outside world.

## Capsule Contents

A command capsule may show:

- command text and working directory;
- gateway and execution mode;
- exit code and status;
- stdout and stderr previews;
- extracted artifacts or raw data references;
- verification details when the plan checks its own result.

## Tryout Event Capsules

Fast tryout modes expose attempted work before the final response. The request
stream can include these visible events:

- `operator.tryout.candidate`
- `operator.tryout.accepted`
- `operator.tryout.executing`
- `operator.tryout.output`
- command start, output, validation, repair, and completion events

They are evidence, not a second safety system. Every capsule still has to
validate as an operator action before the gateway receives any command.

## Terminal Use

Most commands run captured. The terminal route is reserved for commands that need an interactive TTY or are intentionally detached, such as a long-running server, `tail -f`, a REPL, or a password prompt.

The terminal pane can be shown or hidden from Settings or with the square
terminal button beside Mic in the composer. Both controls write the same
backend-persisted terminal visibility preference. The terminal header still
collapses or expands the pane without changing that preference. On the Mobile
Agent UI, the Terminal button opens `/agent-ui?terminal=1`, enables the same
visibility preference, and expands the desktop terminal pane.

Advisory mode has a separate **Include terminal in Advisory** switch in the
terminal header. When enabled, Advisory prompts receive the terminal cwd,
session id, and a capped visible terminal-output snapshot as context. This does
not set `execute_in_terminal` and does not make Advisory run commands.

```mermaid
flowchart LR
    A[shell.command] --> B{Execution mode}
    B -->|captured| C[Gateway exec stream]
    B -->|terminal_detached| D[Terminal session]
    C --> E[Command capsule]
    D --> F[Terminal pane]
```

## Gateway Boundary

The gateway is the process that touches the real shell. The Agent API sends trusted execution requests to it, and the gateway returns structured execution results.
Each gateway advertises its platform, shell, command profile, and capability
tags. The agent keeps the user intent portable, then emits commands for the
selected gateway profile. A Windows PowerShell gateway should receive
PowerShell commands, while Linux/macOS/WSL gateways should receive POSIX shell
commands.

Gateways can be reached as inbound HTTP endpoints or as outbound WebSocket
sessions. Outbound mode is useful when a gateway machine can reach the Agent
server, but firewall or LAN policy prevents the Agent server from connecting to
the gateway's listening port.

The boundary matters because it separates:

- planning from execution;
- UI state from shell state;
- model output from validated commands;
- runtime orchestration from platform-specific terminal behavior.

## Gateway Routing

```mermaid
sequenceDiagram
    participant Runtime
    participant Registry as Gateway Registry
    participant Gateway
    participant Shell
    Runtime->>Registry: Select gateway and cwd
    Runtime->>Gateway: POST /exec, terminal route, or outbound WebSocket request
    Gateway->>Shell: Run command
    Shell-->>Gateway: Output
    Gateway-->>Runtime: Structured result
```
