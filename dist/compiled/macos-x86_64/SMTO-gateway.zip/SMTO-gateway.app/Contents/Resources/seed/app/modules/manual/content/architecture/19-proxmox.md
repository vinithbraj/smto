---
id: architecture-proxmox
title: Proxmox VE skill and API
kind: architecture
tags: [architecture, proxmox, skills, parameters, gateway, authentication]
order: 31
---
# Proxmox VE skill and API

For setup and everyday requests, start with [Using Proxmox VE](../24-proxmox.md).
This page describes the implementation, session state and generated API contract.

Proxmox is an optional native skill and is **disabled by default**. Enable/add
`proxmox` in the existing capability selection for the applicable prompt,
conversation, or global settings. Installing this release does not add it to
default selections, including upgrades of legacy opt-out selections.

In Parameter Store, select **Proxmox Server** beside **New**, then click **New**. This prefills the
existing Value JSON editor; fill in the server and password and save normally:

```json
{
  "profile_type": "server_connection",
  "profile_version": 1,
  "service": "proxmox",
  "scheme": "https",
  "server": "pve.home.example",
  "port": 8006,
  "username": "root@pam",
  "password": "<your password>",
  "verify_tls": true
}
```

Save it as `home_proxmox`, then ask:

> From @home_proxmox, turn on windows11.

A typed reference makes the four entry tools initially available **only if
capability policy already allows them**. The reference grants no approval,
Gateway access, or additional capability. Ordinary requests use:

| Tool | Behavior |
| --- | --- |
| `proxmox.server_info` | Read version and nodes; publish verified server context. |
| `proxmox.guest_list` | List QEMU VMs and LXC containers across the cluster. |
| `proxmox.guest_status` | Resolve an exact name/VMID and obtain fresh status. |
| `proxmox.guest_power` | Resolve, check state, apply power action, wait for task, verify. |

`server_ref` is optional with one accepted/current verified server. Multiple
servers require an explicit accepted key. Guest resolution uses exact numeric
VMID, then exact name, then a unique case-insensitive exact name; no fuzzy or
substring matching can select a guest for mutation. Node and QEMU/LXC routing
are internal. “Turn off” means `shutdown`. `stop` means explicitly requested hard
power-off. Failed shutdown never escalates to stop. Start/shutdown/stop and other
target-state actions return `changed=false` when the target state already holds;
reboot/reset are not reduced to a running-state no-op. Supported actions are
checked against the pinned guest-type endpoint inventory.

Power tools default to `wait=true`, `timeout_seconds=120` (1–3600). UPID polling
is bounded runtime work with cancellation, not model polling. `wait=false`
returns a pending task, without claiming final state. Task failures/timeouts
preserve the UPID. Cancellation stops local waiting; it does not claim to cancel
the remote task. Uncertain mutations are never automatically replayed; the
power helper attempts a fresh state reconciliation and reports unknown effect.

## Authentication and session state

The runtime translates the accepted typed profile into a literal HTTP v3
`session_login` profile. Gateway HTTP performs `POST /api2/json/access/ticket`,
extracts `PVEAuthCookie`, and supplies `CSRFPreventionToken` for writes. The model
never calls login, builds headers, or constructs REST paths for domain tools.

Sessions are scoped to conversation, Gateway route/identity, parameter key and
revision, origin, and a digest of the effective authentication values. They survive individual run cleanup. A warm
conversation reuses its ticket; Gateway expiry or a bounded read-side 401 renews
it silently. Detectably expired sessions renew before dispatching writes. Profile
updates/deletes invalidate known sessions immediately; accepting a new revision
also retires the old known scope. Conversation
delete/abandon invalidates sessions and releases its runtime authentication state.
Requests without a conversation use the existing per-run authentication lifetime.

All entry and model-exposed generated tools accept optional `auth_values` containing
only literal `username`/`password` strings. The runtime validates a detached overlay;
unknown fields and structural changes are rejected before dispatch. Values preserve
exact whitespace and never update Parameter Store. Saved and transient passwords
use the same session provider. Missing values return `credential_required`, exact `missing_fields`, and
`executed=false`. The Agent asks for all missing values in one ordinary `ask_user`
reply, then retries with `auth_values` on its next normal turn. Authentication
rejection is reported separately and can be retried with replacement values. Accepted literal parameter snapshots survive restart. Legacy opaque handles require the exact historical store revision.

Parameter Store and accepted checkpoints retain literal profiles. PARAMETERS controls their consumer projections. Typed values can be exported through the parameter environment; see [Redaction](31-redaction.md).

HTTPS verification defaults on. `verify_tls=false` explicitly selects the
existing insecure TLS mode for installations with self-signed certificates. No
TLS failure retries insecurely. IPv4, IPv6, and hostnames are supported. Gateway identity verification remains authoritative, independently of target TLS.

Verified Working Context retains configured server identity and revision/provenance,
including the configured account. It never stores transient usernames/passwords or
the effective authentication recipe. WORKING_CONTEXT optionally projects its consumer copy. Guest status still comes from fresh receipts.

## API sections and generated tools

The shipped 9.2 API inventory contains 680 method/path descriptors, including
678 model-exposed operations and two internal `/access/ticket` operations.
All raw tools share the same executor/session transport as the entry tools.

`discover_tools(skill_ids=["proxmox"])` exposes only entry tools and root section
metadata. `discover_tools(section_ids=["proxmox.nodes.node.qemu.vmid.status"])`
exposes that section's directly owned tools and child section metadata. Discovery
is non-recursive. Discover `.status.start` to obtain the start endpoint schema.
Discovering a new Proxmox slice replaces its previously advertised raw slice,
while retaining entry tools; repeated exploration cannot accumulate the entire API.
Exact tool discovery remains available within the capability envelope.

Raw arguments contain `parameters` (vendor named path/query/body parameters),
optional `server_ref`, `auth_values`, `wait`, and `timeout_seconds`.
`auth_values` is a wrapper argument and never enters PVE parameters or request bodies. Paths are percent-encoded;
reads and DELETE use query fields, POST/PUT use URL-encoded forms. Booleans are
sent as 0/1 and arrays as repeated fields. Writes use normal effect/approval
policy. Uploads additionally accept a granted `upload_context_id` and reuse
Gateway multipart/file transport. Download-capable operations accept
`response_mode="artifact"` to retain a response as an existing Context artifact.
Existing HTTP body, response, and upload bounds apply (2 MiB inline response,
8 MiB file transfer); this is not a bulk ISO streaming transport or interactive
WebSocket console. Literal authentication reaches execution unchanged. Optional central redaction
affects only consumer projections.

## Updating the pinned API

Canonical source: the official [Proxmox API Viewer](https://pve.proxmox.com/pve-docs/api-viewer/)
`apidoc.js` JSON literal. The vendored gzip retains the exact downloaded bytes;
the generator parses JSON and never executes downloaded JavaScript. Runtime
loads generated files offline and never fetches vendor documentation.

The source manifest records SHA-256, source URL, fetch date, generator version,
target release, counts, and version evidence. The current snapshot is associated
with the co-published official documentation version 9.2.12, built September 18,
2026. The API Viewer itself contains no embedded package/git revision; this
limitation is recorded instead of inventing a commit identity. Do not relabel an
arbitrary old/community `pve-api.json` as a current release.

To update, retrieve the official viewer asset and the version marker from the
co-published administration guide, review the target release, and update
`skills/proxmox/vendor/apidoc.js.gz` and `vendor/source.json` with the exact uncompressed
source digest. Compress with `gzip.compress(data, mtime=0)`. Then run:

```sh
.venv/bin/python scripts/generate_proxmox_api.py
.venv/bin/python scripts/generate_proxmox_api.py --check
.venv/bin/python -m pytest -q tests/test_proxmox_skill.py
```

The generator rejects mismatched source hashes/version evidence, reports removed
method/path identities, and produces deterministic descriptors, sections, and a
manifest. Tests independently enumerate every source method, check ID uniqueness
and validity, validate schemas, and compare generated bytes. IDs depend on
method/path, with deterministic hashes for ambiguous normalization/long names.
PVE property-string formats remain strings; source schemas are retained for
review. Perl-only patterns and variant constraints dependent on server-side
existing state remain server-validated. No endpoint method is silently dropped.

Generated files are smTO-owned build output. The vendor artifact remains
upstream API reference material; it is never model prompt content.
