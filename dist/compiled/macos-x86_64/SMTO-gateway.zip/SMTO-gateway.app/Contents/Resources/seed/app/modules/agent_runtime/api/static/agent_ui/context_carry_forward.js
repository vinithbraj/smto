/* Shared desktop/mobile/settings control. Values belong to server profiles. */
(() => {
  "use strict";
  function create({value = null, defaultValue = {mode: "all"}, allowDefault = true, onChange = () => {}} = {}) {
    const root = document.createElement("fieldset");
    root.className = "context-carry-forward";
    const legend = document.createElement("legend"); legend.textContent = "Context carried forward";
    const mode = document.createElement("select"); mode.setAttribute("aria-label", "Context carried forward");
    mode.className = "chat-field-control";
    const modeShell = document.createElement("span"); modeShell.className = "chat-select-shell";
    modeShell.append(mode);
    for (const [key, label] of [["all", "All"], ["most_recent", "Most recent"], ["rolling", "Rolling window"], ["task_skill", "Use task skill"]]) {
      mode.add(new Option(label, key));
    }
    const countLabel = document.createElement("label"); countLabel.textContent = "Finished runs ";
    const count = document.createElement("input");
    count.className = "chat-field-control";
    count.type = "number"; count.min = "1"; count.max = "24"; count.step = "1"; count.value = "5";
    count.setAttribute("aria-label", "Number of finished runs"); count.style.width = "5em";
    countLabel.append(count);
    const reset = document.createElement("button"); reset.type = "button"; reset.textContent = "Use global default";
    reset.className = "action-button";
    reset.hidden = !allowDefault;
    const help = document.createElement("small"); help.setAttribute("aria-live", "polite");
    root.append(legend, modeShell, countLabel, reset, help);
    let selected = value, globalValue = defaultValue;
    function render(next = selected, nextDefault = globalValue) {
      const previous = selected || globalValue || {mode: "all"};
      selected = next; globalValue = nextDefault || {mode: "all"};
      const effective = selected || globalValue;
      const editingCount = document.activeElement === count && previous.mode === effective.mode &&
        previous.window_size === effective.window_size;
      mode.value = effective.mode;
      if (!editingCount) count.value = String(effective.window_size || 5);
      countLabel.hidden = mode.value !== "rolling";
      reset.disabled = selected === null;
      if (mode.value === "task_skill") {
        help.textContent = (allowDefault && selected === null ? "Using global default. " : "") +
          "Automatically supplies task instructions and compact progress. The agent retrieves additional Task Context when needed. Relevant Memory summaries can also be included. Applies to the next run; existing runs keep their settings.";
        return;
      }
      help.textContent = (allowDefault && selected === null ? "Using global default. " : "") +
        (mode.value === "all" ? "Uses existing history limits. " : "Carries requests, summaries and result references. ") +
        "Shared setup stays available. Applies to the next run; history is kept for lookup.";
    }
    function changed() {
      countLabel.hidden = mode.value !== "rolling";
      if (mode.value === "rolling" && (!count.checkValidity() || !Number.isInteger(Number(count.value)) || !count.value)) {
        count.reportValidity(); return;
      }
      selected = {mode: mode.value, ...(mode.value === "rolling" ? {window_size: Number(count.value)} : {})};
      render(); onChange(selected);
    }
    mode.addEventListener("change", changed);
    count.addEventListener("change", changed);
    reset.addEventListener("click", () => { render(null); onChange(null); });
    root.setValue = render;
    root.setDisabled = disabled => { root.disabled = disabled; };
    render();
    return root;
  }
  window.SMTOContextCarryForward = {create};
})();
