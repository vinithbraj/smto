/**
 * @file src/agent_runtime/api/static/agent_ui/model_configuration.js
 * @brief Render the server-owned execution parameter catalog in Mission Control.
 * @ingroup ProductInterfaces
 * @details
 * Responsibilities:
 * - Present profile selection, compact presence switches, inline values, expandable
 *   help, a context partition guide and resolved values. Checked means User Configured;
 *   unchecked means omit.
 * Boundaries:
 * - The server owns schemas, presets and final validation; settings.js owns autosave.
 * Lifecycle:
 * - create mounts registry definitions; edits publish a profile/map patch; refresh
 *   reconciles accepted values while preserving focused or locally invalid editors.
 * State:
 * - Controls and local validation errors live with the page. No local persistence or
 *   provider calls; getValues reads the Settings controller's current draft.
 * Security:
 * - Labels and help use textContent. JSON editors are data, never evaluated code.
 *   Invalid local input blocks saving; backend validation remains authoritative.
 * Collaborators:
 * - settings.js supplies Connection rows, state access and save/error callbacks;
 *   route_groups/settings.py publishes parameter, profile and provider metadata.
 * Public surface:
 * - SMTOModelConfiguration.create returns element, refresh, hasErrors and
 *   updateMetadata. Updating metadata refreshes the preview, not persisted settings.
 * @see src/agent_runtime/api/static/agent_ui/settings.js
 * @see src/agent_runtime/api/agent_ui_support/route_groups/settings.py
 * @see src/agent_runtime/llm/model_configuration.py
 * @see src/manual/content/25-model-configuration.md
 */
(() => {
  "use strict";
  const OVERRIDES = "llm_execution_request_overrides";
  const PROFILE = "llm_execution_configuration_profile";
  /** Treat explicit false, zero and empty containers as configured by key presence. */
  const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  /** Create presentation nodes using literal text, including provider metadata. */
  const node = (tag, text, className) => {
    const element = document.createElement(tag);
    if (text != null) element.textContent = text;
    if (className) element.className = className;
    return element;
  };

  /** Explain shared context capacity without implying live measurements or fixed partitions. */
  function tokenPartition() {
    const panel = node("details", null, "mission-setting-row model-token-partition");
    panel.id = "model-token-partition";
    panel.append(node("summary", "Token partition"));
    panel.append(node("p", "The context window is the space available for one model call. Input and reserved output must fit together. Each step of a task builds a new input using this same limit. Arrows show the exact setting names and the space they affect."));
    const diagram = node("pre", `+-----------------------------------------------------------+
|                  MODEL CONTEXT WINDOW                     | <--- Context window (tokens; 0 = Auto)
|              Total capacity of one model call             |      Auto uses server capacity when available.
|                                                           |
|  +-----------------------------------------------------+  |
|  | INPUT                                               |  |
|  |                                                     |  |
|  |  System instructions                                |  |
|  |  Rules and guidance that define agent behavior      |  |
|  |                                                     |  |
|  |  Tool definitions                                   |  |
|  |  Available tools and their argument schemas         |  |
|  |                                                     |  |
|  |  Current request and task state                     |  | <--- Task Contract maximum output tokens
|  |  Your prompt, Task Contract and runtime facts       |  |      Caps a separate call; its contract enters here.
|  |                                                     |  | <--- Keep task at tail
|  |                                                     |  |      Includes the contract or request at input end.
|  |                                                     |  |
|  |  Attached context                                   |  | <--- Read full attached context
|  |  File contents and other text read into the input   |  | <--- Maximum characters per Context read
|  |                                                     |  |      Limits each read when full reading is off.
|  |                                                     |  |      Measured in characters, not tokens.
|  |                                                     |  |
|  |  Retained conversation and earlier steps            |  |
|  |  Previous messages, tool calls and their results    |  |
|  |                                                     |  |
|  |  Current tool results                               |  | <--- Tool result delivery
|  |  Tool output used to choose the next action         |  |      Full results or bounded previews; also affects
|  |                                                     |  |      tool results retained in earlier steps.
|  +-----------------------------------------------------+  |
|                                                           |
|  +-----------------------------------------------------+  |
|  | REMAINING INPUT SPACE                               |  | <--- Calculated space; no separate setting
|  | Shrinks as more content is included                 |  |      Context window - input - reserved output.
|  |                                                     |  |      Increasing Maximum completion tokens shrinks it.
|  +-----------------------------------------------------+  |
|                                                           |
|  +-----------------------------------------------------+  |
|  | RESERVED OUTPUT                                     |  | <--- Maximum completion tokens
|  | Space for ONE model response, including:            |  |      Reserves this many tokens on EVERY model call.
|  |                                                     |  |
|  |  Reasoning, where counted                           |  | <--- Thinking token budget (if provider supports it)
|  |                                                     |  | <--- Thinking budget (%) (soft prompt guidance)
|  |                                                     |  |      Both apply WITHIN the output allowance.
|  |  Text and tool-call arguments                       |  |
|  +-----------------------------------------------------+  |
+-----------------------------------------------------------+

       INPUT + RESERVED OUTPUT <= CONTEXT WINDOW`);
    diagram.tabIndex = 0;
    diagram.setAttribute("role", "region");
    diagram.setAttribute("aria-label", "Model context window diagram with arrows mapping settings to input and output");
    panel.append(diagram, node("p", "These sections vary in size; they are not fixed partitions. Content is counted wherever it is included in the request; attached text delivered as a tool result is part of that result."));
    panel.append(node("p", "System instructions, tool definitions and retained history have no separate token-budget setting here. Task Contract thinking budget and Token increase per retry apply to separate contract-generation calls; only the generated contract becomes execution input."));
    panel.append(node("h4", "How settings affect this space"));
    const effects = node("dl");
    for (const [label, text] of [
      ["Context window (tokens; 0 = Auto)", "Sets the total context ceiling. Auto uses active server capacity when available. A larger setting cannot enlarge the server's actual capacity."],
      ["Maximum completion tokens", "Increase -> more output reserved -> less input space. Decrease -> more input space, but reasoning, text or tool arguments may be cut off."],
      ["Tool result delivery", "Adaptive preserves critical evidence with exact recovery. Compact retains legacy previews. Full includes complete captured results and may exhaust context."],
      ["Read full attached context / Maximum characters per Context read", "Full reading returns the remaining attached source when it fits. With full reading off, the character limit bounds each read; further reads may be needed. Characters are not tokens."],
      ["Thinking token budget", "Controls reasoning on supported models. It does not enlarge the context window. Reasoning shares the output allowance where the provider counts it."],
      ["Thinking budget (%)", "Asks the model to keep reasoning within this percentage of Maximum completion tokens. This is soft prompt guidance, not an enforced limit or extra output space."],
      ["Task Contract maximum output tokens", "Controls a separate contract-generation call. The generated contract later becomes part of execution input. This setting does not enlarge the execution context window."],
      ["Keep task at tail", "Includes the Task Contract, or the original request when compilation is off, at the end of each model input."],
    ]) effects.append(node("dt", label), node("dd", text));
    panel.append(effects, node("h4", "Example - illustrative values, not current usage"));
    const example = node("pre", `Total context window                  128,000 tokens
Reserved output                         8,000 tokens
                                     ----------------
Maximum space available for input     120,000 tokens

Increase reserved output to            16,000 tokens
Input space falls to                  112,000 tokens`);
    example.tabIndex = 0;
    example.setAttribute("role", "region");
    example.setAttribute("aria-label", "Example of output reservation reducing input space");
    panel.append(example, node("h4", "When a tool result cannot fit"));
    panel.append(node("p", "If the model is already using its maximum context window, no output-token increase can add input capacity. Increasing completion tokens makes less room for input. Use smaller batches or select Adaptive or Compact under Tool result delivery; reduce an excessive output reservation if appropriate."));
    panel.append(node("p", "Compaction can remove eligible older content, but protected current input may still be too large. Exact execution results remain preserved."));
    panel.append(node("p", "Provider Default still reserves output space internally. Changes to model configuration and Tool result delivery apply to new tasks; resumed tasks retain their saved settings."));
    panel.dataset.settingSearch = `llm context tokens capacity budget overflow ${panel.textContent}`.toLowerCase();
    return panel;
  }

  /** Mount one catalog; callbacks own draft updates, persistence and shared status. */
  function create({section, connectionRows, reasoningRows = [], growthRows = [], getValues, onChange, onError}) {
    const element = node("div", null, "model-configuration");
    if (window.SMTOReadiness) element.append(window.SMTOReadiness.create().element);
    const controls = new Map();
    const errors = new Set();
    let recommendation = section.recommendation;
    const profileRow = node("article", null, "mission-setting-row model-profile-row");
    profileRow.dataset.settingSearch = "configuration profile provider defaults smto recommended agent optimized custom small model starting point";
    const profileLabel = node("label", "Configuration Profile", "mission-setting-label");
    profileLabel.htmlFor = "model-configuration-profile";
    const profile = node("select");
    profile.id = profileLabel.htmlFor;
    profile.setAttribute("aria-describedby", "model-profile-help");
    const definition = section.settings.find(item => item.key === PROFILE);
    for (const option of definition.options) {
      const item = new Option(option.label, option.value);
      window.SMTOAgentUi?.bindBrandCopy(item, option.label);
      profile.add(item);
    }
    const help = node("p", section.profile_help, "mission-setting-description");
    window.SMTOAgentUi?.bindBrandCopy(help, section.profile_help);
    help.id = "model-profile-help";
    const profileHelp = node("details", null, "model-profile-help");
    profileHelp.append(node("summary", "About profiles"), help);
    const target = node("p", "", "mission-setting-description model-profile-target");
    profileRow.append(profileLabel, profile, profileHelp, target);
    element.append(profileRow);
    const resolved = node("details", null, "model-resolved-profile mission-setting-row");
    resolved.dataset.settingSearch = "resolved recommended settings provider defaults configured values profile";
    resolved.append(node("summary", "Configured preferences and endpoint support"));
    const resolvedList = node("dl"); resolved.append(resolvedList); element.append(resolved);
    const connection = node("section", null, "model-parameter-group model-connection-group");
    connection.setAttribute("aria-label", "Connection");
    connection.append(node("h3", "Connection"), ...connectionRows);
    element.append(connection, tokenPartition());
    const reasoningPreview = node("p", "", "mission-setting-description");
    reasoningPreview.id = "model-reasoning-budget-preview";
    reasoningPreview.setAttribute("aria-live", "polite");
    if (reasoningRows.length) {
      const reasoning = node("section", null, "model-parameter-group");
      reasoning.setAttribute("aria-label", "Thinking and recovery");
      reasoning.append(node("h3", "Thinking and recovery"), ...reasoningRows, reasoningPreview);
      element.append(reasoning);
    }
    if (growthRows.length) {
      const growth = node("section", null, "model-parameter-group");
      growth.setAttribute("aria-label", "Automatic budget increases");
      growth.append(node("h3", "Automatic budget increases"),
        node("p", "Increase the output allowance when a response is truncated. Each accepted model response resets the output increase count. Increased output allowances persist in this conversation. Thinking targets do not consume increases.", "mission-setting-description"), ...growthRows);
      element.append(growth);
    }
    const modeHelp = node("p", "Toggle on to set a value; off uses the provider default. Editing a parameter selects Custom.", "mission-setting-description model-mode-help");
    modeHelp.id = "model-mode-help";
    element.append(modeHelp);

    /** Publish an exact map copy and select Custom without changing other fields. */
    function commit(key, value, configured) {
      const values = structuredClone(getValues()[OVERRIDES] || {});
      if (configured) values[key] = value;
      else delete values[key];
      onChange({[OVERRIDES]: values, [PROFILE]: "custom"});
    }

    profile.addEventListener("change", () => {
      errors.clear();
      for (const entry of controls.values()) {
        entry.error.textContent = "";
        entry.input.removeAttribute("aria-invalid");
      }
      const mode = profile.value;
      onChange({[PROFILE]: mode, [OVERRIDES]: mode === "provider_default" ? {}
        : mode === "smto_recommended" ? structuredClone(recommendation.overrides)
        : structuredClone(getValues()[OVERRIDES] || {})});
    });

    for (const [category, title] of Object.entries(section.categories)) {
      const group = node("section", null, "model-parameter-group");
      group.setAttribute("aria-label", title);
      group.append(node("h3", title));
      for (const parameter of section.parameters.filter(item => item.category === category)) {
        const {key, schema} = parameter;
        const row = node("article", null, "mission-setting-row model-parameter-row");
        row.dataset.parameterKey = key;
        row.dataset.settingSearch = [key, parameter.wire_key, parameter.label, parameter.description, parameter.model_behavior,
          parameter.agent_behavior, parameter.recommendation, ...parameter.provider_support,
          ...parameter.warnings].join(" ").toLowerCase();
        const heading = node("div", null, "model-parameter-heading");
        const label = node("label", parameter.label, "mission-setting-label");
        label.htmlFor = `model-mode-${key}`;
        heading.append(label);
        const mode = node("input", null, "mission-switch");
        mode.type = "checkbox"; mode.id = label.htmlFor;
        mode.setAttribute("role", "switch");
        mode.setAttribute("aria-label", `${parameter.label}: User Configured`);
        mode.setAttribute("aria-describedby", `model-mode-help model-help-${key}`);
        const valueCell = node("div", null, "model-parameter-value");
        const defaultValue = node("span", "Provider default", "model-parameter-default");
        const editor = node("div", null, "model-parameter-editor");
        const valueLabel = node("label", `${parameter.label} value`, "model-value-label");
        valueLabel.htmlFor = `model-value-${key}`;
        let input;
        if (schema.enum || schema.type === "boolean") {
          input = node("select");
          const options = schema.enum || [true, false];
          for (const option of options) input.add(new Option(
            schema.type === "boolean" ? (option ? "On" : "Off") : String(option), String(option)));
        } else if (["number", "integer"].includes(schema.type)) {
          input = node("input"); input.type = "number";
          input.step = parameter.step ?? (schema.type === "integer" ? "1" : "any");
          if (schema.minimum != null) input.min = schema.minimum;
          if (schema.maximum != null) input.max = schema.maximum;
        } else {
          input = node("textarea"); input.rows = 1; input.spellcheck = false;
          valueLabel.textContent += " (JSON)";
        }
        input.id = valueLabel.htmlFor;
        input.setAttribute("aria-describedby", `model-help-${key} model-error-${key}`);
        const error = node("p", "", "model-parameter-error");
        error.id = `model-error-${key}`; error.setAttribute("role", "alert");
        editor.append(valueLabel, input, error);
        valueCell.append(defaultValue, editor);
        const description = node("p", parameter.description, "mission-setting-description");
        description.id = `model-help-${key}`;
        const education = node("details", null, "model-parameter-help");
        const helpToggle = node("summary", "Help");
        helpToggle.setAttribute("aria-label", `Help for ${parameter.label}`);
        education.append(helpToggle, description,
          node("p", parameter.provider_support.join(" · "), "model-provider-tags"));
        for (const [title, text] of [
          ["Effect on model behavior", parameter.model_behavior],
          ["Effect on agent behavior", parameter.agent_behavior],
          ["Recommended for agents", parameter.recommendation],
          ["Explicit starting value", JSON.stringify(parameter.recommended_value)],
          ["Warnings", parameter.warnings.join(" ")],
        ]) {
          const paragraph = node("p"); paragraph.append(node("strong", `${title}: `), document.createTextNode(text));
          education.append(paragraph);
        }
        row.append(mode, heading, valueCell, education);
        controls.set(key, {parameter, mode, input, editor, defaultValue, error});
        mode.addEventListener("change", () => {
          errors.delete(key); error.textContent = ""; input.removeAttribute("aria-invalid");
          const configured = mode.checked;
          const values = getValues()[OVERRIDES] || {};
          commit(key, own(values, key) ? values[key] : structuredClone(parameter.recommended_value), configured);
          if (configured) input.focus();
        });
        input.addEventListener("change", () => {
          try {
            let value;
            if (schema.type === "boolean") value = input.value === "true";
            else if (schema.enum) value = input.value;
            else if (["number", "integer"].includes(schema.type)) {
              if (!input.value.trim()) throw window.SMTOErrors.error("ui_number_required");
              value = Number(input.value);
              if (!Number.isFinite(value)) throw window.SMTOErrors.error("ui_number_invalid");
              if (schema.type === "integer" && !Number.isSafeInteger(value)) {
                throw window.SMTOErrors.error("ui_integer_invalid");
              }
              if (schema.minimum != null && value < schema.minimum || schema.maximum != null && value > schema.maximum) {
                throw window.SMTOErrors.error("ui_number_out_of_range", {minimum: schema.minimum, maximum: schema.maximum});
              }
              if (schema.exclusiveMinimum != null && value <= schema.exclusiveMinimum) {
                throw window.SMTOErrors.error("ui_number_out_of_range", {exclusiveMinimum: schema.exclusiveMinimum});
              }
            } else value = JSON.parse(input.value);
            errors.delete(key); error.textContent = ""; input.removeAttribute("aria-invalid");
            commit(key, value, true);
          } catch (exception) {
            errors.add(key); input.setAttribute("aria-invalid", "true");
            const detail = exception.error_detail ? exception : window.SMTOErrors.error("ui_json_invalid");
            window.SMTOErrors.present(error, detail, {profile: "compact"});
            onError(error.textContent);
          }
        });
        group.append(row);
      }
      element.append(group);
    }

    /** Reconcile modes and resolved values without overwriting an active invalid edit. */
    function refresh() {
      const values = getValues()[OVERRIDES] || {};
      const percent = getValues().llm_reasoning_budget_percent ?? 50;
      const limit = values.max_completion_tokens;
      const thinkingDisabled = values.enable_thinking === false || values.thinking_token_budget === 0
        || (values.reasoning_effort === "none" && values.enable_thinking !== true);
      reasoningPreview.textContent = thinkingDisabled
        ? "Thinking is explicitly disabled; no reasoning-budget instruction will be added."
        : Number.isSafeInteger(limit) && limit > 0
          ? `Soft thinking target: ${Math.floor(limit * percent / 100).toLocaleString()} reasoning tokens (${percent}% of ${limit.toLocaleString()}). Exceeding it shows a notice and continues; counts may be estimated.`
          : "Provider Default receives brief-reasoning guidance without a numeric thinking target.";
      profile.value = getValues()[PROFILE] || "provider_default";
      target.textContent = `Model: ${recommendation.model || "unresolved model"}. Endpoint support is learned from ordinary requests; saved preferences stay unchanged.`;
      resolvedList.replaceChildren();
      for (const [key, entry] of controls) {
        const configured = own(values, key);
        entry.mode.checked = configured;
        entry.mode.title = configured ? "User Configured — turn off to use Provider Default" : "Provider Default — turn on to configure";
        entry.defaultValue.hidden = configured;
        entry.editor.hidden = !configured;
        entry.input.disabled = !configured;
        if (!errors.has(key) && document.activeElement !== entry.input) {
          const value = configured ? values[key] : entry.parameter.recommended_value;
          entry.input.value = entry.input instanceof HTMLTextAreaElement ? JSON.stringify(value) : String(value);
        }
        const compatibility = recommendation.compatibility || {};
        const wireKey = (entry.parameter.wire_key || key).split(".")[0];
        const support = (compatibility.support || {})[wireKey];
        const suppressed = (compatibility.suppressed || []).includes(wireKey);
        let status = support === "unsupported" || suppressed ? "Omitted for current endpoint"
          : support === "supported" ? "Accepted by endpoint" : "Support unknown";
        if (key === "max_completion_tokens" && compatibility.output_token_wire_field) {
          status = `Translated to ${compatibility.output_token_wire_field}`;
        }
        resolvedList.append(node("dt", entry.parameter.label), node("dd", configured
          ? `User Configured: ${JSON.stringify(values[key])} · ${status}` : "Provider Default — omitted"));
      }
    }
    refresh();
    return {element, refresh, hasErrors: () => errors.size > 0,
      updateMetadata(value) { recommendation = value; refresh(); }};
  }
  window.SMTOModelConfiguration = {create};
})();
