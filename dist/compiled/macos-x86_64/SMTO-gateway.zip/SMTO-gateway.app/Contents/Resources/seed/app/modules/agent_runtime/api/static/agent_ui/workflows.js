/* Saved requests share the app's editor, appearance and durable task surfaces. */
(() => {
  "use strict";
  let options = {}, recipes = [], busy = new Set(), returnFocus = null;
  const categories = {chat: "Prior chat messages", inputs: "Attached inputs", results: "Previous tool results"};
  const el = (tag, text = "", cls = "") => {
    const node = document.createElement(tag); node.textContent = text;
    if (cls) node.className = cls; return node;
  };
  async function api(path = "", method = "GET", body, signal) {
    const response = await window.SMTOErrors.fetch(`/api/agent/recipes${path}`, {
      method, signal, headers: {"Content-Type": "application/json"},
      ...(body === undefined ? {} : {body: JSON.stringify(body)})});
    const data = await window.SMTOErrors.readJson(response);
    if (!response.ok) {
      const failure = window.SMTOErrors.fromPayload(data, response.status);
      // The shared boundary sanitizes the route's actionable explanation. Keep
      // it visible alongside the catalog identity rather than only a generic
      // validation label. Render as text, never HTML.
      const detail = typeof data.detail === "string" ? data.detail : data.detail?.error;
      if (detail && !failure.message.includes(detail)) failure.message += ` ${detail}`;
      throw failure;
    }
    return data;
  }
  const dialog = el("dialog"); dialog.id = "workflow-editor";
  dialog.setAttribute("aria-labelledby", "workflow-title");
  const form = el("form", "", "workflow-form"), head = el("div", "", "dialog-heading");
  const title = el("h2"); title.id = "workflow-title";
  const content = el("div", "", "form-content"), footer = el("footer", "", "dialog-footer");
  const error = el("p", "", "error-text"); error.setAttribute("role", "alert");
  form.append(head, content, error, footer); dialog.append(form); document.body.append(dialog);
  const editorView = window.SMTOBusy.view(content);
  let editorGeneration = 0;
  const fail = err => { if (err.name === "AbortError") return; error.textContent = err.message || "Workflow could not be saved."; };
  const button = (text, action, cls = "") => {
    const node = el("button", text, cls); node.type = "button";
    let pending = false;
    node.addEventListener("click", () => {
      if (pending) return; pending = true;
      Promise.resolve().then(action).catch(fail).finally(() => { pending = false; });
    }); return node;
  };
  const close = button("×", () => dialog.close(), "close-button"); close.setAttribute("aria-label", "Close workflow dialog");
  head.append(title, close);
  dialog.addEventListener("close", () => { editorGeneration++; editorView.dispose(); if (returnFocus?.isConnected) returnFocus.focus(); });
  function open(label) {
    editorGeneration++; editorView.dispose();
    title.textContent = label; content.replaceChildren(); footer.replaceChildren(); error.textContent = "";
    form.onsubmit = event => event.preventDefault();
    if (!dialog.open) { returnFocus = document.activeElement; dialog.showModal(); }
  }
  function field(parent, label, value = "", multiline = false) {
    const wrap = el("label", label), input = el(multiline ? "textarea" : "input");
    input.value = value; wrap.append(input); parent.append(wrap); return input;
  }
  const eligible = prompt => Boolean(String(prompt || "").trim()) && !String(prompt).trimStart().startsWith("/");
  async function editor({recipe = null, source = null, draft = null} = {}) {
    open(recipe ? "Edit workflow" : "Save to workflow");
    const loading = editorView.begin("Loading saved request…");
    const read = (path, method = "GET", body) => api(path, method, body, loading.signal);
    try {
    const candidate = source ? await read(`/candidates/${encodeURIComponent(source)}`) : null;
    let snapshot = structuredClone(recipe?.artifact.settings || candidate?.settings || (await read("/defaults")).settings);
    const origin = draft || ((!recipe && !source) ? options.draft?.() : null) || {};
    if (!recipe && !source) snapshot = {...snapshot, ...(origin.settings || {})};
    let context = candidate?.context || {};
    if (!recipe && !source) {
      const preview = await read("/draft-preview", "POST", {
        prompt: origin.prompt || "New workflow", conversation_id: origin.conversation_id || "",
        settings: origin.settings || {}, input_refs: origin.input_refs || []});
      context = preview.context; snapshot = preview.settings;
    }
    if (recipe) context = (await read(`/${recipe.recipe_id}/context-preview?recipe_revision=${recipe.recipe_revision}`)).context;
    if (!loading.current || !dialog.open) return;
    content.replaceChildren();
    const name = field(content, "Name", recipe?.title || candidate?.title || String(origin.prompt || "").trim().slice(0, 160)); name.maxLength = 160;
    const prompt = field(content, "Prompt", recipe?.artifact.prompt ?? candidate?.prompt ?? origin.prompt ?? "", true); prompt.maxLength = 24000; prompt.required = true;
    const promptSize = el("p", "", "hint"); promptSize.id = "workflow-prompt-size";
    prompt.setAttribute("aria-describedby", promptSize.id);
    const updatePromptSize = () => {
      const bytes = new TextEncoder().encode(prompt.value).length;
      promptSize.textContent = `Always saved: prompt · ${bytes ? 1 : 0} ${bytes ? "item" : "items"} · ${new Intl.NumberFormat().format(bytes)} bytes. Execution settings are saved separately.`;
    };
    prompt.addEventListener("input", updatePromptSize); updatePromptSize(); content.append(promptSize);
    content.append(el("p", "Runs this prompt with its saved settings. Each run starts a new task.", "hint"));
    const inclusion = el("fieldset"), legend = el("legend", "Include optional context"); inclusion.append(legend);
    inclusion.append(el("p", "These counts exclude the prompt above. Prior messages and tool results stop before this request; its own answer and tool results are not included.", "hint"));
    const switches = {};
    for (const [key, label] of Object.entries(categories)) {
      const row = el("label", "", "mission-switch-row"), input = el("input");
      input.type = "checkbox"; input.className = "mission-switch"; input.role = "switch";
      input.checked = recipe?.artifact.include[key] === true; input.id = `workflow-include-${key}`;
      row.append(input, el("span", label)); inclusion.append(row); switches[key] = input;
      const summary = context[key];
      const empty = {chat: "No earlier chat messages.", inputs: "No attached inputs available to this request.", results: "No earlier tool results."};
      const hint = el("p", summary
        ? `Available: ${summary.count} ${summary.count === 1 ? "item" : "items"} · ${new Intl.NumberFormat().format(summary.bytes)} bytes${summary.count ? "" : `. ${empty[key]}`}`
        : "Context unavailable. Its item count and size could not be determined.", "hint");
      hint.id = `workflow-context-${key}`; input.setAttribute("aria-describedby", hint.id); inclusion.append(hint);
      if (summary?.preview) { const detail = el("details"); detail.append(el("summary", "Preview"), el("pre", summary.preview, "workflow-preview")); inclusion.append(detail); }
    }
    content.append(inclusion, el("p", "Selected context is copied into the workflow and remains available after the original chat is deleted.", "hint"));
    if (candidate?.context_error) content.append(el("p", candidate.context_error, "hint"));
    const settings = el("details", "", "workflow-settings"); settings.append(el("summary", "Execution settings"));
    const gateway = field(settings, "Gateway ID", snapshot.gateway_id || snapshot.gateway_selection?.primary_gateway_id || "");
    const model = field(settings, "Model", snapshot.llm_model || "");
    const endpoint = field(settings, "Model endpoint", snapshot.llm_base_url || "");
    const cwd = field(settings, "Working directory", snapshot.terminal_cwd || snapshot.execution_root || "");
    settings.append(el("p", "These settings are saved with this workflow. Changing global defaults does not change them.", "hint"));
    const advanced = el("details"); advanced.append(el("summary", "Advanced saved settings"));
    const json = field(advanced, "Execution settings (JSON)", JSON.stringify(snapshot, null, 2), true); json.rows = 8;
    settings.append(advanced); content.append(settings);
    let useCurrent = false;
    if (candidate?.missing_settings?.length) {
      settings.open = true;
      content.append(el("p", `Original settings are incomplete: ${candidate.missing_settings.join(", ")}.`, "hint"));
      const use = button("Use current settings", async () => {
        const version = editorGeneration;
        const current = await window.SMTOBusy.run({host: use, label: "Loading current settings…"}, () => api("/defaults"));
        if (version !== editorGeneration || !dialog.open) return;
        snapshot = current.settings; useCurrent = true;
        gateway.value = snapshot.gateway_id || snapshot.gateway_selection?.primary_gateway_id || "";
        model.value = snapshot.llm_model || ""; endpoint.value = snapshot.llm_base_url || "";
        cwd.value = snapshot.terminal_cwd || ""; json.value = JSON.stringify(snapshot, null, 2);
        use.textContent = "Current settings selected"; use.disabled = true;
      }); content.append(use);
    }
    const save = button(recipe ? "Save changes" : "Save workflow", () => form.requestSubmit(), "primary");
    footer.append(button("Cancel", () => dialog.close()), save);
    form.onsubmit = async event => {
      event.preventDefault(); if (save.disabled) return; error.textContent = ""; save.disabled = true;
      const version = editorGeneration;
      const saving = window.SMTOBusy.begin({host: footer, label: "Saving workflow…"});
      try {
        const values = JSON.parse(json.value);
        const originalGateway = snapshot.gateway_id || snapshot.gateway_selection?.primary_gateway_id || "";
        if (gateway.value !== originalGateway) {
          delete values.gateway_selection; values.gateway_id = gateway.value;
        }
        values.llm_model = model.value;
        if (endpoint.value) values.llm_base_url = endpoint.value;
        if (cwd.value) values.terminal_cwd = cwd.value;
        const include = Object.fromEntries(Object.entries(switches).map(([key, input]) => [key, input.checked]));
        const patch = {title: name.value, prompt: prompt.value, include, settings: values};
        const saved = recipe ? await api(`/${recipe.recipe_id}`, "PATCH", {...patch, expected_revision: recipe.recipe_revision}) :
          await api("", "POST", {...patch, source_request_id: source || "", use_current_settings: useCurrent,
            conversation_id: source ? "" : origin.conversation_id || "", input_refs: source ? [] : origin.input_refs || []});
        if (version !== editorGeneration || !dialog.open) return;
        const list = document.getElementById("workflow-list");
        if (list) saving.move(list);
        dialog.close();
        if (list) await library({feedback: saving});
        else { open("Workflow saved"); content.append(el("p", "Your prompt and settings are ready to run again."));
          const link = el("a", "Open in Workflows"); link.href = `/workflows?workflow=${encodeURIComponent(saved.recipe.recipe_id)}`; content.append(link); footer.append(button("Done", () => dialog.close())); }
      } catch (err) { if (version === editorGeneration) fail(err); } finally { saving.finish(); save.disabled = false; }
    };
    name.focus();
    } catch (err) { if (loading.current && err.name !== "AbortError") fail(err); }
    finally { loading.finish(); }
  }
  async function run(recipe, control) {
    if (busy.has(recipe.recipe_id)) return;
    busy.add(recipe.recipe_id); if (control) control.disabled = true;
    const starting = window.SMTOBusy.begin({host: document.getElementById("workflow-list") || control, label: "Starting workflow…"});
    const key = control?.dataset.submissionKey || crypto.randomUUID();
    if (control) control.dataset.submissionKey = key;
    try {
      const result = await api(`/${recipe.recipe_id}/execute`, "POST", {recipe_revision: recipe.recipe_revision, idempotency_key: key});
      if (control) delete control.dataset.submissionKey;
      if (options.onRun) await options.onRun(result);
      else window.location.href = `/agent-ui?conversation=${encodeURIComponent(result.conversation_id)}`;
    } finally { starting.finish(); busy.delete(recipe.recipe_id); if (control) control.disabled = false; }
  }
  async function schedule(recipe) {
    const editor = window.SMTOScheduleEditor.create();
    editor.open(null, {title: recipe.title, prompt: recipe.artifact.prompt, execution: recipe.artifact.settings,
      save: patch => api(`/${recipe.recipe_id}/schedule`, "POST", {recipe_revision: recipe.recipe_revision,
        schedule: {...Object.fromEntries(Object.entries(patch).filter(([key]) => ["schedule_type", "interval_seconds", "next_run_at", "timezone", "recurrence", "notify_on"].includes(key))), prompt: recipe.artifact.prompt, title: recipe.title, action_type: "agent_prompt"}})});
  }
  function pageError(err) {
    const banner = document.getElementById("workflow-page-error");
    if (banner) { banner.hidden = false; banner.textContent = err.message; } else fail(err);
  }
  function render() {
    const list = document.getElementById("workflow-list"); if (!list) return;
    const focusedCard = document.activeElement?.closest("#workflow-list article")?.id;
    const focusedAction = focusedCard ? document.activeElement.textContent : "";
    const query = document.getElementById("workflow-search").value.toLowerCase();
    const sorted = recipes.filter(r => `${r.title} ${r.artifact.prompt}`.toLowerCase().includes(query));
    const sort = document.getElementById("workflow-sort").value;
    sorted.sort((a, b) => sort === "name" ? a.title.localeCompare(b.title) : b.updated_at.localeCompare(a.updated_at));
    list.replaceChildren(); document.getElementById("workflow-count").textContent = `${sorted.length} ${sorted.length === 1 ? "workflow" : "workflows"}`;
    document.getElementById("workflow-empty").hidden = sorted.length > 0;
    for (const recipe of sorted) {
      const card = el("article", "", "schedule-card"); card.id = `workflow-${recipe.recipe_id}`;
      const body = el("div", "", "workflow-card-body");
      body.append(el("h2", recipe.title), el("p", recipe.artifact.prompt, "run-preview"));
      const saved = recipe.artifact.settings, latest = recipe.runs?.[0];
      body.append(el("p", [recipe.gateway_labels?.join(", ") || saved.gateway_id, saved.llm_model, `Revision ${recipe.recipe_revision}`].filter(Boolean).join(" · "), "schedule-meta"));
      body.append(el("p", `Saved context: ${Object.entries(categories).filter(([k]) => recipe.artifact.include[k]).map(([,v]) => v).join(", ") || "None"}`, "schedule-meta"));
      if (latest) body.append(el("p", `Latest run: ${latest.status}`, "schedule-meta"));
      const actions = el("div", "", "card-actions workflow-actions");
      const action = (label, fn, cls = "") => { const btn = button(label, async () => { try { await fn(btn); } catch(err) { pageError(err); } }, cls); actions.append(btn); return btn; };
      action("Run now", btn => run(recipe, btn), "primary");
      action("Edit", () => editor({recipe})); action("Schedule", () => schedule(recipe));
      action("History", () => history(recipe));
      action("Delete", () => {
        open("Delete workflow"); content.append(el("p", `Delete “${recipe.title}”? Existing tasks, schedules and their pinned definitions remain available.`));
        footer.append(button("Keep workflow", () => dialog.close()), button("Delete", async () => {
          const version = editorGeneration;
          await window.SMTOBusy.run({host: footer, label: "Deleting workflow…"}, async operation => {
            await api(`/${recipe.recipe_id}`, "DELETE");
            operation.move(document.getElementById("workflow-list"));
            if (version === editorGeneration) dialog.close();
            await library({feedback: operation});
          });
        }, "destructive"));
      });
      body.append(actions); card.append(body); list.append(card);
    }
    if (focusedCard) {
      const restored = [...(document.getElementById(focusedCard)?.querySelectorAll("button") || [])].find(b => b.textContent === focusedAction);
      (restored || document.getElementById("new-workflow")).focus();
    }
  }
  async function history(recipe) {
    open(`${recipe.title} · history`);
    footer.append(button("Close", () => dialog.close()));
    const loading = editorView.begin("Loading history…");
    try {
    const detail = await api(`/${recipe.recipe_id}/history`, "GET", undefined, loading.signal);
    if (!loading.current || !dialog.open) return;
    content.append(el("p", `Definition revisions: ${detail.revisions.map(r => r.recipe_revision).join(", ")}`, "hint"));
    if (!detail.runs.length) content.append(el("p", "This workflow has not run yet.", "hint"));
    for (const item of detail.runs) {
      const row = el("section"); row.append(el("h3", `${item.status} · revision ${item.recipe_revision}`), el("p", new Date(item.created_at).toLocaleString(), "hint"));
      if (item.error) row.append(el("p", item.error, "error-text"));
      if (item.metadata.conversation_id) { const link = el("a", "Open run"); link.href = `/agent-ui?conversation=${encodeURIComponent(item.metadata.conversation_id)}`; row.append(link); }
      content.append(row);
    }
    } catch (err) { if (loading.current && err.name !== "AbortError") fail(err); }
    finally { loading.finish(); }
  }
  let libraryPending = null, libraryDirty = false;
  async function library({quiet = false, feedback = null} = {}) {
    const list = document.getElementById("workflow-list");
    if (!list) { window.location.href = "/workflows"; return; }
    const loading = feedback || (quiet ? null : window.SMTOBusy.begin({host: list, label: "Loading workflows…", key: "library", replace: true}));
    loading?.update("Loading workflows…");
    try {
      if (libraryPending) libraryDirty = true;
      else libraryPending = (async () => {
        do {
          libraryDirty = false;
          const result = await api(); recipes = result.recipes; render();
        } while (libraryDirty);
      })().finally(() => { libraryPending = null; });
      await libraryPending;
    } finally { if (!feedback) loading?.finish(); }
  }
  function attach(turn, parent, {footer = false} = {}) {
    const slot = footer ? "workflowFooterAction" : "workflowAction";
    if (turn[slot] || !eligible(turn.prompt)) return;
    const btn = button("Save to workflow", () => {
      const source = turn.requestId || turn.id;
      return editor(source ? {source} : {draft: {...(options.draft?.() || {}), prompt: turn.prompt, conversation_id: turn.conversationId || ""}});
    }, footer ? "run-detail-action task-workflow-action" : "workflow-save");
    btn.setAttribute("aria-haspopup", "dialog"); parent.append(btn); turn[slot] = btn;
    turn.refreshWorkflow = () => {
      for (const action of [turn.workflowAction, turn.workflowFooterAction]) {
        if (action) action.hidden = !turn.userAuthored || !eligible(turn.prompt);
      }
    };
    turn.refreshWorkflow();
  }
  window.SMTOWorkflows = {api, library, attach, editor, configure: value => { options = value; },
    saveDraft: () => editor({draft: options.draft?.() || {}})};
  if (document.getElementById("workflow-list")) {
    document.getElementById("new-workflow").addEventListener("click", () => editor().catch(pageError));
    document.getElementById("workflow-search").addEventListener("input", render);
    document.getElementById("workflow-sort").addEventListener("change", render);
    library().then(() => {
      const id = new URLSearchParams(location.search).get("workflow");
      if (id) { const item = document.getElementById(`workflow-${id}`); if (item) { item.tabIndex = -1; item.focus(); item.scrollIntoView({block: "center"}); } }
    }).catch(pageError);
    window.SMTOUiUpdates?.subscribe(["recipes.changed", "tasks.changed", "runs.changed"], () => { void library({quiet: true}).catch(pageError); });
  }
})();
