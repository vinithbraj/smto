# macOS Gateway Agent

Multiple instances on different ports use separate state automatically. Use
`./src/gateway_macos/startup.sh --instance worker --port 8989` for a stable named
instance. See [instance isolation and recovery](../gateway_agent/README.md#multiple-independent-instances).

Gateway operations require the paired smTO controller (V148.1). The configured
smTO client verifies Gateway TLS, pairs automatically on first use, and signs
requests. `/healthz` is the only public operational health surface and returns only
`{"status":"ok"}`. Raw unsigned HTTP/HTTPS examples below illustrate payload shapes;
use the smTO client to execute them.

Outbound Email uses shared `gateway_core` handlers on this platform. The private
`/email/operation` route performs SMTP and Email OAuth HTTPS on the selected Gateway,
supports bounded volatile attachment staging and socket cancellation, and never falls
back to controller SMTP/token requests. Upgrade both controller and Gateway for the
OAuth action. See [Email setup and limits](../manual/content/26-auth-and-email.md).

Pairing and TLS identity survive restarts and upgrades. If the controller identity
is lost, stop the Gateway and run `./src/gateway_macos/reset-pairing.sh` locally
from the checkout root, then restart the Gateway and reconnect the intended
controller. Use the same OS account and `GATEWAY_TLS_STATE_DIR` setting as startup.
The script uses the Gateway's installed virtual environment and resets only the
controller pairing; it preserves the Gateway's TLS identity.
For pairing plus connection cleanup, use `./src/gateway_macos/reset.sh` or
`./src/gateway_macos/startup.sh reset`. The compiled Gateway executable also
accepts `reset`. Add `--dry-run` to preview or `--tls-state-dir PATH` to select
explicit state. Reset also clears saved outbound server pins and abandoned
authentication temporary files, while preserving TLS identity, replay protection,
job history, downloads, artifacts and configuration. Stop the Gateway and its
restart service first, then restart and reconnect after reset. Current Gateways
hold a runtime lease that prevents resetting live state.
See [installation and recovery](../manual/content/02-install-startup.md).

This intentionally permits a new first controller. Automatic first-controller
pairing cannot prevent an active hostile client from winning the very first race
without an out-of-band secret or user confirmation.

Outbound control requires an existing configured Gateway record on the Agent and
a pinned WSS connection to its HTTPS listener. Plain WS is refused. Mutual proofs
bind the session before any operations; encrypted, authenticated sessions may carry
credentials under the existing credential policy. See
[the V148.1 report](../../docs/v148_1-gateway-client-auth-mutual-pairing-report.md)
for protocol and recovery details.


`src/gateway_macos/` is the macOS wrapper for the smTO gateway agent. It
uses the shared gateway core and advertises `platform=macos` through
`GET /capabilities` so the runtime can ask the LLM for macOS-appropriate shell
commands.

## Scope

macOS v1 supports:

- shell command execution through `/bin/bash -lc`;
- streamed shell execution;
- cancellation by execution id;
- PTY-backed terminal sessions;
- terminal command streaming, detached terminal execution, terminal input, and
  terminal output mirroring;
- macOS platform and command profile discovery.

Native macOS features are accessed through command-line tools in v1. Useful
tools include `osascript`, `shortcuts`, `open`, `pbcopy`, `pbpaste`,
`screencapture`, `mdfind`, `system_profiler`, `networksetup`, `pmset`,
`launchctl`, and `defaults`.

## Install

Before provisioning, the installer displays the License and EULA and asks you to
accept each separately. Type `y` or `yes` at both prompts (case-insensitive;
surrounding whitespace is ignored). Any other response, empty input, or EOF
cancels with exit code 1; Ctrl+C exits 130.
Use `./src/gateway_macos/install.sh --show-license` or `--show-eula` to read the
terms without installing. Unattended setup requires `--accept-license VERSION`
and `--accept-eula VERSION` matching those documents. `--non-interactive` alone,
`--yes`, and piped answers cannot grant consent. Each install, upgrade or repair
requires acceptance; receipts do not approve future invocations.

Installation displays step progress, elapsed time and outcomes while capturing
command output in private logs. Redirected output uses plain status lines.
Privilege prompts and errors remain visible; failed logs are retained at the
printed paths. For full output, use `./src/gateway_macos/install.sh --verbose`.

```bash
cd /path/to/smto
./src/gateway_macos/install.sh
```

This creates or updates `src/gateway_macos/.venv` from the canonical
`pyproject.toml` dependency contract, then checks dependencies and mandatory
runtime imports. Normal `./install.sh` on macOS also runs this setup. Restart the
Gateway after updating; installation does not restart services. Each remote
Gateway host must run its installer after updating its own checkout. If
`/capabilities` reports `http_runtime.ready=false`, rerun the installer and restart.

The installer installs the core first, then attempts `.[full]`: all bundled skill Python libraries, manual/site
dependencies and Python tooling. Homebrew/MacPorts also install Tesseract with
English data, the PostgreSQL client and 7-Zip. Versioned/keg-only `psql` paths are
linked into each virtual environment so later Gateway launches can find them.
Homebrew/MacPorts install Docker CLI, Compose and Buildx too; Gateway tools and
the installer discover those plugins without inheriting private Docker configuration.
It does not install or start Docker Desktop, obtain desktop permissions, or set
up provider accounts. Missing optional prerequisites are reported, including when
package-manager installation is explicitly skipped. Failed native package batches are
retried one package at a time. Both the JavaScript browser and Plotly PNG renderer
are attempted and checked locally; their failure does not stop core Gateway setup.
`src/gateway_macos/.venv/smto-installation.json` records optional failures.
Unavailable operations are omitted from Gateway capabilities. Rerun installation after
repairing dependencies, then restart the Gateway to refresh availability.

### Apple Silicon, Intel, and older Intel hosts

The Gateway requires a **64-bit Python 3.11+** and the canonical Gateway Python
dependencies. Homebrew is optional. For an older Intel Mac used only as a remote
Gateway, `./src/gateway_macos/install.sh` is the authoritative standalone path:
it installs Playwright and its matching Chromium, including a headless JavaScript render
check, without running the full server setup. If Playwright/Chromium cannot run on
the host's macOS version, Browser stays unavailable and Gateway installation continues.
Compatible hosts have Browser enabled by default with no extra startup
arguments. Install under the Gateway's OS account so its browser cache is available.
`GATEWAY_BROWSER_ENABLED=false` explicitly disables browser execution; conversation
capability permissions remain separate. `./install.sh` installs the full local smTO environment.

| Host | Dependency path when prerequisites are missing |
| --- | --- |
| Apple Silicon + Homebrew | Existing Homebrew preferred in `auto` |
| Apple Silicon + MacPorts | Existing MacPorts supported |
| Apple Silicon + Python 3.11+ | No manager required for the core; optional tools need their own prerequisites |
| Intel + MacPorts | Preferred Intel/legacy path in `auto` |
| Intel + usable Homebrew | Existing Homebrew supported on a best-effort basis |
| Intel + Python.org 3.11+ | No manager required for the core; optional tools need their own prerequisites |
| Linux | Existing native distro manager and Linux installer |
| Windows | Existing PowerShell installer |

The installer uses a compatible existing Python before considering another
Python installation. It checks `PYTHON_BIN`, PATH commands (`python3.14` through
`python3.11`, then `python3`), MacPorts, Homebrew's resolved prefix and standard
locations, and Python.org frameworks under `/Library/Frameworks/Python.framework`.
An explicit incompatible `PYTHON_BIN` fails clearly; unset or correct it to retry.
Git is installed only when unavailable. Without a manager, missing Git is
reported during discovery; Git-dependent workflows remain unavailable.

For Intel with MacPorts already installed:

```bash
AOR_MACOS_PACKAGE_MANAGER=macports ./src/gateway_macos/install.sh
```

When Python and Git are absent, this runs `sudo /opt/local/bin/port install
python311 git`, then discovers and uses `/opt/local/bin/python3.11` directly.
There is no `port select` or automatic `port selfupdate`.

For Apple Silicon with Homebrew already installed:

```bash
./src/gateway_macos/install.sh
```

To use an existing Python.org framework without system package installation:

```bash
AOR_MACOS_PACKAGE_MANAGER=none \
  PYTHON_BIN=/Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11 \
  ./src/gateway_macos/install.sh
```

`AOR_MACOS_PACKAGE_MANAGER` accepts `auto` (default), `homebrew`, `macports`, and
`none`. Auto prefers usable Homebrew then MacPorts on `arm64`, and MacPorts then
usable Homebrew on `x86_64`. Forced managers must pass a version probe; invalid
values or unusable forced managers fail. `none` uses existing tools only.
`AOR_SKIP_SYSTEM_DEPS=1`, `GATEWAY_SKIP_SYSTEM_DEPS=1`, and
`AOR_INSTALL_SYSTEM_DEPS=0` also prevent system package installation.

Managers are found on PATH or at `/opt/homebrew/bin/brew`, `/usr/local/bin/brew`,
and `/opt/local/bin/port`. The installer never installs a package manager or
edits shell profiles. Homebrew runs as the normal user; MacPorts uses root/sudo
with its resolved executable. Optional package failures are reported and other
packages are still attempted, without switching managers. Command Line Tools may be needed for
source builds; setup only reports this and does not launch their installer.

Install a manager yourself using [MacPorts guidance](https://www.macports.org/install.php)
or [Homebrew guidance](https://brew.sh/), or choose an official
[Python.org macOS package](https://www.python.org/downloads/macos/) compatible
with your host. Homebrew's Intel and older-macOS support is limited; see its
[current support tiers](https://docs.brew.sh/Support-Tiers). Selection is based on
available tools, without hard-coded support deadlines.

The installer supports the Intel/Apple Silicon architecture paths; this is not
certification of every historical macOS release. Optional dependency builds can fail
on older systems without blocking the Gateway. Core Python/runtime failures still stop
setup and print the architecture, macOS version, Python, and selected manager.
PowerPC and 32-bit hosts are unsupported.

## Run

```bash
./src/gateway_macos/startup.sh
```

The helper accepts host and port overrides:

```bash
./src/gateway_macos/startup.sh --host 0.0.0.0 --port 8787
```

### Logs and authorization failures

The startup helper runs in the foreground. Access logs go to stdout and warnings
go to stderr in the launching terminal; it does not create a log file by default.
To retain both streams when starting the Gateway (keep your usual host/port options):

```bash
mkdir -p "$HOME/Library/Logs/SMTO"
./src/gateway_macos/startup.sh --host 0.0.0.0 --port 8787 2>&1 \
  | tee -a "$HOME/Library/Logs/SMTO/gateway.log"
```

For a 401, look for `gateway.controller_auth_failed reason=...` in that output.
These warnings are limited to one per minute. Job command output is stored
separately in `~/.smto/jobs/<node>/<job_id>.log` (or under `GATEWAY_JOB_DIR`).

Controller pairing is stored in `~/.smto/gateway/tls/client-auth/pairing.json`
(under `GATEWAY_TLS_STATE_DIR` if configured). A 401 does not by itself mean this
file or an identity key was deleted. Failure to open authentication storage can
also cause a 401. If a 503 precedes repeated 401s and restarting restores access,
see [the SQLite connection investigation](../../docs/macos-gateway-auth-resource-exhaustion.md).

Because the gateway executes local commands, expose it on `0.0.0.0` only on the
intended network, with paired-controller authentication and TLS enabled.

When inbound access to the gateway is blocked, run outbound mode so the gateway
connects back to the Agent server:

```bash
aor serve --host 0.0.0.0 --port 8011
./src/gateway_macos/startup.sh --server-host 192.168.1.10 --server-port 8011
```

## Configuration

- `GATEWAY_NODE_NAME`
  - logical node served by this gateway
  - default: macOS LocalHostName, short hostname, then `macos`
- `GATEWAY_BIND_HOST`
  - bind host
  - default: `127.0.0.1`
- `GATEWAY_BIND_PORT`
  - bind port
  - default: `8787`
- `GATEWAY_EXEC_TIMEOUT_SECONDS`
  - per-command timeout; `0` disables task timeouts
- `GATEWAY_WORKDIR`
  - optional working directory for command execution
- `GATEWAY_TRACE_COMMANDS`
  - log each requested command on the gateway server
- `GATEWAY_SHELL`
  - command shell path
  - default: `/bin/bash`
- `GATEWAY_SERVER_HOST`
  - Agent server host for outbound gateway mode
- `GATEWAY_SERVER_PORT`
  - Agent server port for outbound gateway mode
- `GATEWAY_SERVER_SCHEME`
  - Agent server scheme for outbound gateway mode
  - default: `http`

## macOS Permissions

Some macOS commands require permission grants to the terminal app or launch
service that runs the gateway:

- Accessibility
- Automation
- Screen Recording
- Full Disk Access
- Files and Folders

Grant only the permissions needed for the workflows you intend to run.

## Automatic Gateway TLS

Supported startup now serves HTTPS on the existing port, normally `https://host:8787`.
smTO generates a durable RSA identity and renews its self-signed certificate
automatically at startup. No OpenSSL executable, certificate copying, CA installation,
fingerprint confirmation, or OS trust-store changes are needed. The Agent pins the
public key on first configured use and verifies it before sending requests. Existing
remote HTTP profiles upgrade automatically when the updated listener is available.

A changed identity key stops operations. After checking the intended machine, use
**Settings → Gateways → Forget trusted identity** for an intentional reinstall/reset,
then reconnect and select the Gateway again. Normal certificate renewal needs no reset.

This protects traffic from passive snooping and pins the Gateway server identity.
Automatic first-use trust cannot prevent an active attacker during first contact.
TLS does not authenticate clients: reachable execution endpoints still require the
existing trusted network/firewall boundary. Remote legacy HTTP cannot carry credentials.
Remote outbound WSS pins the configured Agent server, but credential delivery remains
blocked until independent outbound Gateway client pairing is available; loopback
outbound development remains supported.

See [the V148 report](../../docs/v148-secure-gateway-prerequisite-recovery-report.md)
for identity locations, trust semantics, and acceptance evidence.


### Gateway runtime coherence (V151.1)

The supported installer installs a non-editable package snapshot from the current checkout,
checks canonical dependencies with `pip check`, and validates job and HTTP readiness. Run the
platform installer again after pulling or switching branches, then explicitly restart the
Gateway to use that revision. A Git checkout alone does not upgrade or restart a running Gateway.
Updating dependencies belongs to the installer; the server never installs packages on demand.

`startup.sh` / `startup.ps1` use Python isolated mode and reject legacy editable environments.
Startup checks load jobs, shell execution, privilege, terminal, and available HTTP support before
serving requests. Missing or incompatible `psutil` fails startup with installer guidance.
Authenticated `/capabilities` includes `background_jobs.ready` and a bounded `runtime_identity`
(package version, source snapshot fingerprint, and psutil version), without filesystem paths.

For development, use a separate development environment and invoke `python -m gateway_core.serve`
or the platform app directly. Source/editable development is an explicit opt-in by bypassing the
production startup script; restart that development process whenever code or dependencies change.
Production startup deliberately provides no editable/hot-upgrade switch. Installer updates to an
in-use environment require a coordinated explicit restart; they are not a hot-upgrade mechanism.

## Desktop UI automation

Native AX requires Accessibility permission for the Gateway host. Semantic AX does not require Screen Recording or Input Monitoring. Quartz input additionally checks permission to post events.

The optional `ui` skill reports live partial capabilities through `ui.status`; it is disabled
in fresh Agent capability defaults. See the [Desktop UI manual](../manual/content/architecture/40-desktop-ui.md)
for reference lifetime, secure-field behavior, input bounds and platform validation limitations.
