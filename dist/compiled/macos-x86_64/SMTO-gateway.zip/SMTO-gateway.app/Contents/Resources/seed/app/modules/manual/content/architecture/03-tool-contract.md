---
id: tool-contract
title: Tool and Skill contracts
kind: architecture
tags: [architecture, tools]
order: 3
---
# Tool and Skill contracts

`src/agent_runtime/tools.py` defines the only tool contract. A `ToolDefinition` contains:

| Field | Runtime purpose |
| --- | --- |
| `id` | Globally unique canonical domain.operation ID |
| `display_name`, `description` | Human title and model-visible operation description |
| `arguments_schema` | Complete JSON Schema object, validated before dispatch |
| `result_schema` | Optional documentation of result data; adapters and their tests own result validation |
| `effect` | `read`, `write`, `internal` or `dynamic`; internal Agent state mutations default to no confirmation |
| `state_domain` | `external` (default) or `internal`; local state does not advance external-state revisions and cannot enter execution-cache replay |
| `execution_target` | Optional `gateway` or `controller` execution ownership; Gateway tools receive a selected-ID `target` enum in multi-Gateway model schemas, extracted before business argument validation |
| `completion_contract` | Source-owned `synchronous` (default), `managed`, or `explicit` physical completion contract; never supplied by a model or tool argument |
| `cancellation_transport` | Optional `http`, `command`, `email`, `desktop`, `clipboard`, `screen`, `browser` or `ui` delivery choice for cancellation; Proxmox uses the existing Gateway HTTP cancellation path |
| `requires_confirmation` | Additional authorization requirement |
| `availability` | Prerequisite description in discovery |
| `availability_check` | Optional deterministic runtime-context check; returns `available` and a reason when unavailable; excluded from serialization |
| `input_guard` | Optional deterministic rejection before invocation persistence or schema diagnostics; returns a bounded error without reflecting inputs |
| `executor` | Bound deterministic handler returning `ExecutionResult`; excluded from serialization |

A `SkillDefinition` groups tools with `skill_id`, `display_name`, `description`, `availability`, `platforms` and `credential_requirements`. Nonempty `platforms` restricts the API runtime using `sys.platform` values. Gateway target compatibility still belongs to the adapter. The catalog evaluates each tool's local prerequisites from the configured execution context. An unavailable tool remains listed with its reason but contributes no callable schema. A skill is available when at least one of its tools is available; inspect the individual tool states for mixed families such as Python.

Large skills can declare `entry_tool_ids` and a `SkillSectionDefinition` tree.
Each section has a stable `section_id`, direct `tool_ids`, child section IDs and
optional `api_path`. Validation rejects unknown ownership, duplicate sections,
multiply owned children and cycles. Initial preferred-skill exposure and skill
discovery use entry tools; section discovery exposes only direct operations and
child metadata. Availability summaries also use entry tools for these skills.
Skills without entries or sections retain their existing discovery behavior.

`default_enabled=false` prevents legacy opt-out policy upgrades from adding a new
optional skill. Product defaults remain defined by capability policy; registration
alone is not enablement. [Proxmox VE](19-proxmox.md) is the generated API example.

`registered` means a definition exists. There is no separate package installation state in this registry, so discovery does not invent an `installed` flag. Missing OAuth or a database profile may produce `authentication_required` or `configuration_required` while the service remains available. These flags do not grant authorization or promise remote provider health. Adapters enforce credentials, platform and provider scope at execution too.

`result_schema` is descriptive metadata for discovery, tooling, tests and developer readability. Tool adapters own validation and normalization of successful output. The generic `ExecutionEngine` does not validate result data against this schema and does not infer external-effect failure from a schema mismatch. Preserve effect truth even when reporting fails after an external mutation. Adapter contract tests should compare representative successful output with the documented shape.

Registration validates schemas, unique IDs and executable handlers. A package cannot silently replace an existing tool or partially register after a conflict. Historical namespaces and the reserved `__` wire separator are rejected for new definitions. Definitions are source-owned. Registry copies and catalog snapshots prevent accidental mutation of advertised JSON.

Adapters can use an existing deterministic service. They return actual observations, errors or scoped durable job references. They cannot call an auxiliary agent to decide the next operation.

`ExecutionResult.lifecycle` carries the typed `OperationLifecycle` defined in
`execution/lifecycle.py`. It separates outcome, execution liveness, resource claim,
historical effect uncertainty and cleanup. `complete` describes output coverage;
`remote_effect_possible` describes effects and is not evidence that execution is
still running. A normal nonzero shell exit remains a neutral `completed` outcome.

The engine binds lifecycle evidence to the operation identity at the adapter return
boundary. A synchronous return proves that invocation ended; a transport exception
does not. Synchronous inspection of an object whose business status is `running`
does not inherit that object's lifetime. Shell/Python execution uses the managed
contract and requires process or owned-job evidence. A composite adapter such as
`gateway.copy` uses the explicit contract and supplies its own lifecycle. Adapters
that launch continuing external work must opt into managed/explicit ownership and
publish correlated observations; a generic success response is insufficient.

Release requires conclusive inactivity (`ended` or `not_started`) and a released
or absent claim. A failed outcome can release; a successful acknowledgement can
still retain ownership. Contradictory or malformed lifecycle facts remain protected.
Guards that return before dispatch publish a no-start receipt. Runtime exceptions
after dispatch cannot acquire that proof from a worker's failure status.

Scheduling identity is separate from completion evidence. New Namespace V2 profiles
capture a pinned Gateway enrollment (or Controller identity), optional physical alias
and shared-resource claims before admission. Tool arguments and scheduling hints cannot
mint physical identity, erase inferred writes, or waive execution permissions. An opaque
program remains marked as externally unresolved under the default target isolation policy.
Detected external effects with no usable shared key fail admission with a scope action;
they do not reserve a Controller-wide wildcard while waiting.

Every advertised argument must affect execution as documented. Remove historical no-ops; document and reject arguments that do not apply to the selected action. Test observable behavior, including limits, pagination, exact bindings and effect uncertainty.
