/* Shared message clocks. One details popup; refresh timers do not scale with messages. */
(() => {
  "use strict";
  if (window.SMTOMessageTimestamps) return;
  const parse = value => typeof value === "string" && /(?:Z|[+-]\d\d:\d\d)$/.test(value)
    && Number.isFinite(Date.parse(value)) ? new Date(value) : null;
  const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  function format(value, now = new Date(), locale) {
    const date = parse(value);
    if (!date) return "";
    const options = {hour: "numeric", minute: "2-digit"};
    if (!sameDay(date, now)) Object.assign(options, {month: "short", day: "numeric",
      ...(date.getFullYear() !== now.getFullYear() ? {year: "numeric"} : {})});
    return new Intl.DateTimeFormat(locale, options).format(date);
  }
  function details(value, now = new Date(), locale) {
    const date = parse(value);
    if (!date) return "";
    const seconds = Math.floor(Math.abs(now - date) / 1000), direction = date > now ? 1 : -1;
    const [amount, unit] = seconds < 60 ? [seconds, "second"] : seconds < 3600 ? [Math.floor(seconds / 60), "minute"]
      : seconds < 86400 ? [Math.floor(seconds / 3600), "hour"] : [Math.floor(seconds / 86400), "day"];
    const age = seconds < 5 ? "just now" : new Intl.RelativeTimeFormat(locale, {numeric: "always"}).format(direction * amount, unit);
    return `${new Intl.DateTimeFormat(locale, {year: "numeric", month: "long", day: "numeric",
      hour: "numeric", minute: "2-digit", second: "2-digit", timeZoneName: "short"}).format(date)} · ${age}`;
  }
  let popup, active = null, timer = null, pinned = false;
  function close() {
    clearTimeout(timer); timer = null;
    if (active) { active.setAttribute("aria-expanded", "false"); active.removeAttribute("aria-describedby"); }
    if (popup) popup.hidden = true;
    active = null; pinned = false;
  }
  function paintDetails() {
    clearTimeout(timer);
    if (!active?.isConnected || document.hidden) { close(); return; }
    popup.textContent = details(active.dataset.timestamp);
    active.setAttribute("aria-label", `Message time: ${popup.textContent}`);
    active.querySelector("time").textContent = format(active.dataset.timestamp);
    const box = active.getBoundingClientRect(), width = popup.getBoundingClientRect().width;
    popup.style.left = `${Math.max(8, Math.min(box.left, innerWidth - width - 8))}px`;
    const height = popup.getBoundingClientRect().height;
    popup.style.top = `${Math.max(8, box.bottom + height + 8 < innerHeight ? box.bottom + 6 : box.top - height - 6)}px`;
    timer = setTimeout(paintDetails, 60000);
  }
  function show(button, pin = false) {
    if (active !== button) close();
    if (!popup) {
      popup = document.createElement("div"); popup.className = "message-time-details";
      popup.id = "message-time-details"; popup.setAttribute("role", "tooltip");
      document.body.append(popup);
    }
    active = button; pinned ||= pin; popup.hidden = false;
    button.setAttribute("aria-describedby", popup.id); button.setAttribute("aria-expanded", "true");
    paintDetails();
  }
  function create(value) {
    const root = document.createElement("button"), time = document.createElement("time");
    root.type = "button"; root.className = "message-timestamp";
    root.setAttribute("aria-expanded", "false"); root.append(time);
    root.addEventListener("pointerenter", event => { if (event.pointerType !== "touch") show(root); });
    root.addEventListener("pointerleave", () => { if (active === root && !pinned && document.activeElement !== root) close(); });
    root.addEventListener("focus", () => show(root));
    root.addEventListener("blur", () => { if (active === root) close(); });
    root.addEventListener("click", event => {
      event.preventDefault(); event.stopPropagation();
      if (active === root && pinned) close(); else show(root, true);
    });
    root.addEventListener("keydown", event => {
      if (["Enter", " ", "Escape"].includes(event.key)) event.stopPropagation();
      if (event.key === "Escape") { event.preventDefault(); close(); }
    });
    const update = next => {
      const date = parse(next), iso = date?.toISOString();
      root.hidden = !date;
      if (!date) { if (active === root) close(); return; }
      if (root.dataset.timestamp === iso) return;
      root.dataset.timestamp = iso; time.dateTime = iso; time.textContent = format(iso);
      root.setAttribute("aria-label", `Message time: ${details(iso)}`);
      if (active === root) paintDetails();
    };
    update(value);
    return {root, update};
  }
  function metadata(body, label) {
    const root = document.createElement("div"), clock = create(null);
    root.className = "message-time-heading"; root.hidden = true;
    const role = document.createElement("span"); role.textContent = label;
    root.append(role, clock.root); body.before(root);
    return {root, clock};
  }
  function bind({user, answer, userAuthored = () => true}) {
    const userView = metadata(user, "You"), answerView = metadata(answer, "Agent");
    let userAt = null, answerAt = null, identity = null, source = null;
    function refresh() {
      userView.clock.update(userAt); answerView.clock.update(answerAt);
      userView.root.hidden = !parse(userAt) || !userAuthored() || user.hidden;
      answerView.root.hidden = !parse(answerAt) || answer.hidden || !answer.textContent.trim();
      if (active && (userView.root.hidden && userView.root.contains(active) || answerView.root.hidden && answerView.root.contains(active))) close();
    }
    const observer = new MutationObserver(refresh);
    for (const body of [user, answer]) observer.observe(body, {childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ["hidden"]});
    const setUser = value => { if (parse(value)) userAt = value; refresh(); };
    return {
      user: setUser,
      sentAt: () => userAt,
      startedAt: () => answerAt,
      clear() { answerAt = identity = source = null; refresh(); },
      preview(event) {
        const id = event.detail?.call_id || "preview";
        if (source !== "preview" || id !== identity) answerAt = parse(event.detail?.started_at) ? event.detail.started_at : event.timestamp;
        source = "preview"; identity = id; refresh();
      },
      retain(event) {
        const d = event.detail || {};
        if (source !== "retained" || identity !== d.decision_id) {
          answerAt = parse(d.started_at) ? d.started_at : source === "preview" ? answerAt : event.timestamp;
          identity = d.decision_id; source = "retained";
        }
        refresh();
      },
      restore(payload) {
        const clocks = payload?.message_timestamps || payload?.response_metrics?.message_timestamps;
        const timing = payload?.request_runtime_timing || payload?.visualization_snapshot?.request_runtime_timing || payload?.timing;
        setUser(clocks?.user_sent_at || (!userAt && (timing?.submitted_at || (timing?.source !== "run_prepare" ? payload?.created_at : null))));
        if (clocks) {
          answerAt = clocks.assistant_started_at || null;
          identity = payload.response_metrics?.final_response?.decision_id || identity;
          source = identity ? "retained" : "saved";
        }
        refresh();
      },
      event(event) {
        const d = event.detail || {};
        if (event.event_type === "request.task_reserved") setUser(d.accepted_at);
        else if (["request.received", "request.submitted"].includes(event.event_type) && !userAt && d.timing_source !== "run_prepare") setUser(event.timestamp);
        else if (["request.completed", "request.suspended", "request.final_response.updated"].includes(event.event_type)
          && event.parsed_output?.final_response?.trim() && !answerAt) { answerAt = event.timestamp; source = "saved"; refresh(); }
      },
      destroy() { observer.disconnect(); if (active && (userView.root.contains(active) || answerView.root.contains(active))) close(); },
    };
  }
  document.addEventListener("pointerdown", event => { if (active && !active.contains(event.target) && !popup?.contains(event.target)) close(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape" && active) { event.preventDefault(); close(); } });
  let dateTimer = null;
  function refreshDates() {
    clearTimeout(dateTimer);
    if (document.hidden) return;
    for (const button of document.querySelectorAll(".message-timestamp[data-timestamp]")) {
      button.querySelector("time").textContent = format(button.dataset.timestamp);
    }
    const now = new Date(), midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    dateTimer = setTimeout(refreshDates, midnight - now + 20);
  }
  document.addEventListener("visibilitychange", () => { close(); refreshDates(); });
  window.addEventListener("pagehide", close);
  window.addEventListener("pagehide", () => clearTimeout(dateTimer));
  window.addEventListener("pageshow", refreshDates);
  window.addEventListener("resize", close);
  document.addEventListener("scroll", close, true);
  window.SMTOMessageTimestamps = {parse, format, details, create, bind};
  refreshDates();
})();
