/* Shared, text-only completion. Accepting a suggestion never submits a message. */
(() => {
  "use strict";
  const IDLE_MS = 250;
  const controllers = new WeakMap();
  let sequence = 0, items = [], limit = 100, history = () => items, loader, loading;
  const refresh = () => controllers.get(document.activeElement)?.update();
  function configure(options) {
    if (options.getHistory) history = options.getHistory;
    if (options.loadHistory) { loader = options.loadHistory; load(); }
  }
  function load() {
    if (!loader || loading) return;
    loading = Promise.resolve().then(loader).then(payload => {
      if (Number.isInteger(payload.max_items) && payload.max_items > 0) limit = payload.max_items;
      items = [...new Set([...(payload.items || []), ...items].filter(text => typeof text === "string"))].slice(-limit);
      refresh();
    }).catch(() => { loading = null; });
  }
  function remember(text) {
    if (typeof text !== "string" || !text.trim()) return;
    items = [...items.filter(item => item !== text), text].slice(-limit); refresh();
  }
  function create({input, ghost, hint, getHistory = () => history(), setPrompt,
    disabled = () => false, resize, handleKeys = false}) {
    if (controllers.has(input)) return controllers.get(input);
    input.setAttribute("aria-autocomplete", "inline");
    let suggestion = "", prefix = "", dismissed = null, composing = false, disposed = false;
    let timer = null, pendingValue = "", resizeFrame = 0;
    const events = new AbortController(), options = {signal: events.signal};
    const tools = document.createElement("div"); tools.className = "prompt-completion-tools"; tools.hidden = true;
    const accept = document.createElement("button"); accept.type = "button";
    accept.className = "prompt-completion-accept"; accept.textContent = "Complete";
    accept.setAttribute("aria-label", "Complete suggestion");
    const help = document.createElement("span"); help.textContent = "Tab to complete · Esc to dismiss";
    tools.append(accept, help); input.parentElement.append(tools);
    const unavailable = () => disabled() || input.disabled || input.readOnly
      || input.matches(":disabled") || !input.getClientRects().length || Boolean(input.closest("[inert]"));
    // Keep geometry and history scanning out of the input/selection event path.
    const eligible = () => !disposed && !composing && !disabled() && !input.disabled && !input.readOnly
      && input.isConnected && !input.closest("[inert]")
      && dismissed !== input.value && input.value.length >= 3 && !input.value.includes("\n")
      && input.selectionStart === input.selectionEnd && input.selectionEnd === input.value.length
      && !/^[\s]*[/@]/.test(input.value);
    function cancel() { clearTimeout(timer); timer = null; }
    function size() {
      cancelAnimationFrame(resizeFrame); resizeFrame = 0;
      ghost.style.width = `${input.offsetWidth}px`;
      const style = getComputedStyle(input);
      const edges = style.boxSizing === "border-box"
        ? parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth)
        : -parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
      if (resize) resize();
      else if (input.tagName === "TEXTAREA") {
        input.style.height = "auto";
        input.style.height = `${Math.min(input.scrollHeight + edges, 180)}px`;
      }
      if (!ghost.hidden && input.tagName === "TEXTAREA") {
        ghost.style.height = "auto";
        const height = Math.min(Math.max(input.scrollHeight, ghost.scrollHeight) + edges, 180);
        input.style.setProperty("height", `${height}px`, input.style.getPropertyPriority("height"));
      }
      ghost.style.height = `${input.offsetHeight}px`;
      ghost.scrollTop = input.scrollTop; ghost.scrollLeft = input.scrollLeft;
    }
    function clear() {
      cancel();
      const hadSuggestion = Boolean(suggestion);
      suggestion = ""; prefix = "";
      if (!ghost.hidden || !tools.hidden) {
        ghost.hidden = tools.hidden = true; ghost.replaceChildren(); hint.textContent = "";
      }
      if (hadSuggestion && !resizeFrame) resizeFrame = requestAnimationFrame(size);
    }
    function update() {
      if (!eligible() || document.activeElement !== input) { clear(); return; }
      if (suggestion && prefix !== input.value) clear();
      // Background run updates must not postpone completion while the user is idle.
      if (timer !== null && pendingValue === input.value) return;
      cancel();
      pendingValue = input.value;
      timer = setTimeout(render, IDLE_MS);
    }
    function render() {
      cancel();
      if (!eligible() || document.activeElement !== input || unavailable()) { clear(); return; }
      const next = window.SMTOPromptRecall.suggest(getHistory(), input.value);
      if (!next || (input.maxLength >= 0 && next.length > input.maxLength)) { clear(); return; }
      if (next !== suggestion || prefix !== input.value) {
        const span = document.createElement("span"); span.className = "prompt-ghost-prefix"; span.textContent = input.value;
        ghost.replaceChildren(span, document.createTextNode(next.slice(input.value.length)));
      }
      suggestion = next; prefix = input.value;
      const style = getComputedStyle(input);
      for (const property of ["font", "lineHeight", "letterSpacing", "padding", "borderWidth", "boxSizing", "wordBreak", "overflowWrap", "tabSize"])
        ghost.style[property] = style[property];
      ghost.hidden = tools.hidden = false;
      const message = "Prompt suggestion available. Press Tab to complete.";
      if (hint.textContent !== message) hint.textContent = message;
      size();
    }
    function complete() {
      if (!eligible() || unavailable() || !suggestion || prefix !== input.value) { clear(); return; }
      const text = suggestion; clear(); setPrompt(text);
    }
    function keydown(event) {
      if (event.isComposing || composing || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;
      if (event.key === "Tab") {
        // An explicit completion request can flush the latest prefix immediately.
        render();
        if (!suggestion) return false;
        event.preventDefault(); complete(); return true;
      }
      if (event.key === "Escape" && (suggestion || timer !== null)) {
        event.preventDefault(); event.stopPropagation(); dismissed = input.value; clear(); return true;
      }
      return false;
    }
    accept.addEventListener("pointerdown", event => event.preventDefault(), options);
    accept.addEventListener("click", complete, options);
    input.addEventListener("input", () => { dismissed = null; cancel(); update(); }, options);
    input.addEventListener("compositionstart", () => { composing = true; clear(); }, options);
    input.addEventListener("compositionend", () => { composing = false; update(); }, options);
    input.addEventListener("focus", () => { load(); update(); }, options);
    input.addEventListener("blur", event => { if (event.relatedTarget !== accept) clear(); }, options);
    accept.addEventListener("blur", event => { if (event.relatedTarget !== input) clear(); }, options);
    input.addEventListener("scroll", () => { ghost.scrollTop = input.scrollTop; ghost.scrollLeft = input.scrollLeft; }, options);
    input.form?.addEventListener("submit", clear, {...options, capture: true});
    if (handleKeys) input.addEventListener("keydown", event => {
      if (keydown(event)) event.stopPropagation();
    }, {...options, capture: true});
    const controller = {update, clear, keydown, dispose() {
      disposed = true; clear(); cancelAnimationFrame(resizeFrame);
      events.abort(); tools.remove(); controllers.delete(input);
    }};
    controllers.set(input, controller);
    return controller;
  }
  function attach(input, {disabled = () => false} = {}) {
    if (controllers.has(input)) return controllers.get(input);
    let host = input.parentElement;
    if (!host.matches(".steering-input, .prompt-input-wrap")) {
      const wrapper = document.createElement("div"); wrapper.className = "prompt-input-wrap";
      input.before(wrapper); wrapper.append(input); host = wrapper;
    }
    host.classList.add("prompt-completion-field");
    const ghost = document.createElement("div"); ghost.className = "prompt-ghost"; ghost.hidden = true;
    ghost.setAttribute("aria-hidden", "true");
    const hint = document.createElement("span"); hint.className = "sr-only";
    hint.id = `prompt-completion-hint-${++sequence}`; hint.setAttribute("role", "status");
    hint.setAttribute("aria-live", "polite");
    input.setAttribute("aria-describedby", `${input.getAttribute("aria-describedby") || ""} ${hint.id}`.trim());
    host.append(ghost, hint);
    return create({input, ghost, hint, disabled, handleKeys: true, setPrompt(text) {
      input.value = text; input.focus({preventScroll: true}); input.setSelectionRange(text.length, text.length);
      input.dispatchEvent(new Event("input", {bubbles: true}));
    }});
  }
  document.addEventListener("selectionchange", refresh);
  for (const event of ["resize", "smto:immersive", "smto:font-scale"]) window.addEventListener(event, refresh);
  window.SMTOPromptAutocomplete = {create, attach, configure, refresh, remember};
})();
