/* One shared 200 ms clock updates active labels and the compact timing summary. */
(() => {
  "use strict";
  const T = window.SMTOPerformanceTiming;
  const timers = new WeakMap();
  function renderTimer(node, value, {live = false, prefix = "", suffix = ""} = {}) {
    let timer = timers.get(node);
    // Other activity decorators may replace a heading on an incoming tool event.
    if (!timer || timer.root.parentNode !== node) {
      const before = document.createTextNode(prefix), after = document.createTextNode(suffix);
      const separator = document.createElement("span"); separator.className = "timing-separator";
      const root = document.createElement("span"); root.className = "timing-odometer";
      root.setAttribute("aria-live", "off");
      node.replaceChildren(before, separator, root, after);
      timer = {root, before, separator, after};
      timers.set(node, timer);
    }
    // Hide the counter's separator with its digits, preserving the task status.
    const separator = prefix.endsWith(" · ") ? " · " : "";
    if (separator) prefix = prefix.slice(0, -separator.length);
    if (timer.before.data !== prefix) timer.before.data = prefix;
    if (timer.separator.textContent !== separator) timer.separator.textContent = separator;
    if (timer.after.data !== suffix) timer.after.data = suffix;
    window.SMTONumberOdometer.render(timer.root, value, {live, decimalSeparator: "."});
  }

  function create(root, now) {
    const summary = root.querySelector(".timing-summary"), strip = root.querySelector(".timing-spans");
    const values = new Map([...summary.querySelectorAll("[data-timing]")].map(n => [n.dataset.timing, n]));
    const bindings = new WeakMap(), chips = new Map();
    let state = null;
    function paint(span, at) {
      const binding = bindings.get(span);
      if (binding?.node.isConnected) binding.render(at);
      const chip = chips.get(span);
      if (chip) {
        const prefix = span.kind === "model" ? T.activityLabel(span)
          : [span.kind === "sequence" ? "Sequence" : span.label,
          !span.terminal || ["Rejected", "Stopped", "Failed", "Not run"].includes(span.status) ? span.status : ""].filter(Boolean).join(" · ");
        renderTimer(chip, span.notRun ? "" : T.format(T.duration(span, at)), {
          live: !span.terminal, prefix: prefix + (span.notRun ? "" : " · "),
          suffix: span.recovery ? " · Retry" : ""});
        if (span.kind === "model" && span.reason) {
          let reason = chip.querySelector(".timing-rejection-reason");
          if (!reason) {
            reason = document.createElement("span"); reason.className = "timing-rejection-reason";
            chip.append(reason);
          }
          const text = span.status === "Rejected" ? span.reason_long : `Due to: ${span.reason}`;
          if (reason.textContent !== text) reason.textContent = text;
        }
        chip.title = T.detail(span, at);
        chip.dataset.status = span.status.toLowerCase();
      }
    }
    function paintSummary(at) {
      if (!state || summary.hidden) return;
      const totals = T.totals(state, at);
      for (const [key, node] of values) renderTimer(node, totals[key] === null ? "—" : T.format(totals[key]),
        {live: !state.run.terminal});
      summary.title = "Wall-clock time. Thinking and Tools merge overlapping spans; grouped commands are counted once."
        + (totals.incomplete ? " Some historical timing is unavailable; known spans only." : " Other includes runtime and waits.");
      for (const [key, label] of Object.entries({admission_prepare_ms: "Admission preparation", queue_wait_ms: "Queue",
        model_profile_ms: "Model preparation", gateway_preflight_ms: "Target validation",
        native_initialization_ms: "Run initialization", model_scheduler_wait_ms: "Model slot wait",
        accepted_to_first_model_request_ms: "Accepted to first model request"})) {
        if (Number.isFinite(state.startup?.[key])) summary.title += `\n${label}: ${state.startup[key].toFixed(1)} ms`;
      }
    }
    const ticker = T.createTicker({now, tick(at) {
      if (!state) return;
      for (const span of state.active) paint(span, at);
      paintSummary(at);
    }});
    function refresh(changed = []) {
      if (!state) return;
      const at = now();
      for (const span of changed) paint(span, at);
      summary.hidden = strip.hidden = !(state.models.size || state.tools.size);
      const follow = strip.scrollWidth - strip.scrollLeft - strip.clientWidth < 24;
      let added = false;
      const ordered = T.ordered(state).filter(s => !s.parent);
      for (const span of ordered) {
        if (!chips.has(span)) {
          added = true;
          const chip = document.createElement(span.kind === "model" ? "span" : "button");
          if (span.kind !== "model") chip.type = "button";
          chip.className = "timing-span"; chip.dataset.kind = span.kind;
          if (span.kind !== "model") chip.addEventListener("click", () => {
            const binding = bindings.get(span);
            if (!binding?.node.isConnected) return;
            for (let parent = binding.node.parentElement; parent; parent = parent.parentElement) {
              if (parent.tagName === "DETAILS") parent.open = true;
            }
            const disclosure = binding.node.querySelector("details");
            if (disclosure && !disclosure.open) disclosure.querySelector("summary")?.click();
            binding.node.scrollIntoView({block: "nearest", behavior: "instant"});
            binding.node.focus({preventScroll: true});
          });
          chips.set(span, chip); paint(span, at);
        }
      }
      for (const [span, chip] of chips) if (span.parent) { chip.remove(); chips.delete(span); }
      // Preserve focus and historical DOM; only insert/move when chronology changes.
      ordered.forEach((span, index) => {
        const chip = chips.get(span);
        if (strip.children[index] !== chip) strip.insertBefore(chip, strip.children[index] || null);
      });
      if (added && follow) strip.scrollLeft = strip.scrollWidth;
      paintSummary(at);
      ticker.update(state.active.size > 0 || (!state.run.terminal && Number.isFinite(state.run.start)));
    }
    function select(next) {
      if (state === next) return;
      ticker.dispose(); state = next; chips.clear(); strip.replaceChildren();
      summary.hidden = strip.hidden = true;
      if (state) refresh();
    }
    const visibility = () => document.hidden ? ticker.pause() : ticker.resume();
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("pagehide", ticker.pause);
    window.addEventListener("pageshow", ticker.resume);
    return {select, refresh,
      bind(span, node, render) {
        bindings.set(span, {node, render}); render(now());
      },
      dispose() {
        ticker.dispose(); state = null;
        document.removeEventListener("visibilitychange", visibility);
        window.removeEventListener("pagehide", ticker.pause);
        window.removeEventListener("pageshow", ticker.resume);
      }};
  }
  window.SMTOTimingView = {create, renderTimer};
})();
