import { api, node, button, encode, safeUrl } from "../api.js?v=20261018-loading";
import { copyButton } from "../markdown.js?v=20261018-loading";

const cache = new WeakMap();
const documents = new WeakMap();
export async function loadDetail(body, rid, id, version, retryContract, isCurrent = () => true) {
  const busyFeedback = window.SMTOBusy?.begin({host: body, label: "Loading output…"});
  try {
  const previous = cache.get(body);
  if (previous?.version === version && (previous.ready || previous.loading))
    return;
  const request = { version, loading: true };
  cache.set(body, request);
  if (!previous) {
    const loading = node("p", "Loading output…", "muted output-loading");
    loading.setAttribute("role", "status");
    body.replaceChildren(loading);
  }
  try {
    const detail = await api(`trace/${encode(rid)}/invocations/${encode(id)}`);
    if (!body.isConnected || !isCurrent() || cache.get(body) !== request) return;
    body.replaceChildren();
    if (!detail.completed_at) {
      const loading = node("p", detail.tool_family === "task_contract"
        ? "Generating task contract… Partial output is not yet accepted." : "Waiting for tool result…", "muted output-loading");
      loading.setAttribute("role", "status");
      body.append(loading);
    }
    if (detail.tool_family === "task_contract" && detail.retry_task_contract === true && retryContract) {
      const status = node("p", "", "muted"); status.setAttribute("role", "status");
      const retry = button("Retry contract generation", async () => {
 const busyFeedback = window.SMTOBusy?.action("Starting retry…");
 try {
        retry.disabled = true; status.textContent = "Requesting retry…";
        try {
          if (!await retryContract(rid, id)) { retry.disabled = false; status.textContent = ""; return; }
          status.textContent = "Retry requested. This run will continue when contract generation succeeds.";
        } catch (error) { retry.disabled = false; window.SMTOErrors.present(status, error); }

 } finally { busyFeedback?.finish(); }
});
      body.append(retry, status);
    }
    let remaining = detail.tool_family === "task_contract" ? 256 * 1024 : 64000;
    for (const section of (detail.sections || []).slice(0, 16)) {
      if (remaining <= 0) break;
      const text =
          typeof section.data === "string"
            ? section.data
            : JSON.stringify(section.data, null, 2) || "",
        bounded = text.slice(0, remaining);
      remaining -= bounded.length;
      body.append(node("h4", section.label || "Output"));
      const pre = node("pre", bounded, "detail-output");
      body.append(copyButton(async () => {
        if (!section.truncated) return text;
        const full = await api(`trace/${encode(rid)}/invocations/${encode(id)}/sections/${encode(section.id)}/copy`);
        return typeof full.data === "string" ? full.data : JSON.stringify(full.data, null, 2) ?? "";
      }), pre);
      if (section.truncated || bounded.length < text.length)
        body.append(node("p", "Output preview is truncated.", "muted"));
    }
    if (detail.truncated || remaining <= 0)
      body.append(
        node(
          "p",
          "Output is bounded to keep this conversation responsive.",
          "muted",
        ),
      );
    cache.set(body, { version, ready: true });
  } catch (error) {
    if (!isCurrent() || cache.get(body) !== request) return;
    cache.delete(body);
    body.replaceChildren(
      node("p", error.message, "error"),
      button("Retry", () => loadDetail(body, rid, id, version, retryContract)),
    );
  }

  } finally { busyFeedback?.finish(); }
}
export function renderResults(root, document, answer) {
  const previous = documents.get(root);
  if (previous?.document === document && previous.answer === answer) return;
  documents.set(root, { document, answer });
  const sections = (document.sections || []).slice(0, 30).filter((section) => {
    const content = section.content ?? section.text ?? section.preview;
    return typeof content !== "string" || content.trim() !== answer.trim();
  });
  if (!sections.length) {
    root._disclosureAction?.dispose(); root._disclosureAction = null;
    root.replaceChildren();
    return;
  }
  // Keep the disclosure and its summary stable across trace refreshes so the
  // user's open/closed state and keyboard focus are preserved.
  let panel = root.querySelector(":scope > .results-panel");
  if (!panel) {
    panel = node("details", null, "results-panel");
    const summary = node("summary");
    summary.append(node("span", "Results"), node("span", null, "results-count"));
    panel.append(summary);
    root.replaceChildren(panel);
    if (root._actionContainer) {
      root._disclosureAction = window.SMTOConversationSnapshot.disclosureAction({
        actionContainer: root._actionContainer, panel, label: "Results"});
      root._disclosureAction.action.classList.add("run-results-action");
      root._actionContainer.querySelector(".run-checks-action")?.before(root._disclosureAction.action);
    }
  }
  const count = panel.querySelector(".results-count");
  count.textContent = String(sections.length);
  count.setAttribute("aria-label", `${sections.length} ${sections.length === 1 ? "result" : "results"}`);
  const list = node("div", null, "result-list");
  for (const section of sections) {
    const content = section.content ?? section.text ?? section.preview;
    const block = node("section", null, "result-row");
    block.append(node("h3", section.title || "Result"));
    if (Array.isArray(section.rows) && section.rows.length) {
      const wrap = node("div", null, "table-wrap markdown"),
        table = node("table"),
        columns = section.columns?.length ? section.columns : Object.keys(section.rows[0]),
        head = node("tr");
      columns.forEach((c) => {
        const cell = node("th", c);
        cell.scope = "col";
        head.append(cell);
      });
      const thead = node("thead"), tbody = node("tbody");
      thead.append(head);
      table.append(thead, tbody);
      for (const row of section.rows.slice(0, 100)) {
        const tr = node("tr");
        columns.forEach((c) =>
          tr.append(
            node(
              "td",
              typeof row[c] === "object"
                ? JSON.stringify(row[c])
                : (row[c] ?? ""),
            ),
          ),
        );
        tbody.append(tr);
      }
      wrap.append(table);
      block.append(wrap);
    } else if (content != null)
      block.append(
        node(
          "pre",
          String(
            typeof content === "object"
              ? JSON.stringify(content, null, 2)
              : content,
          ).slice(0, 64000),
          "detail-output",
        ),
      );
    const url = safeUrl(section.url || section.href || "");
    if ((section.url || section.href) && url) {
      const link = node("a", "Open file");
      link.href = url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      block.append(link);
    }
    list.append(block);
  }
  panel.querySelector(".result-list")?.remove();
  panel.append(list);
}
