---
id: source-map
title: Source map
kind: architecture
tags: [architecture, tools]
order: 16
---
# Source map

All paths are relative to the repository root.

| Responsibility | Entry point |
| --- | --- |
| API request and trusted context | `src/agent_runtime/api/agent_ui_support/route_groups/request_lifecycle.py` |
| Runtime composition | `src/agent_runtime/api/runtime/engine.py`, `src/agent_runtime/native/host.py` |
| Model calls and next-decision loop | `src/agent_runtime/native/loop.py` |
| Inference feature boundary and lifecycle | `src/smto_runtime/features.py`, `src/controller_inference/integration.py`, `src/controller_inference/manager.py` own build gating, authenticated routes, durable operations, endpoint bindings and coordinated restart/rollback. |
| Shared inference management and tools | `src/inference_portal/inference_portal/management.py` retains portal operations; `src/controller_inference/contracts.py` and `skill.py` expose the same schemas through controller-local tools. See [Inference management](../45-inference.md). |
| Inference UI | `src/controller_inference/static/` composes the shared portal editors with controller themes, model connections and prompt-caching controls. |
| Load/checkpoint/recovery; lease-held inference identity binding | `src/agent_runtime/native/state.py` |
| Required checkpoint policy envelope | `src/agent_runtime/native/snapshot.py` validates presence without inventing authority or migrating state. |
| Uncertain operation provenance and replay scope | `src/agent_runtime/native/unknowns.py`; execution/reconciliation owners establish physical truth. |
| Built-in controls | `src/agent_runtime/native/controls.py` checks the budget before dispatch; `_read_result` handles stored receipts, transcript projection and research/history delegation without creating an execution path. |
| Dispatch and receipt assembly; pure completion projection | `src/agent_runtime/native/operations.py` |
| UI/output projection | `src/agent_runtime/native/publication.py` |
| Native HTTP snapshots and lifecycle controls | `src/agent_runtime/api/agent_ui_support/route_groups/native.py`; `_snapshot_diagnostics` projects already-read diagnostic facts without I/O. |
| Source-owned loop prompt | `src/agent_runtime/native/protocol.py` |
| Tool and Skill schemas | `src/agent_runtime/tools.py`, `src/agent_runtime/skills/<skill_id>/skill.py` |
| Registration | `src/agent_runtime/skills/catalog.py`, `src/agent_runtime/capabilities/registry.py` |
| Capability selection | `src/agent_runtime/capability_policy.py` normalizes the always-selected Agent Introspection, Memory and Shell baseline; `capability_selection.py` freezes the permitted ceiling and expands selections. `native/capability_selection.py` owns per-input selection and catalog binding. Execution restrictions remain separate. |
| Schema exposure/discovery | `src/agent_runtime/native/catalog.py` |
| Tool execution | `src/agent_runtime/execution/engine.py` |
| Safety and authorization | `src/agent_runtime/execution/native_safety.py`, `authorization.py` |
| Exact nested results | `src/agent_runtime/execution/json_pointer.py`, `bindings.py` |
| Completion evidence | `src/agent_runtime/native/completion.py` |
| Receipts and run journal | `src/agent_runtime/current_run/native_store.py` |
| Jobs and wake/resume | `src/agent_runtime/native/jobs.py`, `continuation.py` |
| Conversation storage | `src/agent_runtime/api/chat_store.py` |
| Events, schedules, monitors | `src/agent_runtime/events/`, `monitors/` |
| Task / monitor API ownership | `src/agent_runtime/api/agent_ui_support/route_groups/task_service.py`, `monitor_service.py` |
| Real provider services | `src/agent_runtime/skills/gmail/`, `parameters/`, `skills/database/support/` |
| GitHub provider | `src/agent_runtime/skills/github/` owns fixed REST routes, exact PAT/repository authority, bounded discovery, artifacts and uncertain effects. Parameter Store owns private tokens; Git/Shell remains the local repository owner. See [GitHub](../32-github.md). |
| Shared Google Workspace identity | `src/agent_runtime/auth/google/` owns typed profiles, verified identity, scope policy, account selection and refresh. `auth/browser.py` shares PKCE/callback lifecycle with the legacy Gmail adapter; `skills/auth/google.py` exposes safe management tools. |
| Microsoft 365 | `src/agent_runtime/auth/microsoft/` owns delegated identity and private Parameter Store grants through shared Auth. `src/agent_runtime/skills/microsoft365/` owns live Graph mail/calendar/contacts/files, bounded sections, artifacts and non-replay receipts. No mirror or helper inference. |
| Google Drive | `src/agent_runtime/skills/google_drive/` owns live ID-based reads/writes, narrow/broad mode enforcement, streaming artifacts, multipart/resumable transfers and reconciliation. It reuses `auth/google` and the public artifact APIs; no mirror or helper inference. |
| Gateway execution | `src/agent_runtime/execution/gateway_client.py` owns controller transport; `src/gateway_core/service.py` and `executor.py` own shared dispatch/process execution. Platform packages wrap that implementation. |
| Remote SSH privilege | `src/agent_runtime/execution/sudo_handler.py` owns `normalize_remote`; `execution/ssh_sudo.py` preserves its compatibility import. `src/gateway_core/privilege_target.py` binds target identity; `src/gateway_core/ssh_privilege.py` owns versioned remote sudo and effect evidence. |
| HTTP / REST Skill | `src/agent_runtime/skills/http/request.py`, `src/gateway_core/http_contract.py`, `src/gateway_core/http_client.py` |
| Proxmox entry tools and API sections | `src/agent_runtime/skills/proxmox/skill.py`, `endpoint_factory.py`, `src/agent_runtime/tools.py`, `src/agent_runtime/native/catalog.py` |
| Proxmox guest operations and HTTP session binding | `src/agent_runtime/skills/proxmox/client.py`, `profile.py`, `session.py` |
| Proxmox generated API provenance | `scripts/generate_proxmox_api.py`, `src/agent_runtime/skills/proxmox/generated/` |
| Parameter templates and private accepted values | `src/agent_runtime/parameters/templates.py`, `private_bindings.py`, `references.py` |
| Conversation-owned private resource cleanup | `src/agent_runtime/native/conversation_resources.py` |
| Agent UI and standalone pages | `src/agent_runtime/api/static/agent_ui/` |
| Mobile observation and drafts | `src/agent_runtime/api/static/agent_ui/mobile/streaming.js` fences asynchronous reconciliation by owner identity; `mobile/api.js` preserves draft conversation scope and delegates eligible GET coalescing. |
| Shared command-output observation | `src/agent_runtime/api/static/agent_ui/shell_live_stream.js` owns per-panel streams, bounded transcript and cleanup; `mobile/lazy/shell_live_stream.js` preserves the lazy mobile entry point. |
| Command palette and desktop invocation | `src/agent_runtime/api/static/agent_ui/command_palette.js` hosts the live composer; `api/cli.py` opens its new-conversation URL. See [invocation semantics](41-command-palette.md). |
| State admission and current mode types | `src/agent_runtime/storage_schema.py`, `src/agent_runtime/state_baseline.py`, `src/agent_runtime/core/modes.py` |

Concrete tool adapters call provider/service boundaries. The native loop consumes their
tool contracts and execution receipts; provider-specific transport belongs to the adapter
and service implementation.

## Maintainer route through a request

The paths below are relative to `src/agent_runtime/` unless they name another
package. Risk describes the contract a maintainer must preserve, not a known bug.

| Surface / entry | State or authority owner and collaborators | Observable contract / risk | Focused tests under `tests/` |
| --- | --- | --- | --- |
| API: `api/app.py`, `api/agent_ui_support/routes.py` | Route groups validate inputs; `request_lifecycle.py`, `native_flow.py` bind request/run ownership | Route order, operation IDs, errors, compact/full snapshots and SSE; GET must not dispatch work | `test_native_api_services.py`, `test_conversation_snapshot_owner.py`, `test_native_snapshot_projection.py` |
| Native: `native/state.py`, `loop.py`, `model_decision.py` | Progression lease, accepted policy/model/target snapshots, inference budget | Resume retains authority; reservations precede provider transport; retries cannot execute rejected output | `test_budget_growth.py`, `test_memory_native_interfaces.py` |
| Dispatch: `native/operations.py` | `execution/engine.py` validates/authorizes; native claims bind receipts; Gateway client transports | Save/approval/claim ordering, once-only effects, prompt cancellation, unknown effects | `test_native_behavior.py`, `test_foreground_completion_receipt.py` |
| Server RAM: `runtime_state/hub.py` | `current_run/memory_store.py`, `memory_state.py`; checkpoint worker serializes snapshots | Private drafts until commit, shared Activity identities after publication, no ordinary SQL | `test_memory_native_execution.py`, `test_memory_run_store.py` |
| Gateway: `gateway_core/app.py`, `service.py` | `jobs.py`, `runtime_state/hub.py`, effect fences and `ipc/authority.py` | Owner epoch/ticket/process binding; reattachment never grants a second launch | `test_gateway_ipc_unified.py`, `test_gateway_ipc_crash.py` |
| Gateway wire: `gateway_core/models.py` | Service supplies facts; Pydantic handler owns field selection and conversion | Optional null omissions, explicit false/zero values, unchanged schemas | `test_gateway_observation_serialization.py`, `test_gateway_old_controller_ram_wire.py` |
| Browser: desktop `app.js`, mobile `mobile/app.js` | Per-page stream/draft/render controllers; API remains execution authority | Active versus selected request, stream cleanup, stable globals/DOM and mobile independence | `test_conversation_activity.py`, `test_performance_timing.py`; see [UI map](26-ui-surfaces.md#browser-source-and-lifetime-map) |
| Mobile reconnect: `mobile/streaming.js` | Captured owner identity survives only while attached and undisposed | Late summary/snapshot completion cannot close a replacement; ordinary completion, retry timing and cursors remain intact | `e2e/test_mobile_stream_ownership_playwright.py`; mobile navigation/history cases in `e2e/test_mobile_agent_ui_playwright.py` |
| Skills: `skills/catalog.py`, `capabilities/registry.py` | Explicit `build_skill` registration, optional availability, adapter contracts | Registration order, discovery versus permission, generated schema resources | `test_skill_packages.py`, `test_capability_activation.py` |
| Packaging: root `pyproject.toml`, `packaging/` | `aor` CLI, `gateway_core.serve`, platform startup scripts, worker subprocess entry points | Public imports and executable string paths are reachable without static import edges | `test_gateway_ram_operations.py`, platform installer tests |

Do not split a route factory or registry just to reduce its span. For native
initialization and dispatch, first follow the lease, the first saved claim and the
physical execution boundary. A pure extraction needs before/after payload and
side-effect evidence; moving transaction boundaries requires recovery tests.
See the [dead-path ledger](../../../../docs/engineering/codebase-dead-path-ledger.md)
before deleting compatibility, export or executable-entry modules.

## Controller memory and recovery owners

The `src/agent_runtime/runtime_state/` package documents its memory and recovery
ownership contracts. Follow these boundaries when changing it:

| Concern | Source owner and invariant |
| --- | --- |
| Bootstrap and shutdown | `lifecycle.py` acquires/binds ownership; `bootstrap.py` installs the complete repository graph; `work.py` counts admitted writers before shutdown can release ownership. |
| Publication | `hub.py` freezes/stages values and validates optimistic read dependencies. Snapshot readers capture one published immutable root without joining writer locks. Retryable callbacks must stay free of external effects. |
| Repository shapes | `records.py` maintains rows, grouped keys, indexes and sequences in one transaction. `persistent.py` and `ordered.py` share unchanged structure; `ordered_nodes.py` caches subtree rank and memory costs. |
| Memory diagnostics | `footprint.py` estimates logical retention; `size.py` counts supported JSON payload bytes; `memory_usage.py` samples RSS off-path for observation only. The Controller has no application RAM budget or memory-based task gate. `bootstrap_heap.py` manages the shared startup GC capture. |
| Recovery | `checkpoint.py` publishes complete generations by committing the manifest last. `writer_budget.py` paces serialization; `managed_files.py` retains referenced context/artifact bodies. |
| Permission and SQL boundaries | `security.py` binds exact consent to arguments, targets and live policy scopes. `sqlite_guard.py` fences runtime SQL at open/prepare/cursor steps and grants context-local recovery access. |
| Process and offline ownership | `ownership.py` holds path/inode OS fences; `operator.py` requires an inactive source and a fresh destination for offline copies. Existing operator CLI help remains unchanged. |

Committed recovery files are immutable. The app retains one checkpoint and builds
one temporary replacement using independent inodes. Publication verifies the
replacement, switches the manifest, and retires the old save, legacy database inputs,
and preserved repair copies. `checkpoint_retention.py` owns this rotation. A failed
retirement blocks allocation of another replacement while durability remains visible.

## Current subsystem ownership

| Subsystem | Ownership and relationship |
| --- | --- |
| Task contract | `native/task_contract.py` owns compiler revision acceptance; field helpers read tolerant bookkeeping views. Model schemas guide generation and optional offline diagnostics, not runtime acceptance. The execution task board is separate. |
| Foreground activities | `native/activities.py` validates batches, isolates workers and joins receipts; `parallel_policy.py` supplies the run-wide limit. |
| Dependency scheduling | `native/dependency_graph.py` owns readiness/branch transitions and completion gates; it submits ready work to resource admission. |
| Resource scheduling | `native/resource_scheduler.py` owns queues/claims and persisted admission; `resource_policy.py` resolves capacity policy. |
| Agent Checks and unsafe actions | `runtime_guard_policy.py` resolves named checks; `native/unsafe_actions.py` and execution authorization bind exact invocations to authority. |
| Schema and final-response normalization | `native/schema_correction.py` applies explicit argument rules; `terminal_normalization.py` validates text-only terminal intent through completion authority. |
| Direct completion | `native/direct_completion.py` separates terminal metadata from business arguments and verifies durable evidence. |
| Execution model configuration | `llm/model_configuration.py` owns the catalog, presets and execution scope; `llm/native_tool_client.py` merges validated overrides; `api/agent_ui_support/settings_runtime.py` resolves new-run snapshots from existing discovery metadata. |
| Context projection | `native/compaction.py` budgets model context without summary inference; `projection.py` preserves protocol groups and the durable journal. |
| Working Context and access | `native/conversation_working_context.py` tracks verified reusable setup; `context_read_policy.py` controls projection/access. |
| Proxmox identity and authentication | `skills/proxmox/working_context.py` publishes safe verified identity and checks profile/Gateway revisions. `skills/proxmox/session.py` reuses `native/http_session_state.py` and Gateway HTTP; `native/conversation_resources.py` releases run connections and sessions after committed conversation deletion/abandonment. |
| Typed Parameter Store profiles | `parameters/templates.py` owns version-one drafts and safe model projections; `parameters/private_bindings.py` retains exact accepted private revisions. `parameters/store.py` remains the durable authority. |
| Outbound Email | `skills/email/` resolves fixed sender revisions, approvals, MIME, attachments and delivery receipts. `parameters/email_templates.py` supplies SMTP OAuth presets. `auth/broker.py` owns tokens and exact consent continuation; `skills/email/oauth_transport.py` binds network exchanges to the selected Gateway. `gateway_core/email_runtime.py`, `email_client.py`, `email_staging.py` and `oauth_transport.py` own private dispatch, SMTP, volatile chunk staging and OAuth HTTPS. |
| Durable Memory | `skills/memory/` owns profile-wide JSON, metadata matching and proactive learning instructions; `skills/memory/context.py` pins a metadata snapshot before normal Agent decisions. Automatic mode defers recall until `native/capability_selection.py` binds the accepted selection, which always includes Memory. |
| Agent KV | `kv/store.py` persists conversation-scoped notes with revision and deletion invariants; `skills/kv/tools.py` provides explicit access. |
| Artifacts and output | `artifacts/` owns generated file versions/access/retention; `output_pipeline/` shapes real results for publication. |
| Verified execution cache | `execution_cache/` separates procedure identity, capture/safety, persistence and loop integration; cached knowledge does not prove fresh external state. |
| Progress and timing | `observability/agent_trace.py` and native publication produce trace/activity facts; UI inspectors and execution diagrams render projections. |
| Desktop composition | `api/static/agent_ui/` owns workspace, settings, policy, Gateway Management, conversation navigation and inspector/diagram interactions. |
| Dedicated mobile composition | `api/static/agent_ui/mobile/` owns a separate composer/conversation/streaming page and lazy panels over shared APIs. |
| Conversation history activity | `api/agent_ui_support/conversation_activity.py` projects existing run ownership; `conversation_management.py` supplies index/search metadata; desktop `conversation_management.js` and mobile `lazy/history.js` render selection and execution independently. |
| Browser automation | `skills/browser/` owns opt-in metadata and dispatch; `gateway_core/browser/` owns lazy Playwright lifecycle, closed contracts, semantic revisions and file exports. Gateway routing, content policy and artifact collection retain shared ownership. |
| Screen observations | `skills/screen/` owns opt-in tools; `gateway_core/screen_contract.py`, `screen_service.py`, `screen_worker.py`, `platform_screen/` and `ocr/` own bounded explicit acquisition. Shared content policy excludes transient payloads. |
| Current clipboard | `skills/clipboard/` owns the opt-in skill; `gateway_core/clipboard_contract.py`, `clipboard_service.py`, `clipboard_worker.py` and `platform_clipboard/` own bounded wire/native execution. `observability/content_policy.py` excludes payloads from diagnostic copies. |
| Desktop control | `skills/desktop/` owns the opt-in skill and receipt adapter; `gateway_core/desktop_contract.py`, `desktop_service.py` and `platform_desktop/` own structured wire validation, cancellation and native host operations. |
| Gateway core and wrappers | `gateway_core/` owns shared target execution; `gateway_agent/`, `gateway_macos/`, `gateway_windows/` supply platform configuration and lifecycle. |
| Resource lifecycle and recovery | `gateway_core/jobs.py` owns admission, observation CAS and baseline persistence; `resource_claims.py` versions effect/ownership facts; `resource_descriptors.py` derives target resources using shared `execution/resources.py` overlap. `resource_execution.py` closes foreground supervision; `native/resource_recovery.py` owns saved candidate continuation, bounded wait watches and UI decisions. The existing resource reconciliation route serializes baseline, stop and explicit candidate-scoped risk decisions. |
| Manual and source reference | `manual/source_contracts.py` defines Tier A/B inventory; `source_catalog.py` renders contracts/relationships; `documentation_audit.py` verifies coverage. |
| Diagnostic console | `agent_runtime/console/` serves process/resource diagnostics; `startup.sh` supplies the Agent target PID. |
| Independent public website | `smto_site/app.py` serves public product/docs/download pages on 8017. `content.py` enforces explicit publication; `releases.py` validates local metadata. It owns no runtime state or credentials and never calls a Gateway or model. See `docs/smto-site.md`. |
| Identity | `agent_runtime/branding.py` resolves presentation metadata while compatibility interfaces retain legacy identifiers. |

For `native/`, `kv/`, `skills/`, `capabilities/` and similar package paths above, the base is
`src/agent_runtime/`; Gateway and manual packages are directly under `src/`.
Use the served [exhaustive source catalog](/manual#doc=generated-source-modules) for
all maintained files and [source relationships](/manual#doc=generated-source-relationships)
for static imports and explicit collaborator contracts. Static edges are not a call graph.

| Credential interaction owner | Responsibility |
| --- | --- |
| `native/catalog.py`, `native/human_input.py` | One ordinary question/reply; next normal Agent decision interprets literal input. |
| `gateway_core/http_auth/connection.py` | Literal connection schema/compiler. |
| `gateway_core/http_auth/values.py` | Shared authentication leaf discovery, missing-value detection and copied transient overlays. |
| `native/http_connections.py` | Run, Gateway, origin and saved-profile revision binding. |
| `native/http_session_state.py` | OAuth and HTTP session lifecycle only. |
| `native/unsafe_actions.py`, `execution/unsafe_authorization.py` | Approval-only unsafe actions and bounded, proven-unexecuted retry authority. |
| `native/authority_control.py` | Runtime-owned capability, permission, unsafe and Agent Check checkpoint lifecycle; safe envelopes and common reply identities. Domain policy owners retain their rules. |
| `gateway_core/http_profiles.py`, `native/http_session_state.py` | Current HTTP v3 validation and OAuth session/expiry lifecycle. |

| Desktop UI automation | `skills/ui/` owns opt-in metadata and dispatch; `gateway_core/ui/` owns closed contracts, expiring references, native UIA/AX/AT-SPI adapters, deterministic waits and input release. Shared Gateway routing, authorization, Error Catalog and content policy remain authoritative. |
