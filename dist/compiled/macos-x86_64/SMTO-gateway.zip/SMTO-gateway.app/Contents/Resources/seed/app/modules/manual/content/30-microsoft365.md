---
id: microsoft365
title: Microsoft 365
kind: manual
tags: [manual, microsoft365, outlook, graph, oauth, integrations, artifacts]
order: 30
---
# Microsoft 365

The `microsoft365` skill operates live Outlook mail, calendars, personal contacts,
OneDrive and authorized SharePoint libraries through Microsoft Graph v1.0. Enable
Microsoft 365 in the existing Capability Policy. Installing it does not change
saved capability snapshots or request consent. Microsoft remains the source of truth;
there is no mailbox mirror, file index, crawler or background token poll.

## Register and connect

Create your own application in Microsoft Entra **App registrations**. Choose supported
account types deliberately: a tenant UUID/domain, `organizations`, `consumers`, or
`common`. SMTO never changes a tenant to `common`. The implementation supports
the global Microsoft cloud, not national-cloud endpoints or app-only/client-credentials
access. Work/school and personal accounts can use the supported delegated resources;
SharePoint site search and multi-user free/busy require work/school accounts.

In Parameter Store, select **Microsoft OAuth App**. Enter the registration's client ID,
tenant, and client type:

- **public**: register the exact `http://localhost:8400/oauth/callback` URI as a mobile/
  desktop redirect. The controller binds that loopback port during consent. You may
  configure another explicit localhost port. Use a browser on the controller machine.
  No client secret is needed or accepted for this type.
- **confidential**: register a Web redirect such as
  `https://your-controller/api/agent/microsoft365/oauth/callback`, and save the private
  client secret. Local development may use an HTTP localhost/127.0.0.1 callback.
  The browser must reach that controller. Reverse-proxy URL reconstruction must match
  the registered URI exactly. SPA redirects are not supported.

Use the normal Agent or the connection tool:

```json
{"auth_app_ref":"microsoft_app","account_key":"work_microsoft","features":["mail_read"]}
```

`microsoft365.connect` returns an expiring same-origin link. Open it and approve
Microsoft's consent screen. The shared Auth browser lifecycle creates random state,
PKCE S256 and OIDC nonce, consumes state once, and expires it after ten minutes. The
provider verifies the signed ID token (issuer, audience, lifetime, nonce, tenant and
object ID), then requires Graph `/me` to return that same object. Only then does
Parameter Store receive the account. Microsoft app registration/tenant policy can
require administrator consent even for delegated requests.

OAuth protocol and JWT verification reuse the existing Auth implementation. A separate
MSAL credential cache is not installed. Browser handshakes remain private memory;
Parameter Store remains the sole token authority. Public profiles and account results
omit access tokens, refresh tokens and client secrets regardless of optional redaction
settings. The normal explicit Parameter Store credential-editing workflow remains the
operator's configuration surface.

## Features and delegated scopes

Verified against Microsoft Learn on **2026-10-01**. Each feature requests the following
scope, in addition to identity/session scopes `openid`, `profile`, `offline_access`
and `User.Read`. `Mail.Read` and `Calendars.Read` are needed for this skill's body reads;
metadata-only permissions such as Mail.ReadBasic/Calendars.ReadBasic do not cover the
whole respective read feature.

| Feature | Requested delegated Graph scope |
| --- | --- |
| `mail_read` | `Mail.Read` |
| `mail_write` | `Mail.ReadWrite` |
| `mail_send` | `Mail.Send` |
| `calendar_read` | `Calendars.Read` |
| `calendar_write` | `Calendars.ReadWrite` |
| `contacts_read` | `Contacts.Read` |
| `contacts_write` | `Contacts.ReadWrite` |
| `files_read` | `Files.Read` |
| `files_write` | `Files.ReadWrite` |
| `sharepoint_read` | `Sites.Read.All` |
| `sharepoint_write` | `Sites.ReadWrite.All` |

Mailbox write authority does **not** permit sending. OneDrive grants do **not** permit
site discovery. Existing broader read/write grants can satisfy their corresponding
read feature; new requests never silently add those broader grants. The actual token
response determines stored `granted_scopes` and derived `authorized_features`.

To add access, explicitly call `connect` again with the same app and `account_key` and
the additional features. Consent includes the previously granted scopes so an upgrade
does not accidentally remove existing authority. A different signed-in tenant/user
cannot overwrite that account. Refreshes serialize per database/account, retain an
omitted refresh token, persist rotated refresh tokens, and use revision-fenced writes.
Revoked refresh authorization requires reconnecting.

`accounts` and `connection_status` expose safe identity, feature and expiry metadata.
They distinguish configured accounts from authorization and do not claim a network
probe. Use exact `account_ref` when several accounts qualify. Accepted Parameter Store
bindings take precedence over the unique-account convenience; an explicit account with
missing permission is never substituted. Exactly one eligible account may be selected
when no identity is supplied. `disconnect` clears local tokens and grants but does not
revoke Microsoft's remote consent. Remove the profile using Parameter Store when desired.

## Discovery and operations

Entry tools are `accounts`, `connect`, `mail_search`, `calendar_events`, `file_search`.
All IDs below have the `microsoft365.` prefix. Discover the relevant bounded section.

| Section | Tool suffixes |
| --- | --- |
| `connection` | `accounts`, `connect`, `connection_status`, `disconnect` |
| `mail_read` | `mail_folders`, `mail_search`, `mail_read_message`, `mail_read_conversation`, `mail_attachments`, `mail_download_attachment` |
| `mail_write` | `mail_create_draft`, `mail_update_draft`, `mail_delete_draft`, `mail_send_draft`, `mail_send`, `mail_reply`, `mail_reply_all`, `mail_forward`, `mail_move`, `mail_copy`, `mail_mark_read`, `mail_flag`, `mail_delete` |
| `calendar_read` | `calendars`, `calendar_events`, `calendar_read_event`, `calendar_availability` |
| `calendar_write` | `calendar_create_event`, `calendar_update_event`, `calendar_delete_event`, `calendar_cancel_event`, `calendar_respond` |
| `contacts_read` | `contact_folders`, `contact_search`, `contact_read` |
| `contacts_write` | `contact_create`, `contact_update`, `contact_delete` |
| `files_read` | `drives`, `sites_search`, `file_list`, `file_search`, `file_info`, `file_download`, `file_copy_status` |
| `files_write` | `file_upload`, `folder_create`, `file_move`, `file_copy`, `file_delete` |

Lists return one page, default 25 and maximum 100 items, plus `cursor`, `has_more` and
`complete`. Continue with the same account, operation, filters and limit. Opaque cursors
expire after 15 minutes or service restart; Graph nextLink URLs are never model context.
There is no automatic mailbox/site traversal. Individual strings and nested collections
are bounded; JSON provider responses are limited to 2 MiB and mail/event bodies to
50,000 characters. Bodies are plain text, including text extracted from HTML with
script/style contents removed. Search returns previews rather than all message bodies.

Mail search accepts structured sender, recipient, subject, date, read-status and
attachment filters. Free `query` uses Graph search syntax and cannot be mixed with the
structured filters; folder scope and pagination remain available. Draft creation accepts
conversation-owned artifact attachments. Draft updates edit content/recipients; replace
an attachment set by creating and reviewing a new draft. Send exact reviewed draft IDs.
Direct send/reply/reply-all/forward require Mail.Send. Delete uses Graph's normal deletion
semantics; no permanent-delete or unbounded bulk tool is exposed.

Contacts are personal Outlook contacts, including folder-scoped searches. Duplicate
names remain distinct exact contact IDs. No directory-wide permission or deduplication
model is used.

## Calendar time and recurrence

Supply `start`, `end`, and `timezone` together for event time changes. List windows are
bounded to 366 days. IANA timezone identifiers are supported through the controller's
timezone database. The Windows aliases in `calendar.WINDOWS` cover UTC, major North
American zones, London, Berlin, Paris, India, China, Japan, Singapore, Sydney, Auckland
and Johannesburg; for other Windows names, supply the equivalent IANA identifier.

DST gaps are rejected. Repeated local times require an explicit matching UTC offset.
Ordinary appointments retain the named zone; an explicitly selected repeated-time
occurrence is sent in UTC to preserve the selected instant. Daily/weekly recurrence
retains local wall-clock time across DST, takes an interval and exactly one of `count`
or `until`, and requires weekdays for weekly patterns. Recurring boundaries at a DST
fold are rejected because Graph's wall-clock recurrence cannot retain that fold choice.

For all-day events use dates, `is_all_day=true`, the explicit timezone and an exclusive
end date. Read results retain series-master/occurrence identity; changes act only on
the exact ID supplied. `calendar_cancel_event` invokes organizer cancellation;
`calendar_respond` supports accept/tentative/decline. Attendees and online meeting
creation are explicit inputs. Online meeting metadata uses the event API, not Teams
chat/channel permissions.

`calendar_availability` returns structured free/busy, not scheduling advice. Graph's
getSchedule supports organization accounts, at most 20 attendees and a window shorter
than 62 days. Personal accounts should inspect `calendar_events` for their own availability.

## OneDrive, SharePoint and artifacts

File operations default to the signed-in user's OneDrive. Supply exact `drive_id`,
`site_id`, `item_id` and parent IDs for other resources. A supplied site and drive must
identify the same SharePoint site. Site access is limited by both the delegated grant
and the signed-in user's provider permissions; do not infer access from a site name.
Moving files acts within the selected drive; copying can specify a destination drive.

Downloads stream into sensitive conversation-owned artifacts. Attachment downloads are
limited to 25 MiB; cloud downloads/uploads to 250 MiB (subject also to artifact quotas).
Filenames are reduced to safe leaf names with Windows reserved-name handling. No binary
payload is returned inline to the Agent. Download redirects and upload session URLs stay
private and receive no Graph bearer header. Transfers accept only pinned global
Microsoft provider host families.

Upload sources must be `artifact://` or `artifact-workspace://` references in the current
conversation. Register files from another Gateway through the existing artifact/Gateway
handoff first. Source bytes are checked against the artifact's size and SHA-256.
Up to 4 MiB uses a single content upload; larger files use a Graph upload session with
3.125 MiB chunks (multiples of 320 KiB). A lost intermediate chunk is continued only if
session status proves its accepted offset. Sessions are not persisted across restarts.
Mail's JSON attachments are limited to 3 MiB total.

Uploads fail on name conflicts by default. Explicit replacement requires an observed
ETag and uses the existing unsafe-action authority in addition to ordinary write
confirmation. File moves/updates/deletes read current ETags and use conditional requests
where the provider supplies them. A stale supplied ETag fails before writing; a provider
412 is reported distinctly. This protects against intervening changes after readback,
not semantic conflicts in user intent.

Copies are asynchronous: `file_copy` returns `copy_pending` and an opaque `copy_handle`.
Poll `file_copy_status`; do not restart the copy. Public sharing-link creation, permission
changes, SharePoint crawling, Teams messaging and bulk operations are outside this surface.

## Failure and effect semantics

Tools declare external read/write effects. Connect/disconnect and all mutations require
the existing native confirmation policy; the skill adds no second confirmation dialog.
GETs and the read-only getSchedule POST may retry twice for transport failure, throttling
or selected 5xx. Retry-After is honored; delays over 30 seconds are returned for later
retry rather than shortened. A definite 401 permits one synchronized refresh. Each HTTP
exchange has a 60-second hard socket deadline; a tool's transfer client has a 15-minute
total ceiling and observes native cancellation.

A transport failure or 5xx after a mutation may mean the effect happened. Such writes
are never generically retried. Desired-state PATCH operations can be read back to prove
the supplied fields. Event creation returns its transaction ID when the result is
unknown. Send acceptance is not proof of delivery, and a lost send response is never
reported as successful delivery. Unknown results carry native `unknown_effect` receipts,
so the runtime's existing replay guard blocks repeated identical calls. Inspect Sent
Items, the exact resource or transaction evidence before authorizing another action.

Canonical `microsoft365.*` errors distinguish missing app/account, ambiguity, scope,
tenant/identity mismatch, invalid consent state, revoked authorization, forbidden sites,
404, conflict, precondition failure, throttling, invalid timezones, transfer bounds and
unknown effects. Consult the generated error manual or the returned remediation.
Provider messages, tokens, authorization headers, raw codes/verifiers and full response
bodies are excluded from diagnostics. Microsoft tool content participates in the shared
structural content-omission policy; credential reflection is redacted unconditionally.
Mail, calendar text, contacts and file metadata remain untrusted external data. Only the
normal Agent interprets it. Provider authentication, shaping, retries and reconciliation
make zero helper-model calls.

## References and verification

Microsoft references checked on 2026-10-01:

- [Authorization code and PKCE](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow), [MSAL Python token acquisition](https://learn.microsoft.com/en-us/entra/msal/python/getting-started/acquiring-tokens).
- [Delegated permissions](https://learn.microsoft.com/en-us/graph/permissions-reference), [mail lists](https://learn.microsoft.com/en-us/graph/api/user-list-messages?view=graph-rest-1.0), [draft send](https://learn.microsoft.com/en-us/graph/api/message-send?view=graph-rest-1.0).
- [Calendar view](https://learn.microsoft.com/en-us/graph/api/user-list-calendarview?view=graph-rest-1.0), [getSchedule](https://learn.microsoft.com/en-us/graph/api/calendar-getschedule?view=graph-rest-1.0), [timezones](https://learn.microsoft.com/en-us/graph/api/resources/datetimetimezone?view=graph-rest-1.0).
- [Contacts](https://learn.microsoft.com/en-us/graph/api/user-list-contacts?view=graph-rest-1.0), [file search](https://learn.microsoft.com/en-us/graph/api/driveitem-search?view=graph-rest-1.0), [site search](https://learn.microsoft.com/en-us/graph/api/site-search?view=graph-rest-1.0).
- [Downloads](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content?view=graph-rest-1.0), [upload sessions](https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0), [asynchronous copy](https://learn.microsoft.com/en-us/graph/api/driveitem-copy?view=graph-rest-1.0).
- [Throttling](https://learn.microsoft.com/en-us/graph/throttling), [error responses](https://learn.microsoft.com/en-us/graph/errors).

Mandatory tests use signed fake OAuth, deterministic Graph fixtures, a local HTTP server
and real desktop/mobile UI surfaces. No live tenant is required. Optional live testing
must use a dedicated test account/tenant and disposable resources; never run destructive
checks on a developer's personal mailbox, calendar or OneDrive.
