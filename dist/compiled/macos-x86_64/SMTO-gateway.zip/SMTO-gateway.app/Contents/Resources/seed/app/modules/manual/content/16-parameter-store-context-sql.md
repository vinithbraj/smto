---
id: parameter-store-context-sql
title: Parameters and Database
kind: manual
tags: [manual, parameter-store, metadata, context-json, database]
order: 20
---
# Parameters and Database

Parameter profiles store reusable values, metadata, aliases and context JSON. Open Parameter Store at `/parameter-editor` to manage them, then reference a key with `@name` in Chat. Ordinary parameters supply prompt content; recognized typed credential profiles supply a safe identity projection and a private execution binding.

`database.discover_schema` and `database.execute` use the existing PostgreSQL implementation. The model first discovers the tools, selects the scoped profile and sends concrete SQL. The execution layer validates SQL and mutation authorization. Account/profile resolution remains separate from model tool selection.

Context JSON and parameter metadata are useful facts for the model. They do not select a tool before the model sees the user's request. Ordinary requests such as “query the research database” enter the agent loop.

Open Parameter Store from Directory. Search by key or filter by tag, select a profile, or use New to create one. Enter a key and a non-empty Value JSON object, add optional context or agent guidance, and save. Direct links such as `/parameter-editor?key=canonical_v1` select a profile. Save updates the value, description, aliases, tags, and context fields. Existing values stay hidden in the editor until you choose Reveal & edit value; saving metadata while hidden preserves the stored value.

Use context summary and prompt guidance for compact domain guidance, clarification guidance for ambiguity handling, and concepts, metrics, and relationships for structured domain facts. Advanced context JSON preserves additional non-secret metadata. Invalid JSON blocks saving. Unsaved edits are protected when navigating between profiles, and Ctrl/Cmd+S saves.

## Default output directories

These entries are added automatically when the Parameter Store opens, including
existing installations. Users do not need to create them. Search for their names
or environment variables in the composer's Parameter Store menu.

| Reference | Meaning | Gateway environment variable |
| --- | --- | --- |
| `@run_temp_directory` | Collected temporary files shared across commands in one run, such as commit messages and helper scripts | `OF_RUN_TEMP_DIR` |
| `@artifact_output_directory` | Final deliverables to display or download, such as plots and reports | `OF_RUN_ARTIFACT_DIR` |
| `@activity_temp_directory` | Collected temporary files for the current execution activity; may change between tool calls | `TMPDIR` on Linux/macOS, `TEMP`/`TMP` on Windows |

For example: **Plot x+y=1, save the PNG in @artifact_output_directory, and show me
the image.**

These entries store environment-variable references and usage guidance, not fixed
filesystem paths. Shell/Python reads the variable during execution on the selected
Gateway. Accepting or queuing a task does not freeze a previous run's directory.
For example, Python uses `Path(os.environ["OF_RUN_ARTIFACT_DIR"]) / "plot.png"`.
The Gateway supplies these variables; users do not need to set `TEMPDIR` or create
an arbitrary `/tmp` directory. Missing entries are restored the next time the store
opens; existing values and user edits are preserved.

## JSON templates and typed profiles

The selector beside **New** offers **Blank**, **Server**, **Proxmox Server**,
**Credential**, **Git Repository**, **Gmail OAuth App**, **Gmail Account**, **Google Workspace OAuth App**, **Google Workspace Account**, and **HTTP Connection** with Basic, Bearer, API Key, Session Login and OAuth2 starters. Choose a template and click **New** to
prefill an unsaved draft (HTTP uses structured fields; other templates use Value JSON);
Format JSON, Save, masking and Reveal & edit value retain their existing roles.
Selecting a template does not save a record, open a connection or enable a skill.

Recognized `server_connection`, `credential`, `git_repository`, `gmail_oauth_app`, `gmail_account`, `google_oauth_app` and `google_account` profiles use
`profile_version: 1`. Save validates required fields, types and unknown fields.
Server profiles require HTTPS, a hostname/IP without a URL path, an integer port
from 1 to 65535 and a Boolean `verify_tls`. Proxmox accounts include their realm,
such as `root@pam`. Credentials belong in the password/token fields, not an
embedded Git URL. Validation errors identify the field and rule without echoing
private values. Untyped arbitrary JSON retains its previous behavior.

See [Using Proxmox VE](24-proxmox.md) for the optional, disabled-by-default skill
and [Proxmox authentication](architecture/19-proxmox.md#authentication-and-session-state)
for secure input, session renewal and cleanup.

## Saved HTTP connections

Choose **HTTP Connection** (or an auth starter) beside **New**, enter a key such as
`production_api`, then open the **HTTP Connection** tab. Configure the base URL,
authentication, TLS and read-only test endpoint, and **Save**. HTTP uses its own
`profile_version: 2` validator and is always a sensitive/private typed profile.
Templates contain public configuration and secure slot names, never credentials.

Use **Set credentials** or **Replace credentials** on the saved Parameter. Fields
come from the HTTP runtime and always start empty. **Test connection** runs the
configured bounded GET/HEAD/OPTIONS request from your selected or default Gateway.
Opening a profile never tests it or authenticates automatically. **Disconnect
Session** clears runtime authentication while retaining the Parameter and its
saved credentials. You can edit metadata, rename, copy the `@` reference, and
delete using normal Parameter controls. Deletion also invalidates sessions.

Public edits preserve credentials when base URL, auth, TLS, proxy and allowed
origins are unchanged; changes to those security identities drop saved credentials.
Profile and metadata edits save together. **Public profile JSON** shows the public
configuration. The separate advanced raw reveal is explicit and audited; replacing
a raw value replaces the whole record value, including its credentials.

For example: **Use @production_api and GET /health.** The model sees the exact
canonical key, base URL, auth/TLS type and credential status. It calls
`http.request(profile_key="production_api", method="GET", url="/health")`; saved
credentials stay private. HTTP requests resolve the current saved record, and
stale runtime recipes fail their existing revision checks after edits or rename.

Existing saved HTTP connections already reside in Parameter Store. They appear
here without copying, re-keying or migration. There is no separate HTTP editor in
Settings. One-off `http.connect` handles (`http_conn_*`) remain temporary, scoped
to the current run, Gateway and origin; they do not create Parameters. See the
[HTTP / REST guide](architecture/18-http.md) for auth, sessions and transport.

## Accepted references and private values

Use `@` in the composer, select **Parameter Store**, then select a key to insert a short reference such as `@ronan_server`. You can also type `@rona` to search directly, or paste the complete reference. The menu shows field names. Aliases, descriptions, and tags help with search; submitted references resolve the canonical key exactly.

A reference deterministically adds a **Parameters** section before the model's first decision. For ordinary untyped entries it includes the whole Value JSON, full Context JSON (including agent and clarification guidance), description, aliases and tags as user-provided prompt content. An older entry's `sensitive` flag alone does not change those prompt semantics.

Typed and untyped references both capture literal accepted values in the run checkpoint.
PARAMETERS optionally masks the model-facing copy, independently of MODEL_INPUT.
Sensitive-record metadata controls only that record's projection and never promotes
ordinary values such as `https` or `local` into global replacement material. Reference
resolution adds no model call. Typed profiles use ordinary environment export.

Manual tasks capture parameters when accepted, including time spent in the queue. Editing or deleting a parameter does not change an accepted task. New tasks use current values. Scheduled tasks keep symbolic references and capture current values for each occurrence, including one-time future tasks. For ordinary JSON values, resuming or continuing a task reuses its persisted contents, including after restart. Tasks captured using the former reference format must be submitted again; their old bindings are never silently reinterpreted.

New typed snapshots survive restart, edit and deletion using their accepted literal
record. Legacy opaque handles can only recover the exact saved store revision;
missing historical values are not fabricated. Parameter storage remains plaintext.
See [Redaction](architecture/31-redaction.md) for optional visibility controls.

The keys `gateway`, `context`, `file`, `artifact`, `parameter`, and `parameters` are reserved, regardless of case or surrounding whitespace. Existing conflicting entries remain manageable; rename them before selecting them with `@`. Keys containing spaces use their normalized form in references, such as `@my_server`. Dots and colons inside a key are literal parts of its name; `@key.field` does not select a field. Emails, escaped references, inline code, and fenced code remain literal text. References follow the composer's existing whitespace boundary rule.

Unknown names and invalid reference tokens remain unchanged in the prompt and do not stop execution. For example, `curl --data @payload.json` stays literal when no `payload.json` parameter exists, and `npm install @scope/package` stays literal because the package name is not a valid parameter key. Mixed prompts resolve existing canonical keys and keep other tokens as text, without a warning or confirmation. Misspelled or deleted names also become literal text; the runtime never guesses a similar key.

If nothing resolves, no Parameters section is added and no parameter usage is recorded. The empty accepted snapshot is preserved across retries, queue dispatch, restart, resume, and Continue, even if a matching parameter is created later. New tasks and each scheduled occurrence use the names currently in the store. A pasted name that already matches a saved key still resolves; wrap commands in inline backticks or a fenced code block to force literal treatment.

Disabled or unavailable storage, invalid stored JSON, and bindings larger than the configured parameter context limit still stop the task before inference. Restore the store or correct the referenced objects; the runtime never truncates JSON.


Gmail OAuth App stores the existing Google application's configuration. `gmail.connect`
creates the Gmail Account parameter after consent. Account projection includes email,
linked app and authorization state, omitting OAuth secrets. Automatic refresh updates
the same account record. Unlike a fixed connection snapshot, Gmail resolves the current
account authorization on every provider call; rename/deletion takes effect immediately.
Multiple Gmail accounts are normal separate parameters. See [Gmail Integration](21-gmail-integration.md).

## Transient Database authentication

`database.discover_schema` and `database.execute` use the selected profile's
configured `host`, `port`, and `dbname`. Optional `auth_values` accepts only literal
`user` and `password` strings for that invocation. Historical profile aliases remain
readable, but tool arguments use the canonical `user` spelling.

Missing authentication returns `credential_required` with `missing_fields` and
`executed=false`. The Agent uses ordinary `ask_user` to request all missing values
in one reply, then retries with `auth_values` on its next normal decision. These
values do not update Parameter Store, schema metadata, or Working Context. To save
a value, explicitly edit the parameter. Missing host/port/dbname instead returns
`database_profile_incomplete`; correct the profile or select another configured
profile. A transient password cannot change the database target. SQL validation
and mutation approval still apply. Database redaction affects projections only;
the Gateway receives the same literal execution environment with redaction on/off.

## Auth and Email profiles

Version-one `oauth2_client` and `oauth2_connection` profiles configure shared OAuth/OIDC
authorization; `email_smtp` fixes an outbound sender and SMTP transport. Their templates
are detached prefills. Private fields in these profiles are excluded from model bindings,
audits and shell environments independently of optional redaction. Read
[Authentication and outbound Email](26-auth-and-email.md) for setup, callback URLs,
provider defaults, attachment limits and uncertain-delivery handling.

## Shared Google Workspace profiles

`google_oauth_app` contains the registered desktop/web client and selected feature IDs;
`google_account` contains provider-verified subject/email, granted scopes, derived features
and private tokens. Both use version 1, strict unknown-field rejection and unconditional
safe projections. `auth.google_connect` creates or updates the account through Parameter
Store only. OAuth refresh uses transactional compare/update checks against account and app
revisions; neither discovery nor template selection migrates existing Gmail profiles.
See [Shared Google Workspace identity](27-google-workspace.md) for setup and scope policy.

## Microsoft 365 profiles

The [Microsoft 365 integration](30-microsoft365.md) adds `microsoft_oauth_app` and
`microsoft365_account`. Public PKCE requires no client secret. Account access/refresh
tokens and confidential-client secrets remain private even when ordinary redaction is
disabled. Use the same account key for reconnect or incremental consent.

## Slack profiles

The [Slack integration](31-slack.md) adds `slack_oauth_app` and `slack_workspace`.
The app stores a private client secret and explicit bot/user scope selections.
Each workspace profile pins one verified team and principal; access and rotation
tokens remain private. Configure a registered HTTPS callback, then use
`slack.connect`. Disconnect clears local credentials without uninstalling the app.

The [GitHub integration](32-github.md) adds `github_account` for exact github.com user PAT
authority, separate from the existing `git_repository` transport profile. Its `token` is
always private. The profile records login/account ID, an explicit repository allowlist,
declared permissions and a deliberate fine-grained or classic credential type. Store
timestamps own creation/update history. Accepted references cannot expand capability policy.
