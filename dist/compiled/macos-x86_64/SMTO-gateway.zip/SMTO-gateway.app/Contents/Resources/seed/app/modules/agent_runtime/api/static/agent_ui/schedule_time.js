/* Presentation only. The server owns timezone resolution and recurrence arithmetic. */
(() => {
  "use strict";
  const browserZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"; } catch (_) { return "UTC"; } };
  function dateParts(value, zone = browserZone()) {
    if (!value || !Number.isFinite(Date.parse(value))) return null;
    try { return Object.fromEntries(new Intl.DateTimeFormat("en-CA", {timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23"}).formatToParts(new Date(value)).map(p => [p.type, p.value])); } catch (_) { return null; }
  }
  function dateText(value) {
    if (!value || !Number.isFinite(Date.parse(value))) return "Unavailable";
    return new Intl.DateTimeFormat(undefined, {timeZone: browserZone(), month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit"}).format(new Date(value));
  }
  const dateLabel = value => /^\d{4}-\d{2}-\d{2}$/.test(value || "") ? new Intl.DateTimeFormat(undefined, {timeZone: "UTC", month: "short", day: "numeric", year: "numeric"}).format(new Date(`${value}T12:00:00Z`)) : "Choose a date";
  const localDate = value => { const p = dateParts(value); return p ? `${p.year}-${p.month}-${p.day}` : ""; };
  const wallTime = value => /^\d{2}:\d{2}$/.test(value || "") ? new Intl.DateTimeFormat(undefined, {hour: "numeric", minute: "2-digit", timeZone: "UTC"}).format(new Date(`2000-01-01T${value}:00Z`)) : value || "Choose a time";
  const intervalUnit = seconds => [86400, 3600, 60, 1].find(unit => Number(seconds) % unit === 0) || 1;
  window.SMTOScheduleTime = {browserZone, dateParts, dateText, dateLabel, localDate, wallTime, intervalUnit};
})();
