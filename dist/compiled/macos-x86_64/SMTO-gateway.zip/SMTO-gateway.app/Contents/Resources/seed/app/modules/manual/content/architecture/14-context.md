---
id: artifacts-context
title: Artifacts and context
kind: architecture
tags: [architecture, tools]
order: 14
---
# Artifacts and context

Exact attachments and authorized resource-associated sources use scoped context IDs.
Current `read_context` requests prefer Unicode character budgets and the returned
continuation cursor. Historical runs with no bound Context policy retain legacy
byte-range semantics. The tool checks source grants; it cannot turn a guessed ID
into access. Result IDs refer to real stored observations, not filenames. Use a
filesystem tool to read a file before referring to its execution result.

`native/history.py` and `native/compaction.py` manage bounded conversation context. Compaction keeps durable source/result references and the current task projection so the model can recover exact values when needed. Artifacts, receipts and provenance remain in their stores even when a model observation is shortened.

Execution preflight, compaction and context reads reserve output space using the
run's saved execution reservation. Provider Default can omit the provider's output
limit while smTO still reserves that space internally. An explicit execution
limit changes the reservation and the room available for input/history. See
[context budgeting](22-context-memory.md) and
[output limits](../25-model-configuration.md#output-limit-and-context-space).

The UI renders actual output and durable state. It does not rewrite a response into an inferred execution plan, deduplicate exact user values semantically, or decide which domain tool should handle ordinary chat.
