/**
 * @file src/agent_runtime/api/static/agent_ui/final_response.js
 * @brief Render retained answer chunks and invalidate rejected terminal continuation text.
 * @details
 * Responsibilities: Assemble ordered retained-content events on the existing conversation turn.
 * Boundaries: Rendering cannot infer ASK or authorize terminal state; server controls own both.
 * Lifecycle: Retained events paint the answer; routing rejection clears it before the ASK decision.
 * State: Per-turn transient fields only; reconnect truth comes from persisted server events.
 * Security: Markdown uses the existing renderer; question prose cannot create an input form.
 * Collaborators: app.js owns previews; native/final_response.py emits retained candidates.
 * Public surface: SMTOFinalResponse.retain consumes ordered content and rejection events.
 * @see src/agent_runtime/api/static/agent_ui/app.js
 * @see src/agent_runtime/native/final_response.py
 */
(() => {
  "use strict";

  function retain(turn, event) {
    if (event?.event_type === "completion.rejected"
        && event.detail?.reason === "terminal_continuation_requires_ask_user") {
      turn.messageTimes?.clear();
      turn.retainedFinal = null;
      turn.finalCorrectionOnly = false;
      turn.answer.replaceChildren();
      turn.answerText = "";
      delete turn.answer.dataset.provisional;
      return false; // Existing preview invalidation owns the remaining display state.
    }
    if (event?.event_type !== "agent.final_response.retained") return false;
    const d = event.detail || {};
    if (!d.decision_id || !Number.isInteger(d.sequence) || typeof d.content !== "string") return true;
    let entry = turn.retainedFinal;
    if (!entry || entry.id !== d.decision_id) {
      entry = turn.retainedFinal = {id: d.decision_id, sequence: 0, text: ""};
    }
    if (d.sequence <= entry.sequence) return true;
    if (d.sequence !== entry.sequence + 1) return true;
    entry.sequence = d.sequence;
    entry.text += d.content;
    if (entry.text.trim()) turn.messageTimes?.retain(event);
    entry.startedAt = turn.messageTimes?.startedAt() || d.started_at || event.timestamp;
    clearTimeout(turn.previewTimer);
    turn.previewClosed = true;
    if (turn.finalizing) turn.finalizing.hidden = true;
    turn.answer.hidden = false;
    delete turn.answer.dataset.provisional;
    turn.answer.removeAttribute("aria-busy");
    turn.answerText = entry.text;
    window.SMTOMarkdown.render(turn.answer, entry.text);
    return true;
  }

  window.SMTOFinalResponse = {retain};
})();
