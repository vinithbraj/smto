/* One editor's resource draft. No selections are shared with sibling inputs. */
(() => {
  "use strict";
  let sequence = 0;
  function create({input, host = input.parentElement, conversationId, scopeKey = conversationId,
    disabled = () => false, notify = () => {}, changed = () => {}, inherited = () => ({}), dependencies = null}) {
    let refs = [], gateways = [], records = [], revision = 0, disposed = false;
    let scope = scopeKey(), catalogLoading, unavailable = false, rendered = "";
    const uploads = new Set(), drafts = new Map();
    const events = new AbortController(), options = {signal: events.signal};
    const chips = document.createElement("div"); chips.className = "input-resource-chips"; chips.hidden = true;
    chips.setAttribute("aria-label", "Selected resources"); host.append(chips);
    const file = document.createElement("input"); file.type = "file"; file.multiple = true; file.hidden = true; host.append(file);
    const api = async (url, init) => {
      const response = await window.SMTOErrors.fetch(url, init);
      if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
      return window.SMTOErrors.readJson(response);
    };
    const existingRefs = () => (inherited()?.attachments || []).map(ref => ref.context_id);
    const existingGateways = () => inherited()?.gateway_selection?.gateway_ids || [];
    const remaining = () => Math.max(0, 16 - new Set([...existingRefs(), ...refs.map(ref => ref.context_id)]).size);
    function render() {
      const signature = JSON.stringify([refs, gateways, Boolean(disabled())]);
      if (signature === rendered) return;
      rendered = signature;
      chips.replaceChildren();
      for (const [kind, items] of [["context", refs], ["gateway", gateways]]) for (const item of items) {
        const id = item.context_id || item.gateway_id, label = item.name || item.label || id;
        const button = document.createElement("button"); button.type = "button";
        button.textContent = `${label} ×`; button.setAttribute("aria-label", `Remove ${label}`);
        button.disabled = disabled();
        button.onclick = () => {
          if (disabled()) return;
          if (kind === "context") refs = refs.filter(ref => ref.context_id !== id);
          else gateways = gateways.filter(gateway => gateway.gateway_id !== id);
          revision++; render(); changed();
        };
        chips.append(button);
      }
      chips.hidden = !refs.length && !gateways.length;
    }
    function invalidate() {
      revision++;
      for (const controller of uploads) controller.abort();
      uploads.clear(); catalogLoading?.abort(); catalogLoading = null; palette.cancel();
    }
    function clear() { invalidate(); refs = []; gateways = []; drafts.delete(scope); render(); }
    function update() {
      if (scope !== scopeKey()) {
        drafts.set(scope, {refs, gateways}); invalidate(); scope = scopeKey();
        ({refs = [], gateways = []} = drafts.get(scope) || {});
      }
      const blocked = Boolean(disabled() || input.disabled || input.closest("[hidden]"));
      if (blocked && !unavailable) invalidate();
      unavailable = blocked;
      if (blocked) palette.close();
      render(); palette.update();
    }
    async function operation(work) {
      const captured = scopeKey(), generation = revision;
      const controller = new AbortController(); uploads.add(controller);
      changed();
      try {
        const metadata = await work(controller.signal);
        if (disposed || disabled() || !input.getClientRects().length || scopeKey() !== captured || generation !== revision) return false;
        if (!refs.some(ref => ref.context_id === metadata.context_id) && !existingRefs().includes(metadata.context_id)) {
          if (!remaining()) throw new Error("At most 16 context sources per run.");
          refs.push(metadata);
        }
        render(); changed(); return true;
      } catch (error) { if (!disposed && captured === scopeKey() && generation === revision && error.name !== "AbortError") notify(error.message); return false; }
      finally { uploads.delete(controller); if (!disposed) changed(); }
    }
    const attachContext = candidate => operation(signal => {
      const cid = conversationId();
      if (!cid) throw new Error("Create this conversation before selecting saved context.");
      return api("/api/agent/context/link", {signal, method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({source_conversation_id: candidate.source_conversation_id,
          target_conversation_id: cid, ...(candidate.context_id ? {context_id: candidate.context_id}
            : {source_run_id: candidate.source_run_id, reference: candidate.reference})})});
    });
    let pickerScope, pickerRevision;
    file.addEventListener("change", async () => {
      if (pickerScope !== scopeKey() || pickerRevision !== revision || disposed) { file.value = ""; return; }
      const files = [...file.files]; file.value = "";
      for (const source of files) {
        if (pickerScope !== scopeKey() || pickerRevision !== revision || disposed) break;
        if (!remaining()) { notify("At most 16 context sources per run."); break; }
        await operation(signal => {
          const query = new URLSearchParams({name: source.name});
          if (conversationId()) query.set("conversation_id", conversationId());
          return api(`/api/agent/context/upload?${query}`, {signal, method: "POST",
            headers: {"Content-Type": source.type || "application/octet-stream"}, body: source});
        });
      }
    }, options);
    const palette = window.SMTOMentionPalette.create({input, composer: host,
      id: `input-mention-${++sequence}`, handleKeys: true, floating: true,
      conversationId, disabled, isSteering: () => false, notify, dependencies,
      onDraftChanged: () => input.dispatchEvent(new Event("input", {bubbles: true})),
      onBusyChanged: changed,
      targetSelector: {
        recordsSnapshot: () => records,
        addGateway(id) {
          const item = records.find(row => row.gateway_id === id);
          if (!item || item.status === "disabled") return false;
          if (!gateways.some(row => row.gateway_id === id) && !existingGateways().includes(id)) {
            if (new Set([...existingGateways(), ...gateways.map(row => row.gateway_id)]).size >= 16) {
              notify("At most 16 Gateways per run."); return false;
            }
            gateways.push(item); render(); changed();
          }
          return true;
        },
      },
      nativeControls: {remainingAttachmentSlots: remaining, attachContext,
        attachArtifact: item => attachContext({source_conversation_id: item.conversation_id,
          source_run_id: item.run_id, reference: item.reference}),
        openFilePicker() { pickerScope = scopeKey(); pickerRevision = revision; file.click(); }},
    });
    function loadGateways() {
      if (disabled() || catalogLoading) return;
      const controller = catalogLoading = new AbortController(), generation = revision;
      const captured = scopeKey();
      void api("/api/agent/gateways", {signal: controller.signal}).then(payload => {
        if (disposed || controller.signal.aborted || generation !== revision || captured !== scopeKey()) return;
        records = (payload.gateways || []).filter(row => row.presentation).map(row => row.presentation);
        palette.update();
      }).catch(error => {
        if (!disposed && !controller.signal.aborted && captured === scopeKey()) notify(error.message);
      }).finally(() => { if (catalogLoading === controller) catalogLoading = null; });
    }
    input.addEventListener("focus", loadGateways, options);
    input.addEventListener("input", () => { if (input.value.includes("@") && !records.length) loadGateways(); }, options);
    return {update, clear, close: palette.close, isOpen: palette.isOpen,
      isBusy: () => uploads.size > 0 || palette.isBusy(),
      snapshot() {
        update();
        return {context_refs: refs.map(ref => ref.context_id), gateway_ids: gateways.map(row => row.gateway_id)};
      },
      dispose() { disposed = true; invalidate(); drafts.clear(); events.abort(); palette.dispose(); chips.remove(); file.remove(); }};
  }
  window.SMTOInputResources = {create};
})();
