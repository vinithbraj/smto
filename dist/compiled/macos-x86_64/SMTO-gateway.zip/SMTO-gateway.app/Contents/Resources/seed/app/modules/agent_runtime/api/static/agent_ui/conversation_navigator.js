/* Desktop rail; the shared core owns labels, active sections and bounded lists. */
(() => {
  "use strict";
  function create({viewport, content, getRecords, navigateToConversationTurn}) {
    const core = window.SMTOConversationNavigatorCore;
    let enabled = false, allowShort = false, entries = [], active = 0, tracker, host, rail, panel, list;
    let frame = 0, openTimer, closeTimer, pinned = false, lifetime, manualTrigger = null;
    function disposeList() {
      const previous = list; list = null;
      previous?.dispose();
      if (panel) panel.hidden = true;
      rail?.setAttribute("aria-expanded", "false");
    }
    function removeHost() {
      tracker?.dispose(); tracker = null;
      lifetime?.abort(); host?.remove(); host = rail = panel = null;
    }
    function close(restoreFocus = false) {
      clearTimeout(openTimer); clearTimeout(closeTimer);
      pinned = false;
      const trigger = manualTrigger || rail;
      manualTrigger?.setAttribute("aria-expanded", "false"); manualTrigger = null;
      disposeList();
      if (!enabled || entries.length < (allowShort ? 1 : core.MIN_TURNS)) removeHost();
      if (restoreFocus && trigger?.isConnected) trigger.focus({preventScroll: true});
    }
    function unmount() { close(); removeHost(); }
    function select(index) {
      const entry = entries[index];
      if (entry && navigateToConversationTurn(entry.messageId)) {
        active = index; renderMarkers(); close(true); tracker?.refresh();
      }
    }
    function open(focus = false) {
      clearTimeout(openTimer); clearTimeout(closeTimer);
      if (!host) return;
      if (!list) {
        panel.hidden = false;
        list = core.createPromptList({entries, activeIndex: active, select});
        panel.append(list.root);
        rail.setAttribute("aria-expanded", "true");
        manualTrigger?.setAttribute("aria-expanded", "true");
        list.open();
      }
      if (focus) list.root.focus({preventScroll: true});
    }
    function renderMarkers() {
      if (!rail) return;
      const markers = core.markerBuckets(entries.length, host.clientHeight, active);
      rail.replaceChildren(...markers.map(marker => {
        const tick = document.createElement("span");
        tick.className = "prompt-navigator-tick";
        tick.dataset.index = String(marker.index);
        tick.dataset.active = String(marker.active);
        tick.dataset.compressed = String(marker.compressed);
        tick.setAttribute("aria-hidden", "true");
        return tick;
      }));
      rail.setAttribute("aria-label", `Conversation Navigator, ${entries.length} user prompts, current prompt ${active + 1}`);
    }
    function position() {
      if (!host) return;
      const rect = viewport.getBoundingClientRect(), height = Math.max(12, Math.min(480, rect.height * 0.6));
      // The desktop shell is a CSS size container, which can establish the fixed
      // containing block. Resolve its origin instead of assuming the window.
      const previous = host.getBoundingClientRect();
      const originTop = previous.top - (parseFloat(host.style.top) || 0);
      const originLeft = previous.left - (parseFloat(host.style.left) || 0);
      host.style.height = `${height}px`;
      host.style.top = `${rect.top + (rect.height - height) / 2 - originTop}px`;
      // clientWidth excludes the native scrollbar, including a non-overlay scrollbar.
      host.style.left = `${rect.left + viewport.clientWidth - 52 - originLeft}px`;
      panel.style.width = `${Math.max(120, Math.min(440, viewport.clientWidth - 76))}px`;
      panel.style.maxHeight = `${Math.max(48, rect.height - 24)}px`;
      renderMarkers(); list?.resize();
    }
    function mount() {
      lifetime = new AbortController();
      const options = {signal: lifetime.signal};
      host = document.createElement("nav");
      host.className = "conversation-prompt-navigator";
      host.style.top = "0px"; host.style.left = "0px";
      host.setAttribute("aria-label", "Conversation Navigator");
      rail = document.createElement("button");
      rail.className = "prompt-navigator-rail";
      rail.type = "button"; rail.title = "Navigate conversation";
      rail.setAttribute("aria-haspopup", "listbox");
      rail.setAttribute("aria-expanded", "false");
      rail.setAttribute("aria-controls", "conversation-prompt-flyout");
      panel = document.createElement("div");
      panel.id = "conversation-prompt-flyout";
      panel.className = "prompt-navigator-flyout";
      panel.hidden = true;
      host.append(rail, panel);
      viewport.parentElement.append(host);
      host.addEventListener("pointerenter", event => {
        clearTimeout(closeTimer);
        if (event.pointerType !== "touch" && matchMedia("(hover: hover)").matches)
          openTimer = setTimeout(() => open(), 150);
      }, options);
      host.addEventListener("pointerleave", () => {
        clearTimeout(openTimer);
        closeTimer = setTimeout(() => { if (!pinned && !host?.contains(document.activeElement)) close(); }, 220);
      }, options);
      rail.addEventListener("click", event => {
        const tick = event.target.closest(".prompt-navigator-tick");
        if (tick && tick.dataset.compressed === "false" && event.detail > 0) select(Number(tick.dataset.index));
        else if (pinned) close();
        else { pinned = true; open(event.detail === 0); }
      }, options);
      host.addEventListener("keydown", event => {
        if (event.key === "Escape") { event.preventDefault(); close(true); }
        else if (event.target === rail && ["ArrowDown", "ArrowUp"].includes(event.key)) {
          event.preventDefault(); pinned = true; open(true);
        }
      }, options);
      host.addEventListener("focusout", event => {
        if (!host?.contains(event.relatedTarget) && event.relatedTarget !== manualTrigger) close();
      }, options);
      document.addEventListener("pointerdown", event => {
        if (!host?.contains(event.target) && !manualTrigger?.contains(event.target)) close();
      }, options);
      position();
    }
    function sync() {
      frame = 0;
      if (!enabled) return;
      // Fail locally: a navigator failure must never disable native conversation scrolling.
      try {
        const next = core.deriveEntries(getRecords(), entries);
        if (next.length < (allowShort ? 1 : core.MIN_TURNS)) { entries = next; unmount(); return; }
        if (host && next.length === entries.length && next.every((entry, index) => entry === entries[index])) return;
        const activeId = entries[active]?.messageId;
        entries = next;
        const wasOpen = Boolean(list), wasPinned = pinned, hadFocus = list?.root === document.activeElement;
        disposeList(); tracker?.dispose();
        active = Math.max(0, entries.findIndex(entry => entry.messageId === activeId));
        if (!host) mount();
        renderMarkers();
        tracker = core.createTracker({entries, viewport, content, resized: position, changed(index) {
          active = index; renderMarkers(); list?.update(index);
        }});
        if (wasOpen) { pinned = wasPinned; open(hadFocus); }
      } catch (error) {
        unmount(); entries = [];
        console.warn("Conversation Navigator is unavailable", error);
      }
    }
    function refresh() { if (enabled && !frame) frame = requestAnimationFrame(sync); }
    return {refresh, refreshActive: () => tracker?.refresh(),
      open(trigger) {
        if (!enabled) return;
        manualTrigger = trigger;
        cancelAnimationFrame(frame); sync();
        if (host) { pinned = true; open(true); }
      },
      setEnabled(value, {allowShort: short = false} = {}) {
        const next = value === true;
        if (next === enabled && allowShort === short) return;
        enabled = next; allowShort = short;
        if (enabled) refresh();
        else { cancelAnimationFrame(frame); frame = 0; unmount(); entries = []; }
      },
      reset() { cancelAnimationFrame(frame); frame = 0; unmount(); entries = []; active = 0; },
      dispose() { enabled = false; cancelAnimationFrame(frame); unmount(); entries = []; },
    };
  }
  window.SMTOConversationPromptNavigator = {create};
})();
