/* Shared number presentation. Values stay exact; only changed digits roll. */
(() => {
  "use strict";
  if (window.SMTONumberOdometer) return;
  const views = new WeakMap();
  const numeric = /([0-9]+(?:[.,\u00a0\u202f][0-9]+)*)/g;
  const defaultDecimal = new Intl.NumberFormat().formatToParts(1.1).find(part => part.type === "decimal")?.value || ".";
  function magnitude(value, decimal) {
    const at = value.lastIndexOf(decimal);
    const integer = (at < 0 ? value : value.slice(0, at)).replace(/\D/g, "").replace(/^0+(?=\d)/, "") || "0";
    return {integer, fraction: at < 0 ? "" : value.slice(at + 1)};
  }

  function stopRolling(digit) {
    digit.removeAttribute("data-roll"); digit.removeAttribute("data-previous");
    digit.removeAttribute("data-direction");
  }

  function render(node, value, {live = true, decimalSeparator = defaultDecimal} = {}) {
    const text = String(value ?? ""), parts = text.split(numeric);
    const shape = JSON.stringify(parts.filter((_, index) => index % 2 === 0));
    let view = views.get(node);
    // A formatter/status change or an outside decorator starts a fresh display.
    if (!view || view.shape !== shape || view.parts.some(part => part.node.parentNode !== node)) {
      const nodes = parts.map((part, index) => {
        if (index % 2 === 0) return {node: document.createTextNode(part)};
        const number = document.createElement("span"); number.className = "number-odometer";
        // Expose one complete number instead of announcing each rolling column.
        number.setAttribute("role", "img"); number.setAttribute("aria-label", part);
        // Completed CSS animations must not replay when a caller moves this number.
        number.addEventListener("animationend", event => {
          if (!event.target.classList.contains("odometer-digit-value")) return;
          const digit = event.target.parentNode;
          if (event.animationName === `odometer-in-${digit.dataset.roll}`) stopRolling(digit);
        });
        return {node: number, cells: new Map(), value: ""};
      });
      node.replaceChildren(...nodes.map(part => part.node));
      view = {shape, parts: nodes}; views.set(node, view);
    }
    const animate = live && !document.hidden;
    for (let index = 1; index < parts.length; index += 2) {
      const group = view.parts[index], next = parts[index];
      if (group.value === next && animate) continue;
      if (group.value !== next) group.node.setAttribute("aria-label", next);
      const before = magnitude(group.value, decimalSeparator), after = magnitude(next, decimalSeparator);
      const precision = Math.max(before.fraction.length, after.fraction.length);
      const decreasing = before.integer.length > after.integer.length
        || (before.integer.length === after.integer.length && (before.integer > after.integer
          || (before.integer === after.integer && before.fraction.padEnd(precision, "0") > after.fraction.padEnd(precision, "0"))));
      const cells = new Map();
      let place = -after.fraction.length;
      // Match place values so carries, grouping and optional decimals retain their columns.
      for (const character of [...next].reverse()) {
        const isDigit = /[0-9]/.test(character);
        const key = `${isDigit ? "digit" : character}:${place}`;
        let cell = group.cells.get(key);
        if (!cell) {
          const element = document.createElement("span");
          element.setAttribute("aria-hidden", "true");
          if (isDigit) {
            element.className = "odometer-digit";
            const current = document.createElement("span"); current.className = "odometer-digit-value";
            element.append(current); cell = {node: element, current, value: ""};
          } else { element.textContent = character; cell = {node: element}; }
        }
        if (isDigit) {
          if (cell.value !== character) {
            if (animate && group.value) {
              cell.node.dataset.previous = cell.value;
              cell.node.dataset.direction = decreasing ? "down" : "up";
              // Alternate names to restart CSS without a forced layout or a JS animation loop.
              cell.node.dataset.roll = cell.node.dataset.roll === "a" ? "b" : "a";
            }
            cell.current.textContent = character; cell.value = character;
          }
          if (!animate) stopRolling(cell.node);
          place++;
        }
        cells.set(key, cell);
      }
      const ordered = [...cells.values()].reverse();
      for (const [key, cell] of group.cells) if (!cells.has(key)) cell.node.remove();
      ordered.forEach((cell, position) => {
        if (group.node.childNodes[position] !== cell.node)
          group.node.insertBefore(cell.node, group.node.childNodes[position] || null);
      });
      group.cells = cells; group.value = next;
    }
  }
  window.SMTONumberOdometer = {render};
})();
