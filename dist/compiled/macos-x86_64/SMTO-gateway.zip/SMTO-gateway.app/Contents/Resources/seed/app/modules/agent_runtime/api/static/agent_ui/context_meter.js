/* Retain observed accounting, never estimates manufactured by the browser. */
(() => {
  "use strict";
  function valid(usage) {
    const used = usage?.used_tokens ?? usage?.used_tokens_estimate;
    return Number.isFinite(usage?.context_window_tokens) && usage.context_window_tokens > 0
      && Number.isFinite(used) && used >= 0;
  }
  function remaining(usage) {
    if (usage?.status === "exceeded") return 0;
    if (!valid(usage)) return null;
    const used = usage.used_tokens ?? usage.used_tokens_estimate;
    const reserved = Number.isFinite(usage.reserved_output_tokens) && usage.reserved_output_tokens >= 0
      ? usage.reserved_output_tokens : 0;
    const required = Number.isFinite(usage.input_tokens) && usage.input_tokens >= 0
      ? Math.max(used, usage.input_tokens + reserved) : used;
    return Math.max(0, Math.min(100, 100 - required / usage.context_window_tokens * 100));
  }
  function create(meter, onChange = () => {}) {
    const lastKnown = new Map();
    let scope = null, current = null;
    function render({reset = false, observedAt, notify = true} = {}) {
      if (!current) {
        meter.textContent = "Context —";
        meter.title = "Context usage will appear after a model request";
        meter.style.setProperty("--context-used-percent", "0%");
        meter.removeAttribute("aria-valuenow");
        meter.removeAttribute("aria-valuetext");
        delete meter.dataset.level;
        if (notify) onChange(null, {reset, observedAt});
        return;
      }
      const used = current.used_tokens ?? current.used_tokens_estimate, windowTokens = current.context_window_tokens;
      const measured = valid(current), exceeded = current.status === "exceeded";
      const reserved = Number.isFinite(current.reserved_output_tokens) && current.reserved_output_tokens >= 0
        ? current.reserved_output_tokens : 0;
      const hasInput = Number.isFinite(current.input_tokens) && current.input_tokens >= 0;
      const required = hasInput ? Math.max(used, current.input_tokens + reserved) : used;
      const percent = 100 - remaining(current);
      window.SMTONumberOdometer.render(meter,
        exceeded ? "Context exceeded" : `Context available ${(100 - percent).toFixed(0)}%`, {live: !reset});
      const tokens = value => Math.round(value).toLocaleString();
      if (exceeded) {
        meter.title = measured && hasInput
          ? `${current.estimated === false ? "Failed" : "Estimated failed"} request: ${tokens(current.input_tokens)} input tokens + ${tokens(reserved)} reserved for output; ${tokens(windowTokens)} token context window.`
            + (required > windowTokens ? ` Exceeds capacity by ${tokens(required - windowTokens)} tokens.` : " The request was rejected for exceeding context capacity.")
          : "The latest request exceeded context capacity. Its token count is unavailable; the previous request's available space no longer applies.";
      } else {
        meter.title = `${current.estimated === false ? "Latest" : "Estimated latest"} model request: ${tokens(used)} of ${tokens(windowTokens)} tokens used (${current.source || "estimate"}).`
          + (hasInput && reserved ? ` The budget reserves ${tokens(reserved)} tokens for output.` : "")
          + " This measures the last recorded model request; new tool results can increase the next request. Older turns and tool traces may be omitted; exact history remains available.";
      }
      meter.style.setProperty("--context-used-percent", `${percent.toFixed(1)}%`);
      meter.setAttribute("aria-valuenow", percent.toFixed(1));
      meter.setAttribute("aria-valuetext", meter.textContent);
      meter.dataset.level = percent >= 90 ? "danger" : percent >= 75 ? "warning" : "ok";
      if (notify) onChange(100 - percent, {reset, observedAt});
    }
    function update(usage, observedAt) {
      const accepted = valid(usage) || usage?.status === "exceeded";
      if (accepted) {
        current = {...usage};
        if (scope) {
          lastKnown.delete(scope); lastKnown.set(scope, current);
          if (lastKnown.size > 100) lastKnown.delete(lastKnown.keys().next().value);
        }
      }
      render({observedAt, notify: accepted});
    }
    function activate(identity) {
      const reset = scope !== (identity || null);
      scope = identity || null;
      current = scope ? lastKnown.get(scope) || null : null;
      render({reset});
    }
    function forget(identity) { lastKnown.delete(identity); if (scope === identity) activate(null); }
    return {activate, update, forget};
  }
  window.SMTOContextMeter = {create, remaining};
})();
