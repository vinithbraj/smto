(() => {
  'use strict';
  const prefix = new URL(document.currentScript.src).pathname.replace(/\/auth\/login\.js$/, '');
  const form = document.getElementById('login-form');
  const button = form.querySelector('button');
  const error = document.getElementById('login-error');
  form.addEventListener('submit', async event => {
    event.preventDefault(); button.disabled = true; error.textContent = '';
    try {
      const response = await fetch(prefix + '/auth/login', {
        method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username: form.username.value, password: form.password.value,
          next: (new URLSearchParams(location.search).get('next') || prefix + '/agent-ui') + location.hash}),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error === 'portal_setup_required'
        ? 'Sign-in needs local setup or repair. Contact the Server owner.' : result.error || 'Unable to sign in.');
      form.password.value = '';
      location.replace(result.next);
    } catch (failure) {
      error.textContent = failure.message || 'Unable to reach the Server.';
      form.password.value = ''; form.password.focus();
    } finally { button.disabled = false; }
  });
})();
