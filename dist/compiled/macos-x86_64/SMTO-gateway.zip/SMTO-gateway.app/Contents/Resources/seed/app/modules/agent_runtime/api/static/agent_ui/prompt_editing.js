/* Plain-text list conveniences for the prompt, independent of composer size. */
(() => {
  "use strict";

  function insideFence(text) {
    let fence = null;
    for (const line of text.split("\n")) {
      const marker = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
      if (!marker) continue;
      if (!fence) fence = marker[1];
      else if (marker[1][0] === fence[0] && marker[1].length >= fence.length && !marker[2].trim()) fence = null;
    }
    return Boolean(fence);
  }

  function replace(input, start, end, text) {
    if (input.maxLength >= 0 && input.value.length - (end - start) + text.length > input.maxLength) return;
    input.setSelectionRange(start, end);
    // Native insertion keeps list edits in the browser's undo/redo history.
    if (!document.execCommand("insertText", false, text)) {
      input.setRangeText(text, start, end, "end");
      input.dispatchEvent(new InputEvent("input", {bubbles: true, inputType: "insertText", data: text}));
    }
  }

  function keydown(event) {
    const input = event.target;
    if (event.defaultPrevented || event.isComposing || event.keyCode === 229 || input.readOnly || input.disabled
      || event.key !== "Enter" || !event.shiftKey || event.ctrlKey || event.metaKey || event.altKey) return false;
    const {value, selectionStart: start, selectionEnd: end} = input;
    const lineStart = value.slice(0, start).lastIndexOf("\n") + 1;
    const newline = value.indexOf("\n", lineStart);
    const lineEnd = newline < 0 ? value.length : newline;
    if (end > lineEnd || insideFence(value.slice(0, lineStart))) return false;
    const marker = value.slice(lineStart, lineEnd).match(/^([ \t]*)(?:(\d{1,9})([.)])|([-+*•]))([ \t]+)(?:\[([ xX])\]([ \t]+))?/);
    if (!marker || start < lineStart + marker[0].length) return false;
    event.preventDefault();
    const [, indent, number, delimiter, bullet, spacing, checkbox, checkboxSpacing] = marker;
    const remaining = value.slice(lineStart + marker[0].length, start) + value.slice(end, lineEnd);
    if (!remaining.trim()) {
      replace(input, lineStart, lineEnd, indent);
    } else {
      const next = number ? `${Number(number) + 1}${delimiter}` : bullet;
      replace(input, start, end, `\n${indent}${next}${spacing}${checkbox === undefined ? "" : `[ ]${checkboxSpacing}`}`);
    }
    return true;
  }

  window.SMTOPromptEditing = {keydown};
})();
