import { button, node } from "../api.js?v=20261018-loading";
import { openSheet, closeSheet, mountControls } from "../overlays.js?v=20261018-loading";

export function open(turn, returnFocus) {
  if (turn.disposed || !turn.root.isConnected) return;
  const wasOpen = turn.controls.open;
  const body = openSheet("Message details", {returnFocus, onClose: () => { turn.controls.open = wasOpen; }});
  mountControls(body, ...turn.root.querySelectorAll(":scope > .message-time-heading"),
    turn.tokenUsage, turn.detailActions, turn.executionInspector?.root, turn.controls);
  const mode = turn.root.querySelector(":scope > .task-mode-banner");
  if (mode) body.prepend(node("p", `Mode · ${mode.textContent}`, "muted"));
  turn.controls.open = true;
  const remove = turn.activityGroup?.querySelector(":scope > .task-delete-button");
  if (remove) body.append(button("Delete task", async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
    await closeSheet();
    if (remove.isConnected && !remove.disabled) remove.click();

 } finally { busyFeedback?.finish(); }
}, "choice"));
  body.append(button("View activity", async () => {
 const busyFeedback = window.SMTOBusy?.action("Updating selection…");
 try {
    await closeSheet();
    if (turn.disposed || !turn.root.isConnected) return;
    turn.activity.open = true;
    for (const group of turn.activity.querySelectorAll(".prose-activity")) group.open = true;
    turn.activity.scrollIntoView({block: "nearest"});

 } finally { busyFeedback?.finish(); }
}, "choice"));
}
