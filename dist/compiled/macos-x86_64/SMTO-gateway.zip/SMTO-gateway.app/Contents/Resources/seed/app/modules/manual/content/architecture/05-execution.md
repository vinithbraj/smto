---
id: execution-receipts
title: Execution and receipts
kind: architecture
tags: [architecture, tools]
order: 5
---
# Execution and receipts

`ExecutionEngine.execute_invocation` validates the registered argument schema, resolves exact bindings, checks deterministic safety and `ExecutionAuthorization`, and invokes the tool's executor. Shell and Python adapters use the gateway; the database adapter preserves the existing PostgreSQL backend; other adapters use their domain services.

A durable dispatch claim precedes execution. The run store keeps a receipt and exact artifact with operation ID, canonical capability ID, status, execution/completion flags, actual data, authorization metadata and binding provenance. Bounded model/UI observations never replace the exact stored result. A successful launch is not a completed job.

A provider adapter must raise `UnknownEffectError` if a mutating operation may have happened but its outcome cannot be established. The runtime records the uncertainty and requires reconciliation. A crash after a claim has the same protection; it does not imply exactly-once external execution.

Effects, authorization and scope remain deterministic. A tool's description or learned preference cannot override them. Provider-specific validation belongs in its adapter/service, and conservative read/write policy in the execution layer.

Python entrypoint canonicalization runs after generic tool-argument normalization
and before claims, effects, authorization or execution. The default-ON **Automatic
Python correction** preference is captured per accepted task and survives resume
and restart. Bounded rules wrap simple scripts and a conservative class of plain
synchronous helper-function scripts, move safe imports/plain-helper preludes into a
sole entrypoint, and remove exact redundant entrypoint calls/guards. Helper support
is scope-aware: helper-local bindings and `return` statements are not confused with
module scope, while decorators/defaults/annotations, dynamic scope/introspection,
helper escape/rebinding, forward closure dependencies, nested scopes, async/generator
semantics and other ambiguous forms remain on the model-repair path. A generated
candidate is compiled without execution and then must pass the existing strict
Python validator and transform sandbox; unsupported source and OFF remain unchanged.

The raw model journal remains exact. Canonical business source is used for
Activity/parallel/dependency children, replay comparison, operation claims, safety,
authorization and receipt arguments. `python.code_canonicalized` records only tool
identity and stable correction metadata. Correction adds no model or Gateway call
and is not execution evidence. Only actual execution can establish a receipt.

`EFFECT_CLASSIFIER_REVISION` versions persisted Shell classifications. Literal subshell
boundaries terminate redirect operands outside quotes; `(git status 2>/dev/null)` remains
read-only, while real file outputs and dynamic destinations remain conservative. Reclassifying
a historical job updates derived effect facts and audit history, never its execution outcome.

Agent scheduling and Gateway admission share `execution/resources.py` overlap semantics.
Gateway derives bounded literal filesystem paths, aliases and hardlink identities on the target;
unsupported commands use `*`. Launch CWD is retained for compatibility, rather than treated as
proof that two mutations affect the same or different resources.

Shell effect analysis reuses `execution/shell_syntax.py` for literal structure and
`shell_operations.py` for executable/argument semantics. `execution/remote_shell.py`
recognizes a bounded SSH invocation, optionally wrapped in `sshpass`, with one literal
remote program argument. `effects.py` classifies that program through the same canonical
classifier, propagating reads, mutations and unknowns through at most four SSH layers.
Unsupported options, dynamic arguments and interactive SSH cannot establish a read proof.
This execution analysis is separate from verified SSH working-context identity; it does
not modify transport, credentials, shared executable discovery or Gateway registration.

## Literal authentication and unsafe approval

Shell accepts literal `sudo_password` and `sudo_username` arguments. The
Gateway reports actual `credential_required`, `credential_rejected`,
`privilege_not_permitted`, and execution/uncertainty facts. The Agent can ask one
ordinary question after such a result and retry on its next normal decision.

Unsafe confirmation collects approval only. After a proven unexecuted authentication
failure, the authority owner can retain a digest-bound grant for the same operation
with only its password changed. The original five-minute expiry and policy still
apply, with at most three retained retries. Command/code, username, cwd, target,
Gateway or authority changes invalidate it. Unknown effects cannot retain it.
Successful sequence prefixes are referenced by their receipts and never replayed.

Foreground execution closes its per-command supervision scope upon receiving a
completion receipt or losing the stream. `completed` is a transport event, not a
success classification: an unknown outcome remains unknown. Gateway process-tree
identity determines physical ownership; supervision and historical effects are
separate. See [resource wait recovery](09-jobs.md#foreground-supervision-and-resource-waits).

## Observe-only assessment

Optional monitoring separates a disabled check's native assessment from its enforcement. Path assessment retains the configured root while dispatching the same disabled-mode path. Strict schema and transform static assessment retain the relaxed/unsandboxed execution path and execute only once. Permission and unsafe-action assessment add no approval interaction. Duration and generation thresholds are observed at existing callbacks or operation completion; monitoring installs no cancellation deadline and leaves provider termination authoritative.

Gateway policy carries the captured monitoring bit in authenticated internal metadata. Bounded observations return in HTTP headers, internal SSE events or outbound session frame metadata. The controller strips this metadata before producing tool results and records normal Activity; Gateways do not write Agent UI state. These diagnostics make no additional model calls or remote executions.


## Controller observation boundary

`inspect_execution` is a read-only native control over retained SMTO identities.
It bypasses target resource admission, effect-conflict preflight and Gateway/Python/Shell
dispatch, and creates no execution receipt or scheduler reservation. Its bounded result
reports lifecycle, dependencies, capacity dimensions/blockers, liveness, progress and
evidence freshness. It cannot establish a new target fact or reconcile an uncertain
effect. Capability guidance prefers this control for status questions; no natural-language
interceptor or helper model call substitutes for the Agent's normal tool choice.

Proven inspection resource claims reuse Shell structural/effect facts. Audited `ps`,
`pgrep`, `lsof`, `stat`, `readlink`, `realpath` and finite `head`/`tail` reads use lightweight
capacity; proven `cat`, `wc`, `du`, `find` and checksum scans use disk-read capacity.
Unsupported flags, output writes, executable helpers, dynamic wrappers, unknown programs
and background launches retain their existing effectful/unknown demands. The default
unknown budget remains one. A read effect is not permission to skip global/run/Gateway
ceilings or authorization.

## Delivery is separate from execution

Adaptive / Compact / Full changes the model's view of stored results. Commands,
permissions, schedules, input bindings, job supervision and cancellation keep their
existing execution paths. A shortened output does not prove a background process
finished, and a successful projection does not resolve unknown external effects.
Context overflow preserves receipts and never automatically repeats completed work.
