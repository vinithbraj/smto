---
id: command-palette
title: Command palette and desktop invocation
kind: architecture
tags: [architecture, ui, commands, desktop]
order: 41
---
# Command palette and desktop invocation

Press **Ctrl+K** on Windows/Linux or **Cmd+K** on macOS in the desktop Agent UI.
The More menu also contains **Command palette**. The dialog contains the existing
composer, attachments and controls, so a draft follows you between the two views.
Escape dismisses the palette and restores focus. Dismissal does not stop a task.

Start input with `/` to search registered application commands. Arrow keys select,
Tab completes, and Enter executes through the existing command control plane.
Unavailable commands show their reason. Unknown commands stay command errors.
Opening, filtering and executing commands make no model calls. Empty input shows
safe available commands, with recently used safe commands first for this page.

Plain text uses the normal Agent submission operation, payload, task queue,
attachments, capability selection and permission policies. No classifier, prompt
wrapper or extra model call is added. Enter submits; Shift+Enter inserts a newline.
The palette is a UI surface and has no Agent skill or model-visible tools.

## Conversations and Gateways

An in-app invocation uses the exact visible conversation by default. The header
shows its identity and the command run identity. **Change conversation** opens the
existing conversation navigator; choose a conversation and reopen the palette.
**New conversation** uses normal new-chat defaults. The launcher starts with **New
conversation**, ignoring saved conversations and global current-run restoration.
An explicit `conversation` parameter on a palette URL selects that exact conversation.
Missing or deleted selections are not replaced with another conversation.

**Target** shows the canonical ordered Gateway selection. **Change target** opens
the existing multi-Gateway selector. Controls retain the saved conversation target,
including remote Gateways and unavailable targets. Admission captures a copy of
the selection; subsequent edits affect future tasks. **Task target** identifies
captured scope when it is available. No second registry or selector is maintained.

Command availability and backend validation still bind exact conversation, request
and run IDs. If that scope changes while the palette is open, reopen it to review
the new scope before executing. Deletion opens the existing confirmation dialog.

## Progress, interactions and accessibility

Submitting is a transport state. Queued, processing, waiting, completed, stopped
and failed states come from the existing durable task lane and per-turn state.
The palette adds no polling loop or SSE connection. A bounded excerpt uses the
same final response as the conversation. **Open conversation** navigates to the
observed task so you can answer questions, review unsafe-action approval or use
full task controls. Slash stop/pause/resume use their normal exact-scope controls.
No approval is granted by opening or dismissing the palette.

The native modal dialog contains keyboard focus, labels the conversation/targets,
uses the shared command listbox and announces status. Escape restores the invoking
focus. Layout fits narrow desktop-browser viewports without horizontal overflow;
the separately served phone UI keeps its existing composer and slash commands.
There are no palette animations or percentage estimates.

## Desktop launcher support

With the runtime already running and `aor` on PATH:

```bash
aor palette
aor palette --url https://your-runtime.example
```

The default URL uses configured server host/port, translating a wildcard bind host
to loopback. `--url` accepts an HTTP(S) runtime base URL without credentials, query
or fragment. It opens `/agent-ui?palette=1&ui=desktop` in the system browser and
exits. Browser policy determines whether a window is reused or a new tab opens;
reliably focusing an existing tab requires a resident browser/native integration.
The launcher does not start a second runtime.

| Platform | System-wide invocation | Verification |
| --- | --- | --- |
| Linux X11 | Bind `aor palette` in the desktop custom shortcut manager | CLI/browser boundary tested on Linux; real desktop registration is user configured |
| Linux Wayland | Bind the same command through GNOME/KDE or the compositor's shortcut manager | No universal Wayland registrar claimed; compositor binding not live-tested |
| Windows | Bind the installed command through an OS shortcut or launcher | Portable browser-launch contract tested with a fake browser; native OS launch unverified |
| macOS | Bind the installed command through Shortcuts/Automator or a launcher | Portable browser-launch contract tested with a fake browser; native OS launch unverified |

For a Python environment installation, use its absolute executable path in the OS
shortcut, for example `/path/to/smto/.venv/bin/aor palette`. Choose an unused
OS shortcut and enable/disable it in the OS shortcut manager. Conflicts and reserved
bindings at that layer belong to the OS. No resident native global registrar is
included in this browser-based product.

**Invocation settings** inside the palette configure the in-app binding, enablement
and current/new conversation behavior for this tab using existing session settings.
Changes apply immediately. Modifier-only and known browser/app conflicts are rejected.
Browsers may consume additional keys; use the More menu to choose another binding.
No OS shortcut is seized automatically.

## Privacy and troubleshooting

The launcher has no keyboard event stream or background hook. It reads neither
clipboard, screen nor active-window content. The browser only handles key events
inside its focused document. Prompt persistence remains the existing composer
draft policy; no palette history database or prompt diagnostics are added.

If no browser opens, configure the default browser or visit the palette URL directly.
If the runtime is unavailable, start it or correct `--url`. If a shortcut conflicts,
use the palette button, another in-app binding or the OS shortcut manager. If target
or conversation settings are unavailable, fix them using the existing Controls.
Canonical backend/network errors retain their Error IDs and remediation.

Source owners: `command_palette.js` moves the existing dock and projects state;
`app.js` owns the single `submitComposer` handler and lifecycle hooks;
`slash_commands.js`, `command_protocol.js` and `command_actions.js` remain shared;
`prompt_queue.js` provides exact-task observation; `api/cli.py` owns `aor palette`.
