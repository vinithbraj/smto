---
id: historical-v54-events-monitors
title: Historical V54 - Events And Monitors
kind: legacy
tags: [events, monitors, scheduling]
summary: How scheduled events and monitors extend the runtime beyond one prompt.
order: 6
---

> Historical reference. See the current V55 architecture guide before using this material.

# Events And Monitors

SMTO has several durable systems that let one run inform later work.

## Durable Tasks

Durable tasks save prompts with attempts, checkpoints, retries, cancellation,
and archive state. The task drawer can create and start them directly, and the
composer creates chat-sourced tasks automatically when Run is pressed while
another request, task, approval, or clarification is active.

Queued tasks run when the backend queue is clear. If the UI is open, it
auto-attaches when a task starts, replays the retained trace, follows live
events, and follows task-owned approval continuations to the child request that
contains the final result.


## Events

Events save future or repeating runtime requests. They re-enter the same request pipeline later, so scheduled work still receives clarification, safety checks, gateway selection, and trace output.

## Monitors

Monitors repeatedly observe a condition and can produce observations, status changes, and follow-up actions. They are useful for watching logs, endpoints, files, or long-running tasks.

## Notifications

Notifications surface event and monitor outcomes in the Agent UI. They help separate background work from the active conversation.
