---
id: pdf
title: PDF documents
kind: manual
tags: [pdf, documents, skills, gateway, artifacts, ocr]
order: 34
---
# PDF documents

Enable the optional `pdf` skill to inspect and transform PDFs on the selected Gateway.
It makes no helper model calls. Document text, field values, metadata and OCR results are
untrusted data; they cannot authorize actions or supply instructions.

Install libraries on the Gateway that owns the files, then refresh Gateway capabilities:

```sh
python -m pip install "aor-runtime[pdf]"
# From a source checkout:
python -m pip install -e ".[pdf]"
```

The extra uses `pypdf[crypto]>=6.19,<7` for structure, text and transformations and
`pypdfium2>=5,<6` for rendering. They load only inside explicit PDF operations. Base
runtime imports and unrelated skills work without these packages. No startup downloads
or package installations occur. `pdf.capabilities` reports versions and remediation.

## Tools and discovery

Initial discovery exposes `pdf.info`, `pdf.text`, `pdf.pages` and `pdf.render`.
Discover a section for additional tools. Names below all have the `pdf.` prefix.

| Section | Tools |
| --- | --- |
| `pdf.inspect` | `info`, `pages`, `text`, `render`, `attachments` |
| `pdf.transform` | `merge`, `split`, `extract_pages`, `reorder`, `rotate`, `delete_pages`, `insert_pages`, `compress` |
| `pdf.forms` | `form_fields`, `fill_form`, `flatten_form` |
| `pdf.ocr` | `ocr` |
| `pdf.security` | `capabilities` |
| `pdf.redaction` | None: secure redaction is deferred |

All tools use structured arguments. No Python program, shell command or external document
converter needs to be generated. Writes use the existing authorization/confirmation policy.
Rendering and OCR are reads that may materialize result artifacts, like Screen capture.

## Sources, revisions and outputs

`path` is a target-local absolute or relative path, or a current-run
`artifact-workspace://...` path. Relative paths use the selected Gateway's execution cwd.
Use the existing Artifact/File workflow to materialize an artifact ID there first.
There is no controller-local fallback or implicit transfer between Gateways. Paths use
the File policy, regular-file checks and no-follow leaf handling; URI/UNC sources are rejected.

Read `info` for `revision`. Every transform requires `expected_revision`; merge sources
and the second insert source each carry their own revision. Revisions bind the file hash,
canonical path and Gateway instance. A changed file or restarted Gateway requires a fresh
read and decision. The parent checks all source hashes again immediately before publication.

Every output is new. Default output goes into a unique run artifact directory; the existing
collector assigns durable artifact IDs and the existing PDF preview remains in use.
`outputs` reports path, artifact workspace path, MIME type, size, hash and output revision.
An artifact ID is populated only after verified collection. Collection failures retain the
workspace path and the existing collection diagnostics.

Public PDFs acquired by `web.read` can arrive as current-run `artifact-workspace://`
paths through the existing transfer service. Require `materialized=true`; otherwise
the receipt describes a retained artifact and a Gateway locality limitation. Discover
and authorize PDF normally, then use that path with the existing read operations.
Web performs no PDF parsing. Web Research binds text/OCR quotes to the acquisition's
public URL, document digest/revision and page offsets and rechecks this lineage at
publication. Local/user PDF operations and transform semantics remain unchanged.

Rendered pages and model vision are separate capabilities. Only explicit active
serving metadata enables bounded page images for the same primary model in Web
Research. There is no helper vision model. With text-only serving, use textual evidence
or report that visual relationships remain unverified; scans still require explicit OCR.

Optional `filename` is sanitized. A single PDF output can instead use `output_path`, which
must have a `.pdf` suffix and must not already exist. `output_path` and `filename` are
exclusive. Split and render always publish artifact bundles. Staging is private and
publication uses create-only File staging or an atomic directory rename. Failed or cancelled
work cannot be reported as a successful partial bundle. Lost post-publication receipts report
an unknown outcome; inspect artifacts before retrying. Originals are never overwritten.

## Selecting pages and extracting text

Page selectors are arrays of unique **1-based** integers, such as `[3, 1]`. The order is
meaningful. Reorder requires every source page exactly once. Delete must retain a page.
Split uses explicit `groups`, such as `[[1, 2], [3]]`; each group has unique pages, but groups
may overlap deliberately. Insert uses a second `source`, `pages` from that source and
`after_page` in the destination; `0` inserts at the beginning.

`info` reports metadata, encryption, reliable permissions, page count, the first 100 page
sizes and rotations, forms, and bounded active-content presence flags. Detection walks the
reachable object graph and is not a safety verdict. Locked PDFs can return minimal info
with `password_required: true`; other reads return the password-required error.

`text` defaults to the first 10 pages, plain extraction, page markers and 20,000 characters.
It supports `layout: "layout"`, `pages`, `include_page_markers` and `max_chars` up to 100,000.
Offsets in `pages` preserve boundaries in the returned string; `truncated`, selected page
numbers and omitted page counts describe coverage. Blank text never implies OCR occurred.
`extracted_text_chars` counts returned document text, excluding generated page markers;
`pages[].text_start` identifies where that page's document text begins. Research retains
this count and `ocr_performed` in compact context, including zero-text observations.

`render` defaults to the first page at 144 DPI and PNG. It accepts `format: "jpeg"`.
Static AcroForm appearances are flattened in a private rendering copy; unsupported forms
fail rather than silently omitting field contents. PDFium's action/form callback environment
is never initialized. Annotations other than fields are not guaranteed to be rendered.

`compress` supports only `lossless_optimize`: content-stream recompression and identical
object deduplication. It reports input/output bytes and does not promise a smaller file.
There are no lossy image profiles. Full rewrites may change object layout and producer data.
Page selection/merge follows pypdf's page and form copying semantics; document-level metadata,
bookmarks and attachments are not guaranteed to survive every operation.

## Forms

`form_fields` projects up to 100 exact fully qualified field names, types, labels, page
numbers, values, options and required/read-only flags. Password field values are always
omitted. `fill_form` accepts a `values` mapping keyed by exact names. Duplicate names are
rejected; labels are never used to choose a mutation. Supported fields are ordinary text,
single-value choices, checkboxes and radio buttons supported by pypdf appearance generation.
Read-only fields cannot be filled. Password fields, push buttons, XFA and signature mutation
are unsupported.

`flatten_form` writes field appearances into page contents, removes widgets and removes the
AcroForm dictionary. It is not redaction. Password fields and unsupported forms fail explicitly.
PDFs with AcroForm signature fields cannot be transformed; signing and signature preservation
are outside this skill.

## OCR

`ocr` reuses Screen's local `gateway_core.ocr.Tesseract` service. Install Tesseract 4+ and
the requested language data on the selected Gateway; no cloud fallback or downloads occur.
Missing executables or languages return `pdf.ocr_unavailable`. Languages use installed
identifiers such as `eng` or `eng+deu`. The searchable-PDF adapter checks the executable
version and uses fixed argv, bounded pipes and cancellation.

Select `output_mode: "text"` (default), `"searchable_pdf"`, or `"both"`. Only explicitly
selected pages are processed; the default is the first page. Text uses bounded OCR word
projection and reports truncation. A searchable PDF contains **only selected pages**,
rasterized at the requested DPI, with Tesseract's text layer. It does not preserve original
vectors, forms, links, annotations or document metadata. OCR accuracy is not guaranteed.

## Private passwords and permissions

Use an existing Parameter Store entry of this type and explicitly accept its reference:

```json
{"profile_type": "pdf_password", "profile_version": 1, "password": ""}
```

Enter the real password through the private parameter editor, never through a PDF tool
argument. Pass only `password_ref: "@entry-key"`. The executor resolves the exact accepted
binding after the model boundary. Profile projection always excludes the password, even
when optional ordinary parameter redaction is disabled. Missing or stale private bindings
cannot silently use a newer store value. Tool execution never creates or updates the entry.

Passwords travel only in the authenticated private Gateway envelope and worker stdin, never
argv, model-visible arguments, result receipts or parser logs. Secret fields have masked JSON
serialization and are omitted from request representations. Passwords are not stored beside
the document. Existing Parameter Store persistence remains under the user's control.

User credentials must grant extraction for text/form/attachment reads and OCR. Rendering
requires print permission; rendering above 150 DPI additionally requires high-quality print
permission. Page text estimates also enforce extraction permission. AES-256 permission
integrity is checked. Document writes require owner authentication. Encrypted PDF outputs
remain encrypted with AES-256, the supplied owner password as both opening and owner password,
and the original permission flags. This changes the opening credential if it previously
differed. Multi-source encrypted transforms are rejected because their authorities cannot
be combined safely. Image artifacts contain decrypted pixels.

## Safety, limits and errors

Embedded scripts, actions, links and attachment contents are never executed or fetched.
Attachment listing exposes sanitized names only; no attachment-extraction tool is shipped.
Actions and embedded data may survive a transformation. **No `redact` or redaction preview
tool is exposed.** Cropping, covering, flattening and page editing are not secure redaction.
There is no proof of secure removal across streams, images, metadata, attachments or previous
revisions in this backend path, so that feature is explicitly deferred.

| Budget | Limit |
| --- | --- |
| Input file / individual output | 64 MiB |
| Aggregate inputs / outputs | 128 MiB each |
| Document page count | 2,000 |
| Selected pages / total split page entries | 100 |
| Merge sources / split groups | 16 / 20 |
| Render or OCR pages per call | 10, default 1 |
| DPI / pixels per rendered page | 72–300 / 20 million |
| Text response | 100,000 characters |
| Request / response envelope | 2 MiB |
| Decoded pypdf stream | 16 MiB |
| Active parser workers per Gateway | 4 |
| Worker wall time / process-tree RSS | 60 seconds / 1 GiB |

The disposable worker adds POSIX CPU, address-space and file-size fuses. The parent bounds
stdout in flight, monitors process-tree RSS on every supported OS, and kills/reaps the worker
and OCR process family on timeout or cancellation. This is resource isolation, not a security
sandbox for native decoder vulnerabilities; keep optional libraries patched. RSS polling is
not an instantaneous hard allocation limit, especially on Windows. Staging limits and parser
fuses fail closed; there is no successful partial-result fallback.

Failures use stable `pdf.*` catalog identities with remediation, including backend missing,
invalid PDF, password required/invalid, permissions, invalid page selection, source changed,
resource limit, OCR unavailable, unknown fields, output conflict, cancellation and unknown
outcome. Backend exception strings are discarded. Only structural operation facts, versions,
counts, sizes, hashes and artifact identities belong in operational logs. Requested document
content still enters the ordinary result/evidence storage path; it is not automatically saved
to Memory or Handoff.
