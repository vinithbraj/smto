/* Composer discovery and execution. Actions/presentation belong to the dispatcher. */
(() => {
  "use strict";
  window.SMTOSlashCommands = {create};
  function create({input, composer, getView, present, showToast, onInput,
    onStart = () => null, onRejected = () => {}}) {
    const protocol = window.SMTOCommandProtocol;
    const availability = command => command.name === "trace" && window.SMTOImmersive?.active()
      ? "Exit Immersive to view task details." : protocol.availability(command, getView());
    let commands = [], matches = [], selected = 0, dismissed = false, busy = false, loading;
    let discovery = false, recent = [];
    const panel = document.createElement("div");
    panel.id = "slash-command-palette"; panel.className = "slash-command-palette";
    panel.setAttribute("role", "listbox"); panel.setAttribute("aria-label", "Application commands");
    panel.hidden = true; composer.prepend(panel);
    const isCommand = text => text.trimStart().startsWith("/");
    function close() {
      panel.hidden = true;
      if (input.getAttribute("aria-controls") === panel.id) {
        input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant");
      }
    }
    function autocomplete() {
      const command = matches[selected];
      if (!command || availability(command)) return false;
      input.value = command.command; onInput(); input.focus(); update(); return true;
    }
    function update() {
      const hints = discovery && !input.value.trim();
      if ((!isCommand(input.value) && !hints) || dismissed || busy) { close(); return; }
      const prefix = input.value.trimStart().slice(1).split(/\s/)[0].toLowerCase();
      matches = commands.filter(c => [c.name, ...(c.aliases || [])].some(n => n.startsWith(prefix)));
      if (hints) matches = commands.filter(c => !c.destructive && !availability(c))
        .sort((a, b) => recent.indexOf(b.name) - recent.indexOf(a.name)).slice(0, 5);
      selected = Math.min(selected, Math.max(0, matches.length - 1)); panel.replaceChildren();
      if (!matches.length) {
        const note = document.createElement("p"); note.textContent = loading ? "No matching commands" : "Loading commands…";
        panel.append(note);
      }
      matches.forEach((command, index) => {
        const option = document.createElement("button"), reason = availability(command);
        option.type = "button"; option.id = `slash-command-${index}`;
        option.tabIndex = -1;
        option.setAttribute("role", "option"); option.setAttribute("aria-selected", String(index === selected));
        option.setAttribute("aria-disabled", String(Boolean(reason)));
        option.dataset.command = command.name; option.dataset.destructive = String(command.destructive);
        const title = document.createElement("strong"), description = document.createElement("span");
        title.textContent = command.command; description.textContent = command.description;
        option.append(title, description);
        if (reason) { const note = document.createElement("small"); note.textContent = reason; option.append(note); }
        option.addEventListener("mousedown", event => event.preventDefault());
        option.onclick = () => { selected = index; if (!autocomplete()) showToast(reason); };
        panel.append(option);
      });
      panel.hidden = false;
      input.setAttribute("aria-controls", panel.id); input.setAttribute("aria-autocomplete", "list");
      input.setAttribute("role", "combobox"); input.setAttribute("aria-haspopup", "listbox");
      input.setAttribute("aria-expanded", "true");
      if (matches.length) input.setAttribute("aria-activedescendant", `slash-command-${selected}`);
      else input.removeAttribute("aria-activedescendant");
    }
    function keydown(event) {
      if (!isCommand(input.value) && event.key === "Enter") return false;
      if (panel.hidden || event.isComposing || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) return false;
      if (!["ArrowUp", "ArrowDown", "Tab", "Enter", "Escape"].includes(event.key)) return false;
      event.preventDefault();
      if (event.key === "Escape") { dismissed = true; close(); }
      else if (event.key === "Tab") autocomplete();
      else if (event.key === "Enter") {
        if (matches[selected] && !/\s/.test(input.value.trim())) {
          if (!autocomplete()) { showToast(availability(matches[selected])); return true; }
        }
        composer.requestSubmit();
      } else if (matches.length) {
        selected = (selected + (event.key === "ArrowDown" ? 1 : -1) + matches.length) % matches.length;
        update(); panel.querySelector(`[aria-selected="true"]`)?.scrollIntoView({block: "nearest"});
      }
      return true;
    }
    async function execute(raw) {
 const busyFeedback = window.SMTOBusy?.action("Running command…");
 try {
      if (busy) return;
      const name = raw.trimStart().slice(1).split(/\s/)[0].toLowerCase();
      const definition = commands.find(c => c.name === name || c.aliases?.includes(name));
      const reason = definition && availability(definition);
      if (reason) { showToast(reason); return; }
      const captured = getView(), pendingDraft = onStart(); busy = true; close();
      input.value = ""; onInput(false);
      const restarting = /^\/restart\s*$/i.test(raw.trim());
      if (restarting) window.SMTOLifecycle?.begin();
      try {
        const response = await window.SMTOErrors.fetch("/api/agent/commands/execute", {method: "POST",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify({command: raw, context: protocol.context(captured, "desktop")})});
        const result = await window.SMTOErrors.readJson(response);
        if (!response.ok) {
          if (restarting && response.status < 500) window.SMTOLifecycle?.cancel();
          throw window.SMTOErrors.fromPayload(result, response.status);
        }
        if (restarting && result.status === 'error') window.SMTOLifecycle?.cancel();
        if (result.status === "error") onRejected(pendingDraft);
        else if (definition && !definition.destructive) recent = [...recent.filter(name => name !== definition.name), definition.name].slice(-5);
        await present(raw, result, captured);
      } catch (error) { if (restarting) window.SMTOLifecycle?.uncertain(); onRejected(pendingDraft); showToast(error); }
      finally { busy = false; onInput(false); }

 } finally { busyFeedback?.finish(); }
}
    input.addEventListener("input", () => { dismissed = false; selected = 0; update(); });
    return {isCommand, keydown, execute, update, isBusy: () => busy,
      discovery(value) { discovery = value; dismissed = false; update(); },
      load() {
        if (!loading) loading = window.SMTOErrors.fetch("/api/agent/commands", {cache: "no-store"})
          .then(async response => { if (!response.ok) throw await window.SMTOErrors.fromResponse(response); return window.SMTOErrors.readJson(response); })
          .then(payload => { commands = payload.commands || []; update(); })
          .catch(() => { commands = []; });
        return loading;
      }};
  }
})();
