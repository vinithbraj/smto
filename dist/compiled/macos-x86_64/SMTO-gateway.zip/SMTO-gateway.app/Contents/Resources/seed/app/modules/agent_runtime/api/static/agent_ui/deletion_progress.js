/* Shared deletion feedback follows server-reported cleanup through completion;
 * time passing never advances a percentage or invents a server-side phase. */
// Mobile history can open before the conversation's animation bundle is loaded.
import './task_disclosure.js?v=20261018-immersive-default';
if (!window.SMTOActivityUpdates) await import('./activity_update_animations.js?v=20261015-smto');
const style = document.createElement('link');
style.rel = 'stylesheet';
style.href = new URL('./deletion_progress.css?v=20261015-smto', import.meta.url).href;
document.head.append(style);

// Requests fence rows immediately; durable queue state comes only from the server.
const pending = new Map(), deleted = new Set(), queued = new Map(), collections = new Map();
const autoPurged = new Set();
let pollTimer, polling = null, pollAgain = false;
let announcedCollections = new Set();
const cleanupDetails = Object.freeze({
  queued: 'Cleanup queued', paused: 'Cleanup waits until tasks finish',
  cleaning: 'Cleaning up stored data', waiting_for_save: 'Waiting for save',
  purging: 'Removing saved copies', retrying: 'Cleanup will retry', complete: 'Cleanup complete',
});
const changed = () => { notifyQueue(); window.dispatchEvent(new Event('smto:conversation-deletion')); };
function progressTray() {
  let tray = document.querySelector('.deletion-progress-tray');
  if (!tray) { tray = document.createElement('div'); tray.className = 'deletion-progress-tray'; document.body.append(tray); }
  return tray;
}
function notifyQueue() {
  const owners = new Set(queued.values());
  const fresh = [...owners].some(owner => !announcedCollections.has(owner));
  announcedCollections = owners;
  // Announce new work once. Polling or phase changes must not reopen a notice
  // after the standard UI has timed it out, replaced it, or the user dismissed it.
  if (!fresh) return;
  const ids = [...queued.keys()];
  const id = ids.find(id => ['cleaning', 'purging', 'retrying', 'reconnecting'].includes(deletionState(id))) || ids[0];
  const phase = deletionState(id);
  const message = `Background cleanup · ${owners.size} pending · ${cleanupDetails[phase] || conversations.detail(id)}`;
  window.dispatchEvent(new CustomEvent('smto:background-notice', {detail: {message}}));
}
function apply(id, gc) {
  if (!gc?.deletion_id) return;
  if (gc.reason === 'auto_purge') autoPurged.add(id);
  if (gc.state !== 'complete' && collections.get(gc.deletion_id)?.state === 'complete') return;
  collections.set(gc.deletion_id, gc);
  if (gc.state === 'complete') { deleted.add(id); queued.delete(id); window.SMTOTaskDisclosure?.forget(id); }
  else { queued.set(id, gc.deletion_id); deleted.delete(id); }
}
function schedule() {
  if (!pollTimer && queued.size) pollTimer = setTimeout(poll, 1000);
}
function poll() {
  clearTimeout(pollTimer); pollTimer = null;
  if (polling) { pollAgain = true; return polling; }
  polling = (async () => {
    do { pollAgain = false; await readStatus(); } while (pollAgain);
  })().finally(() => { polling = null; schedule(); });
  return polling;
}
async function readStatus() {
  try {
    const response = await (window.SMTOAuth?.fetch || window.fetch)('/api/agent/conversation-gc', {cache: 'no-store', signal: AbortSignal.timeout(5000)});
    if (!response.ok) throw new Error('Status unavailable');
    const summary = await response.json();
    const statuses = new Map((summary.collections || []).map(gc => [gc.deletion_id, gc]));
    for (const gc of statuses.values()) if (gc.reason === 'auto_purge')
      for (const id of gc.conversation_ids || []) apply(id, gc);
    const known = new Set(queued.values());
    for (const gc of statuses.values()) if (gc.state !== 'complete' && !known.has(gc.deletion_id))
      apply(`cleanup:${gc.deletion_id}`, gc);
    for (const [id, owner] of queued) {
      const gc = statuses.get(owner);
      if (gc) apply(id, gc);
    }
  } catch {
    for (const identity of new Set(queued.values())) {
      const gc = collections.get(identity);
      if (gc) collections.set(identity, {...gc, unavailable: true});
    }
  } finally { changed(); }
}
function deletionState(id) {
  const gc = collections.get(queued.get(id));
  if (gc?.unavailable) return 'reconnecting';
  if (deleted.has(id)) return 'complete';
  if (pending.has(id) && !gc) return 'requesting';
  if (gc?.phase) return gc.phase;
  if (gc?.state === 'pending_delete' && gc.ram_complete && gc.waiting_for === 'checkpoint') return 'waiting_for_cleanup';
  return gc?.state || 'pending_delete';
}
export const conversations = Object.freeze({
  refresh: poll,
  autoPurged: id => autoPurged.has(id),
  isDeleting: id => pending.has(id) || queued.has(id),
  isDeleted: id => deleted.has(id) || queued.has(id),
  isComplete: id => deleted.has(id),
  blocked: id => pending.has(id) || queued.has(id) || deleted.has(id),
  hasPending: () => pending.size > 0 || queued.size > 0,
  state: deletionState,
  label(id) {
    return {requesting: 'Requesting deletion…', pending_delete: 'Pending delete', deleting: 'Deleting…',
      waiting_for_cleanup: 'Waiting for cleanup', retrying: 'Retrying deletion…',
      queued: 'Cleanup queued', paused: 'Cleanup paused', cleaning: 'Cleaning up…',
      waiting_for_save: 'Waiting for save', purging: 'Removing saved copies…',
      reconnecting: 'Reconnecting', complete: 'Deleted'}[deletionState(id)] || 'Pending delete';
  },
  detail(id) {
    const gc = collections.get(queued.get(id));
    if (gc?.unavailable) return 'Deletion status unavailable · Reconnecting';
    if (gc?.phase === 'complete') return cleanupDetails.complete;
    if (gc?.phase) return `Removed · ${cleanupDetails[gc.phase] || cleanupDetails.queued}`;
    if (gc?.state === 'deleting') return gc.ram_complete ? 'Deleting… · Purging saved data' : 'Deleting… · Clearing conversation data';
    if (gc?.state === 'retrying') return 'Retrying deletion… · Cleanup failed; retrying automatically';
    if (gc?.waiting_for === 'checkpoint') return 'Waiting for cleanup · Conversation data cleared; waiting to remove saved copies';
    if (gc?.waiting_for === 'active_tasks') return 'Pending delete · Waiting for active tasks to finish';
    return pending.has(id) && !gc ? 'Requesting deletion…' : 'Pending delete · Waiting for idle cleanup';
  },
  ingest(rows) {
    for (const row of rows || []) if (row.gc) apply(row.conversation_id, row.gc);
    notifyQueue();
    schedule();
  },
  track(gc) { apply(`cleanup:${gc.deletion_id}`, gc); changed(); schedule(); },
  begin(identities) {
    const ids = [...new Set(identities)];
    for (const id of ids) pending.set(id, (pending.get(id) || 0) + 1);
    changed();
    let settled = false;
    return result => {
      if (settled) return;
      settled = true;
      // Durable acceptance removes navigation immediately; cleanup has its own status.
      const accepted = result?.accepted_ids || [];
      for (const id of accepted) apply(id, result.collections?.find(gc => gc.deletion_id === result.deletion_ids?.[id]) || result.gc);
      for (const id of result?.deleted_ids || (result?.deleted_count === ids.length ? ids : [])) {
        deleted.add(id); window.SMTOTaskDisclosure?.forget(id);
      }
      for (const id of ids) {
        const count = pending.get(id) - 1;
        if (count) pending.set(id, count); else pending.delete(id);
      }
      changed();
      schedule();
    };
  },
});
window.SMTOConversationDeletion = conversations;
// Discover task-only queues on reload too, then stop polling when the queue is empty.
queueMicrotask(() => void poll());
window.SMTOUiUpdates?.subscribe(['chats.changed', 'sync.required'], () => void poll());

export function create(host) {
  const element = document.createElement('div'); element.className = 'deletion-progress'; element.hidden = true;
  const row = document.createElement('div'); row.className = 'deletion-progress-row';
  const status = document.createElement('span'); status.className = 'deletion-progress-status';
  status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite'); status.setAttribute('aria-atomic', 'true');
  const copy = document.createElement('span'); copy.className = 'task-activity-copy';
  const label = document.createElement('span'); label.className = 'deletion-progress-label'; copy.append(label); status.append(copy);
  const elapsed = document.createElement('span'); elapsed.className = 'deletion-progress-elapsed';
  const track = document.createElement('div'); track.className = 'deletion-progress-track';
  track.setAttribute('role', 'progressbar'); track.setAttribute('aria-label', 'Conversation deletion');
  track.setAttribute('aria-valuemin', '0'); track.setAttribute('aria-valuemax', '1'); track.append(document.createElement('span'));
  row.append(status, elapsed); element.append(row, track); host.append(element);
  let timer, removal, started = 0, active = false, persistent = false, disposed = false;
  let acceptedIds = [];
  function queueUpdate() {
    if (!acceptedIds.length || disposed) return;
    if (acceptedIds.every(id => conversations.isComplete(id))) {
      acceptedIds = [];
      terminal('Conversation deletion complete', 'complete');
    } else {
      const busy = id => ['deleting', 'cleaning', 'purging'].includes(conversations.state(id));
      const id = acceptedIds.find(busy) || acceptedIds.find(id => !conversations.isComplete(id));
      element.dataset.state = busy(id) ? 'busy' : 'pending';
      text(conversations.detail(id));
    }
  }
  window.addEventListener('smto:conversation-deletion', queueUpdate);
  function text(message, kind = 'runtime') {
    if (label.textContent !== message) label.textContent = message;
    label.title = message;
    window.SMTOActivityUpdates?.update(copy, {label: message, kind});
    track.setAttribute('aria-valuetext', message);
  }
  function tick() {
    const seconds = Math.floor(Math.max(0, performance.now() - started) / 1000);
    elapsed.textContent = seconds < 60 ? `${seconds}s` : `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    elapsed.title = `${seconds} seconds elapsed`;
  }
  function visibility() { element.dataset.paused = String(document.hidden); }
  document.addEventListener('visibilitychange', visibility); visibility();
  function dispose() {
    if (disposed) return;
    disposed = true; active = false; clearInterval(timer); clearTimeout(removal);
    window.SMTOActivityUpdates?.update(copy, {label: '', kind: 'idle'});
    document.removeEventListener('visibilitychange', visibility);
    window.removeEventListener('smto:conversation-deletion', queueUpdate);
    const parent = element.parentElement;
    element.remove();
    if (parent?.classList.contains('deletion-progress-tray') && !parent.children.length) parent.remove();
  }
  function detach() {
    if (disposed || element.hidden) return;
    const tray = progressTray();
    if (element.parentElement === tray) return;
    tray.append(element);
    if (!active) removal = setTimeout(dispose, 6000);
  }
  function close() {
    if (persistent) detach();
    else dispose();
  }
  function start(message, {persist = false} = {}) {
    if (disposed) return;
    clearTimeout(removal); clearInterval(timer);
    active = true; persistent = persist; started = performance.now();
    element.hidden = false; element.dataset.state = 'busy'; elapsed.hidden = false;
    track.removeAttribute('aria-valuenow'); text(message); tick(); timer = setInterval(tick, 1000);
  }
  function update(message) { if (!disposed) text(message); }
  function hide() {
    if (disposed) return;
    active = false; clearInterval(timer); element.hidden = true;
    window.SMTOActivityUpdates?.update(copy, {label: '', kind: 'idle'});
  }
  function terminal(message, state) {
    if (disposed) return;
    active = false; clearInterval(timer); elapsed.hidden = true;
    element.hidden = false; element.dataset.state = state;
    if (state === 'complete') track.setAttribute('aria-valuenow', '1');
    else track.removeAttribute('aria-valuenow');
    text(message, 'terminal');
    if (element.parentElement?.classList.contains('deletion-progress-tray')) removal = setTimeout(dispose, 6000);
  }
  function finish(result, {refreshFailed = false} = {}) {
    if (result.accepted_count) {
      terminal(result.accepted_count === 1 ? 'Pending delete · Cleanup runs when no tasks are active'
        : `${result.accepted_count} pending delete · Cleanup runs when no tasks are active`, 'pending');
      acceptedIds = result.accepted_ids || [];
      queueUpdate();
      return;
    }
    const count = result.deleted_count ?? 1;
    let message = count === 1 ? 'Conversation deleted' : `${count} conversations deleted`;
    if (refreshFailed) message += ' · Refresh the list to update it';
    else if (result.gc?.disk_status && result.gc.disk_status !== 'complete') {
      message += ` · Storage cleanup ${result.gc.disk_status === 'retrying' ? 'retrying' : result.gc.disk_status === 'running' ? 'running' : 'queued'}`;
    } else if (result.gc?.unresolved_operations) message += ' · Unfinished work is being reconciled';
    terminal(message, 'complete');
  }
  return {element, start, update, hide, detach, close, dispose, finish,
    fail: message => terminal(message, 'failed')};
}
