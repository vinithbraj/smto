/**
 * @file src/agent_runtime/api/static/agent_ui/docs_link.js
 * @brief Navigate a validated citation using the shared Manual deployment policy.
 * @details
 * Responsibilities: Copy server-validated bookmark fields into the existing URL resolver.
 * Boundaries: No document retrieval, external fetch or capability authority.
 * Lifecycle: Runs once on the same-origin citation navigation page.
 * State: Reads inert data attributes; retains no user preferences or credentials.
 * Security: The resolver constructs URLs; this script never accepts a destination URL.
 * Collaborators: docs_links.py validates fields; manual_links.js owns deployment resolution.
 * Public surface: Page entry point sets a usable anchor then replaces the navigation location.
 * @see src/agent_runtime/api/docs_links.py
 * @see src/agent_runtime/api/static/agent_ui/manual_links.js
 */
(() => {
  "use strict";
  const source = document.querySelector("main[data-document]").dataset;
  const url = window.SMTOManualLinks.manualUrl(source.document, source.port, source.heading);
  document.getElementById("manual-link").href = url;
  window.location.replace(url);
})();
