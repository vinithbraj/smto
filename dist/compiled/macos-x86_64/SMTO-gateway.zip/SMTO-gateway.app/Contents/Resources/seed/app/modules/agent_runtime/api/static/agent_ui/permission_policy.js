/* Composer permissions. Authority is validated and enforced by the runtime. */
(() => {
  "use strict";
  const clone = value => JSON.parse(JSON.stringify(value));
  const decisions = ["allow", "ask", "deny"], modes = ["manual", "custom", "full_access", "deny"];
  const names = {manual: "Ask", custom: "Custom", full_access: "Allow", deny: "Deny"};
  const title = value => value[0].toUpperCase() + value.slice(1);
  const identity = rule => rule.skill_id || rule.tool_id || [rule.executable, ...rule.argv_prefix].join(" ");
  const fields = ["skill_rules", "tool_rules", "shell_rules"];
  const name = /^[a-zA-Z0-9_][a-zA-Z0-9_.+-]{0,63}$/;
  // Generated from permission_policy.py; the backend remains the canonical validator.
  const families = {"apt": ["install", "remove", "purge", "update", "upgrade", "autoremove", "clean", "show", "list", "search"], "apt-get": ["install", "remove", "purge", "update", "upgrade", "autoremove", "clean", "download", "check"], "cargo": ["build", "check", "test", "run", "clean", "install", "update", "publish"], "docker": ["compose", "container", "image", "volume", "network", "build", "run", "start", "stop", "restart", "exec", "logs", "ps", "pull", "push", "rm", "rmi", "inspect"], "gh": ["pr", "issue", "repo", "auth", "release", "workflow", "run", "api"], "git": ["add", "commit", "push", "pull", "fetch", "status", "diff", "log", "show", "branch", "checkout", "switch", "restore", "reset", "clean", "rm", "mv", "merge", "rebase", "tag", "stash", "worktree", "remote", "init", "clone"], "go": ["build", "test", "run", "clean", "install", "get", "mod", "version", "env"], "kubectl": ["apply", "get", "describe", "delete", "create", "replace", "patch", "edit", "logs", "exec", "rollout", "scale", "config"], "npm": ["install", "ci", "run", "test", "build", "audit", "update", "uninstall", "publish", "exec"], "pip": ["install", "uninstall", "download", "list", "show", "check", "freeze"], "pip3": ["install", "uninstall", "download", "list", "show", "check", "freeze"], "pnpm": ["install", "add", "remove", "run", "test", "build", "exec", "dlx", "publish"], "podman": ["compose", "container", "image", "volume", "network", "build", "run", "start", "stop", "restart", "exec", "logs", "ps", "pull", "push", "rm", "rmi", "inspect"], "systemctl": ["restart", "start", "stop", "reload", "enable", "disable", "status", "show", "list-units", "daemon-reload", "is-active", "is-enabled"], "uv": ["sync", "run", "add", "remove", "lock", "pip", "tool", "python"], "yarn": ["install", "add", "remove", "run", "test", "build", "exec"]};
  const subfamilies = {"docker compose": ["up", "down", "build", "pull", "push", "start", "stop", "restart", "logs", "ps", "run", "exec", "config"], "gh issue": ["create", "view", "list", "close", "reopen", "comment"], "gh pr": ["create", "view", "list", "diff", "checks", "checkout", "merge", "close", "reopen", "review"], "git remote": ["add", "remove", "rename", "show", "prune", "update"], "git stash": ["push", "pop", "apply", "list", "show", "drop", "clear"], "git worktree": ["add", "list", "remove", "prune", "move", "repair"], "go mod": ["download", "tidy", "vendor", "verify", "graph", "init", "edit"], "kubectl rollout": ["status", "restart", "undo", "history", "pause", "resume"], "podman compose": ["up", "down", "build", "pull", "push", "start", "stop", "restart", "logs", "ps", "run", "exec", "config"], "uv pip": ["install", "uninstall", "sync", "list", "show", "freeze", "check"]};
  function canonical(value = {}) {
    if (!value || typeof value !== "object" || Array.isArray(value)
      || Object.keys(value).some(k => !["schema_version", "mode", "default_confirmation_decision", ...fields].includes(k))
      || value.schema_version !== undefined && value.schema_version !== 1) throw window.SMTOErrors.error("ui_permission_policy_invalid");
    const mode = value.mode === undefined ? "manual" : value.mode;
    const fallback = value.default_confirmation_decision === undefined ? "ask" : value.default_confirmation_decision;
    if (!modes.includes(mode) || !decisions.includes(fallback)) throw window.SMTOErrors.error("ui_permission_policy_invalid");
    const result = {schema_version: 1, mode, default_confirmation_decision: mode === "custom" ? fallback : mode === "full_access" ? "allow" : mode === "deny" ? "deny" : "ask"};
    for (const field of fields) {
      const rules = value[field] === undefined ? [] : value[field], unique = new Map();
      if (!Array.isArray(rules) || rules.length > (field === "skill_rules" ? 32 : 128)) throw window.SMTOErrors.error("ui_permission_rule_limit");
      for (const rule of rules) {
        if (!rule || !decisions.includes(rule.decision)) throw window.SMTOErrors.error("ui_permission_rule_invalid");
        let safe;
        if (field === "shell_rules") {
          const args = rule.argv_prefix === undefined ? [] : rule.argv_prefix;
          if (typeof rule.executable !== "string" || !name.test(rule.executable) || !Array.isArray(args) || args.length > 4
            || args.some((token, i) => typeof token !== "string" || !name.test(token)
              || !(i === 0 ? families[rule.executable] || [] : subfamilies[[rule.executable, ...args.slice(0, i)].join(" ")] || []).includes(token))
            || Object.keys(rule).some(k => !["executable", "argv_prefix", "decision"].includes(k))) {
            throw window.SMTOErrors.error("ui_permission_argument_unsupported");
          }
          safe = {executable: rule.executable, argv_prefix: [...args], decision: rule.decision};
        } else {
          const key = field === "skill_rules" ? "skill_id" : "tool_id", id = rule[key];
          const pattern = key === "skill_id" ? /^[a-z][a-z0-9_]{0,127}$/ : /^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$/;
          if (typeof id !== "string" || id.length > 256 || !pattern.test(id)
            || Object.keys(rule).some(k => ![key, "decision"].includes(k))) throw window.SMTOErrors.error("ui_permission_rule_invalid");
          safe = {[key]: id, decision: rule.decision};
        }
        const id = identity(safe);
        if (unique.has(id) && unique.get(id).decision !== safe.decision) throw window.SMTOErrors.error("ui_permission_rule_conflict");
        unique.set(id, safe);
      }
      result[field] = [...unique].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([, rule]) => rule);
      if (mode !== "custom" && result[field].length) throw window.SMTOErrors.error("ui_permission_custom_required");
    }
    return result;
  }
  function safeDraftState(value) {
    const safe = value => { try { return value ? canonical(value) : null; } catch (_) { return null; } };
    const prompt = value?.has_prompt_override === true ? safe(value.policy) : null, pending = safe(value?.pending_policy);
    return {has_prompt_override: prompt !== null, ...(prompt ? {policy: prompt} : {}), ...(pending ? {pending_policy: pending} : {})};
  }
  function create({apiJson, mode, button, chips, presetSelect, scopeSelect, globalOnly = false, notify = () => {}, onDraftChanged = () => {}, pendingApproval = () => null, approvePolicy = null}) {
    let catalog = null, catalogLoad = null, conversationId = null;
    let promptPolicy = null, pendingPolicy = null, generation = 0, revision = 0, readVersion = 0;
    let draft = canonical(), dirty = false, saving = false, refresh = null, refreshAgain = false;
    let resolved = {policy: canonical(), source: "default", scopes: {}}, editingRequestId = null, editingRevision = 0;
    let composerScope = null, loaded = false;
    const scopeNames = {prompt: "This prompt", conversation: "This conversation", global: "Global", default: "Product default"};
    const sourceLabel = document.createElement("small"); sourceLabel.className = "permission-source";
    scopeSelect.parentElement.after(sourceLabel);
    const json = (method, value) => ({method, headers: {"Content-Type": "application/json"}, ...(value === undefined ? {} : {body: JSON.stringify(value)})});
    const dialog = document.createElement("dialog");
    dialog.className = "capability-dialog permission-dialog"; dialog.setAttribute("aria-labelledby", "permission-title");
    dialog.innerHTML = `<form method="dialog">
      <header><h2 id="permission-title">Permissions</h2><button type="button" data-close aria-label="Close permission editor" data-ui-symbol="cross">×</button></header>
      <label>Apply to <select data-scope aria-label="Permission policy scope"><option value="prompt">This prompt</option><option value="conversation">This conversation</option><option value="global">Global</option></select></label>
      <p data-mode-note class="capability-help" hidden>Ask mode does not execute operational capabilities. You can still edit conversation and global preferences.</p>
      <p data-source class="capability-help"></p><p data-scope-help class="capability-help"></p>
      <p data-error role="alert" hidden></p>
      <div class="capability-editor-scroll"><fieldset data-editor>
        <label>Permissions <select data-preset aria-label="Permission preset"><option value="manual">Ask</option><option value="custom">Custom</option><option value="full_access">Allow</option><option value="deny">Deny</option></select></label>
        <p data-description class="capability-help"></p>
        <section data-custom><label>When an operation would normally require approval <select data-default aria-label="Default confirmation decision"><option value="allow">Allow</option><option value="ask">Ask</option><option value="deny">Deny</option></select></label></section>
        <p class="capability-help">Adding a rule converts a preset to Custom and keeps its default decision.</p>
        <input type="search" data-search aria-label="Search permission Skills and tools" placeholder="Search Skills and tools">
        <div data-skills></div>
        <section><h3>Shell command permissions</h3><p class="capability-help">Rules match executable/subcommand families, such as git commit. They do not match natural-language concepts. Use Approve once for exact arguments.</p>
          <div class="capability-executable-input"><input data-family aria-label="Shell command family" placeholder="git commit" maxlength="256"><select data-decision aria-label="Shell permission decision"><option value="allow">Allow</option><option value="ask">Ask</option><option value="deny">Deny</option></select><button type="button" data-add>Add rule</button></div>
          <div data-shell-rules></div></section>
      </fieldset></div>
      <footer><span class="capability-help">Saved conversation and global changes apply from now on.</span><button type="button" data-inherit>Use inherited permissions</button><button type="button" data-cancel>Cancel</button><button type="button" data-apply>Apply</button></footer>
    </form>`;
    document.body.append(dialog);
    const find = selector => dialog.querySelector(selector), scope = find("[data-scope]"), search = find("[data-search]");
    if (globalOnly) {
      for (const option of [...scope.options]) if (option.value !== "global") option.remove();
      scope.value = scopeSelect.value = "global";
    }
    const report = text => { find("[data-error]").textContent = text || ""; find("[data-error]").hidden = !text; };
    const url = id => `/api/agent/chats/${encodeURIComponent(id)}/permission-policy`;
    const effectivePolicy = () => clone(resolved.policy);
    const policyForRequest = () => promptPolicy === null ? null : clone(promptPolicy);
    const draftSnapshot = () => safeDraftState({has_prompt_override: promptPolicy !== null, policy: promptPolicy, pending_policy: pendingPolicy});
    function renderChips() {
      const policy = effectivePolicy(), rules = fields.flatMap(field => policy[field]);
      const source = resolved.source === "default" ? "global" : resolved.source;
      scopeSelect.value = composerScope || source;
      const selected = policyAt(scopeSelect.value), count = fields.flatMap(field => selected[field]).length;
      presetSelect.value = selected.mode;
      presetSelect.querySelector('[value="custom"]').textContent = `Custom${count ? " · " + count : ""}`;
      presetSelect.disabled = scopeSelect.disabled = saving || !loaded;
      button.disabled = saving;
      button.title = `Edit permissions · Active: ${names[policy.mode]} · ${scopeNames[resolved.source]}`;
      presetSelect.title = `Permissions for ${scopeNames[scopeSelect.value]}`;
      sourceLabel.textContent = `Active: ${names[policy.mode]} · ${scopeNames[resolved.source]}`;
      sourceLabel.hidden = scopeSelect.value === source;
      find("[data-source]").textContent = `Permissions: ${names[resolved.policy.mode]} — ${scopeNames[resolved.source]}`;
      chips.replaceChildren(); chips.hidden = !rules.length; chips.dataset.advisory = String(mode() === "advisory");
      for (const rule of rules.slice(0, 4)) {
        const chip = document.createElement("button"); chip.type = "button"; chip.className = "capability-chip";
        chip.dataset.decision = rule.decision; chip.textContent = `${title(rule.decision)} ${identity(rule)}`;
        chip.onclick = () => open(); chips.append(chip);
      }
      if (rules.length > 4) { const more = document.createElement("button"); more.type = "button"; more.className = "capability-chip"; more.textContent = `+${rules.length - 4} more`; more.onclick = () => open(); chips.append(more); }
    }
    function setRule(field, rule, decision) {
      const next = clone(draft); next.mode = "custom";
      next[field] = next[field].filter(item => identity(item) !== identity(rule));
      if (decision !== "default") next[field].push({...rule, decision});
      draft = canonical(next); dirty = true; report("");
    }
    function row(field, rule, label, description) {
      const root = document.createElement("div"); root.className = "capability-row";
      const text = document.createElement("div"), strong = document.createElement("strong"), detail = document.createElement("small");
      strong.textContent = label; detail.textContent = description; detail.className = "capability-description"; text.append(strong, detail);
      const select = document.createElement("select"); select.setAttribute("aria-label", `Permission for ${label}`);
      for (const decision of ["default", ...decisions]) { const option = document.createElement("option"); option.value = decision; option.textContent = title(decision); select.append(option); }
      select.value = draft[field].find(item => identity(item) === identity(rule))?.decision || "default";
      select.onchange = () => { try { setRule(field, rule, select.value); renderEditor(); } catch (error) { report(error.message); } };
      root.append(text, select); return root;
    }
    function renderEditor() {
      find("[data-preset]").value = draft.mode; find("[data-default]").value = draft.default_confirmation_decision;
      find("[data-custom]").hidden = draft.mode !== "custom";
      find("[data-description]").textContent = {deny: "Deny permission-gated operations. Narrower explicit authority can override this setting.", manual: "Reads execute normally. Approval is requested before state-changing, unknown, or elevated operations.", custom: "Choose what should run automatically, ask, or be denied.", full_access: "Task-relevant operations execute without routine approval. Capability exclusions, hard safety, credentials, OS permissions, and provider authorization still apply."}[draft.mode];
      find("[data-inherit]").textContent = scope.value === "global" ? "Reset to product default" : "Use inherited permissions";
      find("[data-scope-help]").textContent = {prompt: "Only this task.", conversation: "This chat from now on.", global: "All conversations unless overridden."}[scope.value];
      const expanded = new Set([...dialog.querySelectorAll("details[open]")].map(item => item.dataset.skill));
      const list = find("[data-skills]"); list.replaceChildren();
      const query = search.value.toLowerCase().trim();
      for (const skill of catalog?.skills || []) {
        if (![skill.skill_id, skill.display_name, skill.description, ...skill.tools.flatMap(t => [t.tool_id, t.display_name, t.description])].join(" ").toLowerCase().includes(query)) continue;
        const section = document.createElement("section"); section.className = "capability-skill";
        section.append(row("skill_rules", {skill_id: skill.skill_id}, skill.display_name, skill.description + (skill.available ? "" : ` Unavailable: ${skill.reason}`)));
        const details = document.createElement("details"); details.dataset.skill = skill.skill_id; details.open = Boolean(query) || expanded.has(skill.skill_id);
        const summary = document.createElement("summary"); summary.textContent = `Tools (${skill.tools.length})`; details.append(summary);
        for (const tool of skill.tools) details.append(row("tool_rules", {tool_id: tool.tool_id}, tool.tool_id, `${tool.display_name} · ${tool.description}`));
        section.append(details); list.append(section);
      }
      for (const tool of catalog?.tools || []) if ([tool.tool_id, tool.display_name, tool.description].join(" ").toLowerCase().includes(query)) list.append(row("tool_rules", {tool_id: tool.tool_id}, tool.tool_id, tool.description));
      const shell = find("[data-shell-rules]"); shell.replaceChildren();
      for (const rule of draft.shell_rules) shell.append(row("shell_rules", rule, identity(rule), "Executable/subcommand family"));
    }
    function modeChanged() {
      scope.disabled = globalOnly || saving;
      find("[data-editor]").disabled = saving; find("[data-apply]").disabled = saving;
      find("[data-inherit]").disabled = saving;
      find("[data-mode-note]").hidden = mode() !== "advisory";
      renderChips();
    }
    async function loadCatalog() {
      if (catalog) return catalog;
      catalogLoad ||= apiJson("/api/agent/capabilities/catalog").then(value => { catalog = value; return value; }).finally(() => { catalogLoad = null; });
      return catalogLoad;
    }
    function previewPayload() {
      return editingRequestId ? {request_id: editingRequestId} : {
        conversation_id: conversationId, prompt_policy: promptPolicy,
        conversation_policy: conversationId ? null : pendingPolicy,
      };
    }
    function policyAt(selected) {
      const hierarchy = ["prompt", "conversation", "global"];
      for (const key of hierarchy.slice(hierarchy.indexOf(selected))) {
        if (resolved.scopes[key]?.policy) return resolved.scopes[key].policy;
      }
      return canonical();
    }
    const selectedPolicy = () => policyAt(scope.value);
    async function refreshConversation() {
      if (refresh) { refreshAgain = true; return refresh; }
      const epoch = generation, version = readVersion, payload = previewPayload();
      const preview = payload.prompt_policy || payload.conversation_policy;
      const params = new URLSearchParams(Object.entries(payload).filter(([,value]) => value !== null));
      const request = preview ? apiJson("/api/agent/permissions/effective", json("POST", payload))
        : apiJson(`/api/agent/permissions/effective?${params}`);
      refresh = request.then(value => {
        if (epoch !== generation || version !== readVersion) return;
        resolved = value; loaded = true;
        renderChips();
        if (dialog.open && !dirty) { editingRevision = value.scopes[scope.value]?.revision || 0; draft = canonical(selectedPolicy()); renderEditor(); }
        else if (dialog.open && dirty) report("Permissions changed. Your unsaved edits are still shown; reload before overwriting a newer choice.");
      }).catch(error => notify(error.message)).finally(() => {
        refresh = null;
        if (refreshAgain) { refreshAgain = false; void refreshConversation(); }
      });
      return refresh;
    }
    const loadDefaults = refreshConversation;
    async function open({requestId = null, selectedScope = null} = {}) {
    const busyFeedback = window.SMTOBusy?.begin({host: dialog.querySelector("header"), label: "Loading permissions…", key: "open", replace: true});
    try {
      if (saving) return;
      editingRequestId = requestId || pendingApproval(); generation++;
      scope.value = globalOnly ? "global" : selectedScope || (requestId ? "prompt" : scopeSelect.value);
      editingRevision = resolved.scopes[scope.value]?.revision || 0;
      draft = canonical(selectedPolicy()); dirty = false; search.value = "";
      report(""); modeChanged(); renderEditor();
      find(".capability-editor-scroll").scrollTop = 0;
      if (!dialog.open) dialog.showModal();
      try { await Promise.all([loadCatalog(), refreshConversation()]); if (dialog.open && (!busyFeedback || busyFeedback.current)) renderEditor(); }
      catch (error) { if (!busyFeedback || busyFeedback.current) report(error.message); }

    } finally { busyFeedback?.finish(); }
  }
    function setConversation(id) {
      generation++; revision++; conversationId = id || null;
      composerScope = null; loaded = false;
      promptPolicy = null; pendingPolicy = null; editingRequestId = null; dirty = false;
      dialog.close(); modeChanged(); void refreshConversation();
    }
    function followConversation(id) {
      if ((id || null) === conversationId) return;
      generation++; conversationId = id || null;
      void refreshConversation();
    }
    function submissionSnapshot() {
      return {policy: policyForRequest(), pending: clone(pendingPolicy), generation, revision};
    }
    async function requestAccepted(id, snapshot) {
      if (generation !== snapshot.generation && conversationId !== id) return;
      conversationId = id || null; editingRequestId = null;
      if (revision === snapshot.revision) { promptPolicy = null; pendingPolicy = null; composerScope = null; }
      await refreshConversation(); onDraftChanged(false);
    }
    async function persist(policy) {
      const selected = scope.value;
      if (selected === "global" && policy?.mode === "full_access"
        && resolved.scopes.global?.policy?.mode !== "full_access"
        && !window.confirm("Allow permission-gated operations across conversations without asking each time?\n\nNarrower conversation or prompt overrides still apply.")) return false;
      if (policy && pendingApproval() && approvePolicy && ["full_access", "deny"].includes(policy.mode)) {
        await approvePolicy(pendingApproval(), selected, policy, editingRevision);
      } else if (selected === "prompt" && !editingRequestId) promptPolicy = policy;
      else if (selected === "conversation" && !conversationId) pendingPolicy = policy;
      else {
        const base = selected === "global" ? "/api/agent/permissions/global"
          : selected === "conversation" ? url(conversationId)
          : `/api/agent/native/${encodeURIComponent(editingRequestId)}/permission-policy`;
        const expected = editingRevision;
        readVersion++;
        await apiJson(`${base}?expected_revision=${expected}`, json(policy === null ? "DELETE" : "PUT", policy === null ? undefined : policy));
        readVersion++;
      }
      return true;
    }
    async function apply(inherit = false, fromComposer = false) {
    const busyFeedback = window.SMTOBusy?.begin({host: dialog.querySelector("footer") || presetSelect, label: "Saving permissions…"});
    try {
      if (saving) return;
      saving = true; modeChanged(); report("");
      const epoch = generation;
      try {
        const policy = inherit ? null : await apiJson("/api/agent/permissions/validate", json("POST", canonical(draft)));
        if (epoch !== generation) return;
        if (!await persist(policy)) return;
        if (epoch !== generation) return;
        revision++; dirty = false; dialog.close(); editingRequestId = null;
        if (!fromComposer) composerScope = null;
        await refreshConversation(); onDraftChanged();
      } catch (error) { if (fromComposer) notify(error.message); else report(error.message); }
      finally { if (fromComposer) editingRequestId = null; saving = false; modeChanged(); }

    } finally { busyFeedback?.finish(); }
  }
    function addFamily() {
      try {
        const tokens = find("[data-family]").value.trim().split(/\s+/);
        setRule("shell_rules", {executable: tokens[0], argv_prefix: tokens.slice(1)}, find("[data-decision]").value);
        find("[data-family]").value = ""; renderEditor();
      } catch (error) { report(error.message); }
    }
    function restoreDraftState(value) {
      const saved = safeDraftState(value); generation++; revision++;
      composerScope = null; loaded = false;
      promptPolicy = saved.has_prompt_override ? saved.policy : null;
      pendingPolicy = !conversationId ? saved.pending_policy || null : null;
      dialog.close(); modeChanged(); void refreshConversation(); onDraftChanged();
    }
    button.onclick = open;
    scopeSelect.onchange = () => { composerScope = scopeSelect.value; renderChips(); };
    presetSelect.onchange = async () => {
      if (saving || !loaded) return;
      const preset = presetSelect.value, selectedScope = scopeSelect.value;
      if (preset === "custom") {
        await open({selectedScope});
        if (dialog.open && scope.value === selectedScope) {
          draft = canonical({...draft, mode: "custom"}); dirty = true; renderEditor();
        }
        return;
      }
      composerScope = selectedScope;
      editingRequestId = pendingApproval();
      scope.value = selectedScope; editingRevision = resolved.scopes[selectedScope]?.revision || 0;
      draft = canonical({mode: preset});
      await apply(false, true);
    };
    const closeEditor = () => { editingRequestId = null; generation++; dirty = false; dialog.close(); void refreshConversation(); };
    find("[data-close]").onclick = find("[data-cancel]").onclick = closeEditor;
    dialog.addEventListener("cancel", event => { event.preventDefault(); closeEditor(); });
    find("form").onsubmit = event => event.preventDefault(); find("[data-apply]").onclick = () => apply();
    find("[data-inherit]").onclick = () => apply(true);
    find("[data-preset]").onchange = event => { draft = event.target.value === "custom" ? canonical({...draft, mode: "custom"}) : canonical({mode: event.target.value}); dirty = true; renderEditor(); };
    find("[data-default]").onchange = event => { draft.default_confirmation_decision = event.target.value; dirty = true; };
    scope.onchange = () => { editingRevision = resolved.scopes[scope.value]?.revision || 0; draft = canonical(selectedPolicy()); dirty = false; report(""); renderEditor(); };
    search.oninput = renderEditor; find("[data-add]").onclick = addFamily;
    find("[data-family]").onkeydown = event => { if (event.key === "Enter") { event.preventDefault(); addFamily(); } };
    const unsubscribe = window.SMTOUiUpdates?.subscribe("permission-policy.changed", payload => {
      if (payload.syncRequired || payload.events.some(event => event.topics?.includes("permission-policy.changed"))) void refreshConversation();
    });
    const unsubscribeDefaults = window.SMTOUiUpdates?.subscribe("runtime-controls.changed", () => loadDefaults().catch(error => notify(error.message)));
    modeChanged();
    return {open, loadCatalog, loadDefaults, modeChanged, effectivePolicy, policyForRequest, submissionSnapshot, requestAccepted,
      setConversation, followConversation, refreshConversation, draftSnapshot, restoreDraftState,
      pendingConversationPolicy: () => clone(pendingPolicy), reset: () => setConversation(null),
      destroy: () => { unsubscribe?.(); unsubscribeDefaults?.(); dialog.remove(); sourceLabel.remove(); }};
  }
  window.SMTOPermissionPolicy = {create, canonical, safeDraftState, names, families, subfamilies};
})();
