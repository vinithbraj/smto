/* Local presentation state only; conversation data remains server-owned. */
(() => {
  "use strict";
  function create({drawer, shell, layout, scrim, toggle, close, dock, resize, refresh, closeMenu}) {
    const session = window.SMTOUiSession;
    const desktop = window.matchMedia("(min-width: 960px)");
    let preferredWidth = session.get("conversation_pane_width", 380);
    let docked = session.get("conversation_pane_docked", false);
    let visible = session.get("conversation_pane_visible", false), drag = null, opener = toggle;
    const isDocked = () => docked && desktop.matches;
    const isTemporary = () => visible && !isDocked();
    function bounds() {
      const available = document.documentElement.clientWidth;
      const max = desktop.matches ? Math.min(560, available - 640) : Math.min(560, available - 16);
      return {min: Math.min(300, max), max};
    }
    function applyWidth() {
      const {min, max} = bounds();
      const width = innerWidth <= 620 ? max : Math.round(Math.max(min, Math.min(max, preferredWidth)));
      layout.style.setProperty("--conversation-pane-width", `${width}px`);
      resize.setAttribute("aria-valuemin", String(min));
      resize.setAttribute("aria-valuemax", String(max));
      resize.setAttribute("aria-valuenow", String(width));
      resize.setAttribute("aria-valuetext", `${width} pixels`);
      return width;
    }
    function render() {
      const persistent = visible && isDocked(), temporary = isTemporary();
      layout.classList.toggle("history-docked", persistent);
      drawer.dataset.docked = String(persistent);
      drawer.inert = !visible;
      drawer.setAttribute("aria-hidden", String(!visible));
      drawer.setAttribute("role", temporary ? "dialog" : "complementary");
      if (temporary) drawer.setAttribute("aria-modal", "true");
      else drawer.removeAttribute("aria-modal");
      toggle.setAttribute("aria-expanded", String(visible));
      scrim.hidden = !temporary;
      shell.inert = temporary;
      const label = docked ? "Undock conversations pane" : "Dock conversations pane";
      dock.setAttribute("aria-label", label);
      dock.title = !desktop.matches && !docked ? "Docking is available in a wider window" : label;
      dock.setAttribute("aria-pressed", String(docked));
      dock.disabled = !desktop.matches && !docked;
      applyWidth();
    }
    function finishResize() {
      if (!drag) return;
      const pointerId = drag.pointerId;
      drag = null;
      document.body.classList.remove("resizing-conversations");
      if (resize.hasPointerCapture(pointerId)) resize.releasePointerCapture(pointerId);
      session.set("conversation_pane_width", preferredWidth);
    }
    function open({focus = true} = {}) {
      if (!visible) opener = document.activeElement?.closest("button") || toggle;
      visible = true; session.set("conversation_pane_visible", true); render(); void refresh();
      if (focus) close.focus({preventScroll: true});
    }
    function hide() {
      if (!visible) return;
      finishResize(); closeMenu(); visible = false; session.set("conversation_pane_visible", false); render();
      (opener?.isConnected ? opener : toggle).focus({preventScroll: true});
    }
    function closeTemporary() { if (isTemporary()) hide(); }
    toggle.addEventListener("click", () => visible ? hide() : open());
    close.addEventListener("click", hide);
    scrim.addEventListener("click", closeTemporary);
    dock.addEventListener("click", () => {
      finishResize(); docked = !docked;
      session.set("conversation_pane_docked", docked); render();
    });
    resize.addEventListener("pointerdown", event => {
      if (event.button !== 0 || drag) return;
      event.preventDefault(); resize.focus({preventScroll: true});
      drag = {pointerId: event.pointerId, x: event.clientX, width: applyWidth()};
      resize.setPointerCapture(event.pointerId);
      document.body.classList.add("resizing-conversations");
    });
    resize.addEventListener("pointermove", event => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const {min, max} = bounds();
      preferredWidth = Math.round(Math.max(min, Math.min(max, drag.width + event.clientX - drag.x)));
      applyWidth();
    });
    ["pointerup", "pointercancel", "lostpointercapture"].forEach(type => resize.addEventListener(type, finishResize));
    resize.addEventListener("keydown", event => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const {min, max} = bounds(), step = event.shiftKey ? 40 : 10;
      preferredWidth = event.key === "Home" ? min : event.key === "End" ? max
        : Math.max(min, Math.min(max, applyWidth() + (event.key === "ArrowRight" ? step : -step)));
      applyWidth(); session.set("conversation_pane_width", preferredWidth);
    });
    document.addEventListener("keydown", event => {
      if (event.key !== "Tab" || !isTemporary() || document.querySelector("dialog[open]")) return;
      const controls = [...drawer.querySelectorAll('button, input, select, a[href], [tabindex="0"]')]
        .filter(node => !node.disabled && node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && (document.activeElement === first || !drawer.contains(document.activeElement))) {
        event.preventDefault(); last?.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !drawer.contains(document.activeElement))) {
        event.preventDefault(); first?.focus();
      }
    });
    window.addEventListener("resize", () => {
      finishResize(); render();
      if (isTemporary() && !drawer.contains(document.activeElement) && !document.querySelector("dialog[open]")) close.focus();
    });
    window.addEventListener("blur", finishResize);
    render();
    return {open, close: hide, closeTemporary, isTemporary};
  }
  window.SMTOConversationPane = {create};
})();
