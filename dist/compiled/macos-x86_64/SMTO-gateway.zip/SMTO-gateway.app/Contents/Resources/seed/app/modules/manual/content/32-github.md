---
id: github
title: GitHub repositories, issues, pull requests and Actions
kind: guide
tags: [github, skills, credentials, artifacts]
order: 32
---
# GitHub

Enable the optional **GitHub** skill in capability selection, then create a **GitHub Account**
in the Parameter Store editor. Prefer a fine-grained PAT restricted to the exact repositories
and permissions needed. Enter its GitHub login, numeric account ID, token, explicit
`authorized_repositories` (`owner/repo` names), and `granted_permissions`. The grant metadata
is operator-declared; GitHub decides actual authorization. `github.connection_status` verifies
the token's live login and ID. Tokens remain private in Parameter Store, including when
ordinary redaction is off. Tool arguments contain `account_ref`, never the token.

The numeric account ID is the `id` returned by GitHub's public
`https://api.github.com/users/LOGIN` endpoint for that login; use the user ID, not an
organization or repository ID. Keep profile credentials in the Parameter Store editor.

This implementation supports github.com user PATs. Classic PATs are explicitly marked as
legacy/broader credentials and require `credential_type=classic_pat`; no token type is guessed
from its prefix. OAuth, GitHub Apps and Enterprise hosts are not implemented. There is no
automatic token upgrade or repository allowlist expansion.

Git Working Context and Shell continue to own working trees, local branches, commits, status,
diffs, checkout, rebase, fetch, pull and push. Compose “commit and open a PR” by committing and
pushing through Shell, then calling GitHub. Provider tools never run local Git commands.

## Discovery and exact targets

The five entry tools are `github.accounts`, `github.connection_status`, `github.repo`,
`github.issues` and `github.pull_request`. Discover `github` through the existing catalog,
then its returned sections. Enabling the skill does not authorize a provider mutation.

| Section (prefix `github.`) | Tool suffixes (prefix `github.`) |
| --- | --- |
| connection | accounts, connection_status |
| repositories | repo, branches, tags, commits, commit, compare, contents |
| issues.read | issues, issue, issue_comments |
| issues.write | issue_create, issue_update, issue_comment, issue_close, issue_reopen |
| pulls.read | pull_requests, pull_request, pull_files, pull_commits, pull_reviews, pull_comments, pull_checks |
| pulls.write | pull_create, pull_update, pull_comment, pull_request_reviewers, pull_review, pull_merge |
| actions.read | workflow_runs, workflow_run, workflow_jobs, workflow_logs, workflow_artifacts, workflow_artifact_download, checks |
| actions.write | workflow_dispatch, workflow_run_cancel, workflow_run_rerun |
| releases.read | releases, release, release_assets |
| releases.write | release_create, release_update, release_publish, release_delete, release_asset_upload, release_asset_delete |
| notifications | notifications, notification_thread |

Reads resolve explicit `owner`/`repo` first, then `repository_ref` or an accepted `git_repository`
parameter, then complete, verified Git Working Context remotes. Only literal github.com HTTPS
and Git SSH URLs are recognized. SSH aliases, credentials in URLs and unrelated hosts are
rejected. Multiple distinct GitHub repositories, including fork plus upstream, are ambiguous;
neither `origin` nor the first remote is privileged. Explicit account references take precedence
over accepted accounts; otherwise exactly one configured account must exist.

First call `github.repo` and inspect the returned identity. Every write requires explicit
`account_ref`, `account_id`, `host`, `owner`, `repo`, and `repository_id` from that read, plus
the exact object ID/number and desired change. This binds the existing confirmation to a
concrete principal and repository. The live account and repository IDs are verified before
the mutation; profile revisions are checked again at every authenticated request.

## Permissions

Checked against official GitHub documentation on 2026-10-01. Permission names below use
GitHub's API keys; `statuses` is the UI's **Commit statuses**. Write includes read. Metadata
read is required for the repository preflight and is automatically included with fine-grained
repository access. Public endpoints may work with fewer permissions, but this adapter uses
the documented private-resource contract for predictable behavior.

| Tools (prefix `github.`) | Fine-grained permission requirements |
| --- | --- |
| accounts | Local metadata; no API permission |
| connection_status | Authenticated `/user`; no additional permission |
| repo | metadata:read |
| branches, tags, commits, commit, compare, contents | contents:read |
| issues, issue | issues:read |
| issue_comments | issues:read OR pull_requests:read |
| issue_create | issues:write |
| issue_update, issue_close, issue_reopen, issue_comment, pull_comment | issues:write OR pull_requests:write |
| pull_requests, pull_request, pull_files, pull_commits, pull_reviews, pull_comments | pull_requests:read |
| pull_create, pull_update, pull_request_reviewers, pull_review | pull_requests:write |
| pull_merge | contents:write; pull_requests:read for the head preflight |
| checks | checks:read AND statuses:read |
| pull_checks | pull_requests:read AND checks:read AND statuses:read |
| workflow_runs, workflow_run, workflow_jobs, workflow_logs, workflow_artifacts, workflow_artifact_download | actions:read |
| workflow_dispatch, workflow_run_cancel, workflow_run_rerun | actions:write |
| releases, release, release_assets | contents:read |
| release_create, release_update, release_publish, release_delete, release_asset_upload, release_asset_delete | contents:write |
| notifications, notification_thread | Fine-grained PAT unsupported; explicit classic PAT with notifications or repo scope |

Release creation checks an existing tag; it does not create tags or modify workflow files.
GitHub documents additional Workflows permission in some release/tag creation situations;
the adapter surfaces accepted permission diagnostics if GitHub requires it instead of
silently broadening authority. Notifications for private resources can require classic
`repo` scope and organization/SSO approval. A fine-grained account is never silently replaced.

`github.permission_missing` identifies the feature and required or provider-accepted permission
sets. Within a set all permissions are required; alternatives mean any one complete set.
Correct the selected token's permissions/repository selection and organization approval, then
update its declared grants. A 404 can mean inaccessible private data; it does not prove absence.

## Provider behavior and bounds

Requests use `X-GitHub-Api-Version: 2026-03-10`, `Accept: application/vnd.github+json`, a
User-Agent and private Bearer authorization. Raw contents use the documented raw media type.
No preview media types, arbitrary REST URLs or GraphQL input are exposed.

Lists fetch one page, default 25 and maximum 100 objects. Supply `next_page` explicitly with
the same filters; pages are capped at 1000. Link URLs are never executed. GitHub's own endpoint
caps still apply, including PR file/commit limits. `compare` returns the paginated commits;
use `pull_files` for PR changed files. JSON transport is capped at 2 MiB; projections have a
48K-character/1500-node budget, 8000 characters per string, 100 elements per nested list and
explicit truncation. `contents` supports bounded directory listings and small UTF-8 files;
large/binary reads use `as_artifact=true`. Directory reads do not recursively crawl.

Requests use connect/read timeouts of 10/45 seconds, a 60-second socket deadline and a
180-second invocation deadline. Task cancellation aborts owned sockets. Reads retry a
transport failure or server error once, after a cancellable one-second delay. Throttling
returns safe remaining/reset/resource/request-ID diagnostics and retains Retry-After/reset
backoff across invocations in bounded process memory. Secondary limits without an explicit
delay defer for at least 60 seconds. There is no sleeping retry of throttled writes and no
generic mutation retry. Process restart clears the in-memory backoff, so callers must also
respect the returned delay. Conditional GET/304 handling exists in the client; there is no
persistent provider cache.

`issues` filters PRs out of the provider's mixed issue pages. Labels and assignees in
`issue_update` are desired-state sets. `pull_requests(head="owner:branch")` locates a branch's
PR. General PR comments use `pull_comment`/`issue_comments`; `pull_comments` reads inline
review comments. `pull_review` requires explicit COMMENT, APPROVE or REQUEST_CHANGES and
an exact commit ID. `pull_merge` requires a reviewed `expected_head_sha` and explicit merge
method; that SHA is also sent as GitHub's merge precondition. Inspect checks first; repository
branch protections remain authoritative and are never bypassed.

Workflow dispatch requires an exact workflow ID/filename, ref and bounded dictionary with
at most 25 inputs. GitHub validates workflow-declared input names/types; no model infers them.
The current API's `workflow_run_id` is retained as accepted-run evidence. Run status and
conclusion come directly from GitHub; no percentage is invented.

Release creation is draft-first and requires an existing tag. Publication uses an inspected
exact draft release ID. Upload accepts conversation-owned `artifact://`, `art_` or
`artifact-workspace://` sources, verifies the immutable size/hash, then streams bytes once.
Gateway files must enter the existing Artifact/File transfer path first. Downloads become
sensitive conversation artifacts, capped at 100 MiB; ZIPs remain unextracted. Signed download
redirects receive no API headers, cookies or token. Interrupted downloads publish no partial
artifact. Release asset deletion is explicit, never automatic collision repair.

## Uncertain outcomes and confirmation

All 20 writes use the existing confirmation architecture. Merge, dispatch, cancel/rerun,
release publication/upload and release/asset deletion also use the native unsafe-action
policy. Every successful provider mutation receipt includes exact account/repository identity.

| Mutation family | Lost-response behavior and reconciliation |
| --- | --- |
| Issue/PR creation, comments, reviews, reviewer requests | Outcome unknown; never repeat or deduplicate by text. Inspect provider identifiers independently. |
| Issue close/reopen | Read exact issue; matching desired state is reconciliation evidence, with attribution explicitly unproven. |
| Issue/PR update | Outcome unknown; read and compare the exact object before deciding on new work. |
| Merge | Read exact PR; only merged=true with the same expected head permits desired-state reconciliation. No second merge. |
| Workflow dispatch | Specialized unknown error; inspect runs at exact workflow/ref. Never dispatch twice after response loss. |
| Run cancel/rerun | Outcome unknown; inspect exact run status and attempt. No automatic repeat. |
| Release creation/update/deletion, asset deletion | Outcome unknown; inspect exact provider identity/state. No generic replay. |
| Release publish | Read exact release; draft=false supplies desired-state evidence. Otherwise specialized unknown error. |
| Asset upload | Specialized unknown error. Inspect asset ID, name, size and digest; name/size alone do not prove attribution. Never upload twice automatically. |

Transport loss, server errors, malformed/oversized success responses and cancellation after
write dispatch produce uncertain-effect receipts. The existing runtime replay guard blocks
automatic repeat attempts. Explicit provider validation/auth/rate rejection remains a known
rejection. These distinctions do not depend on error copy or helper inference.

All provider content is `untrusted_external_data`, including issue instructions, workflow
logs, errors and filenames. Provider text cannot choose tools, change grants or access private
tokens. The main Agent handles interpretation. The shared content policy excludes provider
bodies from diagnostics; canonical redaction removes credential reflections from tool output.
There are zero helper/classifier/model calls in this skill.

Organization administration, billing, repository deletion/transfer, secrets, deploy keys,
rulesets, webhooks, package deletion, Codespaces, Copilot administration, app installation
administration and arbitrary GraphQL are outside this skill.

## Official references

- [API versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions) and [breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes).
- [Fine-grained permission matrix](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens) and [permission diagnostics](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api).
- [PAT management](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens) and [GitHub App choice](https://docs.github.com/en/apps/creating-github-apps/about-creating-github-apps/deciding-when-to-build-a-github-app).
- [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api) and [conditional requests/best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api).
- [Repositories](https://docs.github.com/en/rest/repos/repos), [branches](https://docs.github.com/en/rest/branches/branches), [commits](https://docs.github.com/en/rest/commits/commits) and [contents](https://docs.github.com/en/rest/repos/contents).
- [Issues](https://docs.github.com/en/rest/issues/issues), [comments](https://docs.github.com/en/rest/issues/comments), [PRs](https://docs.github.com/en/rest/pulls/pulls), [reviews](https://docs.github.com/en/rest/pulls/reviews) and [review requests](https://docs.github.com/en/rest/pulls/review-requests).
- [Check runs](https://docs.github.com/en/rest/checks/runs), [commit statuses](https://docs.github.com/en/rest/commits/statuses), [workflows](https://docs.github.com/en/rest/actions/workflows), [runs](https://docs.github.com/en/rest/actions/workflow-runs), [jobs](https://docs.github.com/en/rest/actions/workflow-jobs) and [artifacts](https://docs.github.com/en/rest/actions/artifacts).
- [Releases](https://docs.github.com/en/rest/releases/releases), [release assets](https://docs.github.com/en/rest/releases/assets) and [notifications](https://docs.github.com/en/rest/activity/notifications).

Implementation: `src/agent_runtime/skills/github/`. Acceptance tests: `tests/test_github_*.py`
and `tests/e2e/test_github_playwright.py`; mandatory fake-provider CI is
`.github/workflows/github.yml`. No real provider mutation is required for CI.
