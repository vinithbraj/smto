/* UI-owned action symbols, shared by desktop and mobile. Never render tool-supplied SVG. */
(() => {
  "use strict";
  const paths = {
    thinking: '<path d="M12 18V5a3 3 0 0 0-5.8-1A4 4 0 0 0 3 10a4 4 0 0 0 1 7.5A4 4 0 0 0 12 18Zm0 0V5a3 3 0 0 1 5.8-1A4 4 0 0 1 21 10a4 4 0 0 1-1 7.5A4 4 0 0 1 12 18ZM7 4v3m-4 3h3l2 2m-4 5.5H7l1-2M17 4v3m4 3h-3l-2 2m4 5.5h-3l-1-2"/>',
    shell: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="m7 9 3 3-3 3m6 0h4"/>',
    sequence: '<circle cx="5" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><path d="M5 7v10m5-12h10m-10 7h10m-10 7h10"/>',
    parallel: '<circle cx="5" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M5 7v10m0-10v2a3 3 0 0 0 3 3h8a3 3 0 0 1 3 3v2"/>',
    batch: '<rect x="3" y="9" width="14" height="12" rx="2"/><path d="M7 9V5h14v12h-4M10 13v4m-2-2h4"/>',
    file: '<path d="M14 3H5v18h14V8Zm0 0v5h5M8 12h8M8 16h6"/>',
    edit: '<path d="M12 4H4v16h16v-8m-4-9 5 5-9 9-6 1 1-6Zm-9 9 5 5"/>',
    folder: '<path d="M3 7V4h6l2 3h10v13H3Z"/>',
    search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
    globe: '<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
    database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
    code: '<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18"/>',
    schedule: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 2v6m10-6v6M3 11h18m-14 4h3m4 0h3"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
    activity: '<path d="M2 12h5l3-8 4 16 3-8h5"/>',
    key: '<circle cx="8" cy="8" r="5"/><path d="m12 12 9 9m-5-5 3-3m-1 5 3-3"/>',
    server: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6h1m-1 11h1"/>',
    context: '<path d="M6 3h14v15H6ZM3 6v15h14M9 7h8m-8 4h8m-8 3h5"/>',
    user: '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    runtime: '<circle cx="12" cy="12" r="4"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4M5 5l3 3m8 8 3 3M5 19l3-3m8-8 3-3"/>',
    screen: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8m-4-4v4"/>',
    clipboard: '<path d="M8 5H5v16h14V5h-3"/><rect x="8" y="2" width="8" height="5" rx="1"/><path d="M8 12h8m-8 4h6"/>',
    chart: '<path d="M3 3v18h18M7 16v-5m5 5V6m5 10v-8"/>',
    chat: '<path d="M21 4H3v13h4v4l5-4h9ZM7 8h10M7 12h7"/>',
    wait: '<path d="M9 5v14m6-14v14"/>',
    stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
  };
  const aliases = {model: "thinking", generating: "thinking", model_recovery: "thinking",
    shell_command: "shell", python: "code", python_code: "code", python_action: "code", llm_text: "thinking",
    "task-contract": "file", task_contract: "file", control: "user", waiting: "wait", pausing: "wait", stopping: "stop"};
  const specific = {"shell.sequence": "sequence", "shell.parallel": "parallel", "shell.batch": "batch",
    "web.search": "search", "file.search": "search", "file.find": "search", "file.list": "folder",
    "file.mkdir": "folder", "file.edit": "edit", "file.write": "edit", "file.patch": "edit"};
  const families = {shell: "shell", file: "file", web: "globe", http: "globe", database: "database",
    python: "code", schedule: "schedule", gmail: "mail", monitor: "activity", parameters: "key", agent: "user",
    kv: "context", read_context: "context", read_result: "context", manage_job: "activity",
    wait_for_event: "activity", ask_user: "user", manage_tasks: "sequence",
    browser: "globe", web_research: "globe", google_calendar: "schedule", email: "mail", slack: "chat",
    memory: "context", docs: "context", artifact: "file", pdf: "file", office: "file", google_drive: "folder",
    microsoft365: "file", github: "code", auth: "key", gateway: "server", docker: "server", proxmox: "server",
    gpu: "server", screen: "screen", desktop: "screen", ui: "screen", clipboard: "clipboard",
    visualization: "chart", local_ai: "thinking", discover_tools: "search", inspect_execution: "activity",
    wait_for_activity: "wait", wait_for_any_activity: "wait", wait_for_all_required_activities: "wait",
    finish_task: "user", schedule_activities: "sequence",
    read_research_evidence: "context", request_research_budget: "user"};
  const own = (map, key) => Object.hasOwn(map, key) ? map[key] : undefined;
  const normalize = kind => own(aliases, kind) || (own(paths, kind) ? kind : "runtime");

  function resolve(detail = {}, fallback = "runtime") {
    const p = detail.presentation || detail;
    const id = String(detail.capability_id || p.capability_id || detail.tool_name || "").replaceAll("__", ".");
    return own(specific, id)
      || (p.icon_kind && p.icon_kind !== "runtime" && own(paths, p.icon_kind) ? p.icon_kind : null)
      || own(families, id.split(".")[0])
      || (detail.kind && (own(aliases, detail.kind) || own(paths, detail.kind)) ? normalize(detail.kind) : null)
      || (detail.code ? "code" : detail.command || detail.shell_command ? "shell" : normalize(fallback));
  }

  function update(icon, kind) {
    kind = normalize(kind);
    if (icon.dataset.actionType === kind) return;
    icon.dataset.actionType = kind;
    icon.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${paths[kind]}</svg>`;
  }
  function create(kind) {
    const icon = document.createElement("span");
    icon.className = "action-type-icon";
    icon.setAttribute("aria-hidden", "true");
    update(icon, kind);
    return icon;
  }
  function decorateLabel(label, kind) {
    let icon = label.querySelector(":scope > .action-type-icon");
    if (icon) { update(icon, kind); return; }
    icon = create(kind);
    const status = label.querySelector(":scope > [data-ui-symbol]");
    if (status) status.after(document.createTextNode(" "), icon);
    else label.prepend(icon);
  }
  window.SMTOActionIcons = {create, update, resolve, decorateLabel};
})();
