/**
 * @file src/manual/static/app.js
 * @brief Drive standalone manual navigation, filtered search, outlines and themed diagrams.
 * @ingroup ManualReference
 * @details
 * Responsibilities:
 * - Fetch catalog/documents, render kind/tag navigation and metadata, and maintain
 *   document/heading navigation in the URL hash.
 * Boundaries:
 * - The browser does not generate source references or decide which source is current; the
 *   manual API owns the corpus and rendered document bodies.
 * Lifecycle:
 * - init loads the catalog then the hash-selected document; search is debounced; hash/appearance
 *   events update the active view.
 * State:
 * - Document filters and timers are page-local. Shared appearance/session code owns permitted
 *   preferences; this module does not create its own browser persistence store.
 * Security:
 * - Metadata uses textContent; article HTML is trusted only from the manual renderer. Mermaid
 *   runs in strict security mode and restores source text on diagram failure.
 * Collaborators:
 * - manual/app.py supplies catalog/search/document APIs; index.html owns DOM anchors; app.css
 *   and shared Agent UI appearance code supply theme tokens.
 * Public surface:
 * - init, loadDocument, runSearch and renderMermaid compose the page; #doc/#heading links are
 *   the bookmark contract.
 *
 * @see src/manual/app.py
 * @see src/manual/static/index.html
 * @see src/manual/static/app.css
 */
const state = {
  catalog: null,
  documents: [],
  groups: [],
  activeDocId: "manual-home",
  activeKind: "",
  activeTags: new Set(),
  query: "",
  searchTimer: null,
};

const elements = {
  root: document.documentElement,
  navToggle: document.querySelector("#nav-toggle"),
  manualNav: document.querySelector("#manual-nav"),
  search: document.querySelector("#manual-search"),
  themeSelect: document.querySelector("#theme-select"),
  kindFilters: document.querySelector("#kind-filters"),
  tagFilters: document.querySelector("#tag-filters"),
  documentNav: document.querySelector("#document-nav"),
  article: document.querySelector("#manual-article"),
  searchResults: document.querySelector("#search-results"),
  docMeta: document.querySelector("#doc-meta"),
  outline: document.querySelector("#outline-nav"),
  related: document.querySelector("#related-list"),
};

/** @brief Normalize optional API/DOM text with an explicit empty-value fallback. */
function compactText(value, fallback = "") {
  const text = String(value ?? "").trim();
  return text || fallback;
}

/** @brief Decode the manual document/heading bookmark from the URL hash. */
function hashParams() {
  const raw = window.location.hash.replace(/^#/, "");
  return new URLSearchParams(raw);
}

/** @brief Replace document/heading bookmark state without creating a new history entry. */
function writeHash(docId, headingId = "") {
  const params = new URLSearchParams();
  params.set("doc", docId);
  if (headingId) {
    params.set("heading", headingId);
  }
  history.replaceState(null, "", `#${params.toString()}`);
}

/** @brief Keep responsive navigation visibility and the toggle accessibility state synchronized. */
function setNavOpen(open) {
  document.body.classList.toggle("nav-open", Boolean(open));
  elements.navToggle?.setAttribute("aria-expanded", String(Boolean(open)));
}

/** @brief Close the responsive navigation after selection or dismissal. */
function closeNav() {
  setNavOpen(false);
}

/** @brief Fetch manual JSON and reject unsuccessful HTTP responses before updating the view. */
async function apiJson(url) {
  const response = await window.SMTOErrors.fetch(url, { headers: { accept: "application/json" } });
  if (!response.ok) {
    throw await window.SMTOErrors.fromResponse(response);
  }
  return window.SMTOErrors.readJson(response);
}

/** @brief Synchronize the theme control and redraw diagrams after shared appearance changes. */
function refreshTheme() {
  elements.themeSelect.value = elements.root.dataset.theme;
  renderMermaid();
}
window.addEventListener("smto:appearance", refreshTheme);

/** @brief Build kind filters from server groups and refresh navigation/search on selection. */
function renderKindFilters() {
  const groups = [{ kind: "", label: "All" }, ...state.groups.map((group) => ({ kind: group.kind, label: group.label }))];
  elements.kindFilters.replaceChildren(
    ...groups.map((group) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `filter-button${group.kind === state.activeKind ? " is-active" : ""}`;
      button.textContent = group.label;
      button.addEventListener("click", () => {
        state.activeKind = group.kind;
        renderKindFilters();
        renderDocumentNav();
        runSearch();
      });
      return button;
    }),
  );
}

/** @brief Build the first 34 corpus tag toggles and maintain conjunctive tag selection. */
function renderTagFilters() {
  const tags = (state.catalog?.tags || []).slice(0, 34);
  elements.tagFilters.replaceChildren(
    ...tags.map((item) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `tag-button${state.activeTags.has(item.tag) ? " is-active" : ""}`;
      button.textContent = `${item.tag} ${item.count}`;
      button.addEventListener("click", () => {
        if (state.activeTags.has(item.tag)) {
          state.activeTags.delete(item.tag);
        } else {
          state.activeTags.add(item.tag);
        }
        renderTagFilters();
        renderDocumentNav();
        runSearch();
      });
      return button;
    }),
  );
}

/** @brief Require the selected kind and every selected tag for client navigation visibility. */
function docMatchesFilters(doc) {
  if (state.activeKind && doc.kind !== state.activeKind) {
    return false;
  }
  for (const tag of state.activeTags) {
    if (!doc.tags.includes(tag)) {
      return false;
    }
  }
  return true;
}

/** @brief Rebuild grouped navigation from server metadata under current filters. */
function renderDocumentNav() {
  const groupFragments = [];
  for (const group of state.groups) {
    const docs = group.documents.filter(docMatchesFilters);
    if (!docs.length) {
      continue;
    }
    const wrapper = document.createElement("section");
    wrapper.className = "nav-group";
    const title = document.createElement("div");
    title.className = "nav-group-title";
    title.textContent = group.label;
    wrapper.append(title);
    for (const doc of docs) {
      wrapper.append(renderDocButton(doc, "doc-link"));
    }
    groupFragments.push(wrapper);
  }
  if (!groupFragments.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No documents match.";
    groupFragments.push(empty);
  }
  elements.documentNav.replaceChildren(...groupFragments);
}

/** @brief Create a text-only document selector with active state and click-to-load behavior. */
function renderDocButton(doc, className) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `${className}${doc.id === state.activeDocId ? " is-active" : ""}`;
  const title = document.createElement("span");
  title.className = className === "doc-link" ? "doc-link-title" : "";
  title.textContent = window.SMTOBranding.text(doc.title);
  const summary = document.createElement("span");
  summary.className = className === "doc-link" ? "doc-link-summary" : "";
  summary.textContent = window.SMTOBranding.text(doc.summary || doc.kind_label || "");
  button.append(title, summary);
  button.addEventListener("click", () => loadDocument(doc.id));
  return button;
}

/** @brief Render source kind, reading time and tags without interpreting metadata as HTML. */
function renderMeta(doc) {
  const title = document.createElement("div");
  title.className = "meta-title";
  title.textContent = window.SMTOBranding.text(doc.title);

  const grid = document.createElement("div");
  grid.className = "meta-grid";
  const items = [
    `${doc.kind_label || doc.kind}`,
    `${doc.reading_time_minutes || 1} min read`,
    doc.generated ? "generated" : "static",
    doc.source_type ? `source: ${doc.source_type}` : "",
  ].filter(Boolean);
  grid.replaceChildren(...items.map((item) => {
    const div = document.createElement("div");
    div.textContent = item;
    return div;
  }));

  const tags = document.createElement("div");
  tags.className = "meta-tags";
  tags.replaceChildren(...(doc.tags || []).map((tag) => {
    const span = document.createElement("span");
    span.className = "meta-tag";
    span.textContent = tag;
    return span;
  }));
  elements.docMeta.replaceChildren(title, grid, tags);
}

/** @brief Expose headings through level three and preserve heading bookmarks on navigation. */
function renderOutline(doc) {
  const headings = (doc.headings || []).filter((heading) => heading.level <= 3);
  if (!headings.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No headings.";
    elements.outline.replaceChildren(empty);
    return;
  }
  elements.outline.replaceChildren(...headings.map((heading) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `outline-link outline-level-${heading.level}`;
    button.textContent = window.SMTOBranding.text(heading.title);
    button.addEventListener("click", () => {
      document.getElementById(heading.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
      writeHash(state.activeDocId, heading.id);
    });
    return button;
  }));
}

/** @brief Fetch related metadata for the active document and render an explicit unavailable state. */
async function renderRelated(docId) {
  try {
    const payload = await apiJson(`/api/manual/related/${encodeURIComponent(docId)}`);
    const items = payload.results || [];
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = "No related documents.";
      elements.related.replaceChildren(empty);
      return;
    }
    elements.related.replaceChildren(...items.map((doc) => renderDocButton(doc, "related-link")));
  } catch {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "Related documents unavailable.";
    elements.related.replaceChildren(empty);
  }
}

/** @brief Read the active computed theme token with a diagram-specific fallback. */
function cssVariable(name, fallback) {
  return compactText(getComputedStyle(document.documentElement).getPropertyValue(name), fallback);
}

/** @brief Derive diagram colors from page tokens while retaining strict Mermaid security. */
function mermaidConfig() {
  const bg = cssVariable("--trace-panel", "#f5f5f5");
  const panel = cssVariable("--panel", "#ffffff");
  const text = cssVariable("--text", "#202020");
  const muted = cssVariable("--muted", "#656565");
  const border = cssVariable("--border", "rgba(0, 0, 0, 0.11)");
  return {
    startOnLoad: false,
    securityLevel: "strict",
    theme: "base",
    themeVariables: {
      fontFamily: cssVariable("--ui-font", "sans-serif"),
      background: bg,
      mainBkg: panel,
      primaryColor: panel,
      primaryTextColor: text,
      primaryBorderColor: border,
      secondaryColor: bg,
      tertiaryColor: panel,
      lineColor: muted,
      textColor: text,
      clusterBkg: bg,
      clusterBorder: border,
      clusterTextColor: text,
      titleColor: text,
      edgeLabelBackground: panel,
    },
    flowchart: { htmlLabels: true, curve: "basis" },
  };
}

/** @brief Preserve diagram source for theme redraws and restore readable code if rendering fails. */
async function renderMermaid() {
  if (!window.mermaid?.run) {
    return;
  }
  const diagrams = Array.from(document.querySelectorAll(".manual-article .mermaid"));
  if (!diagrams.length) {
    return;
  }
  for (const diagram of diagrams) {
    if (diagram.dataset.source) {
      diagram.textContent = diagram.dataset.source;
      diagram.removeAttribute("data-processed");
    } else {
      diagram.dataset.source = diagram.textContent;
    }
  }
  window.mermaid.initialize(mermaidConfig());
  try {
    await window.mermaid.run({ nodes: diagrams });
  } catch (error) {
    for (const diagram of diagrams) {
      diagram.textContent = diagram.dataset.source || diagram.textContent;
    }
  }
}

/** @brief Fetch server-rendered content, refresh metadata/navigation and restore the requested heading. */
async function loadDocument(docId, headingId = "") {
  const safeDocId = compactText(docId, "manual-home");
  elements.article.innerHTML = '<div class="loading-state">Loading document.</div>';
  try {
    const doc = await apiJson(`/api/manual/document/${encodeURIComponent(safeDocId)}`);
    state.activeDocId = doc.id;
    elements.article.innerHTML = doc.html;
    const walker = document.createTreeWalker(elements.article, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (!node.parentElement.closest("pre, code, script, style, textarea, .mermaid")) {
        node.textContent = window.SMTOBranding.text(node.textContent);
      }
    }
    renderMeta(doc);
    renderOutline(doc);
    renderDocumentNav();
    writeHash(doc.id, headingId);
    await renderRelated(doc.id);
    await renderMermaid();
    closeNav();
    const target = headingId ? document.getElementById(headingId) : null;
    if (target) {
      target.scrollIntoView({ block: "start" });
    } else {
      elements.article.focus({ preventScroll: true });
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  } catch (error) {
    window.SMTOErrors.present(elements.article, error);
  }
}

/** @brief Serialize the selected tag set for the manual search API. */
function tagsQuery() {
  return Array.from(state.activeTags).join(",");
}

/** @brief Query server search under current filters and render results or explicit failure text. */
async function runSearch() {
  const q = compactText(state.query);
  const hasFilters = Boolean(q || state.activeKind || state.activeTags.size);
  if (!hasFilters) {
    elements.searchResults.hidden = true;
    elements.searchResults.replaceChildren();
    return;
  }
  const params = new URLSearchParams();
  if (q) {
    params.set("q", q);
  }
  if (state.activeKind) {
    params.set("kind", state.activeKind);
  }
  if (state.activeTags.size) {
    params.set("tags", tagsQuery());
  }
  params.set("limit", "12");
  try {
    const payload = await apiJson(`/api/manual/search?${params.toString()}`);
    const title = document.createElement("h2");
    title.textContent = q ? `Search: ${q}` : "Filtered documents";
    const results = payload.results || [];
    const items = results.length
      ? results.map((doc) => renderDocButton(doc, "result-link"))
      : [Object.assign(document.createElement("div"), { className: "empty-state", textContent: "No matching documents." })];
    elements.searchResults.replaceChildren(title, ...items);
    elements.searchResults.hidden = false;
  } catch (error) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    window.SMTOErrors.present(empty, error);
    elements.searchResults.replaceChildren(empty);
    elements.searchResults.hidden = false;
  }
}

/** @brief Coalesce rapid input into one search after the 120 ms debounce interval. */
function scheduleSearch() {
  clearTimeout(state.searchTimer);
  state.searchTimer = setTimeout(runSearch, 120);
}

/** @brief Load the manual corpus metadata, initialize filters and select the hash-bookmarked document. */
async function init() {
  refreshTheme();
  state.catalog = await apiJson("/api/manual/catalog");
  state.groups = state.catalog.groups || [];
  state.documents = state.catalog.documents || [];
  renderKindFilters();
  renderTagFilters();
  renderDocumentNav();
  const params = hashParams();
  await loadDocument(params.get("doc") || "manual-home", params.get("heading") || "");
}

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
  if (!elements.root.dataset.theme) renderMermaid();
});

elements.themeSelect.addEventListener("change", () => window.SMTOAgentUi.setThemeOverride(elements.themeSelect.value));
elements.search.addEventListener("input", () => {
  state.query = elements.search.value;
  scheduleSearch();
});
elements.navToggle.addEventListener("click", () => {
  setNavOpen(!document.body.classList.contains("nav-open"));
});
window.addEventListener("pointerdown", (event) => {
  if (
    document.body.classList.contains("nav-open")
    && !elements.manualNav?.contains(event.target)
    && !elements.navToggle?.contains(event.target)
  ) {
    closeNav();
  }
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeNav();
  }
});
window.addEventListener("hashchange", () => {
  const params = hashParams();
  const docId = params.get("doc") || "manual-home";
  const headingId = params.get("heading") || "";
  if (docId !== state.activeDocId) {
    loadDocument(docId, headingId);
  } else if (headingId) {
    document.getElementById(headingId)?.scrollIntoView({ block: "start" });
  }
});

init().catch((error) => {
  window.SMTOErrors.present(elements.article, error);
});
