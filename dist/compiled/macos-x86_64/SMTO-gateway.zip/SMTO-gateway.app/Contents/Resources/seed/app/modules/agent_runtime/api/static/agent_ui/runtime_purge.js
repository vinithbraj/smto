(() => {
  'use strict';
  const base = '/api/agent/runtime-purge';
  let mounted;
  function el(tag, text, parent) {
    const node = document.createElement(tag);
    node.textContent = text || '';
    parent?.append(node);
    return node;
  }
  async function api(path, payload) {
    const response = await (window.SMTOAuth?.fetch || window.fetch)(base + path, {
      cache: 'no-store', ...(payload ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)} : {})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Runtime purge request failed');
    return data;
  }
  function bytes(value) {
    return value == null ? 'unknown' : new Intl.NumberFormat(undefined, {maximumFractionDigits: 1}).format(value / 1048576) + ' MiB';
  }
  function mount(host) {
    if (mounted) { host.append(mounted); return; }
    const panel = mounted = el('div', '', host);
    panel.className = 'mission-setting-row runtime-purge-panel';
    el('p', 'Permanently delete runtime data on this Server and every paired Gateway. Keep settings, secrets, pairing, saved Memory, workflows, schedules and saved monitors.', panel);
    el('p', 'Active work will stop and services will restart. Previously enabled automation resumes afterward with fresh execution contexts. Workspace files, repositories, builds, model downloads and your exported backups remain untouched.', panel);
    const previewButton = el('button', 'Preview purge', panel); previewButton.type = 'button';
    const preview = el('div', '', panel);
    const confirmation = el('div', '', panel); confirmation.hidden = true;
    const label = el('label', 'Type PURGE RUNTIME DATA to confirm permanent deletion', confirmation);
    const input = el('input', '', label); input.type = 'text'; input.autocomplete = 'off'; input.spellcheck = false;
    const start = el('button', 'Purge runtime data', confirmation); start.type = 'button'; start.disabled = true;
    input.addEventListener('input', () => {start.disabled = input.value !== 'PURGE RUNTIME DATA';});
    const status = el('div', '', panel); status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite');
    const targets = el('ul', '', panel);
    const retry = el('button', 'Retry pending targets', panel); retry.type = 'button'; retry.hidden = true;
    let operation, busy = false, timer, submissionId;
    function show(data) {
      operation = data.operation_id;
      if (data.status === 'idle') return;
      if (operation) confirmation.hidden = true;
      status.textContent = `${data.phase} · ${data.status}` + (data.status === 'completed' ? '. New automation may already be creating fresh runtime data.' : '');
      targets.replaceChildren();
      for (const target of data.targets || []) {
        el('li', `${target.label || target.id}: ${target.status} · reclaimed ${bytes(target.reclaimed_bytes)}${target.error ? ' · ' + target.error : ''}`, targets);
      }
      retry.hidden = !['partial', 'blocked'].includes(data.status);
      previewButton.disabled = !['completed', 'idle'].includes(data.status);
      if (data.status !== 'completed') schedule();
    }
    function schedule() { clearTimeout(timer); timer = setTimeout(refresh, 2500); }
    async function refresh() {
      try { show(await api('/status')); }
      catch (_) { status.textContent = 'Waiting for service restart. Progress is saved and will reappear when the Server is ready.'; schedule(); }
    }
    previewButton.addEventListener('click', async () => {
      if (busy) return; busy = true; previewButton.disabled = true;
      try {
        const data = await api('/preview'); preview.replaceChildren();
        for (const [name, values] of [['Preserve', data.preserve], ['Delete', data.delete], ['Outside this purge', data.excluded]]) {
          el('strong', name, preview); const list = el('ul', '', preview);
          for (const value of values || []) el('li', value, list);
        }
        const list = el('ul', '', preview);
        for (const target of data.targets) {
          el('li', `${target.label}: ${target.status} · estimated storage ${bytes(target.estimated_bytes)} · active work ${target.active_work ?? 'unknown'}${target.error ? ' · ' + target.error : ''}`, list);
          if (target.work_to_stop) el('li', Object.entries(target.work_to_stop).map(([kind, count]) => `${kind.replaceAll('_', ' ')}: ${count}`).join(' · '), list);
        }
        el('p', 'Unreachable Gateways remain pending. Incompatible Gateways require an upgrade. New execution stays blocked there until cleanup is verified.', preview);
        submissionId = null; confirmation.hidden = false; input.value = ''; start.disabled = true; input.focus();
      } catch (error) { status.textContent = error.message; }
      finally { busy = false; previewButton.disabled = false; }
    });
    start.addEventListener('click', async () => {
      if (busy || input.value !== 'PURGE RUNTIME DATA') return;
      busy = true; start.disabled = true;
      const submission = submissionId ||= Array.from(crypto.getRandomValues(new Uint8Array(16)), value => value.toString(16).padStart(2, '0')).join('');
      try {
        show(await api('/start', {confirmation: input.value, submission_id: submission}));
        confirmation.hidden = true;
      } catch (error) { status.textContent = error.message; schedule(); }
      finally { busy = false; }
    });
    retry.addEventListener('click', async () => {
      retry.disabled = true;
      try { show(await api(`/${operation}/retry`, {})); }
      catch (error) { status.textContent = error.message; }
      finally { retry.disabled = false; }
    });
    void refresh();
  }
  window.SMTORuntimePurge = {mount};
})();
