---
id: gpu
title: GPU telemetry and configuration
kind: architecture
tags: [architecture, current, gpu, nvidia, gateway, skills]
order: 42
---
# GPU telemetry and configuration

Enable **GPU** in Capabilities to inspect and configure devices on the selected Gateway.
The skill starts disabled. Discovery grants no execution or OS privilege. The Gateway advertises
`gpu_telemetry` and `gpu_configuration` when `nvidia-smi` is installed; every operation checks
current driver and device support. These tags do not promise that every setting is supported.
There is no controller fallback, automatic installation, arbitrary argv tool or helper inference.

Discover `gpu` for `gpu.status`, `gpu.devices`, `gpu.device`, `gpu.processes` and `gpu.sample`.
Further tools are grouped as follows:

| Section | Tools |
| --- | --- |
| `gpu.telemetry` | `status`, `devices`, `device`, `sample` |
| `gpu.processes` | `processes` |
| `gpu.configuration` | `power_limits`, `set_power_limit`, `restore_power_limit`, `set_persistence_mode`, `set_compute_mode`, `clock_capabilities`, `set_gpu_clock_range`, `reset_gpu_clocks`, `set_memory_clock_range`, `reset_memory_clocks` |
| `gpu.advanced` | `reset_status`, `reset` |

All tool IDs use the `gpu.` prefix. Advanced tools are absent from entry discovery.
Reads have the `read` effect. Configuration has the broad `write` effect and retains the existing
`gpu_configuration` classification and exact resource descriptors in execution receipts.

## Identity and telemetry

The NVIDIA UUID is durable mutation authority. `device` accepts a UUID or a current display index.
An index mutation also requires `expected_uuid` from discovery, binding approval to that device.
The Gateway resolves the index before admission and checks again after acquiring ownership;
all subprocess mutations use `--id GPU-…`. Device reorder never redirects a mutation.

Inventory includes UUID, index, name, utilization, used/total VRAM bytes, VRAM percentage,
temperature in Celsius, power draw and current power limit in watts. Detail adds PCI bus ID,
driver version, architecture, current/default/minimum/maximum power, persistence, compute mode,
MIG/ECC state and clock observations. Compute capability remains null in this initial adapter.
Unsupported or non-finite metrics are null. Clock observations are instantaneous frequencies,
not proof of configured constraints. Console telemetry, server utilization and GPU tools share
numeric/CSV parsing in `gateway_core/gpu/telemetry.py`.

`processes` reads NVIDIA's XML compute/graphics process list. It returns up to 1,024 PIDs,
process basenames, process types, GPU UUIDs and available memory values, with observation time
and available provider timestamps. An unavailable or truncated process list is explicitly
incomplete and cannot authorize reset. There is no OS PID join, inferred ownership, argument or
environment capture, process kill, or background process watcher. Exact task results retain
needed metadata; diagnostic and portable-history projections omit process content.

## Bounded sampling

Supply `interval_seconds` and exactly one of `samples` or `duration_seconds`, with optional
UUIDs and fields. Intervals are 0.5–60 seconds; at most 120 samples spanning at most 300 seconds
are accepted. Duration includes an initial sample at time zero. For example, five-second samples
for one minute produce 13 observations. Requests outside these bounds fail explicitly.
Selection is pinned to the first observation's UUIDs when omitted. Disappearance fails with
identity-change evidence rather than substituting a device at the same index.

One Gateway call performs the whole sample, using cancellation-aware waits. There are at most
16 active calls per service, 64 devices per inventory, 2 MiB per provider response and 8 MiB per
transport response. Each NVIDIA child has a five-second deadline; configuration/read requests
have a 45-second budget and sampling a 330-second budget. Long or conditional watches belong
to the existing Monitor skill. Sampling never causes one Agent turn per interval.

## Configuration and privileges

The adapter uses argv with `shell=False`; the existing `nvidia_smi_effect` grammar validates
both queries and compiled mutations. Current Shell grammar, wrappers and unsafe behavior remain
unchanged. The installed CLI help and fresh per-device queries gate configuration. The driver
can still reject an otherwise eligible operation; the result reports that rejection.

Power changes query and validate finite hardware min/max/default/current values before mutation
and again after admission. Values are never clamped. Restore uses the queried default, with no
model-specific table. The exact requested value is checked against fresh readback.
Persistence uses explicit booleans and is Linux-only. Compute mode accepts `default`, `prohibited`
or `exclusive_process` (documented CLI values 0, 2 and 3), then reads the resulting state.

Clock setters accept integer minimum/maximum MHz endpoints found in the current device's supported
clock pairs. Unsupported endpoints and reversed ranges fail before mutation. GPU clock locks
are restricted to recognized Volta-or-later architectures with queried supported clocks and
installed CLI flags. Memory locks also exclude Hopper's deferred mechanism. Deprecated application
clocks, deferred memory locks, voltage changes and fan control are not exposed.

NVIDIA's CLI does not provide a reliable query of locked-clock constraints. An acknowledged clock
command returns `verified: false`, current clock telemetry, and
`verification: provider_acknowledged_constraints_unobservable`. It never labels current frequency
as a verified lock. Lost clock acknowledgements remain unknown.

Configuration uses ordinary Permission policy. GPU reset also uses the existing Unsafe Action
policy, bound to the exact request. The Gateway receives that authority through the trusted runtime
envelope, never model arguments. If the OS account lacks permission, the skill returns
`gpu.permission_denied` with operator remediation. It never invents `sudo` or retains root passwords.

## Reset and provider limits

| Provider / operation | Initial support |
| --- | --- |
| NVIDIA telemetry / process metadata | Queried per device; null/incomplete when unavailable |
| NVIDIA power / persistence / compute | Fresh queries, installed CLI and driver acceptance; OS privilege required |
| NVIDIA GPU/memory clocks | Queried endpoints and documented architecture restrictions; no constraint readback claim |
| NVIDIA reset | Linux, one physical GPU, inactive display, MIG disabled/unsupported, complete empty client list, current unsafe authority |
| Multi-GPU peer / NVSwitch reset | Refused; peer/Fabric Manager reset orchestration is not modeled |
| MIG / ECC configuration | Not exposed; available state is telemetry only |
| AMD / Apple | No adapter; no emulated parity |

Reset checks current clients after acquiring resource ownership. Any active client blocks reset;
unknown clients, active displays, virtualization, MIG, or unproven peer scope fail closed.
It never kills clients. Successful reset re-discovers the UUID and reports query/readback health;
this is not a hardware diagnostic certification. A lost reset response causes one probe and an
unknown-outcome receipt, even if the device is visible. Reset is never automatically repeated.

## Resources and unknown outcomes

Gateway configuration registers a durable job using the existing GatewayJobs admission authority,
claiming `gpu:<gateway>:<uuid>`. Same-device configuration serializes. Reads carry lightweight
capacity and do not acquire mutation claims, so GPU B reads remain possible while GPU A changes.
Native configuration uses `gpu_heavy` capacity; the configured per-Gateway limit still applies.
Opaque Shell/model jobs conservatively overlap through existing wildcard ownership.

Local AI start and GPU configuration share a short admission lock and a count of active
configuration owners; disjoint GPU changes can proceed concurrently. Configuration fails promptly
if startup owns the lock or an owned runtime remains live/unknown. This initial local-AI policy blocks
configuration conservatively across all GPUs. Unresolved GPU configuration also fences new
local-AI starts until resource ownership is reconciled. Ordinary external workloads may coexist with
power, persistence, compute and clock changes, subject to NVIDIA's own rejection. Reset always
requires an empty complete client list. Unrelated external applications are not controlled by
SMTO's scheduler, so the driver's final client check remains necessary.

Blocked operations return `gpu.resource_busy` with the Gateway job ID, available blocking job IDs
and the existing correlated resource facts/revision. There is no
indefinite admission wait. Every mutation execution ID is durably fenced against replay.
The GPU job records a reconciliation requirement before dispatch: generic abandoned-job repair
cannot clear a hardware outcome merely because its command ended. Explicit existing job recovery
remains available after inspecting current device state; resetting a job claim does not reset hardware.

| Lost response | Reconciliation |
| --- | --- |
| Power set / restore | Query current value (and current default for restore); report success only if desired state is observed |
| Persistence / compute | Query exact state and compare |
| Clock set / reset | Query telemetry, retain `gpu.operation_outcome_unknown`; constraints are not observable |
| Device reset | Probe UUID/device; retain unknown and never issue a second reset |
| Re-probe unavailable | Retain unknown and resource reconciliation requirement |

Transport sends a mutation once. Lost receipts trigger a read, never another mutation. Readback
proves current desired state; it cannot prove which concurrent actor caused that state.

## Errors and validation

GPU errors are canonical `gpu.*` aliases in the Error Catalog (`SMTO-GWT-0058` through
`SMTO-GWT-0082`). They cover provider/driver absence, identity change, unsupported metrics/configuration,
privileges, power/clock ranges, active clients, reset restrictions, resource contention, sample bounds,
cancellation/timeouts, unknown outcomes, invalid requests/responses, connection loss, duplicates
and unsafe confirmation. Provider stderr and process arguments are never copied into errors.

Deterministic tests inject fake NVIDIA argv responses and use real Gateway job admission. They cover
UUID reorder, null metrics, old/new XML power layouts, processes, typed configuration, readback,
permission errors, clock restrictions, reset refusal/success/lost response, sampling cancellation,
resource contention, authenticated inbound/outbound routing, policy/discovery, privacy and zero helpers.

Optional live smoke is strictly read-only:

```bash
SMTO_GPU_SMOKE=1 .venv/bin/python -m pytest -q tests/test_gpu_live.py
```

The smoke replaces the mutation entry point with a test failure and asserts every subprocess is
classified read-only. No configuration smoke is supplied or run; real changes need a separate
explicit operator procedure with prior-state restoration.

Semantics were checked against installed NVIDIA-SMI 580.159.03 and
[NVIDIA's official nvidia-smi documentation](https://docs.nvidia.com/deploy/nvidia-smi/index.html).
