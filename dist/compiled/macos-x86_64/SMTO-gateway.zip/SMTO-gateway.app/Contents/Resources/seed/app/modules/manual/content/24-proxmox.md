---
id: manual-proxmox
title: Using Proxmox VE
kind: manual
tags: [manual, proxmox, virtual-machines, containers, parameters]
order: 24
---
# Using Proxmox VE

The Proxmox skill manages virtual machines and containers through your selected
Gateway. It is **disabled by default**, including upgrades of older capability
selections. Enable/add `proxmox` in the applicable prompt, conversation or global
capability selection when you need it. A parameter reference cannot enable it or
grant permission to change a server.

## Set up a server

1. Select a Gateway that can reach your Proxmox server and supports native HTTP.
2. Open **Parameter Store** from Directory. Select **Proxmox Server** in the
   template selector beside **New**, then click **New**. This creates an unsaved
   entry in the existing JSON editor.
3. Set the key to `home_proxmox`. Enter the hostname or IP address without a URL
   or path, the port (normally `8006`), and the full account name such as
   `root@pam`. Keep `scheme` as `https` and `verify_tls` as `true`.
4. Enter a password in the parameter editor, or leave it empty so the Agent can ask for it
   through ordinary `ask_user` when a tool needs it. Save the entry.

The template is a JSON prefill. It does not save, connect, test credentials or
change skill selection automatically. For a self-signed server, explicitly
setting `verify_tls` to `false` disables certificate verification; failed
verification never switches to that mode automatically.

## Ask for guest operations

With Proxmox enabled, examples include:

- “List the virtual machines and containers on @home_proxmox.”
- “From @home_proxmox, turn on windows11.”
- “Check the status of VM 104 on @home_proxmox.”
- “Shut down windows11 gracefully.”

The four entry tools read server information, list guests, read fresh guest
status and control guest power. The runtime resolves the exact guest name or
VMID, chooses QEMU or LXC, authenticates, waits for the task and checks the
result. A unique case-insensitive exact name is accepted; similar names are
never guessed for a mutation. Duplicate names require disambiguation.

“Turn off” uses graceful shutdown. Hard stop requires an explicit request;
failed shutdown does not escalate to hard stop. Starting an already running
guest reports no change. Stopping a local wait does not cancel the remote task.
An uncertain mutation is reported for reconciliation and is not blindly repeated.
Existing approval settings still apply to writes.

## Credentials and follow-ups

The saved record remains in the existing plaintext Parameter Store. Literal profile snapshots reach execution unchanged. PARAMETERS, HTTP and WORKING_CONTEXT independently control their consumer projections, all on for new installations.

An empty password uses ordinary user input. Save a literal password in Parameter Store for reuse, or reply normally when asked. The next Agent decision retries the same tool with
`auth_values={"password":"the supplied value"}` (and `username` if needed).
These invocation-local values never update Parameter Store or Working Context. Session and ticket renewal remain protocol operations without another model decision. Runtime session tokens expire on restart; accepted literal profile data remains available.

In Conversation mode, a successful request publishes verified server identity
for later requests. A follow-up can omit `@home_proxmox` when only one current
server is valid for the selected Gateway. Multiple servers require a choice.
Guest status always comes from a fresh read. Profile changes or a different
Gateway prevent reuse of obsolete context. Deleting or abandoning the
conversation invalidates its Gateway sessions.

## If a request cannot proceed

| Result | Next step |
| --- | --- |
| Skill excluded | Enable/add Proxmox in the effective capability selection. |
| Profile missing or ambiguous | Reference the intended typed Proxmox parameter explicitly. |
| Authentication rejected | Check the realm/account and provide replacement `auth_values` through ordinary input. Save only through an explicit Parameter Store edit. |
| TLS verification failed | Repair certificate trust or explicitly choose the appropriate TLS setting. |
| Gateway HTTP unavailable | Update and restart the selected Gateway using the [HTTP readiness guide](architecture/18-http.md#gateway-runtime-readiness-and-updates). |
| Permission denied | Review that account's Proxmox permissions; local approval cannot grant server privileges. |
| Task failed, timed out or outcome unknown | Inspect the reported task and fresh guest state before considering another mutation. |

Advanced operations use a generated API organized into discoverable sections;
the full API is not included in ordinary model requests. See the
[Proxmox architecture guide](architecture/19-proxmox.md) for API coverage,
transport limits, session rules and the offline generation workflow, and
[Parameters and Database](16-parameter-store-context-sql.md) for editor and
accepted-reference semantics.
