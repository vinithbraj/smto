/* Desktop presentation only. Search mounted text; never fetch or persist queries. */
(() => {
  "use strict";
  if (window.SMTOUiFind) return;
  const supported = Boolean(globalThis.Highlight && globalThis.CSS?.highlights);
  const names = {matches: "smto-find", active: "smto-find-active", filters: "smto-filter"};
  const filters = new Map(), adapters = new Set(), reveals = new Map(), pendingToggles = new WeakSet();
  const excluded = 'script,style,noscript,template,iframe,object,canvas,svg,input,textarea,select,[contenteditable]:not([contenteditable="false"]),[data-ui-find-ignore],.sr-only,.app-boot-screen';
  const filterSpecs = [
    ["#chat-search", "#history-list"],
    ["#directory-search", "#directory-page-list, #directory-route-groups"],
    ["#parameter-search", "#parameter-list"], ["#schedule-search", "#schedule-list"],
    ["#notification-search", "#notification-list"], ["#prompt-recall-search", "#prompt-recall-results"],
    [".inference-body #option-search", "#option-list"],
    [".inference-body #log-search", "#log-tail"],
    [".inference-body #log-worker", "#log-tail"],
    ['.capability-dialog [data-search], .permission-dialog [data-search]', null],
  ];
  let bar, field, counter, scopeLabel, previous, next, scope, opener;
  let opened = false, query = "", matches = [], current = -1, version = 0, timer, frame, scanning = false, dirty = false, wantJump = false, scanFeedback;
  let filterState = "";
  let searchAdapter;
  const yieldUi = () => new Promise(resolve => setTimeout(resolve, 0));
  const observer = new MutationObserver(records => {
    if (records.some(record => !record.target.parentElement?.closest('[data-ui-find-ignore]')
        && !record.target.closest?.('[data-ui-find-ignore]'))) queueRefresh();
  });
  const visible = node => node?.isConnected && !node.closest('[hidden],[inert],[aria-hidden="true"]')
    && Boolean(node.getClientRects().length);
  function foreground() {
    // Embedded nonmodal surfaces belong to page search; real modals keep their own scope.
    const dialogs = [...document.querySelectorAll('dialog[open], [role="dialog"][aria-modal="true"]')]
      .filter(node => visible(node) && (!node.hasAttribute("data-ui-find-page") || node.matches(":modal")));
    // Native modal dialogs occupy the top layer, above temporary drawers.
    const modal = document.activeElement?.closest("dialog:modal") || dialogs.filter(node => node.matches("dialog:modal")).at(-1);
    return modal || dialogs.at(-1) || document.body;
  }
  function title(root) {
    if (root === document.body) return document.querySelector("#conversation-viewport") ? "Conversation · Loaded content only"
      : document.querySelector("h1, .surface-name")?.textContent.trim() || "This screen";
    return root.getAttribute("aria-label") || document.getElementById(root.getAttribute("aria-labelledby"))?.textContent.trim()
      || root.querySelector("h1,h2,h3")?.textContent.trim() || "Dialog";
  }
  function paint(name, ranges, priority = 0) {
    if (!supported) return;
    const highlight = new Highlight();
    for (const range of ranges) highlight.add(range);
    highlight.priority = priority;
    CSS.highlights.set(name, highlight);
  }
  function clearFind() {
    if (supported) { CSS.highlights.delete(names.matches); CSS.highlights.delete(names.active); }
    matches = []; current = -1;
  }
  function watch() {
    observer.disconnect();
    const roots = new Set(opened ? [scope] : []);
    for (const [input, rootsFor] of filters) if (visible(input) && input.value.trim())
      for (const root of rootsFor()) if (root?.isConnected) roots.add(root);
    for (const root of roots) if (root?.isConnected) observer.observe(root, {subtree: true, childList: true,
      characterData: true, attributes: true, attributeFilter: ["hidden", "open", "class", "style", "inert", "aria-hidden", "data-run-filtered", "data-task-collapsed"]});
  }
  function registerFilter(input, rootsFor) {
    if (!input || filters.has(input)) return;
    filters.set(input, typeof rootsFor === "function" ? rootsFor : () => rootsFor);
    refresh();
    return () => { filters.delete(input); refresh(); };
  }
  function discoverFilters() {
    for (const [selector, roots] of filterSpecs) for (const input of document.querySelectorAll(selector))
      registerFilter(input, () => roots ? [...document.querySelectorAll(roots)] : [input.closest("dialog")]);
    // Both policy editors can be mounted with a caller-selected dialog class.
    for (const input of document.querySelectorAll('dialog input[type="search"][data-search]'))
      registerFilter(input, () => [input.closest("dialog")]);
    for (const input of filters.keys()) if (!input.isConnected) filters.delete(input);
  }
  function trigger(host) {
    if (!host || host.querySelector(':scope > [data-ui-find-trigger]')) return;
    const button = document.createElement("button"); button.type = "button";
    button.className = "ui-find-trigger"; button.dataset.uiFindTrigger = ""; button.dataset.uiFindIgnore = "";
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>';
    button.title = "Find on this screen (⌘F / Ctrl+F)";
    button.setAttribute("aria-label", "Find on this screen");
    button.addEventListener("click", open);
    if (host.matches('dialog, [role="dialog"]')) host.prepend(button); else host.append(button);
  }
  function syncSurface() {
    frame = 0;
    const root = foreground();
    if (root !== document.body) {
      const headerSelector = document.body.classList.contains("mission-settings-body")
        ? ':scope > header, :scope > form > header, :scope > .prompt-recall-heading'
        : ':scope > header, :scope > .prompt-recall-heading';
      trigger(root.querySelector(headerSelector) || root);
    }
    discoverFilters();
    const nextFilterState = [...filters.keys()].map(input => `${visible(input)}:${input.value}`).join("\0");
    if (nextFilterState !== filterState) { filterState = nextFilterState; refresh(); }
    if (opened && root !== scope) {
      restoreReveals(); scope = root; mountBar(); scopeLabel.textContent = title(scope);
      syncSearch();
      clearFind(); refresh(true);
    }
    if (opened) positionBar();
    watch();
  }
  function surfaceChanged() { if (!frame) frame = requestAnimationFrame(syncSurface); }
  function positionBar() {
    const header = document.querySelector(".app-header, .product-topbar");
    const navigation = document.querySelector(".mission-settings-sidebar");
    const content = document.querySelector(".mission-settings-sections");
    let edge = header?.getBoundingClientRect().bottom || 0;
    // Keep horizontal section navigation usable while the shared popup is open.
    if (navigation && content && navigation.getBoundingClientRect().bottom <= content.getBoundingClientRect().top + 1)
      edge = Math.max(edge, navigation.getBoundingClientRect().bottom);
    bar.style.top = scope === document.body ? `${Math.max(8, edge + 8)}px` : "";
  }
  function mountBar() {
    if (scope === document.body) scope.append(bar); else scope.prepend(bar);
    positionBar();
  }
  function updateCount() {
    const results = opened && scope === searchAdapter?.root ? searchAdapter.getResultCount?.() : 0;
    counter.textContent = !query ? "Type to find" : matches.length ? `${current + 1} of ${matches.length}`
      : results ? `${results} matching result${results === 1 ? "" : "s"}` : "No matches";
    previous.disabled = next.disabled = !matches.length;
  }
  function syncSearch() {
    if (!searchAdapter) return;
    const active = opened && scope === searchAdapter.root;
    searchAdapter.apply(active ? query : "");
    if (field) field.placeholder = active ? searchAdapter.placeholder || "Find on this screen…" : "Find on this screen…";
    if (opened && bar) positionBar();
  }
  function syncDisclosure(details) {
    const summary = details.querySelector(":scope > summary");
    if (summary?.hasAttribute("aria-expanded")) summary.setAttribute("aria-expanded", String(details.open));
    if (details.id) for (const control of document.querySelectorAll("[aria-controls]"))
      if (control.getAttribute("aria-controls") === details.id && control.hasAttribute("aria-expanded"))
        control.setAttribute("aria-expanded", String(details.open));
  }
  function restoreReveals() {
    for (const restore of reveals.values()) restore();
    reveals.clear();
  }
  function reveal(node) {
    for (const adapter of adapters) if (adapter.root.contains(node)) {
      const target = node.closest(adapter.selector);
      if (target) {
        const restore = adapter.reveal(target);
        if (restore) reveals.set(target, restore);
      }
    }
    for (let element = node; element && element !== scope.parentElement; element = element.parentElement) {
      if (element.tagName !== "DETAILS" || element.open || element.querySelector(":scope > summary")?.contains(node)) continue;
      const details = element;
      details.dataset.uiFindReveal = ""; pendingToggles.add(details); details.open = true; syncDisclosure(details);
      reveals.set(details, () => {
        if (!details.hasAttribute("data-ui-find-reveal")) return;
        pendingToggles.add(details); details.open = false;
        details.removeAttribute("data-ui-find-reveal"); syncDisclosure(details);
      });
    }
  }
  function select(index, scroll = false) {
    current = matches.length ? (index + matches.length) % matches.length : -1;
    const range = matches[current];
    if (range && scroll) {
      reveal(range.startContainer.parentElement);
      const node = range.startContainer.parentElement;
      node.scrollIntoView({block: "center", inline: "nearest", behavior: "instant"});
      // Center the actual occurrence, including within long preformatted output.
      for (let host = node; host && host !== document.body; host = host.parentElement) {
        const css = getComputedStyle(host), box = host.getBoundingClientRect(), rect = range.getBoundingClientRect();
        if (/(auto|scroll)/.test(css.overflowY) && host.scrollHeight > host.clientHeight)
          host.scrollTop += rect.top + rect.height / 2 - box.top - host.clientHeight / 2;
      }
    }
    paint(names.active, range ? [range] : [], 2); updateCount();
  }
  function temporarilyHidden(element) {
    return [...adapters].some(adapter => adapter.root.contains(element) && element.matches(adapter.selector));
  }
  // Yield text blocks with offsets into the original nodes, including inline markup.
  function* blocks(root, collapsed) {
    let nodes = [];
    function* flush() { if (nodes.length) { yield nodes; nodes = []; } }
    function* walk(element) {
      if (element.nodeType === Node.TEXT_NODE) { nodes.push(element); return; }
      if (element.nodeType !== Node.ELEMENT_NODE) return;
      const temporary = collapsed && temporarilyHidden(element);
      const foldedPanel = collapsed && element.matches('.activity-disclosures > .activity-section-disclosure:not([open]) > :not(summary)');
      if (element.matches(excluded) || element.hidden || element.getAttribute("aria-hidden") === "true"
          || element.dataset.runFiltered === "true" || (element.inert && !temporary)
          || (element.matches("dialog") && !element.open)
          || (collapsed && element.matches(".task-disclosure-query, .task-disclosure-timing"))) { yield* flush(); return; }
      const css = getComputedStyle(element);
      if ((css.display === "none" && !temporary && !foldedPanel) || css.visibility === "hidden" || css.visibility === "collapse") { yield* flush(); return; }
      const block = !["inline", "contents"].includes(css.display) || element.tagName === "BR";
      if (block) yield* flush();
      for (const child of element.childNodes) {
        if (!collapsed && element.matches("details:not([open])") && child !== element.querySelector(":scope > summary")) continue;
        yield* walk(child);
      }
      if (block) yield* flush();
    }
    yield* walk(root); yield* flush();
  }
  async function scan(root, value, collapsed, stamp) {
    const ranges = [], pattern = new RegExp(value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "giu");
    let started = performance.now(), visited = 0;
    for (const nodes of blocks(root, collapsed)) {
      const pieces = nodes.map(node => node.data), text = pieces.join("");
      pattern.lastIndex = 0;
      let match, offset = 0, cursor = 0;
      while ((match = pattern.exec(text))) {
        const start = match.index, end = start + match[0].length;
        while (cursor < nodes.length - 1 && offset + nodes[cursor].length <= start) offset += nodes[cursor++].length;
        let last = cursor, endOffset = offset;
        while (last < nodes.length - 1 && endOffset + nodes[last].length < end) endOffset += nodes[last++].length;
        const range = new Range(); range.setStart(nodes[cursor], start - offset); range.setEnd(nodes[last], end - endOffset);
        ranges.push(range);
        if (++visited % 100 === 0 && performance.now() - started > 8) {
          await yieldUi(); if (stamp !== version) return []; started = performance.now();
          if (nodes.some((node, i) => node.data !== pieces[i])) break;
        }
      }
      if (performance.now() - started > 8) { await yieldUi(); if (stamp !== version) return []; started = performance.now(); }
    }
    return ranges;
  }
  async function render(stamp, jump) {
    if (!supported) { updateCount(); return; }
    const active = matches[current], oldIndex = current;
    const found = opened && query ? await scan(scope, query, true, stamp) : [];
    if (stamp !== version) return;
    matches = found.filter(range => range.startContainer.isConnected && scope?.contains(range.startContainer));
    paint(names.matches, matches, 1);
    const same = active ? matches.findIndex(range => range.startContainer === active.startContainer && range.startOffset === active.startOffset) : -1;
    current = same >= 0 ? same : Math.min(Math.max(oldIndex, 0), matches.length - 1);
    if (opened) select(current, jump);
    const filtered = [];
    for (const [input, rootsFor] of filters) {
      if (!visible(input) || !input.value.trim()) continue;
      for (const root of rootsFor()) {
        if (!visible(root)) continue;
        const ranges = await scan(root, input.value.trim(), false, stamp);
        if (stamp !== version) return;
        filtered.push(...ranges.filter(range => !(opened && query && scope.contains(range.startContainer))));
      }
    }
    if (stamp === version) paint(names.filters, filtered);
  }
  async function runScan() {
    timer = null;
    if (scanning) return;
    const busyFeedback = scanFeedback;
    try {
    scanning = true; dirty = false;
    const stamp = version, jump = wantJump;
    try {
      await render(stamp, jump);
      if (stamp === version) wantJump = false;
    } finally {
      scanning = false;
      if (dirty) queueRefresh();
    }

    } finally { if (!dirty) { busyFeedback?.finish(); if (scanFeedback === busyFeedback) scanFeedback = null; } }
  }
  // Streaming coalesces into bounded scans instead of postponing Find indefinitely.
  function queueRefresh() {
    dirty = true;
    if (!timer && !scanning) timer = setTimeout(runScan, 80);
  }
  function refresh(jump = false) {
    if (jump) { scanFeedback?.dispose(); scanFeedback = window.SMTOBusy?.begin({host: field, label: "Finding matches…"}); }
    ++version; clearTimeout(timer); wantJump ||= jump; dirty = true; watch();
    timer = setTimeout(runScan, jump ? 100 : 80);
  }
  function open(event) {
    if (!supported && foreground() !== searchAdapter?.root) {
      const button = event?.currentTarget || document.activeElement;
      if (button?.matches("[data-ui-find-trigger]")) {
        button.textContent = "Use ⌘F / Ctrl+F"; button.setAttribute("aria-label", "Use browser Find: Command F or Control F");
      }
      return;
    }
    if (opened) syncSurface();
    if (!opened) {
      opener = visible(event?.currentTarget) ? event.currentTarget : document.activeElement;
      opened = true; scope = foreground();
      mountBar(); bar.hidden = false; scopeLabel.textContent = title(scope); syncSearch(); updateCount();
      document.dispatchEvent(new Event("ui-find-state")); refresh();
    }
    field.focus({preventScroll: true}); field.select();
  }
  function close({restoreFocus = true} = {}) {
    scanFeedback?.dispose(); scanFeedback = null;
    ++version; clearTimeout(timer); timer = null; wantJump = false; opened = false; query = "";
    if (field) field.value = "";
    restoreReveals(); clearFind();
    syncSearch();
    if (bar) { bar.hidden = true; document.body.append(bar); }
    if (restoreFocus && visible(opener)) opener.focus({preventScroll: true});
    document.dispatchEvent(new Event("ui-find-state")); refresh();
  }
  function init() {
    bar = document.createElement("section"); bar.className = "ui-find-bar"; bar.hidden = true; bar.dataset.uiFindIgnore = "";
    bar.setAttribute("role", "search"); bar.setAttribute("aria-label", "Find on this screen");
    bar.innerHTML = '<span class="ui-find-scope"></span><input type="search" aria-label="Find text on this screen" placeholder="Find on this screen…" maxlength="256" autocomplete="off" spellcheck="false"><span class="ui-find-count" role="status" aria-live="polite" aria-atomic="true"></span><button type="button" data-find="previous" aria-label="Previous match" title="Previous match (Shift+Enter)">↑</button><button type="button" data-find="next" aria-label="Next match" title="Next match (Enter)">↓</button><button type="button" data-find="close" aria-label="Close Find" title="Close Find (Escape)">×</button>';
    field = bar.querySelector("input"); counter = bar.querySelector(".ui-find-count"); scopeLabel = bar.querySelector(".ui-find-scope");
    previous = bar.querySelector('[data-find="previous"]'); next = bar.querySelector('[data-find="next"]');
    previous.onclick = () => select(current - 1, true); next.onclick = () => select(current + 1, true);
    bar.querySelector('[data-find="close"]').onclick = () => close();
    field.addEventListener("input", event => {
      if (event.isComposing) return;
      restoreReveals(); query = field.value.trim(); clearFind();
      syncSearch();
      counter.textContent = query ? "Searching…" : "Type to find";
      previous.disabled = next.disabled = true; refresh(true);
    });
    field.addEventListener("compositionend", () => field.dispatchEvent(new Event("input", {bubbles: true})));
    document.body.append(bar);
    trigger(document.querySelector('#settings-secondary-actions')
      || document.querySelector('.header-actions, .mission-settings-actions, .directory-actions, .product-topbar > nav'));
    discoverFilters();
  }
  // Window capture precedes dialog-specific handlers, including capture listeners.
  window.addEventListener("keydown", event => {
    if (event.isComposing || !bar) return;
    if ((supported || foreground() === searchAdapter?.root) && (event.metaKey || event.ctrlKey) && !event.altKey && !event.shiftKey && event.key.toLowerCase() === "f") {
      event.preventDefault(); event.stopImmediatePropagation(); open();
    } else if (opened && event.key === "Escape") {
      event.preventDefault(); event.stopImmediatePropagation(); close();
    } else if (opened && bar.contains(event.target) && event.key === "Enter" && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault(); event.stopImmediatePropagation(); select(current + (event.shiftKey ? -1 : 1), true);
    }
  }, true);
  // A Find reveal is presentation-only: do not run disclosure lazy-load handlers.
  window.addEventListener("toggle", event => {
    if (pendingToggles.has(event.target)) {
      pendingToggles.delete(event.target); event.stopImmediatePropagation(); syncDisclosure(event.target); return;
    }
    surfaceChanged();
  }, true);
  document.addEventListener("click", event => {
    const control = event.target.closest("summary, [aria-controls]");
    const details = control?.matches("summary") ? control.parentElement : document.getElementById(control?.getAttribute("aria-controls"));
    if (details?.matches("details[data-ui-find-reveal]")) {
      reveals.delete(details); pendingToggles.delete(details); details.removeAttribute("data-ui-find-reveal");
    }
    surfaceChanged();
  }, true);
  document.addEventListener("input", event => {
    if (event.target === field) return;
    discoverFilters(); if (filters.has(event.target)) refresh();
  });
  document.addEventListener("focusin", surfaceChanged);
  window.addEventListener("resize", surfaceChanged);
  window.addEventListener("pagehide", () => close({restoreFocus: false}));
  window.SMTOUiFind = {open, close, refresh, registerFilter,
    registerSearch(adapter) { searchAdapter = adapter; if (bar) syncSearch(); },
    registerReveal(adapter) { adapters.add(adapter); return () => adapters.delete(adapter); },
    isOpen: () => opened,
    isRevealed: node => Boolean(node?.closest('[data-ui-find-reveal]')),
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, {once: true}); else init();
})();
