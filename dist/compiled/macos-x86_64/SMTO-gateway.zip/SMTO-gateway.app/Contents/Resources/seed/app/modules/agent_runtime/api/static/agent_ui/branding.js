/* Display identity only; source data and identifiers stay unchanged. */
(() => {
  "use strict";
  const brand = window.__BRANDING__;
  const {page} = window.__BRANDING_UI__;
  let {agent_name: agentName} = window.__BRANDING_UI__;
  const bindings = new Map();
  const displayName = () => agentName || brand.display_name;
  const text = value => String(value ?? "").replace(/\b(?:smTO|SMTO)\b(?![-_])/g, () => displayName());
  function bindText(node, template = "{name}", format) {
    const project = format || (() => template.replaceAll("{name}", displayName));
    if (format || template.includes("{name}")) bindings.set(node, project);
    node.textContent = project();
    return node;
  }
  function render() {
    document.title = agentName ? (page ? `${page} · ${agentName}` : agentName)
      : page === "Settings" ? brand.browser.settings_title
      : page ? `${page} · ${brand.display_name}` : brand.browser.default_title;
    for (const node of document.querySelectorAll('meta[name="application-name"], meta[name="apple-mobile-web-app-title"]')) {
      node.content = agentName || brand.browser.application_name;
    }
    for (const label of document.querySelectorAll("[data-agent-name]")) {
      label.title = displayName();
      label.querySelector("[data-agent-name-custom]").textContent = agentName;
      label.querySelector("[data-agent-name-custom]").hidden = !agentName;
      label.querySelector("[data-agent-name-default]").hidden = Boolean(agentName);
    }
    for (const node of document.querySelectorAll("[data-brand-display-name]")) node.textContent = displayName();
    for (const [node, project] of bindings) {
      if (node.isConnected) node.textContent = project();
      else bindings.delete(node);
    }
  }
  function apply(settings) {
    if (!settings || !Object.hasOwn(settings, "agent_name")) return;
    agentName = typeof settings.agent_name === "string" ? settings.agent_name.trim() : "";
    render();
  }
  window.SMTOBranding = Object.freeze({displayName, text, bindText, apply});
  document.addEventListener("DOMContentLoaded", render);
})();
