---
id: historical-v54-architecture-storage-observability
title: Historical V54 - Storage And Observability
kind: legacy
tags: [architecture, storage, observability, sqlite]
summary: How runtime state is stored and how trace events make request behavior inspectable.
order: 6
---

> Historical reference. See the current V55 architecture guide before using this material.

# Storage And Observability

SMTO uses small local SQLite stores for durable state and trace events
for runtime transparency.

## Storage Map

```mermaid
flowchart TD
    A --> C[Prompts]
    A --> D[Events]
    A --> E[Gateways]
    A --> F[Tasks]
    A --> G[Monitors]
    A --> H[Parameters]
    A --> J[Runtime and learned caches]
    A --> K[Gmail cache and tokens]
```

## Observability Flow

```mermaid
sequenceDiagram
    participant Stage
    participant Trace
    participant UI
    Stage->>Trace: Emit PipelineEvent
    Trace->>Trace: Redact and persist in request state
    UI->>Trace: GET /api/agent/trace/{request_id}
    Trace-->>UI: Stage timeline and details
```

## What To Inspect


## Parameter Store Observability

Parameter Store records are stored in `artifacts/agent_parameters.db`.
List/get responses expose masked `value_json`, bounded `context_json`, schemas,
environment names, use counts, and audit metadata. Raw `value_json` appears
only after the audited reveal route or in execution-only runtime context.

`context_json` is intentionally visible as non-secret guidance, but prompt and
trace paths still use bounded/redacted summaries. SQL trace events show whether
stored schema, relation metadata, and bounded domain context were supplied to
the SQL LLM.

## Learned Cache Observability

LRN-T/LR-T events include lookup, hit, rejected-candidate, write, and
quarantine metadata in the request trace. The Agent UI renders concise grouped
learning summaries in final answers when LRN-T, LR Direct/LR-EX, or LRN writes
apply or do not meet thresholds. Examples include `LR-T applied`,
`LR-T not applied`, `LR-D applied`, and `LRN learned`. Raw ids and detailed
scores stay in trace details rather than the default final-answer footer.


## Gmail Observability

Gmail state is stored in `artifacts/agent_gmail.db` by default. Status and sync
routes expose connected accounts, token health, cache counts, label counts,
per-account sync state, and sync events. Gmail action traces should preserve
selected account, selector, matched messages, confirmation state, and Gmail API
errors so operators can tell whether mail was only previewed or actually
changed.
