/* Persistent presentation of ordinary assistant content, keyed by model decision. */
(() => {
  "use strict";

  function refresh(turn, status = turn?.activity?.status) {
    if (!turn?.work) return;
    const entries = window.SMTOProseActivity.entries(turn.work.items, turn.narrations);
    for (const [index, entry] of entries.entries()) {
      const rows = [...(turn.actionItems?.values() || [])].filter(row => entry.view.items.contains(row.item));
      const facts = rows.map(row => {
        const state = String(row.item.dataset.status || row.span?.status || "").toLowerCase();
        const outcome = row.icon.querySelector(".command-outcome")?.dataset.outcome;
        const failed = ["failed", "error", "timed_out", "failed_to_start", "rejected"].includes(state)
          || outcome === "failure"
          || Number.isInteger(row.exitCode ?? row.span?.exitCode) && (row.exitCode ?? row.span?.exitCode) !== 0;
        return {running: row.item.dataset.running === "true", failed, model: row.span?.kind === "model",
          succeeded: !failed && (outcome === "success" || ["completed", "succeeded"].includes(state))};
      });
      window.SMTOProseActivity.update(entry.view, facts,
        {status, closed: entry.closed, last: index === entries.length - 1});
    }
  }

  function render(turn, event) {
    if (event?.event_type !== "agent.progress.narration") return false;
    const detail = event.detail || {};
    if (!detail.decision_id || !Number.isInteger(detail.sequence)) return false;
    turn.narrations ||= new Map();
    const key = `${event.request_id || turn.requestId}:${detail.decision_id}`;
    let entry = turn.narrations.get(key);
    if (entry && detail.sequence <= entry.sequence) return false;
    if (!entry) {
      entry = {sequence: 0, text: "", block: null};
      turn.narrations.set(key, entry);
    }
    entry.sequence = detail.sequence;
    if (detail.phase === "blocked") {
      if (entry.block) turn.eventCount -= 1;
      if (entry.view) {
        // Keep activity grouped when guarded prose is withdrawn.
        window.SMTOProseActivity.withdraw(entry.view);
        entry.view = null;
      }
      entry.block = null;
      entry.text = "";
      entry.closed = true;
      if (!turn.work.items.querySelector(".prose-activity, .conversation-message")) {
        turn.work.root.classList.remove("progress-timeline");
        turn.work.root.open = window.SMTOProseActivity.preference(turn.conversationId, false);
      }
      refresh(turn);
      return true;
    }
    if (entry.closed) return false;
    if (detail.phase === "completed") {
      entry.closed = true;
      refresh(turn);
      return false;
    }
    if (detail.phase !== "delta" || typeof detail.content !== "string") return false;
    entry.text += detail.content;
    if (!entry.text.trim()) return false;
    if (!entry.block) {
      if (!turn.work.root.classList.contains("progress-timeline")) {
        // Reuse existing tool rows and result disclosures in their original order.
        turn.work.root.classList.add("progress-timeline");
        turn.work.root.open = true;
      }
      entry.block = document.createElement("div");
      entry.block.className = "agent-progress-narration markdown";
      entry.block.dataset.decisionId = detail.decision_id;
      const fallback = window.SMTOProseActivity.entries(turn.work.items)
        .find(item => item.view.items === turn.work.activeItems)?.view;
      entry.view = window.SMTOProseActivity.promoteWorking(fallback,
        {decisionId: detail.decision_id, block: entry.block, timestamp: event.timestamp});
      if (!entry.view) {
        entry.view = window.SMTOProseActivity.create({conversationId: turn.conversationId,
          decisionId: detail.decision_id, timestamp: event.timestamp,
          block: entry.block, itemsClass: "work-items"});
        const previous = turn.work.activeItems || turn.work.items;
        // The inference row starts before its prose arrives. Keep it with that prose.
        const model = previous.lastElementChild;
        if (model?.classList.contains("model-item")) entry.view.items.append(model);
        if (!turn.work.activeItems) {
          entry.view.items.prepend(...window.SMTOProseActivity.leadingItems(turn.work.items));
        }
        turn.work.items.append(entry.view.root);
      }
      turn.work.activeItems = entry.view.items;
      turn.work.root.hidden = false;
      turn.eventCount = (turn.eventCount || 0) + 1;
    }
    window.SMTOMarkdown.render(entry.block, entry.text);
    refresh(turn);
    return true;
  }

  window.SMTOProgressNarration = {render, refresh};
})();
