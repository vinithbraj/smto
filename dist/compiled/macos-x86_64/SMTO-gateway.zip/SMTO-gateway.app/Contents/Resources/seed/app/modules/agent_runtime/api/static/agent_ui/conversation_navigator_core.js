/* Shared, deterministic conversation navigation. No transport or execution dependencies. */
(() => {
  "use strict";
  if (window.SMTOConversationNavigatorCore) return;
  const MIN_TURNS = 3;
  function deriveNavigatorLabel({prompt = "", attachments = []}) {
    let code = false;
    const prose = String(prompt).replace(/^\s*(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:^\s*\1\s*$|(?![\s\S]))/gm, () => {
      code = true; return " ";
    }).replace(/^\s{4}.*$/gm, () => { code = true; return " "; });
    const label = prose.replace(/^\s{0,3}(?:#{1,6}\s+|>\s*|[-*+]\s+|\d+[.)]\s+)/gm, "")
      .replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1")
      .replace(/(\*\*|__|~~|`)/g, "").replace(/\s+/g, " ").trim();
    if (label) return label.length > 100 ? `${label.slice(0, 99).trimEnd()}…` : label;
    if (attachments.length > 1) return `Files · ${attachments.length} attachments`;
    if (attachments.length === 1) {
      const file = attachments[0], name = file.filename || file.name || "";
      const kind = /^(image\/)/.test(file.mime_type || file.content_type || file.type || "")
        || /\.(png|jpe?g|gif|webp|heic|avif|svg)$/i.test(name) ? "Image" : "File";
      return `${kind}${name ? ` · ${name}` : ""}`.slice(0, 100);
    }
    return code ? "Code request" : "User prompt";
  }
  function deriveEntries(records, previous = []) {
    const cache = new Map(previous.map(entry => [entry.messageId, entry]));
    const seen = new Set(), entries = [];
    for (const record of records) {
      if (record.role !== "user" || record.hidden || !record.messageId || seen.has(record.messageId)) continue;
      seen.add(record.messageId);
      const old = cache.get(record.messageId);
      // The prompt remains a reference to authoritative state; only labels are derived.
      entries.push(old && old.prompt === record.prompt && old.attachments === record.attachments && old.anchor === record.anchor
        ? old : {...record, label: deriveNavigatorLabel(record)});
    }
    return entries;
  }
  function markerBuckets(count, height, activeIndex) {
    const capacity = Math.max(1, Math.floor(height / 12));
    const size = Math.min(count, capacity), compressed = count > size;
    return Array.from({length: size}, (_, slot) => {
      const start = Math.floor(slot * count / size), end = Math.floor((slot + 1) * count / size);
      const active = activeIndex >= start && activeIndex < end;
      return {index: active ? activeIndex : start, active, compressed};
    });
  }
  function activeIndexAt(entries, viewport) {
    if (!entries.length) return -1;
    if (viewport.scrollTop <= 1) return 0;
    if (viewport.scrollTop + viewport.clientHeight >= viewport.scrollHeight - 2) return entries.length - 1;
    const threshold = viewport.getBoundingClientRect().top + viewport.clientHeight * 0.25;
    // References are registered by the render owner. No DOM query or full scan on scroll.
    let low = 0, high = entries.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (entries[mid].anchor.getBoundingClientRect().top <= threshold) low = mid + 1;
      else high = mid;
    }
    return Math.max(0, low - 1);
  }
  function createTracker({entries, viewport, content, changed, resized = () => {}}) {
    let active = -1, frame = 0, disposed = false, intersection;
    function update() {
      frame = 0;
      if (disposed) return;
      const next = activeIndexAt(entries, viewport);
      if (next !== active) { active = next; changed(next); }
    }
    function refresh() { if (!disposed && !frame) frame = requestAnimationFrame(update); }
    function observe() {
      intersection?.disconnect();
      if (typeof IntersectionObserver !== "undefined") {
        intersection = new IntersectionObserver(refresh, {root: viewport,
          rootMargin: `0px 0px -${Math.round(viewport.clientHeight * 0.75)}px 0px`});
        for (const entry of entries) intersection.observe(entry.anchor);
      }
    }
    const resize = new ResizeObserver(records => {
      if (records.some(record => record.target === viewport)) { observe(); resized(); }
      refresh();
    });
    resize.observe(viewport);
    resize.observe(content);
    observe(); refresh();
    return {refresh, dispose() {
      disposed = true; cancelAnimationFrame(frame); intersection?.disconnect(); resize.disconnect();
    }};
  }
  function scrollToTurn(anchor) {
    if (!anchor?.isConnected) return false;
    anchor.scrollIntoView({block: "start", inline: "nearest",
      behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth"});
    return true;
  }
  let listSequence = 0;
  function createPromptList({entries, activeIndex, select, rowHeight = 36}) {
    const baseRowHeight = rowHeight;
    const scaledRowHeight = () => baseRowHeight * Math.max(1,
      Number(document.documentElement.dataset.fontScale || 100) / 100);
    rowHeight = scaledRowHeight();
    const root = document.createElement("div"), space = document.createElement("div");
    const prefix = `conversation-prompts-${++listSequence}`;
    root.className = "prompt-navigator-list";
    root.tabIndex = 0;
    root.setAttribute("role", "listbox");
    root.setAttribute("aria-label", `Conversation Navigator, ${entries.length} user prompts`);
    space.className = "prompt-navigator-space";
    space.style.height = `${entries.length * rowHeight}px`;
    root.append(space);
    let active = activeIndex, focused = activeIndex, manual = false, frame = 0, signature = "";
    function render() {
      frame = 0;
      const start = Math.max(0, Math.floor(root.scrollTop / rowHeight) - 3);
      const end = Math.min(entries.length, Math.ceil((root.scrollTop + root.clientHeight) / rowHeight) + 3);
      const nextSignature = `${start}:${end}:${active}:${focused}`;
      if (signature === nextSignature) return;
      signature = nextSignature;
      const rows = [];
      for (let index = start; index < end; index++) {
        const entry = entries[index], row = document.createElement("div");
        row.className = "prompt-navigator-row";
        row.id = `${prefix}-${index}`;
        row.dataset.index = String(index);
        row.dataset.focused = String(index === focused);
        row.style.top = `${index * rowHeight}px`;
        row.style.height = `${rowHeight}px`;
        row.setAttribute("role", "option");
        row.setAttribute("aria-selected", String(index === active));
        if (index === active) row.setAttribute("aria-current", "location");
        row.setAttribute("aria-posinset", String(index + 1));
        row.setAttribute("aria-setsize", String(entries.length));
        row.setAttribute("aria-label", `Jump to user prompt ${index + 1}: ${entry.label}`);
        row.textContent = entry.label;
        rows.push(row);
      }
      space.replaceChildren(...rows);
      if (focused >= start && focused < end) root.setAttribute("aria-activedescendant", `${prefix}-${focused}`);
      else root.removeAttribute("aria-activedescendant");
    }
    function reveal(index, center = false) {
      const top = index * rowHeight;
      if (center) root.scrollTop = top - (root.clientHeight - rowHeight) / 2;
      else if (top < root.scrollTop) root.scrollTop = top;
      else if (top + rowHeight > root.scrollTop + root.clientHeight) root.scrollTop = top + rowHeight - root.clientHeight;
      render();
    }
    root.addEventListener("scroll", () => { if (!frame) frame = requestAnimationFrame(render); }, {passive: true});
    for (const type of ["wheel", "touchstart", "pointerdown"]) root.addEventListener(type, () => { manual = true; }, {passive: true});
    root.addEventListener("click", event => {
      const row = event.target.closest("[data-index]");
      if (row) select(Number(row.dataset.index));
    });
    root.addEventListener("keydown", event => {
      if (["ArrowUp", "ArrowDown", "Home", "End"].includes(event.key)) {
        event.preventDefault(); manual = true;
        focused = event.key === "Home" ? 0 : event.key === "End" ? entries.length - 1
          : Math.max(0, Math.min(entries.length - 1, focused + (event.key === "ArrowDown" ? 1 : -1)));
        reveal(focused);
      } else if (["Enter", " "].includes(event.key)) { event.preventDefault(); select(focused); }
    });
    function resize() {
      const previous = rowHeight;
      rowHeight = scaledRowHeight();
      space.style.height = `${entries.length * rowHeight}px`;
      root.scrollTop = root.scrollTop * rowHeight / previous;
      signature = "";
      render();
    }
    window.addEventListener("smto:font-scale", resize);
    return {root, open() { reveal(active, true); }, resize,
      update(index) { active = index; if (!manual) { focused = index; reveal(index); } else render(); },
      dispose() { window.removeEventListener("smto:font-scale", resize); cancelAnimationFrame(frame); root.remove(); }};
  }
  window.SMTOConversationNavigatorCore = Object.freeze({MIN_TURNS, deriveNavigatorLabel,
    deriveEntries, markerBuckets, activeIndexAt, createTracker, scrollToTurn, createPromptList});
})();
