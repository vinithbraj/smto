/**
@file src/agent_runtime/api/static/agent_ui/conversation_management.js
@brief Render a bounded conversation rail with independent selection and active-run presentation.
@ingroup ProductInterfaces
@details
Responsibilities: Fetch compact summaries, render Running from server fields, manage navigation/search and preserve focused row controls.
Boundaries: Selection is navigation; no browser run registry, lifecycle inference or deletion safety policy lives here.
Lifecycle: Index/search fetches feed virtualized rows; runs/tasks/chats/sync invalidations coalesce into the existing 180ms refresh path.
State: Page-local index, query generations and single-flight indexDirty handle stale responses; both render signatures include activity and count.
Security: Render titles/previews as text; reviewed deletion remains server-owned. No model, Gateway or extra EventSource calls.
Collaborators: conversation_history.js supplies geometry; ui_updates.js invalidates summaries; management APIs supply authoritative activity.
Public surface: SMTOConversationManagement.create returns rail refresh/render and selection helpers.
@see src/agent_runtime/api/static/agent_ui/conversation_management.css
@see src/agent_runtime/api/agent_ui_support/conversation_management.py
*/
(() => {
  "use strict";
  /** Mount the conversation rail using caller-owned API, navigation and selection hooks. */
  function create({drawer, list, apiJson, notify, openConversation, conversationUrl, currentId, deletedCurrent, relativeDate}) {
    const $ = id => drawer.querySelector(`#${id}`);
    const search = $("chat-search"), sort = $("chat-sort"), status = $("chat-status");
    const taskType = $("chat-task-type");
    const pinned = $("chat-pinned"), selectionBar = $("chat-selection"), select = $("chat-select");
    const shown = $("chat-select-shown"), all = $("chat-select-matching"), count = $("chat-selected-count"), more = $("chat-load-more");
    const session = window.SMTOUiSession;
    sort.value = session.get("conversation_sort", sort.value);
    status.value = session.get("conversation_status", status.value);
    taskType.value = session.get("conversation_task_type", taskType.value);
    pinned.setAttribute("aria-pressed", String(session.get("conversation_pinned", false)));
    const feedbackReady = import("./deletion_progress.js?v=20261018-immersive-default");
    const deletionState = () => window.SMTOConversationDeletion;
    const isDeleting = id => deletionState()?.isDeleting(id) || false;
    const isDeleted = id => deletionState()?.isDeleted(id) || false;
    const blocked = id => deletionState()?.blocked(id) || false;
    let rows = [], next = null, matching = 0, selecting = false, allMatching = false;
    let selected = new Set(), excluded = new Set(), generation = 0, timer, openMenu = null, previewing = false;
    const history = window.SMTOConversationHistory, limits = history.limits;
    let index = new Map(), indexPromise = null, indexDirty = false, refreshTimer, searchController;
    let indexGeneration = 0;
    let visibleRows = [], renderedSignature = "", frame = 0;
    /** Use server search for text and filters requiring retained turn content. */
    const serverMode = () => Boolean(search.value.trim() || ["needs_approval", "needs_input", "has_response"].includes(status.value));
    /** Select the fixed virtual row geometry for ordinary or search rows. */
    const rowHeight = () => search.value.trim() ? limits.railSearchRow : limits.railRow;
    /** Bound mounted rows around the viewport with the existing overscan allowance. */
    function windowBounds() {
      const height = rowHeight(), first = Math.max(0, Math.floor(list.scrollTop / height));
      const start = Math.max(0, first - limits.railOverscan);
      const end = Math.min(rows.length, start + limits.railMaxRows,
        first + Math.ceil((list.clientHeight || 600) / height) + limits.railOverscan);
      return {start, end, first, visibleEnd: Math.min(rows.length, first + Math.ceil((list.clientHeight || 600) / height))};
    }
    /** Reserve offscreen row space without adding accessible content. */
    const spacer = height => {
      const node = document.createElement("div"); node.className = "history-rail-spacer";
      node.style.height = `${Math.max(0, height)}px`; node.setAttribute("aria-hidden", "true"); return node;
    };
    /** Snapshot current query controls for server search and all-matching selection. */
    const filters = () => ({query: search.value.trim(), sort: sort.value, status: status.value || null,
      task_type: taskType.value || null, pinned: pinned.getAttribute("aria-pressed") === "true" ? true : null});
    const isScheduled = chat => chat.provenance?.source === "schedule";
    const executionFormat = new Intl.DateTimeFormat(undefined, {year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit"});
    const executionDetailFormat = new Intl.DateTimeFormat(undefined, {dateStyle: "full", timeStyle: "long"});
    /** Show the recorded schedule occurrence time, independent of later edits or follow-ups. */
    function scheduledMeta(chat) {
      const stamp = chat.provenance?.triggered_at;
      const date = stamp ? new Date(stamp) : null;
      const known = date && Number.isFinite(date.getTime());
      const meta = document.createElement("span"); meta.className = "history-item-meta history-scheduled-meta";
      meta.title = known ? `Scheduled run · ${executionDetailFormat.format(date)}` : "Scheduled run · Execution time unavailable";
      meta.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18m-9 3v3l2 1"/></svg>';
      const time = document.createElement(known ? "time" : "span");
      if (known) time.dateTime = date.toISOString();
      time.textContent = known ? executionFormat.format(date) : "Scheduled run";
      meta.append(time);
      return meta;
    }
    /** Resolve bulk selection membership, independent of open and running states. */
    const isSelected = id => !blocked(id) && (allMatching ? !excluded.has(id) : selected.has(id));
    /** Count explicit selection or all-matching selection minus exclusions. */
    const selectedCount = () => allMatching ? Math.max(0, matching - excluded.size) : [...selected].filter(id => !blocked(id)).length;
    /** Serialize reviewed selection intent without copying conversation contents. */
    const descriptor = () => allMatching ? {all_matching: true, ...filters(), excluded_ids: [...excluded]} : {conversation_ids: [...selected].filter(id => !blocked(id))};
    /** Create a labeled text-safe action control bound to its callback. */
    const button = (text, label, action) => {
      const node = document.createElement("button"); node.type = "button"; node.textContent = text;
      node.setAttribute("aria-label", label || text); node.title = label || text;
      node.addEventListener("click", action); return node;
    };
    /** Create plain text feedback without interpreting API strings as HTML. */
    const para = text => { const p = document.createElement("p"); p.textContent = text; return p; };
    /** Replace empty/loading rail content with a concise status message. */
    function message(text) {
      const node = para(text); node.className = "history-message"; node.setAttribute("role", "status");
      list.replaceChildren(node); renderedSignature = "";
    }
    /** Dismiss the row menu and reset its expanded state. */
    function closeMenu() {
      if (!openMenu) return;
      openMenu.menu.hidden = true; openMenu.toggle.setAttribute("aria-expanded", "false"); openMenu = null;
    }
    /** Update selection counts and action availability from the current visible rows. */
    function selectionChanged() {
      const announcement = `${selectedCount()} selected`;
      if (count.textContent !== announcement) count.textContent = announcement;
      const available = visibleRows.filter(row => !blocked(row.conversation_id));
      shown.checked = Boolean(available.length) && available.every(row => isSelected(row.conversation_id));
      shown.indeterminate = !shown.checked && available.some(row => isSelected(row.conversation_id));
      shown.disabled = !available.length;
      $("chat-select-shown-label").textContent = `Select all ${available.length} visible`;
      all.textContent = allMatching ? `All ${matching} matching selected` : `Select all ${matching} matching`;
      all.disabled = allMatching || !matching || deletionState()?.hasPending();
      $("chat-delete-selected").disabled = selectedCount() === 0;
    }
    /** Clear bulk intent and return the rail to navigation controls. */
    function cancelSelection() {
      selecting = false; allMatching = false; selected.clear(); excluded.clear();
      selectionBar.hidden = true; select.hidden = false; render();
    }
    /** Reuse bounded rows using selection and server activity signatures; preserve geometry and keyboard focus. */
    function render() {
      rows = rows.filter(row => !isDeleted(row.conversation_id));
      const bounds = windowBounds(), height = rowHeight();
      visibleRows = rows.slice(bounds.first, bounds.visibleEnd);
      const mounted = rows.slice(bounds.start, bounds.end);
      // Compare only the bounded visible projection; never serialize the index.
      const signature = `${bounds.start}:${rows.length}:${selecting}:` + mounted.map(row =>
        [row.conversation_id, row.title, row.pinned, row.updated_at, row.turn_count, row.match_preview,
          row.provenance?.source, row.provenance?.triggered_at,
          row.has_active_run, row.active_run_count,
          isDeleting(row.conversation_id), deletionState()?.label(row.conversation_id), deletionState()?.detail(row.conversation_id), isSelected(row.conversation_id), row.conversation_id === currentId()].join("\u0001")).join("\u0002");
      selectionChanged(); more.hidden = !serverMode() || !next;
      history.measure("rail_index_row_count", index.size);
      history.measure("rail_mounted_row_count", mounted.length);
      list.dataset.indexCount = String(index.size);
      if (signature === renderedSignature) return;
      renderedSignature = signature;
      const active = document.activeElement, focus = active?.dataset.focusKey;
      const scroll = list.scrollTop;
      const previous = new Map([...list.querySelectorAll(".history-item")].map(node => [node.dataset.conversationId, node]));
      const nodes = [spacer(bounds.start * height)];
      list.style.setProperty("--history-row-height", `${height}px`);
      if (!rows.length) {
        message(search.value || status.value || taskType.value || filters().pinned ? "No matching conversations." : "No conversations yet. Start a new chat to see it here."); return;
      }
      for (const chat of mounted) {
        const id = chat.conversation_id, title = chat.title || "Untitled chat";
        const deleting = isDeleting(id), deletionLabel = deletionState()?.label(id);
        const rowSignature = [title, chat.pinned, chat.updated_at, chat.turn_count, chat.match_preview,
          chat.provenance?.source, chat.provenance?.triggered_at,
          chat.has_active_run, chat.active_run_count, deleting, deletionLabel, deletionState()?.detail(id), selecting, isSelected(id), id === currentId()].join("\u0001");
        const existing = previous.get(id);
        if (existing?.dataset.signature === rowSignature) {
          existing.setAttribute("aria-setsize", String(rows.length));
          existing.setAttribute("aria-posinset", String(bounds.start + mounted.indexOf(chat) + 1));
          nodes.push(existing); continue;
        }
        const item = document.createElement("div"); item.className = "history-item"; item.dataset.conversationId = id;
        item.dataset.signature = rowSignature;
        item.setAttribute("role", "listitem"); item.setAttribute("aria-setsize", String(rows.length));
        item.setAttribute("aria-posinset", String(bounds.start + mounted.indexOf(chat) + 1));
        item.dataset.active = String(id === currentId());
        item.dataset.runActive = String(!deleting && chat.has_active_run === true);
        item.dataset.deleting = String(deleting);
        item.dataset.deletionState = deleting ? deletionState().state(id) : '';
        item.dataset.taskType = isScheduled(chat) ? "scheduled" : "normal";
        if (selecting) {
          const box = document.createElement("input"); box.type = "checkbox"; box.checked = isSelected(id);
          box.disabled = deleting;
          box.setAttribute("aria-label", `Select ${title}`); box.dataset.focusKey = `select:${id}`;
          box.addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); box.click(); } });
          box.addEventListener("change", () => {
            const set = allMatching ? excluded : selected;
            if (allMatching ? !box.checked : box.checked) { if (set.size >= 1000) { box.checked = !box.checked; notify("Use Select all matching for a larger selection."); return; } set.add(id); }
            else set.delete(id);
            selectionChanged();
          });
          item.append(box);
        }
        const open = button("", `Open ${title}${deleting ? ` — ${deletionLabel}` : chat.has_active_run ? " — Running" : ""}`, () => { if (!blocked(id)) openConversation(id); }); open.className = "history-open"; open.dataset.focusKey = `open:${id}`;
        open.disabled = deleting;
        if (id === currentId()) open.setAttribute("aria-current", "page");
        const name = document.createElement("span"); name.className = "history-item-title"; name.textContent = title;
        name.title = title;
        if (chat.pinned) { const pin = document.createElement("span"); pin.className = "chat-pin"; pin.textContent = "⌖ "; pin.setAttribute("aria-label", "Pinned"); name.prepend(pin); }
        const heading = document.createElement("span"); heading.className = "history-item-heading";
        heading.append(name);
        const meta = isScheduled(chat) ? scheduledMeta(chat) : document.createElement("span");
        if (!isScheduled(chat)) {
          meta.className = "history-item-meta";
          meta.append(relativeDate(chat.updated_at));
          meta.append(` · ${chat.turn_count || 0} turn${chat.turn_count === 1 ? "" : "s"}`);
        } else {
          const label = `${open.getAttribute("aria-label")} — ${meta.title}`;
          open.setAttribute("aria-label", label); open.title = label;
        }
        if (deleting || chat.has_active_run) {
          const running = document.createElement("span"); running.className = `history-run-state${deleting ? " history-delete-state" : ""}`;
          running.title = deleting ? deletionState().detail(id) : `${chat.active_run_count} active run${chat.active_run_count === 1 ? "" : "s"}`;
          const dot = document.createElement("span"); dot.className = "history-run-dot"; dot.setAttribute("aria-hidden", "true");
          running.append(dot, deleting ? deletionLabel : "Running"); heading.append(running);
        }
        open.append(heading, meta);
        if (chat.match_preview) { const match = document.createElement("span"); match.className = "chat-match"; match.textContent = `Matched: ${chat.match_preview}`; open.append(match); }
        item.append(open);
        const newTab = document.createElement("a");
        newTab.className = "icon-button chat-new-tab";
        if (deleting) { newTab.setAttribute("aria-disabled", "true"); newTab.tabIndex = -1; }
        else newTab.href = conversationUrl(id);
        newTab.target = "_blank"; newTab.rel = "noopener";
        newTab.setAttribute("aria-label", "Open conversation in new tab");
        newTab.title = `Open ${title} in new tab`; newTab.dataset.focusKey = `new-tab:${id}`;
        newTab.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6m0-6L10 14M10 5H5a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1v-5" /></svg>';
        newTab.addEventListener("click", event => { event.stopPropagation(); if (blocked(id)) event.preventDefault(); });
        item.append(newTab);
        if (!selecting) {
          const remove = button("", `Delete ${title}`, () => { closeMenu(); void deletion({conversation_ids: [id]}, remove); });
          remove.className = "icon-button chat-delete"; remove.dataset.focusKey = `delete:${id}`;
          remove.disabled = deleting;
          remove.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7m4-7v7" /></svg>';
          item.append(remove);
          const menu = document.createElement("div"); menu.className = "chat-row-menu"; menu.hidden = true; menu.setAttribute("role", "menu");
          const toggle = button("⋯", `Manage ${title}`, () => {
            const showing = menu.hidden; closeMenu(); menu.hidden = !showing; toggle.setAttribute("aria-expanded", String(showing));
            if (showing) { openMenu = {menu, toggle}; menu.querySelector("button").focus(); }
          });
          toggle.className = "icon-button chat-menu-toggle"; toggle.setAttribute("aria-haspopup", "menu"); toggle.setAttribute("aria-expanded", "false"); toggle.dataset.focusKey = `menu:${id}`;
          toggle.disabled = deleting;
          const actions = [button("Rename", `Rename ${title}`, () => { closeMenu(); rename(chat, toggle); }),
            button(chat.pinned ? "Unpin" : "Pin", `${chat.pinned ? "Unpin" : "Pin"} ${title}`, async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating conversation…");
        try {
              closeMenu(); try { await apiJson(`/api/agent/chats/${encodeURIComponent(id)}`, {method: "PATCH", headers: {"Content-Type": "application/json"}, body: JSON.stringify({pinned: !chat.pinned})}); await refresh(); } catch (error) { notify(error); }

        } finally { busyFeedback?.finish(); }
      })];
          actions.forEach(action => { action.setAttribute("role", "menuitem"); menu.append(action); });
          menu.addEventListener("keydown", event => {
            if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); closeMenu(); toggle.focus(); }
            if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
              event.preventDefault(); const index = actions.indexOf(document.activeElement);
              actions[event.key === "Home" ? 0 : event.key === "End" ? actions.length - 1 : (index + (event.key === "ArrowDown" ? 1 : -1) + actions.length) % actions.length].focus();
            }
          });
          item.append(toggle, menu);
        }
        nodes.push(item);
      }
      nodes.push(spacer((rows.length - bounds.end) * height));
      list.replaceChildren(...nodes); list.setAttribute("role", "list");
      if (openMenu && !openMenu.toggle.isConnected) closeMenu();
      list.scrollTop = scroll;
      if (active?.isConnected && list.contains(active)) active.focus({preventScroll: true});
      else if (focus) [...list.querySelectorAll("[data-focus-key]")].find(node => node.dataset.focusKey === focus)?.focus({preventScroll: true});
      requestAnimationFrame(() => history.mark("boot_to_first_rail_rows_ms"));
    }
    /** Filter Running by authoritative activity and retain existing sort keys and pin ordering. */
    function indexView() {
      if (serverMode()) return;
      const f = filters();
      rows = [...index.values()].filter(row => !isDeleted(row.conversation_id) && (f.pinned === null || row.pinned === f.pinned)
        && (!f.task_type || isScheduled(row) === (f.task_type === "scheduled"))
        && (!f.status || (f.status === "running" ? row.has_active_run === true
          : f.status === "multi_turn" ? row.turn_count > 1 : row.last_status === f.status)));
      /** Compare deterministic sort values without locale-dependent ordering. */
      const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
      rows.sort((a, b) => Number(b.pinned) - Number(a.pinned)
        || (f.sort === "title" ? compare(a.title.toLowerCase(), b.title.toLowerCase())
          : compare(a.updated_at, b.updated_at) * (f.sort === "oldest" ? 1 : -1))
        || compare(b.conversation_id, a.conversation_id));
      matching = rows.length; next = null; render();
    }
    /** Serialize eager index pages and queue a follow-up if invalidated during a fetch. */
    let indexReadBoundary = 0;
    function refreshIndex() {
      if (indexPromise) return indexPromise;
      clearTimeout(refreshTimer); refreshTimer = null;
      indexReadBoundary = window.SMTOSelectedConversation?.current()?.observed_at || 0;
      indexPromise = (async () => {
        const version = indexGeneration;
        const seen = new Set(); let cursor = null;
        list.dataset.indexLoading = "true";
        try {
          do {
            const params = new URLSearchParams({limit: limits.railPage});
            if (cursor) params.set("cursor", cursor);
            const payload = await apiJson(`/api/agent/chats/index?${params}`);
            if (version !== indexGeneration) { indexDirty = true; return; }
            (await feedbackReady).conversations.ingest(payload.chats);
            for (const row of payload.chats || []) { if (!isDeleted(row.conversation_id)) { index.set(row.conversation_id, row); seen.add(row.conversation_id); } }
            cursor = payload.next_cursor || null;
            indexView();
            await history.yieldToUi();
          } while (cursor);
          if (version !== indexGeneration) { indexDirty = true; return; }
          for (const id of index.keys()) if (!seen.has(id)) index.delete(id);
          indexView();
        } catch (error) {
          if (!index.size && !serverMode()) message(error.message || "Chat history is unavailable.");
          else notify(error.message || "Could not refresh conversations.");
        } finally {
          list.dataset.indexLoading = "false"; indexPromise = null;
          if (indexDirty) { indexDirty = false; scheduleRefresh(); }
        }
      })();
      return indexPromise;
    }
    /** Fetch one search page and discard aborted or superseded query responses. */
    async function refreshSearch({append = false, preserve = true, feedback = false, operation = null} = {}) {
      const indicator = operation || (feedback ? window.SMTOBusy?.begin({host: list, label: "Loading conversations…", key: "search", replace: true}) : null);
      try {
      searchController?.abort(); searchController = new AbortController();
      const signal = searchController.signal, version = ++generation, scroll = preserve ? list.scrollTop : 0;
      let cursor = append ? next : null, loaded = append ? [...rows] : [], payload;
      more.disabled = true; list.setAttribute("aria-busy", "true");
      if (!rows.length) message("Loading conversations…");
      try {
        const params = new URLSearchParams({limit: "50"});
        Object.entries(filters()).forEach(([key, value]) => { if (value !== null && value !== "") params.set(key, value); });
        if (cursor) params.set("cursor", cursor);
        payload = await apiJson(`/api/agent/chats?${params}`, {signal});
        if (version !== generation || signal.aborted || !serverMode()) return;
        (await feedbackReady).conversations.ingest(payload.chats);
        loaded = loaded.concat(payload.chats || []).filter(row => !isDeleted(row.conversation_id));
        rows = [...new Map(loaded.map(row => [row.conversation_id, row])).values()];
        next = payload.next_cursor || null; matching = payload.matching_count ?? rows.length;
        list.scrollTop = scroll; render();
      } catch (error) {
        if (version === generation && error.name !== "AbortError") {
          if (!rows.length) message(error.message || "Chat history is unavailable.");
          else notify(error.message || "Could not refresh conversations.");
        }
      } finally { if (version === generation) { more.disabled = false; list.removeAttribute("aria-busy"); } }
      } finally { indicator?.finish(); }
    }
    /** Reconcile the eager index and current search projection without blocking navigation. */
    function refresh(options = {}) {
      const pending = refreshIndex();
      if (serverMode()) return refreshSearch(options);
      indexView(); return pending;
    }
    /** Coalesce shared run/task/chat/sync invalidations into the existing 180ms refresh. */
    function scheduleRefresh(payload) {
      // Initial replay often arrives while boot is already reading the index.
      // Committed events older than that read's server boundary are covered by it.
      if (indexPromise && payload && (payload.syncRequired && !payload.events?.length
        || payload.events?.length && payload.events.every(event => Date.parse(event.created_at) <= indexReadBoundary * 1000))) return;
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => {
        void checkCurrent();
        if (indexPromise) indexDirty = true;
        else void refreshIndex();
        if (serverMode()) void refreshSearch();
      }, 180);
    }
    /** Invalidate prior search and selection, reset the viewport and persist presentation controls. */
    let searchFeedback;
    function changeFilters() {
      clearTimeout(timer); generation++; searchController?.abort(); cancelSelection();
      list.scrollTop = 0; next = null; renderedSignature = "";
      if (serverMode()) { rows = []; void refreshSearch({preserve: false, feedback: true, operation: searchFeedback}); searchFeedback = null; }
      else { searchFeedback?.finish(); searchFeedback = null; indexView(); }
    }
    /** Open a modal with Escape dismissal and restoration of the triggering focus. */
    function dialog(title, opener) {
      const node = document.createElement("dialog"); node.className = "chat-dialog";
      const heading = document.createElement("h2"); heading.id = "chat-dialog-title"; heading.textContent = title;
      node.setAttribute("aria-labelledby", heading.id); node.append(heading);
      document.body.append(node);
      node.addEventListener("close", () => { node.remove(); if (opener?.isConnected) opener.focus(); else $("chat-select").focus(); });
      node.addEventListener("keydown", event => { if (event.key === "Escape") event.stopPropagation(); });
      return node;
    }
    /** Submit validated title metadata and refresh summaries after a committed rename. */
    function rename(chat, opener) {
      const node = dialog("Rename conversation", opener), form = document.createElement("form");
      const input = document.createElement("input"); input.value = chat.title; input.required = true; input.maxLength = 160; input.setAttribute("aria-label", "Conversation title");
      const errorText = para(""); errorText.setAttribute("role", "alert");
      const actions = document.createElement("div"); actions.className = "chat-dialog-actions";
      const save = button("Save", "Save title", () => {}); save.type = "submit";
      const cancel = button("Cancel", "Cancel rename", () => node.close());
      actions.append(cancel, save); form.append(input, errorText, actions); node.append(form);
      form.addEventListener("submit", async event => {
        const busyFeedback = window.SMTOBusy?.action("Updating conversation…", form);
        try {
        event.preventDefault(); if (!input.value.trim()) { input.setCustomValidity("Enter a title."); input.reportValidity(); return; }
        save.disabled = true;
        try { await apiJson(`/api/agent/chats/${encodeURIComponent(chat.conversation_id)}`, {method: "PATCH", headers: {"Content-Type": "application/json"}, body: JSON.stringify({title: input.value.trim()})}); node.close(); await refresh(); }
        catch (error) { window.SMTOErrors.present(errorText, error); save.disabled = false; }

        } finally { busyFeedback?.finish(); }
      });
      input.addEventListener("input", () => input.setCustomValidity("")); node.showModal(); input.focus(); input.select();
    }
    /** Confirm removal of the selected conversations, including work changing after preview. */
    async function deletion(selection, opener) {
      if (previewing) return;
      if (selection.conversation_ids?.some(blocked)) { notify("This conversation is already being deleted."); return; }
      previewing = true;
      // Keep preparation feedback out of the rail's fixed-width icon columns.
      const busyFeedback = window.SMTOBusy?.begin({host: list, region: opener, label: "Reviewing conversation deletion…"});
      try {
      let preview, node, progress;
      try {
        const feedback = await import("./deletion_progress.js?v=20261018-immersive-default");
        node = dialog("Review deletion", opener);
        progress = feedback.create(node);
        node.addEventListener("close", progress.close);
        const cancelPreview = button("Cancel", "Cancel deletion", () => node.close());
        const previewActions = document.createElement("div"); previewActions.className = "chat-dialog-actions";
        previewActions.append(cancelPreview); node.append(previewActions);
        progress.start("Reviewing conversations…");
        node.showModal(); cancelPreview.focus();
        busyFeedback?.finish(); // The dialog now owns the visible review status.
        preview = await apiJson("/api/agent/chats/delete-preview", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(selection)});
        if (!node.open) return;
        previewActions.remove(); progress.hide();
      }
      catch (error) { node?.close(); progress?.dispose(); notify(error); return; }
      finally { previewing = false; }
      const single = preview.candidate_count === 1;
      node.querySelector("h2").textContent = single ? `Delete “${preview.conversations[0].title}”?` : "Delete conversations?";
      const deleteCount = preview.force_deletable_count ?? preview.candidate_count;
      const identities = preview.conversation_ids || selection.conversation_ids || preview.conversations.map(chat => chat.conversation_id);
      node.append(para(`${preview.candidate_count} selected. ${deleteCount} will be deleted. ${preview.force_saved_turns ?? preview.saved_turns} saved turns will be removed. This cannot be undone.`));
      node.append(para("Deleting removes saved turns and queued prompts and prevents further work in this conversation. Cancellation of running operations will be requested; already-started external operations may continue, and unresolved effects may remain unknown. The conversation disappears as soon as deletion is accepted. Stored data is cleared in the background when no tasks are active; the cleanup indicator shows progress. Only information needed to reconcile unfinished operations or serve other owners is retained. Saved Memory, pinned procedures, independent schedules, monitors and tasks remain."));
      if (preview.blocked_count) {
        node.append(para(`${preview.blocked_count} conversation${preview.blocked_count === 1 ? " has" : "s have"} active or unresolved Agent work that will be abandoned.`));
        for (const chat of preview.blocked.slice(0, 10)) {
          node.append(para(`${chat.title}: ${chat.blockers.map(blocker => blocker.label).join(" ")}`));
          node.append(button("Open conversation", `Open ${chat.title}`, () => { node.close(); openConversation(chat.conversation_id); }));
        }
      }
      if (preview.queued_tasks_to_discard) {
        node.append(para(`${preview.queued_tasks_to_discard} queued prompts that have not started will be discarded.`));
      }
      const errorText = para(""); errorText.setAttribute("role", "alert"); node.append(errorText);
      const actions = document.createElement("div"); actions.className = "chat-dialog-actions";
      const cancel = button("Cancel", "Cancel deletion", () => node.close());
      let stale = false, busy = false;
      const deleteLabel = single ? "Delete conversation" : `Delete all ${deleteCount}`;
      const confirm = button(deleteLabel, "Confirm deletion", async () => {
        const busyFeedback = window.SMTOBusy?.action("Updating conversation…");
        try {
        if (busy || stale || !deleteCount) return;
        if (identities.some(blocked)) { notify("A selected conversation is already being deleted. Review your selection again."); return; }
        busy = true; updateConfirm();
        const deletingCurrent = currentId();
        const settle = deletionState().begin(identities);
        cancelSelection();
        errorText.replaceChildren();
        progress.start(single ? "Requesting deletion…" : `Requesting deletion of ${deleteCount} conversations…`, {persist: true});
        let committed;
        try {
          const result = await apiJson("/api/agent/chats/bulk-delete", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({selection, selection_digest: preview.selection_digest, safety_digest: preview.safety_digest, discard_queued_chat_tasks: true, abandon_unresolved_work: true})});
          committed = result;
          // Apply committed server identities immediately. Follow-up reads may be
          // slow, and an index/search response started before commit is now stale.
          const removed = new Set(result.deleted_ids || []);
          indexGeneration++; generation++; searchController?.abort();
          for (const id of removed) index.delete(id);
          const kept = rows.filter(row => !removed.has(row.conversation_id));
          matching = Math.max(0, matching - (rows.length - kept.length));
          rows = kept;
          settle(result);
          progress.update(result.accepted_count ? "Pending delete · You can continue working" : "Deletion confirmed · Updating conversation list…");
          progress.detach();
          if (result.accepted_count) progress.finish(result);
          node.close(); cancelSelection();
          if (deletingCurrent && [...(result.accepted_ids || []), ...(result.deleted_ids || [])].includes(deletingCurrent)) await deletedCurrent(deletingCurrent, result);
          await checkCurrent(); await refresh(); progress.finish(result);
        } catch (error) {
          if (!committed) settle();
          if (committed) { progress.finish(committed, {refreshFailed: true}); notify(error); return; }
          busy = false;
          progress.fail(error.status === 409 ? "Selection changed · Review deletion again" : "Deletion was not confirmed · Try again");
          if (!node.isConnected) { notify(error); return; }
          window.SMTOErrors.present(errorText, error);
          if (error.status === 409) {
            stale = true;
            actions.append(button("Review again", "Review deletion again", () => { node.close(); void deletion(selection, opener); }));
          }
          updateConfirm();
        }

        } finally { busyFeedback?.finish(); }
      });
      /** Prevent duplicate submission and require another review if the selection changes. */
      function updateConfirm() {
        // Closing a pending dialog dismisses it; the submitted deletion still runs.
        cancel.textContent = busy ? "Close" : "Cancel";
        cancel.setAttribute("aria-label", busy ? "Close deletion" : "Cancel deletion");
        cancel.title = busy ? "Close dialog; deletion will continue" : "Cancel deletion";
        confirm.textContent = busy ? "Queuing…" : deleteLabel;
        confirm.setAttribute("aria-busy", String(busy));
        confirm.disabled = stale || busy || !deleteCount;
      }
      confirm.className = "chat-danger"; updateConfirm();
      actions.append(cancel, confirm); node.append(progress.element, actions); cancel.focus();

      } finally { busyFeedback?.finish(); }
    }
    /** Detect a removed current conversation and hand fallback navigation to the caller. */
    async function checkCurrent() {
      const id = currentId(); if (!id || isDeleting(id)) return;
      try { await apiJson(`/api/agent/chats/${encodeURIComponent(id)}`, {method: "HEAD"}); }
      catch (error) { if (error.status === 404 && id === currentId() && !isDeleting(id)) await deletedCurrent(id); }
    }
    search.addEventListener("input", () => {
      searchFeedback?.dispose();
      searchFeedback = window.SMTOBusy?.begin({host: list, label: "Loading conversations…", key: "search", replace: true});
      // Invalidate in-flight old-query responses immediately, before debounce expires.
      generation++; searchController?.abort(); cancelSelection(); clearTimeout(timer); timer = setTimeout(changeFilters, 200);
      if (sort.value === "recent" && search.value.trim()) sort.value = "best_match";
      else if (!search.value.trim() && sort.value === "best_match") sort.value = "recent";
    });
    $("chat-clear-search").addEventListener("click", () => { search.value = ""; if (sort.value === "best_match") sort.value = "recent"; changeFilters(); search.focus(); });
    sort.addEventListener("change", () => { session.set("conversation_sort", sort.value); changeFilters(); });
    status.addEventListener("change", () => { session.set("conversation_status", status.value); changeFilters(); });
    taskType.addEventListener("change", () => { session.set("conversation_task_type", taskType.value); changeFilters(); });
    pinned.addEventListener("click", () => { pinned.setAttribute("aria-pressed", String(pinned.getAttribute("aria-pressed") !== "true")); session.set("conversation_pinned", pinned.getAttribute("aria-pressed") === "true"); changeFilters(); });
    select.addEventListener("click", () => { selecting = true; select.hidden = true; selectionBar.hidden = false; render(); shown.focus(); });
    $("chat-selection-cancel").addEventListener("click", cancelSelection);
    shown.addEventListener("change", () => { for (const row of visibleRows) { if (blocked(row.conversation_id)) continue; const set = allMatching ? excluded : selected; if (allMatching ? !shown.checked : shown.checked) set.add(row.conversation_id); else set.delete(row.conversation_id); } render(); });
    all.addEventListener("click", () => { allMatching = true; selected.clear(); excluded.clear(); render(); });
    $("chat-delete-selected").addEventListener("click", event => { void deletion(descriptor(), event.currentTarget); });
    more.addEventListener("click", () => { void refresh({append: true, feedback: true}); });
    document.addEventListener("click", event => { if (openMenu && !openMenu.menu.contains(event.target) && event.target !== openMenu.toggle) closeMenu(); });
    list.addEventListener("scroll", () => {
      if (!frame) frame = requestAnimationFrame(() => { frame = 0; render(); });
    }, {passive: true});
    if (window.ResizeObserver) new ResizeObserver(() => render()).observe(list);
    list.addEventListener("keydown", event => {
      if (event.target.closest(".chat-row-menu")) return;
      const item = event.target.closest(".history-item"); if (!item) return;
      const index = rows.findIndex(row => row.conversation_id === item.dataset.conversationId);
      let target = null, last = false;
      if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
        target = event.key === "Home" ? 0 : event.key === "End" ? rows.length - 1 : index + (event.key === "ArrowDown" ? 1 : -1);
      } else if (event.key === "Tab") {
        const controls = [...list.querySelectorAll(".history-item > input:not(:disabled), .history-item > button:not(:disabled), .history-item > a[href]")];
        if (!event.shiftKey && event.target === controls.at(-1) && index < rows.length - 1) target = index + 1;
        if (event.shiftKey && event.target === controls[0] && index > 0) { target = index - 1; last = true; }
      }
      if (target === null) return;
      target = Math.max(0, Math.min(rows.length - 1, target));
      const direction = event.key === "ArrowUp" || event.key === "End" || event.key === "Tab" && event.shiftKey ? -1 : 1;
      while (rows[target] && blocked(rows[target].conversation_id)) target += direction;
      if (!rows[target]) return;
      event.preventDefault();
      list.scrollTop = target * rowHeight(); render();
      const node = [...list.querySelectorAll(".history-item")].find(node => node.dataset.conversationId === rows[target].conversation_id);
      const controls = node?.querySelectorAll(":scope > input:not(:disabled), :scope > button:not(:disabled), :scope > a[href]");
      (last ? controls?.[controls.length - 1] : controls?.[0])?.focus({preventScroll: true});
    });
    window.SMTOUiUpdates.subscribe(["chats.changed", "runs.changed", "tasks.changed", "sync.required"], scheduleRefresh);
    window.addEventListener("smto:conversation-deletion", render);
    return {refresh, refreshIndex, scheduleRefresh, render, closeMenu,
      deleteCurrent(id, opener) {
        if (!id || id !== currentId()) { notify("The conversation changed. Try again."); return; }
        return deletion({conversation_ids: [id]}, opener);
      }};
  }
  window.SMTOConversationManagement = {create};
})();
