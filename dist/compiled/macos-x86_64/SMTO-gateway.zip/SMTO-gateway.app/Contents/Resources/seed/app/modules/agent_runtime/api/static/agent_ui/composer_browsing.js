/* Desktop geometry and submission feedback. Prompt and run state stay with their owners. */
(() => {
  "use strict";
  function create({composer, input, viewport, anchor, protectedWork = () => false, onScroll = () => {}, onResize = () => {}}) {
    const dock = composer.closest("footer");
    const toggle = composer.querySelector("#composer-size-toggle");
    const controlsToggle = composer.querySelector("#composer-controls-toggle");
    const controls = composer.querySelector("#composer-toolbar");
    const submissionStatus = composer.querySelector("#composer-submission-status");
    const session = window.SMTOUiSession;
    const restoredCompact = session?.get("composer_expanded", true) === false;
    let browsing = false, dragging = false, frame = 0;
    let followingUntil = 0, geometry = false, state = restoredCompact ? "compact" : "full";
    let manuallyCompact = restoredCompact, compactWhenIdle = restoredCompact, userScrolling = false, historyNavigation = false;
    let followLayout = false;
    let submission = null, submissionTimer = 0, context = null;
    let fullDockHeight = dock.getBoundingClientRect().height;
    const originalAnchorHeight = anchor.style.height;

    function showControls(expanded) {
      if (!controls || !controlsToggle) return;
      const top = viewport.scrollTop;
      geometry = true;
      if (!expanded && controls.contains(document.activeElement)) controlsToggle.focus({preventScroll: true});
      controls.hidden = !expanded;
      controlsToggle.setAttribute("aria-expanded", String(expanded));
      controlsToggle.title = expanded ? "Hide composer controls" : "Show composer controls";
      viewport.scrollTo({top, behavior: "instant"});
      requestAnimationFrame(() => { geometry = false; });
    }
    controlsToggle?.addEventListener("click", () => {
      const expanded = controls.hidden;
      showControls(expanded);
      session?.set("composer_controls_expanded", expanded);
    });
    showControls(session?.get("composer_controls_expanded", false) ?? false);

    function resetSubmission() {
      clearTimeout(submissionTimer);
      if (submission?.steering) { input.readOnly = false; input.removeAttribute("aria-busy"); }
      submission = null;
      delete composer.dataset.submissionState;
      submissionStatus.textContent = "";
    }

    function protectedState() {
      return Boolean(input.value.length || (composer.contains(document.activeElement) && document.activeElement !== toggle) || dragging
        || composer.hidden || dock.classList.contains("oauth-mode") || protectedWork()
        || [...composer.querySelectorAll('details[open], [aria-expanded="true"]:not(#composer-size-toggle), [aria-invalid="true"]')]
          .some(control => control.getClientRects().length)
        || composer.querySelector('#mention-palette:not([hidden]), #slash-command-palette:not([hidden])')
        || document.querySelector('dialog[open]'));
    }
    function present(compact) {
      composer.dataset.browsingState = state;
      toggle.setAttribute("aria-expanded", String(!compact));
      toggle.setAttribute("aria-label", compact ? "Maximize prompt" : "Minimize prompt");
      toggle.title = compact ? "Maximize prompt" : "Minimize prompt";
      composer.classList.toggle("composer-compact", compact);
      onResize();
    }
    function apply(next) {
      if (next === state) return;
      const compact = next === "compact", wasCompact = state === "compact";
      state = next;
      if (compact) compactWhenIdle = true;
      if (compact === wasCompact) return;
      const top = viewport.scrollTop;
      geometry = true;
      // Reserve the recovered footer height at the existing bottom anchor before
      // growing the viewport. This prevents clamping near the old scroll limit.
      if (compact) {
        fullDockHeight = dock.getBoundingClientRect().height;
        anchor.style.height = `${fullDockHeight}px`;
      }
      present(compact);
      session?.set("composer_expanded", !compact);
      anchor.style.height = compact
        ? `${Math.max(0, fullDockHeight - dock.getBoundingClientRect().height)}px`
        : originalAnchorHeight;
      viewport.scrollTo({top, behavior: "instant"});
      requestAnimationFrame(() => { geometry = false; });
    }
    function update() {
      frame = 0;
      if (!viewport.clientHeight) browsing = false;
      // Returning to the latest message resumes following without reopening the prompt.
      apply(submission?.steering || manuallyCompact ? "compact" : (!browsing && !compactWhenIdle) || protectedState() ? "full" : "compact");
    }
    function refresh() {
      if (!frame) frame = requestAnimationFrame(update);
    }
    function scrolled() {
      onScroll();
      if (geometry || followLayout || performance.now() < followingUntil) return;
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const distance = viewport.scrollHeight - viewport.clientHeight - viewport.scrollTop;
        if (distance > 120) browsing = true;
        else if (distance < 40) browsing = false;
        // Wheel/touch scrolling does not move keyboard focus. Release an empty
        // editor only after the user actually scrolls into conversation history.
        if (browsing && userScrolling && document.activeElement === input && !input.value.length) input.blur();
        update();
      });
    }
    function userScroll(event) {
      if (event.type === "keydown" && (!["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(event.key)
        || event.target.closest('input, textarea, select, [contenteditable="true"]'))) return;
      if (followingUntil > performance.now()) viewport.scrollTo({top: viewport.scrollTop, behavior: "instant"});
      followingUntil = 0;
      followLayout = false;
      historyNavigation = false;
      userScrolling = true;
    }
    viewport.addEventListener("scroll", scrolled, {passive: true});
    viewport.addEventListener("wheel", userScroll, {passive: true});
    viewport.addEventListener("touchstart", userScroll, {passive: true});
    viewport.addEventListener("pointerdown", userScroll, {passive: true});
    viewport.addEventListener("keydown", userScroll);
    composer.addEventListener("pointerdown", event => {
      if (submission?.steering) event.preventDefault();
    });
    toggle.addEventListener("click", () => {
      if (submission?.steering) return;
      manuallyCompact = state !== "compact";
      if (manuallyCompact) toggle.focus({preventScroll: true});
      else {
        compactWhenIdle = false;
        apply("full");
        input.focus({preventScroll: true});
      }
      update();
    });
    // Editing and keyboard focus keep the current size, including after automatic minimization.
    composer.addEventListener("focusin", event => {
      if (submission?.steering) return;
      if (event.target !== toggle) { resetSubmission(); manuallyCompact = state === "compact"; userScrolling = false; }
      update();
    });
    composer.addEventListener("focusout", refresh);
    composer.addEventListener("input", () => { if (submission?.steering) return; resetSubmission(); manuallyCompact = state === "compact"; update(); });
    dock.addEventListener("dragenter", () => { manuallyCompact = false; dragging = true; update(); });
    dock.addEventListener("dragleave", event => {
      if (!dock.contains(event.relatedTarget)) { dragging = false; refresh(); }
    });
    document.addEventListener("drop", () => { dragging = false; refresh(); });
    document.addEventListener("dragend", () => { dragging = false; refresh(); });
    // Menus/palettes, validation and credential UI already publish DOM state.
    const observer = new MutationObserver(records => {
      if (records.some(({target}) => dock.contains(target) || target.matches?.("dialog, #toast"))) refresh();
    });
    observer.observe(document.body, {subtree: true, childList: true, attributes: true,
      attributeFilter: ["hidden", "open", "aria-expanded", "aria-invalid"]});
    const resize = new ResizeObserver(() => {
      refresh();
      // Accepted prompts can reveal queue controls after the initial scroll.
      // Keep the continuation visible through that resize until the user browses away.
      if (followLayout && !document.hidden) viewport.scrollTo({top: viewport.scrollHeight, behavior: "instant"});
    });
    resize.observe(viewport);
    present(restoredCompact);
    return {refresh, isCompact: () => state === "compact", isFollowing: () => !browsing && !historyNavigation,
      holdPosition() {
        followingUntil = 0; followLayout = false; historyNavigation = true;
        viewport.scrollTo({top: viewport.scrollTop, behavior: "instant"});
      },
      setContext(next) {
        if (context !== next) { resetSubmission(); context = next; }
      },
      beginSubmission({steering = false} = {}) {
        resetSubmission();
        submission = {steering};
        if (steering) { input.readOnly = true; input.setAttribute("aria-busy", "true"); }
        composer.dataset.submissionState = "pending";
        submissionStatus.innerHTML = `<svg class="composer-submission-progress" viewBox="0 0 24 12" aria-hidden="true" focusable="false">
          <path d="M-12 6q3-6 6 0t6 0t6 0t6 0t6 0t6 0t6 0t6 0" />
        </svg><span>processing request ...</span>`;
        if (steering) submissionStatus.innerHTML = window.SMTOInlineSteer.progressMarkup;
        manuallyCompact = true;
        if (composer.contains(document.activeElement)) toggle.focus({preventScroll: true});
        update();
        return submission;
      },
      steeringProgress(token, message) {
        if (token === submission) submissionStatus.querySelector("span").textContent = message;
      },
      finishSubmission(token, accepted) {
        if (token !== submission) return;
        const steering = submission.steering;
        if (steering) { input.readOnly = false; input.removeAttribute("aria-busy"); submission.steering = false; }
        if (accepted) {
          composer.dataset.submissionState = "accepted";
          submissionStatus.innerHTML = `${steering ? "Steered" : "Accepted"} <span data-ui-symbol="check">✓</span>`;
          submissionTimer = setTimeout(resetSubmission, 1500);
        } else {
          resetSubmission();
          manuallyCompact = false;
          compactWhenIdle = false;
          apply("full");
          if (composer.contains(document.activeElement) && !composer.hidden) input.focus({preventScroll: true});
          update();
        }
      },
      navigateToTurn(anchor) {
        if (!anchor?.isConnected) return false;
        followingUntil = 0;
        followLayout = false;
        historyNavigation = true;
        browsing = true;
        // Update composer geometry before jumping and hold follow even near the bottom.
        update();
        return window.SMTOConversationNavigatorCore.scrollToTurn(anchor);
      },
      scrollToBottom(behavior = "smooth", force = false) {
      if (document.hidden || ((browsing || historyNavigation) && !force)) return;
      historyNavigation = false;
      browsing = false;
      userScrolling = false;
      if (force) followLayout = true;
      update();
      followingUntil = performance.now() + (behavior === "smooth" ? 600 : 50);
      viewport.scrollTo({top: viewport.scrollHeight, behavior});
    }};
  }
  window.SMTOComposerBrowsing = {create};
})();
