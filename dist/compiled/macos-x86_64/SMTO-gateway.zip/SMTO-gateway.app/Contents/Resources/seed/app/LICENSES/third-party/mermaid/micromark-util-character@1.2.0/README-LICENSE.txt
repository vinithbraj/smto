
[MIT][license] © [Titus Wormer][author]

<!-- Definitions -->

[build-badge]: https://github.com/micromark/micromark/workflows/main/badge.svg

[build]: https://github.com/micromark/micromark/actions

[coverage-badge]: https://img.shields.io/codecov/c/github/micromark/micromark.svg

[coverage]: https://codecov.io/github/micromark/micromark

[downloads-badge]: https://img.shields.io/npm/dm/micromark-util-character.svg

[downloads]: https://www.npmjs.com/package/micromark-util-character

[bundle-size-badge]: https://img.shields.io/badge/dynamic/json?label=minzipped%20size&query=$.size.compressedSize&url=https://deno.bundlejs.com/?q=micromark-util-character

[bundle-size]: https://bundlejs.com/?q=micromark-util-character

[sponsors-badge]: https://opencollective.com/unified/sponsors/badge.svg

[backers-badge]: https://opencollective.com/unified/backers/badge.svg

[opencollective]: https://opencollective.com/unified

[npm]: https://docs.npmjs.com/cli/install

[esm]: https://gist.github.com/sindresorhus/a39789f98801d908bbc7ff3ecc99d99c

[esmsh]: https://esm.sh

[chat-badge]: https://img.shields.io/badge/chat-discussions-success.svg

[chat]: https://github.com/micromark/micromark/discussions

[license]: https://github.com/micromark/micromark/blob/main/license

[author]: https://wooorm.com

[health]: https://github.com/micromark/.github

[securitymd]: https://github.com/micromark/.github/blob/main/security.md

[contributing]: https://github.com/micromark/.github/blob/main/contributing.md

[support]: https://github.com/micromark/.github/blob/main/support.md

[coc]: https://github.com/micromark/.github/blob/main/code-of-conduct.md

[typescript]: https://www.typescriptlang.org

[micromark]: https://github.com/micromark/micromark

[code]: https://github.com/micromark/micromark#preprocess

[api-ascii-alpha]: #asciialphacode

[api-ascii-alphanumeric]: #asciialphanumericcode

[api-ascii-atext]: #asciiatextcode

[api-ascii-control]: #asciicontrolcode

[api-ascii-digit]: #asciidigitcode

[api-ascii-hex-digit]: #asciihexdigitcode

[api-ascii-punctuation]: #asciipunctuationcode

[api-markdown-line-ending]: #markdownlineendingcode

[api-markdown-line-ending-or-space]: #markdownlineendingorspacecode

[api-markdown-space]: #markdownspacecode

[api-unicode-punctuation]: #unicodepunctuationcode

[api-unicode-whitespace]: #unicodewhitespacecode
