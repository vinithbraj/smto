---
id: workflow-recorder
title: Workflows — saved requests
kind: manual
tags: [workflows, recipes, schedules, automation]
order: 44
---
# Workflows — saved requests

A Workflow saves an exact prompt and its execution settings. **Run now** starts a
fresh Agent task, including normal model reasoning and tool use. Each run has its
own conversation and history. Identical inputs do not guarantee identical output.

Choose **Save to workflow** beside a user prompt, including a historical,
text-only or failed request. You can also save an unsent composer draft without
sending or clearing it. On mobile, use **Conversation options → Save draft to
workflow**. Open **More options → Workflows**, the Directory, or `/workflows` to
search, sort, create, edit, run, schedule, view history or delete saved Workflows.

## Choose what to save

The editor shows the name, exact editable prompt, execution settings, and three
independent context switches. All three start off:

| Switch | Material copied |
| --- | --- |
| Prior chat messages | Earlier user messages and assistant answers |
| Attached inputs | Files and attached context available to that request |
| Previous tool results | Earlier result bodies, tool identities and timestamps |

Counts, byte sizes and previews help you choose. Earlier context stops before the
selected request: its answer, its tool results and subsequent turns are excluded.
The prompt is always saved separately, with its own byte count in the editor.
A first request with no attachments can therefore show zero optional context,
even after a successful run. Unavailable context is labeled separately from empty
context; zero optional bytes does not mean the Workflow has no saved prompt.
The categories remain independent. A previous tool result is reference material,
not proof that a new run has already completed an action.

Selected content is copied into immutable Workflow-owned assets, with checksums.
Deleting the original conversation does not delete these copies. Large documents
are available through normal context-reading tools. Missing content, integrity
failures or storage limits prevent the save instead of silently truncating it.
A definition supports up to 16 context documents, each at most 64 MiB; prior-result
extraction also observes the receipt store's bounded extraction limits. Turning a
category on later requires either its retained owned snapshot or its source data.

## Saved execution settings

The Workflow retains the selected Gateway or Gateway group, working directory,
model endpoint and model, generation settings, budgets, behavior, capabilities,
permission policy and runtime controls. Review these under **Execution settings**;
advanced saved settings are available as JSON. Ordinary parameter values are
snapshotted. Credentials remain references handled by existing authentication.
Raw credentials are rejected rather than retained in a Workflow.

Historical requests without complete settings require you to explicitly choose
and review current settings in the editor. Global defaults changed after saving
never replace the saved definition. An unavailable Gateway, model or configuration
must be repaired; the system does not select a substitute.

Execution-affecting edits create a revision. Accepted tasks keep their original
revision. **Schedule** uses the existing schedule editor and pins the reviewed
revision, so later edits do not change that schedule. Deleting a Workflow hides it
from the library while preserving revisions needed by existing runs and schedules.

## Running and reviewing

**Run now** uses saved values directly. Retries of the same submission are
idempotent, and one Workflow cannot have overlapping open manual/scheduled runs.
Normal queue admission, cancellation, pause/resume, recovery, permissions and live
Gateway/account authorization still apply. Saving a Workflow does not save past
approvals, browser sessions or completed-step markers.

**History** shows execution status, revision and a link to the run. Inspect any
required interaction or error there. Saved permission settings do not remove
mandatory interactions. Workflows use the normal Agent task lifecycle and do not
replay a recorded sequence of steps.

## API and appearance

The native Recipe skill and `/api/agent/recipes` namespace use `saved_request_v1`.
Capture identifies a source request and inclusion choices; the server extracts
its settings and copies selected content. Edits require `expected_revision`.
Execution requires `recipe_revision` and an `idempotency_key` and does not accept
replacement runtime context. No conversion of old recorded-step workflows is
performed.

Workflows uses the Schedules layout and shared application fields, switches and
dialogs. Appearance preferences, custom fonts, scaling, contrast, light/dark,
automatic day/night and System appearance are shared with the rest of the app.
