---
id: slack
title: Slack
kind: manual
tags: [manual, slack, oauth, integrations, artifacts]
order: 31
---
# Slack

The `slack` skill performs live workspace operations. Enable Slack in the existing
Skills capability policy. Slack owns messages, conversations and files. The skill
has no workspace mirror, index, crawler, background listener or helper model.
The main Agent interprets requests and summarizes the bounded results.

## Configure and connect

In Parameter Store, select **Slack OAuth App**, fill in the app's client ID and
private client secret, select scopes, and save as (for example) `slack_app`.
The template requests no scopes by default: explicitly choose the minimum needed.
Register the exact callback with your Slack app:

```text
https://your-controller/api/agent/slack/oauth/callback
```

Slack requires HTTPS for registered callbacks. Desktop installations therefore
need a trusted HTTPS route to their existing controller. An HTTP loopback callback
is not offered. The controller's request origin must match the registered URL.
See [Slack's installation guidance](https://docs.slack.dev/authentication/installing-with-oauth/).

Choose `flow: "user"` for personal channel/DM access and search. Set
`requested_user_scopes`, leaving `requested_bot_scopes` empty. This uses
`oauth/v2_user/authorize` and `oauth.v2.user.access`, including S256 PKCE.
Choose `flow: "workspace"` for a bot, set `requested_bot_scopes`, and add user scopes
only if needed. That flow uses `oauth/v2/authorize` and `oauth.v2.access`; it does
not assume that endpoint supports PKCE. Both flows use expiring single-use state,
private launch tickets and confidential client authentication.
[User-only endpoint](https://docs.slack.dev/reference/methods/oauth.v2.user.access/),
[workspace endpoint](https://docs.slack.dev/reference/methods/oauth.v2.access/).

Ask the Agent to connect using the exact saved app:

```json
{"auth_app_ref":"slack_app","workspace_key":"work_slack"}
```

`slack.connect` is in the `connection` section. Open its same-origin authorization
link and approve the selected scopes. Tokens are saved only in private Parameter
Store fields. OAuth and `auth.test` must agree on the team, user ID and principal
type; token prefixes are never identity evidence. Enterprise-wide installations
without an exact team identity are rejected.

A `slack_workspace` profile represents one exact team and one principal. Bot and
optional user grants are separate profiles, with their own actual scopes and
rotation tokens. `slack.workspaces` lists safe identity and capability metadata.
Use the returned `workspace_ref`, not the workspace display name. Omission works
only for one accepted or uniquely connected profile. Several profiles require an
explicit choice, even if just one has the scope for the proposed operation.

`connection_status` reports local grants without probing Slack. `disconnect`
clears local tokens and scopes; it does not uninstall the app or revoke remote
Slack consent. Reconnect with the same profile key to preserve identity. A changed
team or principal requires a new key.

When enabled by the Slack app, expiring tokens are refreshed after the model
boundary. A durable reauthorization fence is written before consuming a refresh
token. Interrupted refreshes require fresh consent rather than retrying a
potentially consumed token. Successful refreshes persist the replacement tokens
with app/profile revision checks. Non-rotating tokens have no invented expiry.
[Slack token rotation](https://docs.slack.dev/authentication/using-token-rotation/).

## Tools and scopes

All tool names below have the `slack.` prefix. The five entry tools are
`workspaces`, `connection_status`, `conversations`, `history`, and `thread`.
Discover the eight sections for additional tools.

| Section | Tools | Actual required scopes |
| --- | --- | --- |
| `connection` | `workspaces`, `connect`, `connection_status`, `disconnect` | Local lifecycle; consent requests only configured scopes |
| `conversations.read` | `conversations`, `conversation`, `members` | `channels:read`, `groups:read`, `im:read`, `mpim:read`, according to conversation kind |
| `messages.read` | `history`, `thread`, `message` | `channels:history`, `groups:history`, `im:history`, `mpim:history`, according to conversation kind |
| `messages.write` | `post_message`, `reply`, `update_message`, `delete_message` | `chat:write` |
| `reactions` | `reactions`, `add_reaction`, `remove_reaction` | `reactions:read` or `reactions:write` |
| `files` | `files`, `file_info`, `download_file`, `upload_file` | `files:read` or `files:write` |
| `users` | `users`, `user` | `users:read`; email is projected only with `users:read.email` |
| `search` | `search_messages` | User principal with `search:read` |

A bot can optionally request `chat:write.public` to post to public channels where
it is not a member. It is never requested automatically. Availability describes
local grants; Slack still decides access to each resource. The skill never changes
membership or substitutes a different principal to gain access.

Provider references verified during implementation (2026-10-01):
[conversations](https://docs.slack.dev/apis/web-api/using-the-conversations-api/),
[thread scopes](https://docs.slack.dev/reference/methods/conversations.replies/),
[posting](https://docs.slack.dev/reference/methods/chat.postMessage/),
[editing](https://docs.slack.dev/reference/methods/chat.update/),
[search](https://docs.slack.dev/reference/methods/search.messages/),
[presence](https://docs.slack.dev/reference/methods/users.getPresence/),
[files](https://docs.slack.dev/reference/methods/files.list/).

## Read and search

Conversations normalize to `public_channel`, `private_channel`, `im` and `mpim`.
`membership: "joined"` uses the selected principal's conversations. Other listing
uses accessible conversations. All listing is one bounded page; continuation
handles are private, expire after 15 minutes and are bound to identity and filters.
History and thread reads return at most **15 messages** per call, even when a
higher limit is requested. Other cursor lists return at most 100. `files` uses
explicit bounded page numbers, with a maximum of 100 pages per query.

To summarize 50 messages, the main Agent must follow pages until it has enough
messages or reaches the provider's boundary. Rate limits may require waiting.
`oldest` and `latest` are exact Slack timestamp strings, preserving fractional
precision. To read an exact reply, provide both its `ts` and its parent `thread_ts`.
Conversation metadata may include a provider `last_read`; the skill does not
invent unread status or mark anything read.

`search_messages` uses Slack's query syntax, for example
`from:alex after:2026-09-24 in:platform`. A bot or missing search scope produces a
precise failure. No channel crawl replaces unavailable search.

Text is capped at 8,000 characters per returned message. Blocks are summarized
structurally (up to ten), with bounded attachments, file references and reactions.
Raw event payloads, transfer URLs and file bytes are not normal JSON results.
User presence is fetched only with `include_presence: true`. Email requires its
separate grant. Provider text, profiles, links and filenames remain untrusted data.

## Writes and uncertain results

Posting requires exact `channel_id`; replies also require parent `thread_ts`.
Updates and deletions require exact `channel_id + ts`. Names and matching text
cannot authorize mutation. Post/reply text is at most 4,000 characters. Optional
blocks support at most ten section/divider blocks, with bounded plain-text or
mrkdwn text. Arbitrary payload fields, buttons and remote images are rejected.
Post/reply supports `mrkdwn`; update uses Slack's documented `parse` behavior.
Link and media unfurling are disabled on new messages.

Every write uses existing native confirmation. Message deletion additionally uses
the existing unsafe-action policy for external data deletion. There is no separate
Slack approval dialog. Public posting receives ordinary external-write approval;
this version does not infer channel size or add a public-channel threshold.

Posts/replies include an operation-stable `client_msg_id`. Slack's method docs
mention duplicate-related errors, but do not supply a general exactly-once
transport guarantee. SMTO therefore never blindly repeats a write.
After a lost post response, one bounded history/thread read can recognize the
exact client ID and sender. A matching text alone is never enough. Reactions use
ensure-present/ensure-absent semantics; already-present/absent errors are successful
no-ops. Reconciliation never interprets a truncated reaction actor list as absence.

A transport failure, uncertain provider error, malformed write response or
cancellation after dispatch yields `slack.mutation_outcome_unknown` unless an exact
read proves the desired state. Native receipts preserve `effect_unknown` and
`remote_effect_possible`, preventing automatic replay. Update/delete and ambiguous
file completion remain unknown for manual inspection; no second mutation is sent.

## Rate limits and files

Slack 429 responses retain their `Retry-After` per app/workspace/method. Reads get
at most three attempts. Delays up to 30 seconds are cancellable; longer delays
return `slack.rate_limited` with the full required wait. The delay also gates later
calls in the same controller process. Writes are never retried, including after
known rate-limit rejection. Restarting the controller clears transient rate-limit
and cursor state. [Slack rate limits](https://docs.slack.dev/apis/web-api/rate-limits/).

Both transfer directions are capped at **25 MiB**. Upload sources must be existing
conversation-owned `artifact://` or `artifact-workspace://` references; arbitrary
host paths are rejected. Source size/hash are verified before any provider write.
The current workflow is `files.getUploadURLExternal`, one binary upload, then
`files.completeUploadExternal` with exact channel/thread IDs. It never invokes the
retired `files.upload` endpoint or public-link sharing.
[Allocation](https://docs.slack.dev/reference/methods/files.getUploadURLExternal/),
[completion](https://docs.slack.dev/reference/methods/files.completeUploadExternal/).

Downloads stream to sensitive run artifacts with sanitized filenames, measured
byte bounds and size verification. URLs must be provider-returned HTTPS Slack file
origins; redirects and unsupported hosts fail closed. Bearer authorization goes
only to authenticated download hosts, never to external upload URLs. Incomplete
transfers do not publish partial artifacts. Uncertain completion preserves the
allocated `file_id` for inspection.

## Diagnostics and limits

Canonical `slack.*` errors distinguish configuration, identity, scopes, membership,
exact-target failures, throttling, file limits, cancellation and unknown effects,
with remediation in the shared error catalog. Parameter projections always omit
access/refresh tokens and client secrets, including with optional redaction off.
Tool outputs scrub credential reflections. Existing content-minimization controls
omit message bodies and provider content from diagnostics and portable history.
OAuth callback query logs and private HTTP diagnostics are suppressed.

The implementation makes **zero helper LLM calls**. No administration, provisioning,
retention changes, channel archive/delete, membership mutations, Socket Mode or
background ingestion are included. Mandatory tests use a fake Slack provider;
no live workspace validation is claimed. GovSlack and enterprise-wide grants
without an exact workspace are not supported in this version.
