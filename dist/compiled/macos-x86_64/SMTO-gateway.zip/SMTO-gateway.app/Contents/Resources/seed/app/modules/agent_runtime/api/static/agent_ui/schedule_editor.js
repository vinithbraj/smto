/* Shared deterministic editor for Schedules and Agent prompt actions. */
(() => {
  "use strict";
  const time = window.SMTOScheduleTime, recurrence = window.SMTOScheduleRecurrence;
  async function api(path, method = "GET", body) {
    const response = await window.SMTOErrors.fetch(`/api/agent/events${path}`, {method, headers: {"Content-Type": "application/json"}, ...(body === undefined ? {} : {body: JSON.stringify(body)})});
    let data;
    try { data = await window.SMTOErrors.readJson(response); } catch (_) { throw window.SMTOErrors.error("ui_response_invalid"); }
    if (!response.ok) {
      if (data.detail?.error_kind === "eula_acceptance_required") window.dispatchEvent(new Event("smto:eula-required"));
      throw window.SMTOErrors.fromPayload(data, response.status);
    }
    return data;
  }
  function create({onSaved = () => {}, enabled = () => true} = {}) {
    const dialog = document.createElement("dialog");
    dialog.id = "schedule-editor";
    dialog.setAttribute("aria-labelledby", "editor-title");
    dialog.setAttribute("aria-describedby", "execution-note");
    // This template contains only source-owned markup. Prompt and server data use value/textContent.
    dialog.innerHTML = `<form id="schedule-form">
      <div class="dialog-heading"><div><h2 id="editor-title">Schedule prompt</h2><p id="editor-meta" class="hint"></p></div><button class="close-button" type="button" data-close="schedule-editor" aria-label="Close editor" data-ui-symbol="cross">×</button></div>
      <div class="form-content">
        <label><span id="instruction-label">Prompt</span><textarea id="edit-prompt" required maxlength="24000" rows="3"></textarea></label>
        <label>Name<input id="edit-title" required maxlength="160" autocomplete="off"></label>
        <label id="action-field">Type<select id="edit-action"><option value="agent_prompt">Run Agent</option><option value="notification">Reminder only</option></select></label>
        <label>Repeat<select id="edit-repeat"><option value="once">Does not repeat</option><option value="daily">Daily</option><option value="weekdays">Weekdays</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="yearly">Yearly</option><option value="interval">Interval · every X</option></select></label>
        <div id="interval-fields" class="form-columns"><label>Every<input id="edit-interval" type="number" min="1" step="1" value="1"></label><label>Unit<select id="edit-unit"><option value="60">minutes</option><option value="3600">hours</option><option value="86400">days</option><option value="1">seconds</option></select></label></div>
        <label id="interval-start-field" class="choice"><input id="edit-explicit-start" class="mission-switch" type="checkbox" role="switch">Choose the first run time</label>
        <div id="once-fields" class="form-columns"><label>Starts<input id="edit-date" type="date"></label><label>At<input id="edit-once-time" type="time" step="1"></label></div>
        <div id="calendar-fields" class="form-columns"><label>Starts<input id="edit-start-date" type="date"></label><label>At<input id="edit-time" type="time" value="09:00"></label></div>
        <label id="every-field" class="every-field">Every <input id="edit-every" type="number" min="1" max="1000" value="1"> <span id="every-unit">days</span></label>
        <fieldset id="weekday-fields"><legend>On these days</legend><div class="weekday-options">${recurrence.days.map((day, i) => `<label><input type="checkbox" name="weekday" value="${i}"><span>${day}</span></label>`).join("")}</div></fieldset>
        <fieldset id="pattern-fields"><legend>Pattern</legend><div class="pattern-options"><label class="choice"><input type="radio" name="pattern" value="absolute" checked>Day of month</label><label class="choice"><input type="radio" name="pattern" value="relative">Relative weekday</label></div></fieldset>
        <div id="month-pattern" class="form-columns"><label id="month-field">Month<select id="edit-month">${recurrence.months.map((m, i) => `<option value="${i + 1}">${m}</option>`).join("")}</select></label><label id="day-field">Day<input id="edit-day" type="number" min="1" max="31" value="1"></label></div>
        <div id="relative-fields" class="form-columns"><label>The<select id="edit-week-index">${["first", "second", "third", "fourth", "last"].map(i => `<option value="${i}">${i[0].toUpperCase() + i.slice(1)}</option>`).join("")}</select></label><label>Weekday<select id="edit-weekday">${recurrence.days.map((d, i) => `<option value="${i}">${d}</option>`).join("")}</select></label></div>
        <fieldset id="range-fields"><legend>Ends</legend><div class="range-options">
          <label class="choice"><input type="radio" name="range" value="no_end" checked>Never</label>
          <div class="range-row"><label class="choice"><input type="radio" name="range" value="end_date">On date</label><input id="edit-end-date" type="date" aria-label="End date"></div>
          <div class="range-row"><label class="choice"><input type="radio" name="range" value="numbered">After</label><input id="edit-count" type="number" min="1" max="10000" value="10" aria-label="Number of occurrences"><span>occurrences</span></div>
        </div></fieldset>
        <p id="recurrence-summary" class="recurrence-summary" aria-live="polite"></p>
        <label>Time zone<input id="edit-timezone" list="timezone-options" required maxlength="80" autocomplete="off"></label><datalist id="timezone-options"></datalist>
        <p id="timing-note" class="hint"></p>
        <p id="execution-note" class="execution-note">Runs as a standalone Agent task. Conversation history and temporary attachments are not included.</p>
        <p id="permissions-note" class="hint">Your permission settings are saved when you create a schedule and used for every run. Changing global permissions later does not update existing schedules.</p>
        <p id="execution-scope" class="hint" hidden></p>
        <a id="open-in-schedules" hidden>Open in Schedules</a>
        <p id="editor-error" class="error-text" role="alert" hidden></p><a id="editor-settings" href="/settings" hidden>Open Mission Control</a>
      </div>
      <footer class="dialog-footer"><button id="resume-schedule" type="button" hidden>Resume</button><button type="button" data-close="schedule-editor">Cancel</button><button id="save-schedule" class="primary" type="submit">Create schedule</button></footer>
    </form>`;
    document.body.append(dialog);
    const $ = id => dialog.querySelector(`#${id}`), form = $("schedule-form");
    let editing = null, original = null, promptSource = null, saving = false, focusReturn = null;
    const error = text => { $("editor-error").textContent = text; $("editor-error").hidden = !text; $("editor-settings").hidden = !/disabled|Gateway/.test(text); if (text && dialog.open) $("editor-error").scrollIntoView({block: "nearest"}); };
    const radio = name => dialog.querySelector(`[name="${name}"]:checked`)?.value;
    function readForm() {
      const v = {};
      for (const [key, id] of Object.entries({title: "title", prompt: "prompt", action: "action", repeat: "repeat", date: "date", onceTime: "once-time", interval: "interval", unit: "unit", time: "time", timezone: "timezone", startDate: "start-date", every: "every", day: "day", month: "month", weekIndex: "week-index", weekday: "weekday", endDate: "end-date", count: "count"})) v[key] = $(`edit-${id}`).value;
      v.title = v.title.trim(); v.timezone = v.timezone.trim();
      v.weekdays = [...dialog.querySelectorAll('[name="weekday"]:checked')].map(input => Number(input.value));
      v.pattern = radio("pattern"); v.range = radio("range"); v.explicitStart = $("edit-explicit-start").checked;
      return v;
    }
    function payload() {
      const v = readForm(), timing = recurrence.timingPayload(v);
      if (!editing) return {title: v.title, prompt: promptSource?.prompt ?? v.prompt, ...(!promptSource ? {action_type: v.action} : {source_request_id: promptSource.requestId || "", task_contract_integrity_guard_enabled: promptSource.task_contract_integrity_guard_enabled}), ...(promptSource?.execution ? {gateway_id: promptSource.execution.gateway_id, gateway_selection: promptSource.execution.gateway_selection} : {}), ...timing};
      const patch = {}, oldTiming = recurrence.timingPayload(original);
      for (const key of ["title", "prompt"]) if (v[key] !== original[key]) patch[key] = v[key];
      for (const [key, value] of Object.entries(timing)) if (JSON.stringify(value) !== JSON.stringify(oldTiming[key])) patch[key] = value;
      if (timing.schedule_type !== oldTiming.schedule_type) Object.assign(patch, timing);
      return patch;
    }
    function updateSave() { $("save-schedule").disabled = saving || !enabled() || Boolean(editing && !Object.keys(payload()).length); }
    function show(id, visible) {
      $(id).hidden = !visible;
      $(id).querySelectorAll("input, select").forEach(input => { input.disabled = !visible; input.required = visible && !["checkbox", "radio"].includes(input.type); });
    }
    function updateFields() {
      const v = readForm(), calendar = !["once", "interval"].includes(v.repeat), patterned = ["monthly", "yearly"].includes(v.repeat);
      show("interval-fields", v.repeat === "interval");
      show("interval-start-field", v.repeat === "interval");
      show("once-fields", v.repeat === "once" || v.repeat === "interval" && v.explicitStart);
      show("calendar-fields", calendar); show("every-field", calendar && v.repeat !== "weekdays");
      show("weekday-fields", v.repeat === "weekly"); show("pattern-fields", patterned);
      show("month-pattern", patterned); show("month-field", v.repeat === "yearly"); show("day-field", patterned && v.pattern === "absolute");
      $("month-pattern").hidden = !patterned || (v.repeat === "monthly" && v.pattern === "relative");
      show("relative-fields", patterned && v.pattern === "relative");
      show("range-fields", calendar);
      for (const [id, visible] of [["edit-end-date", calendar && v.range === "end_date"], ["edit-count", calendar && v.range === "numbered"]]) { $(id).disabled = !visible; $(id).required = visible; }
      $("every-unit").textContent = {daily: "days", weekly: "weeks", monthly: "months", yearly: "years"}[v.repeat] || "weeks";
      $("instruction-label").textContent = promptSource ? "Prompt" : v.action === "notification" ? "Reminder text" : "Instruction";
      $("permissions-note").hidden = v.action === "notification";
      dialog.setAttribute("aria-describedby", v.action === "notification" ? "execution-note" : "execution-note permissions-note");
      $("execution-note").textContent = v.action === "notification" ? "Delivers this reminder directly at the scheduled time, without starting an Agent task." : "Runs as a standalone Agent task. Conversation history and temporary attachments are not included." + (editing ? " Timing edits preserve the saved execution scope." : promptSource?.execution ? " Uses the captured composer Gateways and default model, permissions and behavior." : " Uses the default Gateway, model, permissions and behavior.");
      $("recurrence-summary").textContent = calendar ? `${recurrence.recurrenceText(recurrence.timingPayload(v))} · starting ${time.dateLabel(v.startDate)}` : v.repeat === "interval" ? recurrence.recurrenceText(recurrence.timingPayload(v)) : `Once · ${time.dateLabel(v.date)} at ${time.wallTime(v.onceTime.slice(0, 5))}`;
      $("timing-note").textContent = `${v.timezone === time.browserZone() ? `Local time · ${time.browserZone()}` : `Series timezone: ${v.timezone}. Next occurrence is shown in ${time.browserZone()}.`}${v.repeat === "interval" ? " Intervals measure elapsed time. Without an explicit start, the saved next trigger is retained, or the first run follows one interval." : " Local times are checked for daylight saving transitions."}`;
      updateSave();
    }
    function open(event = null, source = null) {
      focusReturn = dialog.open ? focusReturn : document.activeElement;
      editing = event ? structuredClone(event) : null; promptSource = source;
      form.reset(); error("");
      $("editor-title").textContent = source ? event ? "Edit scheduled prompt" : "Schedule prompt" : event ? "Edit Schedule" : "New Schedule";
      $("editor-meta").textContent = event ? `${event.status[0].toUpperCase() + event.status.slice(1)}${event.next_run_at ? ` · Next: ${time.dateText(event.next_run_at)}` : ""}` : "Run automatically at the times below.";
      $("edit-title").value = event?.title || source?.title || "";
      $("edit-prompt").value = event ? event.action_type === "notification" ? event.notification_message || event.prompt : event.prompt : source?.prompt || "";
      $("edit-prompt").readOnly = Boolean(source && !event);
      if (source) $("edit-prompt").closest("label").after($("execution-note"), $("permissions-note"));
      $("action-field").hidden = Boolean(source); $("edit-action").disabled = Boolean(source || event); $("edit-action").value = event?.action_type || "agent_prompt";
      const zone = event?.timezone || time.browserZone(), r = event?.recurrence;
      $("edit-timezone").value = zone;
      const parts = time.dateParts(event?.next_run_at || new Date(Date.now() + 86400000).toISOString(), zone);
      $("edit-date").value = `${parts.year}-${parts.month}-${parts.day}`;
      $("edit-once-time").value = event?.next_run_at ? `${parts.hour}:${parts.minute}:${parts.second}` : "09:00";
      $("edit-start-date").value = r?.start_date || $("edit-date").value;
      $("edit-end-date").value = r?.end_date || $("edit-start-date").value;
      $("edit-count").value = r?.number_of_occurrences || 10;
      $("edit-every").value = r?.interval || 1;
      $("edit-day").value = r?.day_of_month || Number(parts.day); $("edit-month").value = r?.month || Number(parts.month);
      $("edit-week-index").value = r?.week_index || "first"; $("edit-weekday").value = r?.weekday ?? 0;
      dialog.querySelector(`[name="pattern"][value="${r?.frequency.startsWith("relative") ? "relative" : "absolute"}"]`).checked = true;
      dialog.querySelector(`[name="range"][value="${r?.range_type || "no_end"}"]`).checked = true;
      let repeat = event?.schedule_type || (source ? "once" : "daily");
      if (repeat === "calendar") repeat = r.frequency.endsWith("monthly") ? "monthly" : r.frequency.endsWith("yearly") ? "yearly" : r.frequency === "weekly" && (r.interval || 1) === 1 && r.weekdays.join() === "0,1,2,3,4" ? "weekdays" : r.frequency;
      $("edit-repeat").value = repeat; $("edit-time").value = r?.time || "09:00";
      const unit = time.intervalUnit(event?.interval_seconds || 3600);
      $("edit-unit").value = String(unit); $("edit-interval").value = (event?.interval_seconds || 3600) / unit;
      dialog.querySelectorAll('[name="weekday"]').forEach(input => { input.checked = r?.weekdays.includes(Number(input.value)) || false; });
      $("open-in-schedules").hidden = !source || !event;
      $("open-in-schedules").href = event ? `/schedules?event=${encodeURIComponent(event.event_id)}` : "/schedules";
      $("resume-schedule").hidden = !source || event?.status !== "paused";
      const scope = event?.context || source?.execution;
      $("execution-scope").hidden = !scope;
      $("execution-scope").textContent = scope ? [scope.gateway_selection?.gateway_ids.length > 1 ? `Multiple gateways · ${scope.gateway_selection.gateway_ids.length}` : scope.gateway_label || scope.gateway_node || "Captured Gateway", scope.llm_model, scope.native_permission_policy?.mode, scope.native_behavior_policy?.effort].filter(Boolean).join(" · ") : "";
      $("execution-note").textContent = "Runs as a standalone Agent task. Conversation history and temporary attachments are not included." + (event ? " Timing edits preserve the saved execution scope." : " Current runtime defaults are captured at creation.");
      $("save-schedule").textContent = event ? "Save changes" : "Create schedule";
      original = readForm(); updateFields();
      if (!enabled()) error("Scheduling is disabled in Mission Control.");
      if (!dialog.open) dialog.showModal();
      $("edit-title").focus();
    }
    form.addEventListener("input", updateFields); form.addEventListener("change", updateFields);
    async function save(resume = false) {
      if (saving || !enabled()) return;
      const v = readForm();
      if (!v.title || !v.prompt.trim()) { error("Enter a name and instruction."); return; }
      if (v.repeat === "weekly" && !v.weekdays.length) { error("Select at least one weekday."); return; }
      if (v.range === "end_date" && v.endDate < v.startDate && !["once", "interval"].includes(v.repeat)) { error("End date must be on or after the start date."); return; }
      const patch = payload(); if (resume) patch.status = "active";
      if (editing && !Object.keys(patch).length) return;
      saving = true; error(""); updateSave(); $("save-schedule").textContent = "Saving…"; $("resume-schedule").disabled = true;
      const loading = window.SMTOBusy?.begin({host: $("save-schedule"), label: "Saving schedule…"});
      try {
        const result = promptSource?.save ? await promptSource.save(patch) : await api(editing ? `/${encodeURIComponent(editing.event_id)}/manager` : promptSource ? "/prompt-schedule" : "/manager", editing ? "PATCH" : "POST", patch);
        await onSaved(result.event);
        window.dispatchEvent(new CustomEvent("smto:schedule-saved", {detail: {event: result.event, prompt: promptSource?.prompt}}));
        if (result.outcome === "existing") { open(result.event, promptSource); error("This prompt already has a schedule. Showing the existing schedule."); }
        else dialog.close();
      } catch (e) { error(e.message); }
      finally { loading?.finish(); saving = false; $("save-schedule").textContent = editing ? "Save changes" : "Create schedule"; $("resume-schedule").disabled = false; updateSave(); }
    }
    form.addEventListener("submit", e => { e.preventDefault(); void save(); });
    $("resume-schedule").addEventListener("click", () => { if (form.reportValidity()) void save(true); });
    dialog.querySelectorAll("[data-close]").forEach(button => button.addEventListener("click", () => { if (!saving) dialog.close(); }));
    dialog.addEventListener("cancel", e => { if (saving) e.preventDefault(); });
    dialog.addEventListener("close", () => {
      const replacement = editing && focusReturn?.dataset.action
        ? document.querySelector(`[data-event-id="${CSS.escape(editing.event_id)}"] [data-action="${CSS.escape(focusReturn.dataset.action)}"]`) : null;
      const target = focusReturn?.isConnected ? focusReturn : replacement || document.getElementById("new-schedule");
      target?.focus({preventScroll: true});
    });
    dialog.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); if (!saving) dialog.close(); return; }
      if (e.key !== "Tab") return;
      const controls = [...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href]')].filter(n => n.getClientRects().length);
      if (e.shiftKey && document.activeElement === controls[0]) { e.preventDefault(); controls.at(-1)?.focus(); }
      else if (!e.shiftKey && document.activeElement === controls.at(-1)) { e.preventDefault(); controls[0]?.focus(); }
    });
    try { for (const zone of ["UTC", ...Intl.supportedValuesOf("timeZone")]) { const option = document.createElement("option"); option.value = zone; $("timezone-options").append(option); } } catch (_) { /* The text field accepts IANA zones. */ }
    return {open, updateSave};
  }
  window.SMTOScheduleEditor = {create, api};
})();
