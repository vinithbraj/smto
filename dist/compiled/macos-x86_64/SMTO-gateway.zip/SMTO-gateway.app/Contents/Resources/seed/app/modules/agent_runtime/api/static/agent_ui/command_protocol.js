/* Lightweight, presentation-free command contract shared by desktop and mobile. */
(() => {
  "use strict";
  const terminal = new Set(["completed", "answered", "failed", "cancelled", "interrupted"]);
  function availability(command, view = {}) {
    const run = view.snapshot || {}, status = run.status || view.status;
    const active = Boolean(view.request_id && status && !terminal.has(status));
    const rules = {
      always: () => "",
      idle_only: () => active || view.running ? "Restart is unavailable while a task is active." : "",
      conversation_required: () => view.conversation_id ? "" : "No conversation is open.",
      queue_available: () => !view.conversation_id ? "No conversation is open."
        : view.queued_count === 0 ? "The queue is already empty." : "",
      run_required: () => view.request_id ? "" : "No current run trace is available.",
      active_run: () => active ? "" : "No active task to stop.",
      pausable_run: () => run.pause_requested ? "Pause already requested."
        : active && ["running", "waiting_job", "waiting_event"].includes(status) && !run.cancel_requested
          ? "" : "This task cannot be paused in its current state.",
      resumable_run: () => run.resume_allowed ? "" : "This task cannot be resumed in its current state.",
      compactable_run: () => view.request_id && run.compact_allowed === true ? ""
        : "Compaction requires a safe idle call/result boundary.",
    };
    return (rules[command.availability || "always"] || (() => "Command unavailable."))();
  }
  function context(view, surface) {
    return {conversation_id: view.conversation_id || null, request_id: view.request_id || null,
      run_id: view.run_id || view.snapshot?.run_id || null, surface};
  }
  function sameView(a, b) {
    return (a.conversation_id || null) === (b.conversation_id || null)
      && (a.request_id || null) === (b.request_id || null)
      && a.navigation === b.navigation;
  }
  const numeric = n => typeof n === "number" && Number.isFinite(n) && n >= 0;
  function tokenRate(sample, compact = false) {
    if (!numeric(sample?.tokens_per_second) || !numeric(sample.tokens) || !(sample.calls > 0)) return "Not measured yet";
    const rate = `${sample.tokens_per_second.toLocaleString(undefined, {minimumFractionDigits: 1, maximumFractionDigits: 1})} tokens/s`;
    return compact ? rate : rate
      + ` · ${sample.tokens.toLocaleString()} tokens across ${sample.calls.toLocaleString()} ${sample.calls === 1 ? "call" : "calls"}`;
  }
  function statusText(data, now = Date.now()) {
    const usage = data.context || {}, timing = data.timing || {};
    const remaining = numeric(usage.remaining_tokens) ? usage.remaining_tokens : usage.remaining_tokens_estimate;
    const used = numeric(usage.used_tokens) ? usage.used_tokens : usage.used_tokens_estimate;
    const measured = numeric(remaining) && numeric(usage.context_window_tokens) && usage.context_window_tokens > 0;
    const estimated = usage.estimated !== false || !numeric(usage.remaining_tokens) || !numeric(usage.used_tokens);
    const count = n => numeric(n) ? `${estimated ? "≈" : ""}${Math.round(n).toLocaleString()}` : "Not measured yet";
    const end = numeric(timing.ended_at) ? timing.ended_at * 1000 : now;
    const seconds = numeric(timing.started_at) ? Math.max(0, Math.floor((end - timing.started_at * 1000) / 1000)) : null;
    const elapsed = seconds === null ? "—" : `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
    const phase = data.cancel_requested ? "Stopping" : data.pause_requested ? "Pause requested"
      : (data.state || "idle").replaceAll("_", " ").replace(/^./, c => c.toUpperCase());
    return {phase, elapsed, timingLabel: timing.basis === "execution_started" ? "Elapsed" : "Run age",
      memoryRows: data.memory ? [
        ["Memory", data.memory.memory_enabled === undefined ? "No run selected" : data.memory.memory_enabled ? "Enabled" : "Disabled"],
        ["Memory policy", data.memory.policy_source || "Not recorded"],
        ["Saved memories", data.memory.memory_unavailable ? "Unavailable" : data.memory.saved_records ?? "Not measured"],
        ["Memory revision", data.memory.global_revision ?? "Not measured"],
        ["Memory · current run", `${data.memory.context_matches || 0} metadata matches · ${data.memory.memory_reads || 0} explicit reads · ${data.memory.memory_writes || 0} writes · ${data.memory.memory_noop_writes || 0} unchanged`],
        ["Memory learning", `${data.memory.learning_candidates_created || 0} opportunities · ${data.memory.learning_candidates_stored || 0} stored · ${data.memory.memory_review_nudges || 0} reviews`],
        ...[["Last Memory write · this run", data.memory.last_successful_write],
            ["Last Memory retrieval · this run", data.memory.last_explicit_retrieval]].map(([label, receipt]) =>
          [label, receipt ? `${receipt.key} · revision ${receipt.revision} · ${new Date(receipt.timestamp * 1000).toLocaleString()}` : "None recorded"])
      ] : [],
      tokenRows: [["Average output", tokenRate(data.token_throughput?.output)],
        ["Average input", tokenRate(data.token_throughput?.input)],
        ["Averaging basis", "Current run · measured LLM calls · request time"]],
      remaining: measured ? `${count(remaining)} / ${usage.context_window_tokens.toLocaleString()} tokens` : "Not measured yet",
      used: measured ? `${count(used)}${numeric(usage.used_percent) ? ` · ${usage.used_percent.toFixed(1)}%` : ""}` : "Not measured yet",
      measurement: !measured ? "Not measured yet" : estimated ? "Estimated" : usage.source === "provider_usage" ? "Exact · provider usage" : "Exact measurement",
      summary: `${phase} · ${elapsed} · ${measured ? `${count(remaining)} tokens left` : "Context not measured yet"}`
        + ` · Avg output: ${tokenRate(data.token_throughput?.output, true)}`};
  }
  window.SMTOCommandProtocol = {availability, context, sameView, statusText};
})();
