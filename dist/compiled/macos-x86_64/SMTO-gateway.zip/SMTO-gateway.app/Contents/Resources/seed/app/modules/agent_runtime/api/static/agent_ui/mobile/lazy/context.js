import { api, state, node, button, encode } from "../api.js?v=20261018-loading";
import { openSheet, closeSheet } from "../overlays.js?v=20261018-loading";

export async function open(hooks, back = null) {
  const body = openSheet("Attachments and context", {back});
  appendContextActions(body, hooks, () => void open(hooks, back));
}

export function appendContextActions(body, hooks, back) {
  const generation = state.generation;
  const add = async (ref) => {
    if (generation !== state.generation) return;
    if (state.refs.length >= 16)
      throw window.SMTOErrors.error("ui_context_source_limit");
    if (!state.refs.some((r) => r.context_id === ref.context_id))
      state.refs.push(ref);
    hooks.renderComposer();
    await closeSheet();
  };
  const file = node("input");
  file.type = "file";
  file.setAttribute("aria-label", "Attach file");
  file.className = "sr-only";
  const fileLabel = node("label", "Attach file", "file-choice");
  fileLabel.append(file);
  body.append(fileLabel);
  file.onchange = async () => {
 const busyFeedback = window.SMTOBusy?.action("Attaching context…");
 try {
    if (!file.files?.length) return;
    const selected = file.files[0];
    file.disabled = true;
    try {
      if (selected.size > 64 * 1024 * 1024)
        throw window.SMTOErrors.error("ui_attachment_too_large");
      const params = new URLSearchParams({ name: selected.name });
      if (state.conversationId)
        params.set("conversation_id", state.conversationId);
      await add(
        await api(`context/upload?${params}`, {
          method: "POST",
          body: selected,
          headers: {
            "Content-Type": selected.type || "application/octet-stream",
          },
        }),
      );
    } catch (error) {
      body.append(node("p", error.message, "error"));
    } finally {
      file.disabled = false;
    }

 } finally { busyFeedback?.finish(); }
};
  body.append(
    button(
      "Add text or file path as context",
      () => {
        const entry = openSheet("Add context", {
            back,
          }),
          input = node("textarea");
        input.setAttribute("aria-label", "Context text or file path");
        input.rows = 5;
        input.maxLength = 24000;
        entry.append(input);
        entry.append(
          button(
            "Attach context",
            async () => {
 const busyFeedback = window.SMTOBusy?.action("Attaching context…");
 try {
              if (!input.value.trim()) return;
              const params = new URLSearchParams({ name: "context.txt" });
              if (state.conversationId)
                params.set("conversation_id", state.conversationId);
              await add(
                await api(`context/upload?${params}`, {
                  method: "POST",
                  body: new Blob([input.value], { type: "text/plain" }),
                  headers: { "Content-Type": "text/plain" },
                }),
              );

 } finally { busyFeedback?.finish(); }
},
            "primary",
          ),
        );
      },
      "choice",
    ),
  );
  if (state.conversationId)
    for (const [type, title] of [
      ["sources", "Existing context"],
      ["artifacts", "Task artifacts"],
    ])
      body.append(
        button(
          title,
          async () => {
 const busyFeedback = window.SMTOBusy?.action("Attaching context…");
 try {
            const cid = state.conversationId,
              entry = openSheet(title, { back }),
              payload = await api(
                `context/${type}?conversation_id=${encode(cid)}`,
              );
            if (!entry.isConnected) return;
            for (const item of payload[type] || []) {
              entry.append(
                button(
                  item.name || item.title || item.reference || "Context",
                  async () =>
                    { const busyFeedback = window.SMTOBusy?.action("Attaching context…");
 try { return await (add(
                      await api("context/link", {
                        method: "POST",
                        body: {
                          target_conversation_id: cid,
                          source_conversation_id:
                            item.source_conversation_id || item.conversation_id,
                          ...(item.context_id
                            ? { context_id: item.context_id }
                            : {
                                source_run_id: item.run_id,
                                reference: item.reference,
                              }),
                        },
                      }),
                    )); } finally { busyFeedback?.finish(); } },
                  "choice",
                ),
              );
            }
            if (!entry.children.length)
              entry.append(
                node("p", "No saved context is available.", "muted"),
              );

 } finally { busyFeedback?.finish(); }
},
          "choice",
        ),
      );
}
