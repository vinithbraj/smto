/* Public invocation evidence. Fetch on disclosure; never interpret tool data as HTML. */
(() => {
  "use strict";
  const limit = 256 * 1024;
  const node = (tag, className, text) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  };
  const label = value => ({url: "URL", tls: "TLS"})[value]
    || String(value).replace(/_/g, " ").replace(/^./, c => c.toUpperCase());
  const formatted = value => typeof value === "string" ? value : JSON.stringify(value, null, 2);
  const factValue = value => {
    if (Array.isArray(value) && value.every(item => item && "name" in item && "value" in item)) {
      return value.map(item => `${item.name} = ${formatted(item.value)}`).join("\n");
    }
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return Object.entries(value).map(([key, child]) => `${key}: ${formatted(child)}`).join("\n");
    }
    return formatted(value);
  };
  const bytes = value => value >= 1024 ? `${(value / 1024).toFixed(1)} KB` : `${value} bytes`;
  const duration = value => window.SMTOPerformanceTiming?.format(value) || `${(value / 1000).toFixed(2)} s`;
  const loadingNote = text => {
    const note = node("p", "activity-note output-loading", text);
    note.setAttribute("role", "status");
    return note;
  };
  function render(panel, detail, copyButton) {
    panel.replaceChildren();
    if (!detail.completed_at) panel.append(loadingNote(
      detail.tool_family === "task_contract" ? "Generating task contract…" : "Waiting for tool result…"));
    if (detail.tool_family === "task_contract" && detail.retry_task_contract === true) {
      const retry = node("button", "activity-retry", "Retry contract generation");
      retry.type = "button";
      const status = node("p", "activity-note"); status.setAttribute("role", "status");
      retry.addEventListener("click", async () => {
        const busyFeedback = window.SMTOBusy?.action("Loading tool result…", retry);
        try {
        retry.disabled = true; status.textContent = "Requesting retry…";
        try {
          const result = await window.SMTONative.retryTaskContract(detail.request_id, detail.invocation_id);
          if (!result) { retry.disabled = false; status.textContent = ""; return; }
          detail.retry_task_contract = false;
          status.textContent = "Retry requested. This run will continue when contract generation succeeds.";
        } catch (error) { retry.disabled = false; window.SMTOErrors.present(status, error); }

        } finally { busyFeedback?.finish(); }
      });
      panel.append(retry, status);
    }
    let remaining = limit;
    for (const section of (detail.sections || []).slice(0, 16)) {
      if (remaining <= 0) break;
      const block = node("section", "activity-section");
      block.dataset.sectionId = section.id;
      block.append(node("h4", "", section.label));
      const content = (section.kind === "json" ? JSON.stringify(section.data, null, 2)
        : formatted(section.data)) ?? "";
      const bounded = content.slice(0, remaining);
      remaining -= bounded.length;
      if (section.kind === "link_list" && Array.isArray(section.data) && bounded === content) {
        const list = node("ol", "activity-links");
        for (const result of section.data.slice(0, 100)) {
          const item = node("li"), title = result.title || result.url || "Untitled result";
          let url;
          try { url = new URL(result.url); } catch (_) { /* Keep invalid URLs as text. */ }
          if (url && ["http:", "https:"].includes(url.protocol)) {
            const link = node("a", "", title);
            link.href = url.href; link.target = "_blank"; link.rel = "noopener noreferrer";
            item.append(link, node("div", "activity-source", url.href));
          } else item.append(node("span", "", title));
          if (result.published_date || result.published_at || result.date) {
            item.append(node("div", "activity-source", result.published_date || result.published_at || result.date));
          }
          if (result.snippet || result.description) item.append(node("p", "", result.snippet || result.description));
          list.append(item);
        }
        if (!list.children.length) block.append(node("p", "activity-note", "No results returned."));
        else block.append(list);
      } else if (section.kind === "key_value" && section.data && typeof section.data === "object"
                 && !Array.isArray(section.data) && bounded === content) {
        const list = node("dl", "activity-facts");
        for (const [key, value] of Object.entries(section.data)) {
          if (value === null) continue;
          list.append(node("dt", "", label(key)), node("dd", typeof value === "object" ? "activity-structured-fact" : "", factValue(value)));
        }
        block.append(list);
      } else {
        const pre = node("pre"), code = node("code", "", bounded);
        pre.append(code);
        if (copyButton) pre.append(copyButton(async () => {
          if (!section.truncated) return content;
          const response = await window.SMTOErrors.fetch(
            `/api/agent/trace/${encodeURIComponent(detail.request_id)}/invocations/${encodeURIComponent(detail.invocation_id)}/sections/${encodeURIComponent(section.id)}/copy`,
            {cache: "no-store"});
          if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
          const full = await window.SMTOErrors.readJson(response);
          return formatted(full.data) ?? "";
        }, {
          label: section.id === "task_contract" ? "Copy task contract" : "Copy sanitized data",
          failureMessage: "Could not copy the full content. Try again.",
        }));
        block.append(pre);
      }
      if (section.truncated || bounded !== content) {
        const notice = node("p", "activity-note", `Preview truncated · ${bytes(section.shown_bytes || bounded.length)} shown`
          + (section.total_bytes > section.shown_bytes ? ` · ${bytes(section.total_bytes)} available before preview limit` : ""));
        block.insertBefore(notice, block.children[1] || null);
      }
      panel.append(block);
    }
    if (detail.truncated) panel.append(node("p", "activity-note", "This invocation contains bounded previews; some content is not shown."));
    if (detail.elapsed_ms !== null && detail.elapsed_ms !== undefined) {
      panel.append(node("p", "activity-note", `Invocation elapsed · ${duration(detail.elapsed_ms)}`));
    }
  }
  function attach(row, requestId, eventDetail, copyButton) {
    if (!eventDetail.detail_available || !requestId) return;
    const version = eventDetail.detail_version || "completed";
    const invocationId = eventDetail.invocation_id || eventDetail.operation_id;
    const contract = eventDetail.kind === "task_contract";
    if (!row.inspector) {
      const disclosure = node("details", "tool-activity-detail");
      const summary = node("summary", "tool-activity-summary");
      const header = node("div", "activity-heading");
      const top = node("div", "activity-heading-top");
      top.append(...(row.cue ? [row.cue] : []), row.title);
      row.stats = node("span", "activity-stats");
      header.append(top, row.summary, row.stats);
      if (!row.standalone) row.copy.prepend(header);
      summary.textContent = contract ? "Task contract" : "Tool output";
      const panel = node("div", "activity-panel");
      disclosure.append(summary, panel);
      window.SMTOActivityPresentation.attachSection(row.copy, disclosure, summary.textContent);
      row.inspector = {disclosure, panel, requestId, invocationId, version, data: null, loading: ""};
      disclosure.addEventListener("toggle", () => {
        if (disclosure.open) void load(true);
        else { row.inspector.controller?.abort(); row.inspector.feedback?.dispose(); row.inspector.loading = ""; }
      });
    }
    const state = row.inspector;
    if (state.version === "completed" && version.startsWith("pending")) return;
    if (version.startsWith("pending") && state.version.startsWith("pending")
        && Number(version.split(":")[1] || 0) < Number(state.version.split(":")[1] || 0)) return;
    if (state.version !== version) { state.version = version; state.data = null; }
    row.stats.textContent = [eventDetail.status_text || (Number.isInteger(eventDetail.status_code) ? String(eventDetail.status_code) : ""),
      Number.isInteger(eventDetail.results) ? `${eventDetail.results} results` : "",
      Number.isFinite(eventDetail.elapsed_ms) ? duration(eventDetail.elapsed_ms) : ""].filter(Boolean).join(" · ");
    if (state.disclosure.open) load();
    async function load(feedback = false) {
    let busyFeedback;
    try {
      const current = row.inspector;
      if (window.SMTOUiFind?.isRevealed(current.disclosure)) return;
      if (current.data) { if (current.rendered !== current.version) {
        render(current.panel, current.data, copyButton); current.rendered = current.version;
      } return; }
      if (current.loading === current.version) return;
      busyFeedback = feedback ? window.SMTOBusy?.begin({host: current.panel, label: contract ? "Loading task contract…" : "Loading execution details…"}) : null;
      current.feedback = busyFeedback;
      const request = current.controller = new AbortController();
      const loadingVersion = current.version;
      current.loading = loadingVersion;
      if (!current.rendered) {
        const note = loadingNote(contract ? "Loading task contract…" : "Loading execution details…");
        note.hidden = Boolean(busyFeedback);
        current.panel.replaceChildren(note);
      }
      try {
        const response = await window.SMTOErrors.fetch(`/api/agent/trace/${encodeURIComponent(current.requestId)}/invocations/${encodeURIComponent(current.invocationId)}`,
          {headers: {Accept: "application/json"}, cache: "no-store", signal: request.signal});
        if (request.signal.aborted || current.controller !== request) return;
        if (current.version !== loadingVersion) return;
        if (response.status === 404 || response.status === 410) {
          current.panel.replaceChildren(node("p", "activity-note", contract ? "This task contract is no longer available." : "Execution details are no longer available."));
          return;
        }
        if (!response.ok) throw await window.SMTOErrors.fromResponse(response);
        const data = await window.SMTOErrors.readJson(response);
        if (request.signal.aborted || current.controller !== request || current.version !== loadingVersion) return;
        if (data.request_id !== current.requestId || data.invocation_id !== current.invocationId
            || !Array.isArray(data.sections)) throw window.SMTOErrors.error("ui_response_invalid");
        current.data = data;
        current.rendered = current.version;
        render(current.panel, data, copyButton);
      } catch (_) {
        if (request.signal.aborted || current.controller !== request) return;
        if (current.version !== loadingVersion) return;
        const retry = node("button", "activity-retry", "Retry"); retry.type = "button";
        retry.addEventListener("click", () => load(true));
        current.panel.replaceChildren(node("p", "activity-note", contract ? "Could not load task contract." : "Could not load execution details."), retry);
      } finally {
        if (current.controller === request && current.loading === loadingVersion) current.loading = "";
      }

    } finally { busyFeedback?.finish(); }
  }
  }
  function mount(container, requestId, detail, copyButton) {
    const row = {copy: container, title: node("strong", "", detail.kind === "task_contract" ? "Task contract" : "Tool output"),
      summary: node("p", ""), standalone: true};
    row.summary.hidden = true;
    attach(row, requestId, detail, copyButton);
    row.updateDetails = detail => attach(row, requestId, detail, copyButton);
    return row;
  }
  window.SMTOToolActivity = {attach, mount};
})();
