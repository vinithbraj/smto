---
id: browser
title: Browser automation
kind: architecture
tags: [architecture, browser, gateway, current]
order: 39
---
# Browser automation

Browser is an optional rendered-reading and interactive skill on the **selected Gateway**. The ordinary Agent
uses deterministic browser tools; there is no browser Agent, locator model, DOM summarizer
or screenshot classifier. Web remains the separate lightweight public search/read skill.
The optional [Web Research](43-web-research.md) Skill begins with Web and can request
Browser separately when a named source needs rendered/session access. Selecting Web
Research never grants Browser or changes Browser's operation effects and approvals.
Browser is disabled in new capability selections by default. Existing saved selections
remain authoritative. Enable Browser in the existing capability controls; individual tools
show the selected Gateway's negotiated availability.

## Installation and configuration

The standard Gateway installers install Playwright in the Gateway's Python environment,
download its matching Chromium, and verify a local headless JavaScript render. Browser
execution is enabled by default; no extra startup argument or environment variable is
required. After updating an existing Gateway, restart it and refresh its metadata.
Installation is an explicit operator action; imports and discovery never install packages
or browser binaries.

```bash
./src/gateway_agent/install.sh
./src/gateway_agent/startup.sh
```

Use `src/gateway_macos/install.sh` / `startup.sh` on macOS and
`src/gateway_windows/install.ps1` / `startup.ps1` on Windows. On apt-based Linux,
setup also installs Chromium's OS dependencies unless `AOR_SKIP_SYSTEM_DEPS=1`,
`GATEWAY_SKIP_SYSTEM_DEPS=1`, or `AOR_INSTALL_SYSTEM_DEPS=0` is set. Other Linux
distributions must provide compatible browser libraries. A failed download or launch
fails installation rather than reporting a ready browser. Install and run under the same
OS account, or configure the same accessible `PLAYWRIGHT_BROWSERS_PATH` for both.

| Gateway setting | Default and meaning |
| --- | --- |
| `GATEWAY_BROWSER_ENABLED` | `true`; explicit `false` disables browser execution on this Gateway |
| `GATEWAY_BROWSER_HEADLESS` | `true`; default for managed starts |
| `GATEWAY_BROWSER_PROFILE_ROOT` | `~/.smto/browser`; service creates a private `managed` child |
| `GATEWAY_BROWSER_ALLOW_ATTACH` | `false`; allow explicit CDP attachment |
| `GATEWAY_BROWSER_CDP_ENDPOINT` | Absent; operator-provided endpoint, never a tool argument or status field |

Treat an authenticated CDP endpoint as a secret. Supply it through the Gateway environment,
not ordinary application settings JSON. The setting is excluded from Settings serialization.
No ports are scanned and no personal browser is relaunched or configured automatically.

The current backend is Chromium through Playwright, a standard runtime dependency.
The `browser` extra remains accepted for compatibility. Linux managed
headless and explicit CDP are exercised by local fixture tests. Windows/macOS use Playwright's
Chromium APIs but require validation on those platforms. Firefox/WebKit, cloud browsers,
extension attachment, stealth, CAPTCHA bypass and browser binary installation tools are absent.
A headed session needs an interactive Gateway desktop and its display environment.

`GET /capabilities` includes `browser_runtime`. `browser_status` means diagnostics are supported,
including when automation is unavailable. Other tags are `browser_managed`, `browser_interact`,
`browser_attach_cdp`, `browser_upload`, `browser_downloads`, `browser_screenshot`,
`browser_headless` and `browser_headed`. Missing package and missing Chromium binary have
separate error identities. Controller OS and arbitrary configured capability tags cannot
create backend support.

## Sessions and discovery

The entry set is `browser.status`, `browser.start`, `browser.tabs`, `browser.read_page`.
Discover the following sections for other operations. All IDs below use the `browser.` prefix.

| Section | Operations |
| --- | --- |
| `browser.sessions` | `status`, `start`, `stop`, `sessions`, `attach`, `detach` |
| `browser.tabs` | `tabs`, `open_tab`, `activate_tab`, `close_tab` |
| `browser.navigation` | `navigate`, `back`, `forward`, `reload`, `page_info` |
| `browser.read` | `read_page`, `snapshot`, `find` |
| `browser.interact` | `click`, `fill`, `type_text`, `press`, `select_option`, `check`, `scroll`, `wait_for` |
| `browser.files` | `upload_file`, `downloads`, `wait_for_download`, `screenshot` |

Every session belongs to the conversation that created it on that Gateway. Exact opaque session
and tab IDs prevent title-based targeting. Sessions live until explicit stop/detach or Gateway
shutdown; they do not survive a Gateway restart. The service owns at most eight sessions and
32 tracked tabs per session. Calls serialize at the Gateway to avoid interleaved mutations.

A managed start defaults to Chromium, ephemeral persistence and the configured headless mode.
`profile` is a short logical identifier, never an arbitrary directory. Persistent profiles
require an SMTO ownership marker; an existing unmarked nonempty directory is rejected.
Profiles are never copied from Chrome/Edge/Firefox defaults. `stop` retains persistent profiles
and deletes only the temporary profile owned by that ephemeral session. POSIX directories use
mode 0700. There is no profile-clear/delete tool.

An attached session has `attached=true` and uses only the operator's configured CDP endpoint.
`stop` rejects it; `detach` disconnects without closing the externally owned context or process.
Attachment is not equivalent to a newly managed session. When attachment is not configured,
ask the operator to configure it or offer an explicitly separate managed session.

## Semantic interaction and bounds

```json
{"browser":"chromium","persistence":"ephemeral","headless":false,
 "initial_url":"https://support.example/"}
```

Use returned `browser_session_id` and `tab_id` for a read or find:

```json
{"browser_session_id":"session_...","tab_id":"tab_...",
 "locator":{"role":"button","name":"Save","exact":true}}
```

Click a returned reference with the same session and tab:

```json
{"browser_session_id":"session_...","tab_id":"tab_...","element_ref":"element_..."}
```

The alternative `locator` accepts exactly one of role (optionally name), label, text, test ID
or placeholder. Exact matching and visible-only matching default to true. Actions require one
match; zero and multiple matches have distinct errors. No CSS/XPath or arbitrary JavaScript
argument exists. Main-frame semantic interaction is supported; iframe interaction is not.

References retain **exact element handles**, never a selector to be re-resolved later. DOM
child/attribute/text changes and frame navigation invalidate the current generation. A new
snapshot/find replaces the bounded reference working set. Never reuse a ref after a stale
error; inspect again. This conservative behavior can invalidate refs on active SPAs more often
than a human expects. Waits poll locally in the same operation, without additional Agent turns.

Reads exclude input values, hidden/script/style text and password values. Page text is bounded
to 24,000 characters (default 8,000); snapshots/find to 200 elements (default 100); semantic
candidate matching to 1,000. Metadata has independent bounds: 32 headings, 50 links/controls,
three tables of at most 20 rows and ten cells per row. There is no full HTML result. A result
has `truncated` when the selected projection exceeds its bounds. Envelopes are capped at
512 KiB. `timeout_ms` is 1–60,000, default 10,000, including waits and queue time.

Direct navigation accepts HTTP(S) only. Observed URLs omit userinfo, query and fragment;
URL display also uses the shared redaction processor. Browser tools do not provide `file:`
page reading or bypass the File skill's local-path boundary. Screenshots capture only the
viewport (at most 16 million pixels), with input, textarea, select and editable fields masked.
There is no periodic screenshot or DOM-content streaming.

## Files, secrets and external content

Upload uses a regular absolute **Gateway-local** path and the existing no-follow file reader;
it does not read the controller filesystem. Transfer a file from another Gateway using
`gateway.copy` first. Uploads and artifact exports are capped at 16 MiB. A browser may receive
a larger download into its browser-owned temporary area; export rejects it and deletes that
browser download. The export cap is not a network traffic quota.

Downloads are observed only during explicit session operations and receive opaque IDs. Use
`wait_for_download` or `downloads` with an exact `download_id` and `as_artifact:true` to await
completion and export it. To wait for a newly observed download, use `after_download_id` when
older downloads exist. Ambiguous selection never chooses the first download. At most 100
handles are retained per session. Download filenames remain untrusted metadata and never
choose filesystem paths. Closing a session releases its browser temporary downloads; export
requested outputs before stopping it.

Screenshots and exported downloads publish into the existing run artifact workspace. The
normal collector transfers and registers durable `artifact://` outputs on the controller.
Binary content is never embedded in ordinary tool JSON. If collection fails, the normal
artifact retry path applies without repeating the browser action.

This checkout uses literal Parameter Store values and optional redaction; it has no secure
post-model substitution suitable for `fill_secret`. Accordingly, there is **no `fill_secret`
tool**. `fill`, `type_text` and `press` reject password fields. Ask the user to log in directly
in the headed browser and confirm completion through ordinary `ask_user`; never request the
password in chat. No cookies, password database, authentication tokens, localStorage or
sessionStorage export APIs exist. Existing ordinary input values are not returned.

Page text, labels, titles, URLs and filenames carry `content_trust=untrusted_external_data`.
They are tool data, never system/developer instructions. Page requests to run commands or
reveal secrets grant no authority. The normal Agent must use the user's request and existing
permission policy. Shared transient-content minimization keeps browser arguments/page bodies
out of diagnostics, portable history, automatic working-context capsules and Handoff; exact
current-run tool evidence remains available. This is an architectural boundary, not a claim
that arbitrary model reasoning can be mathematically guaranteed injection-proof.

## Effects, cancellation and recovery

Sessions/list/status, page reads, snapshots/find, waits, download observation/export and
screenshots are external reads. All other operations, including navigation, scrolling,
activation and form actions, are external writes and use existing confirmation/permission
machinery. Active Web Research has one scoped default-confirmation exception for its
research Browser allowlist (session/tab management, navigation and ordinary interaction).
Explicit Permission Policy Ask/Deny and deny mode, capability fences, unsafe-action checks,
secret protections and unknown-effect replay restrictions still apply. Effect classes stay
unchanged. Upload and attachment authority is not widened. No browser-specific approval
store or classifier exists. See [Web Research](43-web-research.md) for method requirements
and durable soft-allowance extension cards.

Transport routes are authenticated `POST /browser/operation` and `POST /browser/cancel`,
with exact node checks on direct and outbound Gateways. Runtime execution identity and
conversation/run scope are transport fields, not model arguments. Every request executes
once; duplicate IDs are fenced. Identity-only fences are bounded to 8,192 per Gateway service
lifetime and fail closed when full. Restart only after reconciling outstanding effects;
existing durable native receipts continue to prohibit unknown mutation replay across restart.

Cancellation before dispatch proves non-execution. Once a mutation is submitted, cancellation,
timeout or response loss can mean `effect_unknown=true`, `executed=null`,
`remote_effect_possible=true`. These fields do not claim success or failure of the remote
business action. Inspect `page_info`, `snapshot` and `downloads` to reconcile. Never click
Submit again solely because the response was lost. Repeated Agent attempts remain blocked
by the existing native unknown-effect machinery.

Canonical errors use `browser_*` error kinds and `browser-*` catalog slugs (also resolvable
through dotted `browser.*` aliases). Examples: `browser_backend_unavailable`,
`browser_browser_binary_missing`, `browser_attach_not_configured`, `browser_element_stale`,
`browser_element_ambiguous`, `browser_file_not_found_on_target`,
`browser_secret_binding_unavailable`, `browser_operation_cancelled`, and
`browser_operation_outcome_unknown`. Error detail/manual links supply exact remediation;
provider exception text, form contents and endpoint secrets are not copied into diagnostics.
