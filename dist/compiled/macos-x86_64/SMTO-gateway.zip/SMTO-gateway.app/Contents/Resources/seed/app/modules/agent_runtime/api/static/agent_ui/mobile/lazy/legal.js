import { api, node, button } from "../api.js?v=20261018-loading";
import { openSheet, closeSheet } from "../overlays.js?v=20261018-loading";
import { markdown } from "../markdown.js?v=20261018-loading";

export async function ensureAgreement() {
  const status = await api("/api/legal/eula/status");
  if (status.accepted === true) return true;
  const body = openSheet(`Review the ${window.__BRANDING__.display_name} agreement`);
  const document = await api("/api/legal/eula");
  if (!body.isConnected) return false;
  const licensing = node("p", document.usage_policy?.summary || "");
  const licensingLink = node("a", "Licensing details and commercial use");
  licensingLink.href = "https://smtorch.com";
  licensingLink.target = "_blank"; licensingLink.rel = "noopener";
  licensing.append(" ", licensingLink);
  body.append(licensing);
  body.append(node("p", `${window.__BRANDING__.display_name} can use authorized tools to perform real actions on your computers. Before starting new work, please review the license and automation risks for this distribution.`));
  body.append(
    node(
      "p",
      `Agreement version: ${document.version} · Applies to designated proprietary ${document.display_name || window.__BRANDING__.display_name} material. Earlier open-source and third-party rights remain unchanged.`,
    ),
  );
  const terms = node("div");
  markdown(terms, document.display_template || document.text);
  if (document.display_template && typeof document.display_name === "string") {
    const walker = terms.ownerDocument.createTreeWalker(terms, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      // Keep the legal product name independent of personalized UI labels.
      walker.currentNode.textContent = walker.currentNode.textContent.replaceAll(
        "{{brand.display_name}}", () => document.display_name);
    }
  }
  terms.tabIndex = 0;
  terms.setAttribute("role", "region");
  terms.setAttribute("aria-label", "Agreement text");
  const full = node("a", "View full agreement");
  full.href = "/legal/eula"; full.target = "_blank"; full.rel = "noopener";
  body.append(terms, full);
  const label = node("label"),
    check = node("input");
  check.type = "checkbox";
  label.append(
    check,
    node(
      "span",
      "I have read and agree to the End User License Agreement and acknowledge the automation risks described above.",
    ),
  );
  body.append(label);
  const agree = button(
    "I Agree & Continue",
    async () => {
 const busyFeedback = window.SMTOBusy?.action("Saving agreement…");
 try {
      if (!check.checked) return;
      await api("/api/legal/eula/accept", {
        method: "POST",
        body: {
          agree: true,
          version: document.version,
          document_sha256: document.document_sha256,
        },
      });
      await closeSheet();

 } finally { busyFeedback?.finish(); }
},
    "primary",
  );
  agree.disabled = true;
  check.onchange = () => {
    agree.disabled = !check.checked;
  };
  const declined = node("p"); declined.setAttribute("role", "status");
  body.append(declined, button("Decline", () => {
    declined.textContent = `You have not accepted the current ${window.__BRANDING__.display_name} agreement. New work that requires acceptance is unavailable. You can review the terms and choose again at any time.`;
    check.checked = false; agree.disabled = true;
  }), agree);
  // No automatic submission after consent; the intact composer can be sent again.
  return false;
}
